
import junit.framework.*;

public class RandoopTest2 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test1"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("14");
    org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var3 = var2.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    var5.setDomainZeroBaselineVisible(false);
    var2.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var5);
    var2.setDefaultEntityRadius((-1));
    java.awt.Stroke var13 = null;
    var2.setSeriesStroke(1, var13);
    java.awt.Shape var16 = var2.lookupLegendShape(100);
    org.jfree.chart.labels.XYItemLabelGenerator var18 = var2.getSeriesItemLabelGenerator(0);
    boolean var19 = var1.equals((java.lang.Object)var2);
    boolean var20 = var2.getDataBoundsIncludesVisibleSeriesOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test2"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("0,0,1,1");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test3"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    var1.clear();
    java.util.List var5 = var1.getItems();
    var1.setDescription("Combined Range XYPlot");
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var9.setDomainDescription("");
    java.util.Collection var12 = var1.getTimePeriodsUniqueToOtherSeries(var9);
    long var13 = var1.getMaximumItemAge();
    var1.setRangeDescription("PlotEntity: tooltip = null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 9223372036854775807L);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test4"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("ChartEntity: tooltip = ", "ERROR : Relative To String", "ThreadContext", "-2", "Pie Plot");

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test5"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.lang.Object var3 = var1.clone();
    var1.setBackgroundAlpha(0.0f);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    var8.setDomainZeroBaselineVisible(false);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot(var13);
    org.jfree.chart.axis.AxisLocation var15 = var14.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var16 = org.jfree.chart.axis.AxisLocation.getOpposite(var15);
    var8.setRangeAxisLocation(0, var16, true);
    boolean var19 = var8.isDomainPannable();
    var8.clearRangeMarkers();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.ChartRenderingInfo var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
    java.awt.geom.Rectangle2D var24 = var23.getDataArea();
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var24, "");
    org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var28.setDomainDescription("");
    var28.clear();
    java.util.List var32 = var28.getItems();
    var8.drawDomainTickBands(var21, var24, var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.mapDatasetToRangeAxes(520764324, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test6"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.event.AxisChangeEvent var31 = null;
    var30.axisChanged(var31);
    org.jfree.chart.axis.AxisLocation var33 = var30.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test7"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    java.lang.Comparable var3 = var1.getAggregatedItemsKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Other"+ "'", var3.equals("Other"));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test8"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.Range var2 = var0.getDomainBounds(false);
    var0.clearSelection();
    org.jfree.data.DomainOrder var4 = var0.getDomainOrder();
    org.jfree.data.Range var6 = var0.getDomainBounds(false);
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.axis.AxisLocation var9 = var8.getDomainAxisLocation();
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var0.getItemCount(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    java.util.List var33 = var30.getCategories();
    var30.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    java.awt.Paint var36 = var30.getRangeGridlinePaint();
    org.jfree.chart.plot.Marker var38 = null;
    org.jfree.chart.util.Layer var39 = null;
    boolean var40 = var30.removeDomainMarker(1969, var38, var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test10"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var1.setUseFillPaint(true);
    var1.setSeriesShapesFilled(5, (java.lang.Boolean)false);
    java.awt.Paint var7 = var1.getBaseFillPaint();
    java.awt.Stroke var8 = null;
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
    float var11 = var10.getTickMarkInsideLength();
    int var12 = var10.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
    var14.setRangeWithMargins(var17);
    var14.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var21 = var14.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var23 = var22.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
    org.jfree.chart.plot.DrawingSupplier var26 = var25.getDrawingSupplier();
    var25.setDomainZeroBaselineVisible(false);
    var22.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var25);
    var22.setDefaultEntityRadius((-1));
    java.awt.Stroke var33 = null;
    var22.setSeriesStroke(1, var33);
    java.awt.Shape var36 = var22.lookupLegendShape(100);
    var14.setDownArrow(var36);
    org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var9, (org.jfree.chart.axis.CategoryAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var38);
    org.jfree.chart.util.RectangleEdge var40 = var39.getRangeAxisEdge();
    java.awt.Paint var41 = var39.getRangeMinorGridlinePaint();
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D();
    float var44 = var43.getTickMarkInsideLength();
    int var45 = var43.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var47 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var48 = null;
    org.jfree.data.Range var50 = org.jfree.data.Range.expandToInclude(var48, 0.0d);
    var47.setRangeWithMargins(var50);
    var47.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var54 = var47.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var55 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var56 = var55.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var58 = new org.jfree.chart.plot.CombinedRangeXYPlot(var57);
    org.jfree.chart.plot.DrawingSupplier var59 = var58.getDrawingSupplier();
    var58.setDomainZeroBaselineVisible(false);
    var55.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var58);
    var55.setDefaultEntityRadius((-1));
    java.awt.Stroke var66 = null;
    var55.setSeriesStroke(1, var66);
    java.awt.Shape var69 = var55.lookupLegendShape(100);
    var47.setDownArrow(var69);
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var42, (org.jfree.chart.axis.CategoryAxis)var43, (org.jfree.chart.axis.ValueAxis)var47, var71);
    var72.setWeight((-123));
    var72.clearAnnotations();
    org.jfree.chart.renderer.category.CategoryItemRenderer var76 = null;
    var72.setRenderer(var76, true);
    var72.mapDatasetToRangeAxis(5, 100);
    java.awt.Stroke var82 = var72.getRangeZeroBaselineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var84 = new org.jfree.chart.plot.ValueMarker(18.0d, var7, var8, var41, var82, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test11"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)true, var1, 5, (-123));
    java.lang.Object var5 = var4.getSource();
    java.lang.Object var6 = var4.getSource();
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var8 = var7.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var9 = var7.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var7.setLegendLabelURLGenerator(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.Plot var13 = var12.getPlot();
    java.util.List var14 = var12.getSubtitles();
    var4.setChart(var12);
    int var16 = var4.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + true+ "'", var5.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + true+ "'", var6.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 5);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test12"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Other", var1);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test13"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 5.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test14"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.ChartRenderingInfo var3 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var4 = new org.jfree.chart.plot.PlotRenderingInfo(var3);
//     java.awt.geom.Rectangle2D var5 = var4.getDataArea();
//     org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var5, "");
//     java.awt.geom.Point2D var8 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 2.88E7d, var5);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, (java.awt.Shape)var5, 2.88E7d, 2.0f, 0.0f);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test15"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     boolean var12 = var1.isDomainPannable();
//     var1.clearRangeMarkers();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var21.setDomainDescription("");
//     var21.clear();
//     java.util.List var25 = var21.getItems();
//     var1.drawDomainTickBands(var14, var17, var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, 0.0d, 1.0d);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     var30.setUseFillPaint(true);
//     var30.setSeriesShapesFilled(5, (java.lang.Boolean)false);
//     java.awt.Paint var36 = var30.getBaseFillPaint();
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var17, var36);
//     var37.setShapeOutlineVisible(true);
//     var37.setShapeVisible(true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var44 = var42.lookupSeriesPaint(0);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var45 = var42.getLegendItemURLGenerator();
//     java.awt.Shape var47 = var42.lookupLegendShape(1);
//     var37.setShape(var47);
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var50 = new org.jfree.chart.plot.CombinedRangeXYPlot(var49);
//     org.jfree.chart.plot.DrawingSupplier var51 = var50.getDrawingSupplier();
//     var50.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var56 = new org.jfree.chart.plot.CombinedRangeXYPlot(var55);
//     org.jfree.chart.axis.AxisLocation var57 = var56.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var58 = org.jfree.chart.axis.AxisLocation.getOpposite(var57);
//     var50.setRangeAxisLocation(0, var58, true);
//     boolean var61 = var50.isDomainPannable();
//     var50.clearRangeMarkers();
//     java.awt.Graphics2D var63 = null;
//     org.jfree.chart.ChartRenderingInfo var64 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var65 = new org.jfree.chart.plot.PlotRenderingInfo(var64);
//     java.awt.geom.Rectangle2D var66 = var65.getDataArea();
//     org.jfree.chart.entity.ChartEntity var68 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var66, "");
//     org.jfree.data.time.TimeSeries var70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var70.setDomainDescription("");
//     var70.clear();
//     java.util.List var74 = var70.getItems();
//     var50.drawDomainTickBands(var63, var66, var74);
//     java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var66, 0.0d, 1.0d);
//     var37.setShape(var78);
//     
//     // Checks the contract:  equals-hashcode on var1 and var50
//     assertTrue("Contract failed: equals-hashcode on var1 and var50", var1.equals(var50) ? var1.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var56
//     assertTrue("Contract failed: equals-hashcode on var7 and var56", var7.equals(var56) ? var7.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var1
//     assertTrue("Contract failed: equals-hashcode on var50 and var1", var50.equals(var1) ? var50.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var7
//     assertTrue("Contract failed: equals-hashcode on var56 and var7", var56.equals(var7) ? var56.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var51
//     assertTrue("Contract failed: equals-hashcode on var2 and var51", var2.equals(var51) ? var2.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var2
//     assertTrue("Contract failed: equals-hashcode on var51 and var2", var51.equals(var2) ? var51.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var65
//     assertTrue("Contract failed: equals-hashcode on var16 and var65", var16.equals(var65) ? var16.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var16
//     assertTrue("Contract failed: equals-hashcode on var65 and var16", var65.equals(var16) ? var65.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test16"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.event.PlotChangeEvent var4 = null;
//     var3.plotChanged(var4);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
//     var3.setRangeGridlinePaint(var9);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     org.jfree.chart.entity.ChartEntity var15 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var13, "");
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var16);
//     var3.setQuadrantOrigin(var17);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getItemLabelPadding();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getItemLabelPadding();
//     org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var1, (org.jfree.chart.title.Title)var19, "100");
//     org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
//     var24.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var27 = var24.getTickLabelInsets();
//     double var29 = var27.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     java.awt.geom.Rectangle2D var32 = var31.getDataArea();
//     org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var32, "");
//     org.jfree.chart.entity.ChartEntity var36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var32, "");
//     org.jfree.chart.util.LengthAdjustmentType var37 = null;
//     org.jfree.chart.util.LengthAdjustmentType var38 = null;
//     java.awt.geom.Rectangle2D var39 = var27.createAdjustedRectangle(var32, var37, var38);
//     var19.setLegendItemGraphicPadding(var27);
//     
//     // Checks the contract:  equals-hashcode on var12 and var31
//     assertTrue("Contract failed: equals-hashcode on var12 and var31", var12.equals(var31) ? var12.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var12
//     assertTrue("Contract failed: equals-hashcode on var31 and var12", var31.equals(var12) ? var31.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test17"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    var1.clear();
    var1.setMaximumItemAge(1L);
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(100);
    int var9 = var8.getYear();
    int var10 = var1.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test18"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Pie Plot", var1);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test19"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    org.jfree.chart.labels.CategoryToolTipGenerator var4 = null;
    var0.setBaseToolTipGenerator(var4, true);
    double var7 = var0.getXOffset();
    double var8 = var0.getMinimumBarLength();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = null;
    var0.setBaseItemLabelGenerator(var9);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator(2147483647, var12, false);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test20"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setBaseShapesVisible(true);
    var0.setAutoPopulateSeriesShape(true);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    org.jfree.chart.renderer.xy.XYItemRendererState var8 = new org.jfree.chart.renderer.xy.XYItemRendererState(var7);
    boolean var9 = var8.getProcessVisibleItemsOnly();
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    boolean var15 = var14.getNotify();
    org.jfree.chart.entity.TitleEntity var17 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape)var12, (org.jfree.chart.title.Title)var14, "{0}: ({1}, {2})");
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var12);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    double var21 = var20.getDomainCrosshairValue();
    boolean var22 = var20.isSubplot();
    org.jfree.chart.util.RectangleEdge var24 = var20.getDomainAxisEdge(1);
    var20.setForegroundAlpha(1.0f);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var29 = var28.getPaint();
    var20.setNoDataMessagePaint(var29);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
    org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
    java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var38 = null;
    org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var38, 0.0d);
    var37.setRangeWithMargins(var40);
    var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var37);
    org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
    var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var44);
    java.awt.Stroke var46 = var44.getMinorTickMarkStroke();
    org.jfree.data.Range var47 = var44.getDefaultAutoRange();
    var20.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var44, true);
    org.jfree.chart.axis.PeriodAxis var51 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var52 = null;
    org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, 0.0d);
    var51.setRangeWithMargins(var54);
    var51.setNegativeArrowVisible(false);
    java.awt.Shape var58 = var51.getRightArrow();
    org.jfree.chart.util.RectangleInsets var63 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, 4.0d, (-1.0d));
    var51.setTickLabelInsets(var63);
    org.jfree.chart.plot.RingPlot var65 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var66 = var65.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var67 = var65.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var68 = null;
    var65.setLegendLabelURLGenerator(var68);
    org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var65);
    java.awt.Stroke var71 = var70.getBorderStroke();
    var51.setMinorTickMarkStroke(var71);
    org.jfree.chart.axis.PeriodAxis var74 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var75 = null;
    org.jfree.data.Range var77 = org.jfree.data.Range.expandToInclude(var75, 0.0d);
    var74.setRangeWithMargins(var77);
    var74.setNegativeArrowVisible(false);
    var74.setLabelURL("hi!");
    var74.setAxisLineVisible(false);
    org.jfree.data.xy.DefaultXYDataset var85 = new org.jfree.data.xy.DefaultXYDataset();
    var0.drawItem(var5, var8, var12, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.axis.ValueAxis)var74, (org.jfree.data.xy.XYDataset)var85, 15, 0, false, (-457));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var93 = var85.getYValue(15, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test21"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var6 = var5.getPlot();
    org.jfree.chart.title.LegendTitle var8 = var5.getLegend(5);
    org.jfree.chart.title.TextTitle var9 = var5.getTitle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test22"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     var30.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var35 = var30.getRangeAxisEdge(2147483647);
//     var30.clearAnnotations();
//     org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var38 = var37.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
//     org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
//     var40.setDomainZeroBaselineVisible(false);
//     var37.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
//     var37.setDefaultEntityRadius((-1));
//     java.awt.Stroke var48 = null;
//     var37.setSeriesStroke(1, var48);
//     boolean var50 = var37.getBaseSeriesVisibleInLegend();
//     boolean var51 = var37.getAutoPopulateSeriesPaint();
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.plot.MultiplePiePlot var54 = new org.jfree.chart.plot.MultiplePiePlot(var53);
//     java.awt.Paint var55 = var54.getAggregatedItemsPaint();
//     var37.setSeriesItemLabelPaint(5, var55);
//     var30.setNoDataMessagePaint(var55);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var37.", var13.equals(var37) == var37.equals(var13));
//     
//     // Checks the contract:  equals-hashcode on var16 and var40
//     assertTrue("Contract failed: equals-hashcode on var16 and var40", var16.equals(var40) ? var16.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var16
//     assertTrue("Contract failed: equals-hashcode on var40 and var16", var40.equals(var16) ? var40.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var41
//     assertTrue("Contract failed: equals-hashcode on var17 and var41", var17.equals(var41) ? var17.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var17
//     assertTrue("Contract failed: equals-hashcode on var41 and var17", var41.equals(var17) ? var41.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test23"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     var3.setDomainZeroBaselineVisible(false);
//     java.lang.Object var7 = var3.clone();
//     var3.setRangePannable(true);
//     boolean var10 = var1.equals((java.lang.Object)var3);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var13 = var12.getRightArrow();
//     var12.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.axis.DateTickMarkPosition var17 = var12.getTickMarkPosition();
//     var3.setRangeAxis(520764324, (org.jfree.chart.axis.ValueAxis)var12, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test24"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setRangeZeroBaselineVisible(false);
    java.lang.Comparable var33 = var30.getDomainCrosshairRowKey();
    var30.setDomainCrosshairColumnKey((java.lang.Comparable)1.0E12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test25"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = null;
//     var0.setSeriesURLGenerator(4, var2);
//     var0.setIncludeBaseInRange(false);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var9 = var8.getTickMarkInsideLength();
//     int var10 = var8.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
//     var12.setRangeWithMargins(var15);
//     var12.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var19 = var12.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var21 = var20.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var23 = new org.jfree.chart.plot.CombinedRangeXYPlot(var22);
//     org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
//     var23.setDomainZeroBaselineVisible(false);
//     var20.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
//     var20.setDefaultEntityRadius((-1));
//     java.awt.Stroke var31 = null;
//     var20.setSeriesStroke(1, var31);
//     java.awt.Shape var34 = var20.lookupLegendShape(100);
//     var12.setDownArrow(var34);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var7, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var12, var36);
//     var37.setWeight((-123));
//     var37.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var41 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var45 = var41.getItemOutlineStroke(0, 0, true);
//     var37.setRangeGridlineStroke(var45);
//     org.jfree.chart.axis.ValueAxis var48 = var37.getRangeAxisForDataset(10);
//     java.awt.Stroke var49 = var37.getDomainCrosshairStroke();
//     boolean var50 = var37.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D();
//     var51.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var54 = var51.getTickLabelInsets();
//     double var56 = var54.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var57 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var58 = new org.jfree.chart.plot.PlotRenderingInfo(var57);
//     java.awt.geom.Rectangle2D var59 = var58.getDataArea();
//     org.jfree.chart.entity.ChartEntity var61 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var59, "");
//     org.jfree.chart.entity.ChartEntity var63 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var59, "");
//     org.jfree.chart.util.LengthAdjustmentType var64 = null;
//     org.jfree.chart.util.LengthAdjustmentType var65 = null;
//     java.awt.geom.Rectangle2D var66 = var54.createAdjustedRectangle(var59, var64, var65);
//     var0.drawBackground(var6, var37, var66);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test26"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange((-1.0d), 0.0d);
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    float var7 = var6.getTickMarkInsideLength();
    int var8 = var6.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
    var10.setRangeWithMargins(var13);
    var10.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var17 = var10.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    var21.setDomainZeroBaselineVisible(false);
    var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
    var18.setDefaultEntityRadius((-1));
    java.awt.Stroke var29 = null;
    var18.setSeriesStroke(1, var29);
    java.awt.Shape var32 = var18.lookupLegendShape(100);
    var10.setDownArrow(var32);
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var34);
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
    var36.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var39 = var36.getTickLabelInsets();
    var35.setAxisOffset(var39);
    var4.setInsets(var39, false);
    var0.setLabelInsets(var39, false);
    double var46 = var39.extendHeight(1.0d);
    java.awt.geom.Rectangle2D var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var48 = var39.createInsetRectangle(var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 5.0d);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test27"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    var1.setRangeWithMargins(var4);
    var1.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var8 = var1.getPlot();
    java.lang.Object var9 = var1.clone();
    var1.pan(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test28"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAnchor var1 = var0.getDomainGridlinePosition();
//     org.jfree.data.category.CategoryDataset var3 = var0.getDataset((-1));
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot(var5);
//     org.jfree.chart.axis.AxisLocation var7 = var6.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var8 = org.jfree.chart.axis.AxisLocation.getOpposite(var7);
//     var0.setRangeAxisLocation(4, var8);
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var11 = var10.getTickMarkInsideLength();
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
//     org.jfree.chart.event.PlotChangeEvent var14 = null;
//     var13.plotChanged(var14);
//     var10.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var13);
//     java.lang.String var17 = var10.getLabelToolTip();
//     boolean var18 = var10.isAxisLineVisible();
//     org.jfree.chart.axis.CategoryAxis[] var19 = new org.jfree.chart.axis.CategoryAxis[] { var10};
//     var0.setDomainAxes(var19);
//     
//     // Checks the contract:  equals-hashcode on var6 and var13
//     assertTrue("Contract failed: equals-hashcode on var6 and var13", var6.equals(var13) ? var6.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var6
//     assertTrue("Contract failed: equals-hashcode on var13 and var6", var13.equals(var6) ? var13.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test29"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    var31.setWeight((-123));
    java.lang.Comparable var34 = null;
    var31.setDomainCrosshairColumnKey(var34);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
    org.jfree.data.xy.XYDatasetSelectionState var37 = var0.getSelectionState();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test30"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 5, 0);
    var3.addException(9223372036854775807L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var8 = var3.containsDomainRange(604800000L, 0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test31"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var1 = var0.getSeparatorStroke();
//     var0.setIgnoreNullValues(true);
//     java.lang.String var4 = var0.getPlotType();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var9, "");
//     org.jfree.chart.util.RectangleAnchor var12 = null;
//     java.awt.geom.Point2D var13 = org.jfree.chart.util.RectangleAnchor.coordinates(var9, var12);
//     org.jfree.chart.plot.PlotState var14 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesPositiveItemLabelPosition(0);
//     java.awt.Shape var18 = var15.getBaseLegendShape();
//     var15.setSeriesVisible(10, (java.lang.Boolean)true);
//     org.jfree.chart.labels.StandardXYSeriesLabelGenerator var23 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("SerialDate.weekInMonthToString(): invalid code.");
//     var15.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var23);
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Rectangle2D var27 = var26.getDataArea();
//     java.awt.geom.Rectangle2D var28 = var26.getPlotArea();
//     boolean var29 = var23.equals((java.lang.Object)var26);
//     var0.draw(var5, var6, var13, var14, var26);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test32"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
    var3.clear();
    org.jfree.chart.block.Arrangement var5 = var3.getArrangement();
    java.lang.Object var6 = var3.clone();
    var3.setMargin((-2.0d), 14.0d, 0.0d, 14.0d);
    java.lang.String var12 = var3.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test33"); }
// 
// 
//     org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.lang.Comparable var34 = null;
//     var31.setDomainCrosshairColumnKey(var34);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
//     org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var38 = var37.clone();
//     var31.setFixedRangeAxisSpace(var37);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot(var42);
//     org.jfree.chart.axis.AxisLocation var44 = var43.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var45 = org.jfree.chart.axis.AxisLocation.getOpposite(var44);
//     org.jfree.chart.axis.AxisLocation var46 = org.jfree.chart.axis.AxisLocation.getOpposite(var45);
//     var31.setDomainAxisLocation(5, var46, false);
//     
//     // Checks the contract:  equals-hashcode on var17 and var43
//     assertTrue("Contract failed: equals-hashcode on var17 and var43", var17.equals(var43) ? var17.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var17
//     assertTrue("Contract failed: equals-hashcode on var43 and var17", var43.equals(var17) ? var43.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test34"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
//     org.jfree.chart.plot.DrawingSupplier var35 = var34.getDrawingSupplier();
//     java.awt.Paint var36 = var34.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var37 = var34.getDomainAxisEdge();
//     var31.ensureAtLeast(100.0d, var37);
//     var31.setRight(4.0d);
//     double var41 = var31.getBottom();
//     var30.setFixedRangeAxisSpace(var31, true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var34
//     assertTrue("Contract failed: equals-hashcode on var16 and var34", var16.equals(var34) ? var16.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var16
//     assertTrue("Contract failed: equals-hashcode on var34 and var16", var34.equals(var16) ? var34.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var35
//     assertTrue("Contract failed: equals-hashcode on var17 and var35", var17.equals(var35) ? var17.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var17
//     assertTrue("Contract failed: equals-hashcode on var35 and var17", var35.equals(var17) ? var35.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test35"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.data.Range var15 = var0.findDomainBounds(var14);
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.StandardPieToolTipGenerator var20 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var21 = var20.getNumberFormat();
    java.text.DateFormat var22 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var23 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var21, var22);
    java.lang.Object var24 = var23.clone();
    var0.setSeriesToolTipGenerator(0, (org.jfree.chart.labels.XYToolTipGenerator)var23, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test36"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    java.awt.geom.Rectangle2D var3 = var1.getBounds();
    org.jfree.chart.util.RectangleInsets var4 = var1.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test37"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test38"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    var0.setIgnoreZeroValues(false);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var0.setLabelLinkMargin(Double.NaN);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test39"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var1 = var0.getPercentFormat();
    java.lang.Object var2 = var0.clone();
    java.text.NumberFormat var3 = var0.getNumberFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test40"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.LegendItemCollection var33 = var30.getLegendItems();
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.awt.geom.Rectangle2D var36 = var35.getDataArea();
    org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var36, "");
    boolean var39 = var33.equals((java.lang.Object)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test41"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    var0.setBarAlignmentFactor(4.0d);
    org.jfree.chart.labels.XYItemLabelGenerator var15 = null;
    var0.setSeriesItemLabelGenerator(5, var15, false);
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var20 = var19.getPaint();
    java.awt.geom.Rectangle2D var21 = var19.getBounds();
    var0.setLegendBar((java.awt.Shape)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test42"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
    java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.util.RectangleEdge.opposite(var7);
    var1.setPosition(var7);
    org.jfree.chart.util.RectangleInsets var10 = var1.getPadding();
    org.jfree.chart.event.TitleChangeEvent var11 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.util.RectangleEdge var12 = var1.getPosition();
    java.awt.geom.Rectangle2D var13 = var1.getBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test43"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    var7.setRangeWithMargins(var10);
    boolean var12 = var3.equals((java.lang.Object)var10);
    org.jfree.data.Range var15 = org.jfree.data.Range.shift(var10, 0.05d, false);
    org.jfree.chart.block.RectangleConstraint var16 = var2.toRangeWidth(var15);
    java.lang.String var17 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.05, height=0.0]"+ "'", var17.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.05, height=0.0]"));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test44"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot(var1);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var2.setFixedRangeAxisSpace(var3);
    org.jfree.chart.LegendItemCollection var5 = new org.jfree.chart.LegendItemCollection();
    var2.setFixedLegendItems(var5);
    var0.add((org.jfree.chart.plot.XYPlot)var2);
    java.util.List var8 = var0.getSubplots();
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
    org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
    var10.setDomainZeroBaselineVisible(false);
    var10.configureRangeAxes();
    var10.clearDomainMarkers();
    double var16 = var10.getGap();
    var0.add((org.jfree.chart.plot.XYPlot)var10);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    org.jfree.chart.plot.CrosshairState var22 = new org.jfree.chart.plot.CrosshairState(false);
    var22.setDatasetIndex(100);
    org.jfree.chart.ChartRenderingInfo var25 = null;
    org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
    java.awt.geom.Rectangle2D var27 = var26.getDataArea();
    org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var27, "");
    org.jfree.chart.util.RectangleAnchor var30 = null;
    java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var27, var30);
    var22.setAnchor(var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(2.0d, 2.88E7d, var20, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test45"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot(var1);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var2.setFixedRangeAxisSpace(var3);
    org.jfree.chart.LegendItemCollection var5 = new org.jfree.chart.LegendItemCollection();
    var2.setFixedLegendItems(var5);
    var0.add((org.jfree.chart.plot.XYPlot)var2);
    java.awt.Stroke var8 = var0.getDomainMinorGridlineStroke();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
    var11.setRangeWithMargins(var14);
    var11.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var18 = var11.getPlot();
    java.awt.Shape var19 = var11.getUpArrow();
    org.jfree.chart.axis.PeriodAxisLabelInfo var20 = null;
    org.jfree.chart.axis.PeriodAxisLabelInfo[] var21 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { var20};
    var11.setLabelInfo(var21);
    var0.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis)var11, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test46"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var1 = var0.getBaseURLGenerator();
    var0.setShadowYOffset(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test47"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
    var3.setMaximumItemCount(1);
    var3.removeAgedItems(false);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test48"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var8 = var5.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var9 = org.jfree.chart.util.RectangleEdge.opposite(var8);
    var2.ensureAtLeast((-1.0d), var8);
    var0.ensureAtLeast(var2);
    double var12 = var2.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test49"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    double var4 = var0.getXOffset();
    java.awt.Paint var5 = var0.getShadowPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test50"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Paint var2 = var1.getAggregatedItemsPaint();
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Rectangle2D var9 = var8.getDataArea();
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot(var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    java.awt.Paint var13 = var11.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var9, var13);
    java.awt.Font var15 = null;
    var14.setLabelFont(var15);
    java.awt.Shape var17 = var14.getLine();
    var1.setLegendItemShape(var17);
    org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var21 = null;
    org.jfree.data.Range var23 = org.jfree.data.Range.expandToInclude(var21, 0.0d);
    var20.setRangeWithMargins(var23);
    var20.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var27 = var20.getPlot();
    java.lang.Object var28 = var20.clone();
    var20.setAutoTickUnitSelection(false, true);
    var20.setInverted(false);
    org.jfree.chart.entity.AxisEntity var36 = new org.jfree.chart.entity.AxisEntity(var17, (org.jfree.chart.axis.Axis)var20, "Thursday", "");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test51"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = null;
//     var1.plotChanged(var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     var1.setRangeGridlinePaint(var7);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
//     var1.setQuadrantOrigin(var15);
//     java.awt.Stroke var17 = var1.getDomainZeroBaselineStroke();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.block.FlowArrangement var19 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var20 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var20, (java.lang.Comparable)(byte)1);
//     java.awt.geom.Rectangle2D var23 = var22.getBounds();
//     org.jfree.chart.axis.SegmentedTimeline var24 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var25 = var24.getSegmentSize();
//     long var26 = var24.getStartTime();
//     boolean var28 = var24.containsDomainValue(172800000L);
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var30.setDomainDescription("");
//     var30.clear();
//     java.util.List var34 = var30.getItems();
//     var24.setExceptionSegments(var34);
//     var1.drawDomainTickBands(var18, var23, var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 86400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test52"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange((-1.0d), 0.0d);
    java.util.Date var4 = var0.getMaximumDate();
    org.jfree.chart.axis.DateTickUnit var5 = var0.getTickUnit();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var7 = var6.getRightArrow();
    var6.zoomRange((-1.0d), 1.0d);
    double var11 = var6.getLowerMargin();
    org.jfree.data.Range var12 = var6.getRange();
    java.util.Date var13 = var6.getMaximumDate();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var15 = var14.getRightArrow();
    var14.zoomRange((-1.0d), 1.0d);
    double var19 = var14.getLowerMargin();
    org.jfree.data.Range var20 = var14.getRange();
    java.util.Date var21 = var14.getMaximumDate();
    org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var21);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
    float var26 = var25.getTickMarkInsideLength();
    int var27 = var25.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 0.0d);
    var29.setRangeWithMargins(var32);
    var29.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var36 = var29.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var38 = var37.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
    org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
    var40.setDomainZeroBaselineVisible(false);
    var37.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
    var37.setDefaultEntityRadius((-1));
    java.awt.Stroke var48 = null;
    var37.setSeriesStroke(1, var48);
    java.awt.Shape var51 = var37.lookupLegendShape(100);
    var29.setDownArrow(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var24, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var53);
    var54.setWeight((-123));
    java.util.List var57 = var54.getCategories();
    var54.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    boolean var60 = var23.hasListener((java.util.EventListener)var54);
    java.util.TimeZone var61 = var23.getTimeZone();
    org.jfree.data.time.Day var62 = new org.jfree.data.time.Day(var21, var61);
    java.util.Date var63 = var5.rollDate(var13, var61);
    int var64 = var5.getMultiple();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 1);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test53"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var1 = var0.getNumberFormat();
    var1.setParseIntegerOnly(false);
    var1.setMinimumIntegerDigits(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test54"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setBaseShapesVisible(true);
    var0.setAutoPopulateSeriesShape(true);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    org.jfree.chart.renderer.xy.XYItemRendererState var8 = new org.jfree.chart.renderer.xy.XYItemRendererState(var7);
    boolean var9 = var8.getProcessVisibleItemsOnly();
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    boolean var15 = var14.getNotify();
    org.jfree.chart.entity.TitleEntity var17 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape)var12, (org.jfree.chart.title.Title)var14, "{0}: ({1}, {2})");
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var12);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    double var21 = var20.getDomainCrosshairValue();
    boolean var22 = var20.isSubplot();
    org.jfree.chart.util.RectangleEdge var24 = var20.getDomainAxisEdge(1);
    var20.setForegroundAlpha(1.0f);
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var29 = var28.getPaint();
    var20.setNoDataMessagePaint(var29);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
    org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
    java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var38 = null;
    org.jfree.data.Range var40 = org.jfree.data.Range.expandToInclude(var38, 0.0d);
    var37.setRangeWithMargins(var40);
    var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var37);
    org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
    var33.setDomainAxis((org.jfree.chart.axis.ValueAxis)var44);
    java.awt.Stroke var46 = var44.getMinorTickMarkStroke();
    org.jfree.data.Range var47 = var44.getDefaultAutoRange();
    var20.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var44, true);
    org.jfree.chart.axis.PeriodAxis var51 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var52 = null;
    org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, 0.0d);
    var51.setRangeWithMargins(var54);
    var51.setNegativeArrowVisible(false);
    java.awt.Shape var58 = var51.getRightArrow();
    org.jfree.chart.util.RectangleInsets var63 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, 4.0d, (-1.0d));
    var51.setTickLabelInsets(var63);
    org.jfree.chart.plot.RingPlot var65 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var66 = var65.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var67 = var65.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var68 = null;
    var65.setLegendLabelURLGenerator(var68);
    org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var65);
    java.awt.Stroke var71 = var70.getBorderStroke();
    var51.setMinorTickMarkStroke(var71);
    org.jfree.chart.axis.PeriodAxis var74 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var75 = null;
    org.jfree.data.Range var77 = org.jfree.data.Range.expandToInclude(var75, 0.0d);
    var74.setRangeWithMargins(var77);
    var74.setNegativeArrowVisible(false);
    var74.setLabelURL("hi!");
    var74.setAxisLineVisible(false);
    org.jfree.data.xy.DefaultXYDataset var85 = new org.jfree.data.xy.DefaultXYDataset();
    var0.drawItem(var5, var8, var12, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.axis.ValueAxis)var74, (org.jfree.data.xy.XYDataset)var85, 15, 0, false, (-457));
    var51.setTickMarksVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test55"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
//     double var2 = var0.getXOffset();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var6 = var5.getTickMarkInsideLength();
//     int var7 = var5.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
//     var9.setRangeWithMargins(var12);
//     var9.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var16 = var9.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var17 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var18 = var17.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
//     org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
//     var20.setDomainZeroBaselineVisible(false);
//     var17.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     var17.setDefaultEntityRadius((-1));
//     java.awt.Stroke var28 = null;
//     var17.setSeriesStroke(1, var28);
//     java.awt.Shape var31 = var17.lookupLegendShape(100);
//     var9.setDownArrow(var31);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var33);
//     int var35 = var34.getDatasetCount();
//     var34.setDomainGridlinesVisible(true);
//     java.awt.Stroke var38 = var34.getRangeGridlineStroke();
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var40 = var39.getRightArrow();
//     var39.setLowerMargin(4.0d);
//     java.awt.Font var43 = var39.getTickLabelFont();
//     var34.setNoDataMessageFont(var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var49 = new org.jfree.chart.plot.CombinedRangeXYPlot(var48);
//     org.jfree.chart.axis.AxisLocation var50 = var49.getDomainAxisLocation();
//     java.awt.Paint var51 = var49.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var52 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var51);
//     java.awt.Paint var53 = var52.getPaint();
//     org.jfree.chart.ChartRenderingInfo var54 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var55 = new org.jfree.chart.plot.PlotRenderingInfo(var54);
//     java.awt.geom.Rectangle2D var56 = var55.getDataArea();
//     var0.drawRangeMarker(var3, var34, var45, (org.jfree.chart.plot.Marker)var52, var56);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test56"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    boolean var13 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Stroke var15 = var0.lookupSeriesOutlineStroke(520764324);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test57"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getX(5, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test58"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Rectangle2D var9 = var8.getDataArea();
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot(var10);
    org.jfree.chart.plot.DrawingSupplier var12 = var11.getDrawingSupplier();
    java.awt.Paint var13 = var11.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var9, var13);
    java.awt.Font var15 = null;
    var14.setLabelFont(var15);
    boolean var17 = var2.equals((java.lang.Object)var14);
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var20 = null;
    org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 0.0d);
    var19.setRangeWithMargins(var22);
    var19.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var26 = var19.getPlot();
    java.lang.Object var27 = var19.clone();
    java.lang.Class var28 = var19.getMinorTickTimePeriodClass();
    boolean var29 = var14.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test59"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var8.setPlot((org.jfree.chart.plot.XYPlot)var12);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var12);
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot(var21);
//     org.jfree.chart.axis.AxisLocation var23 = var22.getDomainAxisLocation();
//     java.awt.Paint var24 = var22.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var24);
//     java.awt.Stroke var26 = var25.getOutlineStroke();
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var12.removeDomainMarker(0, (org.jfree.chart.plot.Marker)var25, var27);
//     
//     // Checks the contract:  equals-hashcode on var12 and var22
//     assertTrue("Contract failed: equals-hashcode on var12 and var22", var12.equals(var22) ? var12.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var12
//     assertTrue("Contract failed: equals-hashcode on var22 and var12", var22.equals(var12) ? var22.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test60"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var8 = var4.getItemOutlineStroke(0, 0, true);
    var0.setSectionOutlineStroke((java.lang.Comparable)4.0d, var8);
    var0.setLabelGap(0.0d);
    var0.setSectionOutlinesVisible(false);
    java.awt.Paint var14 = var0.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test61"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("null", "PlotOrientation.VERTICAL", "[size=1]", var3, "TextAnchor.CENTER", "October", "hi!");

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test62"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.util.Rotation var5 = var0.getDirection();
    double var6 = var5.getFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test63"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "null", "October", "AxisLocation.BOTTOM_OR_LEFT");

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test64"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.event.PlotChangeEvent var5 = null;
    var4.plotChanged(var5);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
    var1.setCategoryLabelPositionOffset(10);
    var1.setMaximumCategoryLabelLines((-123));
    org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
    float var14 = var13.getMinorTickMarkInsideLength();
    boolean var15 = var13.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var16.setSeriesURLGenerator(4, var18);
    org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
    var16.setBaseToolTipGenerator(var20, true);
    java.lang.Object var23 = null;
    boolean var24 = var16.equals(var23);
    var16.setMinimumBarLength(1.0E-8d);
    double var27 = var16.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    double var29 = var16.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 8.0d);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test65"); }
// 
// 
//     org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.lang.Comparable var34 = null;
//     var31.setDomainCrosshairColumnKey(var34);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
//     org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var38 = var37.clone();
//     var31.setFixedRangeAxisSpace(var37);
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var31.getDomainMarkers(var40);
//     org.jfree.chart.ChartRenderingInfo var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
//     java.awt.geom.Rectangle2D var46 = var45.getDataArea();
//     java.awt.geom.Rectangle2D var47 = var45.getPlotArea();
//     java.lang.Object var48 = var45.clone();
//     var31.handleClick((-123), 4, var45);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var51 = new org.jfree.chart.plot.CombinedRangeXYPlot(var50);
//     double var52 = var51.getDomainCrosshairValue();
//     boolean var53 = var51.isSubplot();
//     org.jfree.chart.util.RectangleEdge var55 = var51.getDomainAxisEdge(1);
//     var51.setForegroundAlpha(1.0f);
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var60 = var59.getPaint();
//     var51.setNoDataMessagePaint(var60);
//     var31.setDomainCrosshairPaint(var60);
//     
//     // Checks the contract:  equals-hashcode on var17 and var51
//     assertTrue("Contract failed: equals-hashcode on var17 and var51", var17.equals(var51) ? var17.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var17
//     assertTrue("Contract failed: equals-hashcode on var51 and var17", var51.equals(var17) ? var51.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test66"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var1 = var0.getTickMarkInsideLength();
//     boolean var2 = var0.isTickLabelsVisible();
//     java.awt.Paint var4 = var0.getTickLabelPaint((java.lang.Comparable)"hi!");
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     var8.setDomainZeroBaselineVisible(false);
//     java.lang.Object var12 = var8.clone();
//     java.awt.Paint var13 = var8.getRangeTickBandPaint();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.RenderingSource var17 = null;
//     var8.select(0.0d, 0.0d, var16, var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var22 = null;
//     var20.setSeriesItemLabelGenerator(100, var22);
//     java.awt.Paint var24 = var20.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Rectangle2D var27 = var26.getDataArea();
//     var20.setBaseLegendShape((java.awt.Shape)var27);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.chart.plot.CrosshairState var31 = null;
//     boolean var32 = var8.render(var19, var27, (-1), var30, var31);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
//     org.jfree.chart.plot.DrawingSupplier var35 = var34.getDrawingSupplier();
//     java.awt.Paint var36 = var34.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var37 = var34.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var38 = org.jfree.chart.util.RectangleEdge.opposite(var37);
//     boolean var40 = var37.equals((java.lang.Object)true);
//     org.jfree.chart.util.RectangleEdge var41 = org.jfree.chart.util.RectangleEdge.opposite(var37);
//     double var42 = var0.getCategoryEnd(520764324, 1969, var27, var41);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var8
//     assertTrue("Contract failed: equals-hashcode on var34 and var8", var34.equals(var8) ? var34.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var35
//     assertTrue("Contract failed: equals-hashcode on var9 and var35", var9.equals(var35) ? var9.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var9
//     assertTrue("Contract failed: equals-hashcode on var35 and var9", var35.equals(var9) ? var35.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test67"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     double var2 = var1.getDomainCrosshairValue();
//     boolean var3 = var1.isSubplot();
//     org.jfree.chart.util.RectangleEdge var5 = var1.getDomainAxisEdge(1);
//     var1.setForegroundAlpha(1.0f);
//     var1.setDomainGridlinesVisible(false);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     java.awt.geom.Rectangle2D var15 = var13.getPlotArea();
//     java.lang.Object var16 = var13.clone();
//     org.jfree.chart.plot.CrosshairState var18 = new org.jfree.chart.plot.CrosshairState(false);
//     var18.setDatasetIndex(100);
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     org.jfree.chart.entity.ChartEntity var25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var23, "");
//     org.jfree.chart.util.RectangleAnchor var26 = null;
//     java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var26);
//     var18.setAnchor(var27);
//     var1.zoomDomainAxes(10.0d, 1.0E12d, var13, var27);
//     
//     // Checks the contract:  equals-hashcode on var13 and var22
//     assertTrue("Contract failed: equals-hashcode on var13 and var22", var13.equals(var22) ? var13.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var13
//     assertTrue("Contract failed: equals-hashcode on var22 and var13", var22.equals(var13) ? var22.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test68"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     var1.setRangePannable(true);
//     boolean var8 = var1.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     var10.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.AxisLocation var15 = var10.getDomainAxisLocation(100);
//     var1.remove((org.jfree.chart.plot.XYPlot)var10);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test69"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var12 = org.jfree.chart.util.RectangleEdge.opposite(var11);
    boolean var14 = var11.equals((java.lang.Object)true);
    double var15 = var1.valueToJava2D(0.05d, var6, var11);
    int var16 = var1.getMinorTickCount();
    org.jfree.chart.util.RectangleInsets var17 = var1.getLabelInsets();
    org.jfree.chart.axis.MarkerAxisBand var18 = var1.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test70"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    var1.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var4 = var1.getTickLabelInsets();
    double var6 = var4.extendHeight(10.0d);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    var7.setLowerMargin((-1.0d));
    var7.setAxisLineVisible(false);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
    java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var18, var22);
    java.awt.Font var24 = null;
    var23.setLabelFont(var24);
    java.awt.Shape var26 = var23.getLine();
    java.awt.Paint var27 = var23.getFillPaint();
    var7.setAxisLinePaint(var27);
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(var4, var27);
    org.jfree.chart.util.UnitType var30 = var4.getUnitType();
    boolean var31 = var0.equals((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test71"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    boolean var10 = var0.getItemVisible(10, 100);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getSeriesPositiveItemLabelPosition(10);
    org.jfree.chart.labels.ItemLabelAnchor var13 = var12.getItemLabelAnchor();
    org.jfree.chart.text.TextAnchor var14 = var12.getTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test72"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    boolean var13 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.plot.XYPlot var14 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test73"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var1 = var0.getSeparatorStroke();
//     org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var0.setLegendLabelURLGenerator(var3);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var9.configure();
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     java.awt.Paint var18 = var16.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var19 = var16.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var20 = org.jfree.chart.util.RectangleEdge.opposite(var19);
//     boolean var22 = var19.equals((java.lang.Object)true);
//     double var23 = var9.valueToJava2D(0.05d, var14, var19);
//     var5.draw(var7, var14);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test74"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("100", "Thursday", var3);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test75"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test76"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var6 = var5.getPlot();
    org.jfree.chart.title.LegendTitle var8 = var5.getLegend(5);
    java.lang.Object var9 = var5.getTextAntiAlias();
    org.jfree.chart.event.ChartChangeListener var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addChangeListener(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test77"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtBottom();
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    var2.setLowerMargin((-1.0d));
    var2.setAxisLineVisible(false);
    java.lang.String var8 = var2.getCategoryLabelToolTip((java.lang.Comparable)"0,0,1,1");
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
    double var11 = var10.getDomainCrosshairValue();
    boolean var12 = var10.isSubplot();
    org.jfree.chart.util.RectangleEdge var14 = var10.getDomainAxisEdge(1);
    var0.add((org.jfree.chart.axis.Axis)var2, var14);
    java.util.List var16 = var0.getAxesAtLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test78"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("AxisLocation.BOTTOM_OR_LEFT");
    var1.setAutoRangeMinimumSize(100.0d);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test79"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 2.0f, 0.0f);
//     float[] var4 = null;
//     float[] var5 = var3.getColorComponents(var4);
//     java.awt.color.ColorSpace var6 = null;
//     float[] var8 = new float[] { 100.0f};
//     float[] var9 = var3.getColorComponents(var6, var8);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test80"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    java.awt.Paint var20 = var0.getSeriesFillPaint((-123));
    org.jfree.chart.labels.XYItemLabelGenerator var24 = var0.getItemLabelGenerator(0, 0, true);
    boolean var26 = var0.isSeriesVisibleInLegend(100);
    java.awt.Shape var27 = var0.getBaseLegendShape();
    org.jfree.chart.labels.XYItemLabelGenerator var29 = null;
    var0.setSeriesItemLabelGenerator(10, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test81"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.event.AxisChangeEvent var31 = null;
    var30.axisChanged(var31);
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    var30.setRenderer(var33);
    boolean var35 = var30.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var30.getRenderer(0);
    org.jfree.chart.axis.CategoryAxis var39 = var30.getDomainAxisForDataset(0);
    var39.setMaximumCategoryLabelWidthRatio(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test82"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.util.RectangleEdge var31 = var30.getRangeAxisEdge();
    org.jfree.chart.plot.CategoryMarker var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.addDomainMarker(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test83"); }


    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    var9.setRangeWithMargins(var12);
    var5.setDomainAxis((org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.data.time.RegularTimePeriod var15 = var9.getFirst();
    org.jfree.data.time.TimeSeriesDataItem var17 = var3.addOrUpdate(var15, 10.0d);
    java.beans.PropertyChangeListener var18 = null;
    var3.removePropertyChangeListener(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test84"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getNumberInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test85"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 2.0f, 0.0f);
//     java.awt.color.ColorSpace var4 = null;
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 2.0f, 0.0f);
//     float[] var9 = null;
//     float[] var10 = var8.getColorComponents(var9);
//     float[] var11 = var3.getComponents(var4, var10);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test86"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange((-1.0d), 0.0d);
    java.util.Date var4 = var0.getMaximumDate();
    org.jfree.chart.axis.DateTickUnit var5 = var0.getTickUnit();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var7 = var6.getRightArrow();
    var6.zoomRange((-1.0d), 1.0d);
    double var11 = var6.getLowerMargin();
    org.jfree.data.Range var12 = var6.getRange();
    java.util.Date var13 = var6.getMaximumDate();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var15 = var14.getRightArrow();
    var14.zoomRange((-1.0d), 1.0d);
    double var19 = var14.getLowerMargin();
    org.jfree.data.Range var20 = var14.getRange();
    java.util.Date var21 = var14.getMaximumDate();
    org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var21);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
    float var26 = var25.getTickMarkInsideLength();
    int var27 = var25.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 0.0d);
    var29.setRangeWithMargins(var32);
    var29.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var36 = var29.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var38 = var37.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
    org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
    var40.setDomainZeroBaselineVisible(false);
    var37.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
    var37.setDefaultEntityRadius((-1));
    java.awt.Stroke var48 = null;
    var37.setSeriesStroke(1, var48);
    java.awt.Shape var51 = var37.lookupLegendShape(100);
    var29.setDownArrow(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var24, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var53);
    var54.setWeight((-123));
    java.util.List var57 = var54.getCategories();
    var54.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    boolean var60 = var23.hasListener((java.util.EventListener)var54);
    java.util.TimeZone var61 = var23.getTimeZone();
    org.jfree.data.time.Day var62 = new org.jfree.data.time.Day(var21, var61);
    java.util.Date var63 = var5.rollDate(var13, var61);
    org.jfree.chart.axis.DateTickUnitType var64 = var5.getRollUnitType();
    java.text.DateFormat var66 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var67 = new org.jfree.chart.axis.DateTickUnit(var64, (-123), var66);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test87"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var12 = org.jfree.chart.util.RectangleEdge.opposite(var11);
    boolean var14 = var11.equals((java.lang.Object)true);
    double var15 = var1.valueToJava2D(0.05d, var6, var11);
    org.jfree.chart.event.RendererChangeEvent var17 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var15, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test88"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    int var32 = var31.getDatasetCount();
    org.jfree.chart.event.PlotChangeEvent var33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var31);
    var0.plotChanged(var33);
    double var35 = var0.getGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 5.0d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test89"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    var31.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var34 = var31.getTickLabelInsets();
    var30.setAxisOffset(var34);
    var30.setRangePannable(false);
    org.jfree.chart.axis.AxisSpace var38 = null;
    var30.setFixedDomainAxisSpace(var38, false);
    var30.clearDomainMarkers((-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test90"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getCurrencyInstance();
    int var1 = var0.getMinimumIntegerDigits();
    var0.setMaximumIntegerDigits(4);
    var0.setMinimumFractionDigits((-123));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.parse("14");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test91"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.AxisSpace var2 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var8 = var5.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var9 = org.jfree.chart.util.RectangleEdge.opposite(var8);
    var2.ensureAtLeast((-1.0d), var8);
    var0.ensureAtLeast(var2);
    double var12 = var2.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test92"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    int var31 = var30.getDatasetCount();
    var30.setDomainGridlinesVisible(true);
    org.jfree.chart.util.RectangleInsets var34 = var30.getAxisOffset();
    var30.setRangeCrosshairValue(1.0d, false);
    org.jfree.chart.annotations.CategoryAnnotation var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var39 = var30.removeAnnotation(var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test93"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = null;
    var11.setLabelFont(var12);
    java.awt.Shape var14 = var11.getLine();
    java.lang.Comparable var15 = var11.getSeriesKey();
    var11.setSeriesIndex(520764324);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test94"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("TitleEntity: tooltip = 100", "rect", "PlotEntity: tooltip = null", var3, "AxisLocation.BOTTOM_OR_LEFT", "UnitType.ABSOLUTE", "");
    java.awt.Image var8 = var7.getLogo();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("TitleEntity: tooltip = 100", "rect", "PlotEntity: tooltip = null", var12, "AxisLocation.BOTTOM_OR_LEFT", "UnitType.ABSOLUTE", "");
    java.awt.Image var17 = var16.getLogo();
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test95"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange((-1.0d), 0.0d);
    java.util.Date var4 = var0.getMaximumDate();
    org.jfree.chart.axis.DateTickUnit var5 = var0.getTickUnit();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var7 = var6.getRightArrow();
    var6.zoomRange((-1.0d), 1.0d);
    double var11 = var6.getLowerMargin();
    org.jfree.data.Range var12 = var6.getRange();
    java.util.Date var13 = var6.getMaximumDate();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var15 = var14.getRightArrow();
    var14.zoomRange((-1.0d), 1.0d);
    double var19 = var14.getLowerMargin();
    org.jfree.data.Range var20 = var14.getRange();
    java.util.Date var21 = var14.getMaximumDate();
    org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var21);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
    float var26 = var25.getTickMarkInsideLength();
    int var27 = var25.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 0.0d);
    var29.setRangeWithMargins(var32);
    var29.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var36 = var29.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var38 = var37.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
    org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
    var40.setDomainZeroBaselineVisible(false);
    var37.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
    var37.setDefaultEntityRadius((-1));
    java.awt.Stroke var48 = null;
    var37.setSeriesStroke(1, var48);
    java.awt.Shape var51 = var37.lookupLegendShape(100);
    var29.setDownArrow(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var24, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var53);
    var54.setWeight((-123));
    java.util.List var57 = var54.getCategories();
    var54.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    boolean var60 = var23.hasListener((java.util.EventListener)var54);
    java.util.TimeZone var61 = var23.getTimeZone();
    org.jfree.data.time.Day var62 = new org.jfree.data.time.Day(var21, var61);
    java.util.Date var63 = var5.rollDate(var13, var61);
    org.jfree.chart.axis.DateTickUnitType var64 = var5.getRollUnitType();
    org.jfree.chart.axis.DateTickUnitType var65 = var5.getRollUnitType();
    int var66 = var65.getCalendarField();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 5);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test96"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
//     var4.setRangeWithMargins(var7);
//     boolean var9 = var0.equals((java.lang.Object)var7);
//     var0.setBaseItemLabelsVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.data.Range var15 = var0.findDomainBounds(var14);
//     var0.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
//     double var21 = var20.getDomainCrosshairValue();
//     boolean var22 = var20.isSubplot();
//     var20.setNoDataMessage("");
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
//     var26.setRangeWithMargins(var29);
//     var26.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var33 = var26.getPlot();
//     java.awt.Shape var34 = var26.getUpArrow();
//     org.jfree.chart.axis.PeriodAxisLabelInfo var35 = null;
//     org.jfree.chart.axis.PeriodAxisLabelInfo[] var36 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { var35};
//     var26.setLabelInfo(var36);
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, (-1.0d), 100.0d);
//     java.awt.Paint var45 = var44.getPaint();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var48 = var47.getTickMarkInsideLength();
//     int var49 = var47.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var51 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var52 = null;
//     org.jfree.data.Range var54 = org.jfree.data.Range.expandToInclude(var52, 0.0d);
//     var51.setRangeWithMargins(var54);
//     var51.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var58 = var51.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var59 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var60 = var59.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var62 = new org.jfree.chart.plot.CombinedRangeXYPlot(var61);
//     org.jfree.chart.plot.DrawingSupplier var63 = var62.getDrawingSupplier();
//     var62.setDomainZeroBaselineVisible(false);
//     var59.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var62);
//     var59.setDefaultEntityRadius((-1));
//     java.awt.Stroke var70 = null;
//     var59.setSeriesStroke(1, var70);
//     java.awt.Shape var73 = var59.lookupLegendShape(100);
//     var51.setDownArrow(var73);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var75 = null;
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot(var46, (org.jfree.chart.axis.CategoryAxis)var47, (org.jfree.chart.axis.ValueAxis)var51, var75);
//     var76.setWeight((-123));
//     var76.clearDomainAxes();
//     org.jfree.chart.renderer.xy.XYBarRenderer var80 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var84 = var80.getItemOutlineStroke(0, 0, true);
//     var76.setRangeGridlineStroke(var84);
//     org.jfree.chart.axis.ValueAxis var87 = var76.getRangeAxisForDataset(10);
//     java.awt.Stroke var88 = var76.getDomainCrosshairStroke();
//     var0.drawDomainLine(var18, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.chart.axis.ValueAxis)var26, var38, 5.0d, var45, var88);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test97"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var4 = null;
    org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 10.0f, var4);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.text.TextBlockAnchor var9 = null;
    var5.draw(var6, 100.0f, 0.5f, var9, 1.0f, 0.5f, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test98"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
//     java.awt.Paint var5 = var3.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var5);
//     org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var12 = null;
//     org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
//     var11.setRangeWithMargins(var14);
//     boolean var16 = var7.equals((java.lang.Object)var14);
//     var7.setBaseItemLabelsVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var7.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.data.Range var22 = var7.findDomainBounds(var21);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
//     org.jfree.chart.plot.DrawingSupplier var26 = var25.getDrawingSupplier();
//     var25.setDomainZeroBaselineVisible(false);
//     java.lang.Object var29 = var25.clone();
//     java.awt.Paint var30 = var25.getRangeTickBandPaint();
//     org.jfree.chart.util.RectangleEdge var32 = var25.getDomainAxisEdge(5);
//     java.lang.String var33 = var25.getPlotType();
//     org.jfree.data.xy.XYDataset var35 = var25.getDataset((-123));
//     java.awt.Stroke var36 = var25.getDomainMinorGridlineStroke();
//     var7.setSeriesStroke(0, var36, true);
//     var6.setOutlineStroke(var36);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test99"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    java.awt.Paint var4 = var0.getBaseLegendTextPaint();
    boolean var5 = var0.getAutoPopulateSeriesStroke();
    var0.setItemLabelAnchorOffset(0.05d);
    var0.setShadowVisible(true);
    int var10 = var0.getDefaultEntityRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test100"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    boolean var8 = var3.isDomainZoomable();
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    var9.setBaseItemLabelsVisible(true, true);
    var3.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var9);
    java.awt.Stroke var14 = var3.getRangeMinorGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test101"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesPaint(0);
    org.jfree.chart.labels.XYSeriesLabelGenerator var3 = var0.getLegendItemURLGenerator();
    java.awt.Shape var4 = var0.getBaseShape();
    java.awt.Paint var6 = var0.getSeriesItemLabelPaint(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test102"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearDomainAxes();
    org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var38 = var34.getItemOutlineStroke(0, 0, true);
    var30.setRangeGridlineStroke(var38);
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var43 = null;
    var41.setSeriesURLGenerator(4, var43);
    org.jfree.chart.labels.CategoryToolTipGenerator var45 = null;
    var41.setBaseToolTipGenerator(var45, true);
    double var48 = var41.getXOffset();
    double var49 = var41.getMinimumBarLength();
    var41.setBase(0.0d);
    var30.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
    int var53 = var41.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test103"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    org.jfree.chart.util.RectangleEdge var31 = var30.getRangeAxisEdge();
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var34 = new org.jfree.chart.plot.CombinedRangeXYPlot(var33);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var36 = org.jfree.chart.axis.AxisLocation.getOpposite(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setRangeAxisLocation((-1), var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test104"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearAnnotations();
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    var30.setRenderer(var34, true);
    org.jfree.chart.util.SortOrder var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.setRowRenderingOrder(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test105"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    org.jfree.chart.util.RectangleAnchor var5 = null;
    java.awt.geom.Point2D var6 = org.jfree.chart.util.RectangleAnchor.coordinates(var2, var5);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.entity.PieSectionEntity var13 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var2, var7, 100, 100, (java.lang.Comparable)(-1L), "hi!", "");
    org.jfree.data.general.PieDataset var14 = null;
    var13.setDataset(var14);
    java.lang.String var16 = var13.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "rect"+ "'", var16.equals("rect"));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test106"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var2 = var1.getDomainAxisLocation();
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    var7.setRangeWithMargins(var10);
    boolean var12 = var3.equals((java.lang.Object)var10);
    var3.setBaseItemLabelsVisible(false);
    var3.setBase(2.88E7d);
    org.jfree.chart.urls.XYURLGenerator var20 = var3.getURLGenerator(100, 0, false);
    java.awt.Paint var21 = var3.getBaseItemLabelPaint();
    var1.setDomainMinorGridlinePaint(var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var24 = var1.getQuadrantPaint(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test107"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getRightArrow();
    var0.setLowerMargin(4.0d);
    java.lang.Object var4 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test108"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 2.0f, 0.0f);
//     float[] var4 = null;
//     float[] var5 = var3.getColorComponents(var4);
//     java.awt.color.ColorSpace var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 2.0f, 0.0f);
//     float[] var11 = null;
//     float[] var12 = var10.getColorComponents(var11);
//     float[] var13 = var3.getColorComponents(var6, var11);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test109"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearAnnotations();
    var30.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test110"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    java.awt.Stroke var14 = var12.getMinorTickMarkStroke();
    var12.resizeRange((-1.0d));
    var12.setLowerMargin(10.0d);
    var12.setLabel("null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test111"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    java.awt.geom.Rectangle2D var3 = var1.getPlotArea();
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    var4.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var7 = var4.getTickLabelInsets();
    double var9 = var7.extendHeight(10.0d);
    org.jfree.chart.ChartRenderingInfo var10 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getDataArea();
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var12, "");
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var12, "");
    org.jfree.chart.util.LengthAdjustmentType var17 = null;
    org.jfree.chart.util.LengthAdjustmentType var18 = null;
    java.awt.geom.Rectangle2D var19 = var7.createAdjustedRectangle(var12, var17, var18);
    var1.setPlotArea(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test112"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var7 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var2.add(var7);
    org.jfree.data.xy.XYDataItem var11 = var2.addOrUpdate((java.lang.Number)1L, (java.lang.Number)(-1L));
    boolean var12 = var2.getAllowDuplicateXValues();
    java.beans.PropertyChangeListener var13 = null;
    var2.removePropertyChangeListener(var13);
    double var15 = var2.getMaxX();
    boolean var16 = var2.getNotify();
    var2.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test113"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
    java.lang.String var3 = var2.getText();
    java.awt.Paint var4 = var2.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var3.equals("SerialDate.weekInMonthToString(): invalid code."));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test114"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
    var3.clear();
    java.lang.Object var5 = var3.clone();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var11 = var9.toFixedHeight((-1.0d));
    org.jfree.chart.util.Size2D var12 = var3.arrange(var6, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test115"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test116"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker((-1.0d));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test117"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
    org.jfree.chart.JFreeChart var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var2);
    org.jfree.chart.axis.SymbolAxis var4 = new org.jfree.chart.axis.SymbolAxis("100", var1);
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    float var8 = var7.getTickMarkInsideLength();
    int var9 = var7.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
    var11.setRangeWithMargins(var14);
    var11.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var18 = var11.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var20 = var19.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot(var21);
    org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
    var22.setDomainZeroBaselineVisible(false);
    var19.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var22);
    var19.setDefaultEntityRadius((-1));
    java.awt.Stroke var30 = null;
    var19.setSeriesStroke(1, var30);
    java.awt.Shape var33 = var19.lookupLegendShape(100);
    var11.setDownArrow(var33);
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var35);
    org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
    var37.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var40 = var37.getTickLabelInsets();
    var36.setAxisOffset(var40);
    var5.setInsets(var40, false);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.plot.MultiplePiePlot var45 = new org.jfree.chart.plot.MultiplePiePlot(var44);
    java.awt.Paint var46 = var45.getAggregatedItemsPaint();
    var5.setBackgroundPaint(var46);
    var4.setGridBandPaint(var46);
    java.lang.String var49 = var4.getLabelToolTip();
    org.jfree.chart.labels.StandardPieToolTipGenerator var50 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.lang.Object var51 = var50.clone();
    boolean var52 = var4.equals(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test118"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    double var2 = var1.getDomainCrosshairValue();
    boolean var3 = var1.isSubplot();
    org.jfree.chart.util.RectangleEdge var5 = var1.getDomainAxisEdge(1);
    var1.setForegroundAlpha(1.0f);
    int var8 = var1.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test119"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = null;
    var11.setLabelFont(var12);
    java.awt.Shape var14 = var11.getLine();
    java.awt.Paint var15 = var11.getFillPaint();
    java.lang.String var16 = var11.getURLText();
    java.lang.Comparable var17 = var11.getSeriesKey();
    java.awt.Paint var18 = var11.getLabelPaint();
    org.jfree.chart.util.GradientPaintTransformer var19 = var11.getFillPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test120"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setUseFillPaint(true);
    java.awt.Stroke var4 = var0.lookupSeriesOutlineStroke(5);
    var0.setUseOutlinePaint(false);
    boolean var7 = var0.getUseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test121"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.Range var2 = var0.getDomainBounds(false);
    org.jfree.data.xy.XYDatasetSelectionState var3 = var0.getSelectionState();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var0.getStartXValue(100, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test122"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    float var1 = var0.getTickMarkInsideLength();
    boolean var2 = var0.isTickLabelsVisible();
    java.awt.Paint var4 = var0.getTickLabelPaint((java.lang.Comparable)"hi!");
    double var5 = var0.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test123"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
    java.awt.Paint var5 = var3.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var5);
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.util.GradientPaintTransformer var9 = var8.getFillPaintTransformer();
    var6.setGradientPaintTransformer(var9);
    java.awt.Paint var11 = null;
    var6.setOutlinePaint(var11);
    org.jfree.chart.event.MarkerChangeEvent var13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var6);
    var6.setEndValue(0.05d);
    java.awt.Stroke var16 = var6.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test124"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearAnnotations();
    var30.setNotify(true);
    org.jfree.chart.plot.CategoryMarker var36 = null;
    org.jfree.chart.util.Layer var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var30.addDomainMarker(var36, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test125"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var1 = var0.getSeparatorStroke();
//     org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var0.setLegendLabelURLGenerator(var3);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     var8.setDomainZeroBaselineVisible(false);
//     java.lang.Object var12 = var8.clone();
//     java.awt.Paint var13 = var8.getRangeTickBandPaint();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.RenderingSource var17 = null;
//     var8.select(0.0d, 0.0d, var16, var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var22 = null;
//     var20.setSeriesItemLabelGenerator(100, var22);
//     java.awt.Paint var24 = var20.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Rectangle2D var27 = var26.getDataArea();
//     var20.setBaseLegendShape((java.awt.Shape)var27);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.chart.plot.CrosshairState var31 = null;
//     boolean var32 = var8.render(var19, var27, (-1), var30, var31);
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot();
//     var33.setIgnoreZeroValues(false);
//     org.jfree.data.time.TimeSeriesCollection var37 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var40 = var39.getTickMarkInsideLength();
//     int var41 = var39.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var43 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var44 = null;
//     org.jfree.data.Range var46 = org.jfree.data.Range.expandToInclude(var44, 0.0d);
//     var43.setRangeWithMargins(var46);
//     var43.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var50 = var43.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var51 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var52 = var51.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var54 = new org.jfree.chart.plot.CombinedRangeXYPlot(var53);
//     org.jfree.chart.plot.DrawingSupplier var55 = var54.getDrawingSupplier();
//     var54.setDomainZeroBaselineVisible(false);
//     var51.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var54);
//     var51.setDefaultEntityRadius((-1));
//     java.awt.Stroke var62 = null;
//     var51.setSeriesStroke(1, var62);
//     java.awt.Shape var65 = var51.lookupLegendShape(100);
//     var43.setDownArrow(var65);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var67 = null;
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot(var38, (org.jfree.chart.axis.CategoryAxis)var39, (org.jfree.chart.axis.ValueAxis)var43, var67);
//     var68.setWeight((-123));
//     java.lang.Comparable var71 = null;
//     var68.setDomainCrosshairColumnKey(var71);
//     var37.addChangeListener((org.jfree.data.general.DatasetChangeListener)var68);
//     org.jfree.chart.axis.AxisSpace var74 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var75 = var74.clone();
//     var68.setFixedRangeAxisSpace(var74);
//     org.jfree.chart.util.Layer var77 = null;
//     java.util.Collection var78 = var68.getDomainMarkers(var77);
//     org.jfree.chart.ChartRenderingInfo var81 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var82 = new org.jfree.chart.plot.PlotRenderingInfo(var81);
//     java.awt.geom.Rectangle2D var83 = var82.getDataArea();
//     java.awt.geom.Rectangle2D var84 = var82.getPlotArea();
//     java.lang.Object var85 = var82.clone();
//     var68.handleClick((-123), 4, var82);
//     org.jfree.chart.plot.PiePlotState var87 = var0.initialise(var6, var27, (org.jfree.chart.plot.PiePlot)var33, (java.lang.Integer)15, var82);
//     
//     // Checks the contract:  equals-hashcode on var0 and var33
//     assertTrue("Contract failed: equals-hashcode on var0 and var33", var0.equals(var33) ? var0.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var0
//     assertTrue("Contract failed: equals-hashcode on var33 and var0", var33.equals(var0) ? var33.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var54
//     assertTrue("Contract failed: equals-hashcode on var8 and var54", var8.equals(var54) ? var8.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var8
//     assertTrue("Contract failed: equals-hashcode on var54 and var8", var54.equals(var8) ? var54.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var55
//     assertTrue("Contract failed: equals-hashcode on var9 and var55", var9.equals(var55) ? var9.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var9
//     assertTrue("Contract failed: equals-hashcode on var55 and var9", var55.equals(var9) ? var55.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var82
//     assertTrue("Contract failed: equals-hashcode on var26 and var82", var26.equals(var82) ? var26.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var26
//     assertTrue("Contract failed: equals-hashcode on var82 and var26", var82.equals(var26) ? var82.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test126"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection();
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var1);
    var1.removeAllSeries();
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var5 = var4.getRightArrow();
    var4.zoomRange((-1.0d), 1.0d);
    double var9 = var4.getLowerMargin();
    org.jfree.data.Range var10 = var4.getRange();
    java.util.Date var11 = var4.getMaximumDate();
    org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
    org.jfree.data.time.RegularTimePeriod var13 = var12.previous();
    int var14 = var1.indexOf((java.lang.Comparable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test127"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot(var1);
    org.jfree.chart.axis.AxisLocation var3 = var2.getDomainAxisLocation();
    java.awt.Paint var4 = var2.getDomainCrosshairPaint();
    java.awt.Paint var5 = var2.getRangeGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var7 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var2, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test128"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.renderer.xy.XYBarRenderer var2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    boolean var11 = var2.equals((java.lang.Object)var9);
    var2.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var2.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.chart.text.TextAnchor var16 = var15.getRotationAnchor();
    double var17 = var15.getAngle();
    org.jfree.chart.labels.ItemLabelAnchor var18 = var15.getItemLabelAnchor();
    var0.setBasePositiveItemLabelPosition(var15, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test129"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    var0.setIgnoreZeroValues(false);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var6, "");
    boolean var9 = var3.equals((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test130"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.util.List var34 = var31.getCategories();
//     var31.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var37 = var0.hasListener((java.util.EventListener)var31);
//     org.jfree.chart.axis.ValueAxis var38 = var31.getRangeAxis();
//     var31.setWeight((-1));
//     java.awt.Graphics2D var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var44 = new org.jfree.chart.plot.CombinedRangeXYPlot(var43);
//     org.jfree.chart.event.PlotChangeEvent var45 = null;
//     var44.plotChanged(var45);
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var48 = new org.jfree.chart.plot.CombinedRangeXYPlot(var47);
//     org.jfree.chart.plot.DrawingSupplier var49 = var48.getDrawingSupplier();
//     java.awt.Paint var50 = var48.getRangeZeroBaselinePaint();
//     var44.setRangeGridlinePaint(var50);
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     java.awt.geom.Rectangle2D var54 = var53.getDataArea();
//     org.jfree.chart.entity.ChartEntity var56 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var54, "");
//     org.jfree.chart.util.RectangleAnchor var57 = null;
//     java.awt.geom.Point2D var58 = org.jfree.chart.util.RectangleAnchor.coordinates(var54, var57);
//     var44.setQuadrantOrigin(var58);
//     org.jfree.chart.plot.PlotState var60 = null;
//     org.jfree.chart.ChartRenderingInfo var61 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var62 = new org.jfree.chart.plot.PlotRenderingInfo(var61);
//     var31.draw(var41, var42, var58, var60, var62);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test131"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test132"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
    java.awt.Paint var5 = var3.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var5);
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.util.GradientPaintTransformer var9 = var8.getFillPaintTransformer();
    var6.setGradientPaintTransformer(var9);
    java.awt.Paint var11 = null;
    var6.setOutlinePaint(var11);
    org.jfree.chart.event.MarkerChangeEvent var13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var6);
    org.jfree.chart.util.RectangleAnchor var14 = var6.getLabelAnchor();
    java.awt.Paint var15 = var6.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test133"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
    int var2 = var1.getMinimumIntegerDigits();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(12.0d, var1, (-1));
    var1.setMinimumFractionDigits((-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test134"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var4.toFixedHeight((-1.0d));
    org.jfree.chart.block.LengthConstraintType var7 = var4.getWidthConstraintType();
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
    var10.setRangeWithMargins(var13);
    var10.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var17 = var10.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    var21.setDomainZeroBaselineVisible(false);
    var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
    var18.setDefaultEntityRadius((-1));
    java.awt.Stroke var29 = null;
    var18.setSeriesStroke(1, var29);
    java.awt.Shape var32 = var18.lookupLegendShape(100);
    var10.setDownArrow(var32);
    org.jfree.chart.axis.PeriodAxis var35 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var36 = null;
    org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var36, 0.0d);
    var35.setRangeWithMargins(var38);
    var10.setRangeWithMargins(var38);
    org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var45 = var43.toFixedHeight((-1.0d));
    org.jfree.chart.block.LengthConstraintType var46 = var43.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(0.05d, var1, var7, 1.0E12d, var38, var46);
    org.jfree.chart.axis.PeriodAxis var49 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var50 = null;
    org.jfree.data.Range var52 = org.jfree.data.Range.expandToInclude(var50, 0.0d);
    var49.setRangeWithMargins(var52);
    var49.setNegativeArrowVisible(false);
    var49.setLabelURL("hi!");
    var49.setAxisLineVisible(true);
    float var60 = var49.getMinorTickMarkInsideLength();
    org.jfree.chart.axis.PeriodAxis var62 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var63 = null;
    org.jfree.data.Range var65 = org.jfree.data.Range.expandToInclude(var63, 0.0d);
    var62.setRangeWithMargins(var65);
    org.jfree.data.Range var68 = org.jfree.data.Range.scale(var65, 10.0d);
    var49.setRange(var68, true, false);
    org.jfree.chart.renderer.xy.XYBarRenderer var72 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var74 = var72.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var76 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var77 = null;
    org.jfree.data.Range var79 = org.jfree.data.Range.expandToInclude(var77, 0.0d);
    var76.setRangeWithMargins(var79);
    boolean var81 = var72.equals((java.lang.Object)var79);
    org.jfree.chart.util.ObjectList var82 = new org.jfree.chart.util.ObjectList();
    boolean var83 = var79.equals((java.lang.Object)var82);
    org.jfree.chart.block.RectangleConstraint var84 = new org.jfree.chart.block.RectangleConstraint(var68, var79);
    double var85 = var79.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var86 = var47.toRangeWidth(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test135"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getRightArrow();
    org.jfree.chart.axis.DateTickMarkPosition var2 = var0.getTickMarkPosition();
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "DateTickMarkPosition.START"+ "'", var3.equals("DateTickMarkPosition.START"));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test136"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    var4.setNegativeArrowVisible(false);
    var4.setLabelURL("hi!");
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var4};
    var1.setRangeAxes(var13);
    org.jfree.chart.util.RectangleEdge var15 = var1.getRangeAxisEdge();
    org.jfree.chart.axis.ValueAxis var17 = var1.getRangeAxis(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test137"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = null;
    var1.plotChanged(var2);
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    var1.setRangeGridlinePaint(var7);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
    org.jfree.chart.util.RectangleAnchor var14 = null;
    java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
    var1.setQuadrantOrigin(var15);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.LegendItemSource[] var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setSources(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test138"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    org.jfree.chart.util.RectangleAnchor var5 = null;
    java.awt.geom.Point2D var6 = org.jfree.chart.util.RectangleAnchor.coordinates(var2, var5);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.entity.PieSectionEntity var13 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var2, var7, 100, 100, (java.lang.Comparable)(-1L), "hi!", "");
    int var14 = var13.getSectionIndex();
    int var15 = var13.getSectionIndex();
    var13.setPieIndex((-457));
    org.jfree.data.xy.XYSeries var20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var22 = var20.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var25 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var20.add(var25);
    double var27 = var25.getXValue();
    var25.setY((java.lang.Number)100L);
    var13.setSectionKey((java.lang.Comparable)100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test139"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    var31.setWeight((-123));
    java.lang.Comparable var34 = null;
    var31.setDomainCrosshairColumnKey(var34);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
    org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var38 = var37.clone();
    var31.setFixedRangeAxisSpace(var37);
    org.jfree.chart.util.Layer var40 = null;
    java.util.Collection var41 = var31.getDomainMarkers(var40);
    java.util.List var42 = var31.getCategories();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test140"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection();
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var1);
    var1.removeAllSeries();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    float var7 = var5.getForegroundAlpha();
    var1.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
    org.jfree.data.xy.XYDatasetSelectionState var9 = var1.getSelectionState();
    int var10 = var1.getSeriesCount();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test141"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setUseFillPaint(true);
    java.awt.Stroke var4 = var0.lookupSeriesOutlineStroke(5);
    var0.setUseOutlinePaint(false);
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var12 = var8.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.labels.StandardPieToolTipGenerator var14 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var15 = var14.getNumberFormat();
    java.text.DateFormat var16 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var17 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var15, var16);
    var8.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var17, false);
    java.text.NumberFormat var22 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var23 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var24 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var22, var23);
    java.lang.Object var25 = null;
    boolean var26 = var24.equals(var25);
    org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var31 = var27.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.urls.StandardXYURLGenerator var33 = new org.jfree.chart.urls.StandardXYURLGenerator();
    var27.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var33);
    org.jfree.chart.renderer.xy.XYAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var24, (org.jfree.chart.urls.XYURLGenerator)var33);
    var8.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var33, true);
    var0.setSeriesURLGenerator(100, (org.jfree.chart.urls.XYURLGenerator)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test142"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.14d, 0.14d);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test143"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test144"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(18.0d, 1.0E12d);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test145"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = null;
    var11.setLabelFont(var12);
    var11.setDatasetIndex(2147483647);
    var11.setShapeVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test146"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("[size=1]", "WMAP_Plot", "RectangleAnchor.TOP_LEFT", var3, "31-December-1969", "ItemLabelAnchor.OUTSIDE6", "HorizontalAlignment.CENTER");

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test147"); }


    org.jfree.chart.labels.StandardXYToolTipGenerator var1 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
    java.lang.String var2 = var1.getNullYString();
    org.jfree.chart.renderer.xy.XYBarRenderer var3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var7 = var3.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.labels.StandardPieToolTipGenerator var9 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var10 = var9.getNumberFormat();
    java.text.DateFormat var11 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var10, var11);
    var3.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var12, false);
    java.text.NumberFormat var17 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var18 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var19 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var17, var18);
    java.lang.Object var20 = null;
    boolean var21 = var19.equals(var20);
    org.jfree.chart.renderer.xy.XYBarRenderer var22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var26 = var22.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.urls.StandardXYURLGenerator var28 = new org.jfree.chart.urls.StandardXYURLGenerator();
    var22.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var28);
    org.jfree.chart.renderer.xy.XYAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var19, (org.jfree.chart.urls.XYURLGenerator)var28);
    var3.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var28, true);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(15, (org.jfree.chart.labels.XYToolTipGenerator)var1, (org.jfree.chart.urls.XYURLGenerator)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "null"+ "'", var2.equals("null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test148"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getRightArrow();
    var0.zoomRange((-1.0d), 1.0d);
    var0.pan((-1.0d));
    org.jfree.data.Range var7 = var0.getDefaultAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test149"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
    java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.util.RectangleEdge.opposite(var7);
    var1.setPosition(var7);
    org.jfree.chart.util.RectangleInsets var10 = var1.getPadding();
    double var12 = var10.trimWidth(0.0d);
    double var14 = var10.trimHeight(0.05d);
    double var16 = var10.trimWidth(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 6.0d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test150"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getStartTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == (-2208960000000L));
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test151"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var3.plotChanged(var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
    var3.setRangeGridlinePaint(var9);
    org.jfree.chart.ChartRenderingInfo var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
    java.awt.geom.Rectangle2D var13 = var12.getDataArea();
    org.jfree.chart.entity.ChartEntity var15 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var13, "");
    org.jfree.chart.util.RectangleAnchor var16 = null;
    java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var16);
    var3.setQuadrantOrigin(var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
    org.jfree.chart.util.RectangleInsets var20 = var19.getItemLabelPadding();
    org.jfree.chart.util.RectangleInsets var21 = var19.getItemLabelPadding();
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var1, (org.jfree.chart.title.Title)var19, "100");
    java.lang.String var24 = var23.toString();
    var23.setURLText("ERROR : Relative To String");
    java.lang.String var27 = var23.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "TitleEntity: tooltip = 100"+ "'", var24.equals("TitleEntity: tooltip = 100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "100"+ "'", var27.equals("100"));

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test152"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.text.TextFragment var4 = var3.getLastTextFragment();
//     java.awt.Font var5 = var4.getFont();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
//     java.awt.Paint var10 = null;
//     boolean var11 = org.jfree.chart.util.PaintUtilities.equal(var9, var10);
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER", var5, var9);
//     var0.setRadiusGridlinePaint(var9);
//     var0.setAngleLabelsVisible(false);
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
//     org.jfree.chart.axis.AxisSpace var20 = null;
//     var19.setFixedRangeAxisSpace(var20);
//     org.jfree.chart.LegendItemCollection var22 = new org.jfree.chart.LegendItemCollection();
//     var19.setFixedLegendItems(var22);
//     var17.add((org.jfree.chart.plot.XYPlot)var19);
//     boolean var25 = var17.isSubplot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var30 = var28.getSeriesPositiveItemLabelPosition(0);
//     java.awt.Shape var31 = var28.getBaseLegendShape();
//     var28.setSeriesVisible(10, (java.lang.Boolean)true);
//     org.jfree.chart.labels.StandardXYSeriesLabelGenerator var36 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("SerialDate.weekInMonthToString(): invalid code.");
//     var28.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var36);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     java.awt.geom.Rectangle2D var40 = var39.getDataArea();
//     java.awt.geom.Rectangle2D var41 = var39.getPlotArea();
//     boolean var42 = var36.equals((java.lang.Object)var39);
//     java.awt.geom.Rectangle2D var43 = var39.getPlotArea();
//     var17.handleClick(15, 100, var39);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var46 = new org.jfree.chart.plot.CombinedRangeXYPlot(var45);
//     org.jfree.chart.plot.DrawingSupplier var47 = var46.getDrawingSupplier();
//     java.lang.Object var48 = var46.clone();
//     java.awt.Paint var49 = var46.getDomainTickBandPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     org.jfree.chart.ChartRenderingInfo var55 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = new org.jfree.chart.plot.PlotRenderingInfo(var55);
//     java.awt.geom.Rectangle2D var57 = var56.getDataArea();
//     org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var57, "");
//     java.awt.geom.Point2D var60 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 2.88E7d, var57);
//     var46.zoomRangeAxes(4.0d, 10.0d, var52, var60);
//     var0.zoomRangeAxes(14.0d, var39, var60, false);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test153"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange((-1.0d), 0.0d);
    java.util.Date var4 = var0.getMaximumDate();
    org.jfree.chart.axis.DateTickUnit var5 = var0.getTickUnit();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var7 = var6.getRightArrow();
    var6.zoomRange((-1.0d), 1.0d);
    double var11 = var6.getLowerMargin();
    org.jfree.data.Range var12 = var6.getRange();
    java.util.Date var13 = var6.getMaximumDate();
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var15 = var14.getRightArrow();
    var14.zoomRange((-1.0d), 1.0d);
    double var19 = var14.getLowerMargin();
    org.jfree.data.Range var20 = var14.getRange();
    java.util.Date var21 = var14.getMaximumDate();
    org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var21);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
    float var26 = var25.getTickMarkInsideLength();
    int var27 = var25.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 0.0d);
    var29.setRangeWithMargins(var32);
    var29.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var36 = var29.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var38 = var37.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
    org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
    var40.setDomainZeroBaselineVisible(false);
    var37.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
    var37.setDefaultEntityRadius((-1));
    java.awt.Stroke var48 = null;
    var37.setSeriesStroke(1, var48);
    java.awt.Shape var51 = var37.lookupLegendShape(100);
    var29.setDownArrow(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var24, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var53);
    var54.setWeight((-123));
    java.util.List var57 = var54.getCategories();
    var54.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    boolean var60 = var23.hasListener((java.util.EventListener)var54);
    java.util.TimeZone var61 = var23.getTimeZone();
    org.jfree.data.time.Day var62 = new org.jfree.data.time.Day(var21, var61);
    java.util.Date var63 = var5.rollDate(var13, var61);
    org.jfree.chart.axis.DateTickUnitType var64 = var5.getRollUnitType();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var66 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
    double var67 = var66.getItemLabelAnchorOffset();
    boolean var68 = var66.getShapesVisible();
    int var69 = var5.compareTo((java.lang.Object)var68);
    int var70 = var5.getCalendarField();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 5);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test154"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var8 = var1.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var9.setDefaultEntityRadius((-1));
//     java.awt.Stroke var20 = null;
//     var9.setSeriesStroke(1, var20);
//     java.awt.Shape var23 = var9.lookupLegendShape(100);
//     var1.setDownArrow(var23);
//     float var25 = var1.getMinorTickMarkInsideLength();
//     var1.configure();
//     org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var30 = null;
//     var28.setSeriesItemLabelGenerator(100, var30);
//     java.awt.Paint var32 = var28.getBaseLegendTextPaint();
//     org.jfree.chart.ChartRenderingInfo var33 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var34 = new org.jfree.chart.plot.PlotRenderingInfo(var33);
//     java.awt.geom.Rectangle2D var35 = var34.getDataArea();
//     var28.setBaseLegendShape((java.awt.Shape)var35);
//     org.jfree.chart.axis.AxisCollection var37 = new org.jfree.chart.axis.AxisCollection();
//     java.util.List var38 = var37.getAxesAtBottom();
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     var39.setLowerMargin((-1.0d));
//     var39.setAxisLineVisible(false);
//     java.lang.String var45 = var39.getCategoryLabelToolTip((java.lang.Comparable)"0,0,1,1");
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var47 = new org.jfree.chart.plot.CombinedRangeXYPlot(var46);
//     double var48 = var47.getDomainCrosshairValue();
//     boolean var49 = var47.isSubplot();
//     org.jfree.chart.util.RectangleEdge var51 = var47.getDomainAxisEdge(1);
//     var37.add((org.jfree.chart.axis.Axis)var39, var51);
//     double var53 = var1.valueToJava2D((-6.0d), var35, var51);
//     
//     // Checks the contract:  equals-hashcode on var12 and var47
//     assertTrue("Contract failed: equals-hashcode on var12 and var47", var12.equals(var47) ? var12.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var12
//     assertTrue("Contract failed: equals-hashcode on var47 and var12", var47.equals(var12) ? var47.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test155"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test156"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.data.time.RegularTimePeriod var14 = var12.getLast();
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 0.0d);
//     var19.setRangeWithMargins(var22);
//     boolean var24 = var15.equals((java.lang.Object)var22);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var25 = var15.getLegendItemToolTipGenerator();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var35 = new org.jfree.chart.plot.CombinedRangeXYPlot(var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     java.awt.Paint var37 = var35.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var33, var37);
//     java.awt.Font var39 = null;
//     var38.setLabelFont(var39);
//     java.awt.Shape var41 = var38.getLine();
//     java.awt.Paint var42 = var38.getFillPaint();
//     var15.setSeriesPaint(0, var42);
//     var12.setMinorTickMarkPaint(var42);
//     
//     // Checks the contract:  equals-hashcode on var2 and var36
//     assertTrue("Contract failed: equals-hashcode on var2 and var36", var2.equals(var36) ? var2.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var2
//     assertTrue("Contract failed: equals-hashcode on var36 and var2", var36.equals(var2) ? var36.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test157"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var1 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
//     org.jfree.data.general.Dataset var4 = var3.getDataset();
//     java.lang.Comparable var5 = var3.getSeriesKey();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
//     var9.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var12 = var9.getTickLabelInsets();
//     double var14 = var12.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.chart.util.LengthAdjustmentType var22 = null;
//     org.jfree.chart.util.LengthAdjustmentType var23 = null;
//     java.awt.geom.Rectangle2D var24 = var12.createAdjustedRectangle(var17, var22, var23);
//     var8.setPlotArea(var17);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, (-1.0d), (-1.0d));
//     java.text.NumberFormat var29 = java.text.NumberFormat.getCurrencyInstance();
//     int var30 = var29.getMinimumIntegerDigits();
//     var29.setMaximumIntegerDigits(4);
//     java.lang.Object var33 = var3.draw(var6, var17, (java.lang.Object)var29);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test158"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var1.configure();
    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var12 = org.jfree.chart.util.RectangleEdge.opposite(var11);
    boolean var14 = var11.equals((java.lang.Object)true);
    double var15 = var1.valueToJava2D(0.05d, var6, var11);
    int var16 = var1.getMinorTickCount();
    var1.configure();
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var19.configure();
    org.jfree.chart.axis.NumberTickUnit var21 = var19.getTickUnit();
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.plot.MultiplePiePlot var23 = new org.jfree.chart.plot.MultiplePiePlot(var22);
    java.awt.Paint var24 = var23.getAggregatedItemsPaint();
    int var25 = var21.compareTo((java.lang.Object)var23);
    java.lang.String var27 = var21.valueToString(100.0d);
    var1.setTickUnit(var21, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "100"+ "'", var27.equals("100"));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test159"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getRightArrow();
    var0.zoomRange((-1.0d), 1.0d);
    double var5 = var0.getLowerMargin();
    org.jfree.data.Range var6 = var0.getRange();
    java.util.Date var7 = var0.getMaximumDate();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var7);
    org.jfree.data.time.RegularTimePeriod var9 = var8.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test160"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var1 = var0.getSeparatorStroke();
//     org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var0.setLegendLabelURLGenerator(var3);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.Plot var6 = var5.getPlot();
//     org.jfree.chart.title.LegendTitle var8 = var5.getLegend(5);
//     java.awt.RenderingHints var9 = null;
//     var5.setRenderingHints(var9);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test161"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var1 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
//     var3.clear();
//     java.lang.String var5 = var3.getURLText();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var9 = var8.getPaint();
//     java.awt.geom.Rectangle2D var10 = var8.getBounds();
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var12 = var11.getRightArrow();
//     var11.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.axis.DateTickMarkPosition var16 = var11.getTickMarkPosition();
//     int var17 = var11.getMinorTickCount();
//     var11.setLabel("ERROR : Relative To String");
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var22 = var21.getPaint();
//     var11.setTickMarkPaint(var22);
//     java.text.DateFormat var24 = null;
//     var11.setDateFormatOverride(var24);
//     java.lang.Object var26 = var3.draw(var6, var10, (java.lang.Object)var24);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test162"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
    var1.setRangeAxisLocation(0, var9, true);
    var1.configureDomainAxes();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    int var15 = var1.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
    double var16 = var14.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test163"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange((-1.0d), 0.0d);
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    float var7 = var6.getTickMarkInsideLength();
    int var8 = var6.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
    var10.setRangeWithMargins(var13);
    var10.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var17 = var10.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    var21.setDomainZeroBaselineVisible(false);
    var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
    var18.setDefaultEntityRadius((-1));
    java.awt.Stroke var29 = null;
    var18.setSeriesStroke(1, var29);
    java.awt.Shape var32 = var18.lookupLegendShape(100);
    var10.setDownArrow(var32);
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var34);
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
    var36.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var39 = var36.getTickLabelInsets();
    var35.setAxisOffset(var39);
    var4.setInsets(var39, false);
    var0.setLabelInsets(var39, false);
    java.util.Date var45 = var0.getMaximumDate();
    java.lang.String var46 = var0.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test164"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test165"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("AxisLocation.BOTTOM_OR_LEFT");
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.awt.geom.Rectangle2D var8 = var7.getDataArea();
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
    org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
    java.awt.Paint var12 = var10.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var8, var12);
    var1.setLabelPaint(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test166"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    java.awt.Font var2 = var0.getLabelFont();
    boolean var3 = var0.getIgnoreNullValues();
    double var4 = var0.getOuterSeparatorExtension();
    boolean var5 = var0.getSeparatorsVisible();
    org.jfree.chart.util.RectangleInsets var6 = var0.getLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test167"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentSize();
//     long var2 = var0.getStartTime();
//     long var3 = var0.getStartTime();
//     java.lang.Object var4 = var0.clone();
//     org.jfree.chart.axis.SegmentedTimeline var5 = var0.getBaseTimeline();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 86400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test168"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    java.awt.Paint var6 = var1.getRangeTickBandPaint();
    org.jfree.chart.util.RectangleEdge var8 = var1.getDomainAxisEdge(5);
    java.lang.String var9 = var1.getPlotType();
    org.jfree.data.xy.XYDataset var11 = var1.getDataset((-123));
    java.awt.Stroke var12 = var1.getDomainMinorGridlineStroke();
    var1.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Combined Range XYPlot"+ "'", var9.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test169"); }
// 
// 
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
//     java.text.NumberFormat var2 = java.text.NumberFormat.getCurrencyInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var1, var2);
//     java.lang.String var5 = var1.format(1.0E12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "$1,000,000,000,000.00"+ "'", var5.equals("$1,000,000,000,000.00"));
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test170"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.XYItemLabelGenerator var11 = null;
    var0.setBaseItemLabelGenerator(var11, true);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.data.Range var15 = var0.findRangeBounds(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test171"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
    float var4 = var3.getTickMarkInsideLength();
    int var5 = var3.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    var7.setRangeWithMargins(var10);
    var7.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var14 = var7.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var16 = var15.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
    org.jfree.chart.plot.DrawingSupplier var19 = var18.getDrawingSupplier();
    var18.setDomainZeroBaselineVisible(false);
    var15.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var18);
    var15.setDefaultEntityRadius((-1));
    java.awt.Stroke var26 = null;
    var15.setSeriesStroke(1, var26);
    java.awt.Shape var29 = var15.lookupLegendShape(100);
    var7.setDownArrow(var29);
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var2, (org.jfree.chart.axis.CategoryAxis)var3, (org.jfree.chart.axis.ValueAxis)var7, var31);
    int var33 = var32.getDatasetCount();
    org.jfree.chart.event.PlotChangeEvent var34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var32);
    var1.plotChanged(var34);
    boolean var36 = var0.equals((java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test172"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test173"); }
// 
// 
//     org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.lang.Comparable var34 = null;
//     var31.setDomainCrosshairColumnKey(var34);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var39 = new org.jfree.chart.plot.CombinedRangeXYPlot(var38);
//     org.jfree.chart.plot.DrawingSupplier var40 = var39.getDrawingSupplier();
//     var39.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot(var44);
//     org.jfree.chart.axis.AxisLocation var46 = var45.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var47 = org.jfree.chart.axis.AxisLocation.getOpposite(var46);
//     var39.setRangeAxisLocation(0, var47, true);
//     boolean var50 = var39.isDomainPannable();
//     var39.clearRangeMarkers();
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
//     java.awt.geom.Rectangle2D var55 = var54.getDataArea();
//     org.jfree.chart.entity.ChartEntity var57 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var55, "");
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var59.setDomainDescription("");
//     var59.clear();
//     java.util.List var63 = var59.getItems();
//     var39.drawDomainTickBands(var52, var55, var63);
//     java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var55, 0.0d, 1.0d);
//     var31.drawBackgroundImage(var37, var55);
//     
//     // Checks the contract:  equals-hashcode on var17 and var45
//     assertTrue("Contract failed: equals-hashcode on var17 and var45", var17.equals(var45) ? var17.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var17
//     assertTrue("Contract failed: equals-hashcode on var45 and var17", var45.equals(var17) ? var45.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var40
//     assertTrue("Contract failed: equals-hashcode on var18 and var40", var18.equals(var40) ? var18.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var18
//     assertTrue("Contract failed: equals-hashcode on var40 and var18", var40.equals(var18) ? var40.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test174"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearAnnotations();
    var30.setNotify(true);
    org.jfree.chart.axis.ValueAxis var37 = var30.getRangeAxisForDataset(5);
    boolean var38 = var30.isRangePannable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test175"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    var31.setWeight((-123));
    java.lang.Comparable var34 = null;
    var31.setDomainCrosshairColumnKey(var34);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var39 = var0.getXValue(5, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

//  public void test176() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest2.test176"); }
//
//
//    java.lang.Class var0 = null;
//    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//    java.util.ResourceBundle.clearCache(var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var1);
//
//  }
//
  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test177"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.Range var2 = var0.getDomainBounds(false);
    var0.clearSelection();
    org.jfree.data.DomainOrder var4 = var0.getDomainOrder();
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var6.setDomainDescription("");
    var6.clear();
    java.util.List var10 = var6.getItems();
    var6.setDescription("Combined Range XYPlot");
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
    org.jfree.chart.plot.DrawingSupplier var19 = var18.getDrawingSupplier();
    java.awt.Paint var20 = var18.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var22 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var23 = null;
    org.jfree.data.Range var25 = org.jfree.data.Range.expandToInclude(var23, 0.0d);
    var22.setRangeWithMargins(var25);
    var18.setDomainAxis((org.jfree.chart.axis.ValueAxis)var22);
    org.jfree.data.time.RegularTimePeriod var28 = var22.getFirst();
    org.jfree.data.time.TimeSeriesDataItem var30 = var16.addOrUpdate(var28, 10.0d);
    var6.add(var28, 0.2d);
    var0.addSeries(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test178"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    double var4 = var0.getXOffset();
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12.0d);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test179"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = null;
    var1.plotChanged(var2);
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    var1.setRangeGridlinePaint(var7);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
    org.jfree.chart.util.RectangleAnchor var14 = null;
    java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
    var1.setQuadrantOrigin(var15);
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.util.RectangleInsets var19 = var17.getItemLabelPadding();
    java.lang.String var20 = var17.getID();
    org.jfree.chart.util.RectangleEdge var21 = var17.getLegendItemGraphicEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test180"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    var32.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var35 = var32.getTickLabelInsets();
    var31.setAxisOffset(var35);
    var0.setInsets(var35, false);
    var0.zoom(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test181"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot(var1);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var2.setFixedRangeAxisSpace(var3);
    org.jfree.chart.LegendItemCollection var5 = new org.jfree.chart.LegendItemCollection();
    var2.setFixedLegendItems(var5);
    var0.add((org.jfree.chart.plot.XYPlot)var2);
    java.util.List var8 = var0.getSubplots();
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var14 = var10.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.labels.StandardPieToolTipGenerator var16 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var17 = var16.getNumberFormat();
    java.text.DateFormat var18 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var19 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var17, var18);
    var10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var19, false);
    java.text.NumberFormat var24 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var25 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var26 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var24, var25);
    java.lang.Object var27 = null;
    boolean var28 = var26.equals(var27);
    org.jfree.chart.renderer.xy.XYBarRenderer var29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var33 = var29.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.urls.StandardXYURLGenerator var35 = new org.jfree.chart.urls.StandardXYURLGenerator();
    var29.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var35);
    org.jfree.chart.renderer.xy.XYAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var26, (org.jfree.chart.urls.XYURLGenerator)var35);
    var10.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var35, true);
    org.jfree.chart.renderer.xy.XYBarRenderer var40 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    var40.setBaseItemLabelsVisible(true, true);
    org.jfree.data.time.TimeSeriesCollection var44 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.Range var46 = var44.getDomainBounds(false);
    org.jfree.data.Range var47 = var40.findRangeBounds((org.jfree.data.xy.XYDataset)var44);
    org.jfree.data.Range var48 = var10.findRangeBounds((org.jfree.data.xy.XYDataset)var44);
    var0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test182"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("TitleEntity: tooltip = 100", "rect", "PlotEntity: tooltip = null", var3, "AxisLocation.BOTTOM_OR_LEFT", "UnitType.ABSOLUTE", "");
    var7.setLicenceText("PlotOrientation.VERTICAL");
    var7.setVersion("HorizontalAlignment.CENTER");

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test183"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.event.PlotChangeEvent var5 = null;
    var4.plotChanged(var5);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
    var1.setCategoryLabelPositionOffset(10);
    var1.setMaximumCategoryLabelLines((-123));
    org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
    float var14 = var13.getMinorTickMarkInsideLength();
    boolean var15 = var13.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var16.setSeriesURLGenerator(4, var18);
    org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
    var16.setBaseToolTipGenerator(var20, true);
    java.lang.Object var23 = null;
    boolean var24 = var16.equals(var23);
    var16.setMinimumBarLength(1.0E-8d);
    double var27 = var16.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.urls.CategoryURLGenerator var29 = null;
    var16.setBaseURLGenerator(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test184"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 2.88E7d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test185"); }
// 
// 
//     org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.lang.Comparable var34 = null;
//     var31.setDomainCrosshairColumnKey(var34);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
//     org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var38 = var37.clone();
//     var31.setFixedRangeAxisSpace(var37);
//     float var40 = var31.getForegroundAlpha();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var43 = var42.getTickMarkInsideLength();
//     int var44 = var42.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var46 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var47 = null;
//     org.jfree.data.Range var49 = org.jfree.data.Range.expandToInclude(var47, 0.0d);
//     var46.setRangeWithMargins(var49);
//     var46.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var53 = var46.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var54 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var55 = var54.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var57 = new org.jfree.chart.plot.CombinedRangeXYPlot(var56);
//     org.jfree.chart.plot.DrawingSupplier var58 = var57.getDrawingSupplier();
//     var57.setDomainZeroBaselineVisible(false);
//     var54.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var57);
//     var54.setDefaultEntityRadius((-1));
//     java.awt.Stroke var65 = null;
//     var54.setSeriesStroke(1, var65);
//     java.awt.Shape var68 = var54.lookupLegendShape(100);
//     var46.setDownArrow(var68);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var70 = null;
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var41, (org.jfree.chart.axis.CategoryAxis)var42, (org.jfree.chart.axis.ValueAxis)var46, var70);
//     java.awt.Font var73 = var42.getTickLabelFont((java.lang.Comparable)4.0d);
//     org.jfree.chart.axis.CategoryAxis3D var74 = new org.jfree.chart.axis.CategoryAxis3D();
//     var74.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var77 = var74.getTickLabelInsets();
//     var42.setTickLabelInsets(var77);
//     var42.setCategoryLabelPositionOffset(5);
//     java.util.List var81 = var31.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var42);
//     
//     // Checks the contract:  equals-hashcode on var17 and var57
//     assertTrue("Contract failed: equals-hashcode on var17 and var57", var17.equals(var57) ? var17.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var17
//     assertTrue("Contract failed: equals-hashcode on var57 and var17", var57.equals(var17) ? var57.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var58
//     assertTrue("Contract failed: equals-hashcode on var18 and var58", var18.equals(var58) ? var18.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var18
//     assertTrue("Contract failed: equals-hashcode on var58 and var18", var58.equals(var18) ? var58.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test186"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    var0.setIgnoreNullValues(true);
    java.lang.String var4 = var0.getPlotType();
    org.jfree.chart.plot.DefaultDrawingSupplier var5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var6 = var5.getNextFillPaint();
    java.awt.Paint var7 = var5.getNextFillPaint();
    var0.setSeparatorPaint(var7);
    var0.setExplodePercent((java.lang.Comparable)"TextAnchor.CENTER", 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Pie Plot"+ "'", var4.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test187"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var1 = var0.getSeparatorStroke();
//     org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var8 = var4.getItemOutlineStroke(0, 0, true);
//     var0.setSectionOutlineStroke((java.lang.Comparable)4.0d, var8);
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var12 = var11.getPaint();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot(var13);
//     org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
//     java.awt.Paint var16 = var14.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var17 = var14.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var18 = org.jfree.chart.util.RectangleEdge.opposite(var17);
//     var11.setPosition(var17);
//     org.jfree.chart.util.RectangleInsets var20 = var11.getPadding();
//     double var22 = var20.trimWidth(0.0d);
//     var0.setLabelPadding(var20);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     var26.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var32 = new org.jfree.chart.plot.CombinedRangeXYPlot(var31);
//     org.jfree.chart.axis.AxisLocation var33 = var32.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var34 = org.jfree.chart.axis.AxisLocation.getOpposite(var33);
//     var26.setRangeAxisLocation(0, var34, true);
//     boolean var37 = var26.isDomainPannable();
//     var26.clearRangeMarkers();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.ChartRenderingInfo var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
//     java.awt.geom.Rectangle2D var42 = var41.getDataArea();
//     org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var42, "");
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var46.setDomainDescription("");
//     var46.clear();
//     java.util.List var50 = var46.getItems();
//     var26.drawDomainTickBands(var39, var42, var50);
//     java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var42, 0.0d, 1.0d);
//     org.jfree.chart.plot.CrosshairState var56 = new org.jfree.chart.plot.CrosshairState(false);
//     var56.setDatasetIndex(100);
//     org.jfree.chart.ChartRenderingInfo var59 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var60 = new org.jfree.chart.plot.PlotRenderingInfo(var59);
//     java.awt.geom.Rectangle2D var61 = var60.getDataArea();
//     org.jfree.chart.entity.ChartEntity var63 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var61, "");
//     org.jfree.chart.util.RectangleAnchor var64 = null;
//     java.awt.geom.Point2D var65 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var64);
//     var56.setAnchor(var65);
//     org.jfree.chart.plot.PlotState var67 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var68 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var70 = var68.getSeriesPositiveItemLabelPosition(0);
//     java.awt.Shape var71 = var68.getBaseLegendShape();
//     var68.setSeriesVisible(10, (java.lang.Boolean)true);
//     org.jfree.chart.labels.StandardXYSeriesLabelGenerator var76 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("SerialDate.weekInMonthToString(): invalid code.");
//     var68.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var76);
//     org.jfree.chart.ChartRenderingInfo var78 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var79 = new org.jfree.chart.plot.PlotRenderingInfo(var78);
//     java.awt.geom.Rectangle2D var80 = var79.getDataArea();
//     java.awt.geom.Rectangle2D var81 = var79.getPlotArea();
//     boolean var82 = var76.equals((java.lang.Object)var79);
//     java.awt.geom.Rectangle2D var83 = var79.getPlotArea();
//     var0.draw(var24, var42, var65, var67, var79);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test188"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
    double var15 = var13.getAngle();
    org.jfree.chart.labels.ItemLabelAnchor var16 = var13.getItemLabelAnchor();
    java.lang.String var17 = var16.toString();
    java.lang.String var18 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "ItemLabelAnchor.OUTSIDE6"+ "'", var17.equals("ItemLabelAnchor.OUTSIDE6"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "ItemLabelAnchor.OUTSIDE6"+ "'", var18.equals("ItemLabelAnchor.OUTSIDE6"));

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test189"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.text.TextFragment var4 = var3.getLastTextFragment();
//     java.awt.Font var5 = var4.getFont();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
//     java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
//     java.awt.Paint var10 = null;
//     boolean var11 = org.jfree.chart.util.PaintUtilities.equal(var9, var10);
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER", var5, var9);
//     var0.setRadiusGridlinePaint(var9);
//     var0.setAngleLabelsVisible(false);
//     org.jfree.data.general.DatasetChangeEvent var16 = null;
//     var0.datasetChanged(var16);
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesPositiveItemLabelPosition(0);
//     java.awt.Shape var23 = var20.getBaseLegendShape();
//     var20.setSeriesVisible(10, (java.lang.Boolean)true);
//     org.jfree.chart.labels.StandardXYSeriesLabelGenerator var28 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("SerialDate.weekInMonthToString(): invalid code.");
//     var20.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var28);
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     java.awt.geom.Rectangle2D var32 = var31.getDataArea();
//     java.awt.geom.Rectangle2D var33 = var31.getPlotArea();
//     boolean var34 = var28.equals((java.lang.Object)var31);
//     java.awt.geom.Rectangle2D var35 = var31.getPlotArea();
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
//     org.jfree.chart.event.PlotChangeEvent var38 = null;
//     var37.plotChanged(var38);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var41 = new org.jfree.chart.plot.CombinedRangeXYPlot(var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = var41.getDrawingSupplier();
//     java.awt.Paint var43 = var41.getRangeZeroBaselinePaint();
//     var37.setRangeGridlinePaint(var43);
//     org.jfree.chart.ChartRenderingInfo var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var45);
//     java.awt.geom.Rectangle2D var47 = var46.getDataArea();
//     org.jfree.chart.entity.ChartEntity var49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var47, "");
//     org.jfree.chart.util.RectangleAnchor var50 = null;
//     java.awt.geom.Point2D var51 = org.jfree.chart.util.RectangleAnchor.coordinates(var47, var50);
//     var37.setQuadrantOrigin(var51);
//     var0.zoomRangeAxes((-1.95d), 0.2d, var31, var51);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test190"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesPaint(0);
    org.jfree.chart.labels.XYSeriesLabelGenerator var3 = var0.getLegendItemURLGenerator();
    java.awt.Shape var4 = var0.getBaseShape();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible(2147483647, (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test191"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var7 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var2.add(var7);
    org.jfree.data.xy.XYDataItem var11 = var2.addOrUpdate((java.lang.Number)1L, (java.lang.Number)(-1L));
    org.jfree.data.time.TimeSeriesCollection var12 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    float var15 = var14.getTickMarkInsideLength();
    int var16 = var14.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 0.0d);
    var18.setRangeWithMargins(var21);
    var18.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var25 = var18.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var27 = var26.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var29 = new org.jfree.chart.plot.CombinedRangeXYPlot(var28);
    org.jfree.chart.plot.DrawingSupplier var30 = var29.getDrawingSupplier();
    var29.setDomainZeroBaselineVisible(false);
    var26.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var29);
    var26.setDefaultEntityRadius((-1));
    java.awt.Stroke var37 = null;
    var26.setSeriesStroke(1, var37);
    java.awt.Shape var40 = var26.lookupLegendShape(100);
    var18.setDownArrow(var40);
    org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var13, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var18, var42);
    var43.setWeight((-123));
    java.lang.Comparable var46 = null;
    var43.setDomainCrosshairColumnKey(var46);
    var12.addChangeListener((org.jfree.data.general.DatasetChangeListener)var43);
    var2.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var12);
    double var50 = var2.getMinX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test192"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    var0.setBase(2.88E7d);
    var0.setBaseSeriesVisibleInLegend(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test193"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    var4.setNegativeArrowVisible(false);
    var4.setLabelURL("hi!");
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var4};
    var1.setRangeAxes(var13);
    org.jfree.chart.util.RectangleEdge var15 = var1.getRangeAxisEdge();
    org.jfree.chart.util.RectangleInsets var16 = var1.getInsets();
    double var18 = var16.calculateRightInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 8.0d);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test194"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     double var5 = var0.getLowerMargin();
//     org.jfree.data.Range var6 = var0.getRange();
//     java.util.Date var7 = var0.getMaximumDate();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var7);
//     java.util.Calendar var9 = null;
//     var8.peg(var9);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test195"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var3 = var0.getTickLabelInsets();
    double var5 = var3.extendHeight(10.0d);
    double var6 = var3.getLeft();
    double var8 = var3.trimHeight((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-6.0d));

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test196"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test197"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var3.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var9 = var3.getFixedRangeAxisSpace();
    org.jfree.chart.util.RectangleEdge var10 = var3.getDomainAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test198"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.general.PieDataset var1 = var0.getDataset();
    var0.setExplodePercent((java.lang.Comparable)86400000L, (-1.0d));
    java.awt.Font var6 = null;
    java.awt.Paint var7 = null;
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var7, 10.0f, var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.util.Size2D var12 = var10.calculateDimensions(var11);
    var12.setWidth(100.0d);
    boolean var15 = var0.equals((java.lang.Object)100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test199"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     var1.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var4 = var1.getTickLabelInsets();
//     double var6 = var4.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var9, "");
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var9, "");
//     org.jfree.chart.util.LengthAdjustmentType var14 = null;
//     org.jfree.chart.util.LengthAdjustmentType var15 = null;
//     java.awt.geom.Rectangle2D var16 = var4.createAdjustedRectangle(var9, var14, var15);
//     boolean var17 = org.jfree.chart.util.LineUtilities.clipLine(var0, var16);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test200"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    boolean var2 = var1.getNotify();
    var1.setExpandToFitSpace(false);
    org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var7 = null;
    var5.setSeriesItemLabelGenerator(100, var7);
    java.awt.Paint var9 = var5.getBaseLegendTextPaint();
    org.jfree.chart.labels.XYToolTipGenerator var10 = var5.getBaseToolTipGenerator();
    org.jfree.chart.urls.XYURLGenerator var14 = var5.getURLGenerator(100, (-1), true);
    org.jfree.chart.ChartRenderingInfo var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
    java.awt.geom.Rectangle2D var22 = var21.getDataArea();
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot(var23);
    org.jfree.chart.plot.DrawingSupplier var25 = var24.getDrawingSupplier();
    java.awt.Paint var26 = var24.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var22, var26);
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var29 = var28.getRightArrow();
    var28.setLowerMargin(4.0d);
    java.awt.Font var32 = var28.getTickLabelFont();
    var27.setLabelFont(var32);
    var5.setSeriesItemLabelFont(0, var32, false);
    var1.setFont(var32);
    var1.setWidth(2.88E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test201"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    var4.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var11 = var4.getPlot();
    java.awt.Shape var12 = var4.getUpArrow();
    var0.setLegendItemShape(var12);
    var0.setShadowXOffset(5.0d);
    org.jfree.chart.LegendItemCollection var16 = var0.getLegendItems();
    org.jfree.chart.urls.PieURLGenerator var17 = var0.getURLGenerator();
    boolean var18 = var0.getIgnoreNullValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test202"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("TitleEntity: tooltip = 100");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test203"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = null;
//     var1.plotChanged(var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     var1.setRangeGridlinePaint(var7);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
//     var1.setQuadrantOrigin(var15);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.lang.Object var18 = var17.clone();
//     org.jfree.chart.util.RectangleInsets var19 = var17.getItemLabelPadding();
//     java.lang.String var20 = var17.getID();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var23 = var22.getTickMarkInsideLength();
//     int var24 = var22.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var27 = null;
//     org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
//     var26.setRangeWithMargins(var29);
//     var26.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var33 = var26.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var35 = var34.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
//     org.jfree.chart.plot.DrawingSupplier var38 = var37.getDrawingSupplier();
//     var37.setDomainZeroBaselineVisible(false);
//     var34.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var37);
//     var34.setDefaultEntityRadius((-1));
//     java.awt.Stroke var45 = null;
//     var34.setSeriesStroke(1, var45);
//     java.awt.Shape var48 = var34.lookupLegendShape(100);
//     var26.setDownArrow(var48);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var22, (org.jfree.chart.axis.ValueAxis)var26, var50);
//     var51.setWeight((-123));
//     var51.clearAnnotations();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     var51.setRenderer(var55, true);
//     var51.mapDatasetToRangeAxis(5, 100);
//     org.jfree.chart.LegendItemSource[] var61 = new org.jfree.chart.LegendItemSource[] { var51};
//     var17.setSources(var61);
//     
//     // Checks the contract:  equals-hashcode on var5 and var37
//     assertTrue("Contract failed: equals-hashcode on var5 and var37", var5.equals(var37) ? var5.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var5
//     assertTrue("Contract failed: equals-hashcode on var37 and var5", var37.equals(var5) ? var37.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var38
//     assertTrue("Contract failed: equals-hashcode on var6 and var38", var6.equals(var38) ? var6.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var6
//     assertTrue("Contract failed: equals-hashcode on var38 and var6", var38.equals(var6) ? var38.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test204"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    java.awt.Stroke var11 = null;
    var0.setSeriesStroke(1, var11);
    boolean var13 = var0.getBaseSeriesVisibleInLegend();
    boolean var14 = var0.getAutoPopulateSeriesPaint();
    java.awt.Stroke var16 = var0.getSeriesOutlineStroke(4);
    org.jfree.data.time.TimeSeriesCollection var17 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection();
    var17.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var18);
    org.jfree.data.time.TimePeriodAnchor var20 = var18.getXPosition();
    org.jfree.data.Range var21 = var0.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var24 = var18.getXValue(5, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test205"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    java.awt.Paint var20 = var0.getSeriesFillPaint((-123));
    var0.setDrawBarOutline(true);
    org.jfree.chart.labels.XYToolTipGenerator var24 = var0.getSeriesToolTipGenerator(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test206"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
//     java.awt.geom.Rectangle2D var7 = var6.getDataArea();
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var9 = new org.jfree.chart.plot.CombinedRangeXYPlot(var8);
//     org.jfree.chart.plot.DrawingSupplier var10 = var9.getDrawingSupplier();
//     java.awt.Paint var11 = var9.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var7, var11);
//     java.text.AttributedString var13 = var12.getAttributedLabel();
//     java.awt.Paint var14 = var12.getOutlinePaint();
//     org.jfree.chart.renderer.xy.XYBarRenderer var15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var17 = null;
//     var15.setSeriesItemLabelGenerator(100, var17);
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot(var27);
//     org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
//     java.awt.Paint var30 = var28.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var26, var30);
//     var15.setSeriesItemLabelPaint(1, var30, false);
//     boolean var34 = var15.getAutoPopulateSeriesShape();
//     java.awt.Font var36 = var15.lookupLegendTextFont(5);
//     org.jfree.chart.labels.ItemLabelPosition var40 = var15.getNegativeItemLabelPosition(0, 2147483647, false);
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot(var41);
//     java.awt.Stroke var43 = var42.getDomainMinorGridlineStroke();
//     var15.setBaseStroke(var43, true);
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var47 = new org.jfree.chart.plot.CombinedRangeXYPlot(var46);
//     org.jfree.chart.axis.AxisLocation var48 = var47.getDomainAxisLocation();
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var51 = var49.getSeriesPositiveItemLabelPosition(0);
//     org.jfree.chart.axis.PeriodAxis var53 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var54 = null;
//     org.jfree.data.Range var56 = org.jfree.data.Range.expandToInclude(var54, 0.0d);
//     var53.setRangeWithMargins(var56);
//     boolean var58 = var49.equals((java.lang.Object)var56);
//     var49.setBaseItemLabelsVisible(false);
//     var49.setBase(2.88E7d);
//     org.jfree.chart.urls.XYURLGenerator var66 = var49.getURLGenerator(100, 0, false);
//     java.awt.Paint var67 = var49.getBaseItemLabelPaint();
//     var47.setDomainMinorGridlinePaint(var67);
//     org.jfree.chart.axis.ValueAxis var72 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var73 = new org.jfree.chart.plot.CombinedRangeXYPlot(var72);
//     org.jfree.chart.axis.AxisLocation var74 = var73.getDomainAxisLocation();
//     java.awt.Paint var75 = var73.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var76 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var75);
//     java.awt.Stroke var77 = var76.getOutlineStroke();
//     org.jfree.chart.util.Layer var78 = null;
//     boolean var80 = var47.removeRangeMarker(10, (org.jfree.chart.plot.Marker)var76, var78, true);
//     java.awt.Paint var81 = var76.getLabelPaint();
//     java.awt.Stroke var82 = null;
//     org.jfree.chart.plot.ValueMarker var84 = new org.jfree.chart.plot.ValueMarker(0.14d, var14, var43, var81, var82, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var6 and var25
//     assertTrue("Contract failed: equals-hashcode on var6 and var25", var6.equals(var25) ? var6.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var6
//     assertTrue("Contract failed: equals-hashcode on var25 and var6", var25.equals(var6) ? var25.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var28
//     assertTrue("Contract failed: equals-hashcode on var9 and var28", var9.equals(var28) ? var9.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var73
//     assertTrue("Contract failed: equals-hashcode on var9 and var73", var9.equals(var73) ? var9.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var9
//     assertTrue("Contract failed: equals-hashcode on var28 and var9", var28.equals(var9) ? var28.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var73
//     assertTrue("Contract failed: equals-hashcode on var28 and var73", var28.equals(var73) ? var28.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var9
//     assertTrue("Contract failed: equals-hashcode on var73 and var9", var73.equals(var9) ? var73.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var28
//     assertTrue("Contract failed: equals-hashcode on var73 and var28", var73.equals(var28) ? var73.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var29
//     assertTrue("Contract failed: equals-hashcode on var10 and var29", var10.equals(var29) ? var10.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var10
//     assertTrue("Contract failed: equals-hashcode on var29 and var10", var29.equals(var10) ? var29.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var31
//     assertTrue("Contract failed: equals-hashcode on var12 and var31", var12.equals(var31) ? var12.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var12
//     assertTrue("Contract failed: equals-hashcode on var31 and var12", var31.equals(var12) ? var31.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test207"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    java.awt.Paint var4 = var0.getBaseLegendTextPaint();
    org.jfree.chart.ChartRenderingInfo var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = new org.jfree.chart.plot.PlotRenderingInfo(var5);
    java.awt.geom.Rectangle2D var7 = var6.getDataArea();
    var0.setBaseLegendShape((java.awt.Shape)var7);
    org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var11 = var10.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    var13.setDomainZeroBaselineVisible(false);
    var10.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var13);
    boolean var20 = var10.getItemVisible(10, 100);
    org.jfree.chart.labels.ItemLabelPosition var22 = var10.getSeriesPositiveItemLabelPosition(10);
    var0.setSeriesPositiveItemLabelPosition(0, var22, true);
    var0.setAutoPopulateSeriesFillPaint(true);
    java.awt.Font var28 = var0.getLegendTextFont(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test208"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.data.time.RegularTimePeriod var11 = var5.getFirst();
    org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem(var11, 0.0d);
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
    org.jfree.chart.axis.AxisLocation var16 = var15.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var17 = org.jfree.chart.axis.AxisLocation.getOpposite(var16);
    boolean var18 = var13.equals((java.lang.Object)var16);
    java.lang.String var19 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var19.equals("AxisLocation.BOTTOM_OR_LEFT"));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test209"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.data.Range var15 = var0.findDomainBounds(var14);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
    org.jfree.chart.plot.DrawingSupplier var19 = var18.getDrawingSupplier();
    java.awt.Paint var20 = var18.getRangeZeroBaselinePaint();
    var0.setSeriesFillPaint(5, var20);
    org.jfree.chart.labels.XYItemLabelGenerator var22 = null;
    var0.setBaseItemLabelGenerator(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test210"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = null;
//     var1.plotChanged(var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     var1.setRangeGridlinePaint(var7);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
//     var1.setQuadrantOrigin(var15);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var21 = null;
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var20, var21);
//     org.jfree.chart.block.RectangleConstraint var23 = var22.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var24 = var17.arrange(var19, var22);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var27 = var26.getTickMarkInsideLength();
//     int var28 = var26.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var31 = null;
//     org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 0.0d);
//     var30.setRangeWithMargins(var33);
//     var30.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var37 = var30.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var39 = var38.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var41 = new org.jfree.chart.plot.CombinedRangeXYPlot(var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = var41.getDrawingSupplier();
//     var41.setDomainZeroBaselineVisible(false);
//     var38.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var41);
//     var38.setDefaultEntityRadius((-1));
//     java.awt.Stroke var49 = null;
//     var38.setSeriesStroke(1, var49);
//     java.awt.Shape var52 = var38.lookupLegendShape(100);
//     var30.setDownArrow(var52);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var25, (org.jfree.chart.axis.CategoryAxis)var26, (org.jfree.chart.axis.ValueAxis)var30, var54);
//     var55.setWeight((-123));
//     var55.clearDomainAxes();
//     boolean var59 = var55.isRangeZeroBaselineVisible();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var61 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var60};
//     var55.setRenderers(var61);
//     var17.setSources((org.jfree.chart.LegendItemSource[])var61);
//     
//     // Checks the contract:  equals-hashcode on var5 and var41
//     assertTrue("Contract failed: equals-hashcode on var5 and var41", var5.equals(var41) ? var5.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var5
//     assertTrue("Contract failed: equals-hashcode on var41 and var5", var41.equals(var5) ? var41.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test211"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    java.awt.Shape var5 = var0.getSeriesShape(10);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test212"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    boolean var19 = var0.getAutoPopulateSeriesShape();
    java.awt.Font var21 = var0.lookupLegendTextFont(5);
    org.jfree.chart.labels.ItemLabelPosition var25 = var0.getNegativeItemLabelPosition(0, 2147483647, false);
    org.jfree.chart.plot.DrawingSupplier var26 = var0.getDrawingSupplier();
    org.jfree.chart.labels.XYToolTipGenerator var30 = var0.getToolTipGenerator(0, 4, true);
    var0.setShadowVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test213"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var11, var15);
    var0.setSeriesItemLabelPaint(1, var15, false);
    org.jfree.data.general.SeriesChangeInfo var19 = null;
    org.jfree.data.general.SeriesChangeEvent var20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var0, var19);
    java.lang.String var21 = var20.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test214"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
    var3.clear();
    var3.setToolTipText("");
    java.lang.Object var7 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test215"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearAnnotations();
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
    var30.setRenderer(var34, true);
    org.jfree.chart.plot.Plot var37 = var30.getRootPlot();
    java.awt.Stroke var38 = var30.getRangeMinorGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test216"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
    java.awt.Paint var5 = var3.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var5);
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.util.GradientPaintTransformer var9 = var8.getFillPaintTransformer();
    var6.setGradientPaintTransformer(var9);
    java.awt.Paint var11 = null;
    var6.setOutlinePaint(var11);
    org.jfree.chart.event.MarkerChangeEvent var13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var6);
    org.jfree.chart.util.RectangleAnchor var14 = var6.getLabelAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test217"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
    var1.setRangeGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test218"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    java.awt.Paint var4 = var0.getBaseLegendTextPaint();
    java.awt.Paint var6 = var0.getSeriesItemLabelPaint(1);
    java.lang.Boolean var8 = var0.getSeriesVisible(2147483647);
    boolean var9 = var0.getBaseCreateEntities();
    java.lang.Boolean var11 = null;
    var0.setSeriesVisible(15, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test219"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    java.lang.Object var1 = var0.clone();
    java.awt.Stroke var3 = var0.getStroke(100);
    var0.clear();
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var6 = var5.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var7 = var5.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var5.setLegendLabelURLGenerator(var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.plot.Plot var11 = var10.getPlot();
    org.jfree.chart.title.LegendTitle var13 = var10.getLegend(5);
    java.lang.Object var14 = var10.getTextAntiAlias();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.event.PlotChangeEvent var17 = null;
    var16.plotChanged(var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var20 = new org.jfree.chart.plot.CombinedRangeXYPlot(var19);
    org.jfree.chart.plot.DrawingSupplier var21 = var20.getDrawingSupplier();
    java.awt.Paint var22 = var20.getRangeZeroBaselinePaint();
    var16.setRangeGridlinePaint(var22);
    org.jfree.chart.ChartRenderingInfo var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
    java.awt.geom.Rectangle2D var26 = var25.getDataArea();
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var26, "");
    org.jfree.chart.util.RectangleAnchor var29 = null;
    java.awt.geom.Point2D var30 = org.jfree.chart.util.RectangleAnchor.coordinates(var26, var29);
    var16.setQuadrantOrigin(var30);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
    org.jfree.chart.util.RectangleInsets var33 = var32.getItemLabelPadding();
    org.jfree.chart.util.RectangleInsets var34 = var32.getItemLabelPadding();
    var10.addSubtitle((org.jfree.chart.title.Title)var32);
    boolean var36 = var0.equals((java.lang.Object)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test220"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var3 = var2.getSeparatorStroke();
//     org.jfree.chart.labels.PieToolTipGenerator var4 = var2.getToolTipGenerator();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     java.awt.Shape var14 = var6.getUpArrow();
//     var2.setLegendItemShape(var14);
//     var2.setShadowXOffset(5.0d);
//     var2.setShadowYOffset(10.0d);
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var22 = var21.getPaint();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D();
//     var26.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var29 = var26.getTickLabelInsets();
//     double var31 = var29.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
//     java.awt.geom.Rectangle2D var34 = var33.getDataArea();
//     org.jfree.chart.entity.ChartEntity var36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var34, "");
//     org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var34, "");
//     org.jfree.chart.util.LengthAdjustmentType var39 = null;
//     org.jfree.chart.util.LengthAdjustmentType var40 = null;
//     java.awt.geom.Rectangle2D var41 = var29.createAdjustedRectangle(var34, var39, var40);
//     var25.setPlotArea(var34);
//     var21.draw(var23, var34);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot(var44);
//     org.jfree.chart.plot.DrawingSupplier var46 = var45.getDrawingSupplier();
//     java.awt.Paint var47 = var45.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var48 = var45.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var49 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var52 = new org.jfree.chart.plot.CombinedRangeXYPlot(var51);
//     org.jfree.chart.plot.DrawingSupplier var53 = var52.getDrawingSupplier();
//     java.awt.Paint var54 = var52.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var55 = var52.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var56 = org.jfree.chart.util.RectangleEdge.opposite(var55);
//     var49.ensureAtLeast((-1.0d), var55);
//     org.jfree.chart.axis.AxisSpace var58 = var0.reserveSpace(var1, (org.jfree.chart.plot.Plot)var2, var34, var48, var49);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test221"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
    boolean var2 = var1.isShapesFilled();
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    var1.setSeriesPositiveItemLabelPosition(100, var4);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var9 = new org.jfree.chart.plot.CombinedRangeXYPlot(var8);
    org.jfree.chart.event.PlotChangeEvent var10 = null;
    var9.plotChanged(var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var13 = new org.jfree.chart.plot.CombinedRangeXYPlot(var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    java.awt.Paint var15 = var13.getRangeZeroBaselinePaint();
    var9.setRangeGridlinePaint(var15);
    org.jfree.chart.ChartRenderingInfo var17 = null;
    org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var17);
    java.awt.geom.Rectangle2D var19 = var18.getDataArea();
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var19, "");
    org.jfree.chart.util.RectangleAnchor var22 = null;
    java.awt.geom.Point2D var23 = org.jfree.chart.util.RectangleAnchor.coordinates(var19, var22);
    var9.setQuadrantOrigin(var23);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
    org.jfree.chart.util.RectangleInsets var26 = var25.getItemLabelPadding();
    org.jfree.chart.util.RectangleInsets var27 = var25.getItemLabelPadding();
    org.jfree.chart.entity.TitleEntity var29 = new org.jfree.chart.entity.TitleEntity(var7, (org.jfree.chart.title.Title)var25, "100");
    org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var7);
    var1.setBaseLegendShape(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test222"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test223"); }


    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat(18.0d, "PlotOrientation.VERTICAL", false);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test224"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
    java.lang.Object var2 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test225"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot(var1);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var2.setFixedRangeAxisSpace(var3);
//     org.jfree.chart.LegendItemCollection var5 = new org.jfree.chart.LegendItemCollection();
//     var2.setFixedLegendItems(var5);
//     var0.add((org.jfree.chart.plot.XYPlot)var2);
//     boolean var8 = var0.isSubplot();
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var12 = var11.getTickMarkInsideLength();
//     int var13 = var11.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var16 = null;
//     org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 0.0d);
//     var15.setRangeWithMargins(var18);
//     var15.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var22 = var15.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var24 = var23.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     var26.setDomainZeroBaselineVisible(false);
//     var23.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     var23.setDefaultEntityRadius((-1));
//     java.awt.Stroke var34 = null;
//     var23.setSeriesStroke(1, var34);
//     java.awt.Shape var37 = var23.lookupLegendShape(100);
//     var15.setDownArrow(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var11, (org.jfree.chart.axis.ValueAxis)var15, var39);
//     var40.setWeight((-123));
//     java.lang.Comparable var43 = null;
//     var40.setDomainCrosshairColumnKey(var43);
//     var9.addChangeListener((org.jfree.data.general.DatasetChangeListener)var40);
//     org.jfree.chart.axis.AxisSpace var46 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var47 = var46.clone();
//     var40.setFixedRangeAxisSpace(var46);
//     org.jfree.chart.util.Layer var49 = null;
//     java.util.Collection var50 = var40.getDomainMarkers(var49);
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
//     java.awt.geom.Rectangle2D var55 = var54.getDataArea();
//     java.awt.geom.Rectangle2D var56 = var54.getPlotArea();
//     java.lang.Object var57 = var54.clone();
//     var40.handleClick((-123), 4, var54);
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var60 = new org.jfree.chart.plot.CombinedRangeXYPlot(var59);
//     org.jfree.chart.axis.AxisSpace var61 = null;
//     var60.setFixedRangeAxisSpace(var61);
//     org.jfree.chart.LegendItemCollection var63 = new org.jfree.chart.LegendItemCollection();
//     var60.setFixedLegendItems(var63);
//     var60.setDomainMinorGridlinesVisible(true);
//     java.awt.geom.Point2D var67 = var60.getQuadrantOrigin();
//     org.jfree.chart.plot.XYPlot var68 = var0.findSubplot(var54, var67);
//     
//     // Checks the contract:  equals-hashcode on var5 and var63
//     assertTrue("Contract failed: equals-hashcode on var5 and var63", var5.equals(var63) ? var5.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var5
//     assertTrue("Contract failed: equals-hashcode on var63 and var5", var63.equals(var5) ? var63.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test226"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    var1.clear();
    java.util.List var5 = var1.getItems();
    var1.setDescription("Combined Range XYPlot");
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var9.setDomainDescription("");
    java.util.Collection var12 = var1.getTimePeriodsUniqueToOtherSeries(var9);
    long var13 = var1.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
    org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
    java.awt.Paint var21 = var19.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var23 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var24 = null;
    org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var24, 0.0d);
    var23.setRangeWithMargins(var26);
    var19.setDomainAxis((org.jfree.chart.axis.ValueAxis)var23);
    org.jfree.data.time.RegularTimePeriod var29 = var23.getFirst();
    org.jfree.data.time.TimeSeriesDataItem var31 = var17.addOrUpdate(var29, 10.0d);
    java.lang.Number var32 = null;
    var1.add(var29, var32);
    java.util.Date var34 = var29.getStart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test227"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
//     org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
//     java.awt.Paint var5 = var3.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var6 = var3.getDomainAxisEdge();
//     var0.ensureAtLeast(100.0d, var6);
//     var0.setRight(4.0d);
//     double var10 = var0.getBottom();
//     org.jfree.chart.axis.AxisSpace var11 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
//     org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
//     java.awt.Paint var17 = var15.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var18 = var15.getDomainAxisEdge();
//     var12.ensureAtLeast(100.0d, var18);
//     var12.setBottom(2.0d);
//     var11.ensureAtLeast(var12);
//     double var23 = var11.getTop();
//     var0.ensureAtLeast(var11);
//     
//     // Checks the contract:  equals-hashcode on var3 and var15
//     assertTrue("Contract failed: equals-hashcode on var3 and var15", var3.equals(var15) ? var3.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var3
//     assertTrue("Contract failed: equals-hashcode on var15 and var3", var15.equals(var3) ? var15.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test228"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Stroke var1 = var0.getSeparatorStroke();
//     org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
//     org.jfree.chart.urls.PieURLGenerator var3 = null;
//     var0.setLegendLabelURLGenerator(var3);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var6 = var5.isNotify();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.event.PlotChangeEvent var9 = null;
//     var8.plotChanged(var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
//     var8.setRangeGridlinePaint(var14);
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.awt.geom.Rectangle2D var18 = var17.getDataArea();
//     org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var18, "");
//     org.jfree.chart.util.RectangleAnchor var21 = null;
//     java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var18, var21);
//     var8.setQuadrantOrigin(var22);
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
//     var5.addLegend(var24);
//     java.util.List var26 = var5.getSubtitles();
//     org.jfree.chart.entity.EntityCollection var30 = null;
//     org.jfree.chart.ChartRenderingInfo var31 = new org.jfree.chart.ChartRenderingInfo(var30);
//     org.jfree.chart.RenderingSource var32 = null;
//     var31.setRenderingSource(var32);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     java.awt.geom.Rectangle2D var40 = var39.getDataArea();
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var42 = new org.jfree.chart.plot.CombinedRangeXYPlot(var41);
//     org.jfree.chart.plot.DrawingSupplier var43 = var42.getDrawingSupplier();
//     java.awt.Paint var44 = var42.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var40, var44);
//     var31.setChartArea(var40);
//     java.awt.image.BufferedImage var47 = var5.createBufferedImage(10, 1, 10, var31);
//     
//     // Checks the contract:  equals-hashcode on var12 and var42
//     assertTrue("Contract failed: equals-hashcode on var12 and var42", var12.equals(var42) ? var12.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var12
//     assertTrue("Contract failed: equals-hashcode on var42 and var12", var42.equals(var12) ? var42.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var43
//     assertTrue("Contract failed: equals-hashcode on var13 and var43", var13.equals(var43) ? var13.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var13
//     assertTrue("Contract failed: equals-hashcode on var43 and var13", var43.equals(var13) ? var43.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var39
//     assertTrue("Contract failed: equals-hashcode on var17 and var39", var17.equals(var39) ? var17.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var17
//     assertTrue("Contract failed: equals-hashcode on var39 and var17", var39.equals(var17) ? var39.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test229"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     var1.setRangeWithMargins(var4);
//     var1.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var8 = var1.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
//     var9.setDefaultEntityRadius((-1));
//     java.awt.Stroke var20 = null;
//     var9.setSeriesStroke(1, var20);
//     java.awt.Shape var23 = var9.lookupLegendShape(100);
//     var1.setDownArrow(var23);
//     double var25 = var1.getLowerMargin();
//     double var26 = var1.getUpperBound();
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Paint var29 = var27.lookupSeriesPaint(0);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var30 = var27.getLegendItemURLGenerator();
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var33 = var32.getTickMarkInsideLength();
//     int var34 = var32.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var37 = null;
//     org.jfree.data.Range var39 = org.jfree.data.Range.expandToInclude(var37, 0.0d);
//     var36.setRangeWithMargins(var39);
//     var36.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var43 = var36.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var44 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var45 = var44.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var47 = new org.jfree.chart.plot.CombinedRangeXYPlot(var46);
//     org.jfree.chart.plot.DrawingSupplier var48 = var47.getDrawingSupplier();
//     var47.setDomainZeroBaselineVisible(false);
//     var44.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var47);
//     var44.setDefaultEntityRadius((-1));
//     java.awt.Stroke var55 = null;
//     var44.setSeriesStroke(1, var55);
//     java.awt.Shape var58 = var44.lookupLegendShape(100);
//     var36.setDownArrow(var58);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var31, (org.jfree.chart.axis.CategoryAxis)var32, (org.jfree.chart.axis.ValueAxis)var36, var60);
//     java.awt.Font var63 = var32.getTickLabelFont((java.lang.Comparable)4.0d);
//     var27.setBaseLegendTextFont(var63);
//     var1.setLabelFont(var63);
//     
//     // Checks the contract:  equals-hashcode on var12 and var47
//     assertTrue("Contract failed: equals-hashcode on var12 and var47", var12.equals(var47) ? var12.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var12
//     assertTrue("Contract failed: equals-hashcode on var47 and var12", var47.equals(var12) ? var47.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var48
//     assertTrue("Contract failed: equals-hashcode on var13 and var48", var13.equals(var48) ? var13.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var13
//     assertTrue("Contract failed: equals-hashcode on var48 and var13", var48.equals(var13) ? var48.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test230"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.awt.Paint var2 = var1.getAggregatedItemsPaint();
    java.awt.Paint var3 = var1.getAggregatedItemsPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test231"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    var0.setBase(2.88E7d);
    var0.setItemLabelAnchorOffset(100.0d);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot(var17);
    double var19 = var18.getDomainCrosshairValue();
    boolean var20 = var18.isSubplot();
    org.jfree.chart.util.RectangleEdge var22 = var18.getDomainAxisEdge(1);
    var18.setForegroundAlpha(1.0f);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var27 = var26.getPaint();
    var18.setNoDataMessagePaint(var27);
    var0.setSeriesFillPaint(3, var27, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test232"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var3 = var0.getTickLabelInsets();
    double var4 = var0.getCategoryMargin();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    float var8 = var7.getTickMarkInsideLength();
    int var9 = var7.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 0.0d);
    var11.setRangeWithMargins(var14);
    var11.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var18 = var11.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var20 = var19.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var22 = new org.jfree.chart.plot.CombinedRangeXYPlot(var21);
    org.jfree.chart.plot.DrawingSupplier var23 = var22.getDrawingSupplier();
    var22.setDomainZeroBaselineVisible(false);
    var19.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var22);
    var19.setDefaultEntityRadius((-1));
    java.awt.Stroke var30 = null;
    var19.setSeriesStroke(1, var30);
    java.awt.Shape var33 = var19.lookupLegendShape(100);
    var11.setDownArrow(var33);
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var35);
    java.awt.Font var38 = var7.getTickLabelFont((java.lang.Comparable)4.0d);
    var0.setTickLabelFont((java.lang.Comparable)15, var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test233"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Font var2 = null;
    java.awt.Paint var3 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 10.0f, var5);
    org.jfree.chart.util.HorizontalAlignment var7 = var6.getLineAlignment();
    boolean var8 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.text.TextFragment var11 = var10.getLastTextFragment();
    org.jfree.chart.text.TextFragment var12 = var10.getLastTextFragment();
    var6.addLine(var10);
    org.jfree.chart.text.TextFragment var14 = var10.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test234"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection();
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var1);
    org.jfree.data.time.TimePeriodAnchor var3 = var1.getXPosition();
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.lang.Object var7 = var5.clone();
    java.util.List var8 = var5.getSubplots();
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1, var8, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test235"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     var32.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var35 = var32.getTickLabelInsets();
//     var31.setAxisOffset(var35);
//     var0.setInsets(var35, false);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot(var39);
//     java.awt.Paint var41 = var40.getAggregatedItemsPaint();
//     var0.setBackgroundPaint(var41);
//     org.jfree.data.general.WaferMapDataset var43 = var0.getDataset();
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot(var44);
//     org.jfree.chart.plot.DrawingSupplier var46 = var45.getDrawingSupplier();
//     org.jfree.chart.axis.PeriodAxis var48 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var49 = null;
//     org.jfree.data.Range var51 = org.jfree.data.Range.expandToInclude(var49, 0.0d);
//     var48.setRangeWithMargins(var51);
//     var48.setNegativeArrowVisible(false);
//     var48.setLabelURL("hi!");
//     org.jfree.chart.axis.ValueAxis[] var57 = new org.jfree.chart.axis.ValueAxis[] { var48};
//     var45.setRangeAxes(var57);
//     org.jfree.chart.util.RectangleEdge var59 = var45.getRangeAxisEdge();
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var45);
//     
//     // Checks the contract:  equals-hashcode on var18 and var46
//     assertTrue("Contract failed: equals-hashcode on var18 and var46", var18.equals(var46) ? var18.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var18
//     assertTrue("Contract failed: equals-hashcode on var46 and var18", var46.equals(var18) ? var46.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test236"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     double var5 = var0.getLowerMargin();
//     org.jfree.data.Range var6 = var0.getRange();
//     java.util.Date var7 = var0.getMaximumDate();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var7);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var12 = var11.getTickMarkInsideLength();
//     int var13 = var11.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var16 = null;
//     org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 0.0d);
//     var15.setRangeWithMargins(var18);
//     var15.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var22 = var15.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var24 = var23.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     var26.setDomainZeroBaselineVisible(false);
//     var23.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     var23.setDefaultEntityRadius((-1));
//     java.awt.Stroke var34 = null;
//     var23.setSeriesStroke(1, var34);
//     java.awt.Shape var37 = var23.lookupLegendShape(100);
//     var15.setDownArrow(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var11, (org.jfree.chart.axis.ValueAxis)var15, var39);
//     var40.setWeight((-123));
//     java.util.List var43 = var40.getCategories();
//     var40.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var46 = var9.hasListener((java.util.EventListener)var40);
//     java.util.TimeZone var47 = var9.getTimeZone();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day(var7, var47);
//     java.lang.String var49 = var48.toString();
//     int var50 = var48.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "31-December-1969"+ "'", var49.equals("31-December-1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 31);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test237"); }


    org.jfree.chart.util.StrokeMap var0 = new org.jfree.chart.util.StrokeMap();
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var2 = var1.getSeparatorStroke();
    var1.setIgnoreNullValues(true);
    org.jfree.chart.urls.PieURLGenerator var5 = null;
    var1.setURLGenerator(var5);
    boolean var7 = var0.equals((java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test238"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    java.awt.Stroke var14 = var12.getMinorTickMarkStroke();
    org.jfree.data.Range var15 = var12.getDefaultAutoRange();
    java.awt.Font var16 = var12.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test239"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
    int var4 = var2.indexOf((java.lang.Number)(byte)100);
    org.jfree.data.xy.XYDataItem var7 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)1.0f);
    var2.add(var7);
    org.jfree.data.xy.XYSeries var11 = var2.createCopy(0, (-123));
    var2.add((java.lang.Number)100, (java.lang.Number)8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test240"); }


    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
    java.awt.Paint var10 = var8.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var6, var10);
    java.awt.Font var12 = null;
    var11.setLabelFont(var12);
    java.awt.Shape var14 = var11.getLine();
    java.awt.Paint var15 = var11.getFillPaint();
    java.awt.Font var16 = var11.getLabelFont();
    boolean var17 = var11.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test241"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     boolean var12 = var1.isDomainPannable();
//     var1.clearRangeMarkers();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var21.setDomainDescription("");
//     var21.clear();
//     java.util.List var25 = var21.getItems();
//     var1.drawDomainTickBands(var14, var17, var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, 0.0d, 1.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var34 = var30.getItemOutlineStroke(0, 0, true);
//     org.jfree.chart.labels.StandardPieToolTipGenerator var36 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
//     java.text.NumberFormat var37 = var36.getNumberFormat();
//     java.text.DateFormat var38 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var39 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var37, var38);
//     var30.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var39, false);
//     java.text.NumberFormat var44 = java.text.NumberFormat.getCurrencyInstance();
//     java.text.NumberFormat var45 = java.text.NumberFormat.getCurrencyInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var44, var45);
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var53 = var49.getItemOutlineStroke(0, 0, true);
//     org.jfree.chart.urls.StandardXYURLGenerator var55 = new org.jfree.chart.urls.StandardXYURLGenerator();
//     var49.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var55);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var57 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var46, (org.jfree.chart.urls.XYURLGenerator)var55);
//     var30.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var55, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var60 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     var60.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.time.TimeSeriesCollection var64 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.Range var66 = var64.getDomainBounds(false);
//     org.jfree.data.Range var67 = var60.findRangeBounds((org.jfree.data.xy.XYDataset)var64);
//     org.jfree.data.Range var68 = var30.findRangeBounds((org.jfree.data.xy.XYDataset)var64);
//     org.jfree.chart.entity.XYItemEntity var73 = new org.jfree.chart.entity.XYItemEntity((java.awt.Shape)var17, (org.jfree.data.xy.XYDataset)var64, 4, 100, "PlotOrientation.VERTICAL", "Other");
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var75 = new org.jfree.chart.plot.CombinedRangeXYPlot(var74);
//     org.jfree.chart.event.PlotChangeEvent var76 = null;
//     var75.plotChanged(var76);
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var79 = new org.jfree.chart.plot.CombinedRangeXYPlot(var78);
//     org.jfree.chart.plot.DrawingSupplier var80 = var79.getDrawingSupplier();
//     java.awt.Paint var81 = var79.getRangeZeroBaselinePaint();
//     var75.setRangeGridlinePaint(var81);
//     org.jfree.chart.ChartRenderingInfo var83 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var84 = new org.jfree.chart.plot.PlotRenderingInfo(var83);
//     java.awt.geom.Rectangle2D var85 = var84.getDataArea();
//     org.jfree.chart.entity.ChartEntity var87 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var85, "");
//     org.jfree.chart.util.RectangleAnchor var88 = null;
//     java.awt.geom.Point2D var89 = org.jfree.chart.util.RectangleAnchor.coordinates(var85, var88);
//     var75.setQuadrantOrigin(var89);
//     org.jfree.chart.title.LegendTitle var91 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var75);
//     org.jfree.chart.util.RectangleInsets var92 = var91.getItemLabelPadding();
//     java.awt.Graphics2D var93 = null;
//     org.jfree.data.Range var94 = null;
//     org.jfree.data.Range var95 = null;
//     org.jfree.chart.block.RectangleConstraint var96 = new org.jfree.chart.block.RectangleConstraint(var94, var95);
//     org.jfree.chart.util.Size2D var97 = var91.arrange(var93, var96);
//     org.jfree.chart.util.RectangleAnchor var98 = var91.getLegendItemGraphicAnchor();
//     boolean var99 = var73.equals((java.lang.Object)var98);
//     
//     // Checks the contract:  equals-hashcode on var7 and var79
//     assertTrue("Contract failed: equals-hashcode on var7 and var79", var7.equals(var79) ? var7.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var7
//     assertTrue("Contract failed: equals-hashcode on var79 and var7", var79.equals(var7) ? var79.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var80
//     assertTrue("Contract failed: equals-hashcode on var2 and var80", var2.equals(var80) ? var2.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var2
//     assertTrue("Contract failed: equals-hashcode on var80 and var2", var80.equals(var2) ? var80.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var84
//     assertTrue("Contract failed: equals-hashcode on var16 and var84", var16.equals(var84) ? var16.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var16
//     assertTrue("Contract failed: equals-hashcode on var84 and var16", var84.equals(var16) ? var84.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test242"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test243"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.util.Rotation var5 = var0.getDirection();
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    java.awt.Paint var10 = var7.getRangeGridlinePaint();
    var0.setLabelOutlinePaint(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test244"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    float var3 = var2.getTickMarkInsideLength();
    int var4 = var2.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
    var31.setWeight((-123));
    java.lang.Comparable var34 = null;
    var31.setDomainCrosshairColumnKey(var34);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
    org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
    java.lang.Object var38 = var37.clone();
    var31.setFixedRangeAxisSpace(var37);
    boolean var40 = var31.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test245"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    java.util.List var33 = var30.getCategories();
    org.jfree.data.category.CategoryDataset var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var30.getRendererForDataset(var34);
    var30.setRangeMinorGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test246"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var2 = var1.getPaint();
    java.awt.geom.Rectangle2D var3 = var1.getBounds();
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
    var8.setRangeWithMargins(var11);
    boolean var13 = var4.equals((java.lang.Object)var11);
    var4.setBaseItemLabelsVisible(false);
    var4.setBase(2.88E7d);
    org.jfree.chart.urls.XYURLGenerator var21 = var4.getURLGenerator(100, 0, false);
    java.awt.Paint var22 = var4.getBaseItemLabelPaint();
    var1.setPaint(var22);
    var1.setExpandToFitSpace(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test247"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.event.PlotChangeEvent var2 = null;
    var1.plotChanged(var2);
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
    java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
    var1.setRangeGridlinePaint(var7);
    org.jfree.chart.plot.SeriesRenderingOrder var9 = var1.getSeriesRenderingOrder();
    var1.clearAnnotations();
    boolean var11 = var1.canSelectByRegion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test248"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     double var5 = var0.getLowerMargin();
//     org.jfree.data.Range var6 = var0.getRange();
//     java.util.Date var7 = var0.getMaximumDate();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var7);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var12 = var11.getTickMarkInsideLength();
//     int var13 = var11.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var16 = null;
//     org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 0.0d);
//     var15.setRangeWithMargins(var18);
//     var15.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var22 = var15.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var24 = var23.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     var26.setDomainZeroBaselineVisible(false);
//     var23.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     var23.setDefaultEntityRadius((-1));
//     java.awt.Stroke var34 = null;
//     var23.setSeriesStroke(1, var34);
//     java.awt.Shape var37 = var23.lookupLegendShape(100);
//     var15.setDownArrow(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var11, (org.jfree.chart.axis.ValueAxis)var15, var39);
//     var40.setWeight((-123));
//     java.util.List var43 = var40.getCategories();
//     var40.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var46 = var9.hasListener((java.util.EventListener)var40);
//     java.util.TimeZone var47 = var9.getTimeZone();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day(var7, var47);
//     long var49 = var48.getLastMillisecond();
//     org.jfree.data.time.SerialDate var50 = var48.getSerialDate();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test249"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    boolean var6 = var5.isNotify();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.event.PlotChangeEvent var9 = null;
    var8.plotChanged(var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
    var8.setRangeGridlinePaint(var14);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var18, "");
    org.jfree.chart.util.RectangleAnchor var21 = null;
    java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var18, var21);
    var8.setQuadrantOrigin(var22);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    var5.addLegend(var24);
    org.jfree.chart.util.RectangleInsets var26 = var5.getPadding();
    var5.setTextAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test250"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.event.PlotChangeEvent var2 = null;
//     var1.plotChanged(var2);
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
//     org.jfree.chart.plot.DrawingSupplier var6 = var5.getDrawingSupplier();
//     java.awt.Paint var7 = var5.getRangeZeroBaselinePaint();
//     var1.setRangeGridlinePaint(var7);
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var11, "");
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var14);
//     var1.setQuadrantOrigin(var15);
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getItemLabelPadding();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var21 = null;
//     org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var20, var21);
//     org.jfree.chart.block.RectangleConstraint var23 = var22.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var24 = var17.arrange(var19, var22);
//     org.jfree.chart.axis.AxisCollection var25 = new org.jfree.chart.axis.AxisCollection();
//     java.util.List var26 = var25.getAxesAtBottom();
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
//     var27.setLowerMargin((-1.0d));
//     var27.setAxisLineVisible(false);
//     java.lang.String var33 = var27.getCategoryLabelToolTip((java.lang.Comparable)"0,0,1,1");
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var35 = new org.jfree.chart.plot.CombinedRangeXYPlot(var34);
//     double var36 = var35.getDomainCrosshairValue();
//     boolean var37 = var35.isSubplot();
//     org.jfree.chart.util.RectangleEdge var39 = var35.getDomainAxisEdge(1);
//     var25.add((org.jfree.chart.axis.Axis)var27, var39);
//     var17.setLegendItemGraphicEdge(var39);
//     
//     // Checks the contract:  equals-hashcode on var5 and var35
//     assertTrue("Contract failed: equals-hashcode on var5 and var35", var5.equals(var35) ? var5.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var5
//     assertTrue("Contract failed: equals-hashcode on var35 and var5", var35.equals(var5) ? var35.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test251"); }
// 
// 
//     org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'#', true);
//     double var3 = var2.getMaxX();
//     var2.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test252"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
    var1.setRangeAxisLocation(0, var9, true);
    var1.configureDomainAxes();
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var14 = var13.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var15 = var13.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var16 = null;
    var13.setLegendLabelURLGenerator(var16);
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, (-1.0d), 100.0d);
    java.awt.Paint var23 = var22.getPaint();
    var13.setSeparatorPaint(var23);
    var1.setDomainCrosshairPaint(var23);
    java.awt.geom.Point2D var26 = var1.getQuadrantOrigin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test253"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getMaximumBarWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test254"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    var1.configureRangeAxes();
    var1.clearDomainMarkers();
    double var7 = var1.getGap();
    org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation(100);
    boolean var10 = var1.isDomainPannable();
    var1.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test255"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.ChartRenderingInfo var12 = null;
    org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    var14.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var17 = var14.getTickLabelInsets();
    double var19 = var17.extendHeight(10.0d);
    org.jfree.chart.ChartRenderingInfo var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
    java.awt.geom.Rectangle2D var22 = var21.getDataArea();
    org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var22, "");
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var22, "");
    org.jfree.chart.util.LengthAdjustmentType var27 = null;
    org.jfree.chart.util.LengthAdjustmentType var28 = null;
    java.awt.geom.Rectangle2D var29 = var17.createAdjustedRectangle(var22, var27, var28);
    var13.setPlotArea(var22);
    var1.drawBackgroundImage(var11, var22);
    org.jfree.chart.axis.AxisSpace var32 = var1.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test256"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var1 = var0.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test257"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    org.jfree.chart.labels.CategoryToolTipGenerator var4 = null;
    var0.setBaseToolTipGenerator(var4, true);
    double var7 = var0.getXOffset();
    double var8 = var0.getMinimumBarLength();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = null;
    var0.setBaseItemLabelGenerator(var9);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var0.getItemLabelGenerator(520764324, 2, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test258"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    boolean var8 = var3.isDomainZoomable();
    int var9 = var3.getSeriesCount();
    org.jfree.chart.util.RectangleEdge var10 = var3.getDomainAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test259"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 2.0f, 0.0f);
    float[] var4 = null;
    float[] var5 = var3.getColorComponents(var4);
    int var6 = var3.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test260"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var2 = var0.lookupSeriesOutlineStroke(4);
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var4 = new org.jfree.chart.plot.CombinedRangeXYPlot(var3);
    org.jfree.chart.plot.DrawingSupplier var5 = var4.getDrawingSupplier();
    java.awt.Paint var6 = var4.getRangeZeroBaselinePaint();
    var4.setDomainMinorGridlinesVisible(true);
    org.jfree.chart.axis.ValueAxis var10 = var4.getDomainAxis((-123));
    var4.setOutlineVisible(false);
    java.awt.Stroke var13 = var4.getDomainZeroBaselineStroke();
    var0.setBaseStroke(var13, true);
    java.io.ObjectOutputStream var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var13, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test261"); }
// 
// 
//     org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var3 = var2.getTickMarkInsideLength();
//     int var4 = var2.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
//     var17.setDomainZeroBaselineVisible(false);
//     var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     var14.setDefaultEntityRadius((-1));
//     java.awt.Stroke var25 = null;
//     var14.setSeriesStroke(1, var25);
//     java.awt.Shape var28 = var14.lookupLegendShape(100);
//     var6.setDownArrow(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var30);
//     var31.setWeight((-123));
//     java.lang.Comparable var34 = null;
//     var31.setDomainCrosshairColumnKey(var34);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var31);
//     org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var38 = var37.clone();
//     var31.setFixedRangeAxisSpace(var37);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var41 = new org.jfree.chart.plot.CombinedDomainXYPlot(var40);
//     java.awt.Stroke var42 = var41.getDomainMinorGridlineStroke();
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var44 = new org.jfree.chart.plot.CombinedRangeXYPlot(var43);
//     org.jfree.chart.plot.DrawingSupplier var45 = var44.getDrawingSupplier();
//     var44.setDomainZeroBaselineVisible(false);
//     java.lang.Object var48 = var44.clone();
//     org.jfree.data.xy.XYDataset var50 = var44.getDataset(0);
//     boolean var51 = var44.canSelectByRegion();
//     org.jfree.chart.plot.PlotOrientation var52 = var44.getOrientation();
//     var41.setOrientation(var52);
//     var31.setOrientation(var52);
//     
//     // Checks the contract:  equals-hashcode on var17 and var44
//     assertTrue("Contract failed: equals-hashcode on var17 and var44", var17.equals(var44) ? var17.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var17
//     assertTrue("Contract failed: equals-hashcode on var44 and var17", var44.equals(var17) ? var44.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var45
//     assertTrue("Contract failed: equals-hashcode on var18 and var45", var18.equals(var45) ? var18.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var18
//     assertTrue("Contract failed: equals-hashcode on var45 and var18", var45.equals(var18) ? var45.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test262"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Font var2 = null;
//     java.awt.Paint var3 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, var3, 10.0f, var5);
//     org.jfree.chart.util.HorizontalAlignment var7 = var6.getLineAlignment();
//     boolean var8 = var0.equals((java.lang.Object)var6);
//     org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.text.TextFragment var11 = var10.getLastTextFragment();
//     org.jfree.chart.text.TextFragment var12 = var10.getLastTextFragment();
//     var6.addLine(var10);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     java.awt.Shape var21 = var6.calculateBounds(var14, 100.0f, (-1.0f), var17, 100.0f, 0.0f, Double.NaN);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test263"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentSize();
//     long var2 = var0.getStartTime();
//     long var3 = var0.getStartTime();
//     java.lang.Object var4 = var0.clone();
//     var0.setStartTime(0L);
//     int var7 = var0.getSegmentsExcluded();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 86400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-2208960000000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test264"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("AxisLocation.BOTTOM_OR_LEFT");
    double var3 = var1.calculateValue(2.88E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == Double.POSITIVE_INFINITY);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test265"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     boolean var12 = var1.isDomainPannable();
//     var1.clearRangeMarkers();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var21.setDomainDescription("");
//     var21.clear();
//     java.util.List var25 = var21.getItems();
//     var1.drawDomainTickBands(var14, var17, var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, 0.0d, 1.0d);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     var30.setUseFillPaint(true);
//     var30.setSeriesShapesFilled(5, (java.lang.Boolean)false);
//     java.awt.Paint var36 = var30.getBaseFillPaint();
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var17, var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var41 = var40.getPaint();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot(var42);
//     org.jfree.chart.plot.DrawingSupplier var44 = var43.getDrawingSupplier();
//     java.awt.Paint var45 = var43.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var46 = var43.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var47 = org.jfree.chart.util.RectangleEdge.opposite(var46);
//     var40.setPosition(var46);
//     org.jfree.chart.util.RectangleInsets var49 = var40.getPadding();
//     org.jfree.chart.event.TitleChangeEvent var50 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var40);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
//     var52.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var55 = var52.getTickLabelInsets();
//     double var57 = var55.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var58 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var59 = new org.jfree.chart.plot.PlotRenderingInfo(var58);
//     java.awt.geom.Rectangle2D var60 = var59.getDataArea();
//     org.jfree.chart.entity.ChartEntity var62 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var60, "");
//     org.jfree.chart.entity.ChartEntity var64 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var60, "");
//     org.jfree.chart.util.LengthAdjustmentType var65 = null;
//     org.jfree.chart.util.LengthAdjustmentType var66 = null;
//     java.awt.geom.Rectangle2D var67 = var55.createAdjustedRectangle(var60, var65, var66);
//     var40.draw(var51, var67);
//     org.jfree.data.general.PieDataset var69 = null;
//     org.jfree.chart.plot.PiePlot var70 = new org.jfree.chart.plot.PiePlot(var69);
//     org.jfree.chart.plot.AbstractPieLabelDistributor var71 = var70.getLabelDistributor();
//     java.lang.Object var72 = var37.draw(var38, var67, (java.lang.Object)var71);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test266"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     boolean var12 = var1.isDomainPannable();
//     var1.clearRangeMarkers();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var21.setDomainDescription("");
//     var21.clear();
//     java.util.List var25 = var21.getItems();
//     var1.drawDomainTickBands(var14, var17, var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, 0.0d, 1.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var34 = var30.getItemOutlineStroke(0, 0, true);
//     org.jfree.chart.labels.StandardPieToolTipGenerator var36 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
//     java.text.NumberFormat var37 = var36.getNumberFormat();
//     java.text.DateFormat var38 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var39 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var37, var38);
//     var30.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var39, false);
//     java.text.NumberFormat var44 = java.text.NumberFormat.getCurrencyInstance();
//     java.text.NumberFormat var45 = java.text.NumberFormat.getCurrencyInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var44, var45);
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var53 = var49.getItemOutlineStroke(0, 0, true);
//     org.jfree.chart.urls.StandardXYURLGenerator var55 = new org.jfree.chart.urls.StandardXYURLGenerator();
//     var49.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var55);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var57 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var46, (org.jfree.chart.urls.XYURLGenerator)var55);
//     var30.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var55, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var60 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     var60.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.time.TimeSeriesCollection var64 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.Range var66 = var64.getDomainBounds(false);
//     org.jfree.data.Range var67 = var60.findRangeBounds((org.jfree.data.xy.XYDataset)var64);
//     org.jfree.data.Range var68 = var30.findRangeBounds((org.jfree.data.xy.XYDataset)var64);
//     org.jfree.chart.entity.XYItemEntity var73 = new org.jfree.chart.entity.XYItemEntity((java.awt.Shape)var17, (org.jfree.data.xy.XYDataset)var64, 4, 100, "PlotOrientation.VERTICAL", "Other");
//     org.jfree.chart.axis.NumberAxis3D var75 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var75.configure();
//     org.jfree.chart.ChartRenderingInfo var78 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var79 = new org.jfree.chart.plot.PlotRenderingInfo(var78);
//     java.awt.geom.Rectangle2D var80 = var79.getDataArea();
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var82 = new org.jfree.chart.plot.CombinedRangeXYPlot(var81);
//     org.jfree.chart.plot.DrawingSupplier var83 = var82.getDrawingSupplier();
//     java.awt.Paint var84 = var82.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var85 = var82.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var86 = org.jfree.chart.util.RectangleEdge.opposite(var85);
//     boolean var88 = var85.equals((java.lang.Object)true);
//     double var89 = var75.valueToJava2D(0.05d, var80, var85);
//     boolean var90 = var73.equals((java.lang.Object)var75);
//     
//     // Checks the contract:  equals-hashcode on var7 and var82
//     assertTrue("Contract failed: equals-hashcode on var7 and var82", var7.equals(var82) ? var7.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var7
//     assertTrue("Contract failed: equals-hashcode on var82 and var7", var82.equals(var7) ? var82.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var83
//     assertTrue("Contract failed: equals-hashcode on var2 and var83", var2.equals(var83) ? var2.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var2
//     assertTrue("Contract failed: equals-hashcode on var83 and var2", var83.equals(var2) ? var83.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var79
//     assertTrue("Contract failed: equals-hashcode on var16 and var79", var16.equals(var79) ? var16.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var16
//     assertTrue("Contract failed: equals-hashcode on var79 and var16", var79.equals(var16) ? var79.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test267"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var1 = var0.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    var3.setDomainZeroBaselineVisible(false);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var3);
    var0.setDefaultEntityRadius((-1));
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
    java.awt.Paint var11 = var0.getBaseItemLabelPaint();
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test268"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("rect");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test269"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = null;
//     var0.setSeriesURLGenerator(4, var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var7 = var6.getTickMarkInsideLength();
//     int var8 = var6.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     var10.setRangeWithMargins(var13);
//     var10.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var17 = var10.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var19 = var18.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var21 = new org.jfree.chart.plot.CombinedRangeXYPlot(var20);
//     org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
//     var21.setDomainZeroBaselineVisible(false);
//     var18.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var21);
//     var18.setDefaultEntityRadius((-1));
//     java.awt.Stroke var29 = null;
//     var18.setSeriesStroke(1, var29);
//     java.awt.Shape var32 = var18.lookupLegendShape(100);
//     var10.setDownArrow(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var34);
//     var35.setRangeZeroBaselineVisible(false);
//     java.awt.geom.Rectangle2D var38 = null;
//     var0.drawBackground(var4, var35, var38);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test270"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    int var31 = var30.getDatasetCount();
    var30.setDomainGridlinesVisible(true);
    java.awt.Stroke var34 = var30.getDomainGridlineStroke();
    org.jfree.chart.util.Layer var35 = null;
    java.util.Collection var36 = var30.getRangeMarkers(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test271"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
//     java.awt.Shape var3 = var0.getBaseLegendShape();
//     var0.setSeriesVisible(10, (java.lang.Boolean)true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var8 = var7.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     var10.setDomainZeroBaselineVisible(false);
//     var7.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
//     var7.setDefaultEntityRadius((-1));
//     org.jfree.chart.labels.XYSeriesLabelGenerator var17 = var7.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var17);
//     var0.setMargin(1.0E-8d);
//     org.jfree.data.time.TimeSeriesCollection var21 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection();
//     var21.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var22);
//     var22.removeAllSeries();
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     float var28 = var26.getForegroundAlpha();
//     var22.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var26);
//     org.jfree.data.xy.XYDatasetSelectionState var30 = var22.getSelectionState();
//     org.jfree.data.Range var32 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var22, false);
//     var22.clearSelection();
//     org.jfree.data.Range var34 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var22);
//     org.jfree.data.Range var35 = var0.findRangeBounds((org.jfree.data.xy.XYDataset)var22);
//     
//     // Checks the contract:  equals-hashcode on var10 and var26
//     assertTrue("Contract failed: equals-hashcode on var10 and var26", var10.equals(var26) ? var10.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var10
//     assertTrue("Contract failed: equals-hashcode on var26 and var10", var26.equals(var10) ? var26.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var27
//     assertTrue("Contract failed: equals-hashcode on var11 and var27", var11.equals(var27) ? var11.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var11
//     assertTrue("Contract failed: equals-hashcode on var27 and var11", var27.equals(var11) ? var27.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test272"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    float var1 = var0.getTickMarkInsideLength();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var3.plotChanged(var4);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
    java.lang.String var7 = var0.getLabelToolTip();
    double var8 = var0.getLowerMargin();
    var0.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test273"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    boolean var6 = var5.isNotify();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
    org.jfree.chart.event.PlotChangeEvent var9 = null;
    var8.plotChanged(var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
    var8.setRangeGridlinePaint(var14);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var18, "");
    org.jfree.chart.util.RectangleAnchor var21 = null;
    java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var18, var21);
    var8.setQuadrantOrigin(var22);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    var5.addLegend(var24);
    org.jfree.chart.util.RectangleInsets var26 = var5.getPadding();
    org.jfree.chart.util.RectangleInsets var27 = var5.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test274"); }


    java.text.NumberFormat var2 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var3 = java.text.NumberFormat.getCurrencyInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var2, var3);
    java.lang.Object var5 = null;
    boolean var6 = var4.equals(var5);
    org.jfree.chart.renderer.xy.XYBarRenderer var7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var11 = var7.getItemOutlineStroke(0, 0, true);
    org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator();
    var7.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var13);
    org.jfree.chart.renderer.xy.XYAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
    var15.setBaseCreateEntities(true, true);
    java.awt.Shape var19 = var15.getLegendArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test275"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.text.TextFragment var4 = var3.getLastTextFragment();
    java.awt.Font var5 = var4.getFont();
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
    java.awt.Paint var10 = null;
    boolean var11 = org.jfree.chart.util.PaintUtilities.equal(var9, var10);
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER", var5, var9);
    var0.setRadiusGridlinePaint(var9);
    var0.setAngleLabelsVisible(false);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var17 = var16.getMarkerBand();
    var16.pan(12.0d);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.MarkerAxisBand var21 = var20.getMarkerBand();
    org.jfree.chart.event.AxisChangeEvent var22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var20);
    org.jfree.chart.axis.NumberTickUnit var23 = var20.getTickUnit();
    var16.setTickUnit(var23);
    var0.setAngleTickUnit((org.jfree.chart.axis.TickUnit)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test276"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test277"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var2, "");
    org.jfree.chart.util.RectangleAnchor var5 = null;
    java.awt.geom.Point2D var6 = org.jfree.chart.util.RectangleAnchor.coordinates(var2, var5);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.entity.PieSectionEntity var13 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var2, var7, 100, 100, (java.lang.Comparable)(-1L), "hi!", "");
    int var14 = var13.getSectionIndex();
    int var15 = var13.getSectionIndex();
    var13.setSectionIndex(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test278"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.LegendItemCollection var33 = var30.getLegendItems();
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var34.getLegendItemToolTipGenerator();
    var30.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var34, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test279"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var1 = var0.getNextFillPaint();
    java.awt.Shape var2 = var0.getNextShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test280"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    var0.setIgnoreZeroValues(false);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    org.jfree.chart.plot.CrosshairState var5 = new org.jfree.chart.plot.CrosshairState(false);
    var5.updateCrosshairY(0.05d, 10);
    boolean var9 = var3.equals((java.lang.Object)0.05d);
    var0.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    java.lang.Object var11 = var3.clone();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    float var14 = var13.getTickMarkInsideLength();
    int var15 = var13.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 0.0d);
    var17.setRangeWithMargins(var20);
    var17.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var24 = var17.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var25 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var26 = var25.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot(var27);
    org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
    var28.setDomainZeroBaselineVisible(false);
    var25.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var28);
    var25.setDefaultEntityRadius((-1));
    java.awt.Stroke var36 = null;
    var25.setSeriesStroke(1, var36);
    java.awt.Shape var39 = var25.lookupLegendShape(100);
    var17.setDownArrow(var39);
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var12, (org.jfree.chart.axis.CategoryAxis)var13, (org.jfree.chart.axis.ValueAxis)var17, var41);
    int var43 = var42.getDatasetCount();
    var42.setDomainGridlinesVisible(true);
    java.awt.Stroke var46 = var42.getDomainGridlineStroke();
    boolean var47 = var3.equals((java.lang.Object)var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test281"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var8 = new org.jfree.chart.plot.CombinedRangeXYPlot(var7);
//     org.jfree.chart.plot.DrawingSupplier var9 = var8.getDrawingSupplier();
//     var8.setDomainZeroBaselineVisible(false);
//     java.lang.Object var12 = var8.clone();
//     org.jfree.data.xy.XYDataset var14 = var8.getDataset(0);
//     boolean var15 = var8.canSelectByRegion();
//     org.jfree.chart.plot.PlotOrientation var16 = var8.getOrientation();
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     var21.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var24 = var21.getTickLabelInsets();
//     double var26 = var24.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     java.awt.geom.Rectangle2D var29 = var28.getDataArea();
//     org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var29, "");
//     org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var29, "");
//     org.jfree.chart.util.LengthAdjustmentType var34 = null;
//     org.jfree.chart.util.LengthAdjustmentType var35 = null;
//     java.awt.geom.Rectangle2D var36 = var24.createAdjustedRectangle(var29, var34, var35);
//     var20.setPlotArea(var29);
//     org.jfree.chart.renderer.RendererState var38 = new org.jfree.chart.renderer.RendererState(var20);
//     var8.handleClick(15, (-1), var20);
//     org.jfree.chart.ChartRenderingInfo var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
//     java.awt.geom.Rectangle2D var42 = var41.getDataArea();
//     org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var42, "");
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var42, var45);
//     var1.zoomDomainAxes(0.0d, var20, var46);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var12
//     assertTrue("Contract failed: equals-hashcode on var5 and var12", var5.equals(var12) ? var5.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var5
//     assertTrue("Contract failed: equals-hashcode on var12 and var5", var12.equals(var5) ? var12.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var41
//     assertTrue("Contract failed: equals-hashcode on var28 and var41", var28.equals(var41) ? var28.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var28
//     assertTrue("Contract failed: equals-hashcode on var41 and var28", var41.equals(var28) ? var41.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test282"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorUp((-6.0d));

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test283"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var1 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
//     var3.clear();
//     java.lang.Object var5 = var3.clone();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var8 = var7.getPaint();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     java.awt.Paint var12 = var10.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var13 = var10.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var14 = org.jfree.chart.util.RectangleEdge.opposite(var13);
//     var7.setPosition(var13);
//     org.jfree.chart.util.RectangleInsets var16 = var7.getPadding();
//     org.jfree.chart.event.TitleChangeEvent var17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var7);
//     java.lang.String var18 = var7.getText();
//     java.lang.String var19 = var7.getText();
//     org.jfree.chart.util.HorizontalAlignment var20 = var7.getTextAlignment();
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.FlowArrangement var24 = new org.jfree.chart.block.FlowArrangement(var20, var21, Double.NaN, 0.0d);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D("ThreadContext");
//     boolean var27 = var24.equals((java.lang.Object)"ThreadContext");
//     var3.setArrangement((org.jfree.chart.block.Arrangement)var24);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     boolean var31 = var30.getNotify();
//     java.lang.Object var32 = null;
//     boolean var33 = var30.equals(var32);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot(var36);
//     org.jfree.chart.axis.AxisLocation var38 = var37.getDomainAxisLocation();
//     java.awt.Paint var39 = var37.getDomainCrosshairPaint();
//     org.jfree.chart.plot.IntervalMarker var40 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var39);
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.chart.util.GradientPaintTransformer var43 = var42.getFillPaintTransformer();
//     var40.setGradientPaintTransformer(var43);
//     java.awt.Paint var45 = null;
//     var40.setOutlinePaint(var45);
//     org.jfree.chart.event.MarkerChangeEvent var47 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var40);
//     org.jfree.chart.plot.Marker var48 = var47.getMarker();
//     var24.add((org.jfree.chart.block.Block)var30, (java.lang.Object)var48);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test284"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     var0.zoomRange((-1.0d), 0.0d);
//     java.util.Date var4 = var0.getMaximumDate();
//     org.jfree.chart.axis.DateTickUnit var5 = var0.getTickUnit();
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var7 = var6.getRightArrow();
//     var6.zoomRange((-1.0d), 1.0d);
//     double var11 = var6.getLowerMargin();
//     org.jfree.data.Range var12 = var6.getRange();
//     java.util.Date var13 = var6.getMaximumDate();
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var15 = var14.getRightArrow();
//     var14.zoomRange((-1.0d), 1.0d);
//     double var19 = var14.getLowerMargin();
//     org.jfree.data.Range var20 = var14.getRange();
//     java.util.Date var21 = var14.getMaximumDate();
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var21);
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var26 = var25.getTickMarkInsideLength();
//     int var27 = var25.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var30 = null;
//     org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 0.0d);
//     var29.setRangeWithMargins(var32);
//     var29.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var36 = var29.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var37 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var38 = var37.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var40 = new org.jfree.chart.plot.CombinedRangeXYPlot(var39);
//     org.jfree.chart.plot.DrawingSupplier var41 = var40.getDrawingSupplier();
//     var40.setDomainZeroBaselineVisible(false);
//     var37.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
//     var37.setDefaultEntityRadius((-1));
//     java.awt.Stroke var48 = null;
//     var37.setSeriesStroke(1, var48);
//     java.awt.Shape var51 = var37.lookupLegendShape(100);
//     var29.setDownArrow(var51);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var24, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var53);
//     var54.setWeight((-123));
//     java.util.List var57 = var54.getCategories();
//     var54.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var60 = var23.hasListener((java.util.EventListener)var54);
//     java.util.TimeZone var61 = var23.getTimeZone();
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day(var21, var61);
//     java.util.Date var63 = var5.rollDate(var13, var61);
//     org.jfree.chart.axis.DateTickUnitType var64 = var5.getRollUnitType();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var66 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(10);
//     double var67 = var66.getItemLabelAnchorOffset();
//     boolean var68 = var66.getShapesVisible();
//     int var69 = var5.compareTo((java.lang.Object)var68);
//     org.jfree.data.time.DateRange var72 = new org.jfree.data.time.DateRange((-6.0d), 2.88E7d);
//     java.util.Date var73 = var72.getLowerDate();
//     java.util.Date var74 = var72.getUpperDate();
//     java.lang.String var75 = var5.dateToString(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 2.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var75 + "' != '" + "1/1/70 12:00 AM"+ "'", var75.equals("1/1/70 12:00 AM"));
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test285"); }


    org.jfree.chart.urls.StandardXYURLGenerator var0 = new org.jfree.chart.urls.StandardXYURLGenerator();
    org.jfree.data.xy.XYDataset var1 = null;
    java.lang.String var4 = var0.generateURL(var1, 10, (-1));
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    var6.setRangeWithMargins(var9);
    var6.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var13 = var6.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var14 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    var17.setDomainZeroBaselineVisible(false);
    var14.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
    var14.setDefaultEntityRadius((-1));
    java.awt.Stroke var25 = null;
    var14.setSeriesStroke(1, var25);
    java.awt.Shape var28 = var14.lookupLegendShape(100);
    var6.setDownArrow(var28);
    boolean var30 = var0.equals((java.lang.Object)var6);
    java.lang.Class var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setAutoRangeTimePeriodClass(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "index.html?series=10&amp;item=-1"+ "'", var4.equals("index.html?series=10&amp;item=-1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test286"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    java.awt.Font var5 = null;
    org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, 10.0d, 10.0d, 1.0d, 100.0d, var5);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var7.setUseFillPaint(true);
    var7.setSeriesShapesFilled(5, (java.lang.Boolean)false);
    boolean var13 = var6.equals((java.lang.Object)false);
    java.lang.Object var14 = null;
    boolean var15 = var6.equals(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test287"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     double var2 = var1.getDomainCrosshairValue();
//     org.jfree.chart.plot.DefaultDrawingSupplier var4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     var6.setRangeWithMargins(var9);
//     var6.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var13 = var6.getPlot();
//     java.lang.Object var14 = var6.clone();
//     org.jfree.chart.JFreeChart var15 = null;
//     org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var15);
//     var6.setMinorTickCount(5);
//     boolean var19 = var4.equals((java.lang.Object)var6);
//     var1.setRangeAxis(520764324, (org.jfree.chart.axis.ValueAxis)var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test288"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.setCursor(0.05d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test289"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    var1.clear();
    java.util.List var5 = var1.getItems();
    var1.setDescription("Combined Range XYPlot");
    var1.removeAgedItems((-1L), false);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    java.awt.Paint var14 = var12.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
    var16.setRangeWithMargins(var19);
    var12.setDomainAxis((org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.data.time.RegularTimePeriod var22 = var16.getFirst();
    org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem(var22, 0.0d);
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
    org.jfree.chart.axis.AxisLocation var27 = var26.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var28 = org.jfree.chart.axis.AxisLocation.getOpposite(var27);
    boolean var29 = var24.equals((java.lang.Object)var27);
    java.lang.Object var30 = var24.clone();
    org.jfree.data.time.TimeSeriesDataItem var31 = var1.addOrUpdate(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test290"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var1 = var0.getRightArrow();
//     var0.zoomRange((-1.0d), 1.0d);
//     double var5 = var0.getLowerMargin();
//     org.jfree.data.Range var6 = var0.getRange();
//     java.util.Date var7 = var0.getMaximumDate();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var7);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var12 = var11.getTickMarkInsideLength();
//     int var13 = var11.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var16 = null;
//     org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 0.0d);
//     var15.setRangeWithMargins(var18);
//     var15.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var22 = var15.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var24 = var23.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
//     org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
//     var26.setDomainZeroBaselineVisible(false);
//     var23.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     var23.setDefaultEntityRadius((-1));
//     java.awt.Stroke var34 = null;
//     var23.setSeriesStroke(1, var34);
//     java.awt.Shape var37 = var23.lookupLegendShape(100);
//     var15.setDownArrow(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var11, (org.jfree.chart.axis.ValueAxis)var15, var39);
//     var40.setWeight((-123));
//     java.util.List var43 = var40.getCategories();
//     var40.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var46 = var9.hasListener((java.util.EventListener)var40);
//     java.util.TimeZone var47 = var9.getTimeZone();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day(var7, var47);
//     java.lang.String var49 = var48.toString();
//     long var50 = var48.getSerialIndex();
//     java.util.Calendar var51 = null;
//     long var52 = var48.getFirstMillisecond(var51);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test291"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearDomainAxes();
    org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var38 = var34.getItemOutlineStroke(0, 0, true);
    var30.setRangeGridlineStroke(var38);
    java.awt.Stroke var40 = var30.getRangeZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var41 = var30.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = var30.getRenderer(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test292"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.data.Range var15 = var0.findDomainBounds(var14);
    org.jfree.chart.labels.XYToolTipGenerator var17 = var0.getSeriesToolTipGenerator((-123));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test293"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
    java.awt.Paint var5 = var3.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var5);
    java.awt.Stroke var7 = var6.getOutlineStroke();
    org.jfree.chart.renderer.xy.XYBarRenderer var8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
    var12.setRangeWithMargins(var15);
    boolean var17 = var8.equals((java.lang.Object)var15);
    var8.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var21 = var8.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.chart.text.TextAnchor var22 = var21.getRotationAnchor();
    java.lang.String var23 = var22.toString();
    var6.setLabelTextAnchor(var22);
    var6.setStartValue((-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "TextAnchor.CENTER"+ "'", var23.equals("TextAnchor.CENTER"));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test294"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(0);
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot(var4);
    org.jfree.chart.event.PlotChangeEvent var6 = null;
    var5.plotChanged(var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var9 = new org.jfree.chart.plot.CombinedRangeXYPlot(var8);
    org.jfree.chart.plot.DrawingSupplier var10 = var9.getDrawingSupplier();
    java.awt.Paint var11 = var9.getRangeZeroBaselinePaint();
    var5.setRangeGridlinePaint(var11);
    org.jfree.chart.ChartRenderingInfo var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
    java.awt.geom.Rectangle2D var15 = var14.getDataArea();
    org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var15, "");
    org.jfree.chart.util.RectangleAnchor var18 = null;
    java.awt.geom.Point2D var19 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var18);
    var5.setQuadrantOrigin(var19);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    org.jfree.chart.util.RectangleInsets var22 = var21.getItemLabelPadding();
    org.jfree.chart.util.RectangleInsets var23 = var21.getItemLabelPadding();
    var0.set(5, (java.lang.Object)var23);
    double var26 = var23.calculateLeftOutset(18.0d);
    double var27 = var23.getRight();
    double var28 = var23.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 2.0d);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test295"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    org.jfree.chart.labels.CategoryToolTipGenerator var4 = null;
    var0.setBaseToolTipGenerator(var4, true);
    java.lang.Object var7 = null;
    boolean var8 = var0.equals(var7);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
    var0.setSeriesItemLabelGenerator(100, var12);
    boolean var14 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test296"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.axis.AxisSpace var2 = null;
//     var1.setFixedRangeAxisSpace(var2);
//     org.jfree.chart.LegendItemCollection var4 = var1.getLegendItems();
//     java.awt.geom.GeneralPath var5 = null;
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
//     java.awt.Paint var8 = var7.getPaint();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var10 = new org.jfree.chart.plot.CombinedRangeXYPlot(var9);
//     org.jfree.chart.plot.DrawingSupplier var11 = var10.getDrawingSupplier();
//     java.awt.Paint var12 = var10.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var13 = var10.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var14 = org.jfree.chart.util.RectangleEdge.opposite(var13);
//     var7.setPosition(var13);
//     org.jfree.chart.util.RectangleInsets var16 = var7.getPadding();
//     org.jfree.chart.event.TitleChangeEvent var17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var7);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D();
//     var19.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var22 = var19.getTickLabelInsets();
//     double var24 = var22.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Rectangle2D var27 = var26.getDataArea();
//     org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var27, "");
//     org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var27, "");
//     org.jfree.chart.util.LengthAdjustmentType var32 = null;
//     org.jfree.chart.util.LengthAdjustmentType var33 = null;
//     java.awt.geom.Rectangle2D var34 = var22.createAdjustedRectangle(var27, var32, var33);
//     var7.draw(var18, var34);
//     org.jfree.chart.RenderingSource var36 = null;
//     var1.select(var5, var34, var36);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test297"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0E12d);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test298"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    boolean var6 = var5.isNotify();
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    var7.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var10 = var7.getTickLabelInsets();
    double var12 = var10.extendHeight(10.0d);
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    var13.setLowerMargin((-1.0d));
    var13.setAxisLineVisible(false);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
    java.awt.geom.Rectangle2D var24 = var23.getDataArea();
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var26 = new org.jfree.chart.plot.CombinedRangeXYPlot(var25);
    org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
    java.awt.Paint var28 = var26.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var24, var28);
    java.awt.Font var30 = null;
    var29.setLabelFont(var30);
    java.awt.Shape var32 = var29.getLine();
    java.awt.Paint var33 = var29.getFillPaint();
    var13.setAxisLinePaint(var33);
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(var10, var33);
    var5.setBorderPaint(var33);
    var5.setTextAntiAlias(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test299"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ", "");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot(var5);
//     org.jfree.chart.plot.DrawingSupplier var7 = var6.getDrawingSupplier();
//     java.awt.Paint var8 = var6.getRangeZeroBaselinePaint();
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     var10.setRangeWithMargins(var13);
//     var6.setDomainAxis((org.jfree.chart.axis.ValueAxis)var10);
//     org.jfree.data.time.RegularTimePeriod var16 = var10.getFirst();
//     java.util.Date var17 = var16.getEnd();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var4.addOrUpdate(var16, (-1.0d));
//     boolean var20 = var0.equals((java.lang.Object)var16);
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var22 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var21, var22, (java.lang.Comparable)(byte)1);
//     var24.clear();
//     java.lang.String var26 = var24.getURLText();
//     java.lang.Comparable var27 = var24.getSeriesKey();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var33 = var31.toFixedHeight((-1.0d));
//     org.jfree.chart.util.Size2D var34 = var0.arrange((org.jfree.chart.block.BlockContainer)var24, var28, var33);
//     org.jfree.chart.util.RectangleInsets var35 = new org.jfree.chart.util.RectangleInsets();
//     double var37 = var35.calculateTopInset(0.2d);
//     boolean var38 = var0.equals((java.lang.Object)var37);
//     org.jfree.chart.block.FlowArrangement var39 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.data.general.Dataset var40 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var42 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var39, var40, (java.lang.Comparable)(byte)1);
//     var42.clear();
//     java.lang.String var44 = var42.getURLText();
//     java.lang.Comparable var45 = var42.getSeriesKey();
//     org.jfree.chart.block.CenterArrangement var46 = new org.jfree.chart.block.CenterArrangement();
//     var42.setArrangement((org.jfree.chart.block.Arrangement)var46);
//     java.awt.Graphics2D var48 = null;
//     org.jfree.data.Range var50 = null;
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var55 = var53.toFixedHeight((-1.0d));
//     org.jfree.chart.block.LengthConstraintType var56 = var53.getWidthConstraintType();
//     org.jfree.chart.axis.PeriodAxis var59 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var60 = null;
//     org.jfree.data.Range var62 = org.jfree.data.Range.expandToInclude(var60, 0.0d);
//     var59.setRangeWithMargins(var62);
//     var59.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var66 = var59.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var67 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var68 = var67.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var70 = new org.jfree.chart.plot.CombinedRangeXYPlot(var69);
//     org.jfree.chart.plot.DrawingSupplier var71 = var70.getDrawingSupplier();
//     var70.setDomainZeroBaselineVisible(false);
//     var67.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var70);
//     var67.setDefaultEntityRadius((-1));
//     java.awt.Stroke var78 = null;
//     var67.setSeriesStroke(1, var78);
//     java.awt.Shape var81 = var67.lookupLegendShape(100);
//     var59.setDownArrow(var81);
//     org.jfree.chart.axis.PeriodAxis var84 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var85 = null;
//     org.jfree.data.Range var87 = org.jfree.data.Range.expandToInclude(var85, 0.0d);
//     var84.setRangeWithMargins(var87);
//     var59.setRangeWithMargins(var87);
//     org.jfree.chart.block.RectangleConstraint var92 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var94 = var92.toFixedHeight((-1.0d));
//     org.jfree.chart.block.LengthConstraintType var95 = var92.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var96 = new org.jfree.chart.block.RectangleConstraint(0.05d, var50, var56, 1.0E12d, var87, var95);
//     org.jfree.chart.util.Size2D var97 = var0.arrange((org.jfree.chart.block.BlockContainer)var42, var48, var96);
//     
//     // Checks the contract:  equals-hashcode on var7 and var71
//     assertTrue("Contract failed: equals-hashcode on var7 and var71", var7.equals(var71) ? var7.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var7
//     assertTrue("Contract failed: equals-hashcode on var71 and var7", var71.equals(var7) ? var71.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var39
//     assertTrue("Contract failed: equals-hashcode on var21 and var39", var21.equals(var39) ? var21.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var21
//     assertTrue("Contract failed: equals-hashcode on var39 and var21", var39.equals(var21) ? var39.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test300"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    var30.clearDomainAxes();
    org.jfree.chart.renderer.xy.XYBarRenderer var34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var38 = var34.getItemOutlineStroke(0, 0, true);
    var30.setRangeGridlineStroke(var38);
    org.jfree.chart.axis.ValueAxis var41 = var30.getRangeAxisForDataset(10);
    var30.setDomainCrosshairColumnKey((java.lang.Comparable)"-2");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test301"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
//     var0.setSeriesItemLabelGenerator(100, var2);
//     java.awt.Paint var4 = var0.getBaseLegendTextPaint();
//     java.awt.Paint var6 = var0.getSeriesItemLabelPaint(1);
//     java.lang.Boolean var8 = var0.getSeriesVisible(2147483647);
//     org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.time.TimeSeriesCollection var10 = new org.jfree.data.time.TimeSeriesCollection();
//     var9.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var10);
//     var10.removeAllSeries();
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot(var13);
//     org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
//     float var16 = var14.getForegroundAlpha();
//     var10.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var14);
//     org.jfree.data.xy.XYDatasetSelectionState var18 = var10.getSelectionState();
//     org.jfree.data.Range var20 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var10, false);
//     org.jfree.data.Range var21 = var0.findRangeBounds((org.jfree.data.xy.XYDataset)var10);
//     
//     // Checks the contract:  equals-hashcode on var9 and var10
//     assertTrue("Contract failed: equals-hashcode on var9 and var10", var9.equals(var10) ? var9.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var9
//     assertTrue("Contract failed: equals-hashcode on var10 and var9", var10.equals(var9) ? var10.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test302"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, var1, (java.lang.Comparable)(byte)1);
    var3.clear();
    java.lang.String var5 = var3.getURLText();
    boolean var6 = var3.isEmpty();
    boolean var7 = var3.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test303"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    org.jfree.chart.labels.CategoryToolTipGenerator var4 = null;
    var0.setBaseToolTipGenerator(var4, true);
    java.lang.Object var7 = null;
    boolean var8 = var0.equals(var7);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D();
    var15.setLowerMargin((-1.0d));
    var15.setAxisLineVisible(false);
    org.jfree.chart.ChartRenderingInfo var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
    java.awt.geom.Rectangle2D var26 = var25.getDataArea();
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot(var27);
    org.jfree.chart.plot.DrawingSupplier var29 = var28.getDrawingSupplier();
    java.awt.Paint var30 = var28.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var26, var30);
    java.awt.Font var32 = null;
    var31.setLabelFont(var32);
    java.awt.Shape var34 = var31.getLine();
    java.awt.Paint var35 = var31.getFillPaint();
    var15.setAxisLinePaint(var35);
    org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(0.05d, 1.0d, 2.88E7d, 0.0d, var35);
    var0.setWallPaint(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test304"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     boolean var12 = var1.isDomainPannable();
//     var1.clearRangeMarkers();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var21.setDomainDescription("");
//     var21.clear();
//     java.util.List var25 = var21.getItems();
//     var1.drawDomainTickBands(var14, var17, var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, 0.0d, 1.0d);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
//     var30.setUseFillPaint(true);
//     var30.setSeriesShapesFilled(5, (java.lang.Boolean)false);
//     java.awt.Paint var36 = var30.getBaseFillPaint();
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var17, var36);
//     var37.setShapeOutlineVisible(true);
//     var37.setShapeVisible(true);
//     org.jfree.chart.util.RectangleInsets var42 = var37.getMargin();
//     org.jfree.chart.util.StandardGradientPaintTransformer var43 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.renderer.xy.XYBarRenderer var44 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.XYItemLabelGenerator var46 = null;
//     var44.setSeriesItemLabelGenerator(100, var46);
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
//     java.awt.geom.Rectangle2D var55 = var54.getDataArea();
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var57 = new org.jfree.chart.plot.CombinedRangeXYPlot(var56);
//     org.jfree.chart.plot.DrawingSupplier var58 = var57.getDrawingSupplier();
//     java.awt.Paint var59 = var57.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var55, var59);
//     var44.setSeriesItemLabelPaint(1, var59, false);
//     java.awt.Paint var64 = var44.getSeriesFillPaint((-123));
//     org.jfree.chart.labels.XYItemLabelGenerator var68 = var44.getItemLabelGenerator(0, 0, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var69 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var71 = var69.getSeriesPositiveItemLabelPosition(0);
//     var44.setBaseNegativeItemLabelPosition(var71);
//     boolean var73 = var43.equals((java.lang.Object)var44);
//     var37.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var43);
//     
//     // Checks the contract:  equals-hashcode on var7 and var57
//     assertTrue("Contract failed: equals-hashcode on var7 and var57", var7.equals(var57) ? var7.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var7
//     assertTrue("Contract failed: equals-hashcode on var57 and var7", var57.equals(var7) ? var57.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var58
//     assertTrue("Contract failed: equals-hashcode on var2 and var58", var2.equals(var58) ? var2.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var2
//     assertTrue("Contract failed: equals-hashcode on var58 and var2", var58.equals(var2) ? var58.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var54
//     assertTrue("Contract failed: equals-hashcode on var16 and var54", var16.equals(var54) ? var16.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var16
//     assertTrue("Contract failed: equals-hashcode on var54 and var16", var54.equals(var16) ? var54.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test305"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 5, 0);
    org.jfree.chart.axis.SegmentedTimeline.Segment var5 = var3.getSegment(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test306"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var2 = var1.getTickMarkInsideLength();
//     int var3 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
//     org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
//     var16.setDomainZeroBaselineVisible(false);
//     var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     var13.setDefaultEntityRadius((-1));
//     java.awt.Stroke var24 = null;
//     var13.setSeriesStroke(1, var24);
//     java.awt.Shape var27 = var13.lookupLegendShape(100);
//     var5.setDownArrow(var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
//     var30.setWeight((-123));
//     java.util.List var33 = var30.getCategories();
//     var30.clearDomainMarkers();
//     org.jfree.chart.ChartRenderingInfo var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = new org.jfree.chart.plot.PlotRenderingInfo(var39);
//     java.awt.geom.Rectangle2D var41 = var40.getDataArea();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot(var42);
//     org.jfree.chart.plot.DrawingSupplier var44 = var43.getDrawingSupplier();
//     java.awt.Paint var45 = var43.getRangeZeroBaselinePaint();
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("", "", "", "", (java.awt.Shape)var41, var45);
//     java.awt.Font var47 = null;
//     var46.setLabelFont(var47);
//     java.awt.Shape var49 = var46.getLine();
//     java.awt.Paint var50 = var46.getFillPaint();
//     java.awt.Stroke var51 = var46.getLineStroke();
//     var30.setDomainGridlineStroke(var51);
//     
//     // Checks the contract:  equals-hashcode on var16 and var43
//     assertTrue("Contract failed: equals-hashcode on var16 and var43", var16.equals(var43) ? var16.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var16
//     assertTrue("Contract failed: equals-hashcode on var43 and var16", var43.equals(var16) ? var43.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var44
//     assertTrue("Contract failed: equals-hashcode on var17 and var44", var17.equals(var44) ? var17.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var17
//     assertTrue("Contract failed: equals-hashcode on var44 and var17", var44.equals(var17) ? var44.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test307"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     java.lang.Object var5 = var1.clone();
//     org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
//     boolean var8 = var1.canSelectByRegion();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
//     var12.setDomainZeroBaselineVisible(false);
//     java.lang.Object var16 = var12.clone();
//     org.jfree.data.xy.XYDataset var18 = var12.getDataset(0);
//     boolean var19 = var12.canSelectByRegion();
//     org.jfree.chart.plot.PlotOrientation var20 = var12.getOrientation();
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
//     var25.setLowerMargin((-1.0d));
//     org.jfree.chart.util.RectangleInsets var28 = var25.getTickLabelInsets();
//     double var30 = var28.extendHeight(10.0d);
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var33, "");
//     org.jfree.chart.entity.ChartEntity var37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var33, "");
//     org.jfree.chart.util.LengthAdjustmentType var38 = null;
//     org.jfree.chart.util.LengthAdjustmentType var39 = null;
//     java.awt.geom.Rectangle2D var40 = var28.createAdjustedRectangle(var33, var38, var39);
//     var24.setPlotArea(var33);
//     org.jfree.chart.renderer.RendererState var42 = new org.jfree.chart.renderer.RendererState(var24);
//     var12.handleClick(15, (-1), var24);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot(var44);
//     org.jfree.chart.event.PlotChangeEvent var46 = null;
//     var45.plotChanged(var46);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var49 = new org.jfree.chart.plot.CombinedRangeXYPlot(var48);
//     org.jfree.chart.plot.DrawingSupplier var50 = var49.getDrawingSupplier();
//     java.awt.Paint var51 = var49.getRangeZeroBaselinePaint();
//     var45.setRangeGridlinePaint(var51);
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
//     java.awt.geom.Rectangle2D var55 = var54.getDataArea();
//     org.jfree.chart.entity.ChartEntity var57 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var55, "");
//     org.jfree.chart.util.RectangleAnchor var58 = null;
//     java.awt.geom.Point2D var59 = org.jfree.chart.util.RectangleAnchor.coordinates(var55, var58);
//     var45.setQuadrantOrigin(var59);
//     var1.zoomDomainAxes(5.0d, 6.0d, var24, var59);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var49
//     assertTrue("Contract failed: equals-hashcode on var1 and var49", var1.equals(var49) ? var1.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var49
//     assertTrue("Contract failed: equals-hashcode on var12 and var49", var12.equals(var49) ? var12.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var1
//     assertTrue("Contract failed: equals-hashcode on var49 and var1", var49.equals(var1) ? var49.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var12
//     assertTrue("Contract failed: equals-hashcode on var49 and var12", var49.equals(var12) ? var49.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var50
//     assertTrue("Contract failed: equals-hashcode on var2 and var50", var2.equals(var50) ? var2.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var50
//     assertTrue("Contract failed: equals-hashcode on var13 and var50", var13.equals(var50) ? var13.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var2
//     assertTrue("Contract failed: equals-hashcode on var50 and var2", var50.equals(var2) ? var50.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var13
//     assertTrue("Contract failed: equals-hashcode on var50 and var13", var50.equals(var13) ? var50.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var16
//     assertTrue("Contract failed: equals-hashcode on var5 and var16", var5.equals(var16) ? var5.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var5
//     assertTrue("Contract failed: equals-hashcode on var16 and var5", var16.equals(var5) ? var16.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var54
//     assertTrue("Contract failed: equals-hashcode on var32 and var54", var32.equals(var54) ? var32.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var32
//     assertTrue("Contract failed: equals-hashcode on var54 and var32", var54.equals(var32) ? var54.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test308"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    java.awt.Shape var3 = var0.getBaseLegendShape();
    var0.setSeriesVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("SerialDate.weekInMonthToString(): invalid code.");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var8);
    org.jfree.chart.urls.StandardXYURLGenerator var14 = new org.jfree.chart.urls.StandardXYURLGenerator("[size=1]", "hi!", "0,0,1,1");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator(2147483647, (org.jfree.chart.urls.XYURLGenerator)var14, true);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test309"); }


    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var4 = var3.getDomainAxisLocation();
    java.awt.Paint var5 = var3.getDomainCrosshairPaint();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var5);
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.util.GradientPaintTransformer var9 = var8.getFillPaintTransformer();
    var6.setGradientPaintTransformer(var9);
    float var11 = var6.getAlpha();
    java.awt.Paint var12 = var6.getOutlinePaint();
    org.jfree.chart.util.LengthAdjustmentType var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLabelOffsetType(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test310"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    var1.clear();
    java.util.List var5 = var1.getItems();
    var1.setDescription("Combined Range XYPlot");
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var9.setDomainDescription("");
    java.util.Collection var12 = var1.getTimePeriodsUniqueToOtherSeries(var9);
    org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection();
    var13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var14);
    var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var13);
    java.lang.Object var17 = var13.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test311"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    java.util.List var33 = var30.getCategories();
    org.jfree.data.category.CategoryDataset var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var30.getRendererForDataset(var34);
    java.awt.Paint var36 = var30.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test312"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var1.setDomainDescription("");
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Shape var5 = var4.getRightArrow();
//     var4.zoomRange((-1.0d), 1.0d);
//     double var9 = var4.getLowerMargin();
//     org.jfree.data.Range var10 = var4.getRange();
//     java.util.Date var11 = var4.getMaximumDate();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var11);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D();
//     float var16 = var15.getTickMarkInsideLength();
//     int var17 = var15.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var20 = null;
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var20, 0.0d);
//     var19.setRangeWithMargins(var22);
//     var19.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var26 = var19.getPlot();
//     org.jfree.chart.renderer.xy.XYBarRenderer var27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var28 = var27.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot(var29);
//     org.jfree.chart.plot.DrawingSupplier var31 = var30.getDrawingSupplier();
//     var30.setDomainZeroBaselineVisible(false);
//     var27.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var30);
//     var27.setDefaultEntityRadius((-1));
//     java.awt.Stroke var38 = null;
//     var27.setSeriesStroke(1, var38);
//     java.awt.Shape var41 = var27.lookupLegendShape(100);
//     var19.setDownArrow(var41);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var14, (org.jfree.chart.axis.CategoryAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var43);
//     var44.setWeight((-123));
//     java.util.List var47 = var44.getCategories();
//     var44.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
//     boolean var50 = var13.hasListener((java.util.EventListener)var44);
//     java.util.TimeZone var51 = var13.getTimeZone();
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day(var11, var51);
//     java.lang.String var53 = var52.toString();
//     var1.add((org.jfree.data.time.RegularTimePeriod)var52, (java.lang.Number)10L, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "31-December-1969"+ "'", var53.equals("31-December-1969"));
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test313"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("ThreadContext");
    var1.resizeRange2(2.88E7d, 4.0d);
    var1.configure();
    var1.setVerticalTickLabels(false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test314"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test315"); }


    float[] var6 = new float[] { 0.0f, 0.0f, 100.0f};
    float[] var7 = java.awt.Color.RGBtoHSB(0, 3, 5, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test316"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    var1.setRangeWithMargins(var4);
    var1.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var8 = var1.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var10 = var9.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot(var11);
    org.jfree.chart.plot.DrawingSupplier var13 = var12.getDrawingSupplier();
    var12.setDomainZeroBaselineVisible(false);
    var9.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    var9.setDefaultEntityRadius((-1));
    java.awt.Stroke var20 = null;
    var9.setSeriesStroke(1, var20);
    java.awt.Shape var23 = var9.lookupLegendShape(100);
    var1.setDownArrow(var23);
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var27 = null;
    org.jfree.data.Range var29 = org.jfree.data.Range.expandToInclude(var27, 0.0d);
    var26.setRangeWithMargins(var29);
    var1.setRangeWithMargins(var29);
    var1.setAutoTickUnitSelection(false, false);
    org.jfree.chart.util.RectangleInsets var35 = var1.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test317"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = var0.getRightArrow();
    var0.zoomRange((-1.0d), 1.0d);
    double var5 = var0.getLowerMargin();
    org.jfree.chart.axis.Timeline var6 = var0.getTimeline();
    java.util.TimeZone var7 = var0.getTimeZone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test318"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    var1.setDomainZeroBaselineVisible(false);
    java.lang.Object var5 = var1.clone();
    org.jfree.data.xy.XYDataset var7 = var1.getDataset(0);
    boolean var8 = var1.canSelectByRegion();
    org.jfree.chart.plot.PlotOrientation var9 = var1.getOrientation();
    org.jfree.chart.ChartRenderingInfo var12 = null;
    org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    var14.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var17 = var14.getTickLabelInsets();
    double var19 = var17.extendHeight(10.0d);
    org.jfree.chart.ChartRenderingInfo var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
    java.awt.geom.Rectangle2D var22 = var21.getDataArea();
    org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var22, "");
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var22, "");
    org.jfree.chart.util.LengthAdjustmentType var27 = null;
    org.jfree.chart.util.LengthAdjustmentType var28 = null;
    java.awt.geom.Rectangle2D var29 = var17.createAdjustedRectangle(var22, var27, var28);
    var13.setPlotArea(var22);
    org.jfree.chart.renderer.RendererState var31 = new org.jfree.chart.renderer.RendererState(var13);
    var1.handleClick(15, (-1), var13);
    org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection();
    var33.removeAllSeries();
    int var35 = var1.indexOf((org.jfree.data.xy.XYDataset)var33);
    org.jfree.chart.axis.ValueAxis var36 = var1.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test319"); }


    org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.chart.text.TextFragment var4 = var3.getLastTextFragment();
    java.awt.Font var5 = var4.getFont();
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var7.getDrawingSupplier();
    java.awt.Paint var9 = var7.getRangeZeroBaselinePaint();
    java.awt.Paint var10 = null;
    boolean var11 = org.jfree.chart.util.PaintUtilities.equal(var9, var10);
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("TextAnchor.CENTER", var5, var9);
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var18 = null;
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 0.0d);
    var17.setRangeWithMargins(var20);
    boolean var22 = var13.equals((java.lang.Object)var20);
    var13.setBaseItemLabelsVisible(false);
    var13.setBase(2.88E7d);
    org.jfree.chart.urls.XYURLGenerator var30 = var13.getURLGenerator(100, 0, false);
    java.awt.Paint var31 = var13.getBaseItemLabelPaint();
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var33 = new org.jfree.chart.plot.CombinedRangeXYPlot(var32);
    org.jfree.chart.plot.DrawingSupplier var34 = var33.getDrawingSupplier();
    java.awt.Paint var35 = var33.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var36 = var33.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var37 = org.jfree.chart.util.RectangleEdge.opposite(var36);
    boolean var39 = var36.equals((java.lang.Object)true);
    java.awt.Font var41 = null;
    java.awt.Paint var42 = null;
    org.jfree.chart.text.TextMeasurer var44 = null;
    org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var41, var42, 10.0f, var44);
    java.awt.Graphics2D var46 = null;
    org.jfree.chart.util.Size2D var47 = var45.calculateDimensions(var46);
    org.jfree.chart.renderer.xy.XYBarRenderer var48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var50 = var48.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var52 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var53 = null;
    org.jfree.data.Range var55 = org.jfree.data.Range.expandToInclude(var53, 0.0d);
    var52.setRangeWithMargins(var55);
    boolean var57 = var48.equals((java.lang.Object)var55);
    java.awt.Stroke var59 = var48.getSeriesOutlineStroke((-123));
    boolean var60 = var45.equals((java.lang.Object)var48);
    org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var63 = var62.getPaint();
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var65 = new org.jfree.chart.plot.CombinedRangeXYPlot(var64);
    org.jfree.chart.plot.DrawingSupplier var66 = var65.getDrawingSupplier();
    java.awt.Paint var67 = var65.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var68 = var65.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var69 = org.jfree.chart.util.RectangleEdge.opposite(var68);
    var62.setPosition(var68);
    org.jfree.chart.util.RectangleInsets var71 = var62.getPadding();
    org.jfree.chart.event.TitleChangeEvent var72 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var62);
    java.lang.String var73 = var62.getText();
    java.lang.String var74 = var62.getText();
    org.jfree.chart.util.HorizontalAlignment var75 = var62.getTextAlignment();
    org.jfree.chart.util.VerticalAlignment var76 = null;
    org.jfree.chart.block.FlowArrangement var79 = new org.jfree.chart.block.FlowArrangement(var75, var76, Double.NaN, 0.0d);
    var45.setLineAlignment(var75);
    org.jfree.chart.util.VerticalAlignment var81 = null;
    org.jfree.chart.axis.CategoryAxis3D var82 = new org.jfree.chart.axis.CategoryAxis3D();
    var82.setLowerMargin((-1.0d));
    org.jfree.chart.util.RectangleInsets var85 = var82.getTickLabelInsets();
    double var87 = var85.extendHeight(10.0d);
    org.jfree.chart.ChartRenderingInfo var88 = null;
    org.jfree.chart.plot.PlotRenderingInfo var89 = new org.jfree.chart.plot.PlotRenderingInfo(var88);
    java.awt.geom.Rectangle2D var90 = var89.getDataArea();
    org.jfree.chart.entity.ChartEntity var92 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var90, "");
    org.jfree.chart.entity.ChartEntity var94 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var90, "");
    org.jfree.chart.util.LengthAdjustmentType var95 = null;
    org.jfree.chart.util.LengthAdjustmentType var96 = null;
    java.awt.geom.Rectangle2D var97 = var85.createAdjustedRectangle(var90, var95, var96);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var98 = new org.jfree.chart.title.TextTitle("RectangleAnchor.TOP_LEFT", var5, var31, var36, var75, var81, var85);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var73 + "' != '" + "ChartEntity: tooltip = "+ "'", var73.equals("ChartEntity: tooltip = "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + "ChartEntity: tooltip = "+ "'", var74.equals("ChartEntity: tooltip = "));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 14.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test320"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    boolean var1 = var0.isRangeZoomable();
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var3 = new org.jfree.chart.plot.CombinedRangeXYPlot(var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var3.getDrawingSupplier();
    java.lang.Object var5 = var3.clone();
    boolean var6 = var0.equals(var5);
    org.jfree.chart.plot.PlotOrientation var7 = var0.getOrientation();
    boolean var8 = var0.isAngleLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test321"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.axis.AxisSpace var2 = null;
//     var1.setFixedRangeAxisSpace(var2);
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     var5.setRangeWithMargins(var8);
//     var5.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.Plot var12 = var5.getPlot();
//     double var13 = var5.getUpperBound();
//     int var14 = var1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var5);
//     boolean var15 = var1.isRangeZoomable();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2.88E7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test322"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    java.awt.Stroke var1 = var0.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test323"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    var4.setRangeWithMargins(var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    var0.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
    java.lang.String var15 = var14.toString();
    boolean var17 = var14.equals((java.lang.Object)"{0}: ({1}, {2})");
    java.lang.String var18 = var14.toString();
    java.lang.String var19 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "TextAnchor.CENTER"+ "'", var15.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "TextAnchor.CENTER"+ "'", var18.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "TextAnchor.CENTER"+ "'", var19.equals("TextAnchor.CENTER"));

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test324"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.XYItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(100, var2);
    java.awt.Paint var4 = var0.getBaseLegendTextPaint();
    org.jfree.chart.labels.XYToolTipGenerator var5 = var0.getBaseToolTipGenerator();
    org.jfree.chart.urls.XYURLGenerator var9 = var0.getURLGenerator(100, (-1), true);
    java.awt.Paint var13 = var0.getItemPaint(0, 10, true);
    boolean var14 = var0.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test325"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    float var2 = var1.getTickMarkInsideLength();
    int var3 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var5.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var12 = var5.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var13 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var14 = var13.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var16 = new org.jfree.chart.plot.CombinedRangeXYPlot(var15);
    org.jfree.chart.plot.DrawingSupplier var17 = var16.getDrawingSupplier();
    var16.setDomainZeroBaselineVisible(false);
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    var13.setDefaultEntityRadius((-1));
    java.awt.Stroke var24 = null;
    var13.setSeriesStroke(1, var24);
    java.awt.Shape var27 = var13.lookupLegendShape(100);
    var5.setDownArrow(var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var29);
    var30.setWeight((-123));
    org.jfree.chart.ChartRenderingInfo var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
    java.awt.geom.Rectangle2D var36 = var35.getDataArea();
    java.awt.geom.Point2D var37 = null;
    var30.panDomainAxes(100.0d, var35, var37);
    java.awt.Stroke var39 = var30.getRangeMinorGridlineStroke();
    org.jfree.chart.LegendItemCollection var40 = var30.getFixedLegendItems();
    org.jfree.chart.axis.ValueAxis var42 = var30.getRangeAxis(1);
    java.awt.Paint var43 = var30.getRangeMinorGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test326"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    var0.setUseFillPaint(true);
    java.awt.Stroke var4 = var0.lookupSeriesOutlineStroke(5);
    boolean var7 = var0.getItemShapeVisible(520764324, 15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test327"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    var5.setRangeWithMargins(var8);
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var5);
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    var1.setDomainAxis((org.jfree.chart.axis.ValueAxis)var12);
    var12.setNegativeArrowVisible(true);
    java.awt.Shape var16 = var12.getUpArrow();
    org.jfree.data.time.RegularTimePeriod var17 = var12.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test328"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     var1.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var7 = new org.jfree.chart.plot.CombinedRangeXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var8 = var7.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var9 = org.jfree.chart.axis.AxisLocation.getOpposite(var8);
//     var1.setRangeAxisLocation(0, var9, true);
//     boolean var12 = var1.isDomainPannable();
//     var1.clearRangeMarkers();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var17, "");
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     var21.setDomainDescription("");
//     var21.clear();
//     java.util.List var25 = var21.getItems();
//     var1.drawDomainTickBands(var14, var17, var25);
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, 0.0d, 1.0d);
//     org.jfree.chart.renderer.xy.XYBarRenderer var30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var34 = var30.getItemOutlineStroke(0, 0, true);
//     org.jfree.chart.labels.StandardPieToolTipGenerator var36 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
//     java.text.NumberFormat var37 = var36.getNumberFormat();
//     java.text.DateFormat var38 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var39 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var37, var38);
//     var30.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var39, false);
//     java.text.NumberFormat var44 = java.text.NumberFormat.getCurrencyInstance();
//     java.text.NumberFormat var45 = java.text.NumberFormat.getCurrencyInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var46 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", var44, var45);
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.renderer.xy.XYBarRenderer var49 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.awt.Stroke var53 = var49.getItemOutlineStroke(0, 0, true);
//     org.jfree.chart.urls.StandardXYURLGenerator var55 = new org.jfree.chart.urls.StandardXYURLGenerator();
//     var49.setSeriesURLGenerator(5, (org.jfree.chart.urls.XYURLGenerator)var55);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var57 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1), (org.jfree.chart.labels.XYToolTipGenerator)var46, (org.jfree.chart.urls.XYURLGenerator)var55);
//     var30.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var55, true);
//     org.jfree.chart.renderer.xy.XYBarRenderer var60 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     var60.setBaseItemLabelsVisible(true, true);
//     org.jfree.data.time.TimeSeriesCollection var64 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.data.Range var66 = var64.getDomainBounds(false);
//     org.jfree.data.Range var67 = var60.findRangeBounds((org.jfree.data.xy.XYDataset)var64);
//     org.jfree.data.Range var68 = var30.findRangeBounds((org.jfree.data.xy.XYDataset)var64);
//     org.jfree.chart.entity.XYItemEntity var73 = new org.jfree.chart.entity.XYItemEntity((java.awt.Shape)var17, (org.jfree.data.xy.XYDataset)var64, 4, 100, "PlotOrientation.VERTICAL", "Other");
//     org.jfree.data.general.DatasetGroup var75 = new org.jfree.data.general.DatasetGroup("14");
//     org.jfree.chart.renderer.xy.XYBarRenderer var76 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.urls.XYURLGenerator var77 = var76.getBaseURLGenerator();
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var79 = new org.jfree.chart.plot.CombinedRangeXYPlot(var78);
//     org.jfree.chart.plot.DrawingSupplier var80 = var79.getDrawingSupplier();
//     var79.setDomainZeroBaselineVisible(false);
//     var76.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var79);
//     var76.setDefaultEntityRadius((-1));
//     java.awt.Stroke var87 = null;
//     var76.setSeriesStroke(1, var87);
//     java.awt.Shape var90 = var76.lookupLegendShape(100);
//     org.jfree.chart.labels.XYItemLabelGenerator var92 = var76.getSeriesItemLabelGenerator(0);
//     boolean var93 = var75.equals((java.lang.Object)var76);
//     var64.setGroup(var75);
//     
//     // Checks the contract:  equals-hashcode on var7 and var79
//     assertTrue("Contract failed: equals-hashcode on var7 and var79", var7.equals(var79) ? var7.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var7
//     assertTrue("Contract failed: equals-hashcode on var79 and var7", var79.equals(var7) ? var79.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var80
//     assertTrue("Contract failed: equals-hashcode on var2 and var80", var2.equals(var80) ? var2.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var2
//     assertTrue("Contract failed: equals-hashcode on var80 and var2", var80.equals(var2) ? var80.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test329"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesPositiveItemLabelPosition(0);
    java.awt.Shape var4 = var1.getBaseLegendShape();
    var1.setSeriesVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("SerialDate.weekInMonthToString(): invalid code.");
    var1.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var9);
    org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
    float var13 = var12.getTickMarkInsideLength();
    boolean var14 = var12.isTickLabelsVisible();
    java.awt.Paint var16 = var12.getTickLabelPaint((java.lang.Comparable)"hi!");
    var1.setSeriesFillPaint(0, var16, false);
    var0.setBaseLegendTextPaint(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest2.test330"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
//     org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
//     var4.setRangeWithMargins(var7);
//     var4.setNegativeArrowVisible(false);
//     var4.setLabelURL("hi!");
//     org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var4};
//     var1.setRangeAxes(var13);
//     org.jfree.chart.util.RectangleEdge var15 = var1.getRangeAxisEdge();
//     java.awt.Stroke var16 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var19 = new org.jfree.chart.plot.CombinedRangeXYPlot(var18);
//     org.jfree.chart.plot.DrawingSupplier var20 = var19.getDrawingSupplier();
//     var19.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.CombinedRangeXYPlot var25 = new org.jfree.chart.plot.CombinedRangeXYPlot(var24);
//     org.jfree.chart.axis.AxisLocation var26 = var25.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var27 = org.jfree.chart.axis.AxisLocation.getOpposite(var26);
//     var19.setRangeAxisLocation(0, var27, true);
//     var1.setRangeAxisLocation(520764324, var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test331"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setVersion("[size=1]");

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test332"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    java.awt.Font var1 = var0.getBaseItemLabelFont();
    var0.setStepPoint(0.0d);
    var0.setBaseShapesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test333"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = null;
    var0.setSeriesURLGenerator(4, var2);
    org.jfree.chart.labels.CategoryToolTipGenerator var4 = null;
    var0.setBaseToolTipGenerator(var4, true);
    double var7 = var0.getXOffset();
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = null;
    var0.setSeriesToolTipGenerator(100, var9, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 12.0d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test334"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.axis.AxisSpace var2 = null;
    var1.setFixedRangeAxisSpace(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var5 = var1.getRangeAxisForDataset(520764324);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test335"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.Comparable var2 = var1.getAggregatedItemsKey();
    java.lang.Object var3 = var1.clone();
    double var4 = var1.getLimit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Other"+ "'", var2.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test336"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.awt.Stroke var8 = var4.getItemOutlineStroke(0, 0, true);
    var0.setSectionOutlineStroke((java.lang.Comparable)4.0d, var8);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
    java.awt.Paint var12 = var11.getPaint();
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var14 = new org.jfree.chart.plot.CombinedRangeXYPlot(var13);
    org.jfree.chart.plot.DrawingSupplier var15 = var14.getDrawingSupplier();
    java.awt.Paint var16 = var14.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var17 = var14.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var18 = org.jfree.chart.util.RectangleEdge.opposite(var17);
    var11.setPosition(var17);
    org.jfree.chart.util.RectangleInsets var20 = var11.getPadding();
    double var22 = var20.trimWidth(0.0d);
    var0.setLabelPadding(var20);
    double var24 = var0.getShadowXOffset();
    org.jfree.chart.labels.StandardPieToolTipGenerator var25 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    java.text.NumberFormat var26 = var25.getPercentFormat();
    java.lang.String var27 = var25.getLabelFormat();
    var0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator)var25);
    var0.setCircular(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "{0}: ({1}, {2})"+ "'", var27.equals("{0}: ({1}, {2})"));

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test337"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var1 = new org.jfree.chart.plot.CombinedRangeXYPlot(var0);
    org.jfree.chart.plot.DrawingSupplier var2 = var1.getDrawingSupplier();
    java.awt.Paint var3 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var1.getDomainAxisEdge();
    org.jfree.chart.axis.AxisSpace var5 = var1.getFixedRangeAxisSpace();
    var1.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.ValueAxis var8 = var1.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test338"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    boolean var1 = var0.isRangeZoomable();
    java.lang.Object var2 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test339"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    var1.setDomainDescription("");
    java.lang.Class var4 = null;
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var6 = var5.getRightArrow();
    var5.zoomRange((-1.0d), 1.0d);
    double var10 = var5.getLowerMargin();
    org.jfree.data.Range var11 = var5.getRange();
    java.util.Date var12 = var5.getMaximumDate();
    org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var12);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
    float var17 = var16.getTickMarkInsideLength();
    int var18 = var16.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var21 = null;
    org.jfree.data.Range var23 = org.jfree.data.Range.expandToInclude(var21, 0.0d);
    var20.setRangeWithMargins(var23);
    var20.setNegativeArrowVisible(false);
    org.jfree.chart.plot.Plot var27 = var20.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.urls.XYURLGenerator var29 = var28.getBaseURLGenerator();
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var31 = new org.jfree.chart.plot.CombinedRangeXYPlot(var30);
    org.jfree.chart.plot.DrawingSupplier var32 = var31.getDrawingSupplier();
    var31.setDomainZeroBaselineVisible(false);
    var28.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var31);
    var28.setDefaultEntityRadius((-1));
    java.awt.Stroke var39 = null;
    var28.setSeriesStroke(1, var39);
    java.awt.Shape var42 = var28.lookupLegendShape(100);
    var20.setDownArrow(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var15, (org.jfree.chart.axis.CategoryAxis)var16, (org.jfree.chart.axis.ValueAxis)var20, var44);
    var45.setWeight((-123));
    java.util.List var48 = var45.getCategories();
    var45.setDomainCrosshairColumnKey((java.lang.Comparable)100.0d);
    boolean var51 = var14.hasListener((java.util.EventListener)var45);
    java.util.TimeZone var52 = var14.getTimeZone();
    org.jfree.data.time.RegularTimePeriod var53 = org.jfree.data.time.RegularTimePeriod.createInstance(var4, var12, var52);
    org.jfree.data.time.TimeSeriesCollection var54 = new org.jfree.data.time.TimeSeriesCollection(var1, var52);
    org.jfree.data.time.Year var56 = new org.jfree.data.time.Year(100);
    java.lang.Number var57 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest2.test340"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieToolTipGenerator var2 = var0.getToolTipGenerator();
    org.jfree.chart.urls.PieURLGenerator var3 = null;
    var0.setLegendLabelURLGenerator(var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var6 = var5.getPlot();
    org.jfree.chart.title.LegendTitle var8 = var5.getLegend(5);
    java.lang.Object var9 = var5.getTextAntiAlias();
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot(var10);
    org.jfree.chart.event.PlotChangeEvent var12 = null;
    var11.plotChanged(var12);
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.plot.CombinedRangeXYPlot var15 = new org.jfree.chart.plot.CombinedRangeXYPlot(var14);
    org.jfree.chart.plot.DrawingSupplier var16 = var15.getDrawingSupplier();
    java.awt.Paint var17 = var15.getRangeZeroBaselinePaint();
    var11.setRangeGridlinePaint(var17);
    org.jfree.chart.ChartRenderingInfo var19 = null;
    org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
    java.awt.geom.Rectangle2D var21 = var20.getDataArea();
    org.jfree.chart.entity.ChartEntity var23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var21, "");
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var24);
    var11.setQuadrantOrigin(var25);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11);
    org.jfree.chart.util.RectangleInsets var28 = var27.getItemLabelPadding();
    org.jfree.chart.util.RectangleInsets var29 = var27.getItemLabelPadding();
    var5.addSubtitle((org.jfree.chart.title.Title)var27);
    var5.fireChartChanged();
    int var32 = var5.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 15);

  }

}
