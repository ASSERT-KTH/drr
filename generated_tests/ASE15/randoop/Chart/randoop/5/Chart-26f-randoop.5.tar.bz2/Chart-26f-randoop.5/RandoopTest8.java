
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Paint var10 = var0.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    double var14 = var13.getOuterSeparatorExtension();
    double var15 = var13.getSectionDepth();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.event.ChartProgressListener var18 = null;
    var16.addProgressListener(var18);
    org.jfree.chart.event.ChartProgressListener var20 = null;
    var16.addProgressListener(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.setValue((java.lang.Comparable)(-1), 0.2d);
    var0.removeValue(0);
    org.jfree.chart.util.SortOrder var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByKeys(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    var1.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    java.awt.Paint var6 = var1.getLabelPaint();
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.labels.PieSectionLabelGenerator var10 = var7.getLegendLabelGenerator();
    var1.setLabelGenerator(var10);
    java.awt.Stroke var12 = var1.getSeparatorStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var3 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var4 = var3.getUpperClip();
    boolean var5 = var3.getBaseCreateEntities();
    java.awt.Font var6 = var3.getBaseItemLabelFont();
    org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("", var6);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    double var10 = var9.getOuterSeparatorExtension();
    double var11 = var9.getSectionDepth();
    java.awt.Paint var12 = var9.getLabelLinkPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var13 = null;
    var9.setLegendLabelToolTipGenerator(var13);
    boolean var15 = var9.isSubplot();
    java.awt.Paint var16 = var9.getSeparatorPaint();
    org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("Other", var6, var16, (-1.0f));
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var21 = var19.getDataset((-1));
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.plot.CrosshairState var26 = null;
    boolean var27 = var19.render(var22, var23, 10, var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = var19.getDomainAxis();
    java.awt.Paint var29 = var19.getRangeCrosshairPaint();
    org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("Multiple Pie Plot", var6, var29);
    double var31 = var30.getWidth();
    java.lang.String var32 = var30.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var5.setLabel("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.text.TextAnchor var8 = var5.getLabelTextAnchor();
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 10.0f, var8, 0.0d, 2.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getLabelGap();
    double var4 = var1.getMaximumLabelWidth();
    org.jfree.data.general.DatasetGroup var5 = var1.getDatasetGroup();
    java.awt.Paint var6 = var1.getLabelLinkPaint();
    java.awt.Shape var7 = var1.getLegendItemShape();
    org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var9 = var8.getUpperClip();
    java.awt.Stroke var12 = var8.getItemStroke((-459), (-459));
    var1.setOutlineStroke(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "hi!");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
    int var9 = var6.getColumnCount();
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
    var11.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.axis.SegmentedTimeline var14 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var15 = var14.getSegmentSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var17 = var14.getSegment(604800000L);
    org.jfree.chart.renderer.category.LayeredBarRenderer var19 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var20 = var19.getUpperClip();
    boolean var21 = var19.getBaseCreateEntities();
    java.awt.Font var22 = var19.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("", var22);
    var11.setTickLabelFont((java.lang.Comparable)var17, var22);
    org.jfree.chart.entity.CategoryItemEntity var25 = new org.jfree.chart.entity.CategoryItemEntity(var1, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var17);
    var25.setToolTipText("hi!");
    java.lang.Comparable var28 = var25.getColumnKey();
    java.lang.Comparable var29 = var25.getRowKey();
    java.lang.Comparable var30 = var25.getColumnKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (short)(-1)+ "'", var29.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }
// 
// 
//     org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var6.setShape(100, var9);
//     java.awt.Color var14 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
//     java.awt.Color var15 = var14.brighter();
//     java.awt.Color var16 = var14.darker();
//     java.awt.Color var17 = var14.brighter();
//     org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("First", "First", "Multiple Pie Plot", "February", var9, (java.awt.Paint)var17);
//     java.awt.image.ColorModel var19 = null;
//     java.awt.Rectangle var20 = null;
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var21.draw(var22, var23);
//     double var25 = var21.getContentYOffset();
//     boolean var26 = var21.getExpandToFitSpace();
//     double var27 = var21.getContentXOffset();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var29 = var28.getPadding();
//     var21.setMargin(var29);
//     double var32 = var29.calculateTopOutset(1.0d);
//     org.jfree.chart.entity.EntityCollection var33 = null;
//     org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo(var33);
//     org.jfree.chart.plot.PlotRenderingInfo var35 = var34.getPlotInfo();
//     org.jfree.chart.util.Size2D var38 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var39 = var38.getHeight();
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var43.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var46 = var43.getLabelAnchor();
//     java.awt.geom.Rectangle2D var47 = org.jfree.chart.util.RectangleAnchor.createRectangle(var38, 0.65d, 0.65d, var46);
//     var35.setDataArea(var47);
//     java.awt.geom.Rectangle2D var49 = var29.createOutsetRectangle(var47);
//     java.awt.geom.AffineTransform var50 = null;
//     java.awt.RenderingHints var51 = null;
//     java.awt.PaintContext var52 = var17.createContext(var19, var20, var49, var50, var51);
//     java.awt.geom.Point2D var53 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(9.223372036854776E18d, 2.0d, var49);
//     java.awt.geom.Rectangle2D var54 = null;
//     boolean var55 = org.jfree.chart.util.ShapeUtilities.intersects(var49, var54);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setLowerBound(0.0d);
    org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var5 = var4.getUpperClip();
    boolean var6 = var4.getBaseCreateEntities();
    var4.setBase(1.0d);
    java.awt.Shape var9 = var4.getBaseShape();
    org.jfree.chart.entity.AxisLabelEntity var12 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var9, "", "RangeType.FULL");
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    org.jfree.chart.urls.PieURLGenerator var15 = var14.getURLGenerator();
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
    java.awt.Paint var17 = var16.getItemPaint();
    org.jfree.chart.title.LegendGraphic var18 = new org.jfree.chart.title.LegendGraphic(var9, var17);
    var18.setShapeOutlineVisible(true);
    java.awt.Shape var21 = var18.getShape();
    org.jfree.chart.util.StandardGradientPaintTransformer var22 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var23 = var22.clone();
    var18.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var22);
    org.jfree.chart.util.RectangleInsets var25 = var18.getMargin();
    org.jfree.chart.util.RectangleAnchor var26 = var18.getShapeAnchor();
    java.lang.Object var27 = var18.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.zoom(0.0d);
    java.awt.Paint var9 = var0.getDomainTickBandPaint();
    java.awt.Paint var10 = var0.getDomainTickBandPaint();
    org.jfree.data.xy.XYDataset var11 = var0.getDataset();
    java.awt.Paint var12 = var0.getDomainZeroBaselinePaint();
    java.io.ObjectOutputStream var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
//     java.lang.Object var4 = var2.clone();
//     var2.setAutoRange(true);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getOuterSeparatorExtension();
//     double var10 = var8.getSectionDepth();
//     java.awt.Paint var11 = var8.getLabelLinkPaint();
//     var2.setLabelPaint(var11);
//     java.awt.Font var13 = var2.getTickLabelFont();
//     var2.setVisible(true);
//     java.awt.Shape var16 = var2.getUpArrow();
//     java.awt.Shape var17 = var2.getUpArrow();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var20, 1);
//     double var24 = var20.getRangeUpperBound(false);
//     org.jfree.chart.entity.CategoryItemEntity var27 = new org.jfree.chart.entity.CategoryItemEntity(var17, "RangeType.FULL", "", (org.jfree.data.category.CategoryDataset)var20, (java.lang.Comparable)1577980800000L, (java.lang.Comparable)"DateTickUnit[DAY, 1]");
//     org.jfree.data.category.CategoryDataset var28 = var27.getDataset();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var30 = var29.getPadding();
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var29.removeChangeListener(var31);
//     java.lang.String var33 = var29.getID();
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis("");
//     var35.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var38 = new org.jfree.data.time.DateRange();
//     java.util.Date var39 = var38.getLowerDate();
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     double var42 = var35.dateToJava2D(var39, var40, var41);
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     boolean var44 = var43.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var46 = new org.jfree.chart.axis.ValueAxis[] { var45};
//     var43.setDomainAxes(var46);
//     org.jfree.chart.axis.AxisSpace var48 = null;
//     var43.setFixedDomainAxisSpace(var48);
//     var43.zoom(0.0d);
//     org.jfree.data.KeyedObjects2D var52 = new org.jfree.data.KeyedObjects2D();
//     java.lang.Object var53 = null;
//     boolean var54 = var52.equals(var53);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var55 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var56 = var55.getUpperClip();
//     boolean var57 = var55.getBaseCreateEntities();
//     java.awt.Paint var58 = var55.getBaseOutlinePaint();
//     java.awt.Paint var59 = var55.getBaseFillPaint();
//     var52.setObject((java.lang.Object)var59, (java.lang.Comparable)10.0f, (java.lang.Comparable)10L);
//     var43.setOutlinePaint(var59);
//     var35.setTickMarkPaint(var59);
//     var29.setPaint(var59);
//     java.awt.Color var69 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
//     java.awt.Color var70 = var69.brighter();
//     java.awt.Color var71 = var69.darker();
//     java.lang.String var72 = var71.toString();
//     float[] var73 = null;
//     float[] var74 = var71.getComponents(var73);
//     var29.setPaint((java.awt.Paint)var71);
//     boolean var76 = var27.equals((java.lang.Object)var71);
//     java.awt.Shape var77 = var27.getArea();
//     java.lang.Comparable var78 = var27.getColumnKey();
//     org.jfree.data.category.CategoryDataset var79 = var27.getDataset();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + "java.awt.Color[r=178,g=178,b=178]"+ "'", var72.equals("java.awt.Color[r=178,g=178,b=178]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var78 + "' != '" + "DateTickUnit[DAY, 1]"+ "'", var78.equals("DateTickUnit[DAY, 1]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
    org.jfree.chart.ui.BasicProjectInfo var9 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
    boolean var11 = var9.equals((java.lang.Object)(short)10);
    var4.addLibrary((org.jfree.chart.ui.Library)var9);
    var4.setInfo("Polar Plot");
    org.jfree.chart.ui.Library[] var15 = var4.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var16 = var4.getOptionalLibraries();
    var4.setVersion("java.awt.Color[r=255,g=255,b=255]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    var2.setBaseShapesVisible(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
    java.awt.Paint var7 = var2.getSeriesItemLabelPaint(0);
    var2.setBaseShapesVisible(false);
    var2.setUseFillPaint(true);
    java.awt.Paint var12 = var2.getBaseOutlinePaint();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
    var14.setLabelInsets(var16);
    java.lang.String var18 = var14.getLabelToolTip();
    java.awt.Shape var19 = var14.getDownArrow();
    var2.setBaseShape(var19);
    java.awt.Paint var21 = var2.getErrorIndicatorPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("");
    var5.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange();
    java.util.Date var10 = var9.getLowerDate();
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var5.dateToJava2D(var10, var11, var12);
    var3.setMinimumDate(var10);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("");
    var16.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange();
    java.util.Date var20 = var19.getLowerDate();
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var16.dateToJava2D(var20, var21, var22);
    org.jfree.data.time.SimpleTimePeriod var24 = new org.jfree.data.time.SimpleTimePeriod(var10, var20);
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var10);
    java.lang.String var26 = var25.getDescription();
    boolean var27 = var1.isOnOrAfter(var25);
    int var28 = var1.toSerial();
    int var29 = var1.getYYYY();
    int var30 = var1.toSerial();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 12);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    var1.draw(var2, var3);
    double var5 = var1.getContentYOffset();
    org.jfree.chart.util.VerticalAlignment var6 = var1.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement(var0, var6, 2.0d, 98.0d);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var11 = var10.getPadding();
    org.jfree.chart.event.TitleChangeListener var12 = null;
    var10.removeChangeListener(var12);
    org.jfree.chart.event.TitleChangeEvent var14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var10);
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    boolean var16 = var15.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var18 = new org.jfree.chart.axis.ValueAxis[] { var17};
    var15.setDomainAxes(var18);
    org.jfree.chart.axis.AxisLocation var20 = var15.getDomainAxisLocation();
    org.jfree.chart.LegendItemCollection var21 = var15.getLegendItems();
    var9.add((org.jfree.chart.block.Block)var10, (java.lang.Object)var21);
    double var23 = var10.getContentYOffset();
    java.awt.geom.Rectangle2D var24 = var10.getBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseCreateEntities();
    java.awt.Font var3 = var0.getBaseItemLabelFont();
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var4 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator)var4, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var8.setBaseSeriesVisible(false, false);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    double var15 = var14.getOuterSeparatorExtension();
    double var16 = var14.getSectionDepth();
    java.awt.Paint var17 = var14.getLabelPaint();
    var8.setSeriesOutlinePaint(0, var17, false);
    var0.setSeriesFillPaint(0, var17);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var23, 1);
    int var26 = var23.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var27 = null;
    var23.removeChangeListener(var27);
    org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D();
    var29.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    var32.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var34);
    java.text.NumberFormat var36 = var34.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var37 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var38 = var37.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, (org.jfree.chart.axis.CategoryAxis)var29, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
    org.jfree.chart.axis.CategoryAxis var41 = var39.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var42 = var39.getRangeAxisLocation();
    org.jfree.chart.axis.AxisSpace var43 = var39.getFixedRangeAxisSpace();
    org.jfree.chart.renderer.category.LayeredBarRenderer var44 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var45 = var44.getUpperClip();
    java.awt.Stroke var48 = var44.getItemStroke((-459), (-459));
    var39.setDomainGridlineStroke(var48);
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var52 = var0.initialise(var21, var22, var39, 4, var51);
    org.jfree.chart.entity.EntityCollection var53 = var52.getEntityCollection();
    var52.setBarWidth(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var1 = var0.getSegmentSize();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    var3.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    java.util.Date var8 = var7.getLowerDate();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var3.dateToJava2D(var8, var9, var10);
    boolean var12 = var0.containsDomainValue(var8);
    java.lang.Object var13 = var0.clone();
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange();
    java.util.Date var15 = var14.getLowerDate();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var20 = var17.getPositiveItemLabelPosition(0, 2);
    org.jfree.chart.text.TextAnchor var21 = var20.getTextAnchor();
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var23 = var22.getBackgroundPaint();
    java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
    java.awt.Paint[] var25 = null;
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    boolean var27 = var26.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var28};
    var26.setDomainAxes(var29);
    org.jfree.chart.axis.AxisLocation var31 = var26.getDomainAxisLocation();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
    double var34 = var33.getOuterSeparatorExtension();
    double var35 = var33.getSectionDepth();
    java.awt.Paint var36 = var33.getLabelLinkPaint();
    var26.setOutlinePaint(var36);
    java.awt.Paint[] var38 = new java.awt.Paint[] { var36};
    java.awt.Stroke var39 = null;
    java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
    java.awt.Stroke var41 = null;
    java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    java.awt.Shape[] var45 = new java.awt.Shape[] { var44};
    org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier(var24, var25, var38, var40, var42, var45);
    java.awt.Paint var47 = var46.getNextOutlinePaint();
    boolean var48 = var21.equals((java.lang.Object)var47);
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var51 = var50.getAlpha();
    org.jfree.chart.text.TextAnchor var52 = var50.getLabelTextAnchor();
    org.jfree.chart.axis.DateTick var54 = new org.jfree.chart.axis.DateTick(var15, "First", var21, var52, 0.0d);
    org.jfree.data.DefaultKeyedValues2D var56 = new org.jfree.data.DefaultKeyedValues2D(false);
    java.util.List var57 = var56.getColumnKeys();
    int var58 = var56.getRowCount();
    org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis("");
    var60.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var63 = new org.jfree.data.time.DateRange();
    java.util.Date var64 = var63.getLowerDate();
    java.awt.geom.Rectangle2D var65 = null;
    org.jfree.chart.util.RectangleEdge var66 = null;
    double var67 = var60.dateToJava2D(var64, var65, var66);
    var56.removeValue((java.lang.Comparable)var64, (java.lang.Comparable)(-1.0d));
    org.jfree.data.time.DateRange var70 = new org.jfree.data.time.DateRange(var15, var64);
    org.jfree.chart.axis.SegmentedTimeline.Segment var71 = var0.getSegment(var64);
    org.jfree.data.time.SerialDate var72 = org.jfree.data.time.SerialDate.createInstance(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var1 = var0.clone();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    org.jfree.data.xy.XYDataset var3 = var0.getDataset();
    org.jfree.chart.renderer.PolarItemRenderer var4 = null;
    var0.setRenderer(var4);
    java.awt.Font var6 = var0.getAngleLabelFont();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    boolean var8 = var7.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var7.setDomainAxes(var10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var7.setFixedDomainAxisSpace(var12);
    var7.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    double var18 = var17.getOuterSeparatorExtension();
    double var19 = var17.getSectionDepth();
    java.awt.Paint var20 = var17.getLabelLinkPaint();
    var7.setNoDataMessagePaint(var20);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    var7.setRenderer(15, var23, true);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    boolean var27 = var26.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var28};
    var26.setDomainAxes(var29);
    org.jfree.chart.axis.AxisSpace var31 = null;
    var26.setFixedDomainAxisSpace(var31);
    var26.zoom(0.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var35 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var37 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var35, 1);
    org.jfree.data.general.PieDataset var41 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var37, (java.lang.Comparable)(short)0, (-1.0d), 10);
    org.jfree.data.general.DatasetChangeEvent var42 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0.0d, (org.jfree.data.general.Dataset)var41);
    var7.datasetChanged(var42);
    org.jfree.data.general.Dataset var44 = var42.getDataset();
    var0.datasetChanged(var42);
    java.lang.String var46 = var42.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=0.0]"+ "'", var46.equals("org.jfree.data.general.DatasetChangeEvent[source=0.0]"));

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }
// 
// 
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.0d, 0.5d);
//     java.lang.String var3 = var2.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "hi!");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
    int var9 = var6.getColumnCount();
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
    var11.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.axis.SegmentedTimeline var14 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var15 = var14.getSegmentSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var17 = var14.getSegment(604800000L);
    org.jfree.chart.renderer.category.LayeredBarRenderer var19 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var20 = var19.getUpperClip();
    boolean var21 = var19.getBaseCreateEntities();
    java.awt.Font var22 = var19.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("", var22);
    var11.setTickLabelFont((java.lang.Comparable)var17, var22);
    org.jfree.chart.entity.CategoryItemEntity var25 = new org.jfree.chart.entity.CategoryItemEntity(var1, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var17);
    var25.setToolTipText("hi!");
    java.lang.Comparable var28 = var25.getColumnKey();
    java.lang.String var29 = var25.getShapeCoords();
    java.lang.String var30 = var25.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "0,10,10,-10,-10,-10,-10,-10"+ "'", var29.equals("0,10,10,-10,-10,-10,-10,-10"));

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     var1.setLowerBound(0.0d);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var5 = var4.getUpperClip();
//     boolean var6 = var4.getBaseCreateEntities();
//     var4.setBase(1.0d);
//     java.awt.Shape var9 = var4.getBaseShape();
//     org.jfree.chart.entity.AxisLabelEntity var12 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var9, "", "RangeType.FULL");
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     org.jfree.chart.urls.PieURLGenerator var15 = var14.getURLGenerator();
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14);
//     java.awt.Paint var17 = var16.getItemPaint();
//     org.jfree.chart.title.LegendGraphic var18 = new org.jfree.chart.title.LegendGraphic(var9, var17);
//     var18.setShapeOutlineVisible(true);
//     java.awt.Shape var21 = var18.getShape();
//     var18.setShapeVisible(true);
//     org.jfree.chart.util.RectangleAnchor var24 = var18.getShapeLocation();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot(var26);
//     org.jfree.chart.urls.PieURLGenerator var28 = var27.getURLGenerator();
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27);
//     org.jfree.chart.block.BlockContainer var30 = var29.getItemContainer();
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(10.0d, 1.0E-8d);
//     org.jfree.chart.util.Size2D var35 = var29.arrange(var31, var34);
//     org.jfree.chart.block.RectangleConstraint var37 = var34.toFixedHeight((-0.07499999999999998d));
//     org.jfree.chart.util.Size2D var38 = var18.arrange(var25, var34);
//     
//     // Checks the contract:  equals-hashcode on var14 and var27
//     assertTrue("Contract failed: equals-hashcode on var14 and var27", var14.equals(var27) ? var14.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var14
//     assertTrue("Contract failed: equals-hashcode on var27 and var14", var27.equals(var14) ? var27.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.zoom(0.0d);
    org.jfree.data.KeyedObjects2D var9 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var10 = null;
    boolean var11 = var9.equals(var10);
    org.jfree.chart.renderer.category.LayeredBarRenderer var12 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var13 = var12.getUpperClip();
    boolean var14 = var12.getBaseCreateEntities();
    java.awt.Paint var15 = var12.getBaseOutlinePaint();
    java.awt.Paint var16 = var12.getBaseFillPaint();
    var9.setObject((java.lang.Object)var16, (java.lang.Comparable)10.0f, (java.lang.Comparable)10L);
    var0.setOutlinePaint(var16);
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    boolean var22 = var21.isRangeGridlinesVisible();
    var21.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var21.getDomainMarkers(100, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    int var29 = var21.indexOf(var28);
    org.jfree.chart.axis.AxisLocation var31 = var21.getDomainAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var32 = var21.getDomainAxisLocation();
    var0.setRangeAxisLocation(var32, true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var38 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var36, 1);
    int var39 = var36.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var40 = null;
    var36.removeChangeListener(var40);
    org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D();
    var42.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
    var45.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var47);
    java.text.NumberFormat var49 = var47.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var50 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var51 = var50.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var36, (org.jfree.chart.axis.CategoryAxis)var42, (org.jfree.chart.axis.ValueAxis)var47, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
    org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var56 = var55.getAlpha();
    org.jfree.chart.util.Layer var57 = null;
    var52.addRangeMarker(10, (org.jfree.chart.plot.Marker)var55, var57);
    org.jfree.chart.axis.AxisLocation var59 = var52.getRangeAxisLocation();
    org.jfree.chart.axis.ValueAxis var60 = var52.getRangeAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var61 = var52.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.axis.CategoryLabelPositions var66 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
    var64.setCategoryLabelPositions(var66);
    var52.setDomainAxis(1, var64);
    org.jfree.chart.axis.CategoryAxis var69 = var52.getDomainAxis();
    org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot();
    boolean var72 = var71.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var74 = new org.jfree.chart.axis.ValueAxis[] { var73};
    var71.setDomainAxes(var74);
    org.jfree.chart.axis.AxisLocation var76 = var71.getDomainAxisLocation();
    var52.setRangeAxisLocation(0, var76);
    var0.setDomainAxisLocation(2014, var76, false);
    org.jfree.chart.plot.XYPlot var80 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var82 = new org.jfree.chart.axis.NumberAxis();
    var80.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var82);
    org.jfree.chart.renderer.category.LayeredBarRenderer var84 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var86 = var84.getSeriesOutlineStroke(1);
    java.awt.Paint var88 = var84.lookupSeriesFillPaint((-1));
    var82.setLabelPaint(var88);
    boolean var90 = var82.isPositiveArrowVisible();
    java.awt.Stroke var91 = var82.getAxisLineStroke();
    double var92 = var82.getFixedAutoRange();
    var82.setAutoRangeStickyZero(true);
    org.jfree.data.Range var95 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var95);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    var2.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var4);
    java.text.NumberFormat var6 = var4.getNumberFormatOverride();
    boolean var7 = var4.isAxisLineVisible();
    org.jfree.chart.renderer.PolarItemRenderer var8 = null;
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var4, var8);
    org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
    double var13 = var12.getOuterSeparatorExtension();
    double var14 = var12.getLabelGap();
    org.jfree.chart.util.ShapeList var19 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var19.setShape(100, var22);
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    boolean var25 = var24.isRangeGridlinesVisible();
    var24.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var29 = null;
    java.util.Collection var30 = var24.getDomainMarkers(100, var29);
    org.jfree.data.xy.XYDataset var31 = null;
    int var32 = var24.indexOf(var31);
    java.awt.Stroke var33 = var24.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var34 = null;
    org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot(var34);
    double var36 = var35.getOuterSeparatorExtension();
    double var37 = var35.getSectionDepth();
    java.awt.Paint var38 = var35.getLabelPaint();
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var22, var33, var38);
    var12.setLabelShadowPaint(var38);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    var12.handleClick(0, (-1), var43);
    double var45 = var12.getSectionDepth();
    java.awt.Paint var47 = var12.getSectionPaint((java.lang.Comparable)"Pie 3D Plot");
    java.awt.Font var48 = var12.getLabelFont();
    var9.setAngleLabelFont(var48);
    org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = ", var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    java.awt.Paint var17 = var16.getDomainGridlinePaint();
    var16.configureRangeAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
    boolean var20 = var16.isOutlineVisible();
    org.jfree.data.category.CategoryDataset var21 = null;
    var16.setDataset(var21);
    boolean var23 = var16.isRangeCrosshairVisible();
    org.jfree.chart.axis.AxisLocation var25 = var16.getRangeAxisLocation(100);
    org.jfree.chart.util.RectangleEdge var27 = var16.getRangeAxisEdge(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ChartEntity: tooltip = ");

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var2 = var1.getBackgroundPaint();
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     boolean var6 = var5.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var5.setDomainAxes(var8);
//     org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     double var13 = var12.getOuterSeparatorExtension();
//     double var14 = var12.getSectionDepth();
//     java.awt.Paint var15 = var12.getLabelLinkPaint();
//     var5.setOutlinePaint(var15);
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var15};
//     java.awt.Stroke var18 = null;
//     java.awt.Stroke[] var19 = new java.awt.Stroke[] { var18};
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
//     org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var4, var17, var19, var21, var24);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var27 = var26.getBackgroundPaint();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Paint[] var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
//     boolean var31 = var30.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var33 = new org.jfree.chart.axis.ValueAxis[] { var32};
//     var30.setDomainAxes(var33);
//     org.jfree.chart.axis.AxisLocation var35 = var30.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
//     double var38 = var37.getOuterSeparatorExtension();
//     double var39 = var37.getSectionDepth();
//     java.awt.Paint var40 = var37.getLabelLinkPaint();
//     var30.setOutlinePaint(var40);
//     java.awt.Paint[] var42 = new java.awt.Paint[] { var40};
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var49 = new java.awt.Shape[] { var48};
//     org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var28, var29, var42, var44, var46, var49);
//     java.awt.Stroke[] var51 = null;
//     java.awt.Shape[] var52 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var53 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var17, var46, var51, var52);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var30
//     assertTrue("Contract failed: equals-hashcode on var5 and var30", var5.equals(var30) ? var5.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var5
//     assertTrue("Contract failed: equals-hashcode on var30 and var5", var30.equals(var5) ? var30.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var37
//     assertTrue("Contract failed: equals-hashcode on var12 and var37", var12.equals(var37) ? var12.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var12
//     assertTrue("Contract failed: equals-hashcode on var37 and var12", var37.equals(var12) ? var37.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var50
//     assertTrue("Contract failed: equals-hashcode on var25 and var50", var25.equals(var50) ? var25.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var25
//     assertTrue("Contract failed: equals-hashcode on var50 and var25", var50.equals(var25) ? var50.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setURLText("DatasetRenderingOrder.REVERSE");

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var4 = var3.getLabelFont();
//     var3.setAutoRangeMinimumSize(100.0d, true);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     double var10 = var9.getOuterSeparatorExtension();
//     java.lang.String var11 = var9.getNoDataMessage();
//     java.awt.Stroke var12 = var9.getSeparatorStroke();
//     var3.setAxisLineStroke(var12);
//     var0.setStroke(1, var12);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, 1);
//     int var18 = var15.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var19 = null;
//     var15.removeChangeListener(var19);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     var21.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     var24.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var26);
//     java.text.NumberFormat var28 = var26.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var29 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var30 = var29.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, (org.jfree.chart.axis.CategoryAxis)var21, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
//     java.awt.Paint var32 = var31.getDomainGridlinePaint();
//     var31.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var34 = var31.getDatasetRenderingOrder();
//     java.awt.Stroke var35 = var31.getRangeCrosshairStroke();
//     var31.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var38 = var31.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     var39.setUpperMargin(98.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var42 = var39.getCategoryLabelPositions();
//     int var43 = var31.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var39);
//     boolean var44 = var0.equals((java.lang.Object)var31);
//     var31.setRangeCrosshairValue(10.0d);
//     var31.clearDomainMarkers(100);
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var49 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     boolean var51 = var50.isRangeGridlinesVisible();
//     var50.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var55 = null;
//     java.util.Collection var56 = var50.getDomainMarkers(100, var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     int var58 = var50.indexOf(var57);
//     org.jfree.chart.util.ShapeList var63 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var63.setShape(100, var66);
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot();
//     boolean var69 = var68.isRangeGridlinesVisible();
//     var68.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var73 = null;
//     java.util.Collection var74 = var68.getDomainMarkers(100, var73);
//     org.jfree.data.xy.XYDataset var75 = null;
//     int var76 = var68.indexOf(var75);
//     java.awt.Stroke var77 = var68.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var78 = null;
//     org.jfree.chart.plot.RingPlot var79 = new org.jfree.chart.plot.RingPlot(var78);
//     double var80 = var79.getOuterSeparatorExtension();
//     double var81 = var79.getSectionDepth();
//     java.awt.Paint var82 = var79.getLabelPaint();
//     org.jfree.chart.LegendItem var83 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var66, var77, var82);
//     var50.setDomainCrosshairPaint(var82);
//     org.jfree.chart.axis.AxisLocation var85 = var50.getDomainAxisLocation();
//     var50.clearAnnotations();
//     org.jfree.chart.axis.AxisSpace var87 = var50.getFixedDomainAxisSpace();
//     java.awt.Stroke var88 = var50.getDomainZeroBaselineStroke();
//     var49.setGroupStroke(var88);
//     boolean var90 = var49.isDrawLines();
//     java.awt.Stroke var91 = var49.getGroupStroke();
//     var31.setRangeCrosshairStroke(var91);
//     
//     // Checks the contract:  equals-hashcode on var9 and var79
//     assertTrue("Contract failed: equals-hashcode on var9 and var79", var9.equals(var79) ? var9.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var9
//     assertTrue("Contract failed: equals-hashcode on var79 and var9", var79.equals(var9) ? var79.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }


    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    var2.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.data.RangeType var6 = var4.getRangeType();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getOuterSeparatorExtension();
    var8.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    boolean var13 = var4.hasListener((java.util.EventListener)var8);
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange();
    var4.setDefaultAutoRange((org.jfree.data.Range)var14);
    org.jfree.data.Range var16 = org.jfree.data.Range.combine((org.jfree.data.Range)var1, (org.jfree.data.Range)var14);
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var18 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, var18);
    org.jfree.chart.block.RectangleConstraint var21 = var19.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var22 = var19.getHeightConstraintType();
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange();
    java.util.Date var25 = var24.getLowerDate();
    org.jfree.data.Range var26 = null;
    org.jfree.data.Range var27 = null;
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, var27);
    org.jfree.chart.block.RectangleConstraint var30 = var28.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var31 = var28.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, (org.jfree.data.Range)var14, var22, 1.0d, (org.jfree.data.Range)var24, var31);
    org.jfree.data.DefaultKeyedValues2D var34 = new org.jfree.data.DefaultKeyedValues2D(false);
    java.util.List var35 = var34.getColumnKeys();
    var34.clear();
    boolean var37 = var31.equals((java.lang.Object)var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var39 = var34.getRowKey((-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    int var19 = var16.getWeight();
    var16.clearDomainAxes();
    org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Paint var23 = var22.getPaint();
    org.jfree.chart.event.MarkerChangeEvent var24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var22);
    var16.markerChanged(var24);
    var16.setNoDataMessage("({0}, {1}) = {3} - {4}");
    org.jfree.chart.util.SortOrder var28 = var16.getColumnRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("First");
    org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
    org.jfree.chart.text.TextFragment var3 = var1.getLastTextFragment();
    org.jfree.chart.text.TextFragment var4 = var1.getLastTextFragment();
    org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var9 = var8.getUpperClip();
    boolean var10 = var8.getBaseCreateEntities();
    java.awt.Font var11 = var8.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var11);
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var11);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("CONTRACT", var14);
    var1.addFragment(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("CategoryLabelWidthType.CATEGORY", (org.jfree.data.time.TimePeriod)var2);
    var3.setPercentComplete((java.lang.Double)1.05d);
    var3.setPercentComplete((java.lang.Double)8.6399998E7d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.String var2 = var1.getPlotType();
    org.jfree.chart.JFreeChart var3 = var1.getPieChart();
    java.lang.Object var4 = var3.clone();
    org.jfree.data.KeyedObject var5 = new org.jfree.data.KeyedObject((java.lang.Comparable)'a', (java.lang.Object)var3);
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
    var6.setShadowYOffset(0.05d);
    var5.setObject((java.lang.Object)0.05d);
    java.lang.Object var10 = var5.clone();
    org.jfree.chart.renderer.category.LineRenderer3D var11 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var11.setXOffset(4.0d);
    org.jfree.chart.urls.CategoryURLGenerator var15 = var11.getSeriesURLGenerator((-1));
    var11.setSeriesVisibleInLegend(4, (java.lang.Boolean)false, false);
    boolean var20 = var11.getUseOutlinePaint();
    java.awt.Paint var21 = var11.getWallPaint();
    boolean var22 = var5.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Multiple Pie Plot"+ "'", var2.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
    boolean var4 = var3.getIncludeBaseInRange();
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var6 = var5.getUpperClip();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = var5.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var10 = var5.getNegativeItemLabelPosition(0, (-459));
    var3.setPositiveItemLabelPositionFallback(var10);
    double var12 = var3.getXOffset();
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = var3.getSeriesToolTipGenerator(2);
    double var15 = var3.getXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 98.0d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    boolean var2 = var1.isRangeGridlinesVisible();
    var1.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var1.getDomainMarkers(100, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    int var9 = var1.indexOf(var8);
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var14.setShape(100, var17);
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    boolean var20 = var19.isRangeGridlinesVisible();
    var19.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var24 = null;
    java.util.Collection var25 = var19.getDomainMarkers(100, var24);
    org.jfree.data.xy.XYDataset var26 = null;
    int var27 = var19.indexOf(var26);
    java.awt.Stroke var28 = var19.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
    double var31 = var30.getOuterSeparatorExtension();
    double var32 = var30.getSectionDepth();
    java.awt.Paint var33 = var30.getLabelPaint();
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var17, var28, var33);
    var1.setDomainCrosshairPaint(var33);
    org.jfree.chart.axis.AxisLocation var36 = var1.getDomainAxisLocation();
    var1.clearAnnotations();
    org.jfree.chart.axis.AxisSpace var38 = var1.getFixedDomainAxisSpace();
    java.awt.Stroke var39 = var1.getDomainZeroBaselineStroke();
    var0.setGroupStroke(var39);
    boolean var41 = var0.isDrawLines();
    java.awt.Stroke var42 = var0.getGroupStroke();
    var0.setDrawLines(false);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var45 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    boolean var46 = var45.isDrawLines();
    javax.swing.Icon var47 = var45.getObjectIcon();
    var0.setObjectIcon(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getLabelInsets();
//     double var2 = var0.getAutoRangeMinimumSize();
//     org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange((org.jfree.data.Range)var3);
//     java.util.Date var5 = var3.getUpperDate();
//     var0.setDefaultAutoRange((org.jfree.data.Range)var3);
//     java.lang.String var7 = var3.toString();
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range)var3, 0.2d);
//     double var10 = var9.getLength();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var7.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0d);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)0.0d, (java.lang.Number)(short)1);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1, var7);
    var0.addValue((java.lang.Comparable)1, (-2.0d));
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    java.awt.Paint var17 = var16.getDomainGridlinePaint();
    var16.configureRangeAxes();
    var16.clearRangeAxes();
    org.jfree.chart.axis.CategoryAxis var21 = var16.getDomainAxis(0);
    org.jfree.chart.axis.CategoryLabelPositions var22 = var21.getCategoryLabelPositions();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesCreateEntities(100);
    java.lang.Object var3 = null;
    boolean var4 = var0.equals(var3);
    java.lang.Boolean var6 = null;
    var0.setSeriesVisibleInLegend(100, var6, true);
    org.jfree.chart.renderer.category.LineRenderer3D var9 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var10 = var9.getBaseShapesFilled();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var11, 1);
    int var14 = var11.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var15 = null;
    var11.removeChangeListener(var15);
    org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
    var17.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    var20.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var22);
    java.text.NumberFormat var24 = var22.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var25 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var26 = var25.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, (org.jfree.chart.axis.CategoryAxis)var17, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var11, (java.lang.Comparable)0.5f);
    java.util.List var30 = var11.getColumnKeys();
    boolean var31 = var9.equals((java.lang.Object)var11);
    org.jfree.data.Range var32 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var11);
    org.jfree.chart.axis.SegmentedTimeline var34 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var35 = var34.getSegmentSize();
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis("");
    var37.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange();
    java.util.Date var42 = var41.getLowerDate();
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleEdge var44 = null;
    double var45 = var37.dateToJava2D(var42, var43, var44);
    boolean var46 = var34.containsDomainValue(var42);
    org.jfree.data.time.Month var47 = new org.jfree.data.time.Month(var42);
    java.lang.Number var48 = var11.getStdDevValue((java.lang.Comparable)9.223372036854776E18d, (java.lang.Comparable)var47);
    int var49 = var11.getColumnCount();
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
    var51.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var53);
    java.text.NumberFormat var55 = var53.getNumberFormatOverride();
    java.awt.Paint var56 = var53.getTickMarkPaint();
    double var57 = var53.getUpperMargin();
    org.jfree.chart.axis.NumberTickUnit var59 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    var53.setTickUnit(var59, true, true);
    java.lang.Number var63 = var11.getStdDevValue((java.lang.Comparable)"AreaRendererEndType.TAPER", (java.lang.Comparable)var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("CONTRACT", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getSectionDepth();
    java.awt.Paint var5 = var1.getSectionOutlinePaint((java.lang.Comparable)0.0f);
    org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(10, 0);
    boolean var9 = var1.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.util.RectangleInsets var2 = var0.getInsets();
    double var3 = var2.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setLowerBound(0.0d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, Double.NaN, 10.0d);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    var5.draw(var6, var7);
    var5.setURLText("Multiple Pie Plot");
    org.jfree.chart.util.RectangleEdge var11 = var5.getPosition();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    org.jfree.chart.urls.PieURLGenerator var14 = var13.getURLGenerator();
    org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    java.awt.Paint var16 = var15.getItemPaint();
    java.awt.Paint var17 = var15.getItemPaint();
    org.jfree.chart.util.RectangleAnchor var18 = var15.getLegendItemGraphicAnchor();
    org.jfree.chart.util.RectangleAnchor var19 = var15.getLegendItemGraphicAnchor();
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var21 = var20.getPadding();
    var15.setPadding(var21);
    java.lang.Object var23 = var15.clone();
    org.jfree.chart.block.BlockContainer var24 = var15.getItemContainer();
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
    double var27 = var26.getOuterSeparatorExtension();
    java.lang.String var28 = var26.getNoDataMessage();
    java.awt.Stroke var29 = var26.getSeparatorStroke();
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
    boolean var31 = var30.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var33 = new org.jfree.chart.axis.ValueAxis[] { var32};
    var30.setDomainAxes(var33);
    org.jfree.chart.axis.AxisSpace var35 = null;
    var30.setFixedDomainAxisSpace(var35);
    var30.zoom(0.0d);
    java.awt.Paint var39 = var30.getDomainTickBandPaint();
    java.awt.Paint var40 = var30.getDomainGridlinePaint();
    var26.setLabelPaint(var40);
    org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(var40);
    var15.setBackgroundPaint(var40);
    var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    boolean var25 = var24.isShapeFilled();
    boolean var26 = var24.isShapeFilled();
    org.jfree.data.general.Dataset var27 = var24.getDataset();
    var24.setDatasetIndex((-51764));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.95f, 0.0f, 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("white");

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.awt.Stroke var4 = var0.getDomainCrosshairStroke();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var0.markerChanged(var5);
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.AxisLocation var10 = var0.getRangeAxisLocation(4);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    var13.clearDomainMarkers();
    boolean var15 = var12.equals((java.lang.Object)var13);
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var18.setTickMarkOutsideLength(0.0f);
    var13.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var18);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var23.draw(var24, var25);
    double var27 = var23.getContentYOffset();
    boolean var28 = var23.getExpandToFitSpace();
    double var29 = var23.getContentXOffset();
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var31 = var30.getPadding();
    var23.setMargin(var31);
    double var34 = var31.calculateTopOutset(1.0d);
    org.jfree.chart.entity.EntityCollection var35 = null;
    org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
    org.jfree.chart.plot.PlotRenderingInfo var37 = var36.getPlotInfo();
    org.jfree.chart.util.Size2D var40 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
    double var41 = var40.getHeight();
    org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var45.setLabel("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.util.RectangleAnchor var48 = var45.getLabelAnchor();
    java.awt.geom.Rectangle2D var49 = org.jfree.chart.util.RectangleAnchor.createRectangle(var40, 0.65d, 0.65d, var48);
    var37.setDataArea(var49);
    java.awt.geom.Rectangle2D var51 = var31.createOutsetRectangle(var49);
    org.jfree.chart.axis.SegmentedTimeline var52 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var53 = var52.getSegmentSize();
    org.jfree.chart.axis.DateAxis var55 = new org.jfree.chart.axis.DateAxis("");
    var55.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var59 = new org.jfree.data.time.DateRange();
    java.util.Date var60 = var59.getLowerDate();
    java.awt.geom.Rectangle2D var61 = null;
    org.jfree.chart.util.RectangleEdge var62 = null;
    double var63 = var55.dateToJava2D(var60, var61, var62);
    boolean var64 = var52.containsDomainValue(var60);
    java.lang.Object var65 = var52.clone();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var66 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var68 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var66, 1);
    int var69 = var66.getColumnCount();
    org.jfree.data.Range var70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var66);
    java.util.List var71 = var66.getRowKeys();
    var52.setExceptionSegments(var71);
    var13.drawRangeTickBands(var22, var49, var71);
    org.jfree.data.KeyToGroupMap var74 = new org.jfree.data.KeyToGroupMap();
    java.util.List var75 = var74.getGroups();
    var0.drawDomainTickBands(var11, var49, var75);
    org.jfree.data.xy.XYDataset var77 = null;
    var0.setDataset(var77);
    var0.setRangeCrosshairValue(2.0d);
    org.jfree.chart.renderer.xy.XYItemRenderer var81 = null;
    var0.setRenderer(var81);
    org.jfree.chart.util.RectangleEdge var84 = var0.getRangeAxisEdge(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.util.RectangleInsets var2 = var0.getInsets();
    org.jfree.chart.util.UnitType var3 = var2.getUnitType();
    double var5 = var2.calculateRightOutset(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     java.awt.Stroke var9 = var0.getRangeGridlineStroke();
//     java.awt.Paint var10 = var0.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     double var14 = var13.getOuterSeparatorExtension();
//     double var15 = var13.getSectionDepth();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     float var18 = var16.getBackgroundImageAlpha();
//     java.awt.Paint var19 = var16.getBackgroundPaint();
//     org.jfree.chart.title.LegendTitle var21 = var16.getLegend(5);
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("");
//     var23.setURLText("poly");
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, 1);
//     int var29 = var26.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var30 = null;
//     var26.removeChangeListener(var30);
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     var32.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     var35.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var37);
//     java.text.NumberFormat var39 = var37.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var40 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var41 = var40.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, (org.jfree.chart.axis.CategoryAxis)var32, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
//     org.jfree.chart.axis.CategoryAxis var44 = var42.getDomainAxisForDataset(100);
//     org.jfree.chart.event.PlotChangeEvent var45 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var42);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     boolean var47 = var46.isRangeGridlinesVisible();
//     var46.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var51 = null;
//     java.util.Collection var52 = var46.getDomainMarkers(100, var51);
//     org.jfree.data.xy.XYDataset var53 = null;
//     int var54 = var46.indexOf(var53);
//     java.awt.Stroke var55 = var46.getRangeGridlineStroke();
//     java.awt.Paint var56 = var46.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.RingPlot var59 = new org.jfree.chart.plot.RingPlot(var58);
//     double var60 = var59.getOuterSeparatorExtension();
//     double var61 = var59.getSectionDepth();
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var59);
//     var46.addChangeListener((org.jfree.chart.event.PlotChangeListener)var62);
//     var62.setAntiAlias(true);
//     var45.setChart(var62);
//     int var67 = var62.getSubtitleCount();
//     var23.addChangeListener((org.jfree.chart.event.TitleChangeListener)var62);
//     java.awt.RenderingHints var69 = var62.getRenderingHints();
//     var16.setRenderingHints(var69);
//     
//     // Checks the contract:  equals-hashcode on var0 and var46
//     assertTrue("Contract failed: equals-hashcode on var0 and var46", var0.equals(var46) ? var0.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var0
//     assertTrue("Contract failed: equals-hashcode on var46 and var0", var46.equals(var0) ? var46.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var59
//     assertTrue("Contract failed: equals-hashcode on var13 and var59", var13.equals(var59) ? var13.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var13
//     assertTrue("Contract failed: equals-hashcode on var59 and var13", var59.equals(var13) ? var59.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var62
//     assertTrue("Contract failed: equals-hashcode on var16 and var62", var16.equals(var62) ? var16.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var16
//     assertTrue("Contract failed: equals-hashcode on var62 and var16", var62.equals(var16) ? var62.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    var3.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    java.util.Date var8 = var7.getLowerDate();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var3.dateToJava2D(var8, var9, var10);
    var1.setMinimumDate(var8);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    var14.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    java.util.Date var18 = var17.getLowerDate();
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var14.dateToJava2D(var18, var19, var20);
    org.jfree.data.time.SimpleTimePeriod var22 = new org.jfree.data.time.SimpleTimePeriod(var8, var18);
    org.jfree.chart.renderer.category.LayeredBarRenderer var23 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var24 = var23.getUpperClip();
    boolean var25 = var23.getBaseCreateEntities();
    var23.setBase(1.0d);
    boolean var28 = var22.equals((java.lang.Object)var23);
    double var29 = var23.getItemMargin();
    var23.setBaseSeriesVisible(false);
    var23.setBaseCreateEntities(true);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    java.lang.Number var37 = var34.getMaxOutlier((java.lang.Comparable)10, (java.lang.Comparable)0.8f);
    int var38 = var34.getRowCount();
    int var39 = var34.getRowCount();
    org.jfree.data.general.PieDataset var41 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var34, 12);
    org.jfree.data.Range var42 = var23.findRangeBounds((org.jfree.data.category.CategoryDataset)var34);
    java.awt.Stroke var44 = var23.lookupSeriesStroke((-245));
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createRegularCross(2.0f, 1.0f);
    var23.setSeriesShape(0, var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    var1.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var3);
    org.jfree.chart.plot.DatasetRenderingOrder var5 = var1.getDatasetRenderingOrder();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("CONTRACT", (org.jfree.chart.plot.Plot)var1);
    boolean var7 = var1.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     double var3 = var2.getOuterSeparatorExtension();
//     double var4 = var2.getSectionDepth();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
//     var5.setNotify(false);
//     org.jfree.chart.title.LegendTitle var9 = var5.getLegend(12);
//     float var10 = var5.getBackgroundImageAlpha();
//     int var11 = var5.getSubtitleCount();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     org.jfree.chart.urls.PieURLGenerator var14 = var13.getURLGenerator();
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     org.jfree.chart.block.BlockContainer var16 = var15.getItemContainer();
//     var15.setHeight(10.0d);
//     org.jfree.chart.util.HorizontalAlignment var19 = var15.getHorizontalAlignment();
//     var5.addSubtitle((org.jfree.chart.title.Title)var15);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("February");
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var4 = var3.getYear();
    org.jfree.data.time.Year var5 = var3.getYear();
    org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(2, var5);
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.category.LayeredBarRenderer var9 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var10 = var9.getUpperClip();
    boolean var11 = var9.getBaseCreateEntities();
    java.awt.Font var12 = var9.getBaseItemLabelFont();
    var8.setAngleLabelFont(var12);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    var14.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.renderer.category.LayeredBarRenderer var18 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var20 = var18.getSeriesOutlineStroke(1);
    java.awt.Paint var22 = var18.lookupSeriesFillPaint((-1));
    var16.setLabelPaint(var22);
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var12, var22);
    java.util.List var25 = var24.getLines();
    org.jfree.chart.text.TextBlockAnchor var26 = null;
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var28.setLabel("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.text.TextAnchor var31 = var28.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var33 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)2, var24, var26, var31, 98.0d);
    org.jfree.chart.renderer.category.LayeredBarRenderer var35 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var36 = var35.getUpperClip();
    boolean var37 = var35.getBaseCreateEntities();
    java.awt.Font var38 = var35.getBaseItemLabelFont();
    org.jfree.chart.text.TextLine var39 = new org.jfree.chart.text.TextLine("", var38);
    var24.addLine(var39);
    org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("February");
    float var43 = var42.getBaselineOffset();
    java.awt.Font var44 = var42.getFont();
    var39.addFragment(var42);
    var1.removeFragment(var42);
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis();
    var47.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var49);
    java.awt.Stroke var51 = var47.getDomainCrosshairStroke();
    org.jfree.chart.axis.AxisSpace var52 = var47.getFixedRangeAxisSpace();
    org.jfree.chart.renderer.xy.XYItemRenderer var54 = var47.getRenderer((-246));
    org.jfree.chart.plot.PlotOrientation var55 = var47.getOrientation();
    boolean var56 = var1.equals((java.lang.Object)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var1.getColumnKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    var5.setNotify(false);
    java.awt.Stroke var8 = null;
    var5.setBorderStroke(var8);
    var5.setBorderVisible(false);
    var5.removeLegend();
    var5.clearSubtitles();
    java.lang.Object var14 = var5.getTextAntiAlias();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var17 = var5.createBufferedImage(15, (-416));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     org.jfree.data.time.Year var3 = var1.getYear();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(2, var3);
//     java.lang.String var5 = var3.toString();
//     java.lang.String var6 = var3.toString();
//     org.jfree.chart.axis.SegmentedTimeline var10 = new org.jfree.chart.axis.SegmentedTimeline(1577894400001L, 0, 0);
//     java.util.Date var12 = var10.getDate((-2208960000000L));
//     int var13 = var3.compareTo((java.lang.Object)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "2014"+ "'", var5.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2014"+ "'", var6.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.awt.Stroke var4 = var0.getDomainCrosshairStroke();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var0.markerChanged(var5);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 1);
    int var10 = var7.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var11 = null;
    var7.removeChangeListener(var11);
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    var13.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
    java.text.NumberFormat var20 = var18.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var22 = var21.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, (org.jfree.chart.axis.CategoryAxis)var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var27 = var26.getAlpha();
    org.jfree.chart.util.Layer var28 = null;
    var23.addRangeMarker(10, (org.jfree.chart.plot.Marker)var26, var28);
    org.jfree.chart.axis.AxisLocation var30 = var23.getRangeAxisLocation();
    org.jfree.chart.axis.ValueAxis var31 = var23.getRangeAxis();
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
    boolean var34 = var33.isRangeGridlinesVisible();
    var33.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var38 = null;
    java.util.Collection var39 = var33.getDomainMarkers(100, var38);
    org.jfree.data.xy.XYDataset var40 = null;
    int var41 = var33.indexOf(var40);
    org.jfree.chart.axis.AxisLocation var43 = var33.getDomainAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var44 = var33.getDomainAxisLocation();
    var23.setRangeAxisLocation(1, var44);
    org.jfree.chart.LegendItemCollection var46 = var23.getFixedLegendItems();
    var23.setRangeCrosshairVisible(false);
    int var49 = var23.getWeight();
    org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var53 = var52.getAlpha();
    org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
    var54.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.chart.renderer.category.LayeredBarRenderer var58 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var60 = var58.getSeriesOutlineStroke(1);
    java.awt.Paint var62 = var58.lookupSeriesFillPaint((-1));
    var56.setLabelPaint(var62);
    var52.setOutlinePaint(var62);
    org.jfree.chart.util.Layer var65 = null;
    var23.addRangeMarker(1, (org.jfree.chart.plot.Marker)var52, var65);
    double var67 = var52.getValue();
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var52);
    java.awt.Paint var70 = var0.getQuadrantPaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var20 = var19.getAlpha();
//     org.jfree.chart.util.Layer var21 = null;
//     var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
//     org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation();
//     org.jfree.chart.axis.ValueAxis var24 = var16.getRangeAxis();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     boolean var27 = var26.isRangeGridlinesVisible();
//     var26.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var31 = null;
//     java.util.Collection var32 = var26.getDomainMarkers(100, var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     int var34 = var26.indexOf(var33);
//     org.jfree.chart.axis.AxisLocation var36 = var26.getDomainAxisLocation(1);
//     org.jfree.chart.axis.AxisLocation var37 = var26.getDomainAxisLocation();
//     var16.setRangeAxisLocation(1, var37);
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var40.setAutoRange(true);
//     var40.setAutoTickUnitSelection(true, false);
//     org.jfree.data.RangeType var46 = var40.getRangeType();
//     boolean var47 = var16.equals((java.lang.Object)var40);
//     org.jfree.data.time.DateRange var49 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     var50.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var52);
//     org.jfree.data.RangeType var54 = var52.getRangeType();
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.RingPlot var56 = new org.jfree.chart.plot.RingPlot(var55);
//     double var57 = var56.getOuterSeparatorExtension();
//     var56.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     boolean var61 = var52.hasListener((java.util.EventListener)var56);
//     org.jfree.data.time.DateRange var62 = new org.jfree.data.time.DateRange();
//     var52.setDefaultAutoRange((org.jfree.data.Range)var62);
//     org.jfree.data.Range var64 = org.jfree.data.Range.combine((org.jfree.data.Range)var49, (org.jfree.data.Range)var62);
//     org.jfree.data.Range var65 = null;
//     org.jfree.data.Range var66 = null;
//     org.jfree.chart.block.RectangleConstraint var67 = new org.jfree.chart.block.RectangleConstraint(var65, var66);
//     org.jfree.chart.block.RectangleConstraint var69 = var67.toFixedHeight(0.0d);
//     org.jfree.chart.block.LengthConstraintType var70 = var67.getHeightConstraintType();
//     org.jfree.data.time.DateRange var72 = new org.jfree.data.time.DateRange();
//     java.util.Date var73 = var72.getLowerDate();
//     org.jfree.data.Range var74 = null;
//     org.jfree.data.Range var75 = null;
//     org.jfree.chart.block.RectangleConstraint var76 = new org.jfree.chart.block.RectangleConstraint(var74, var75);
//     org.jfree.chart.block.RectangleConstraint var78 = var76.toFixedHeight(0.0d);
//     org.jfree.chart.block.LengthConstraintType var79 = var76.getHeightConstraintType();
//     org.jfree.chart.block.RectangleConstraint var80 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, (org.jfree.data.Range)var62, var70, 1.0d, (org.jfree.data.Range)var72, var79);
//     org.jfree.chart.block.RectangleConstraint var82 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var62, 98.0d);
//     org.jfree.chart.block.RectangleConstraint var83 = var82.toUnconstrainedWidth();
//     org.jfree.data.Range var84 = var82.getWidthRange();
//     var40.setRange(var84, false, false);
//     
//     // Checks the contract:  equals-hashcode on var9 and var50
//     assertTrue("Contract failed: equals-hashcode on var9 and var50", var9.equals(var50) ? var9.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var9
//     assertTrue("Contract failed: equals-hashcode on var50 and var9", var50.equals(var9) ? var50.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesCreateEntities(100);
    java.lang.Object var3 = null;
    boolean var4 = var0.equals(var3);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    double var8 = var7.getOuterSeparatorExtension();
    double var9 = var7.getSectionDepth();
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    java.util.List var11 = var10.getSubtitles();
    boolean var12 = var0.equals((java.lang.Object)var10);
    var0.setRenderAsPercentages(true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var0.getPositiveItemLabelPosition(0, 2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    var18.setLowerMargin(2.0d);
    var18.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesCreateEntities(100);
    java.awt.Shape var3 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = var0.getSeriesItemLabelGenerator(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var2 = new org.jfree.data.gantt.TaskSeries("UnitType.ABSOLUTE");
    org.jfree.data.gantt.Task var3 = null;
    var2.remove(var3);
    var2.fireSeriesChanged();
    var0.remove(var2);
    org.jfree.data.gantt.TaskSeries var8 = new org.jfree.data.gantt.TaskSeries("UnitType.ABSOLUTE");
    var0.add(var8);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(12);
    int var12 = var11.getMonth();
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(12);
    boolean var15 = var11.isOnOrBefore((org.jfree.data.time.SerialDate)var14);
    java.util.Date var16 = var11.toDate();
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("");
    var18.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange();
    java.util.Date var23 = var22.getLowerDate();
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var18.dateToJava2D(var23, var24, var25);
    org.jfree.data.time.DateRange var27 = new org.jfree.data.time.DateRange(var16, var23);
    int var28 = var0.getRowIndex((java.lang.Comparable)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }


    org.jfree.chart.renderer.OutlierListCollection var0 = new org.jfree.chart.renderer.OutlierListCollection();
    var0.setHighFarOut(false);
    org.jfree.chart.renderer.Outlier var3 = null;
    boolean var4 = var0.add(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var1.setBaseSeriesVisible(false, false);
    java.awt.Paint var7 = var1.getItemLabelPaint(0, 10);
    var0.setAngleGridlinePaint(var7);
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    var0.setRenderer(var9);
    var0.setRadiusGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue(var0, (java.lang.Number)(short)1);
    java.lang.Comparable var3 = var2.getKey();
    java.lang.Number var4 = var2.getValue();
    java.lang.Comparable var5 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)1+ "'", var4.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    java.util.List var19 = var16.getCategories();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Paint var10 = var0.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    double var14 = var13.getOuterSeparatorExtension();
    double var15 = var13.getSectionDepth();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.event.ChartProgressListener var18 = null;
    var16.addProgressListener(var18);
    var16.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var24 = var23.getPadding();
    org.jfree.chart.event.TitleChangeListener var25 = null;
    var23.removeChangeListener(var25);
    java.lang.String var27 = var23.getID();
    java.lang.String var28 = var23.getText();
    java.lang.Object var29 = var23.clone();
    org.jfree.chart.util.RectangleEdge var30 = var23.getPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addSubtitle(4, (org.jfree.chart.title.Title)var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + ""+ "'", var28.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
//     org.jfree.chart.axis.AxisSpace var20 = var16.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     var16.setRangeAxis(var21);
//     int var23 = var16.getRangeAxisCount();
//     var16.clearRangeMarkers((-16777216));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, 1);
//     int var29 = var26.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var30 = null;
//     var26.removeChangeListener(var30);
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     var32.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     var35.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var37);
//     java.text.NumberFormat var39 = var37.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var40 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var41 = var40.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, (org.jfree.chart.axis.CategoryAxis)var32, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
//     java.awt.Paint var43 = var42.getDomainGridlinePaint();
//     var42.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var45 = var42.getDatasetRenderingOrder();
//     boolean var46 = var42.isOutlineVisible();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     var42.setDataset(var47);
//     org.jfree.chart.axis.AxisLocation var50 = var42.getDomainAxisLocation(5);
//     var16.setDomainAxisLocation(var50, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var35
//     assertTrue("Contract failed: equals-hashcode on var9 and var35", var9.equals(var35) ? var9.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var9
//     assertTrue("Contract failed: equals-hashcode on var35 and var9", var35.equals(var9) ? var35.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    java.awt.Shape var8 = var0.calculateBounds(var1, 0.8f, 0.8f, var4, 100.0f, 2.0f, 8.0d);
    org.jfree.chart.util.HorizontalAlignment var9 = var0.getLineAlignment();
    org.jfree.chart.text.TextLine var10 = var0.getLastLine();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.util.Size2D var12 = var0.calculateDimensions(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }
// 
// 
//     org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
//     var0.insertValue(0, (java.lang.Comparable)0.0d, (java.lang.Number)(short)1);
//     org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
//     int var7 = var0.getIndex((java.lang.Comparable)0.0d);
//     org.jfree.chart.axis.SegmentedTimeline var8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var9 = var8.getSegmentSize();
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
//     var11.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
//     java.util.Date var16 = var15.getLowerDate();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var11.dateToJava2D(var16, var17, var18);
//     boolean var20 = var8.containsDomainValue(var16);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var16);
//     java.lang.String var22 = var21.toString();
//     long var23 = var21.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var24 = var21.previous();
//     var0.setValue((java.lang.Comparable)var21, 1.0E-8d);
//     int var27 = var21.getYearValue();
//     long var28 = var21.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 86400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "December 1969"+ "'", var22.equals("December 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-2649600000L));
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    java.lang.Object var1 = var0.clone();
    long var3 = var0.getTimeFromLong(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "hi!");
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
//     int var9 = var6.getColumnCount();
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
//     var11.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.axis.SegmentedTimeline var14 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var15 = var14.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var17 = var14.getSegment(604800000L);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var19 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var20 = var19.getUpperClip();
//     boolean var21 = var19.getBaseCreateEntities();
//     java.awt.Font var22 = var19.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("", var22);
//     var11.setTickLabelFont((java.lang.Comparable)var17, var22);
//     org.jfree.chart.entity.CategoryItemEntity var25 = new org.jfree.chart.entity.CategoryItemEntity(var1, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var17);
//     java.lang.String var26 = var25.toString();
//     java.lang.Comparable var27 = var25.getRowKey();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var28, 1);
//     int var31 = var28.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var32 = null;
//     var28.removeChangeListener(var32);
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D();
//     var34.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     var37.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var39);
//     java.text.NumberFormat var41 = var39.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var42 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var43 = var42.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var28, (org.jfree.chart.axis.CategoryAxis)var34, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
//     org.jfree.chart.axis.CategoryAxis var46 = var44.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis("");
//     var50.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var54 = new org.jfree.data.time.DateRange();
//     java.util.Date var55 = var54.getLowerDate();
//     java.awt.geom.Rectangle2D var56 = null;
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var50.dateToJava2D(var55, var56, var57);
//     var48.setMinimumDate(var55);
//     org.jfree.chart.axis.DateAxis var61 = new org.jfree.chart.axis.DateAxis("");
//     var61.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var65 = var61.getTickUnit();
//     java.lang.String var67 = var65.valueToString(4.0d);
//     int var68 = var65.getUnit();
//     java.lang.String var69 = var65.toString();
//     var48.setTickUnit(var65);
//     org.jfree.chart.axis.DateAxis var72 = new org.jfree.chart.axis.DateAxis("");
//     var72.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var76 = new org.jfree.data.time.DateRange();
//     java.util.Date var77 = var76.getLowerDate();
//     java.awt.geom.Rectangle2D var78 = null;
//     org.jfree.chart.util.RectangleEdge var79 = null;
//     double var80 = var72.dateToJava2D(var77, var78, var79);
//     java.lang.String var81 = var65.dateToString(var77);
//     java.awt.Font var82 = null;
//     var46.setTickLabelFont((java.lang.Comparable)var65, var82);
//     int var84 = var65.getUnit();
//     org.jfree.chart.text.TextFragment var86 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Font var87 = var86.getFont();
//     java.awt.Font var88 = var86.getFont();
//     int var89 = var65.compareTo((java.lang.Object)var86);
//     var25.setColumnKey((java.lang.Comparable)var65);
//     
//     // Checks the contract:  equals-hashcode on var6 and var28
//     assertTrue("Contract failed: equals-hashcode on var6 and var28", var6.equals(var28) ? var6.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var6
//     assertTrue("Contract failed: equals-hashcode on var28 and var6", var28.equals(var6) ? var28.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    var2.setBaseShapesVisible(false);
    var2.setAutoPopulateSeriesPaint(true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 1);
    int var10 = var7.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var11 = null;
    var7.removeChangeListener(var11);
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    var13.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
    java.text.NumberFormat var20 = var18.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var22 = var21.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, (org.jfree.chart.axis.CategoryAxis)var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    java.awt.Color var27 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var28 = var27.brighter();
    var23.setDomainGridlinePaint((java.awt.Paint)var27);
    java.awt.Paint var30 = var23.getRangeGridlinePaint();
    var2.setBasePaint(var30);
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    var33.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var35);
    java.lang.Object var37 = var35.clone();
    boolean var38 = var35.isTickLabelsVisible();
    var35.setAutoRangeMinimumSize(0.2d, false);
    boolean var42 = var35.getAutoRangeIncludesZero();
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(2.0f, 1.0f);
    var35.setDownArrow(var45);
    var2.setSeriesShape(30, var45, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     org.jfree.data.time.Year var3 = var1.getYear();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(2, var3);
//     java.lang.String var5 = var3.toString();
//     java.lang.String var6 = var3.toString();
//     long var7 = var3.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "2014"+ "'", var5.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2014"+ "'", var6.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1404331199999L);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.data.RangeType var4 = var2.getRangeType();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     double var7 = var6.getOuterSeparatorExtension();
//     var6.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     boolean var11 = var2.hasListener((java.util.EventListener)var6);
//     boolean var12 = var6.getLabelLinksVisible();
//     org.jfree.data.DefaultKeyedValues2D var14 = new org.jfree.data.DefaultKeyedValues2D(false);
//     java.util.List var15 = var14.getColumnKeys();
//     int var16 = var14.getRowCount();
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("");
//     var18.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     java.util.Date var22 = var21.getLowerDate();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var18.dateToJava2D(var22, var23, var24);
//     var14.removeValue((java.lang.Comparable)var22, (java.lang.Comparable)(-1.0d));
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("");
//     var31.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var35 = new org.jfree.data.time.DateRange();
//     java.util.Date var36 = var35.getLowerDate();
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var31.dateToJava2D(var36, var37, var38);
//     double var40 = var31.getFixedAutoRange();
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
//     var42.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var46 = var42.getTickUnit();
//     java.lang.String var48 = var46.valueToString(4.0d);
//     int var49 = var46.getUnit();
//     java.lang.String var50 = var46.toString();
//     var31.setTickUnit(var46);
//     var14.addValue((java.lang.Number)0L, (java.lang.Comparable)(-1.0f), (java.lang.Comparable)var46);
//     int var53 = var46.getUnit();
//     boolean var54 = var6.equals((java.lang.Object)var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "12/31/69 4:00 PM"+ "'", var48.equals("12/31/69 4:00 PM"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "DateTickUnit[DAY, 1]"+ "'", var50.equals("DateTickUnit[DAY, 1]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Paint var10 = var0.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    double var14 = var13.getOuterSeparatorExtension();
    double var15 = var13.getSectionDepth();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.event.ChartProgressListener var18 = null;
    var16.addProgressListener(var18);
    boolean var20 = var16.isBorderVisible();
    boolean var21 = var16.isNotify();
    var16.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, 1);
    org.jfree.data.Range var4 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    double var7 = var6.getOuterSeparatorExtension();
    double var8 = var6.getSectionDepth();
    boolean var9 = var6.getIgnoreNullValues();
    java.awt.Paint var10 = var6.getOutlinePaint();
    var6.setOuterSeparatorExtension(1.0d);
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var6);
    org.jfree.chart.urls.PieURLGenerator var14 = var6.getURLGenerator();
    java.awt.Paint var15 = var6.getNoDataMessagePaint();
    org.jfree.chart.plot.DrawingSupplier var16 = var6.getDrawingSupplier();
    var6.setLabelLinksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    var3.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    java.util.Date var8 = var7.getLowerDate();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var3.dateToJava2D(var8, var9, var10);
    var1.setMinimumDate(var8);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    var14.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    java.util.Date var18 = var17.getLowerDate();
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var14.dateToJava2D(var18, var19, var20);
    org.jfree.data.time.SimpleTimePeriod var22 = new org.jfree.data.time.SimpleTimePeriod(var8, var18);
    org.jfree.chart.renderer.category.LayeredBarRenderer var23 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var24 = var23.getUpperClip();
    boolean var25 = var23.getBaseCreateEntities();
    var23.setBase(1.0d);
    boolean var28 = var22.equals((java.lang.Object)var23);
    double var29 = var23.getItemMargin();
    var23.setBaseSeriesVisible(false);
    boolean var32 = var23.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.awt.Stroke var4 = var0.getDomainCrosshairStroke();
    org.jfree.chart.axis.AxisSpace var5 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var0.getDomainMarkers(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var9 = var0.getRangeAxisForDataset((-5478402));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    boolean var5 = var2.getItemShapeVisible((-459), 1);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var7.getPositiveItemLabelPosition(0, 2);
    org.jfree.chart.text.TextAnchor var11 = var10.getTextAnchor();
    var2.setSeriesPositiveItemLabelPosition(10, var10, false);
    var2.setSeriesShapesFilled(12, (java.lang.Boolean)false);
    boolean var17 = var2.getDrawOutlines();
    java.awt.Paint var19 = var2.getSeriesFillPaint(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    double var7 = var0.getDomainCrosshairValue();
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge();
    var0.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var4 = var3.brighter();
    java.awt.Color var5 = var3.darker();
    java.awt.Color var6 = var5.brighter();
    java.awt.color.ColorSpace var7 = var6.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var2 = new org.jfree.data.gantt.TaskSeries("UnitType.ABSOLUTE");
    org.jfree.data.gantt.Task var3 = null;
    var2.remove(var3);
    var2.fireSeriesChanged();
    var0.remove(var2);
    org.jfree.data.gantt.TaskSeries var8 = new org.jfree.data.gantt.TaskSeries("UnitType.ABSOLUTE");
    var0.add(var8);
    org.jfree.data.general.SeriesChangeEvent var10 = null;
    var0.seriesChanged(var10);
    org.jfree.data.gantt.TaskSeries var13 = var0.getSeries((java.lang.Comparable)(-2.0d));
    org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
    org.jfree.data.time.RegularTimePeriod var15 = var14.previous();
    java.lang.Object var16 = null;
    int var17 = var14.compareTo(var16);
    org.jfree.data.time.Year var18 = var14.getYear();
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    boolean var20 = var19.isRangeGridlinesVisible();
    org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var22 = var21.getUpperClip();
    boolean var23 = var21.getBaseCreateEntities();
    var21.setBase(1.0d);
    boolean var26 = var21.getAutoPopulateSeriesFillPaint();
    java.awt.Paint var29 = var21.getItemFillPaint(2, 10);
    var19.setDomainTickBandPaint(var29);
    int var31 = var18.compareTo((java.lang.Object)var19);
    org.jfree.data.time.RegularTimePeriod var32 = var18.previous();
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addDays(1, var36);
    org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addMonths(10, var37);
    org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
    var42.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var46 = new org.jfree.data.time.DateRange();
    java.util.Date var47 = var46.getLowerDate();
    java.awt.geom.Rectangle2D var48 = null;
    org.jfree.chart.util.RectangleEdge var49 = null;
    double var50 = var42.dateToJava2D(var47, var48, var49);
    var40.setMinimumDate(var47);
    org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis("");
    var53.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var56 = new org.jfree.data.time.DateRange();
    java.util.Date var57 = var56.getLowerDate();
    java.awt.geom.Rectangle2D var58 = null;
    org.jfree.chart.util.RectangleEdge var59 = null;
    double var60 = var53.dateToJava2D(var57, var58, var59);
    org.jfree.data.time.SimpleTimePeriod var61 = new org.jfree.data.time.SimpleTimePeriod(var47, var57);
    org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var47);
    org.jfree.data.time.SerialDate var63 = var38.getEndOfCurrentMonth(var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var65 = var0.getStartValue((java.lang.Comparable)var18, (java.lang.Comparable)var38, (-5478402));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }


    org.jfree.chart.renderer.category.LineRenderer3D var4 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var4.setXOffset(4.0d);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var4.getSeriesURLGenerator((-1));
    var4.setSeriesVisibleInLegend(4, (java.lang.Boolean)false, false);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    double var15 = var14.getOuterSeparatorExtension();
    java.lang.String var16 = var14.getNoDataMessage();
    java.awt.Stroke var17 = var14.getSeparatorStroke();
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var21 = new org.jfree.chart.axis.ValueAxis[] { var20};
    var18.setDomainAxes(var21);
    org.jfree.chart.axis.AxisSpace var23 = null;
    var18.setFixedDomainAxisSpace(var23);
    var18.zoom(0.0d);
    java.awt.Paint var27 = var18.getDomainTickBandPaint();
    java.awt.Paint var28 = var18.getDomainGridlinePaint();
    var14.setLabelPaint(var28);
    org.jfree.chart.util.RectangleInsets var30 = var14.getInsets();
    java.awt.Paint var31 = var14.getBaseSectionOutlinePaint();
    var4.setWallPaint(var31);
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 1.0d, 0.0d, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, Double.NaN, 10.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, 1);
//     int var8 = var5.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var9 = null;
//     var5.removeChangeListener(var9);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     var11.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var15 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Stroke var17 = var15.getSeriesOutlineStroke(1);
//     java.awt.Paint var19 = var15.lookupSeriesFillPaint((-1));
//     var13.setLabelPaint(var19);
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     var22.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var24);
//     org.jfree.data.RangeType var26 = var24.getRangeType();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
//     double var29 = var28.getOuterSeparatorExtension();
//     var28.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     boolean var33 = var24.hasListener((java.util.EventListener)var28);
//     org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange();
//     var24.setDefaultAutoRange((org.jfree.data.Range)var34);
//     org.jfree.data.Range var36 = org.jfree.data.Range.combine((org.jfree.data.Range)var21, (org.jfree.data.Range)var34);
//     var13.setRange(var36);
//     boolean var38 = var5.equals((java.lang.Object)var36);
//     double var40 = var5.getRangeUpperBound(false);
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis("");
//     var43.setRange(0.0d, 100.0d);
//     java.util.TimeZone var47 = var43.getTimeZone();
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("First", var47);
//     org.jfree.chart.axis.DateTickUnit var49 = var48.getTickUnit();
//     java.awt.Color var56 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
//     java.awt.Color var57 = var56.brighter();
//     java.awt.Color var58 = var56.darker();
//     java.lang.String var59 = var58.toString();
//     float[] var60 = null;
//     float[] var61 = var58.getComponents(var60);
//     float[] var62 = java.awt.Color.RGBtoHSB(4, (-246), 255, var61);
//     boolean var63 = var49.equals((java.lang.Object)4);
//     org.jfree.chart.title.LegendItemBlockContainer var64 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, (org.jfree.data.general.Dataset)var5, (java.lang.Comparable)var63);
//     var64.setURLText("RectangleEdge.RIGHT");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + "java.awt.Color[r=178,g=178,b=178]"+ "'", var59.equals("java.awt.Color[r=178,g=178,b=178]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     java.util.List var1 = var0.getRowKeys();
//     org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)(-2.0d));
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
//     var6.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange();
//     java.util.Date var11 = var10.getLowerDate();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var6.dateToJava2D(var11, var12, var13);
//     double var15 = var6.getFixedAutoRange();
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     var17.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var21 = var17.getTickUnit();
//     java.lang.String var23 = var21.valueToString(4.0d);
//     int var24 = var21.getUnit();
//     java.lang.String var25 = var21.toString();
//     var6.setTickUnit(var21);
//     int var27 = var21.getRollCount();
//     java.lang.String var28 = var21.toString();
//     java.lang.Number var29 = var0.getMinOutlier((java.lang.Comparable)(short)10, (java.lang.Comparable)var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var31 = var0.getRowKey(30);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "12/31/69 4:00 PM"+ "'", var23.equals("12/31/69 4:00 PM"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "DateTickUnit[DAY, 1]"+ "'", var25.equals("DateTickUnit[DAY, 1]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "DateTickUnit[DAY, 1]"+ "'", var28.equals("DateTickUnit[DAY, 1]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    java.text.DateFormat var1 = var0.getDateFormat();
    java.lang.Object var2 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    var5.setNotify(false);
    org.jfree.chart.plot.Plot var8 = var5.getPlot();
    var5.setNotify(false);
    int var11 = var5.getSubtitleCount();
    var5.setBorderVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.lang.Object var4 = var2.clone();
    var2.setAutoRange(true);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getOuterSeparatorExtension();
    double var10 = var8.getSectionDepth();
    java.awt.Paint var11 = var8.getLabelLinkPaint();
    var2.setLabelPaint(var11);
    java.awt.Font var13 = var2.getTickLabelFont();
    var2.setVisible(true);
    java.awt.Shape var16 = var2.getUpArrow();
    java.awt.Shape var17 = var2.getUpArrow();
    var2.setVisible(false);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
    double var22 = var21.getOuterSeparatorExtension();
    double var23 = var21.getLabelGap();
    org.jfree.chart.event.PlotChangeEvent var24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var21);
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot();
    var25.setIgnoreZeroValues(true);
    java.awt.Paint var28 = var25.getLabelPaint();
    var21.setLabelOutlinePaint(var28);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var31 = var30.getPadding();
    double var33 = var31.trimHeight(100.0d);
    var21.setInsets(var31);
    var2.addChangeListener((org.jfree.chart.event.AxisChangeListener)var21);
    double var36 = var21.getStartAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 90.0d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    boolean var5 = var2.getItemShapeVisible((-459), 1);
    var2.setBaseItemLabelsVisible(true, true);
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var9 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    boolean var11 = var10.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var10.setDomainAxes(var13);
    org.jfree.chart.axis.AxisSpace var15 = null;
    var10.setFixedDomainAxisSpace(var15);
    var10.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelLinkPaint();
    var10.setNoDataMessagePaint(var23);
    var9.setBasePaint(var23, false);
    org.jfree.chart.util.HorizontalAlignment var27 = null;
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var29 = null;
    java.awt.geom.Rectangle2D var30 = null;
    var28.draw(var29, var30);
    double var32 = var28.getContentYOffset();
    org.jfree.chart.util.VerticalAlignment var33 = var28.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement(var27, var33, 2.0d, 98.0d);
    org.jfree.chart.block.Block var37 = null;
    org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    var39.setAutoRange(true);
    var36.add(var37, (java.lang.Object)true);
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    var43.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var45);
    java.awt.Stroke var47 = var43.getDomainCrosshairStroke();
    boolean var48 = var36.equals((java.lang.Object)var47);
    org.jfree.data.general.PieDataset var49 = null;
    org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot(var49);
    double var51 = var50.getOuterSeparatorExtension();
    double var52 = var50.getLabelGap();
    org.jfree.chart.event.PlotChangeEvent var53 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var50);
    org.jfree.chart.plot.PiePlot var54 = new org.jfree.chart.plot.PiePlot();
    var54.setIgnoreZeroValues(true);
    java.awt.Paint var57 = var54.getLabelPaint();
    var50.setLabelOutlinePaint(var57);
    org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var60 = var59.getPadding();
    double var62 = var60.trimHeight(100.0d);
    var50.setInsets(var60);
    org.jfree.chart.block.LineBorder var64 = new org.jfree.chart.block.LineBorder(var23, var47, var60);
    var2.setBaseItemLabelPaint(var23);
    boolean var66 = var2.getUseFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     java.awt.Paint var17 = var16.getDomainGridlinePaint();
//     var16.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
//     java.awt.Stroke var20 = var16.getRangeCrosshairStroke();
//     var16.clearRangeMarkers(0);
//     var16.setRangeCrosshairVisible(false);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
//     java.awt.Image var27 = var26.getBackgroundImage();
//     var26.removeLegend();
//     org.jfree.chart.util.RectangleInsets var29 = var26.getPadding();
//     var16.addChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
//     
//     // Checks the contract:  equals-hashcode on var25 and var9
//     assertTrue("Contract failed: equals-hashcode on var25 and var9", var25.equals(var9) ? var25.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var25 and var9.", var25.equals(var9) == var9.equals(var25));
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var0.removeChangeListener(var2);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    var4.draw(var5, var6);
    var4.setNotify(false);
    java.lang.String var10 = var4.getText();
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.category.LayeredBarRenderer var13 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var14 = var13.getUpperClip();
    boolean var15 = var13.getBaseCreateEntities();
    java.awt.Font var16 = var13.getBaseItemLabelFont();
    var12.setAngleLabelFont(var16);
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    var18.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var20);
    org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var24 = var22.getSeriesOutlineStroke(1);
    java.awt.Paint var26 = var22.lookupSeriesFillPaint((-1));
    var20.setLabelPaint(var26);
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var16, var26);
    org.jfree.chart.util.HorizontalAlignment var29 = var28.getLineAlignment();
    var4.setTextAlignment(var29);
    var0.setHorizontalAlignment(var29);
    var0.setID("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }


    org.jfree.chart.entity.EntityCollection var4 = null;
    org.jfree.chart.ChartRenderingInfo var5 = new org.jfree.chart.ChartRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getChartArea();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
    var10.setRenderAsPercentages(true);
    java.awt.Paint var13 = var10.getWallPaint();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var15 = var14.getBackgroundPaint();
    org.jfree.chart.renderer.category.LayeredBarRenderer var17 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var18 = var17.getUpperClip();
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    boolean var20 = var19.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var22 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var19.setDomainAxes(var22);
    org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
    boolean var25 = var17.equals((java.lang.Object)var24);
    var14.setRangeAxisLocation(10, var24, true);
    boolean var28 = var14.isRangeCrosshairLockedOnData();
    boolean var29 = var10.equals((java.lang.Object)var14);
    boolean var30 = var14.isDomainZoomable();
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
    double var33 = var32.getOuterSeparatorExtension();
    double var34 = var32.getSectionDepth();
    java.awt.Paint var35 = var32.getLabelLinkPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var36 = null;
    var32.setLegendLabelToolTipGenerator(var36);
    boolean var38 = var32.isSubplot();
    java.awt.Paint var39 = var32.getSeparatorPaint();
    var14.setRangeCrosshairPaint(var39);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "AreaRendererEndType.TAPER", "DateTickUnit[DAY, 1]", "XY Plot", (java.awt.Shape)var6, var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    double var11 = var10.getOuterSeparatorExtension();
    var10.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
    double var17 = var16.getOuterSeparatorExtension();
    double var18 = var16.getSectionDepth();
    java.awt.Paint var19 = var16.getLabelPaint();
    var10.setLabelLinkPaint(var19);
    var0.setParent((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.event.RendererChangeEvent var22 = null;
    var0.rendererChanged(var22);
    org.jfree.chart.util.RectangleInsets var24 = var0.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    java.lang.String var3 = var2.getPlotType();
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    var2.setRenderer(var4);
    org.jfree.data.general.WaferMapDataset var6 = null;
    var2.setDataset(var6);
    java.lang.String var8 = var2.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "WMAP_Plot"+ "'", var3.equals("WMAP_Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "WMAP_Plot"+ "'", var8.equals("WMAP_Plot"));

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var1 = var0.getBaseShapesFilled();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, 1);
    int var5 = var2.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var6 = null;
    var2.removeChangeListener(var6);
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
    var8.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    var11.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var13);
    java.text.NumberFormat var15 = var13.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var16 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var17 = var16.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.data.general.PieDataset var20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, (java.lang.Comparable)0.5f);
    java.util.List var21 = var2.getColumnKeys();
    boolean var22 = var0.equals((java.lang.Object)var2);
    var0.setYOffset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, 1);
    int var4 = var1.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var5 = null;
    var1.removeChangeListener(var5);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    var7.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    var10.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var12);
    java.text.NumberFormat var14 = var12.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var15 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var16 = var15.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var21 = var20.getAlpha();
    org.jfree.chart.util.Layer var22 = null;
    var17.addRangeMarker(10, (org.jfree.chart.plot.Marker)var20, var22);
    org.jfree.chart.axis.AxisLocation var24 = var17.getRangeAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var17.getRangeAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var26 = var17.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
    var29.setCategoryLabelPositions(var31);
    var17.setDomainAxis(1, var29);
    org.jfree.chart.axis.CategoryAxis var34 = var17.getDomainAxis();
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("DateTickUnit[DAY, 1]", (org.jfree.chart.plot.Plot)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    boolean var1 = var0.isDrawLines();
    javax.swing.Icon var2 = var0.getObjectIcon();
    var0.setDrawLines(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue(var0, (java.lang.Number)(short)1);
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Stroke var5 = var3.getAngleGridlineStroke();
//     org.jfree.data.xy.XYDataset var6 = var3.getDataset();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getOuterSeparatorExtension();
//     java.lang.String var10 = var8.getNoDataMessage();
//     java.awt.Stroke var11 = var8.getSeparatorStroke();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     boolean var13 = var12.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var14};
//     var12.setDomainAxes(var15);
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var12.setFixedDomainAxisSpace(var17);
//     var12.zoom(0.0d);
//     java.awt.Paint var21 = var12.getDomainTickBandPaint();
//     java.awt.Paint var22 = var12.getDomainGridlinePaint();
//     var8.setLabelPaint(var22);
//     org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder(var22);
//     var3.setAngleGridlinePaint(var22);
//     boolean var26 = var2.equals((java.lang.Object)var22);
//     java.lang.Comparable var27 = var2.getKey();
//     java.lang.Comparable var28 = var2.getKey();
//     java.lang.String var29 = var2.toString();
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    var2.setBaseShapesVisible(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
    var2.setSeriesVisible(15, (java.lang.Boolean)false, false);
    boolean var12 = var2.getItemLineVisible((-245), 5);
    var2.setBaseItemLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("");
//     var2.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange();
//     java.util.Date var7 = var6.getLowerDate();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var2.dateToJava2D(var7, var8, var9);
//     double var11 = var2.getFixedAutoRange();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     var13.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var17 = var13.getTickUnit();
//     java.lang.String var19 = var17.valueToString(4.0d);
//     int var20 = var17.getUnit();
//     java.lang.String var21 = var17.toString();
//     var2.setTickUnit(var17);
//     int var23 = var17.getRollCount();
//     java.lang.String var24 = var17.toString();
//     int var25 = var17.getRollUnit();
//     int var26 = var0.getIndex((java.lang.Comparable)var17);
//     int var27 = var0.getItemCount();
//     java.lang.Comparable var28 = null;
//     org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
//     double var30 = var29.getRight();
//     java.lang.String var31 = var29.toString();
//     var0.addObject(var28, (java.lang.Object)var29);
//     org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("");
//     var34.setLowerBound(0.0d);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var37 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var38 = var37.getUpperClip();
//     boolean var39 = var37.getBaseCreateEntities();
//     var37.setBase(1.0d);
//     java.awt.Shape var42 = var37.getBaseShape();
//     org.jfree.chart.entity.AxisLabelEntity var45 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var34, var42, "", "RangeType.FULL");
//     org.jfree.chart.axis.SegmentedTimeline var46 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var47 = var46.getSegmentSize();
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("");
//     var49.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var53 = new org.jfree.data.time.DateRange();
//     java.util.Date var54 = var53.getLowerDate();
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var49.dateToJava2D(var54, var55, var56);
//     boolean var58 = var46.containsDomainValue(var54);
//     var34.setMaximumDate(var54);
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(var54);
//     org.jfree.data.general.PieDataset var61 = null;
//     org.jfree.chart.plot.RingPlot var62 = new org.jfree.chart.plot.RingPlot(var61);
//     double var63 = var62.getOuterSeparatorExtension();
//     double var64 = var62.getLabelGap();
//     org.jfree.chart.event.PlotChangeEvent var65 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var62);
//     org.jfree.chart.plot.PiePlot var66 = new org.jfree.chart.plot.PiePlot();
//     var66.setIgnoreZeroValues(true);
//     java.awt.Paint var69 = var66.getLabelPaint();
//     var62.setLabelOutlinePaint(var69);
//     org.jfree.chart.title.TextTitle var71 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var72 = var71.getPadding();
//     double var74 = var72.trimHeight(100.0d);
//     var62.setInsets(var72);
//     org.jfree.data.general.PieDataset var76 = null;
//     org.jfree.chart.plot.RingPlot var77 = new org.jfree.chart.plot.RingPlot(var76);
//     boolean var78 = var77.isCircular();
//     org.jfree.chart.labels.PieSectionLabelGenerator var79 = var77.getLabelGenerator();
//     var62.setLegendLabelToolTipGenerator(var79);
//     var62.setMinimumArcAngleToDraw(3.0d);
//     var0.setObject((java.lang.Comparable)var54, (java.lang.Object)3.0d);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    java.awt.Paint var1 = var0.getPositiveBarPaint();
    java.awt.Paint var2 = var0.getLastBarPaint();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var4 = var3.getLabelFont();
    var3.setAutoRangeMinimumSize(100.0d, true);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    double var10 = var9.getOuterSeparatorExtension();
    java.lang.String var11 = var9.getNoDataMessage();
    java.awt.Stroke var12 = var9.getSeparatorStroke();
    var3.setAxisLineStroke(var12);
    var3.zoomRange(0.0d, 0.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var17, 1);
    int var20 = var17.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var21 = null;
    var17.removeChangeListener(var21);
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
    var23.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    var26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
    java.text.NumberFormat var30 = var28.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var31 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var32 = var31.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    org.jfree.chart.axis.CategoryAxis var35 = var33.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var36 = var33.getRangeAxisLocation();
    org.jfree.chart.plot.Plot var37 = var33.getRootPlot();
    org.jfree.chart.axis.CategoryAnchor var38 = var33.getDomainGridlinePosition();
    var33.mapDatasetToDomainAxis(1, (-1));
    org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot();
    java.lang.Object var43 = var42.clone();
    java.awt.Stroke var44 = var42.getAngleGridlineStroke();
    org.jfree.data.xy.XYDataset var45 = var42.getDataset();
    org.jfree.data.general.PieDataset var46 = null;
    org.jfree.chart.plot.RingPlot var47 = new org.jfree.chart.plot.RingPlot(var46);
    double var48 = var47.getOuterSeparatorExtension();
    java.lang.String var49 = var47.getNoDataMessage();
    java.awt.Stroke var50 = var47.getSeparatorStroke();
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
    boolean var52 = var51.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var54 = new org.jfree.chart.axis.ValueAxis[] { var53};
    var51.setDomainAxes(var54);
    org.jfree.chart.axis.AxisSpace var56 = null;
    var51.setFixedDomainAxisSpace(var56);
    var51.zoom(0.0d);
    java.awt.Paint var60 = var51.getDomainTickBandPaint();
    java.awt.Paint var61 = var51.getDomainGridlinePaint();
    var47.setLabelPaint(var61);
    org.jfree.chart.block.BlockBorder var63 = new org.jfree.chart.block.BlockBorder(var61);
    var42.setAngleGridlinePaint(var61);
    var33.setDomainGridlinePaint(var61);
    var3.setLabelPaint(var61);
    var0.setPositiveBarPaint(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    var0.draw(var2, var3);
    var0.setToolTipText("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    var8.clearDomainMarkers();
    boolean var10 = var7.equals((java.lang.Object)var8);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var8.zoomDomainAxes(1.0E-8d, (-1.0d), var13, var14);
    org.jfree.chart.util.RectangleEdge var16 = var8.getRangeAxisEdge();
    var0.setPosition(var16);
    org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(0.0d, (-2.0d), Double.NaN, 1.0d);
    var0.setFrame((org.jfree.chart.block.BlockFrame)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var3 = var2.getWidthType();
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var5 = var4.getWidthType();
    double var6 = var4.getAngle();
    float var7 = var4.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var9 = var8.getWidthType();
    double var10 = var8.getAngle();
    org.jfree.chart.util.RectangleAnchor var11 = var8.getCategoryAnchor();
    float var12 = var8.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelPosition var13 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var14 = var13.getWidthType();
    double var15 = var13.getAngle();
    float var16 = var13.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelPositions var17 = new org.jfree.chart.axis.CategoryLabelPositions(var2, var4, var8, var13);
    org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var2);
    java.lang.Object var19 = null;
    boolean var20 = var2.equals(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var1 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var2 = var1.getUpperClip();
//     boolean var3 = var1.getBaseCreateEntities();
//     var1.setBase(1.0d);
//     java.awt.Font var6 = var1.getBaseItemLabelFont();
//     org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(0.25d, (-2.0d));
//     java.awt.Paint var10 = var9.getWallPaint();
//     org.jfree.chart.text.TextLine var11 = new org.jfree.chart.text.TextLine("CategoryAnchor.MIDDLE", var6, var10);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     var13.setLowerBound(0.0d);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var16 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var17 = var16.getUpperClip();
//     boolean var18 = var16.getBaseCreateEntities();
//     var16.setBase(1.0d);
//     java.awt.Shape var21 = var16.getBaseShape();
//     org.jfree.chart.entity.AxisLabelEntity var24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var13, var21, "", "RangeType.FULL");
//     var13.setAxisLineVisible(true);
//     java.text.DateFormat var27 = null;
//     var13.setDateFormatOverride(var27);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     var30.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange();
//     java.util.Date var35 = var34.getLowerDate();
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var30.dateToJava2D(var35, var36, var37);
//     double var39 = var30.getFixedAutoRange();
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     var41.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var45 = var41.getTickUnit();
//     java.lang.String var47 = var45.valueToString(4.0d);
//     int var48 = var45.getUnit();
//     java.lang.String var49 = var45.toString();
//     var30.setTickUnit(var45);
//     int var51 = var45.getRollCount();
//     java.lang.String var52 = var45.toString();
//     org.jfree.chart.axis.SegmentedTimeline var56 = new org.jfree.chart.axis.SegmentedTimeline(1577894400001L, 0, 0);
//     java.util.Date var58 = var56.getDate((-2208960000000L));
//     org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis("");
//     var62.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var66 = new org.jfree.data.time.DateRange();
//     java.util.Date var67 = var66.getLowerDate();
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.util.RectangleEdge var69 = null;
//     double var70 = var62.dateToJava2D(var67, var68, var69);
//     var60.setMinimumDate(var67);
//     org.jfree.chart.axis.DateAxis var73 = new org.jfree.chart.axis.DateAxis("");
//     var73.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var76 = new org.jfree.data.time.DateRange();
//     java.util.Date var77 = var76.getLowerDate();
//     java.awt.geom.Rectangle2D var78 = null;
//     org.jfree.chart.util.RectangleEdge var79 = null;
//     double var80 = var73.dateToJava2D(var77, var78, var79);
//     org.jfree.data.time.SimpleTimePeriod var81 = new org.jfree.data.time.SimpleTimePeriod(var67, var77);
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.createInstance(var67);
//     org.jfree.chart.axis.DateAxis var84 = new org.jfree.chart.axis.DateAxis("");
//     var84.setRange(0.0d, 100.0d);
//     java.util.TimeZone var88 = var84.getTimeZone();
//     org.jfree.data.time.Month var89 = new org.jfree.data.time.Month(var67, var88);
//     java.util.Date var90 = var45.rollDate(var58, var88);
//     var13.setTimeZone(var88);
//     boolean var92 = var11.equals((java.lang.Object)var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "12/31/69 4:00 PM"+ "'", var47.equals("12/31/69 4:00 PM"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "DateTickUnit[DAY, 1]"+ "'", var49.equals("DateTickUnit[DAY, 1]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "DateTickUnit[DAY, 1]"+ "'", var52.equals("DateTickUnit[DAY, 1]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    java.awt.Paint var17 = var16.getDomainGridlinePaint();
    var16.configureRangeAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
    boolean var20 = var16.isOutlineVisible();
    var16.setWeight(0);
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Paint var25 = var24.getPaint();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var27 = var26.getPadding();
    var24.setLabelOffset(var27);
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
    double var31 = var30.getOuterSeparatorExtension();
    double var32 = var30.getLabelGap();
    org.jfree.chart.util.ShapeList var37 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var37.setShape(100, var40);
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
    boolean var43 = var42.isRangeGridlinesVisible();
    var42.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var47 = null;
    java.util.Collection var48 = var42.getDomainMarkers(100, var47);
    org.jfree.data.xy.XYDataset var49 = null;
    int var50 = var42.indexOf(var49);
    java.awt.Stroke var51 = var42.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var52 = null;
    org.jfree.chart.plot.RingPlot var53 = new org.jfree.chart.plot.RingPlot(var52);
    double var54 = var53.getOuterSeparatorExtension();
    double var55 = var53.getSectionDepth();
    java.awt.Paint var56 = var53.getLabelPaint();
    org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var40, var51, var56);
    var30.setLabelShadowPaint(var56);
    org.jfree.chart.plot.PlotRenderingInfo var61 = null;
    var30.handleClick(0, (-1), var61);
    double var63 = var30.getSectionDepth();
    var24.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var30);
    boolean var65 = var16.equals((java.lang.Object)var24);
    boolean var66 = var16.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.AxisLocation var67 = var16.getRangeAxisLocation();
    java.lang.String var68 = var16.getPlotType();
    org.jfree.chart.axis.AxisLocation var69 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setRangeAxisLocation(var69);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + "Category Plot"+ "'", var68.equals("Category Plot"));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = null;
    int var3 = var0.getRangeAxisIndex(var2);
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation(10);
    int var6 = var0.getWeight();
    var0.clearDomainMarkers(15);
    var0.setRangeCrosshairVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    var5.setNotify(false);
    org.jfree.chart.plot.Plot var8 = var5.getPlot();
    var5.setNotify(false);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    var11.draw(var12, var13);
    var11.setNotify(false);
    java.lang.Object var17 = var11.clone();
    org.jfree.chart.util.RectangleEdge var18 = var11.getPosition();
    double var19 = var11.getContentYOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setTextAntiAlias((java.lang.Object)var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    var0.setNotify(false);
    java.lang.String var6 = var0.getText();
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.category.LayeredBarRenderer var9 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var10 = var9.getUpperClip();
    boolean var11 = var9.getBaseCreateEntities();
    java.awt.Font var12 = var9.getBaseItemLabelFont();
    var8.setAngleLabelFont(var12);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    var14.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.renderer.category.LayeredBarRenderer var18 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var20 = var18.getSeriesOutlineStroke(1);
    java.awt.Paint var22 = var18.lookupSeriesFillPaint((-1));
    var16.setLabelPaint(var22);
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var12, var22);
    org.jfree.chart.util.HorizontalAlignment var25 = var24.getLineAlignment();
    var0.setTextAlignment(var25);
    var0.setURLText("Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var1 = var0.getUpperClip();
    var0.setBase(0.05d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, Double.NaN, 10.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.util.List var6 = var5.getBlocks();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    org.jfree.chart.urls.PieURLGenerator var9 = var8.getURLGenerator();
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8);
    org.jfree.chart.block.BlockContainer var11 = var10.getItemContainer();
    org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var14 = var13.getToolTipText();
    java.awt.Font var15 = var13.getFont();
    java.lang.Object var16 = var13.clone();
    org.jfree.chart.util.RectangleInsets var17 = var13.getMargin();
    java.awt.Font var18 = var13.getFont();
    var10.setItemFont(var18);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
    double var22 = var21.getOuterSeparatorExtension();
    double var23 = var21.getLabelGap();
    org.jfree.chart.event.PlotChangeEvent var24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var21);
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot();
    var25.setIgnoreZeroValues(true);
    java.awt.Paint var28 = var25.getLabelPaint();
    var21.setLabelOutlinePaint(var28);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var31 = var30.getPadding();
    double var33 = var31.trimHeight(100.0d);
    var21.setInsets(var31);
    var5.add((org.jfree.chart.block.Block)var10, (java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 98.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(1577894400001L, 12, 10);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 1);
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var4, true);
    java.util.List var9 = var4.getColumnKeys();
    var3.setExceptionSegments(var9);
    var3.addException((-2649600000L));
    boolean var13 = var3.getAdjustForDaylightSaving();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    java.awt.Color var12 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var13 = var12.brighter();
    java.awt.Color var14 = var12.darker();
    java.awt.Color var15 = var12.brighter();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("First", "First", "Multiple Pie Plot", "February", var7, (java.awt.Paint)var15);
    java.awt.Stroke var17 = var16.getOutlineStroke();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var18, 1);
    int var21 = var18.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var22 = null;
    var18.removeChangeListener(var22);
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
    var24.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
    var27.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var29);
    java.text.NumberFormat var31 = var29.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var32 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var33 = var32.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var18, (org.jfree.chart.axis.CategoryAxis)var24, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
    org.jfree.chart.axis.CategoryAxis var36 = var34.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var37 = var34.getRangeAxisLocation();
    org.jfree.chart.axis.AxisSpace var38 = var34.getFixedRangeAxisSpace();
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    boolean var40 = var39.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var41};
    var39.setDomainAxes(var42);
    org.jfree.chart.axis.AxisLocation var44 = var39.getDomainAxisLocation();
    var34.setRangeAxisLocation(var44, false);
    boolean var47 = var16.equals((java.lang.Object)var44);
    boolean var48 = var16.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
    var1.setLabelOffset(var4);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    double var8 = var7.getOuterSeparatorExtension();
    double var9 = var7.getLabelGap();
    org.jfree.chart.util.ShapeList var14 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var14.setShape(100, var17);
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    boolean var20 = var19.isRangeGridlinesVisible();
    var19.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var24 = null;
    java.util.Collection var25 = var19.getDomainMarkers(100, var24);
    org.jfree.data.xy.XYDataset var26 = null;
    int var27 = var19.indexOf(var26);
    java.awt.Stroke var28 = var19.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.RingPlot var30 = new org.jfree.chart.plot.RingPlot(var29);
    double var31 = var30.getOuterSeparatorExtension();
    double var32 = var30.getSectionDepth();
    java.awt.Paint var33 = var30.getLabelPaint();
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var17, var28, var33);
    var7.setLabelShadowPaint(var33);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    var7.handleClick(0, (-1), var38);
    double var40 = var7.getSectionDepth();
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var7);
    org.jfree.chart.util.RectangleAnchor var42 = var1.getLabelAnchor();
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 0.5f);
    boolean var46 = var1.equals((java.lang.Object)0.5f);
    org.jfree.chart.text.TextAnchor var47 = var1.getLabelTextAnchor();
    org.jfree.chart.renderer.category.LayeredBarRenderer var48 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var49 = var48.getUpperClip();
    java.awt.Stroke var52 = var48.getItemStroke((-459), (-459));
    boolean var53 = var48.getBaseSeriesVisible();
    int var54 = var48.getColumnCount();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    org.jfree.chart.urls.StandardCategoryURLGenerator var59 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    var57.setSeriesURLGenerator(10, (org.jfree.chart.urls.CategoryURLGenerator)var59);
    var48.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var59, true);
    boolean var63 = var47.equals((java.lang.Object)var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var4 = var3.getLabelFont();
//     var3.setAutoRangeMinimumSize(100.0d, true);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     double var10 = var9.getOuterSeparatorExtension();
//     java.lang.String var11 = var9.getNoDataMessage();
//     java.awt.Stroke var12 = var9.getSeparatorStroke();
//     var3.setAxisLineStroke(var12);
//     var0.setStroke(1, var12);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, 1);
//     int var18 = var15.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var19 = null;
//     var15.removeChangeListener(var19);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     var21.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     var24.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var26);
//     java.text.NumberFormat var28 = var26.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var29 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var30 = var29.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, (org.jfree.chart.axis.CategoryAxis)var21, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
//     java.awt.Paint var32 = var31.getDomainGridlinePaint();
//     var31.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var34 = var31.getDatasetRenderingOrder();
//     java.awt.Stroke var35 = var31.getRangeCrosshairStroke();
//     var31.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var38 = var31.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     var39.setUpperMargin(98.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var42 = var39.getCategoryLabelPositions();
//     int var43 = var31.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var39);
//     boolean var44 = var0.equals((java.lang.Object)var31);
//     var31.setRangeCrosshairValue(10.0d);
//     boolean var47 = var31.isRangeCrosshairVisible();
//     var31.clearRangeAxes();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var49 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var51 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var49, 1);
//     int var52 = var49.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var53 = null;
//     var49.removeChangeListener(var53);
//     org.jfree.chart.axis.CategoryAxis3D var55 = new org.jfree.chart.axis.CategoryAxis3D();
//     var55.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     var58.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var60);
//     java.text.NumberFormat var62 = var60.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var63 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var64 = var63.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var49, (org.jfree.chart.axis.CategoryAxis)var55, (org.jfree.chart.axis.ValueAxis)var60, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
//     java.awt.Paint var66 = var65.getDomainGridlinePaint();
//     var65.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var68 = var65.getDatasetRenderingOrder();
//     boolean var69 = var65.isOutlineVisible();
//     org.jfree.data.category.CategoryDataset var70 = null;
//     var65.setDataset(var70);
//     boolean var72 = var65.isRangeCrosshairVisible();
//     org.jfree.chart.LegendItemCollection var73 = var65.getFixedLegendItems();
//     var65.setRangeCrosshairValue(100.0d, true);
//     org.jfree.chart.axis.AxisLocation var78 = var65.getRangeAxisLocation((-1));
//     var31.setRangeAxisLocation(var78, false);
//     
//     // Checks the contract:  equals-hashcode on var15 and var49
//     assertTrue("Contract failed: equals-hashcode on var15 and var49", var15.equals(var49) ? var15.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var15
//     assertTrue("Contract failed: equals-hashcode on var49 and var15", var49.equals(var15) ? var49.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var58
//     assertTrue("Contract failed: equals-hashcode on var24 and var58", var24.equals(var58) ? var24.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var24
//     assertTrue("Contract failed: equals-hashcode on var58 and var24", var58.equals(var24) ? var58.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Paint var10 = var0.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    double var14 = var13.getOuterSeparatorExtension();
    double var15 = var13.getSectionDepth();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    java.awt.Image var18 = var16.getBackgroundImage();
    java.util.List var19 = var16.getSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var5 = var4.getUpperClip();
    boolean var6 = var4.getBaseCreateEntities();
    var4.setBase(1.0d);
    java.awt.Shape var9 = var4.getBaseShape();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    org.jfree.chart.urls.PieURLGenerator var12 = var11.getURLGenerator();
    java.awt.Stroke var13 = var11.getBaseSectionOutlineStroke();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    boolean var15 = var14.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var17 = new org.jfree.chart.axis.ValueAxis[] { var16};
    var14.setDomainAxes(var17);
    org.jfree.chart.axis.AxisSpace var19 = null;
    var14.setFixedDomainAxisSpace(var19);
    var14.zoom(0.0d);
    java.awt.Paint var23 = var14.getDomainTickBandPaint();
    java.awt.Paint var24 = var14.getDomainGridlinePaint();
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "hi!", "poly", "DateTickUnit[DAY, 1]", var9, var13, var24);
    java.awt.Shape var26 = var25.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     var1.setLowerBound(0.0d);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var5 = var4.getUpperClip();
//     boolean var6 = var4.getBaseCreateEntities();
//     var4.setBase(1.0d);
//     java.awt.Shape var9 = var4.getBaseShape();
//     org.jfree.chart.entity.AxisLabelEntity var12 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var9, "", "RangeType.FULL");
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
//     var14.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var18 = var14.getTickUnit();
//     java.lang.String var20 = var18.valueToString(4.0d);
//     int var21 = var18.getUnit();
//     var1.setTickUnit(var18, false, false);
//     java.awt.Shape var25 = var1.getLeftArrow();
//     org.jfree.chart.axis.DateTickMarkPosition var26 = var1.getTickMarkPosition();
//     java.lang.String var27 = var26.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "12/31/69 4:00 PM"+ "'", var20.equals("12/31/69 4:00 PM"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "DateTickMarkPosition.START"+ "'", var27.equals("DateTickMarkPosition.START"));
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.urls.PieURLGenerator var2 = var1.getURLGenerator();
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.block.BlockContainer var4 = var3.getItemContainer();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var6.setLabel("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.util.RectangleAnchor var9 = var6.getLabelAnchor();
    var3.setLegendItemGraphicAnchor(var9);
    java.awt.Graphics2D var11 = null;
    org.jfree.data.Range var13 = null;
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(10.0d, var13);
    org.jfree.data.time.DateRange var15 = new org.jfree.data.time.DateRange();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange((org.jfree.data.Range)var15);
    org.jfree.chart.block.RectangleConstraint var17 = var14.toRangeHeight((org.jfree.data.Range)var15);
    org.jfree.chart.util.Size2D var18 = var3.arrange(var11, var14);
    boolean var19 = var3.getNotify();
    org.jfree.chart.util.RectangleAnchor var20 = var3.getLegendItemGraphicAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    var3.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    java.util.Date var8 = var7.getLowerDate();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var3.dateToJava2D(var8, var9, var10);
    var1.setMinimumDate(var8);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    var14.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    java.util.Date var18 = var17.getLowerDate();
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var14.dateToJava2D(var18, var19, var20);
    org.jfree.data.time.SimpleTimePeriod var22 = new org.jfree.data.time.SimpleTimePeriod(var8, var18);
    org.jfree.chart.renderer.category.LayeredBarRenderer var23 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var24 = var23.getUpperClip();
    boolean var25 = var23.getBaseCreateEntities();
    var23.setBase(1.0d);
    boolean var28 = var22.equals((java.lang.Object)var23);
    java.util.Date var29 = var22.getEnd();
    java.util.Date var30 = var22.getEnd();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    boolean var5 = var2.getItemShapeVisible((-459), 1);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var7.getPositiveItemLabelPosition(0, 2);
    org.jfree.chart.text.TextAnchor var11 = var10.getTextAnchor();
    var2.setSeriesPositiveItemLabelPosition(10, var10, false);
    org.jfree.chart.text.TextAnchor var14 = var10.getTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.lang.Object var4 = var2.clone();
    boolean var5 = var2.isTickLabelsVisible();
    var2.setAutoRangeMinimumSize(0.2d, false);
    boolean var9 = var2.getAutoRangeIncludesZero();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(2.0f, 1.0f);
    var2.setDownArrow(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    org.jfree.chart.axis.AxisLocation var10 = var0.getDomainAxisLocation(1);
    var0.setRangeZeroBaselineVisible(false);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    var14.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var16);
    java.text.NumberFormat var18 = var16.getNumberFormatOverride();
    boolean var19 = var16.isAxisLineVisible();
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var13, (org.jfree.chart.axis.ValueAxis)var16, var20);
    org.jfree.chart.LegendItemCollection var22 = var21.getLegendItems();
    var0.setFixedLegendItems(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    java.awt.Paint var17 = var16.getDomainGridlinePaint();
    var16.configureRangeAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
    java.awt.Stroke var20 = var16.getRangeCrosshairStroke();
    var16.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var23 = var16.getColumnRenderingOrder();
    org.jfree.data.category.CategoryDataset var25 = var16.getDataset(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    java.lang.String var25 = var24.getURLText();
    java.lang.String var26 = var24.getLabel();
    java.awt.Paint var27 = var24.getFillPaint();
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(2);
    var24.setSeriesKey((java.lang.Comparable)2);
    boolean var31 = var24.isShapeFilled();
    java.lang.String var32 = var24.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "hi!"+ "'", var25.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + ""+ "'", var26.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + ""+ "'", var32.equals(""));

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseCreateEntities();
    java.awt.Font var3 = var0.getBaseItemLabelFont();
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var4 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator)var4, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var8.setBaseSeriesVisible(false, false);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    double var15 = var14.getOuterSeparatorExtension();
    double var16 = var14.getSectionDepth();
    java.awt.Paint var17 = var14.getLabelPaint();
    var8.setSeriesOutlinePaint(0, var17, false);
    var0.setSeriesFillPaint(0, var17);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var23, 1);
    int var26 = var23.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var27 = null;
    var23.removeChangeListener(var27);
    org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D();
    var29.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    var32.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var34);
    java.text.NumberFormat var36 = var34.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var37 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var38 = var37.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, (org.jfree.chart.axis.CategoryAxis)var29, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
    org.jfree.chart.axis.CategoryAxis var41 = var39.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var42 = var39.getRangeAxisLocation();
    org.jfree.chart.axis.AxisSpace var43 = var39.getFixedRangeAxisSpace();
    org.jfree.chart.renderer.category.LayeredBarRenderer var44 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var45 = var44.getUpperClip();
    java.awt.Stroke var48 = var44.getItemStroke((-459), (-459));
    var39.setDomainGridlineStroke(var48);
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var52 = var0.initialise(var21, var22, var39, 4, var51);
    java.awt.Stroke var53 = var39.getRangeGridlineStroke();
    org.jfree.chart.renderer.category.StackedAreaRenderer var54 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
    boolean var56 = var55.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var58 = new org.jfree.chart.axis.ValueAxis[] { var57};
    var55.setDomainAxes(var58);
    org.jfree.chart.axis.AxisSpace var60 = null;
    var55.setFixedDomainAxisSpace(var60);
    var55.zoom(0.0d);
    java.awt.Paint var64 = var55.getDomainTickBandPaint();
    java.awt.Paint var65 = var55.getDomainGridlinePaint();
    boolean var66 = var54.hasListener((java.util.EventListener)var55);
    var54.setSeriesVisible(0, (java.lang.Boolean)true, true);
    var54.setSeriesItemLabelsVisible(10, true);
    var39.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var54, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

}
