
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.isCircular();
    org.jfree.chart.block.Arrangement var3 = null;
    org.jfree.chart.block.Arrangement var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(10, var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)1, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, 100.0d, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("", var1);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var3 = var2.getBackgroundPaint();
//     boolean var4 = org.jfree.chart.util.PaintUtilities.equal(var1, var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var2 = var0.getDataset((-1));
    java.awt.Stroke var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeCrosshairStroke(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.plot.SeriesRenderingOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesRenderingOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.awt.Paint var0 = null;
    java.awt.Stroke var1 = null;
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var3 = var2.getPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder(var0, var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange(var0);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.Range var3 = null;
//     org.jfree.data.Range var4 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(var3, var4);
//     org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var2, var5);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlineStroke(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    java.awt.Paint var5 = var2.getLabelPaint();
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryMarker var7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(short)100, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    java.awt.Stroke var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var11 = var10.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem(var0, "", "", "hi!", var7, var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    java.lang.String var3 = var1.getNoDataMessage();
    java.awt.Stroke var5 = var1.getSectionOutlineStroke((java.lang.Comparable)100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    java.awt.geom.Point2D var2 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var1);
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    java.awt.Paint var5 = var2.getLabelLinkPaint();
    java.awt.Stroke var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, 100.0d, 0.0f, 1.0f);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var1 = var0.getLabelFont();
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelPaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-1.0d), 0.05d, (-1), (java.lang.Comparable)(byte)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.annotations.XYAnnotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var3 = var0.removeAnnotation(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getLabelGap();
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExplodePercent(var4, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.lang.Object var5 = var1.draw(var2, var3, (java.lang.Object)(short)(-1));
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
    java.lang.Number[] var2 = null;
    java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
    java.lang.Number[] var4 = null;
    java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var0, (java.lang.Comparable[])var1, var3, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    double var11 = var10.getOuterSeparatorExtension();
    double var12 = var10.getSectionDepth();
    java.awt.Paint var13 = var10.getLabelLinkPaint();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    boolean var15 = var14.isRangeGridlinesVisible();
    var14.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var14.getDomainMarkers(100, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    int var22 = var14.indexOf(var21);
    java.awt.Stroke var23 = var14.getRangeGridlineStroke();
    org.jfree.chart.renderer.category.LayeredBarRenderer var24 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var26 = var24.getSeriesOutlineStroke(1);
    java.awt.Paint var28 = var24.lookupSeriesFillPaint((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "hi!", var7, var13, var23, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var3 = var1.createOutsetRectangle(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 0);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var1.createOutsetRectangle(var2, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
//     var4.setLicenceName("");
//     org.jfree.chart.ui.Library var7 = null;
//     var4.addLibrary(var7);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var2 = var0.getSeriesOutlineStroke(1);
    var0.setDrawBarOutline(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesBarWidth((-1), 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     var0.configureRangeAxes();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var5);
//     java.awt.Stroke var7 = var3.getDomainCrosshairStroke();
//     var0.setDomainCrosshairStroke(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    var6.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var8);
    java.lang.Object var10 = var8.clone();
    var8.setAutoRange(true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var13, 1);
    int var16 = var13.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var3, var4, var5, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.data.category.CategoryDataset)var13, 0, 0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    boolean var4 = var3.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var6 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var3.setDomainAxes(var6);
    org.jfree.chart.axis.AxisLocation var8 = var3.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var2 = var1.getTop();
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var4 = var1.createOutsetRectangle(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 10.0f);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var3 = var1.createInsetRectangle(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getSectionDepth();
    java.awt.Paint var4 = var1.getLabelPaint();
    java.awt.Graphics2D var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getOuterSeparatorExtension();
    double var10 = var8.getSectionDepth();
    boolean var11 = var8.getIgnoreNullValues();
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var14 = var1.initialise(var5, var6, (org.jfree.chart.plot.PiePlot)var8, (java.lang.Integer)(-1), var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     var1.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var5 = null;
//     java.util.Date var6 = var1.calculateLowestVisibleTickValue(var5);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     var0.configureRangeAxes();
//     org.jfree.chart.plot.Marker var4 = null;
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(100, var4, var5);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("java.awt.Color[r=255,g=255,b=255]", var1);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var1 = var0.getUpperClip();
//     boolean var2 = var0.getBaseCreateEntities();
//     java.awt.Font var3 = var0.getBaseItemLabelFont();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var0.drawOutline(var4, var5, var6);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    int var3 = var2.getPassCount();
    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlinePaint(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=255,g=255,b=255]", var1, 0.0f, 0.0f, 0.0d, 1.0f, 10.0f);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)0.05d, "java.awt.Color[r=255,g=255,b=255]", var2, var3, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.05d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
//     java.awt.Paint[] var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     boolean var5 = var4.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var4.setDomainAxes(var7);
//     org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getOuterSeparatorExtension();
//     double var13 = var11.getSectionDepth();
//     java.awt.Paint var14 = var11.getLabelLinkPaint();
//     var4.setOutlinePaint(var14);
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var14};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var16, var18, var20, var23);
//     java.awt.Paint var25 = var24.getNextOutlinePaint();
//     java.awt.Paint var26 = var24.getNextFillPaint();
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var3 = var1.trimHeight(100.0d);
    double var5 = var1.calculateRightOutset(0.2d);
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var1.createInsetRectangle(var6, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var2 = var0.getTimeFromLong(1L);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    boolean var4 = var3.isRangeGridlinesVisible();
    var3.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var3.getDomainMarkers(100, var8);
    org.jfree.data.xy.XYDataset var10 = null;
    int var11 = var3.indexOf(var10);
    java.awt.Stroke var12 = var3.getRangeGridlineStroke();
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.data.KeyToGroupMap var16 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(-1.0d));
    int var18 = var16.getKeyCount((java.lang.Comparable)(byte)1);
    java.util.List var19 = var16.getGroups();
    var3.drawRangeTickBands(var13, var14, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addExceptions(var19);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "First"+ "'", var1.equals("First"));

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 0.2d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var0.arrange(var4, var7);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    java.lang.Object var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.ui.BasicProjectInfo var6 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"", var7);
    org.jfree.chart.event.ChartChangeEventType var9 = var8.getType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent(var0, var1, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    java.lang.String var3 = var1.getNoDataMessage();
    java.awt.Stroke var5 = var1.getSectionOutlineStroke((java.lang.Comparable)1.0d);
    var1.setLabelGap(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     java.awt.Stroke var9 = var0.getRangeGridlineStroke();
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.KeyToGroupMap var13 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(-1.0d));
//     int var15 = var13.getKeyCount((java.lang.Comparable)(byte)1);
//     java.util.List var16 = var13.getGroups();
//     var0.drawRangeTickBands(var10, var11, var16);
//     org.jfree.chart.plot.Marker var18 = null;
//     var0.addRangeMarker(var18);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "February"+ "'", var1.equals("February"));

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.plot.DatasetRenderingOrder var4 = var0.getDatasetRenderingOrder();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    var5.draw(var6, var7);
    boolean var9 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.plot.PlotOrientation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.lang.Object var4 = var2.clone();
    var2.setAutoRange(true);
    var2.zoomRange(Double.NaN, 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getOuterSeparatorExtension();
//     java.lang.String var3 = var1.getNoDataMessage();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     org.jfree.chart.plot.PlotState var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var1.draw(var4, var5, var6, var7, var8);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.util.UnitType var2 = var1.getUnitType();
//     java.awt.geom.Rectangle2D var3 = null;
//     var1.trim(var3);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    double var11 = var10.getOuterSeparatorExtension();
    double var12 = var10.getSectionDepth();
    java.awt.Paint var13 = var10.getLabelLinkPaint();
    var0.setNoDataMessagePaint(var13);
    org.jfree.chart.plot.Marker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    double var3 = var1.trimHeight(100.0d);
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var1.createInsetRectangle(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 98.0d);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var1 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var2 = var1.getUpperClip();
//     boolean var3 = var1.getBaseCreateEntities();
//     java.awt.Font var4 = var1.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var5.draw(var6, var7);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var4.setShape(100, var7);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     boolean var10 = var9.isRangeGridlinesVisible();
//     var9.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var14 = null;
//     java.util.Collection var15 = var9.getDomainMarkers(100, var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     int var17 = var9.indexOf(var16);
//     java.awt.Stroke var18 = var9.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     double var21 = var20.getOuterSeparatorExtension();
//     double var22 = var20.getSectionDepth();
//     java.awt.Paint var23 = var20.getLabelPaint();
//     org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
//     java.lang.String var25 = var24.getURLText();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, 1);
//     var24.setDataset((org.jfree.data.general.Dataset)var26);
//     java.awt.Paint var30 = var24.getFillPaint();
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
//     double var33 = var32.getOuterSeparatorExtension();
//     double var34 = var32.getSectionDepth();
//     java.awt.Paint var35 = var32.getLabelPaint();
//     boolean var36 = org.jfree.chart.util.PaintUtilities.equal(var30, var35);
//     
//     // Checks the contract:  equals-hashcode on var20 and var32
//     assertTrue("Contract failed: equals-hashcode on var20 and var32", var20.equals(var32) ? var20.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var20
//     assertTrue("Contract failed: equals-hashcode on var32 and var20", var32.equals(var20) ? var32.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, var1);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var13.setShape(100, var16);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     boolean var19 = var18.isRangeGridlinesVisible();
//     var18.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var23 = null;
//     java.util.Collection var24 = var18.getDomainMarkers(100, var23);
//     org.jfree.data.xy.XYDataset var25 = null;
//     int var26 = var18.indexOf(var25);
//     java.awt.Stroke var27 = var18.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     double var30 = var29.getOuterSeparatorExtension();
//     double var31 = var29.getSectionDepth();
//     java.awt.Paint var32 = var29.getLabelPaint();
//     org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var16, var27, var32);
//     var0.setDomainCrosshairPaint(var32);
//     java.awt.Graphics2D var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     var0.drawBackground(var35, var36);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentSize();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
//     var3.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
//     java.util.Date var8 = var7.getLowerDate();
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var3.dateToJava2D(var8, var9, var10);
//     long var12 = var0.toTimelineValue(var8);
//     java.util.Date var13 = null;
//     org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange();
//     java.util.Date var15 = var14.getLowerDate();
//     boolean var16 = var0.containsDomainRange(var13, var15);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getPositiveItemLabelPosition(0, 2);
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var11 = var0.initialise(var6, var7, var8, (-459), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var0.setShape(100, var3);
    java.awt.Shape var6 = var0.getShape(100);
    java.lang.Object var7 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    float[] var5 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var3.getComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getSectionDepth();
    java.awt.Paint var5 = var1.getSectionOutlinePaint((java.lang.Comparable)0.0f);
    var1.setMaximumLabelWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.TimeZone var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var1.createInsetRectangle(var2, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getSectionDepth();
    java.awt.Paint var4 = var1.getLabelLinkPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = null;
    var1.setLegendLabelToolTipGenerator(var5);
    boolean var7 = var1.isSubplot();
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var9 = var1.getSectionOutlinePaint(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RangeType.FULL");

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    var2.setBaseShapesVisible(false);
    org.jfree.chart.event.RendererChangeListener var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addChangeListener(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     java.awt.Stroke var9 = var0.getRangeGridlineStroke();
//     java.awt.Paint var10 = var0.getDomainGridlinePaint();
//     org.jfree.chart.plot.Marker var11 = null;
//     var0.addRangeMarker(var11);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.chart.axis.AxisState var7 = var0.draw(var1, 98.0d, var3, var4, var5, var6);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    double var11 = var10.getOuterSeparatorExtension();
    double var12 = var10.getSectionDepth();
    java.awt.Paint var13 = var10.getLabelLinkPaint();
    var0.setNoDataMessagePaint(var13);
    java.awt.geom.Point2D var15 = var0.getQuadrantOrigin();
    org.jfree.chart.annotations.XYAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     var1.setLowerBound(0.0d);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var5 = var4.getUpperClip();
//     boolean var6 = var4.getBaseCreateEntities();
//     var4.setBase(1.0d);
//     java.awt.Shape var9 = var4.getBaseShape();
//     org.jfree.chart.entity.AxisLabelEntity var12 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var9, "", "RangeType.FULL");
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.chart.axis.AxisState var19 = var1.draw(var13, 0.2d, var15, var16, var17, var18);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getLabelGap();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var8.setShape(100, var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    boolean var14 = var13.isRangeGridlinesVisible();
    var13.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var18 = null;
    java.util.Collection var19 = var13.getDomainMarkers(100, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    int var21 = var13.indexOf(var20);
    java.awt.Stroke var22 = var13.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
    double var25 = var24.getOuterSeparatorExtension();
    double var26 = var24.getSectionDepth();
    java.awt.Paint var27 = var24.getLabelPaint();
    org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var11, var22, var27);
    var1.setLabelShadowPaint(var27);
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    var1.handleClick(0, (-1), var32);
    double var34 = var1.getLabelGap();
    java.awt.Graphics2D var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.RingPlot var38 = new org.jfree.chart.plot.RingPlot(var37);
    double var39 = var38.getOuterSeparatorExtension();
    double var40 = var38.getLabelGap();
    org.jfree.chart.util.ShapeList var45 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var45.setShape(100, var48);
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
    boolean var51 = var50.isRangeGridlinesVisible();
    var50.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var55 = null;
    java.util.Collection var56 = var50.getDomainMarkers(100, var55);
    org.jfree.data.xy.XYDataset var57 = null;
    int var58 = var50.indexOf(var57);
    java.awt.Stroke var59 = var50.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var60 = null;
    org.jfree.chart.plot.RingPlot var61 = new org.jfree.chart.plot.RingPlot(var60);
    double var62 = var61.getOuterSeparatorExtension();
    double var63 = var61.getSectionDepth();
    java.awt.Paint var64 = var61.getLabelPaint();
    org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var48, var59, var64);
    var38.setLabelShadowPaint(var64);
    org.jfree.chart.plot.PlotRenderingInfo var68 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var69 = var1.initialise(var35, var36, (org.jfree.chart.plot.PiePlot)var38, (java.lang.Integer)15, var68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var2 = var0.getDataset((-1));
    org.jfree.chart.axis.ValueAxis var4 = var0.getDomainAxis(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     var0.configureRangeAxes();
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     var3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var5);
//     java.lang.Object var7 = var5.clone();
//     var5.setAutoRange(true);
//     org.jfree.chart.axis.MarkerAxisBand var10 = var5.getMarkerBand();
//     int var11 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("February");
//     float var2 = var1.getBaselineOffset();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     float var5 = var1.calculateBaselineOffset(var3, var4);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    var1.clearDomainMarkers();
    boolean var3 = var0.equals((java.lang.Object)var1);
    int var4 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    org.jfree.chart.renderer.category.StackedAreaRenderer var5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
    org.jfree.data.Range var9 = var5.findRangeBounds((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.chart.renderer.category.LayeredBarRenderer var10 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var11 = var10.getUpperClip();
    java.awt.Stroke var14 = var10.getItemStroke((-459), (-459));
    var5.setBaseStroke(var14, false);
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    boolean var18 = var17.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var19};
    var17.setDomainAxes(var20);
    org.jfree.chart.axis.AxisLocation var22 = var17.getDomainAxisLocation();
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
    double var25 = var24.getOuterSeparatorExtension();
    double var26 = var24.getSectionDepth();
    java.awt.Paint var27 = var24.getLabelLinkPaint();
    var17.setOutlinePaint(var27);
    org.jfree.chart.renderer.category.StackedAreaRenderer var29 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var30, 1);
    org.jfree.data.Range var33 = var29.findRangeBounds((org.jfree.data.category.CategoryDataset)var30);
    org.jfree.chart.renderer.category.LayeredBarRenderer var34 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var35 = var34.getUpperClip();
    java.awt.Stroke var38 = var34.getItemStroke((-459), (-459));
    var29.setBaseStroke(var38, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(100.0d, (java.awt.Paint)var4, var14, var27, var38, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    java.util.List var6 = var5.getSubtitles();
    org.jfree.chart.event.ChartChangeListener var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.removeChangeListener(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Paint var10 = var0.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    double var14 = var13.getOuterSeparatorExtension();
    double var15 = var13.getSectionDepth();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.event.ChartChangeListener var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addChangeListener(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     java.lang.Number[] var0 = null;
//     java.lang.Number[][] var1 = new java.lang.Number[][] { var0};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var5 = var4.brighter();
    org.jfree.chart.renderer.category.StackedAreaRenderer var6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 1);
    org.jfree.data.Range var10 = var6.findRangeBounds((org.jfree.data.category.CategoryDataset)var7);
    org.jfree.chart.renderer.category.LayeredBarRenderer var11 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var12 = var11.getUpperClip();
    java.awt.Stroke var15 = var11.getItemStroke((-459), (-459));
    var6.setBaseStroke(var15, false);
    java.awt.Color var21 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var23 = var22.getUpperClip();
    java.awt.Stroke var26 = var22.getItemStroke((-459), (-459));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(Double.NaN, (java.awt.Paint)var5, var15, (java.awt.Paint)var21, var26, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.renderer.category.LayeredBarRenderer var3 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var4 = var3.getUpperClip();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    boolean var6 = var5.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var5.setDomainAxes(var8);
    org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation();
    boolean var11 = var3.equals((java.lang.Object)var10);
    var0.setRangeAxisLocation(10, var10, true);
    org.jfree.chart.plot.PlotOrientation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var10, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    boolean var5 = var2.getItemShapeVisible((-459), 1);
    var2.setBaseItemLabelsVisible(true, true);
    var2.setBaseShapesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "hi!");
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var5.setShape(100, var8);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    boolean var11 = var10.isRangeGridlinesVisible();
    var10.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var10.getDomainMarkers(100, var15);
    org.jfree.data.xy.XYDataset var17 = null;
    int var18 = var10.indexOf(var17);
    java.awt.Stroke var19 = var10.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
    double var22 = var21.getOuterSeparatorExtension();
    double var23 = var21.getSectionDepth();
    java.awt.Paint var24 = var21.getLabelPaint();
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var8, var19, var24);
    java.lang.String var26 = var25.getURLText();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var27, 1);
    var25.setDataset((org.jfree.data.general.Dataset)var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var32 = var0.generateRowLabel((org.jfree.data.category.CategoryDataset)var27, (-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "hi!"+ "'", var26.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.util.RectangleInsets var3 = var2.getLabelInsets();
//     var1.setLabelInsets(var3);
//     java.awt.geom.Rectangle2D var5 = null;
//     var3.trim(var5);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
    java.util.List var2 = var1.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeColumn(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var2, (java.lang.Comparable)(short)0, (-1.0d), 10);
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var6, (java.lang.Comparable)10.0f, 1.0d, (-1));
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    boolean var13 = var12.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var14};
    var12.setDomainAxes(var15);
    org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation();
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
    double var20 = var19.getOuterSeparatorExtension();
    double var21 = var19.getSectionDepth();
    java.awt.Paint var22 = var19.getLabelLinkPaint();
    var12.setOutlinePaint(var22);
    var11.setBaseSectionOutlinePaint(var22);
    java.awt.Paint var25 = var11.getLabelOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("poly", var1, var2);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("poly", "First", var3);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit((-2.0d), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "Multiple Pie Plot");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    double var1 = var0.getMax();
    double var2 = var0.getCursor();
    var0.setCursor(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     double var3 = var2.getOuterSeparatorExtension();
//     double var4 = var2.getSectionDepth();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var7 = var6.getBackgroundPaint();
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     java.awt.Paint[] var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     boolean var11 = var10.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var13 = new org.jfree.chart.axis.ValueAxis[] { var12};
//     var10.setDomainAxes(var13);
//     org.jfree.chart.axis.AxisLocation var15 = var10.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
//     double var18 = var17.getOuterSeparatorExtension();
//     double var19 = var17.getSectionDepth();
//     java.awt.Paint var20 = var17.getLabelLinkPaint();
//     var10.setOutlinePaint(var20);
//     java.awt.Paint[] var22 = new java.awt.Paint[] { var20};
//     java.awt.Stroke var23 = null;
//     java.awt.Stroke[] var24 = new java.awt.Stroke[] { var23};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var29 = new java.awt.Shape[] { var28};
//     org.jfree.chart.plot.DefaultDrawingSupplier var30 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var9, var22, var24, var26, var29);
//     java.awt.Paint var31 = var30.getNextPaint();
//     var5.setBackgroundPaint(var31);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.2d, (-2.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.awt.Color var5 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var6 = var5.brighter();
    java.awt.Color var7 = var5.darker();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var9 = var8.getLabelFont();
    var8.setAutoRangeMinimumSize(100.0d, true);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    double var15 = var14.getOuterSeparatorExtension();
    java.lang.String var16 = var14.getNoDataMessage();
    java.awt.Stroke var17 = var14.getSeparatorStroke();
    var8.setAxisLineStroke(var17);
    java.awt.Color var22 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var23 = var22.brighter();
    int var24 = var23.getTransparency();
    int var25 = var23.getTransparency();
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    var26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.renderer.category.LayeredBarRenderer var30 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var32 = var30.getSeriesOutlineStroke(1);
    java.awt.Paint var34 = var30.lookupSeriesFillPaint((-1));
    var28.setLabelPaint(var34);
    java.awt.Stroke var36 = var28.getTickMarkStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var38 = new org.jfree.chart.plot.IntervalMarker(0.0d, 100.0d, (java.awt.Paint)var5, var17, (java.awt.Paint)var23, var36, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange();
    java.util.Date var5 = var4.getLowerDate();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var1.dateToJava2D(var5, var6, var7);
    java.util.TimeZone var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, 1);
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var3, (java.lang.Comparable)(short)0, (-1.0d), 10);
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var7, (java.lang.Comparable)10.0f, 1.0d, (-1));
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var7);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    boolean var14 = var13.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var16 = new org.jfree.chart.axis.ValueAxis[] { var15};
    var13.setDomainAxes(var16);
    org.jfree.chart.axis.AxisLocation var18 = var13.getDomainAxisLocation();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelLinkPaint();
    var13.setOutlinePaint(var23);
    var12.setBaseSectionOutlinePaint(var23);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    var26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
    org.jfree.chart.renderer.category.LayeredBarRenderer var30 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var32 = var30.getSeriesOutlineStroke(1);
    java.awt.Paint var34 = var30.lookupSeriesFillPaint((-1));
    var28.setLabelPaint(var34);
    boolean var36 = var28.isPositiveArrowVisible();
    java.awt.Stroke var37 = var28.getAxisLineStroke();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var38.setBaseSeriesVisible(false, false);
    java.awt.Paint var44 = var38.getItemLabelPaint(0, 10);
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
    var45.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var47);
    java.awt.Stroke var49 = var45.getDomainCrosshairStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(0.0d, var23, var37, var44, var49, 2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    java.util.List var6 = var5.getSubtitles();
    org.jfree.chart.plot.Plot var7 = var5.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var8 = var5.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    org.jfree.chart.axis.AxisLocation var10 = var0.getDomainAxisLocation(1);
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeZeroBaselinePaint(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var3.setRenderAsPercentages(true);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 1);
//     int var10 = var7.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var11 = null;
//     var7.removeChangeListener(var11);
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     var13.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
//     java.text.NumberFormat var20 = var18.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var22 = var21.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, (org.jfree.chart.axis.CategoryAxis)var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
//     java.awt.geom.Rectangle2D var24 = null;
//     var3.drawBackground(var6, var23, var24);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.awt.Stroke var4 = var0.getDomainCrosshairStroke();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var0.markerChanged(var5);
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var11 = var10.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var12 = null;
    int var13 = var10.getRangeAxisIndex(var12);
    org.jfree.chart.axis.AxisLocation var15 = var10.getDomainAxisLocation(10);
    var0.setRangeAxisLocation(0, var15, true);
    org.jfree.data.xy.XYDataset var18 = null;
    var0.setDataset(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(15, 15, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.KeyToGroupMap var13 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(-1.0d));
    int var15 = var13.getKeyCount((java.lang.Comparable)(byte)1);
    java.util.List var16 = var13.getGroups();
    var0.drawRangeTickBands(var10, var11, var16);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getSectionDepth();
    boolean var4 = var1.getIgnoreNullValues();
    int var5 = var1.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 15);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    var0.setNotify(false);
    java.lang.Object var6 = var0.clone();
    java.awt.Graphics2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var0.arrange(var7);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelPaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.awt.Paint var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     var1.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var5 = var4.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var7 = var4.getSegment(604800000L);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var9 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var10 = var9.getUpperClip();
//     boolean var11 = var9.getBaseCreateEntities();
//     java.awt.Font var12 = var9.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("", var12);
//     var1.setTickLabelFont((java.lang.Comparable)var7, var12);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var17 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var18 = var17.getUpperClip();
//     boolean var19 = var17.getBaseCreateEntities();
//     java.awt.Font var20 = var17.getBaseItemLabelFont();
//     var16.setLabelFont(var20);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var23 = var22.getBackgroundPaint();
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
//     java.awt.Paint[] var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     boolean var27 = var26.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var28};
//     var26.setDomainAxes(var29);
//     org.jfree.chart.axis.AxisLocation var31 = var26.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.RingPlot var33 = new org.jfree.chart.plot.RingPlot(var32);
//     double var34 = var33.getOuterSeparatorExtension();
//     double var35 = var33.getSectionDepth();
//     java.awt.Paint var36 = var33.getLabelLinkPaint();
//     var26.setOutlinePaint(var36);
//     java.awt.Paint[] var38 = new java.awt.Paint[] { var36};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Stroke var41 = null;
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var45 = new java.awt.Shape[] { var44};
//     org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier(var24, var25, var38, var40, var42, var45);
//     java.awt.Paint var47 = var46.getNextPaint();
//     var16.setShadowPaint(var47);
//     org.jfree.chart.text.TextMeasurer var50 = null;
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("Pie 3D Plot", var12, var47, 0.8f, var50);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.renderer.category.LayeredBarRenderer var3 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var4 = var3.getUpperClip();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    boolean var6 = var5.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var5.setDomainAxes(var8);
    org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation();
    boolean var11 = var3.equals((java.lang.Object)var10);
    var0.setRangeAxisLocation(10, var10, true);
    org.jfree.chart.plot.PlotOrientation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    int var3 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    boolean var25 = var24.isShapeFilled();
    java.lang.String var26 = var24.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + ""+ "'", var26.equals(""));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.util.RectangleInsets var1 = var0.getLabelInsets();
    double var2 = var0.getAutoRangeMinimumSize();
    var0.setLabelURL("Multiple Pie Plot");
    java.awt.Shape var5 = var0.getUpArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
//     double var3 = var2.getOuterSeparatorExtension();
//     double var4 = var2.getSectionDepth();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     double var8 = var7.getOuterSeparatorExtension();
//     java.lang.String var9 = var7.getNoDataMessage();
//     java.awt.Stroke var10 = var7.getSeparatorStroke();
//     var5.setBorderStroke(var10);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     var16.setAnchorValue((-1.0d), false);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var22, 1);
//     int var25 = var22.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var26 = null;
//     var22.removeChangeListener(var26);
//     org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
//     var28.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     var31.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var33);
//     java.text.NumberFormat var35 = var33.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var36 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var37 = var36.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, (org.jfree.chart.axis.CategoryAxis)var28, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     java.util.List var39 = var16.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var28);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var31
//     assertTrue("Contract failed: equals-hashcode on var9 and var31", var9.equals(var31) ? var9.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var9
//     assertTrue("Contract failed: equals-hashcode on var31 and var9", var31.equals(var9) ? var31.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    java.lang.String var3 = var1.getNoDataMessage();
    var1.setSectionDepth(10.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
//     java.awt.Paint[] var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     boolean var5 = var4.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var4.setDomainAxes(var7);
//     org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getOuterSeparatorExtension();
//     double var13 = var11.getSectionDepth();
//     java.awt.Paint var14 = var11.getLabelLinkPaint();
//     var4.setOutlinePaint(var14);
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var14};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var16, var18, var20, var23);
//     java.awt.Paint var25 = var24.getNextPaint();
//     java.awt.Paint var26 = var24.getNextFillPaint();
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    double var11 = var10.getOuterSeparatorExtension();
    var10.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
    double var17 = var16.getOuterSeparatorExtension();
    double var18 = var16.getSectionDepth();
    java.awt.Paint var19 = var16.getLabelPaint();
    var10.setLabelLinkPaint(var19);
    var0.setParent((org.jfree.chart.plot.Plot)var10);
    org.jfree.chart.util.RectangleInsets var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var22, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var18 = var16.removeAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var3.setRenderAsPercentages(true);
//     java.awt.Paint var6 = var3.getWallPaint();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var10 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var11 = var10.getUpperClip();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     boolean var13 = var12.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var14};
//     var12.setDomainAxes(var15);
//     org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation();
//     boolean var18 = var10.equals((java.lang.Object)var17);
//     var7.setRangeAxisLocation(10, var17, true);
//     boolean var21 = var7.isRangeCrosshairLockedOnData();
//     boolean var22 = var3.equals((java.lang.Object)var7);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, 1);
//     int var27 = var24.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var28 = null;
//     var24.removeChangeListener(var28);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var33.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var35);
//     java.text.NumberFormat var37 = var35.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var38 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var39 = var38.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var42, 1);
//     int var45 = var42.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var46 = null;
//     var42.removeChangeListener(var46);
//     org.jfree.chart.axis.CategoryAxis3D var48 = new org.jfree.chart.axis.CategoryAxis3D();
//     var48.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     var51.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var53);
//     java.text.NumberFormat var55 = var53.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var56 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var57 = var56.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var42, (org.jfree.chart.axis.CategoryAxis)var48, (org.jfree.chart.axis.ValueAxis)var53, (org.jfree.chart.renderer.category.CategoryItemRenderer)var56);
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var62 = var61.getAlpha();
//     org.jfree.chart.util.Layer var63 = null;
//     var58.addRangeMarker(10, (org.jfree.chart.plot.Marker)var61, var63);
//     java.awt.geom.Rectangle2D var65 = null;
//     var3.drawRangeMarker(var23, var40, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.plot.Marker)var61, var65);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    var0.setNotify(false);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.RectangleEdge var7 = var0.getPosition();
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTextAlignment(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var2 = var0.getSeriesOutlineStroke(1);
    java.awt.Paint var4 = var0.lookupSeriesFillPaint((-1));
    java.awt.Paint var6 = var0.getSeriesOutlinePaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    boolean var3 = var2.isRangeGridlinesVisible();
    var2.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var2.getDomainMarkers(100, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    int var10 = var2.indexOf(var9);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var15.setShape(100, var18);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    boolean var21 = var20.isRangeGridlinesVisible();
    var20.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var20.getDomainMarkers(100, var25);
    org.jfree.data.xy.XYDataset var27 = null;
    int var28 = var20.indexOf(var27);
    java.awt.Stroke var29 = var20.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
    double var32 = var31.getOuterSeparatorExtension();
    double var33 = var31.getSectionDepth();
    java.awt.Paint var34 = var31.getLabelPaint();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var18, var29, var34);
    var2.setDomainCrosshairPaint(var34);
    var0.setSeriesOutlinePaint(15, var34, true);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var41 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var40);
    org.jfree.chart.entity.EntityCollection var42 = var41.getEntityCollection();
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var44 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var44, 1);
    int var47 = var44.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var48 = null;
    var44.removeChangeListener(var48);
    org.jfree.chart.axis.CategoryAxis3D var50 = new org.jfree.chart.axis.CategoryAxis3D();
    var50.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
    var53.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var55);
    java.text.NumberFormat var57 = var55.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var58 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var59 = var58.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var44, (org.jfree.chart.axis.CategoryAxis)var50, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.chart.renderer.category.CategoryItemRenderer)var58);
    org.jfree.chart.axis.CategoryAxis var62 = var60.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var63 = var60.getRangeAxisLocation();
    org.jfree.chart.axis.CategoryAxis3D var64 = new org.jfree.chart.axis.CategoryAxis3D();
    var64.setUpperMargin(98.0d);
    org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var68 = var67.getLabelFont();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var69 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var71 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var69, 1);
    int var72 = var69.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var73 = null;
    var69.removeChangeListener(var73);
    var69.add(10.0d, 0.05d, (java.lang.Comparable)'#', (java.lang.Comparable)100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var39, var41, var43, var60, (org.jfree.chart.axis.CategoryAxis)var64, (org.jfree.chart.axis.ValueAxis)var67, (org.jfree.data.category.CategoryDataset)var69, 10, 10, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    var2.setBaseShapesVisible(false);
    org.jfree.chart.renderer.category.LayeredBarRenderer var6 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var7 = var6.getUpperClip();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = var6.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var11 = var6.getNegativeItemLabelPosition(0, (-459));
    java.lang.Object var12 = null;
    boolean var13 = var11.equals(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesNegativeItemLabelPosition((-459), var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
//     java.text.NumberFormat var4 = var2.getNumberFormatOverride();
//     java.awt.Paint var5 = var2.getTickMarkPaint();
//     float var6 = var2.getTickMarkOutsideLength();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
//     var7.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.data.RangeType var11 = var9.getRangeType();
//     var2.setRangeType(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("RangeType.FULL");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     java.awt.Stroke var9 = var0.getRangeGridlineStroke();
//     java.awt.Paint var10 = var0.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     double var14 = var13.getOuterSeparatorExtension();
//     double var15 = var13.getSectionDepth();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     var16.setAntiAlias(true);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
//     double var23 = var22.getOuterSeparatorExtension();
//     double var24 = var22.getSectionDepth();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var22);
//     java.util.List var26 = var25.getSubtitles();
//     var16.setSubtitles(var26);
//     
//     // Checks the contract:  equals-hashcode on var13 and var22
//     assertTrue("Contract failed: equals-hashcode on var13 and var22", var13.equals(var22) ? var13.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var13
//     assertTrue("Contract failed: equals-hashcode on var22 and var13", var22.equals(var13) ? var22.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var25
//     assertTrue("Contract failed: equals-hashcode on var16 and var25", var16.equals(var25) ? var16.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var16
//     assertTrue("Contract failed: equals-hashcode on var25 and var16", var25.equals(var16) ? var25.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var2.getPositiveItemLabelPosition(0, 2);
    org.jfree.chart.text.TextAnchor var6 = var5.getTextAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var10 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var6, 1.0d, var8, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = null;
    int var3 = var0.getRangeAxisIndex(var2);
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation(10);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelInsets();
    double var9 = var7.getAutoRangeMinimumSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis)var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0E-8d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getLabelGap();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var8.setShape(100, var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    boolean var14 = var13.isRangeGridlinesVisible();
    var13.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var18 = null;
    java.util.Collection var19 = var13.getDomainMarkers(100, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    int var21 = var13.indexOf(var20);
    java.awt.Stroke var22 = var13.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
    double var25 = var24.getOuterSeparatorExtension();
    double var26 = var24.getSectionDepth();
    java.awt.Paint var27 = var24.getLabelPaint();
    org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var11, var22, var27);
    var1.setLabelShadowPaint(var27);
    java.lang.Comparable var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
    var31.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var33);
    org.jfree.chart.plot.DatasetRenderingOrder var35 = var31.getDatasetRenderingOrder();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    var36.draw(var37, var38);
    boolean var40 = var31.equals((java.lang.Object)var38);
    java.awt.Paint var41 = var31.getRangeCrosshairPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSectionPaint(var30, var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    boolean var4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var0.getRowKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0d+ "'", var5.equals(0.0d));

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getOuterSeparatorExtension();
//     double var3 = var1.getLabelGap();
//     org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var8.setShape(100, var11);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     boolean var14 = var13.isRangeGridlinesVisible();
//     var13.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var18 = null;
//     java.util.Collection var19 = var13.getDomainMarkers(100, var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     int var21 = var13.indexOf(var20);
//     java.awt.Stroke var22 = var13.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
//     double var25 = var24.getOuterSeparatorExtension();
//     double var26 = var24.getSectionDepth();
//     java.awt.Paint var27 = var24.getLabelPaint();
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var11, var22, var27);
//     var1.setLabelShadowPaint(var27);
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     var1.handleClick(0, (-1), var32);
//     double var34 = var1.getLabelGap();
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot(var39);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var41 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var42 = var41.getUpperClip();
//     boolean var43 = var41.getBaseCreateEntities();
//     java.awt.Font var44 = var41.getBaseItemLabelFont();
//     var40.setLabelFont(var44);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var47 = var46.getBackgroundPaint();
//     java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
//     java.awt.Paint[] var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     boolean var51 = var50.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var53 = new org.jfree.chart.axis.ValueAxis[] { var52};
//     var50.setDomainAxes(var53);
//     org.jfree.chart.axis.AxisLocation var55 = var50.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.RingPlot var57 = new org.jfree.chart.plot.RingPlot(var56);
//     double var58 = var57.getOuterSeparatorExtension();
//     double var59 = var57.getSectionDepth();
//     java.awt.Paint var60 = var57.getLabelLinkPaint();
//     var50.setOutlinePaint(var60);
//     java.awt.Paint[] var62 = new java.awt.Paint[] { var60};
//     java.awt.Stroke var63 = null;
//     java.awt.Stroke[] var64 = new java.awt.Stroke[] { var63};
//     java.awt.Stroke var65 = null;
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
//     java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var69 = new java.awt.Shape[] { var68};
//     org.jfree.chart.plot.DefaultDrawingSupplier var70 = new org.jfree.chart.plot.DefaultDrawingSupplier(var48, var49, var62, var64, var66, var69);
//     java.awt.Paint var71 = var70.getNextPaint();
//     var40.setShadowPaint(var71);
//     org.jfree.chart.block.BlockBorder var73 = new org.jfree.chart.block.BlockBorder(98.0d, 0.2d, 10.0d, 0.0d, var71);
//     var1.setBaseSectionPaint(var71);
//     
//     // Checks the contract:  equals-hashcode on var24 and var57
//     assertTrue("Contract failed: equals-hashcode on var24 and var57", var24.equals(var57) ? var24.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var24
//     assertTrue("Contract failed: equals-hashcode on var57 and var24", var57.equals(var24) ? var57.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var20 = var19.getAlpha();
//     org.jfree.chart.util.Layer var21 = null;
//     var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
//     org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation();
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     boolean var27 = var26.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var29 = new org.jfree.chart.axis.ValueAxis[] { var28};
//     var26.setDomainAxes(var29);
//     org.jfree.chart.axis.AxisSpace var31 = null;
//     var26.setFixedDomainAxisSpace(var31);
//     var26.setRangeCrosshairValue(98.0d);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.RingPlot var36 = new org.jfree.chart.plot.RingPlot(var35);
//     double var37 = var36.getOuterSeparatorExtension();
//     double var38 = var36.getSectionDepth();
//     java.awt.Paint var39 = var36.getLabelLinkPaint();
//     var26.setNoDataMessagePaint(var39);
//     java.awt.geom.Point2D var41 = var26.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     var16.draw(var24, var25, var41, var42, var43);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(-1));
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var8.setShape(100, var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    boolean var14 = var13.isRangeGridlinesVisible();
    var13.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var18 = null;
    java.util.Collection var19 = var13.getDomainMarkers(100, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    int var21 = var13.indexOf(var20);
    java.awt.Stroke var22 = var13.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
    double var25 = var24.getOuterSeparatorExtension();
    double var26 = var24.getSectionDepth();
    java.awt.Paint var27 = var24.getLabelPaint();
    org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var11, var22, var27);
    org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    var29.draw(var30, var31);
    var29.setNotify(false);
    java.lang.Object var35 = var29.clone();
    org.jfree.chart.util.RectangleEdge var36 = var29.getPosition();
    org.jfree.chart.util.HorizontalAlignment var37 = null;
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var38.draw(var39, var40);
    double var42 = var38.getContentYOffset();
    org.jfree.chart.util.VerticalAlignment var43 = var38.getVerticalAlignment();
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
    var44.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var46);
    org.jfree.chart.renderer.category.LayeredBarRenderer var48 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var50 = var48.getSeriesOutlineStroke(1);
    java.awt.Paint var52 = var48.lookupSeriesFillPaint((-1));
    var46.setLabelPaint(var52);
    java.awt.Stroke var54 = var46.getTickMarkStroke();
    org.jfree.chart.util.RectangleInsets var55 = var46.getLabelInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("", var3, var27, var36, var37, var43, var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var2, (java.lang.Comparable)(short)0, (-1.0d), 10);
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var2);
//     java.lang.String var8 = var7.getPlotType();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     boolean var12 = var11.isRangeGridlinesVisible();
//     java.awt.Paint var13 = var11.getNoDataMessagePaint();
//     org.jfree.chart.plot.DrawingSupplier var14 = var11.getDrawingSupplier();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     boolean var18 = var17.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var20 = new org.jfree.chart.axis.ValueAxis[] { var19};
//     var17.setDomainAxes(var20);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     var17.setFixedDomainAxisSpace(var22);
//     var17.setRangeCrosshairValue(98.0d);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.RingPlot var27 = new org.jfree.chart.plot.RingPlot(var26);
//     double var28 = var27.getOuterSeparatorExtension();
//     double var29 = var27.getSectionDepth();
//     java.awt.Paint var30 = var27.getLabelLinkPaint();
//     var17.setNoDataMessagePaint(var30);
//     java.awt.geom.Point2D var32 = var17.getQuadrantOrigin();
//     var11.zoomRangeAxes((-1.0d), var16, var32);
//     org.jfree.chart.plot.PlotState var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     var7.draw(var9, var10, var32, var34, var35);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    boolean var3 = var2.isRangeGridlinesVisible();
    var2.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var2.getDomainMarkers(100, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    int var10 = var2.indexOf(var9);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var15.setShape(100, var18);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    boolean var21 = var20.isRangeGridlinesVisible();
    var20.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var20.getDomainMarkers(100, var25);
    org.jfree.data.xy.XYDataset var27 = null;
    int var28 = var20.indexOf(var27);
    java.awt.Stroke var29 = var20.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
    double var32 = var31.getOuterSeparatorExtension();
    double var33 = var31.getSectionDepth();
    java.awt.Paint var34 = var31.getLabelPaint();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var18, var29, var34);
    var2.setDomainCrosshairPaint(var34);
    var0.setSeriesOutlinePaint(15, var34, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-1), (java.lang.Boolean)true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Paint var10 = var0.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    double var14 = var13.getOuterSeparatorExtension();
    double var15 = var13.getSectionDepth();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.event.ChartProgressListener var18 = null;
    var16.addProgressListener(var18);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var23 = var16.createBufferedImage((-459), 0, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
    var5.setRenderAsPercentages(true);
    java.awt.Paint var8 = var5.getWallPaint();
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
    java.awt.Paint[] var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    boolean var14 = var13.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var16 = new org.jfree.chart.axis.ValueAxis[] { var15};
    var13.setDomainAxes(var16);
    org.jfree.chart.axis.AxisLocation var18 = var13.getDomainAxisLocation();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelLinkPaint();
    var13.setOutlinePaint(var23);
    java.awt.Paint[] var25 = new java.awt.Paint[] { var23};
    java.awt.Stroke var26 = null;
    java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
    java.awt.Stroke var28 = null;
    java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    java.awt.Shape[] var32 = new java.awt.Shape[] { var31};
    org.jfree.chart.plot.DefaultDrawingSupplier var33 = new org.jfree.chart.plot.DefaultDrawingSupplier(var11, var12, var25, var27, var29, var32);
    java.awt.Paint var34 = var33.getNextOutlinePaint();
    var5.setWallPaint(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var2 = var1.getYear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var3 = new org.jfree.data.time.Month((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setUpperMargin(98.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var3 = var0.getCategoryLabelPositions();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     var8.clearDomainMarkers();
//     boolean var10 = var7.equals((java.lang.Object)var8);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var8.zoomDomainAxes(1.0E-8d, (-1.0d), var13, var14);
//     org.jfree.chart.util.RectangleEdge var16 = var8.getRangeAxisEdge();
//     double var17 = var0.getCategoryMiddle(2, 1, var6, var16);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var3.setRenderAsPercentages(true);
//     double var6 = var3.getYOffset();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, 1);
//     int var11 = var8.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var12 = null;
//     var8.removeChangeListener(var12);
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
//     var14.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var17.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var19);
//     java.text.NumberFormat var21 = var19.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var23 = var22.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     org.jfree.chart.axis.CategoryAxis var26 = var24.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var27 = var24.getRangeAxisLocation();
//     java.awt.geom.Rectangle2D var28 = null;
//     var3.drawDomainGridline(var7, var24, var28, 98.0d);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 1);
    int var7 = var4.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var8 = null;
    var4.removeChangeListener(var8);
    var4.add(10.0d, 0.05d, (java.lang.Comparable)'#', (java.lang.Comparable)100.0d);
    org.jfree.data.Range var15 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
    boolean var4 = var3.getIncludeBaseInRange();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var7 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var6);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var9, 1);
    int var12 = var9.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var13 = null;
    var9.removeChangeListener(var13);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D();
    var15.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    var18.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var20);
    java.text.NumberFormat var22 = var20.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var23 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var24 = var23.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var9, (org.jfree.chart.axis.CategoryAxis)var15, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.axis.CategoryAxis var27 = var25.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var28 = var25.getRangeAxisLocation();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var31 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var29, 1);
    int var32 = var29.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var33 = null;
    var29.removeChangeListener(var33);
    org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
    var35.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    var38.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var40);
    java.text.NumberFormat var42 = var40.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var43 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var44 = var43.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var29, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.renderer.category.CategoryItemRenderer)var43);
    org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis("");
    var47.setLowerBound(0.0d);
    org.jfree.chart.renderer.category.LayeredBarRenderer var50 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var51 = var50.getUpperClip();
    boolean var52 = var50.getBaseCreateEntities();
    var50.setBase(1.0d);
    java.awt.Shape var55 = var50.getBaseShape();
    org.jfree.chart.entity.AxisLabelEntity var58 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var47, var55, "", "RangeType.FULL");
    var47.setAxisLineVisible(true);
    org.jfree.chart.util.ShapeList var65 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var65.setShape(100, var68);
    org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot();
    boolean var71 = var70.isRangeGridlinesVisible();
    var70.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var75 = null;
    java.util.Collection var76 = var70.getDomainMarkers(100, var75);
    org.jfree.data.xy.XYDataset var77 = null;
    int var78 = var70.indexOf(var77);
    java.awt.Stroke var79 = var70.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var80 = null;
    org.jfree.chart.plot.RingPlot var81 = new org.jfree.chart.plot.RingPlot(var80);
    double var82 = var81.getOuterSeparatorExtension();
    double var83 = var81.getSectionDepth();
    java.awt.Paint var84 = var81.getLabelPaint();
    org.jfree.chart.LegendItem var85 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var68, var79, var84);
    java.lang.String var86 = var85.getURLText();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var87 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var89 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var87, 1);
    var85.setDataset((org.jfree.data.general.Dataset)var87);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.drawItem(var5, var7, var8, var25, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var47, (org.jfree.data.category.CategoryDataset)var87, 15, 10, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + "hi!"+ "'", var86.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var20, 1);
//     int var23 = var20.getColumnCount();
//     org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var20);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = var16.getRendererForDataset((org.jfree.data.category.CategoryDataset)var20);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.util.RectangleInsets var3 = var2.getLabelInsets();
    var1.setLabelInsets(var3);
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var3.createOutsetRectangle(var5, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(2.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     var1.setLowerBound(0.0d);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     var7.clearDomainMarkers();
//     boolean var9 = var6.equals((java.lang.Object)var7);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     var7.zoomDomainAxes(1.0E-8d, (-1.0d), var12, var13);
//     org.jfree.chart.util.RectangleEdge var15 = var7.getRangeAxisEdge();
//     double var16 = var1.java2DToValue(4.0d, var5, var15);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     boolean var2 = var1.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var4 = new org.jfree.chart.axis.ValueAxis[] { var3};
//     var1.setDomainAxes(var4);
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var1.setFixedDomainAxisSpace(var6);
//     var1.zoom(0.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var10, 1);
//     org.jfree.data.general.PieDataset var16 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var12, (java.lang.Comparable)(short)0, (-1.0d), 10);
//     org.jfree.data.general.DatasetChangeEvent var17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0.0d, (org.jfree.data.general.Dataset)var16);
//     var0.datasetChanged(var17);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     boolean var20 = var19.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var22 = new org.jfree.chart.axis.ValueAxis[] { var21};
//     var19.setDomainAxes(var22);
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var19.setFixedDomainAxisSpace(var24);
//     var19.zoom(0.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var28, 1);
//     org.jfree.data.general.PieDataset var34 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var30, (java.lang.Comparable)(short)0, (-1.0d), 10);
//     org.jfree.data.general.DatasetChangeEvent var35 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0.0d, (org.jfree.data.general.Dataset)var34);
//     java.lang.Object var36 = var35.getSource();
//     var0.datasetChanged(var35);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var28
//     assertTrue("Contract failed: equals-hashcode on var10 and var28", var10.equals(var28) ? var10.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var10
//     assertTrue("Contract failed: equals-hashcode on var28 and var10", var28.equals(var10) ? var28.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)0.0d, (java.lang.Number)(short)1);
    org.jfree.chart.util.SortOrder var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByValues(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    boolean var25 = var24.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var26, "hi!");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var31, 1);
    int var34 = var31.getColumnCount();
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
    var36.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.axis.SegmentedTimeline var39 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var40 = var39.getSegmentSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var42 = var39.getSegment(604800000L);
    org.jfree.chart.renderer.category.LayeredBarRenderer var44 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var45 = var44.getUpperClip();
    boolean var46 = var44.getBaseCreateEntities();
    java.awt.Font var47 = var44.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("", var47);
    var36.setTickLabelFont((java.lang.Comparable)var42, var47);
    org.jfree.chart.entity.CategoryItemEntity var50 = new org.jfree.chart.entity.CategoryItemEntity(var26, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var31, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var42);
    var24.setSeriesKey((java.lang.Comparable)var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getLabelGap();
    org.jfree.chart.util.ShapeList var8 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var8.setShape(100, var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    boolean var14 = var13.isRangeGridlinesVisible();
    var13.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var18 = null;
    java.util.Collection var19 = var13.getDomainMarkers(100, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    int var21 = var13.indexOf(var20);
    java.awt.Stroke var22 = var13.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
    double var25 = var24.getOuterSeparatorExtension();
    double var26 = var24.getSectionDepth();
    java.awt.Paint var27 = var24.getLabelPaint();
    org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var11, var22, var27);
    var1.setLabelShadowPaint(var27);
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    var1.handleClick(0, (-1), var32);
    double var34 = var1.getLabelGap();
    java.lang.String var35 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "Pie Plot"+ "'", var35.equals("Pie Plot"));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=255,g=255,b=255]");
    var1.setToolTipText("RangeType.FULL");

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Other", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
    java.util.List var2 = var1.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var1.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var1 = var0.getSegmentsGroupSize();
//     int var2 = var0.getSegmentsExcluded();
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
//     var6.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange();
//     java.util.Date var11 = var10.getLowerDate();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var6.dateToJava2D(var11, var12, var13);
//     var4.setMinimumDate(var11);
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     var17.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange();
//     java.util.Date var21 = var20.getLowerDate();
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.util.RectangleEdge var23 = null;
//     double var24 = var17.dateToJava2D(var21, var22, var23);
//     org.jfree.data.time.SimpleTimePeriod var25 = new org.jfree.data.time.SimpleTimePeriod(var11, var21);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var11);
//     long var27 = var0.getTime(var11);
//     java.util.TimeZone var28 = null;
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(var11, var28);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.data.RangeType var4 = var2.getRangeType();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "hi!");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var11, 1);
    int var14 = var11.getColumnCount();
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
    var16.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.axis.SegmentedTimeline var19 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var20 = var19.getSegmentSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var22 = var19.getSegment(604800000L);
    org.jfree.chart.renderer.category.LayeredBarRenderer var24 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var25 = var24.getUpperClip();
    boolean var26 = var24.getBaseCreateEntities();
    java.awt.Font var27 = var24.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("", var27);
    var16.setTickLabelFont((java.lang.Comparable)var22, var27);
    org.jfree.chart.entity.CategoryItemEntity var30 = new org.jfree.chart.entity.CategoryItemEntity(var6, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var11, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var22);
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, var6, "", "poly");
    var2.setRangeAboutValue((-2.0d), 0.2d);
    java.awt.Stroke var37 = var2.getTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var4 = var3.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var6 = var3.getSegment(604800000L);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var9 = var8.getUpperClip();
//     boolean var10 = var8.getBaseCreateEntities();
//     java.awt.Font var11 = var8.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var11);
//     var0.setTickLabelFont((java.lang.Comparable)var6, var11);
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var17.draw(var18, var19);
//     var17.setNotify(false);
//     java.lang.Object var23 = var17.clone();
//     org.jfree.chart.util.RectangleEdge var24 = var17.getPosition();
//     double var25 = var0.getCategoryMiddle(0, 2, var16, var24);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RangeType.FULL", var1);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Multiple Pie Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setSeriesVisibleInLegend((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(100.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.text.DateFormat var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit((-459), 15, 15, 15, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var20 = var19.getAlpha();
    org.jfree.chart.util.Layer var21 = null;
    var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
    org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation();
    org.jfree.chart.annotations.CategoryAnnotation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var25 = var16.removeAnnotation(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
//     var1.setAutoRange(true);
//     org.jfree.chart.axis.TickUnitSource var4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
//     var1.setStandardTickUnits(var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     var11.clearDomainMarkers();
//     boolean var13 = var10.equals((java.lang.Object)var11);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var11.zoomDomainAxes(1.0E-8d, (-1.0d), var16, var17);
//     org.jfree.chart.util.RectangleEdge var19 = var11.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     org.jfree.chart.axis.AxisState var21 = var1.draw(var6, 98.0d, var8, var9, var19, var20);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    double var1 = var0.getFixedDimension();
    boolean var2 = var0.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var1.setLabel("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.util.RectangleAnchor var4 = var1.getLabelAnchor();
    org.jfree.chart.text.TextBlockAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getSectionDepth();
    java.awt.Paint var4 = var1.getLabelLinkPaint();
    java.awt.Paint var6 = var1.getSectionPaint((java.lang.Comparable)Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     org.jfree.chart.util.ShapeList var13 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var13.setShape(100, var16);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     boolean var19 = var18.isRangeGridlinesVisible();
//     var18.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var23 = null;
//     java.util.Collection var24 = var18.getDomainMarkers(100, var23);
//     org.jfree.data.xy.XYDataset var25 = null;
//     int var26 = var18.indexOf(var25);
//     java.awt.Stroke var27 = var18.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     double var30 = var29.getOuterSeparatorExtension();
//     double var31 = var29.getSectionDepth();
//     java.awt.Paint var32 = var29.getLabelPaint();
//     org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var16, var27, var32);
//     var0.setDomainCrosshairPaint(var32);
//     org.jfree.chart.axis.AxisLocation var35 = var0.getDomainAxisLocation();
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     boolean var39 = var38.isRangeGridlinesVisible();
//     java.awt.Paint var40 = var38.getNoDataMessagePaint();
//     org.jfree.chart.plot.DrawingSupplier var41 = var38.getDrawingSupplier();
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     boolean var45 = var44.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var47 = new org.jfree.chart.axis.ValueAxis[] { var46};
//     var44.setDomainAxes(var47);
//     org.jfree.chart.axis.AxisSpace var49 = null;
//     var44.setFixedDomainAxisSpace(var49);
//     var44.setRangeCrosshairValue(98.0d);
//     org.jfree.data.general.PieDataset var53 = null;
//     org.jfree.chart.plot.RingPlot var54 = new org.jfree.chart.plot.RingPlot(var53);
//     double var55 = var54.getOuterSeparatorExtension();
//     double var56 = var54.getSectionDepth();
//     java.awt.Paint var57 = var54.getLabelLinkPaint();
//     var44.setNoDataMessagePaint(var57);
//     java.awt.geom.Point2D var59 = var44.getQuadrantOrigin();
//     var38.zoomRangeAxes((-1.0d), var43, var59);
//     org.jfree.chart.plot.PlotState var61 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     var0.draw(var36, var37, var59, var61, var62);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    double var4 = var0.getContentYOffset();
    org.jfree.chart.util.VerticalAlignment var5 = var0.getVerticalAlignment();
    java.lang.String var6 = var0.getToolTipText();
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[][] var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    var2.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.data.RangeType var6 = var4.getRangeType();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getOuterSeparatorExtension();
    var8.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    boolean var13 = var4.hasListener((java.util.EventListener)var8);
    org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange();
    var4.setDefaultAutoRange((org.jfree.data.Range)var14);
    org.jfree.data.Range var16 = org.jfree.data.Range.combine((org.jfree.data.Range)var1, (org.jfree.data.Range)var14);
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var18 = null;
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, var18);
    org.jfree.chart.block.RectangleConstraint var21 = var19.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var22 = var19.getHeightConstraintType();
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange();
    java.util.Date var25 = var24.getLowerDate();
    org.jfree.data.Range var26 = null;
    org.jfree.data.Range var27 = null;
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, var27);
    org.jfree.chart.block.RectangleConstraint var30 = var28.toFixedHeight(0.0d);
    org.jfree.chart.block.LengthConstraintType var31 = var28.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, (org.jfree.data.Range)var14, var22, 1.0d, (org.jfree.data.Range)var24, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var35 = org.jfree.data.Range.expand((org.jfree.data.Range)var14, (-1.0d), (-2.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var2 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var3 = var2.getUpperClip();
//     boolean var4 = var2.getBaseCreateEntities();
//     java.awt.Font var5 = var2.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("", var5);
//     org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("", var5);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var7.calculateDimensions(var8);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(-1));
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    boolean var5 = var4.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
    var4.setDomainAxes(var7);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var4.setFixedDomainAxisSpace(var9);
    var4.zoom(0.0d);
    java.awt.Paint var13 = var4.getDomainTickBandPaint();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var4.getDomainMarkers(var14);
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("hi!", var3, (org.jfree.chart.plot.Plot)var4, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var19 = var17.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    java.util.List var6 = var5.getSubtitles();
    org.jfree.chart.plot.Plot var7 = var5.getPlot();
    org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var9 = var8.getUpperClip();
    boolean var10 = var8.getBaseCreateEntities();
    java.awt.Font var11 = var8.getBaseItemLabelFont();
    org.jfree.chart.labels.ItemLabelPosition var14 = var8.getNegativeItemLabelPosition(100, 15);
    boolean var15 = var5.equals((java.lang.Object)var8);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
    org.jfree.chart.renderer.category.LayeredBarRenderer var20 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var22 = var20.getSeriesOutlineStroke(1);
    java.awt.Paint var24 = var20.lookupSeriesFillPaint((-1));
    var18.setLabelPaint(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setTextAntiAlias((java.lang.Object)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
//     var18.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var20);
//     org.jfree.data.RangeType var22 = var20.getRangeType();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
//     double var25 = var24.getOuterSeparatorExtension();
//     var24.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     boolean var29 = var20.hasListener((java.util.EventListener)var24);
//     org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange();
//     var20.setDefaultAutoRange((org.jfree.data.Range)var30);
//     var16.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var20, false);
//     
//     // Checks the contract:  equals-hashcode on var9 and var18
//     assertTrue("Contract failed: equals-hashcode on var9 and var18", var9.equals(var18) ? var9.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var9
//     assertTrue("Contract failed: equals-hashcode on var18 and var9", var18.equals(var9) ? var18.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var2 = var0.getTimeFromLong(1L);
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
//     var3.setIgnoreZeroValues(true);
//     var3.setLabelLinkMargin(98.0d);
//     boolean var8 = var0.equals((java.lang.Object)var3);
//     java.util.Date var9 = null;
//     boolean var10 = var0.containsDomainValue(var9);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.lang.Boolean var4 = var2.getSeriesShapesFilled(15);
    var2.setSeriesShapesVisible(15, (java.lang.Boolean)true);
    org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var9 = var8.getUpperClip();
    boolean var10 = var8.getBaseCreateEntities();
    java.awt.Paint var11 = var8.getBaseOutlinePaint();
    java.awt.Paint var12 = var8.getBaseFillPaint();
    var2.setBaseOutlinePaint(var12, true);
    var2.setSeriesShapesFilled(15, (java.lang.Boolean)false);
    var2.setSeriesLinesVisible(10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
    org.jfree.chart.axis.AxisSpace var20 = var16.getFixedRangeAxisSpace();
    org.jfree.chart.axis.ValueAxis var21 = null;
    var16.setRangeAxis(var21);
    org.jfree.chart.plot.PlotOrientation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setOrientation(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
    var4.setLicenceName("");
    org.jfree.chart.ui.Library[] var7 = var4.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var3.setRenderAsPercentages(true);
//     double var6 = var3.getYOffset();
//     boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var10, 1);
//     int var13 = var10.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var14 = null;
//     var10.removeChangeListener(var14);
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
//     var16.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     var19.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var21);
//     java.text.NumberFormat var23 = var21.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var24 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var25 = var24.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, (org.jfree.chart.axis.CategoryAxis)var16, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
//     org.jfree.chart.axis.CategoryAxis var28 = var26.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var29 = var26.getRangeAxisLocation();
//     java.awt.Paint var30 = var26.getDomainGridlinePaint();
//     java.awt.geom.Rectangle2D var31 = null;
//     var3.drawOutline(var9, var26, var31);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     java.awt.Paint var17 = var16.getDomainGridlinePaint();
//     var16.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     var16.drawBackground(var20, var21);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setUpperMargin(98.0d);
    int var3 = var0.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setCategoryLabelPositionOffset((-459));
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     var8.clearDomainMarkers();
//     boolean var10 = var7.equals((java.lang.Object)var8);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var8.zoomDomainAxes(1.0E-8d, (-1.0d), var13, var14);
//     org.jfree.chart.util.RectangleEdge var16 = var8.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.axis.AxisState var18 = var0.draw(var3, 4.0d, var5, var6, var16, var17);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    double var3 = var2.getOuterSeparatorExtension();
    double var4 = var2.getSectionDepth();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    java.util.List var6 = var5.getSubtitles();
    org.jfree.chart.plot.Plot var7 = var5.getPlot();
    org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var9 = var8.getUpperClip();
    boolean var10 = var8.getBaseCreateEntities();
    java.awt.Font var11 = var8.getBaseItemLabelFont();
    org.jfree.chart.labels.ItemLabelPosition var14 = var8.getNegativeItemLabelPosition(100, 15);
    boolean var15 = var5.equals((java.lang.Object)var8);
    org.jfree.chart.entity.EntityCollection var19 = null;
    org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var21 = var5.createBufferedImage((-459), 10, 0, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.awt.Paint var2 = var1.getBorderPaint();
    org.jfree.chart.ChartRenderingInfo var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var8 = var1.createBufferedImage(100, (-459), 0.0d, 0.0d, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     var2.setBaseShapesVisible(false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
//     java.awt.Paint var7 = var2.getSeriesItemLabelPaint(0);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var2.drawDomainGridline(var8, var9, var10, 4.0d);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.urls.StandardCategoryURLGenerator var21 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "Other", "java.awt.Color[r=255,g=255,b=255]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setSeriesURLGenerator((-459), (org.jfree.chart.urls.CategoryURLGenerator)var21, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    boolean var3 = var2.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var5 = new org.jfree.chart.axis.ValueAxis[] { var4};
    var2.setDomainAxes(var5);
    org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
    double var10 = var9.getOuterSeparatorExtension();
    double var11 = var9.getSectionDepth();
    java.awt.Paint var12 = var9.getLabelLinkPaint();
    var2.setOutlinePaint(var12);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    boolean var15 = var14.isRangeGridlinesVisible();
    var14.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var14.getDomainMarkers(100, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    int var22 = var14.indexOf(var21);
    java.awt.Stroke var23 = var14.getRangeGridlineStroke();
    org.jfree.chart.renderer.category.StackedBarRenderer3D var27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
    var27.setRenderAsPercentages(true);
    java.awt.Paint var30 = var27.getWallPaint();
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var32 = var31.getBackgroundPaint();
    java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
    java.awt.Paint[] var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    boolean var36 = var35.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var38 = new org.jfree.chart.axis.ValueAxis[] { var37};
    var35.setDomainAxes(var38);
    org.jfree.chart.axis.AxisLocation var40 = var35.getDomainAxisLocation();
    org.jfree.data.general.PieDataset var41 = null;
    org.jfree.chart.plot.RingPlot var42 = new org.jfree.chart.plot.RingPlot(var41);
    double var43 = var42.getOuterSeparatorExtension();
    double var44 = var42.getSectionDepth();
    java.awt.Paint var45 = var42.getLabelLinkPaint();
    var35.setOutlinePaint(var45);
    java.awt.Paint[] var47 = new java.awt.Paint[] { var45};
    java.awt.Stroke var48 = null;
    java.awt.Stroke[] var49 = new java.awt.Stroke[] { var48};
    java.awt.Stroke var50 = null;
    java.awt.Stroke[] var51 = new java.awt.Stroke[] { var50};
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    java.awt.Shape[] var54 = new java.awt.Shape[] { var53};
    org.jfree.chart.plot.DefaultDrawingSupplier var55 = new org.jfree.chart.plot.DefaultDrawingSupplier(var33, var34, var47, var49, var51, var54);
    java.awt.Paint var56 = var55.getNextOutlinePaint();
    var27.setWallPaint(var56);
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
    var58.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var60);
    org.jfree.chart.renderer.category.LayeredBarRenderer var62 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var64 = var62.getSeriesOutlineStroke(1);
    java.awt.Paint var66 = var62.lookupSeriesFillPaint((-1));
    var60.setLabelPaint(var66);
    java.awt.Stroke var68 = var60.getTickMarkStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var70 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (-1.0d), var12, var23, var56, var68, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.util.UnitType var2 = var1.getUnitType();
    double var4 = var1.calculateTopInset((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(-1));
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    boolean var5 = var4.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
    var4.setDomainAxes(var7);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var4.setFixedDomainAxisSpace(var9);
    var4.zoom(0.0d);
    java.awt.Paint var13 = var4.getDomainTickBandPaint();
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var4.getDomainMarkers(var14);
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("hi!", var3, (org.jfree.chart.plot.Plot)var4, false);
    org.jfree.chart.event.ChartChangeListener var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.addChangeListener(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    java.awt.Paint var17 = var16.getDomainGridlinePaint();
    var16.configureRangeAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
    boolean var20 = var16.isOutlineVisible();
    java.awt.Stroke var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setRangeGridlineStroke(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.awt.Paint var2 = var1.getBorderPaint();
    org.jfree.chart.event.ChartChangeListener var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeChangeListener(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var2 = var1.getToolTipText();
    java.awt.Font var3 = var1.getFont();
    java.lang.String var4 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var1.setLabel("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.util.RectangleAnchor var4 = var1.getLabelAnchor();
    org.jfree.chart.text.TextBlockAnchor var5 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition(var4, var5, var6, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     java.awt.Paint var17 = var16.getDomainGridlinePaint();
//     var16.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
//     boolean var20 = var16.isOutlineVisible();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var24.setRenderAsPercentages(true);
//     java.awt.Paint var27 = var24.getWallPaint();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var29 = var28.getBackgroundPaint();
//     java.awt.Paint[] var30 = new java.awt.Paint[] { var29};
//     java.awt.Paint[] var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     boolean var33 = var32.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var35 = new org.jfree.chart.axis.ValueAxis[] { var34};
//     var32.setDomainAxes(var35);
//     org.jfree.chart.axis.AxisLocation var37 = var32.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     double var40 = var39.getOuterSeparatorExtension();
//     double var41 = var39.getSectionDepth();
//     java.awt.Paint var42 = var39.getLabelLinkPaint();
//     var32.setOutlinePaint(var42);
//     java.awt.Paint[] var44 = new java.awt.Paint[] { var42};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var51 = new java.awt.Shape[] { var50};
//     org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier(var30, var31, var44, var46, var48, var51);
//     java.awt.Paint var53 = var52.getNextOutlinePaint();
//     var24.setWallPaint(var53);
//     boolean var55 = var24.getRenderAsPercentages();
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var56 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var24};
//     var16.setRenderers(var56);
//     
//     // Checks the contract:  equals-hashcode on var28 and var9
//     assertTrue("Contract failed: equals-hashcode on var28 and var9", var28.equals(var9) ? var28.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var9.", var28.equals(var9) == var9.equals(var28));
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var3.setRenderAsPercentages(true);
//     java.awt.Paint var6 = var3.getWallPaint();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var10 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var11 = var10.getUpperClip();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     boolean var13 = var12.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var14};
//     var12.setDomainAxes(var15);
//     org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation();
//     boolean var18 = var10.equals((java.lang.Object)var17);
//     var7.setRangeAxisLocation(10, var17, true);
//     boolean var21 = var7.isRangeCrosshairLockedOnData();
//     boolean var22 = var3.equals((java.lang.Object)var7);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, 1);
//     int var27 = var24.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var28 = null;
//     var24.removeChangeListener(var28);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var33.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var35);
//     java.text.NumberFormat var37 = var35.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var38 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var39 = var38.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     org.jfree.chart.axis.CategoryAxis var42 = var40.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var43 = var40.getRangeAxisLocation();
//     org.jfree.chart.plot.Plot var44 = var40.getRootPlot();
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
//     var45.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var47);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var49 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Stroke var51 = var49.getSeriesOutlineStroke(1);
//     java.awt.Paint var53 = var49.lookupSeriesFillPaint((-1));
//     var47.setLabelPaint(var53);
//     org.jfree.data.time.DateRange var55 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     var56.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var58);
//     org.jfree.data.RangeType var60 = var58.getRangeType();
//     org.jfree.data.general.PieDataset var61 = null;
//     org.jfree.chart.plot.RingPlot var62 = new org.jfree.chart.plot.RingPlot(var61);
//     double var63 = var62.getOuterSeparatorExtension();
//     var62.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     boolean var67 = var58.hasListener((java.util.EventListener)var62);
//     org.jfree.data.time.DateRange var68 = new org.jfree.data.time.DateRange();
//     var58.setDefaultAutoRange((org.jfree.data.Range)var68);
//     org.jfree.data.Range var70 = org.jfree.data.Range.combine((org.jfree.data.Range)var55, (org.jfree.data.Range)var68);
//     var47.setRange(var70);
//     org.jfree.chart.plot.ValueMarker var73 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var74 = var73.getPaint();
//     java.awt.geom.Rectangle2D var75 = null;
//     var3.drawRangeMarker(var23, var40, (org.jfree.chart.axis.ValueAxis)var47, (org.jfree.chart.plot.Marker)var73, var75);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedRangeAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, Double.NaN, 10.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var5.draw(var6, var7);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    double var1 = var0.getMax();
    var0.setMax(100.0d);
    var0.cursorRight(10.0d);
    var0.cursorLeft(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    boolean var5 = var0.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(15, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var10 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-2.0d), 0.0d, 0, (java.lang.Comparable)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getPositiveItemLabelPosition(0, 2);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     var4.addChangeListener((org.jfree.chart.event.RendererChangeListener)var8);
//     double var10 = var4.getLowerClip();
//     java.awt.Shape var13 = var4.getItemShape(2, 0);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     var14.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var16);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var18 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Stroke var20 = var18.getSeriesOutlineStroke(1);
//     java.awt.Paint var22 = var18.lookupSeriesFillPaint((-1));
//     var16.setLabelPaint(var22);
//     boolean var24 = var16.isPositiveArrowVisible();
//     java.awt.Stroke var25 = var16.getAxisLineStroke();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var27 = var26.getBackgroundPaint();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Paint[] var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
//     boolean var31 = var30.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var33 = new org.jfree.chart.axis.ValueAxis[] { var32};
//     var30.setDomainAxes(var33);
//     org.jfree.chart.axis.AxisLocation var35 = var30.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
//     double var38 = var37.getOuterSeparatorExtension();
//     double var39 = var37.getSectionDepth();
//     java.awt.Paint var40 = var37.getLabelLinkPaint();
//     var30.setOutlinePaint(var40);
//     java.awt.Paint[] var42 = new java.awt.Paint[] { var40};
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var49 = new java.awt.Shape[] { var48};
//     org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var28, var29, var42, var44, var46, var49);
//     java.awt.Paint var51 = var50.getNextPaint();
//     org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "Pie Plot", var13, var25, var51);
//     
//     // Checks the contract:  equals-hashcode on var8 and var14
//     assertTrue("Contract failed: equals-hashcode on var8 and var14", var8.equals(var14) ? var8.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var14
//     assertTrue("Contract failed: equals-hashcode on var26 and var14", var26.equals(var14) ? var26.hashCode() == var14.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var14.", var8.equals(var14) == var14.equals(var8));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var14.", var26.equals(var14) == var14.equals(var26));
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var3 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var4 = var3.getUpperClip();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     boolean var6 = var5.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var5.setDomainAxes(var8);
//     org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation();
//     boolean var11 = var3.equals((java.lang.Object)var10);
//     var0.setRangeAxisLocation(10, var10, true);
//     org.jfree.chart.plot.Plot var14 = var0.getParent();
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var0.getDomainMarkers(var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     boolean var20 = var19.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var22 = new org.jfree.chart.axis.ValueAxis[] { var21};
//     var19.setDomainAxes(var22);
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var19.setFixedDomainAxisSpace(var24);
//     var19.zoom(0.0d);
//     java.awt.Paint var28 = var19.getDomainTickBandPaint();
//     java.awt.Paint var29 = var19.getDomainGridlinePaint();
//     java.awt.Graphics2D var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot(var33);
//     double var35 = var34.getOuterSeparatorExtension();
//     double var36 = var34.getSectionDepth();
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var34);
//     java.util.List var38 = var37.getSubtitles();
//     var19.drawDomainTickBands(var30, var31, var38);
//     var0.drawRangeTickBands(var17, var18, var38);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    java.lang.String var3 = var1.getNoDataMessage();
    org.jfree.data.DefaultKeyedValues2D var5 = new org.jfree.data.DefaultKeyedValues2D(false);
    java.util.List var6 = var5.getColumnKeys();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 1);
    int var10 = var7.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var11 = null;
    var7.removeChangeListener(var11);
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    var13.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
    java.text.NumberFormat var20 = var18.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var22 = var21.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, (org.jfree.chart.axis.CategoryAxis)var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    java.awt.Color var27 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var28 = var27.brighter();
    var23.setDomainGridlinePaint((java.awt.Paint)var27);
    boolean var30 = var5.equals((java.lang.Object)var27);
    var1.setLabelPaint((java.awt.Paint)var27);
    var1.setSeparatorsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var20 = var19.getAlpha();
    org.jfree.chart.util.Layer var21 = null;
    var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
    org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation();
    org.jfree.chart.plot.CategoryMarker var24 = null;
    org.jfree.chart.util.Layer var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addDomainMarker(var24, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     var16.setAnchorValue((-1.0d), false);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     boolean var23 = var22.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var24};
//     var22.setDomainAxes(var25);
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var22.setFixedDomainAxisSpace(var27);
//     var22.zoom(0.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var31, 1);
//     org.jfree.data.general.PieDataset var37 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var33, (java.lang.Comparable)(short)0, (-1.0d), 10);
//     org.jfree.data.general.DatasetChangeEvent var38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0.0d, (org.jfree.data.general.Dataset)var37);
//     var16.datasetChanged(var38);
//     
//     // Checks the contract:  equals-hashcode on var0 and var31
//     assertTrue("Contract failed: equals-hashcode on var0 and var31", var0.equals(var31) ? var0.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.resources.DataPackageResources var0 = new org.jfree.data.resources.DataPackageResources();
    java.lang.Object var2 = var0.handleGetObject("First");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var4 = var0.getStringArray("12/31/69 4:00 PM");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)0.0d, (java.lang.Number)(short)1);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1, var7);
    var0.addValue((java.lang.Comparable)1, (-2.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    java.awt.Paint var2 = var0.getNoDataMessagePaint();
    org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    var5.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var7);
    org.jfree.chart.renderer.category.LayeredBarRenderer var9 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var11 = var9.getSeriesOutlineStroke(1);
    java.awt.Paint var13 = var9.lookupSeriesFillPaint((-1));
    var7.setLabelPaint(var13);
    java.text.NumberFormat var15 = null;
    var7.setNumberFormatOverride(var15);
    var0.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis)var7);
    var7.setPositiveArrowVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     var1.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var3);
//     org.jfree.chart.plot.DatasetRenderingOrder var5 = var1.getDatasetRenderingOrder();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var6.draw(var7, var8);
//     boolean var10 = var1.equals((java.lang.Object)var8);
//     java.awt.Paint var11 = var1.getRangeCrosshairPaint();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     boolean var13 = var12.isRangeGridlinesVisible();
//     var12.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.plot.DrawingSupplier var16 = var12.getDrawingSupplier();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var17.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var19);
//     java.awt.Stroke var21 = var17.getDomainCrosshairStroke();
//     var12.setRangeZeroBaselineStroke(var21);
//     java.awt.Paint var23 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, 1);
//     int var27 = var24.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var28 = null;
//     var24.removeChangeListener(var28);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var33.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var35);
//     java.text.NumberFormat var37 = var35.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var38 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var39 = var38.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var44 = var43.getAlpha();
//     org.jfree.chart.util.Layer var45 = null;
//     var40.addRangeMarker(10, (org.jfree.chart.plot.Marker)var43, var45);
//     java.awt.Stroke var47 = var43.getStroke();
//     org.jfree.chart.plot.CategoryMarker var49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)10.0d, var11, var21, var23, var47, 0.5f);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var33
//     assertTrue("Contract failed: equals-hashcode on var17 and var33", var17.equals(var33) ? var17.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var17
//     assertTrue("Contract failed: equals-hashcode on var33 and var17", var33.equals(var17) ? var33.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getOuterSeparatorExtension();
//     double var3 = var1.getSectionDepth();
//     java.awt.Paint var5 = var1.getSectionOutlinePaint((java.lang.Comparable)0.0f);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     boolean var8 = var7.isCircular();
//     org.jfree.chart.labels.PieSectionLabelGenerator var9 = var7.getLabelGenerator();
//     var1.setLegendLabelGenerator(var9);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    java.lang.String var3 = var1.getNoDataMessage();
    java.awt.Stroke var4 = var1.getSeparatorStroke();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    boolean var6 = var5.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var5.setDomainAxes(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var5.setFixedDomainAxisSpace(var10);
    var5.zoom(0.0d);
    java.awt.Paint var14 = var5.getDomainTickBandPaint();
    java.awt.Paint var15 = var5.getDomainGridlinePaint();
    var1.setLabelPaint(var15);
    org.jfree.chart.util.RectangleInsets var17 = var1.getInsets();
    java.awt.geom.Rectangle2D var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var19 = var17.createOutsetRectangle(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.mapDatasetToDomainAxis((-1), 100);
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var0.zoomDomainAxes(4.0d, var5, var6);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.data.RangeType var4 = var2.getRangeType();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    double var7 = var6.getOuterSeparatorExtension();
    var6.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    boolean var11 = var2.hasListener((java.util.EventListener)var6);
    org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange();
    var2.setDefaultAutoRange((org.jfree.data.Range)var12);
    double var14 = var12.getLength();
    double var16 = var12.constrain(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.String var1 = var0.getPlotType();
    java.awt.Color var5 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    var0.setAggregatedItemsPaint((java.awt.Paint)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Multiple Pie Plot"+ "'", var1.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("hi!", "Other", "java.awt.Color[r=255,g=255,b=255]");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 1);
    int var7 = var4.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var8 = null;
    var4.removeChangeListener(var8);
    var4.add(10.0d, 0.05d, (java.lang.Comparable)'#', (java.lang.Comparable)100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var3.generateURL((org.jfree.data.category.CategoryDataset)var4, 100, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    var0.addException(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var20 = var19.getAlpha();
//     org.jfree.chart.util.Layer var21 = null;
//     var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
//     java.awt.Stroke var23 = var19.getStroke();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var24.draw(var25, var26);
//     var24.setNotify(false);
//     java.lang.Object var30 = var24.clone();
//     org.jfree.chart.util.RectangleEdge var31 = var24.getPosition();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     var32.draw(var33, var34);
//     var32.setNotify(false);
//     java.lang.Object var38 = var32.clone();
//     org.jfree.chart.util.RectangleEdge var39 = var32.getPosition();
//     var24.setPosition(var39);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var41 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var41, 1);
//     int var44 = var41.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var45 = null;
//     var41.removeChangeListener(var45);
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
//     var47.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     var50.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var52);
//     java.text.NumberFormat var54 = var52.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var55 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var56 = var55.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var41, (org.jfree.chart.axis.CategoryAxis)var47, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
//     org.jfree.chart.axis.CategoryAxis var59 = var57.getDomainAxisForDataset(100);
//     boolean var60 = var24.equals((java.lang.Object)100);
//     java.awt.Font var61 = var24.getFont();
//     var19.setLabelFont(var61);
//     
//     // Checks the contract:  equals-hashcode on var0 and var41
//     assertTrue("Contract failed: equals-hashcode on var0 and var41", var0.equals(var41) ? var0.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var0
//     assertTrue("Contract failed: equals-hashcode on var41 and var0", var41.equals(var0) ? var41.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var50
//     assertTrue("Contract failed: equals-hashcode on var9 and var50", var9.equals(var50) ? var9.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var9
//     assertTrue("Contract failed: equals-hashcode on var50 and var9", var50.equals(var9) ? var50.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var57
//     assertTrue("Contract failed: equals-hashcode on var16 and var57", var16.equals(var57) ? var16.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var16
//     assertTrue("Contract failed: equals-hashcode on var57 and var16", var57.equals(var16) ? var57.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(15, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var10 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 100.0d, 4.0d, 10, (java.lang.Comparable)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    java.lang.String var3 = var1.getNoDataMessage();
    org.jfree.data.DefaultKeyedValues2D var5 = new org.jfree.data.DefaultKeyedValues2D(false);
    java.util.List var6 = var5.getColumnKeys();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 1);
    int var10 = var7.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var11 = null;
    var7.removeChangeListener(var11);
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    var13.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
    java.text.NumberFormat var20 = var18.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var21 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var22 = var21.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, (org.jfree.chart.axis.CategoryAxis)var13, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    java.awt.Color var27 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var28 = var27.brighter();
    var23.setDomainGridlinePaint((java.awt.Paint)var27);
    boolean var30 = var5.equals((java.lang.Object)var27);
    var1.setLabelPaint((java.awt.Paint)var27);
    float[] var32 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var33 = var27.getColorComponents(var32);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Preceding"+ "'", var1.equals("Preceding"));

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var1 = var0.getUpperClip();
//     boolean var2 = var0.getBaseCreateEntities();
//     java.awt.Paint var3 = var0.getBaseOutlinePaint();
//     var0.setBaseItemLabelsVisible(false);
//     org.jfree.chart.renderer.category.StackedAreaRenderer var7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, 1);
//     org.jfree.data.Range var11 = var7.findRangeBounds((org.jfree.data.category.CategoryDataset)var8);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var12 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var13 = var12.getUpperClip();
//     java.awt.Stroke var16 = var12.getItemStroke((-459), (-459));
//     var7.setBaseStroke(var16, false);
//     var0.setSeriesOutlineStroke(0, var16);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    boolean var5 = var2.getItemShapeVisible((-459), 1);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var7.getPositiveItemLabelPosition(0, 2);
    org.jfree.chart.text.TextAnchor var11 = var10.getTextAnchor();
    var2.setSeriesPositiveItemLabelPosition(10, var10, false);
    boolean var14 = var2.getBaseShapesVisible();
    var2.setSeriesLinesVisible(2, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(4.0d, 0.65d, var2);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var6 = var4.getSeriesOutlineStroke(1);
    java.awt.Paint var8 = var4.lookupSeriesFillPaint((-1));
    var2.setLabelPaint(var8);
    var2.setAutoRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getOuterSeparatorExtension();
//     double var3 = var1.getSectionDepth();
//     java.awt.Paint var4 = var1.getLabelLinkPaint();
//     org.jfree.chart.labels.PieSectionLabelGenerator var5 = null;
//     var1.setLegendLabelToolTipGenerator(var5);
//     boolean var7 = var1.isSubplot();
//     double var8 = var1.getMaximumExplodePercent();
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
//     var3.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
//     java.util.Date var8 = var7.getLowerDate();
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var3.dateToJava2D(var8, var9, var10);
//     var1.setMinimumDate(var8);
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var1.java2DToValue(0.0d, var14, var15);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var17 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Stroke var19 = var17.getSeriesOutlineStroke(1);
//     var17.setDrawBarOutline(false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var23 = null;
//     var17.setSeriesToolTipGenerator(100, var23);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     var26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
//     java.text.NumberFormat var30 = var28.getNumberFormatOverride();
//     java.awt.Paint var31 = var28.getTickMarkPaint();
//     var17.setSeriesItemLabelPaint(0, var31, false);
//     boolean var34 = var1.equals((java.lang.Object)0);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     var35.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var37);
//     org.jfree.chart.plot.DatasetRenderingOrder var39 = var35.getDatasetRenderingOrder();
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     var40.draw(var41, var42);
//     boolean var44 = var35.equals((java.lang.Object)var42);
//     java.awt.Paint var45 = var35.getRangeCrosshairPaint();
//     var1.setLabelPaint(var45);
//     
//     // Checks the contract:  equals-hashcode on var26 and var35
//     assertTrue("Contract failed: equals-hashcode on var26 and var35", var26.equals(var35) ? var26.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var26
//     assertTrue("Contract failed: equals-hashcode on var35 and var26", var35.equals(var26) ? var35.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    boolean var4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    var5.mapDatasetToDomainAxis((-1), 100);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
    var5.setDomainZeroBaselineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.zoom(0.0d);
    java.awt.Paint var9 = var0.getDomainTickBandPaint();
    org.jfree.chart.axis.ValueAxis var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-459), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(2);
//     java.awt.Font var5 = var0.getTickLabelFont((java.lang.Comparable)2);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
//     int var9 = var6.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var10 = null;
//     var6.removeChangeListener(var10);
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
//     var12.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     var15.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var17);
//     java.text.NumberFormat var19 = var17.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var20 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var21 = var20.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, (org.jfree.chart.axis.CategoryAxis)var12, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.axis.CategoryAxis var24 = var22.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var25 = var22.getRangeAxisLocation();
//     org.jfree.chart.plot.Plot var26 = var22.getRootPlot();
//     org.jfree.chart.axis.CategoryAnchor var27 = var22.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var31.draw(var32, var33);
//     var31.setNotify(false);
//     java.lang.Object var37 = var31.clone();
//     org.jfree.chart.util.RectangleEdge var38 = var31.getPosition();
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     var39.draw(var40, var41);
//     var39.setNotify(false);
//     java.lang.Object var45 = var39.clone();
//     org.jfree.chart.util.RectangleEdge var46 = var39.getPosition();
//     var31.setPosition(var46);
//     double var48 = var0.getCategoryJava2DCoordinate(var27, 10, (-459), var30, var46);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    double var11 = var10.getOuterSeparatorExtension();
    double var12 = var10.getSectionDepth();
    java.awt.Paint var13 = var10.getLabelLinkPaint();
    var0.setNoDataMessagePaint(var13);
    java.awt.geom.Point2D var15 = var0.getQuadrantOrigin();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    var0.drawAnnotations(var16, var17, var18);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    var0.setRenderer(var20);
    java.awt.geom.Point2D var22 = var0.getQuadrantOrigin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
    java.util.List var2 = var1.getColumnKeys();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, 1);
    int var6 = var3.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var7 = null;
    var3.removeChangeListener(var7);
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
    var9.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    var12.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var14);
    java.text.NumberFormat var16 = var14.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var17 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var18 = var17.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var3, (org.jfree.chart.axis.CategoryAxis)var9, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
    java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.awt.Color var24 = var23.brighter();
    var19.setDomainGridlinePaint((java.awt.Paint)var23);
    boolean var26 = var1.equals((java.lang.Object)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange();
    java.util.Date var6 = var5.getLowerDate();
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var1.dateToJava2D(var6, var7, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(0.2d, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
//     java.awt.Paint[] var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     boolean var5 = var4.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var4.setDomainAxes(var7);
//     org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getOuterSeparatorExtension();
//     double var13 = var11.getSectionDepth();
//     java.awt.Paint var14 = var11.getLabelLinkPaint();
//     var4.setOutlinePaint(var14);
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var14};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var16, var18, var20, var23);
//     java.awt.Paint var25 = var24.getNextPaint();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, 1);
//     int var29 = var26.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var30 = null;
//     var26.removeChangeListener(var30);
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     var32.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     var35.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var37);
//     java.text.NumberFormat var39 = var37.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var40 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var41 = var40.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, (org.jfree.chart.axis.CategoryAxis)var32, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
//     java.util.List var43 = var42.getAnnotations();
//     boolean var44 = var24.equals((java.lang.Object)var42);
//     
//     // Checks the contract:  equals-hashcode on var0 and var35
//     assertTrue("Contract failed: equals-hashcode on var0 and var35", var0.equals(var35) ? var0.hashCode() == var35.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var35.", var0.equals(var35) == var35.equals(var0));
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    double var1 = var0.getLimit();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    var3.removeLegend();
    org.jfree.chart.title.TextTitle var6 = var3.getTitle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPieChart(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 10, 4);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.data.RangeType var8 = var6.getRangeType();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
    double var11 = var10.getOuterSeparatorExtension();
    var10.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    boolean var15 = var6.hasListener((java.util.EventListener)var10);
    boolean var16 = var10.getLabelLinksVisible();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
    var0.validateObject();
    java.lang.Comparable var19 = null;
    java.lang.Number var21 = var0.getMeanValue(var19, (java.lang.Comparable)15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var1 = var0.getUpperClip();
    java.awt.Stroke var4 = var0.getItemStroke((-459), (-459));
    boolean var5 = var0.getBaseSeriesVisible();
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var0.setBaseItemLabelGenerator(var6, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    java.util.List var5 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var6 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var5);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.String[] var3 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var3, var4, var6);
//     java.lang.String[] var9 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var10 = null;
//     java.lang.Number[] var11 = null;
//     java.lang.Number[][] var12 = new java.lang.Number[][] { var11};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var9, var10, var12);
//     org.jfree.data.category.DefaultIntervalCategoryDataset var14 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var4, var12);
//     
//     // Checks the contract:  equals-hashcode on var7 and var13
//     assertTrue("Contract failed: equals-hashcode on var7 and var13", var7.equals(var13) ? var7.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var14
//     assertTrue("Contract failed: equals-hashcode on var7 and var14", var7.equals(var14) ? var7.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var7
//     assertTrue("Contract failed: equals-hashcode on var13 and var7", var13.equals(var7) ? var13.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var14
//     assertTrue("Contract failed: equals-hashcode on var13 and var14", var13.equals(var14) ? var13.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var7
//     assertTrue("Contract failed: equals-hashcode on var14 and var7", var14.equals(var7) ? var14.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var13
//     assertTrue("Contract failed: equals-hashcode on var14 and var13", var14.equals(var13) ? var14.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     java.awt.Image var2 = var1.getBackgroundImage();
//     var1.removeLegend();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var5 = var4.getPadding();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var4.draw(var6, var7);
//     var4.setToolTipText("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var11 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     var12.clearDomainMarkers();
//     boolean var14 = var11.equals((java.lang.Object)var12);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var12.zoomDomainAxes(1.0E-8d, (-1.0d), var17, var18);
//     org.jfree.chart.util.RectangleEdge var20 = var12.getRangeAxisEdge();
//     var4.setPosition(var20);
//     var1.removeSubtitle((org.jfree.chart.title.Title)var4);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    var0.setNotify(false);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.RectangleEdge var7 = var0.getPosition();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var8.draw(var9, var10);
    var8.setNotify(false);
    java.lang.Object var14 = var8.clone();
    org.jfree.chart.util.RectangleEdge var15 = var8.getPosition();
    var0.setPosition(var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var17, 1);
    int var20 = var17.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var21 = null;
    var17.removeChangeListener(var21);
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
    var23.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
    var26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
    java.text.NumberFormat var30 = var28.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var31 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var32 = var31.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    org.jfree.chart.axis.CategoryAxis var35 = var33.getDomainAxisForDataset(100);
    boolean var36 = var0.equals((java.lang.Object)100);
    java.awt.Font var37 = var0.getFont();
    var0.setPadding(0.65d, (-2.0d), (-2.0d), 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     var1.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange();
//     java.util.Date var5 = var4.getLowerDate();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var1.dateToJava2D(var5, var6, var7);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var11 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     var12.clearDomainMarkers();
//     boolean var14 = var11.equals((java.lang.Object)var12);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var12.zoomDomainAxes(1.0E-8d, (-1.0d), var17, var18);
//     org.jfree.chart.util.RectangleEdge var20 = var12.getRangeAxisEdge();
//     double var21 = var1.lengthToJava2D(2.0d, var10, var20);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     double var4 = var0.getRangeUpperBound(false);
//     org.jfree.chart.axis.SegmentedTimeline var6 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var7 = var6.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var9 = var6.getSegment(604800000L);
//     java.lang.Number var10 = var0.getValue((java.lang.Comparable)1577894400000L, (java.lang.Comparable)604800000L);
//     java.lang.Comparable var13 = null;
//     var0.add((java.lang.Number)1.0E-8d, (java.lang.Number)0.8f, var13, (java.lang.Comparable)2.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var17 = var0.getColumnKey(2);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 86400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    java.awt.Paint var18 = null;
    var14.setSeriesItemLabelPaint(0, var18, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RangeType.FULL", var1);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    org.jfree.chart.renderer.category.LayeredBarRenderer var3 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var4 = var3.getUpperClip();
    boolean var5 = var3.getBaseCreateEntities();
    java.awt.Paint var6 = var3.getBaseOutlinePaint();
    java.awt.Paint var7 = var3.getBaseFillPaint();
    var0.setObject((java.lang.Object)var7, (java.lang.Comparable)10.0f, (java.lang.Comparable)10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)(-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     org.jfree.data.time.Year var3 = var1.getYear();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(2, var3);
//     java.util.Calendar var5 = null;
//     var3.peg(var5);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
//     var0.setDomainAxes(var3);
//     org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     double var8 = var7.getOuterSeparatorExtension();
//     double var9 = var7.getSectionDepth();
//     java.awt.Paint var10 = var7.getLabelLinkPaint();
//     var0.setOutlinePaint(var10);
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     double var14 = var13.getOuterSeparatorExtension();
//     double var15 = var13.getSectionDepth();
//     java.awt.Paint var16 = var13.getLabelLinkPaint();
//     org.jfree.chart.labels.PieSectionLabelGenerator var17 = null;
//     var13.setLegendLabelToolTipGenerator(var17);
//     boolean var19 = var13.isSubplot();
//     java.awt.Paint var20 = var13.getSeparatorPaint();
//     var0.setRangeCrosshairPaint(var20);
//     
//     // Checks the contract:  equals-hashcode on var7 and var13
//     assertTrue("Contract failed: equals-hashcode on var7 and var13", var7.equals(var13) ? var7.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var7
//     assertTrue("Contract failed: equals-hashcode on var13 and var7", var13.equals(var7) ? var13.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    var0.setNotify(false);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.util.RectangleEdge var7 = var0.getPosition();
    boolean var8 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
    java.lang.String var5 = var4.getName();
    var4.setName("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     int var6 = var5.getColumnCount();
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var3.setRenderAsPercentages(true);
//     double var6 = var3.getYOffset();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, 1);
//     int var11 = var8.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var12 = null;
//     var8.removeChangeListener(var12);
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
//     var14.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var17.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var19);
//     java.text.NumberFormat var21 = var19.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var23 = var22.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     java.awt.Paint var25 = var24.getDomainGridlinePaint();
//     var24.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var27 = var24.getDatasetRenderingOrder();
//     boolean var28 = var24.isOutlineVisible();
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var32 = var31.clone();
//     java.awt.geom.Rectangle2D var33 = null;
//     var3.drawRangeMarker(var7, var24, var29, (org.jfree.chart.plot.Marker)var31, var33);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var3 = var2.getYear();
    org.jfree.data.time.Year var4 = var2.getYear();
    org.jfree.data.time.RegularTimePeriod var5 = var4.previous();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var1.getValue((java.lang.Comparable)var4, (java.lang.Comparable)(-2.0d));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getPositiveItemLabelPosition(0, 2);
    org.jfree.chart.util.GradientPaintTransformer var4 = null;
    var0.setGradientPaintTransformer(var4);
    java.lang.Object var6 = null;
    boolean var7 = var0.equals(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var2 = null;
    int var3 = var0.getRangeAxisIndex(var2);
    org.jfree.chart.axis.AxisSpace var4 = var0.getFixedRangeAxisSpace();
    var0.setRangeCrosshairValue((-1.0d), false);
    org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.util.RectangleInsets var11 = var10.getLabelInsets();
    double var12 = var10.getAutoRangeMinimumSize();
    boolean var13 = var9.equals((java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-459), (org.jfree.chart.axis.ValueAxis)var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     int var6 = var5.getRowCount();
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(Double.NaN, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     double var2 = var1.getTop();
//     java.awt.geom.Rectangle2D var3 = null;
//     var1.trim(var3);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
    java.lang.Number[][] var2 = null;
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var5.getSeriesKey(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
//     var3.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
//     java.util.Date var8 = var7.getLowerDate();
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var3.dateToJava2D(var8, var9, var10);
//     var1.setMinimumDate(var8);
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
//     var14.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
//     java.util.Date var18 = var17.getLowerDate();
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var14.dateToJava2D(var18, var19, var20);
//     org.jfree.data.time.SimpleTimePeriod var22 = new org.jfree.data.time.SimpleTimePeriod(var8, var18);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var8);
//     java.util.TimeZone var24 = null;
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(var8, var24);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(2);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addDays(1, var9);
//     java.lang.Number var11 = var5.getStartValue((java.lang.Comparable)1, (java.lang.Comparable)var9);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    int var3 = var2.getPassCount();
    java.awt.Paint var5 = null;
    var2.setSeriesFillPaint(0, var5);
    var2.setBaseCreateEntities(true);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    org.jfree.chart.util.ShapeList var22 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var22.setShape(100, var25);
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    boolean var28 = var27.isRangeGridlinesVisible();
    var27.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var27.getDomainMarkers(100, var32);
    org.jfree.data.xy.XYDataset var34 = null;
    int var35 = var27.indexOf(var34);
    java.awt.Stroke var36 = var27.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var37 = null;
    org.jfree.chart.plot.RingPlot var38 = new org.jfree.chart.plot.RingPlot(var37);
    double var39 = var38.getOuterSeparatorExtension();
    double var40 = var38.getSectionDepth();
    java.awt.Paint var41 = var38.getLabelPaint();
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var25, var36, var41);
    var9.setDomainCrosshairPaint(var41);
    org.jfree.chart.axis.AxisLocation var44 = var9.getDomainAxisLocation();
    java.awt.Paint var46 = var9.getQuadrantPaint(0);
    var2.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    java.lang.Number var3 = var0.getMaxOutlier((java.lang.Comparable)10, (java.lang.Comparable)0.8f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getMeanValue(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     java.awt.Stroke var9 = var0.getRangeGridlineStroke();
//     java.awt.Paint var10 = var0.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     double var14 = var13.getOuterSeparatorExtension();
//     double var15 = var13.getSectionDepth();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var23 = var22.getUpperClip();
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     boolean var25 = var24.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var27 = new org.jfree.chart.axis.ValueAxis[] { var26};
//     var24.setDomainAxes(var27);
//     org.jfree.chart.axis.AxisLocation var29 = var24.getDomainAxisLocation();
//     boolean var30 = var22.equals((java.lang.Object)var29);
//     var19.setRangeAxisLocation(10, var29, true);
//     org.jfree.chart.plot.Plot var33 = var19.getParent();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     boolean var35 = var34.isRangeGridlinesVisible();
//     var34.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var39 = null;
//     java.util.Collection var40 = var34.getDomainMarkers(100, var39);
//     org.jfree.data.xy.XYDataset var41 = null;
//     int var42 = var34.indexOf(var41);
//     org.jfree.chart.util.ShapeList var47 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var47.setShape(100, var50);
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
//     boolean var53 = var52.isRangeGridlinesVisible();
//     var52.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var57 = null;
//     java.util.Collection var58 = var52.getDomainMarkers(100, var57);
//     org.jfree.data.xy.XYDataset var59 = null;
//     int var60 = var52.indexOf(var59);
//     java.awt.Stroke var61 = var52.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.RingPlot var63 = new org.jfree.chart.plot.RingPlot(var62);
//     double var64 = var63.getOuterSeparatorExtension();
//     double var65 = var63.getSectionDepth();
//     java.awt.Paint var66 = var63.getLabelPaint();
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var50, var61, var66);
//     var34.setDomainCrosshairPaint(var66);
//     org.jfree.chart.axis.AxisLocation var69 = var34.getDomainAxisLocation();
//     var19.setRangeAxisLocation(var69);
//     var0.setDomainAxisLocation(15, var69);
//     
//     // Checks the contract:  equals-hashcode on var52 and var0
//     assertTrue("Contract failed: equals-hashcode on var52 and var0", var52.equals(var0) ? var52.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var52 and var0.", var52.equals(var0) == var0.equals(var52));
//     
//     // Checks the contract:  equals-hashcode on var13 and var63
//     assertTrue("Contract failed: equals-hashcode on var13 and var63", var13.equals(var63) ? var13.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var13
//     assertTrue("Contract failed: equals-hashcode on var63 and var13", var63.equals(var13) ? var63.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.awt.Stroke var4 = var0.getDomainCrosshairStroke();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var0.markerChanged(var5);
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var11 = var10.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var12 = null;
    int var13 = var10.getRangeAxisIndex(var12);
    org.jfree.chart.axis.AxisLocation var15 = var10.getDomainAxisLocation(10);
    var0.setRangeAxisLocation(0, var15, true);
    org.jfree.chart.plot.PlotOrientation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var15, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.data.RangeType var4 = var2.getRangeType();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    org.jfree.chart.entity.ChartEntity var8 = new org.jfree.chart.entity.ChartEntity(var6, "hi!");
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var11, 1);
    int var14 = var11.getColumnCount();
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
    var16.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.axis.SegmentedTimeline var19 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var20 = var19.getSegmentSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var22 = var19.getSegment(604800000L);
    org.jfree.chart.renderer.category.LayeredBarRenderer var24 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var25 = var24.getUpperClip();
    boolean var26 = var24.getBaseCreateEntities();
    java.awt.Font var27 = var24.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("", var27);
    var16.setTickLabelFont((java.lang.Comparable)var22, var27);
    org.jfree.chart.entity.CategoryItemEntity var30 = new org.jfree.chart.entity.CategoryItemEntity(var6, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var11, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var22);
    org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, var6, "", "poly");
    var2.setRangeAboutValue((-2.0d), 0.2d);
    java.awt.Paint var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setTickMarkPaint(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    java.awt.Paint var2 = var0.getNoDataMessagePaint();
    org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    boolean var7 = var6.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var9 = new org.jfree.chart.axis.ValueAxis[] { var8};
    var6.setDomainAxes(var9);
    org.jfree.chart.axis.AxisSpace var11 = null;
    var6.setFixedDomainAxisSpace(var11);
    var6.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
    double var17 = var16.getOuterSeparatorExtension();
    double var18 = var16.getSectionDepth();
    java.awt.Paint var19 = var16.getLabelLinkPaint();
    var6.setNoDataMessagePaint(var19);
    java.awt.geom.Point2D var21 = var6.getQuadrantOrigin();
    var0.zoomRangeAxes((-1.0d), var5, var21);
    var0.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseCreateEntities();
    java.awt.Font var3 = var0.getBaseItemLabelFont();
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var5);
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, 1);
    int var11 = var8.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var12 = null;
    var8.removeChangeListener(var12);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    var14.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    var17.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var19);
    java.text.NumberFormat var21 = var19.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var23 = var22.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    java.awt.Paint var25 = var24.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D();
    var26.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.axis.SegmentedTimeline var29 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var30 = var29.getSegmentSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var32 = var29.getSegment(604800000L);
    org.jfree.chart.renderer.category.LayeredBarRenderer var34 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var35 = var34.getUpperClip();
    boolean var36 = var34.getBaseCreateEntities();
    java.awt.Font var37 = var34.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("", var37);
    var26.setTickLabelFont((java.lang.Comparable)var32, var37);
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var41 = var40.getBackgroundPaint();
    var40.configureRangeAxes();
    java.awt.geom.Point2D var43 = var40.getQuadrantOrigin();
    boolean var44 = var26.hasListener((java.util.EventListener)var40);
    org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("");
    var46.setLowerBound(0.0d);
    org.jfree.chart.renderer.category.LayeredBarRenderer var49 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var50 = var49.getUpperClip();
    boolean var51 = var49.getBaseCreateEntities();
    var49.setBase(1.0d);
    java.awt.Shape var54 = var49.getBaseShape();
    org.jfree.chart.entity.AxisLabelEntity var57 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var46, var54, "", "RangeType.FULL");
    org.jfree.chart.axis.DateTickMarkPosition var58 = var46.getTickMarkPosition();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var59 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var61 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var59, 1);
    int var62 = var59.getColumnCount();
    boolean var63 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var59);
    java.lang.Number var64 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var59);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var4, var6, var7, var24, (org.jfree.chart.axis.CategoryAxis)var26, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.data.category.CategoryDataset)var59, 0, 1, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + 0.0d+ "'", var64.equals(0.0d));

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
//     org.jfree.chart.axis.AxisSpace var20 = var16.getFixedRangeAxisSpace();
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     var16.draw(var21, var22, var25, var26, var27);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
//     var0.setDomainAxes(var3);
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var0.setFixedDomainAxisSpace(var5);
//     var0.setRangeCrosshairValue(98.0d);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     double var11 = var10.getOuterSeparatorExtension();
//     double var12 = var10.getSectionDepth();
//     java.awt.Paint var13 = var10.getLabelLinkPaint();
//     var0.setNoDataMessagePaint(var13);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, 1);
//     int var18 = var15.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var19 = null;
//     var15.removeChangeListener(var19);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     var21.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     var24.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var26);
//     java.text.NumberFormat var28 = var26.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var29 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var30 = var29.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, (org.jfree.chart.axis.CategoryAxis)var21, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
//     org.jfree.chart.axis.CategoryAxis var33 = var31.getDomainAxisForDataset(100);
//     org.jfree.chart.event.PlotChangeEvent var34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var31);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     boolean var36 = var35.isRangeGridlinesVisible();
//     var35.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var35.getDomainMarkers(100, var40);
//     org.jfree.data.xy.XYDataset var42 = null;
//     int var43 = var35.indexOf(var42);
//     java.awt.Stroke var44 = var35.getRangeGridlineStroke();
//     java.awt.Paint var45 = var35.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     double var49 = var48.getOuterSeparatorExtension();
//     double var50 = var48.getSectionDepth();
//     org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var48);
//     var35.addChangeListener((org.jfree.chart.event.PlotChangeListener)var51);
//     var51.setAntiAlias(true);
//     var34.setChart(var51);
//     var0.notifyListeners(var34);
//     
//     // Checks the contract:  equals-hashcode on var10 and var48
//     assertTrue("Contract failed: equals-hashcode on var10 and var48", var10.equals(var48) ? var10.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var10
//     assertTrue("Contract failed: equals-hashcode on var48 and var10", var48.equals(var10) ? var48.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    boolean var2 = var1.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var4 = new org.jfree.chart.axis.ValueAxis[] { var3};
    var1.setDomainAxes(var4);
    org.jfree.chart.axis.AxisSpace var6 = null;
    var1.setFixedDomainAxisSpace(var6);
    var1.zoom(0.0d);
    java.awt.Paint var10 = var1.getDomainTickBandPaint();
    java.awt.Paint var11 = var1.getDomainGridlinePaint();
    boolean var12 = var0.hasListener((java.util.EventListener)var1);
    var1.setDomainCrosshairValue(1.0d, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var17 = var1.getDomainAxisForDataset((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     double var2 = var0.getMaxRadius();
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("Multiple Pie Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     var0.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     int var8 = var0.indexOf(var7);
//     java.awt.Stroke var9 = var0.getRangeGridlineStroke();
//     java.awt.Paint var10 = var0.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     double var14 = var13.getOuterSeparatorExtension();
//     double var15 = var13.getSectionDepth();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
//     float var18 = var16.getBackgroundImageAlpha();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var19, 1);
//     int var22 = var19.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var23 = null;
//     var19.removeChangeListener(var23);
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
//     var25.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     var28.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var30);
//     java.text.NumberFormat var32 = var30.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var33 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var34 = var33.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var19, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
//     org.jfree.chart.axis.CategoryAxis var37 = var35.getDomainAxisForDataset(100);
//     org.jfree.chart.event.PlotChangeEvent var38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var35);
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     boolean var40 = var39.isRangeGridlinesVisible();
//     var39.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var44 = null;
//     java.util.Collection var45 = var39.getDomainMarkers(100, var44);
//     org.jfree.data.xy.XYDataset var46 = null;
//     int var47 = var39.indexOf(var46);
//     java.awt.Stroke var48 = var39.getRangeGridlineStroke();
//     java.awt.Paint var49 = var39.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.RingPlot var52 = new org.jfree.chart.plot.RingPlot(var51);
//     double var53 = var52.getOuterSeparatorExtension();
//     double var54 = var52.getSectionDepth();
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var52);
//     var39.addChangeListener((org.jfree.chart.event.PlotChangeListener)var55);
//     var55.setAntiAlias(true);
//     var38.setChart(var55);
//     var16.plotChanged(var38);
//     
//     // Checks the contract:  equals-hashcode on var0 and var39
//     assertTrue("Contract failed: equals-hashcode on var0 and var39", var0.equals(var39) ? var0.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var0
//     assertTrue("Contract failed: equals-hashcode on var39 and var0", var39.equals(var0) ? var39.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var52
//     assertTrue("Contract failed: equals-hashcode on var13 and var52", var13.equals(var52) ? var13.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var13
//     assertTrue("Contract failed: equals-hashcode on var52 and var13", var52.equals(var13) ? var52.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var55
//     assertTrue("Contract failed: equals-hashcode on var16 and var55", var16.equals(var55) ? var16.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var16
//     assertTrue("Contract failed: equals-hashcode on var55 and var16", var55.equals(var16) ? var55.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setXOffset(4.0d);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getSeriesURLGenerator((-1));
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.renderer.category.LayeredBarRenderer var6 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var7 = var6.getUpperClip();
//     boolean var8 = var6.getBaseCreateEntities();
//     java.awt.Font var9 = var6.getBaseItemLabelFont();
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var10 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var6.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator)var10, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var14.setBaseSeriesVisible(false, false);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     double var21 = var20.getOuterSeparatorExtension();
//     double var22 = var20.getSectionDepth();
//     java.awt.Paint var23 = var20.getLabelPaint();
//     var14.setSeriesOutlinePaint(0, var23, false);
//     var6.setSeriesFillPaint(0, var23);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var31 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var29, 1);
//     int var32 = var29.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var33 = null;
//     var29.removeChangeListener(var33);
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
//     var35.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     var38.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var40);
//     java.text.NumberFormat var42 = var40.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var43 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var44 = var43.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var29, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.renderer.category.CategoryItemRenderer)var43);
//     org.jfree.chart.axis.CategoryAxis var47 = var45.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var48 = var45.getRangeAxisLocation();
//     org.jfree.chart.axis.AxisSpace var49 = var45.getFixedRangeAxisSpace();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var50 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var51 = var50.getUpperClip();
//     java.awt.Stroke var54 = var50.getItemStroke((-459), (-459));
//     var45.setDomainGridlineStroke(var54);
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var58 = var6.initialise(var27, var28, var45, 4, var57);
//     java.awt.geom.Rectangle2D var59 = null;
//     var0.drawOutline(var5, var45, var59);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     java.awt.Paint var17 = var16.getDomainGridlinePaint();
//     var16.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
//     java.awt.Stroke var20 = var16.getRangeCrosshairStroke();
//     var16.clearRangeMarkers(0);
//     var16.setRangeCrosshairVisible(false);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis();
//     var25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var27);
//     org.jfree.chart.plot.DatasetRenderingOrder var29 = var25.getDatasetRenderingOrder();
//     java.lang.String var30 = var29.toString();
//     var16.setDatasetRenderingOrder(var29);
//     
//     // Checks the contract:  equals-hashcode on var9 and var25
//     assertTrue("Contract failed: equals-hashcode on var9 and var25", var9.equals(var25) ? var9.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var9
//     assertTrue("Contract failed: equals-hashcode on var25 and var9", var25.equals(var9) ? var25.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var17, 1);
//     int var20 = var17.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var21 = null;
//     var17.removeChangeListener(var21);
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
//     var23.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     var26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
//     java.text.NumberFormat var30 = var28.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var31 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var32 = var31.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
//     org.jfree.chart.axis.CategoryAxis var35 = var33.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var36 = var33.getRangeAxisLocation();
//     org.jfree.chart.plot.Plot var37 = var33.getRootPlot();
//     org.jfree.chart.axis.CategoryAnchor var38 = var33.getDomainGridlinePosition();
//     var16.setDomainGridlinePosition(var38);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var26
//     assertTrue("Contract failed: equals-hashcode on var9 and var26", var9.equals(var26) ? var9.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var9
//     assertTrue("Contract failed: equals-hashcode on var26 and var9", var26.equals(var9) ? var26.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var33
//     assertTrue("Contract failed: equals-hashcode on var16 and var33", var16.equals(var33) ? var16.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var16
//     assertTrue("Contract failed: equals-hashcode on var33 and var16", var33.equals(var16) ? var33.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     boolean var4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     var5.mapDatasetToDomainAxis((-1), 100);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
//     var11.setCategoryLabelPositions(var13);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     boolean var16 = var15.isTickMarksVisible();
//     var15.setLabel("");
//     var15.setAutoRangeMinimumSize(98.0d, false);
//     boolean var22 = var15.isAutoTickUnitSelection();
//     org.jfree.chart.renderer.category.StackedAreaRenderer var23 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, 1);
//     org.jfree.data.Range var27 = var23.findRangeBounds((org.jfree.data.category.CategoryDataset)var24);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var28 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var29 = var28.getUpperClip();
//     java.awt.Stroke var32 = var28.getItemStroke((-459), (-459));
//     var23.setBaseStroke(var32, false);
//     double var35 = var23.getItemLabelAnchorOffset();
//     org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.lang.String var39 = var38.getToolTipText();
//     java.awt.Font var40 = var38.getFont();
//     var23.setSeriesItemLabelFont(0, var40, false);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var11, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var24
//     assertTrue("Contract failed: equals-hashcode on var0 and var24", var0.equals(var24) ? var0.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    var24.setDatasetIndex(0);
    boolean var27 = var24.isShapeOutlineVisible();
    boolean var28 = var24.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    boolean var3 = var2.isRangeGridlinesVisible();
    var2.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var2.getDomainMarkers(100, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    int var10 = var2.indexOf(var9);
    org.jfree.chart.util.ShapeList var15 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var15.setShape(100, var18);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    boolean var21 = var20.isRangeGridlinesVisible();
    var20.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var20.getDomainMarkers(100, var25);
    org.jfree.data.xy.XYDataset var27 = null;
    int var28 = var20.indexOf(var27);
    java.awt.Stroke var29 = var20.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
    double var32 = var31.getOuterSeparatorExtension();
    double var33 = var31.getSectionDepth();
    java.awt.Paint var34 = var31.getLabelPaint();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var18, var29, var34);
    var2.setDomainCrosshairPaint(var34);
    var0.setSeriesOutlinePaint(15, var34, true);
    java.awt.Font var40 = var0.getSeriesItemLabelFont((-459));
    boolean var41 = var0.getRenderAsPercentages();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    boolean var46 = var0.getItemCreateEntity(100, (-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     java.lang.Number var3 = var0.getMaxOutlier((java.lang.Comparable)10, (java.lang.Comparable)0.8f);
//     int var4 = var0.getRowCount();
//     org.jfree.data.statistics.BoxAndWhiskerItem var5 = null;
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange((org.jfree.data.Range)var6);
//     java.util.Date var8 = var6.getUpperDate();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.previous();
//     var0.add(var5, (java.lang.Comparable)var8, (java.lang.Comparable)var10);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var6 = var4.getSeriesOutlineStroke(1);
    java.awt.Paint var8 = var4.lookupSeriesFillPaint((-1));
    var2.setLabelPaint(var8);
    boolean var10 = var2.isPositiveArrowVisible();
    java.awt.Stroke var11 = var2.getAxisLineStroke();
    double var12 = var2.getFixedAutoRange();
    org.jfree.chart.axis.NumberTickUnit var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setTickUnit(var13, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
//     var0.setNotify(false);
//     java.lang.Object var6 = var0.clone();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
//     double var9 = var8.getOuterSeparatorExtension();
//     var8.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     java.awt.Paint var13 = var8.getLabelPaint();
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     double var17 = var16.getOuterSeparatorExtension();
//     double var18 = var16.getSectionDepth();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var16);
//     java.util.List var20 = var19.getSubtitles();
//     org.jfree.chart.plot.Plot var21 = var19.getPlot();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var23 = var22.getUpperClip();
//     boolean var24 = var22.getBaseCreateEntities();
//     java.awt.Font var25 = var22.getBaseItemLabelFont();
//     org.jfree.chart.labels.ItemLabelPosition var28 = var22.getNegativeItemLabelPosition(100, 15);
//     boolean var29 = var19.equals((java.lang.Object)var22);
//     org.jfree.chart.ui.BasicProjectInfo var34 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
//     org.jfree.chart.JFreeChart var35 = null;
//     org.jfree.chart.event.ChartChangeEvent var36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"", var35);
//     org.jfree.chart.event.ChartChangeEventType var37 = var36.getType();
//     org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var13, var19, var37);
//     var19.setTitle("Polar Plot");
//     var0.addChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     var42.draw(var43, var44);
//     var42.setNotify(false);
//     java.lang.Object var48 = var42.clone();
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot(var49);
//     double var51 = var50.getOuterSeparatorExtension();
//     var50.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     java.awt.Paint var55 = var50.getLabelPaint();
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.RingPlot var58 = new org.jfree.chart.plot.RingPlot(var57);
//     double var59 = var58.getOuterSeparatorExtension();
//     double var60 = var58.getSectionDepth();
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var58);
//     java.util.List var62 = var61.getSubtitles();
//     org.jfree.chart.plot.Plot var63 = var61.getPlot();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var64 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var65 = var64.getUpperClip();
//     boolean var66 = var64.getBaseCreateEntities();
//     java.awt.Font var67 = var64.getBaseItemLabelFont();
//     org.jfree.chart.labels.ItemLabelPosition var70 = var64.getNegativeItemLabelPosition(100, 15);
//     boolean var71 = var61.equals((java.lang.Object)var64);
//     org.jfree.chart.ui.BasicProjectInfo var76 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
//     org.jfree.chart.JFreeChart var77 = null;
//     org.jfree.chart.event.ChartChangeEvent var78 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"", var77);
//     org.jfree.chart.event.ChartChangeEventType var79 = var78.getType();
//     org.jfree.chart.event.ChartChangeEvent var80 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var55, var61, var79);
//     var61.setTitle("Polar Plot");
//     var42.addChangeListener((org.jfree.chart.event.TitleChangeListener)var61);
//     var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var61);
//     
//     // Checks the contract:  equals-hashcode on var8 and var50
//     assertTrue("Contract failed: equals-hashcode on var8 and var50", var8.equals(var50) ? var8.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var58
//     assertTrue("Contract failed: equals-hashcode on var16 and var58", var16.equals(var58) ? var16.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var8
//     assertTrue("Contract failed: equals-hashcode on var50 and var8", var50.equals(var8) ? var50.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var16
//     assertTrue("Contract failed: equals-hashcode on var58 and var16", var58.equals(var16) ? var58.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var61
//     assertTrue("Contract failed: equals-hashcode on var19 and var61", var19.equals(var61) ? var19.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var19
//     assertTrue("Contract failed: equals-hashcode on var61 and var19", var61.equals(var19) ? var61.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var63
//     assertTrue("Contract failed: equals-hashcode on var21 and var63", var21.equals(var63) ? var21.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var21
//     assertTrue("Contract failed: equals-hashcode on var63 and var21", var63.equals(var21) ? var63.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var70
//     assertTrue("Contract failed: equals-hashcode on var28 and var70", var28.equals(var70) ? var28.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var28
//     assertTrue("Contract failed: equals-hashcode on var70 and var28", var70.equals(var28) ? var70.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setRange(0.0d, 100.0d);
    org.jfree.chart.axis.DateTickUnit var5 = var1.getTickUnit();
    double var6 = var5.getSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.64E7d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.zoom(0.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var9, 1);
    org.jfree.data.general.PieDataset var15 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var11, (java.lang.Comparable)(short)0, (-1.0d), 10);
    org.jfree.data.general.DatasetChangeEvent var16 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)0.0d, (org.jfree.data.general.Dataset)var15);
    java.lang.Object var17 = var16.getSource();
    org.jfree.data.general.Dataset var18 = var16.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + 0.0d+ "'", var17.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.urls.PieURLGenerator var2 = var1.getURLGenerator();
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    java.awt.Paint var4 = var3.getItemPaint();
    org.jfree.chart.util.RectangleEdge var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setLegendItemGraphicEdge(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     var0.setIgnoreZeroValues(true);
//     java.awt.Paint var3 = var0.getLabelPaint();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     var7.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
//     java.util.Date var12 = var11.getLowerDate();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var7.dateToJava2D(var12, var13, var14);
//     var5.setMinimumDate(var12);
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("");
//     var18.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     java.util.Date var22 = var21.getLowerDate();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var18.dateToJava2D(var22, var23, var24);
//     org.jfree.data.time.SimpleTimePeriod var26 = new org.jfree.data.time.SimpleTimePeriod(var12, var22);
//     java.awt.Stroke var27 = var0.getSectionOutlineStroke((java.lang.Comparable)var22);
//     double var28 = var0.getMaximumExplodePercent();
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    var0.draw(var2, var3);
    var0.setToolTipText("java.awt.Color[r=255,g=255,b=255]");
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var5.setShape(100, var8);
//     java.awt.Shape var11 = var5.getShape(100);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
//     org.jfree.chart.util.RectangleInsets var14 = var13.getInsets();
//     java.awt.Paint var15 = var13.getPaint();
//     java.awt.Color var20 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
//     java.lang.String var21 = var20.toString();
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var23 = var22.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     int var25 = var22.getRangeAxisIndex(var24);
//     org.jfree.chart.axis.AxisSpace var26 = var22.getFixedRangeAxisSpace();
//     var22.setRangeCrosshairValue((-1.0d), false);
//     java.awt.Stroke var30 = var22.getDomainCrosshairStroke();
//     org.jfree.chart.util.ShapeList var36 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var36.setShape(100, var39);
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
//     boolean var42 = var41.isRangeGridlinesVisible();
//     var41.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var46 = null;
//     java.util.Collection var47 = var41.getDomainMarkers(100, var46);
//     org.jfree.data.xy.XYDataset var48 = null;
//     int var49 = var41.indexOf(var48);
//     java.awt.Stroke var50 = var41.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.RingPlot var52 = new org.jfree.chart.plot.RingPlot(var51);
//     double var53 = var52.getOuterSeparatorExtension();
//     double var54 = var52.getSectionDepth();
//     java.awt.Paint var55 = var52.getLabelPaint();
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var39, var50, var55);
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var58 = var57.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     int var60 = var57.getRangeAxisIndex(var59);
//     org.jfree.chart.axis.AxisSpace var61 = var57.getFixedRangeAxisSpace();
//     var57.setRangeCrosshairValue((-1.0d), false);
//     java.awt.Stroke var65 = var57.getDomainCrosshairStroke();
//     java.awt.Paint var66 = null;
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("poly", "First", "Pie 3D Plot", "12/31/69 4:00 PM", true, var11, false, var15, false, (java.awt.Paint)var20, var30, false, var39, var65, var66);
//     
//     // Checks the contract:  equals-hashcode on var22 and var57
//     assertTrue("Contract failed: equals-hashcode on var22 and var57", var22.equals(var57) ? var22.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var22
//     assertTrue("Contract failed: equals-hashcode on var57 and var22", var57.equals(var22) ? var57.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue(var0, (java.lang.Number)(short)1);
//     java.lang.Comparable var3 = var2.getKey();
//     java.lang.String var4 = var2.toString();
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
    org.jfree.chart.axis.AxisSpace var20 = var16.getFixedRangeAxisSpace();
    org.jfree.chart.util.Layer var22 = null;
    java.util.Collection var23 = var16.getDomainMarkers(0, var22);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    boolean var28 = var27.isRangeGridlinesVisible();
    java.awt.Paint var29 = var27.getNoDataMessagePaint();
    org.jfree.chart.plot.DrawingSupplier var30 = var27.getDrawingSupplier();
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
    boolean var34 = var33.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var36 = new org.jfree.chart.axis.ValueAxis[] { var35};
    var33.setDomainAxes(var36);
    org.jfree.chart.axis.AxisSpace var38 = null;
    var33.setFixedDomainAxisSpace(var38);
    var33.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var42 = null;
    org.jfree.chart.plot.RingPlot var43 = new org.jfree.chart.plot.RingPlot(var42);
    double var44 = var43.getOuterSeparatorExtension();
    double var45 = var43.getSectionDepth();
    java.awt.Paint var46 = var43.getLabelLinkPaint();
    var33.setNoDataMessagePaint(var46);
    java.awt.geom.Point2D var48 = var33.getQuadrantOrigin();
    var27.zoomRangeAxes((-1.0d), var32, var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.zoomRangeAxes(1.0d, 0.0d, var26, var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var2 = var0.getTimeFromLong(1L);
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    var3.setIgnoreZeroValues(true);
    var3.setLabelLinkMargin(98.0d);
    boolean var8 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.axis.SegmentedTimeline var9 = var0.getBaseTimeline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=255,b=255]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 1);
//     int var7 = var4.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var8 = null;
//     var4.removeChangeListener(var8);
//     var4.add(10.0d, 0.05d, (java.lang.Comparable)'#', (java.lang.Comparable)100.0d);
//     org.jfree.data.Range var15 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var16.getPositiveItemLabelPosition(0, 2);
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     var16.addChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     var3.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, 1);
//     int var27 = var24.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var28 = null;
//     var24.removeChangeListener(var28);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var33.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var35);
//     java.text.NumberFormat var37 = var35.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var38 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var39 = var38.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     java.awt.Paint var41 = var40.getDomainGridlinePaint();
//     var40.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var43 = var40.getDatasetRenderingOrder();
//     java.awt.Stroke var44 = var40.getRangeCrosshairStroke();
//     var40.clearRangeMarkers(0);
//     java.awt.geom.Rectangle2D var47 = null;
//     var3.drawDomainGridline(var23, var40, var47, 1.05d);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, 1);
    org.jfree.data.Range var4 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var6 = var5.getUpperClip();
    java.awt.Stroke var9 = var5.getItemStroke((-459), (-459));
    var0.setBaseStroke(var9, false);
    boolean var12 = var0.getRenderAsPercentages();
    org.jfree.chart.renderer.AreaRendererEndType var13 = var0.getEndType();
    java.lang.String var14 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AreaRendererEndType.TAPER"+ "'", var14.equals("AreaRendererEndType.TAPER"));

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setRange(0.0d, 100.0d);
    org.jfree.chart.axis.DateTickUnit var5 = var1.getTickUnit();
    org.jfree.chart.util.ShapeList var6 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var6.setShape(100, var9);
    var1.setUpArrow(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getLabelGap();
    double var4 = var1.getMaximumLabelWidth();
    org.jfree.chart.util.Rotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
//     java.awt.Paint[] var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     boolean var5 = var4.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var4.setDomainAxes(var7);
//     org.jfree.chart.axis.AxisLocation var9 = var4.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     double var12 = var11.getOuterSeparatorExtension();
//     double var13 = var11.getSectionDepth();
//     java.awt.Paint var14 = var11.getLabelLinkPaint();
//     var4.setOutlinePaint(var14);
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var14};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var3, var16, var18, var20, var23);
//     java.awt.Paint var25 = var24.getNextPaint();
//     java.lang.Object var26 = var24.clone();
//     java.lang.Object var27 = var24.clone();
//     
//     // Checks the contract:  equals-hashcode on var26 and var27
//     assertTrue("Contract failed: equals-hashcode on var26 and var27", var26.equals(var27) ? var26.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var26
//     assertTrue("Contract failed: equals-hashcode on var27 and var26", var27.equals(var26) ? var27.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange();
//     java.util.Date var7 = var6.getLowerDate();
//     int var8 = var5.getRowIndex((java.lang.Comparable)var7);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     java.awt.Paint var17 = var16.getDomainGridlinePaint();
//     var16.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
//     java.awt.Stroke var20 = var16.getRangeCrosshairStroke();
//     var16.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var23 = var16.getColumnRenderingOrder();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, 1);
//     int var27 = var24.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var28 = null;
//     var24.removeChangeListener(var28);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var33.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var35);
//     java.text.NumberFormat var37 = var35.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var38 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var39 = var38.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var42 = var41.previous();
//     var30.removeCategoryLabelToolTip((java.lang.Comparable)var42);
//     var16.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var30);
//     
//     // Checks the contract:  equals-hashcode on var0 and var24
//     assertTrue("Contract failed: equals-hashcode on var0 and var24", var0.equals(var24) ? var0.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     java.awt.Paint var17 = var16.getDomainGridlinePaint();
//     var16.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
//     boolean var20 = var16.isOutlineVisible();
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var21.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.plot.DatasetRenderingOrder var25 = var21.getDatasetRenderingOrder();
//     var16.setDatasetRenderingOrder(var25);
//     
//     // Checks the contract:  equals-hashcode on var9 and var21
//     assertTrue("Contract failed: equals-hashcode on var9 and var21", var9.equals(var21) ? var9.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var9
//     assertTrue("Contract failed: equals-hashcode on var21 and var9", var21.equals(var9) ? var21.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
    org.jfree.chart.axis.AxisSpace var20 = var16.getFixedRangeAxisSpace();
    var16.clearDomainMarkers();
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    boolean var26 = var16.render(var22, var23, (-459), var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getValue(0, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     var4.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.data.RangeType var8 = var6.getRangeType();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     double var11 = var10.getOuterSeparatorExtension();
//     var10.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
//     boolean var15 = var6.hasListener((java.util.EventListener)var10);
//     boolean var16 = var10.getLabelLinksVisible();
//     var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var10);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var18, 1);
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var20, (java.lang.Comparable)(short)0, (-1.0d), 10);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var20);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     var26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var28);
//     java.lang.Object var30 = var28.clone();
//     var28.setAutoRange(true);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot(var33);
//     double var35 = var34.getOuterSeparatorExtension();
//     double var36 = var34.getSectionDepth();
//     java.awt.Paint var37 = var34.getLabelLinkPaint();
//     var28.setLabelPaint(var37);
//     boolean var39 = var25.equals((java.lang.Object)var37);
//     var10.setShadowPaint(var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    var1.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var3);
    org.jfree.data.RangeType var5 = var3.getRangeType();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    double var8 = var7.getOuterSeparatorExtension();
    var7.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    boolean var12 = var3.hasListener((java.util.EventListener)var7);
    org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
    var3.setDefaultAutoRange((org.jfree.data.Range)var13);
    org.jfree.data.Range var15 = org.jfree.data.Range.combine((org.jfree.data.Range)var0, (org.jfree.data.Range)var13);
    boolean var17 = var15.contains((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    boolean var5 = var2.getItemShapeVisible((-459), 1);
    java.lang.Boolean var7 = var2.getSeriesLinesVisible(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.text.NumberFormat var4 = var2.getNumberFormatOverride();
    java.awt.Paint var5 = var2.getTickMarkPaint();
    boolean var6 = var2.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    java.lang.String var25 = var24.getURLText();
    java.lang.String var26 = var24.getLabel();
    java.awt.Paint var27 = var24.getFillPaint();
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(2);
    var24.setSeriesKey((java.lang.Comparable)2);
    java.awt.Shape var31 = var24.getShape();
    java.io.ObjectOutputStream var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var31, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "hi!"+ "'", var25.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + ""+ "'", var26.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.urls.PieURLGenerator var2 = var1.getURLGenerator();
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    var4.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var6);
    java.awt.Stroke var8 = var4.getDomainCrosshairStroke();
    var1.setLabelOutlineStroke(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    var12.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.data.RangeType var16 = var14.getRangeType();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    double var19 = var18.getOuterSeparatorExtension();
    var18.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    boolean var23 = var14.hasListener((java.util.EventListener)var18);
    org.jfree.chart.util.RectangleInsets var24 = var18.getInsets();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var27 = var1.initialise(var10, var11, (org.jfree.chart.plot.PiePlot)var18, (java.lang.Integer)1, var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, Double.NaN, 10.0d);
//     org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var5);
//     java.util.List var7 = var6.getBlocks();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange();
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange((org.jfree.data.Range)var9);
//     org.jfree.data.Range var11 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var10, var11);
//     org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedWidth(0.05d);
//     org.jfree.chart.util.Size2D var15 = var0.arrange(var6, var8, var14);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     var7.setRange(0.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var11 = var7.getTickUnit();
//     java.lang.String var13 = var11.valueToString(4.0d);
//     int var14 = var11.getUnit();
//     java.lang.String var15 = var11.toString();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var17, "hi!");
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var22, 1);
//     int var25 = var22.getColumnCount();
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
//     var27.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.axis.SegmentedTimeline var30 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var31 = var30.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var33 = var30.getSegment(604800000L);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var35 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var36 = var35.getUpperClip();
//     boolean var37 = var35.getBaseCreateEntities();
//     java.awt.Font var38 = var35.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var39 = new org.jfree.chart.block.LabelBlock("", var38);
//     var27.setTickLabelFont((java.lang.Comparable)var33, var38);
//     org.jfree.chart.entity.CategoryItemEntity var41 = new org.jfree.chart.entity.CategoryItemEntity(var17, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var22, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var33);
//     java.lang.Number var42 = var5.getValue((java.lang.Comparable)var15, (java.lang.Comparable)(short)(-1));
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.renderer.OutlierListCollection var0 = new org.jfree.chart.renderer.OutlierListCollection();
    var0.setLowFarOut(true);
    boolean var3 = var0.isHighFarOut();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
    java.awt.Paint var20 = var16.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis var22 = var16.getDomainAxisForDataset(12);
    int var23 = var22.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
//     org.jfree.chart.axis.AxisSpace var20 = var16.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     boolean var22 = var21.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var23};
//     var21.setDomainAxes(var24);
//     org.jfree.chart.axis.AxisLocation var26 = var21.getDomainAxisLocation();
//     var16.setRangeAxisLocation(var26, false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var30 = var29.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var32 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var33 = var32.getUpperClip();
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     boolean var35 = var34.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var37 = new org.jfree.chart.axis.ValueAxis[] { var36};
//     var34.setDomainAxes(var37);
//     org.jfree.chart.axis.AxisLocation var39 = var34.getDomainAxisLocation();
//     boolean var40 = var32.equals((java.lang.Object)var39);
//     var29.setRangeAxisLocation(10, var39, true);
//     boolean var43 = var29.isRangeCrosshairVisible();
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var45 = var44.getBackgroundPaint();
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     int var47 = var44.getRangeAxisIndex(var46);
//     org.jfree.chart.axis.AxisLocation var49 = var44.getDomainAxisLocation(10);
//     var29.setDomainAxisLocation(var49);
//     var16.setRangeAxisLocation(var49, false);
//     
//     // Checks the contract:  equals-hashcode on var21 and var34
//     assertTrue("Contract failed: equals-hashcode on var21 and var34", var21.equals(var34) ? var21.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var21
//     assertTrue("Contract failed: equals-hashcode on var34 and var21", var34.equals(var21) ? var34.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var9
//     assertTrue("Contract failed: equals-hashcode on var44 and var9", var44.equals(var9) ? var44.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var44 and var9.", var44.equals(var9) == var9.equals(var44));
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     int var7 = var5.getColumnIndex((java.lang.Comparable)"December 1969");
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.data.Range var7 = var0.getRangeBounds(false);
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var0.getMeanValue(100, 12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    var4.setShape(100, var7);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    boolean var10 = var9.isRangeGridlinesVisible();
    var9.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var9.getDomainMarkers(100, var14);
    org.jfree.data.xy.XYDataset var16 = null;
    int var17 = var9.indexOf(var16);
    java.awt.Stroke var18 = var9.getRangeGridlineStroke();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    double var21 = var20.getOuterSeparatorExtension();
    double var22 = var20.getSectionDepth();
    java.awt.Paint var23 = var20.getLabelPaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var7, var18, var23);
    java.lang.String var25 = var24.getURLText();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, 1);
    var24.setDataset((org.jfree.data.general.Dataset)var26);
    java.awt.Paint var30 = var24.getFillPaint();
    boolean var31 = var24.isShapeOutlineVisible();
    org.jfree.chart.util.GradientPaintTransformer var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.setFillPaintTransformer(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "hi!"+ "'", var25.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var20 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var21 = var20.getUpperClip();
//     boolean var22 = var20.getBaseCreateEntities();
//     java.awt.Font var23 = var20.getBaseItemLabelFont();
//     org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("", var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.RingPlot var26 = new org.jfree.chart.plot.RingPlot(var25);
//     double var27 = var26.getOuterSeparatorExtension();
//     double var28 = var26.getSectionDepth();
//     java.awt.Paint var29 = var26.getLabelLinkPaint();
//     org.jfree.chart.labels.PieSectionLabelGenerator var30 = null;
//     var26.setLegendLabelToolTipGenerator(var30);
//     boolean var32 = var26.isSubplot();
//     java.awt.Paint var33 = var26.getSeparatorPaint();
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("Other", var23, var33, (-1.0f));
//     java.awt.Font var36 = var35.getFont();
//     var14.setSeriesItemLabelFont(0, var36);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var14.", var20.equals(var14) == var14.equals(var20));
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     var16.setAnchorValue((-1.0d), false);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var22, 1);
//     int var25 = var22.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var26 = null;
//     var22.removeChangeListener(var26);
//     org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
//     var28.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     var31.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var33);
//     java.text.NumberFormat var35 = var33.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var36 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var37 = var36.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, (org.jfree.chart.axis.CategoryAxis)var28, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     org.jfree.chart.axis.CategoryAxis var40 = var38.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var41 = var38.getRangeAxisLocation();
//     org.jfree.chart.plot.Plot var42 = var38.getRootPlot();
//     org.jfree.chart.axis.CategoryAnchor var43 = var38.getDomainGridlinePosition();
//     var16.setDomainGridlinePosition(var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var31
//     assertTrue("Contract failed: equals-hashcode on var9 and var31", var9.equals(var31) ? var9.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var9
//     assertTrue("Contract failed: equals-hashcode on var31 and var9", var31.equals(var9) ? var31.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    var0.clearAnnotations();
    org.jfree.chart.util.Layer var3 = null;
    java.util.Collection var4 = var0.getDomainMarkers(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    java.awt.Paint var2 = var0.getNoDataMessagePaint();
    org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    boolean var7 = var6.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var9 = new org.jfree.chart.axis.ValueAxis[] { var8};
    var6.setDomainAxes(var9);
    org.jfree.chart.axis.AxisSpace var11 = null;
    var6.setFixedDomainAxisSpace(var11);
    var6.setRangeCrosshairValue(98.0d);
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
    double var17 = var16.getOuterSeparatorExtension();
    double var18 = var16.getSectionDepth();
    java.awt.Paint var19 = var16.getLabelLinkPaint();
    var6.setNoDataMessagePaint(var19);
    java.awt.geom.Point2D var21 = var6.getQuadrantOrigin();
    var0.zoomRangeAxes((-1.0d), var5, var21);
    org.jfree.chart.axis.ValueAxis var23 = var0.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("CategoryLabelWidthType.CATEGORY", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 1);
//     int var7 = var4.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var8 = null;
//     var4.removeChangeListener(var8);
//     var4.add(10.0d, 0.05d, (java.lang.Comparable)'#', (java.lang.Comparable)100.0d);
//     org.jfree.data.Range var15 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var20 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Stroke var22 = var20.getSeriesOutlineStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesFillPaint((-1));
//     var18.setLabelPaint(var24);
//     var3.setWallPaint(var24);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var29 = var28.getBackgroundPaint();
//     java.awt.Paint[] var30 = new java.awt.Paint[] { var29};
//     java.awt.Paint[] var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     boolean var33 = var32.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var35 = new org.jfree.chart.axis.ValueAxis[] { var34};
//     var32.setDomainAxes(var35);
//     org.jfree.chart.axis.AxisLocation var37 = var32.getDomainAxisLocation();
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     double var40 = var39.getOuterSeparatorExtension();
//     double var41 = var39.getSectionDepth();
//     java.awt.Paint var42 = var39.getLabelLinkPaint();
//     var32.setOutlinePaint(var42);
//     java.awt.Paint[] var44 = new java.awt.Paint[] { var42};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     java.awt.Shape[] var51 = new java.awt.Shape[] { var50};
//     org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier(var30, var31, var44, var46, var48, var51);
//     java.awt.Paint var53 = var52.getNextPaint();
//     var3.setSeriesItemLabelPaint(1, var53);
//     
//     // Checks the contract:  equals-hashcode on var28 and var16
//     assertTrue("Contract failed: equals-hashcode on var28 and var16", var28.equals(var16) ? var28.hashCode() == var16.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var16.", var28.equals(var16) == var16.equals(var28));
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
//     var16.setAnchorValue((-1.0d), false);
//     org.jfree.chart.util.SortOrder var22 = var16.getColumnRenderingOrder();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var23 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var23, 1);
//     int var26 = var23.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var27 = null;
//     var23.removeChangeListener(var27);
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D();
//     var29.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     var32.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var34);
//     java.text.NumberFormat var36 = var34.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var37 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var38 = var37.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, (org.jfree.chart.axis.CategoryAxis)var29, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.chart.axis.CategoryAxis var41 = var39.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var42 = var39.getRangeAxisLocation();
//     org.jfree.chart.plot.Plot var43 = var39.getRootPlot();
//     boolean var44 = var22.equals((java.lang.Object)var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var23
//     assertTrue("Contract failed: equals-hashcode on var0 and var23", var0.equals(var23) ? var0.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var0
//     assertTrue("Contract failed: equals-hashcode on var23 and var0", var23.equals(var0) ? var23.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var32
//     assertTrue("Contract failed: equals-hashcode on var9 and var32", var9.equals(var32) ? var9.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var9
//     assertTrue("Contract failed: equals-hashcode on var32 and var9", var32.equals(var9) ? var32.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var4 = var3.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var6 = var3.getSegment(604800000L);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var9 = var8.getUpperClip();
//     boolean var10 = var8.getBaseCreateEntities();
//     java.awt.Font var11 = var8.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var11);
//     var0.setTickLabelFont((java.lang.Comparable)var6, var11);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var15 = var14.getBackgroundPaint();
//     var14.configureRangeAxes();
//     java.awt.geom.Point2D var17 = var14.getQuadrantOrigin();
//     boolean var18 = var0.hasListener((java.util.EventListener)var14);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var19, 1);
//     int var22 = var19.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var23 = null;
//     var19.removeChangeListener(var23);
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D();
//     var25.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     var28.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var30);
//     java.text.NumberFormat var32 = var30.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var33 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var34 = var33.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var19, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
//     org.jfree.chart.axis.CategoryAxis var37 = var35.getDomainAxisForDataset(100);
//     org.jfree.chart.axis.AxisLocation var38 = var35.getRangeAxisLocation();
//     org.jfree.chart.plot.Plot var39 = var35.getRootPlot();
//     org.jfree.chart.axis.CategoryAnchor var40 = var35.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     var44.draw(var45, var46);
//     var44.setNotify(false);
//     java.lang.Object var50 = var44.clone();
//     org.jfree.chart.util.RectangleEdge var51 = var44.getPosition();
//     org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     var52.draw(var53, var54);
//     var52.setNotify(false);
//     java.lang.Object var58 = var52.clone();
//     org.jfree.chart.util.RectangleEdge var59 = var52.getPosition();
//     var44.setPosition(var59);
//     double var61 = var0.getCategoryJava2DCoordinate(var40, 12, 10, var43, var59);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var2 = var0.getSeriesOutlineStroke(1);
    double var3 = var0.getLowerClip();
    var0.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.lang.Object var2 = null;
//     int var3 = var0.compareTo(var2);
//     long var4 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    var0.draw(var1, var2);
    var0.setNotify(false);
    java.lang.Object var6 = var0.clone();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getOuterSeparatorExtension();
    var8.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    java.awt.Paint var13 = var8.getLabelPaint();
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
    double var17 = var16.getOuterSeparatorExtension();
    double var18 = var16.getSectionDepth();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var16);
    java.util.List var20 = var19.getSubtitles();
    org.jfree.chart.plot.Plot var21 = var19.getPlot();
    org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var23 = var22.getUpperClip();
    boolean var24 = var22.getBaseCreateEntities();
    java.awt.Font var25 = var22.getBaseItemLabelFont();
    org.jfree.chart.labels.ItemLabelPosition var28 = var22.getNegativeItemLabelPosition(100, 15);
    boolean var29 = var19.equals((java.lang.Object)var22);
    org.jfree.chart.ui.BasicProjectInfo var34 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "");
    org.jfree.chart.JFreeChart var35 = null;
    org.jfree.chart.event.ChartChangeEvent var36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"", var35);
    org.jfree.chart.event.ChartChangeEventType var37 = var36.getType();
    org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var13, var19, var37);
    var19.setTitle("Polar Plot");
    var0.addChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
    boolean var43 = var42.isRangeGridlinesVisible();
    var42.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var47 = null;
    java.util.Collection var48 = var42.getDomainMarkers(100, var47);
    org.jfree.data.xy.XYDataset var49 = null;
    int var50 = var42.indexOf(var49);
    java.awt.Stroke var51 = var42.getRangeGridlineStroke();
    java.awt.Graphics2D var52 = null;
    java.awt.geom.Rectangle2D var53 = null;
    org.jfree.data.KeyToGroupMap var55 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable)(-1.0d));
    int var57 = var55.getKeyCount((java.lang.Comparable)(byte)1);
    java.util.List var58 = var55.getGroups();
    var42.drawRangeTickBands(var52, var53, var58);
    org.jfree.chart.util.RectangleInsets var60 = var42.getAxisOffset();
    var19.setPadding(var60);
    float var62 = var19.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.5f);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     java.lang.String var2 = var0.getPlotType();
//     java.lang.Object var3 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     java.awt.Paint var17 = var16.getDomainGridlinePaint();
//     var16.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var16.getDatasetRenderingOrder();
//     java.awt.Stroke var20 = var16.getRangeCrosshairStroke();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.util.Size2D var24 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var25 = var24.getHeight();
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var29.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var32 = var29.getLabelAnchor();
//     java.awt.geom.Rectangle2D var33 = org.jfree.chart.util.RectangleAnchor.createRectangle(var24, 0.65d, 0.65d, var32);
//     var16.drawBackground(var21, var33);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    java.awt.geom.Point2D var2 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var1);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    boolean var4 = var3.isRangeGridlinesVisible();
    var3.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var3.getDomainMarkers(100, var8);
    org.jfree.data.xy.XYDataset var10 = null;
    int var11 = var3.indexOf(var10);
    java.awt.Stroke var12 = var3.getRangeGridlineStroke();
    java.awt.Paint var13 = var3.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
    double var17 = var16.getOuterSeparatorExtension();
    double var18 = var16.getSectionDepth();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var16);
    var3.addChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
    float var21 = var19.getBackgroundImageAlpha();
    java.awt.Paint var22 = var19.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
//     var2.setBaseShapesVisible(false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
//     java.awt.Paint var7 = var2.getSeriesItemLabelPaint(0);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var10 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var9);
//     org.jfree.chart.entity.EntityCollection var11 = var10.getEntityCollection();
//     double var12 = var10.getSeriesRunningTotal();
//     org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var16 = var15.getHeight();
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var20.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var23 = var20.getLabelAnchor();
//     java.awt.geom.Rectangle2D var24 = org.jfree.chart.util.RectangleAnchor.createRectangle(var15, 0.65d, 0.65d, var23);
//     org.jfree.chart.plot.CategoryPlot var25 = null;
//     org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D();
//     var26.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.axis.SegmentedTimeline var29 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var30 = var29.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var32 = var29.getSegment(604800000L);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var34 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var35 = var34.getUpperClip();
//     boolean var36 = var34.getBaseCreateEntities();
//     java.awt.Font var37 = var34.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("", var37);
//     var26.setTickLabelFont((java.lang.Comparable)var32, var37);
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D("12/31/69 4:00 PM");
//     var41.setAutoRange(true);
//     org.jfree.data.category.CategoryDataset var44 = null;
//     var2.drawItem(var8, var10, var24, var25, (org.jfree.chart.axis.CategoryAxis)var26, (org.jfree.chart.axis.ValueAxis)var41, var44, 0, 0, 4);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    boolean var2 = var1.isCircular();
    java.awt.Paint var4 = var1.getSectionPaint((java.lang.Comparable)(-1));
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var7 = var5.getSeriesOutlineStroke(1);
    java.awt.Paint var9 = var5.lookupSeriesFillPaint((-1));
    var1.setLabelBackgroundPaint(var9);
    var1.setShadowXOffset(1.0E-8d);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var14 = var13.getLabelFont();
    var13.setAutoRangeMinimumSize(100.0d, true);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot(var18);
    double var20 = var19.getOuterSeparatorExtension();
    java.lang.String var21 = var19.getNoDataMessage();
    java.awt.Stroke var22 = var19.getSeparatorStroke();
    var13.setAxisLineStroke(var22);
    var1.setSeparatorStroke(var22);
    var1.setCircular(false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("hi!");
    java.lang.String var4 = var3.getToolTipText();
    java.awt.Font var5 = var3.getFont();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("AreaRendererEndType.TAPER", var5);
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("RangeType.FULL", var5, var7, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("CategoryLabelWidthType.CATEGORY", (org.jfree.data.time.TimePeriod)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var5 = var3.getSubtask(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     org.jfree.chart.urls.PieURLGenerator var2 = var1.getURLGenerator();
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     java.awt.Paint var4 = var3.getItemPaint();
//     java.awt.Paint var5 = var3.getItemPaint();
//     org.jfree.chart.util.RectangleAnchor var6 = var3.getLegendItemGraphicAnchor();
//     org.jfree.chart.util.RectangleAnchor var7 = var3.getLegendItemGraphicAnchor();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var11 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var12 = var11.getHeight();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var16.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var19 = var16.getLabelAnchor();
//     java.awt.geom.Rectangle2D var20 = org.jfree.chart.util.RectangleAnchor.createRectangle(var11, 0.65d, 0.65d, var19);
//     var3.draw(var8, var20);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    double var3 = var1.getSectionDepth();
    boolean var4 = var1.getIgnoreNullValues();
    java.awt.Paint var5 = var1.getOutlinePaint();
    var1.setCircular(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var1, "hi!");
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, 1);
//     int var9 = var6.getColumnCount();
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
//     var11.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.axis.SegmentedTimeline var14 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     long var15 = var14.getSegmentSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var17 = var14.getSegment(604800000L);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var19 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var20 = var19.getUpperClip();
//     boolean var21 = var19.getBaseCreateEntities();
//     java.awt.Font var22 = var19.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("", var22);
//     var11.setTickLabelFont((java.lang.Comparable)var17, var22);
//     org.jfree.chart.entity.CategoryItemEntity var25 = new org.jfree.chart.entity.CategoryItemEntity(var1, "RangeType.FULL", "Multiple Pie Plot", (org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)(short)(-1), (java.lang.Comparable)var17);
//     java.lang.String var26 = var25.getToolTipText();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var27, 1);
//     int var30 = var27.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var31 = null;
//     var27.removeChangeListener(var31);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D();
//     var33.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     var36.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var38);
//     java.text.NumberFormat var40 = var38.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var41 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var42 = var41.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, (org.jfree.chart.axis.CategoryAxis)var33, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
//     org.jfree.data.general.PieDataset var45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var27, (java.lang.Comparable)0.5f);
//     var25.setDataset((org.jfree.data.category.CategoryDataset)var27);
//     
//     // Checks the contract:  equals-hashcode on var6 and var27
//     assertTrue("Contract failed: equals-hashcode on var6 and var27", var6.equals(var27) ? var6.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var6
//     assertTrue("Contract failed: equals-hashcode on var27 and var6", var27.equals(var6) ? var27.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var20 = var19.getAlpha();
//     org.jfree.chart.util.Layer var21 = null;
//     var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
//     org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation();
//     org.jfree.chart.axis.ValueAxis var24 = var16.getRangeAxis();
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var27 = var26.getAlpha();
//     var16.addRangeMarker((org.jfree.chart.plot.Marker)var26);
//     
//     // Checks the contract:  equals-hashcode on var19 and var26
//     assertTrue("Contract failed: equals-hashcode on var19 and var26", var19.equals(var26) ? var19.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var19
//     assertTrue("Contract failed: equals-hashcode on var26 and var19", var26.equals(var19) ? var26.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var1 = var0.getLabelFont();
    var0.setAutoRangeMinimumSize(100.0d, true);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    double var7 = var6.getOuterSeparatorExtension();
    java.lang.String var8 = var6.getNoDataMessage();
    java.awt.Stroke var9 = var6.getSeparatorStroke();
    var0.setAxisLineStroke(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(98.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var1 = var0.getUpperClip();
//     boolean var2 = var0.getBaseCreateEntities();
//     java.awt.Paint var3 = var0.getBaseOutlinePaint();
//     java.awt.Paint var4 = var0.getBaseFillPaint();
//     var0.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     var8.setIgnoreZeroValues(true);
//     java.awt.Paint var11 = var8.getLabelPaint();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     var15.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange();
//     java.util.Date var20 = var19.getLowerDate();
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var15.dateToJava2D(var20, var21, var22);
//     var13.setMinimumDate(var20);
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     var26.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var29 = new org.jfree.data.time.DateRange();
//     java.util.Date var30 = var29.getLowerDate();
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     double var33 = var26.dateToJava2D(var30, var31, var32);
//     org.jfree.data.time.SimpleTimePeriod var34 = new org.jfree.data.time.SimpleTimePeriod(var20, var30);
//     java.awt.Stroke var35 = var8.getSectionOutlineStroke((java.lang.Comparable)var30);
//     org.jfree.chart.util.ShapeList var40 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var40.setShape(100, var43);
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
//     boolean var46 = var45.isRangeGridlinesVisible();
//     var45.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var50 = null;
//     java.util.Collection var51 = var45.getDomainMarkers(100, var50);
//     org.jfree.data.xy.XYDataset var52 = null;
//     int var53 = var45.indexOf(var52);
//     java.awt.Stroke var54 = var45.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.RingPlot var56 = new org.jfree.chart.plot.RingPlot(var55);
//     double var57 = var56.getOuterSeparatorExtension();
//     double var58 = var56.getSectionDepth();
//     java.awt.Paint var59 = var56.getLabelPaint();
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var43, var54, var59);
//     var8.setBaseSectionOutlineStroke(var54);
//     var0.setSeriesStroke(2, var54);
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
//     boolean var64 = var63.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var66 = new org.jfree.chart.axis.ValueAxis[] { var65};
//     var63.setDomainAxes(var66);
//     org.jfree.chart.axis.AxisSpace var68 = null;
//     var63.setFixedDomainAxisSpace(var68);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var70 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var70.setBaseSeriesVisible(false, false);
//     org.jfree.data.general.PieDataset var75 = null;
//     org.jfree.chart.plot.RingPlot var76 = new org.jfree.chart.plot.RingPlot(var75);
//     double var77 = var76.getOuterSeparatorExtension();
//     double var78 = var76.getSectionDepth();
//     java.awt.Paint var79 = var76.getLabelPaint();
//     var70.setSeriesOutlinePaint(0, var79, false);
//     var63.setDomainGridlinePaint(var79);
//     var0.setBaseOutlinePaint(var79, false);
//     
//     // Checks the contract:  equals-hashcode on var56 and var76
//     assertTrue("Contract failed: equals-hashcode on var56 and var76", var56.equals(var76) ? var56.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var56
//     assertTrue("Contract failed: equals-hashcode on var76 and var56", var76.equals(var56) ? var76.hashCode() == var56.hashCode() : true);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.chart.urls.PieURLGenerator var2 = var1.getURLGenerator();
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    java.awt.Paint var4 = var3.getItemPaint();
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setItemPaint(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    float var20 = var19.getAlpha();
    org.jfree.chart.util.Layer var21 = null;
    var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
    org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation();
    org.jfree.chart.axis.ValueAxis var24 = var16.getRangeAxis();
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    boolean var27 = var26.isRangeGridlinesVisible();
    var26.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var31 = null;
    java.util.Collection var32 = var26.getDomainMarkers(100, var31);
    org.jfree.data.xy.XYDataset var33 = null;
    int var34 = var26.indexOf(var33);
    org.jfree.chart.axis.AxisLocation var36 = var26.getDomainAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var37 = var26.getDomainAxisLocation();
    var16.setRangeAxisLocation(1, var37);
    org.jfree.chart.LegendItemCollection var39 = var16.getFixedLegendItems();
    org.jfree.chart.renderer.category.LayeredBarRenderer var40 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var42 = var40.getSeriesStroke(100);
    var16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var40, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
    org.jfree.chart.plot.Plot var20 = var16.getRootPlot();
    org.jfree.chart.axis.CategoryAnchor var21 = var16.getDomainGridlinePosition();
    org.jfree.data.general.PieDataset var22 = null;
    org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
    double var24 = var23.getOuterSeparatorExtension();
    double var25 = var23.getLabelGap();
    org.jfree.chart.event.PlotChangeEvent var26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var23);
    org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot();
    var27.setIgnoreZeroValues(true);
    java.awt.Paint var30 = var27.getLabelPaint();
    var23.setLabelOutlinePaint(var30);
    org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var33 = var32.getPadding();
    double var35 = var33.trimHeight(100.0d);
    var23.setInsets(var33);
    java.awt.Paint var37 = var23.getSeparatorPaint();
    boolean var38 = var21.equals((java.lang.Object)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 98.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.renderer.PolarItemRenderer var2 = var0.getRenderer();
//     java.lang.Object var3 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.entity.EntityCollection var3 = null;
//     org.jfree.chart.ChartRenderingInfo var4 = new org.jfree.chart.ChartRenderingInfo(var3);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = var4.getPlotInfo();
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var9 = var8.getHeight();
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var13.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var16 = var13.getLabelAnchor();
//     java.awt.geom.Rectangle2D var17 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 0.65d, 0.65d, var16);
//     var5.setDataArea(var17);
//     org.jfree.chart.util.Size2D var21 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var22 = var21.getHeight();
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var26.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var29 = var26.getLabelAnchor();
//     java.awt.geom.Rectangle2D var30 = org.jfree.chart.util.RectangleAnchor.createRectangle(var21, 0.65d, 0.65d, var29);
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     org.jfree.chart.entity.EntityCollection var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = var33.getPlotInfo();
//     org.jfree.chart.axis.AxisState var35 = var0.draw(var1, 1.05d, var17, var30, var31, var34);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    boolean var4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    var5.mapDatasetToDomainAxis((-1), 100);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var5);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var13 = var0.getMeanValue(2, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var5.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.text.TextAnchor var8 = var5.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var9 = org.jfree.chart.text.TextUtilities.drawAlignedString("AreaRendererEndType.TAPER", var1, 0.8f, 0.8f, var8);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 1);
//     int var7 = var4.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var8 = null;
//     var4.removeChangeListener(var8);
//     var4.add(10.0d, 0.05d, (java.lang.Comparable)'#', (java.lang.Comparable)100.0d);
//     org.jfree.data.Range var15 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     var16.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var20 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     java.awt.Stroke var22 = var20.getSeriesOutlineStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesFillPaint((-1));
//     var18.setLabelPaint(var24);
//     var3.setWallPaint(var24);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var28, 1);
//     int var31 = var28.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var32 = null;
//     var28.removeChangeListener(var32);
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D();
//     var34.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     var37.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var39);
//     java.text.NumberFormat var41 = var39.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var42 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var43 = var42.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var28, (org.jfree.chart.axis.CategoryAxis)var34, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
//     java.util.List var45 = var44.getAnnotations();
//     java.awt.geom.Rectangle2D var46 = null;
//     var3.drawDomainGridline(var27, var44, var46, 98.0d);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     var0.setIgnoreZeroValues(true);
//     java.awt.Paint var3 = var0.getLabelPaint();
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     var7.setRange(0.0d, 100.0d);
//     org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange();
//     java.util.Date var12 = var11.getLowerDate();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var7.dateToJava2D(var12, var13, var14);
//     var5.setMinimumDate(var12);
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("");
//     var18.setLowerBound(0.0d);
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     java.util.Date var22 = var21.getLowerDate();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var18.dateToJava2D(var22, var23, var24);
//     org.jfree.data.time.SimpleTimePeriod var26 = new org.jfree.data.time.SimpleTimePeriod(var12, var22);
//     java.awt.Stroke var27 = var0.getSectionOutlineStroke((java.lang.Comparable)var22);
//     org.jfree.chart.util.ShapeList var32 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var32.setShape(100, var35);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     boolean var38 = var37.isRangeGridlinesVisible();
//     var37.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var42 = null;
//     java.util.Collection var43 = var37.getDomainMarkers(100, var42);
//     org.jfree.data.xy.XYDataset var44 = null;
//     int var45 = var37.indexOf(var44);
//     java.awt.Stroke var46 = var37.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     double var49 = var48.getOuterSeparatorExtension();
//     double var50 = var48.getSectionDepth();
//     java.awt.Paint var51 = var48.getLabelPaint();
//     org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var35, var46, var51);
//     var0.setBaseSectionOutlineStroke(var46);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(2);
//     java.awt.Paint var56 = var0.getSectionOutlinePaint((java.lang.Comparable)2);
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.RingPlot var58 = new org.jfree.chart.plot.RingPlot(var57);
//     double var59 = var58.getOuterSeparatorExtension();
//     double var60 = var58.getLabelGap();
//     org.jfree.chart.event.PlotChangeEvent var61 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var58);
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot();
//     var62.setIgnoreZeroValues(true);
//     java.awt.Paint var65 = var62.getLabelPaint();
//     var58.setLabelOutlinePaint(var65);
//     org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var68 = var67.getPadding();
//     double var70 = var68.trimHeight(100.0d);
//     var58.setInsets(var68);
//     org.jfree.data.general.PieDataset var72 = null;
//     org.jfree.chart.plot.RingPlot var73 = new org.jfree.chart.plot.RingPlot(var72);
//     boolean var74 = var73.isCircular();
//     org.jfree.chart.labels.PieSectionLabelGenerator var75 = var73.getLabelGenerator();
//     var58.setLegendLabelToolTipGenerator(var75);
//     var0.setLabelGenerator(var75);
//     
//     // Checks the contract:  equals-hashcode on var48 and var73
//     assertTrue("Contract failed: equals-hashcode on var48 and var73", var48.equals(var73) ? var48.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var48
//     assertTrue("Contract failed: equals-hashcode on var73 and var48", var73.equals(var48) ? var73.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(1, var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(15, var6);
    java.lang.Number var9 = var1.getValue((java.lang.Comparable)(short)100, (java.lang.Comparable)var8);
    java.util.List var12 = var1.getOutliers((java.lang.Comparable)1.0f, (java.lang.Comparable)"Polar Plot");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var15 = var0.generateURL((org.jfree.data.category.CategoryDataset)var1, 0, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("CategoryLabelWidthType.CATEGORY", (org.jfree.data.time.TimePeriod)var2);
    org.jfree.data.time.TimePeriod var4 = var3.getDuration();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
//     var0.setDomainAxes(var3);
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var0.setFixedDomainAxisSpace(var5);
//     var0.setRangeCrosshairValue(98.0d);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     double var11 = var10.getOuterSeparatorExtension();
//     double var12 = var10.getSectionDepth();
//     java.awt.Paint var13 = var10.getLabelLinkPaint();
//     var0.setNoDataMessagePaint(var13);
//     java.awt.geom.Point2D var15 = var0.getQuadrantOrigin();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var0.drawAnnotations(var16, var17, var18);
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     var0.setRenderer(var20);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     boolean var23 = var22.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var24};
//     var22.setDomainAxes(var25);
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var22.setFixedDomainAxisSpace(var27);
//     var22.zoom(0.0d);
//     org.jfree.chart.axis.AxisLocation var31 = var22.getDomainAxisLocation();
//     var0.setDomainAxisLocation(var31);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var35 = var34.getPaint();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var37 = var36.getPadding();
//     var34.setLabelOffset(var37);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot(var39);
//     double var41 = var40.getOuterSeparatorExtension();
//     double var42 = var40.getLabelGap();
//     org.jfree.chart.util.ShapeList var47 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var47.setShape(100, var50);
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
//     boolean var53 = var52.isRangeGridlinesVisible();
//     var52.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var57 = null;
//     java.util.Collection var58 = var52.getDomainMarkers(100, var57);
//     org.jfree.data.xy.XYDataset var59 = null;
//     int var60 = var52.indexOf(var59);
//     java.awt.Stroke var61 = var52.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.RingPlot var63 = new org.jfree.chart.plot.RingPlot(var62);
//     double var64 = var63.getOuterSeparatorExtension();
//     double var65 = var63.getSectionDepth();
//     java.awt.Paint var66 = var63.getLabelPaint();
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var50, var61, var66);
//     var40.setLabelShadowPaint(var66);
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     var40.handleClick(0, (-1), var71);
//     double var73 = var40.getSectionDepth();
//     var34.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var40);
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var34);
//     
//     // Checks the contract:  equals-hashcode on var10 and var63
//     assertTrue("Contract failed: equals-hashcode on var10 and var63", var10.equals(var63) ? var10.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var10
//     assertTrue("Contract failed: equals-hashcode on var63 and var10", var63.equals(var10) ? var63.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    long var1 = var0.getSegmentSize();
    boolean var4 = var0.containsDomainRange((-1L), 1L);
    boolean var7 = var0.containsDomainRange(1577894400001L, 1577980800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     java.lang.Object var6 = var5.clone();
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.setMax((-1.0d));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, 1);
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var3, true);
    java.util.List var8 = var3.getColumnKeys();
    var0.setTicks(var8);
    double var10 = var0.getMax();
    var0.cursorRight(10.0d);
    double var13 = var0.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.0d));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, 1);
    org.jfree.data.Range var4 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var6 = var5.getUpperClip();
    java.awt.Stroke var9 = var5.getItemStroke((-459), (-459));
    var0.setBaseStroke(var9, false);
    boolean var12 = var0.getRenderAsPercentages();
    java.lang.Object var13 = var0.clone();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var16 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var15);
    org.jfree.chart.entity.EntityCollection var17 = var16.getEntityCollection();
    org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
    double var21 = var20.getHeight();
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var25.setLabel("java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.util.RectangleAnchor var28 = var25.getLabelAnchor();
    java.awt.geom.Rectangle2D var29 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 0.65d, 0.65d, var28);
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Font var33 = var31.getTickLabelFont((java.lang.Comparable)(-1));
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var35 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    java.lang.Number var38 = var35.getMaxOutlier((java.lang.Comparable)10, (java.lang.Comparable)0.8f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var14, var16, var29, var30, (org.jfree.chart.axis.CategoryAxis)var31, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.data.category.CategoryDataset)var35, 1, 10, 12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setXOffset(4.0d);
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getSeriesURLGenerator((-1));
    boolean var5 = var0.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    org.jfree.data.xy.XYDataset var7 = null;
    int var8 = var0.indexOf(var7);
    java.awt.Stroke var9 = var0.getRangeGridlineStroke();
    java.awt.Paint var10 = var0.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    double var14 = var13.getOuterSeparatorExtension();
    double var15 = var13.getSectionDepth();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var13);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var16);
    org.jfree.chart.axis.AxisSpace var18 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var19 = var0.getDomainAxisLocation();
    java.awt.Stroke var20 = var0.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.lang.Boolean var4 = var2.getSeriesShapesFilled(15);
    var2.setSeriesShapesVisible(15, (java.lang.Boolean)true);
    org.jfree.chart.renderer.category.LayeredBarRenderer var8 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var9 = var8.getUpperClip();
    boolean var10 = var8.getBaseCreateEntities();
    java.awt.Paint var11 = var8.getBaseOutlinePaint();
    java.awt.Paint var12 = var8.getBaseFillPaint();
    var2.setBaseOutlinePaint(var12, true);
    var2.setUseFillPaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Polar Plot", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    var16.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    boolean var20 = var19.isRangeGridlinesVisible();
    var19.setRangeCrosshairValue(0.2d);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    boolean var24 = var23.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var26 = new org.jfree.chart.axis.ValueAxis[] { var25};
    var23.setDomainAxes(var26);
    var19.setRangeAxes(var26);
    var16.setRangeAxes(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var17);
//     
//     // Checks the contract:  equals-hashcode on var17 and var9
//     assertTrue("Contract failed: equals-hashcode on var17 and var9", var17.equals(var9) ? var17.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var9.", var17.equals(var9) == var9.equals(var17));
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    java.lang.Number var3 = var0.getMaxOutlier((java.lang.Comparable)10, (java.lang.Comparable)0.8f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getMeanValue((-1), 4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseCreateEntities();
    var0.setBase(1.0d);
    java.awt.Font var5 = var0.getBaseItemLabelFont();
    var0.setAutoPopulateSeriesOutlineStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     double var2 = var1.getOuterSeparatorExtension();
//     java.lang.String var3 = var1.getNoDataMessage();
//     java.awt.Stroke var4 = var1.getSeparatorStroke();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     boolean var6 = var5.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var8 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var5.setDomainAxes(var8);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var5.setFixedDomainAxisSpace(var10);
//     var5.zoom(0.0d);
//     java.awt.Paint var14 = var5.getDomainTickBandPaint();
//     java.awt.Paint var15 = var5.getDomainGridlinePaint();
//     var1.setLabelPaint(var15);
//     var1.setNoDataMessage("");
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.entity.EntityCollection var20 = null;
//     org.jfree.chart.ChartRenderingInfo var21 = new org.jfree.chart.ChartRenderingInfo(var20);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = var21.getPlotInfo();
//     org.jfree.chart.util.Size2D var25 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var26 = var25.getHeight();
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var30.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var33 = var30.getLabelAnchor();
//     java.awt.geom.Rectangle2D var34 = org.jfree.chart.util.RectangleAnchor.createRectangle(var25, 0.65d, 0.65d, var33);
//     var22.setDataArea(var34);
//     org.jfree.chart.plot.PiePlot var36 = null;
//     java.lang.Integer var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     org.jfree.chart.plot.PiePlotState var39 = var1.initialise(var19, var34, var36, var37, var38);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    var3.draw(var4, var5);
    var3.setNotify(false);
    java.lang.Object var9 = var3.clone();
    org.jfree.chart.util.RectangleEdge var10 = var3.getPosition();
    var1.setTitle(var3);
    java.awt.Graphics2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var13 = var3.arrange(var12);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var1 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var2 = var1.getUpperClip();
//     boolean var3 = var1.getBaseCreateEntities();
//     java.awt.Font var4 = var1.getBaseItemLabelFont();
//     var0.setAngleLabelFont(var4);
//     var0.zoom(0.0d);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getMeanValue(1, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var2 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var3 = var2.getUpperClip();
    boolean var4 = var2.getBaseCreateEntities();
    java.awt.Font var5 = var2.getBaseItemLabelFont();
    org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine("", var5);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.RingPlot var8 = new org.jfree.chart.plot.RingPlot(var7);
    double var9 = var8.getOuterSeparatorExtension();
    double var10 = var8.getSectionDepth();
    java.awt.Paint var11 = var8.getLabelLinkPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var12 = null;
    var8.setLegendLabelToolTipGenerator(var12);
    boolean var14 = var8.isSubplot();
    java.awt.Paint var15 = var8.getSeparatorPaint();
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("Other", var5, var15, (-1.0f));
    java.awt.Font var18 = var17.getFont();
    java.awt.Font var19 = var17.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
//     java.lang.Comparable var7 = var5.getRowKey(100);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
    int var3 = var0.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var4 = null;
    var0.removeChangeListener(var4);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    var6.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
    java.text.NumberFormat var13 = var11.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var15 = var14.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxisForDataset(100);
    org.jfree.chart.axis.AxisLocation var19 = var16.getRangeAxisLocation();
    org.jfree.chart.plot.Plot var20 = var16.getRootPlot();
    org.jfree.chart.axis.CategoryAnchor var21 = var16.getDomainGridlinePosition();
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var24 = var23.clone();
    org.jfree.chart.util.Layer var25 = null;
    var16.addRangeMarker((org.jfree.chart.plot.Marker)var23, var25);
    double var27 = var16.getRangeCrosshairValue();
    org.jfree.chart.util.Layer var29 = null;
    java.util.Collection var30 = var16.getDomainMarkers((-1), var29);
    org.jfree.chart.plot.CategoryMarker var32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)"java.awt.Color[r=255,g=255,b=255]");
    org.jfree.chart.util.Layer var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addDomainMarker(var32, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
//     java.text.NumberFormat var4 = var2.getNumberFormatOverride();
//     java.awt.Paint var5 = var2.getTickMarkPaint();
//     java.awt.Font var6 = var2.getTickLabelFont();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.entity.EntityCollection var9 = null;
//     org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo(var9);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = var10.getPlotInfo();
//     org.jfree.chart.util.Size2D var14 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var15 = var14.getHeight();
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var19.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var22 = var19.getLabelAnchor();
//     java.awt.geom.Rectangle2D var23 = org.jfree.chart.util.RectangleAnchor.createRectangle(var14, 0.65d, 0.65d, var22);
//     var11.setDataArea(var23);
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     var27.clearDomainMarkers();
//     boolean var29 = var26.equals((java.lang.Object)var27);
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     java.awt.geom.Point2D var33 = null;
//     var27.zoomDomainAxes(1.0E-8d, (-1.0d), var32, var33);
//     org.jfree.chart.util.RectangleEdge var35 = var27.getRangeAxisEdge();
//     org.jfree.chart.entity.EntityCollection var36 = null;
//     org.jfree.chart.ChartRenderingInfo var37 = new org.jfree.chart.ChartRenderingInfo(var36);
//     org.jfree.chart.entity.EntityCollection var38 = var37.getEntityCollection();
//     org.jfree.chart.plot.PlotRenderingInfo var39 = var37.getPlotInfo();
//     org.jfree.chart.axis.AxisState var40 = var2.draw(var7, 0.05d, var23, var25, var35, var39);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(98.0d, 0.0d, true);
//     var3.setRenderAsPercentages(true);
//     java.awt.Paint var6 = var3.getWallPaint();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Paint var8 = var7.getBackgroundPaint();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var10 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var11 = var10.getUpperClip();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     boolean var13 = var12.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var14};
//     var12.setDomainAxes(var15);
//     org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation();
//     boolean var18 = var10.equals((java.lang.Object)var17);
//     var7.setRangeAxisLocation(10, var17, true);
//     boolean var21 = var7.isRangeCrosshairLockedOnData();
//     boolean var22 = var3.equals((java.lang.Object)var7);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, 1);
//     int var27 = var24.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var28 = null;
//     var24.removeChangeListener(var28);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     var30.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     var33.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var35);
//     java.text.NumberFormat var37 = var35.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var38 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var39 = var38.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var30, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var44 = var43.getAlpha();
//     org.jfree.chart.util.Layer var45 = null;
//     var40.addRangeMarker(10, (org.jfree.chart.plot.Marker)var43, var45);
//     org.jfree.chart.axis.AxisLocation var47 = var40.getRangeAxisLocation();
//     java.awt.geom.Rectangle2D var48 = null;
//     var3.drawDomainGridline(var23, var40, var48, (-1.0d));
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.insertValue(0, (java.lang.Comparable)0.0d, (java.lang.Number)(short)1);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(2);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(1, var7);
    var0.addValue((java.lang.Comparable)1, (-2.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var12 = var0.getKey(5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairValue(0.2d);
    org.jfree.chart.plot.DrawingSupplier var4 = var0.getDrawingSupplier();
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = var0.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     java.lang.Number var3 = var0.getMaxOutlier((java.lang.Comparable)10, (java.lang.Comparable)0.8f);
//     int var4 = var0.getRowCount();
//     int var5 = var0.getRowCount();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(2);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addDays(1, var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(15, var12);
//     java.lang.Number var15 = var7.getValue((java.lang.Comparable)(short)100, (java.lang.Comparable)var14);
//     java.lang.Number var16 = var0.getMedianValue((java.lang.Comparable)(-2.0d), (java.lang.Comparable)var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, 1);
    org.jfree.data.Range var4 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.renderer.category.LayeredBarRenderer var5 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var6 = var5.getUpperClip();
    java.awt.Stroke var9 = var5.getItemStroke((-459), (-459));
    var0.setBaseStroke(var9, false);
    double var12 = var0.getItemLabelAnchorOffset();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 2.0f);
    var0.setBaseShape(var15, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     java.lang.String[] var3 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var3, var4, var6);
//     org.jfree.data.category.CategoryDataset var8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.ABSOLUTE", "", var4);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     java.lang.String[] var0 = null;
//     java.lang.String[] var2 = new java.lang.String[] { "Multiple Pie Plot"};
//     java.lang.Number[][] var3 = null;
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var2, var3, var5);
//     java.lang.Number[] var7 = null;
//     java.lang.Number[][] var8 = new java.lang.Number[][] { var7};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var9 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var5, var8);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    var2.setBaseShapesVisible(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var2.getLegendItemLabelGenerator();
    java.awt.Paint var7 = var2.getSeriesItemLabelPaint(0);
    java.lang.Boolean var9 = var2.getSeriesLinesVisible(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, Double.NaN, 10.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.util.List var6 = var5.getBlocks();
//     java.util.List var7 = var5.getBlocks();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var11 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var12 = var11.getHeight();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var16.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var19 = var16.getLabelAnchor();
//     java.awt.geom.Rectangle2D var20 = org.jfree.chart.util.RectangleAnchor.createRectangle(var11, 0.65d, 0.65d, var19);
//     var5.draw(var8, var20);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.data.RangeType var4 = var2.getRangeType();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    double var7 = var6.getOuterSeparatorExtension();
    var6.setExplodePercent((java.lang.Comparable)"hi!", 1.0d);
    boolean var11 = var2.hasListener((java.util.EventListener)var6);
    org.jfree.chart.util.RectangleInsets var12 = var6.getInsets();
    org.jfree.chart.LegendItemCollection var13 = var6.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = var13.get(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.Comparable var1 = var0.getAggregatedItemsKey();
    java.awt.Font var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessageFont(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Other"+ "'", var1.equals("Other"));

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    var1.clearDomainMarkers();
    boolean var3 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var1.zoomDomainAxes(1.0E-8d, (-1.0d), var6, var7);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRenderer((-1), var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, 1);
    int var4 = var1.getColumnCount();
    org.jfree.data.general.DatasetChangeListener var5 = null;
    var1.removeChangeListener(var5);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    var7.setMaximumCategoryLabelWidthRatio(0.0f);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    var10.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var12);
    java.text.NumberFormat var14 = var12.getNumberFormatOverride();
    org.jfree.chart.renderer.category.LayeredBarRenderer var15 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var16 = var15.getUpperClip();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.CategoryAxis var19 = var17.getDomainAxisForDataset(100);
    org.jfree.chart.event.PlotChangeEvent var20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var17);
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
    boolean var22 = var21.isRangeGridlinesVisible();
    var21.setRangeCrosshairValue(0.2d);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var21.getDomainMarkers(100, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    int var29 = var21.indexOf(var28);
    java.awt.Stroke var30 = var21.getRangeGridlineStroke();
    java.awt.Paint var31 = var21.getDomainGridlinePaint();
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot(var33);
    double var35 = var34.getOuterSeparatorExtension();
    double var36 = var34.getSectionDepth();
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var34);
    var21.addChangeListener((org.jfree.chart.event.PlotChangeListener)var37);
    var37.setAntiAlias(true);
    var20.setChart(var37);
    org.jfree.chart.event.ChartChangeEvent var42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)10, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var1 = var0.getUpperClip();
    boolean var2 = var0.getBaseCreateEntities();
    java.awt.Font var3 = var0.getBaseItemLabelFont();
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getNegativeItemLabelPosition(100, 15);
    double var7 = var6.getAngle();
    org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
    boolean var11 = var6.equals((java.lang.Object)100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var2, (java.lang.Comparable)(short)0, (-1.0d), 10);
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var2);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     var8.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var10);
//     java.lang.Object var12 = var10.clone();
//     var10.setAutoRange(true);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     double var17 = var16.getOuterSeparatorExtension();
//     double var18 = var16.getSectionDepth();
//     java.awt.Paint var19 = var16.getLabelLinkPaint();
//     var10.setLabelPaint(var19);
//     boolean var21 = var7.equals((java.lang.Object)var19);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.RingPlot var23 = new org.jfree.chart.plot.RingPlot(var22);
//     boolean var24 = var23.isCircular();
//     org.jfree.chart.labels.PieSectionLabelGenerator var25 = var23.getLabelGenerator();
//     var7.setLabelGenerator(var25);
//     
//     // Checks the contract:  equals-hashcode on var16 and var23
//     assertTrue("Contract failed: equals-hashcode on var16 and var23", var16.equals(var23) ? var16.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var16
//     assertTrue("Contract failed: equals-hashcode on var23 and var16", var23.equals(var16) ? var23.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    var3.setRange(0.0d, 100.0d);
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange();
    java.util.Date var8 = var7.getLowerDate();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var3.dateToJava2D(var8, var9, var10);
    var1.setMinimumDate(var8);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    var14.setLowerBound(0.0d);
    org.jfree.data.time.DateRange var17 = new org.jfree.data.time.DateRange();
    java.util.Date var18 = var17.getLowerDate();
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var14.dateToJava2D(var18, var19, var20);
    org.jfree.data.time.SimpleTimePeriod var22 = new org.jfree.data.time.SimpleTimePeriod(var8, var18);
    org.jfree.chart.renderer.category.LayeredBarRenderer var23 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var24 = var23.getUpperClip();
    boolean var25 = var23.getBaseCreateEntities();
    var23.setBase(1.0d);
    boolean var28 = var22.equals((java.lang.Object)var23);
    java.awt.Paint var30 = var23.getSeriesItemLabelPaint((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 1);
//     int var3 = var0.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var4 = null;
//     var0.removeChangeListener(var4);
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     var9.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var11);
//     java.text.NumberFormat var13 = var11.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var14 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var15 = var14.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var20 = var19.getAlpha();
//     org.jfree.chart.util.Layer var21 = null;
//     var16.addRangeMarker(10, (org.jfree.chart.plot.Marker)var19, var21);
//     org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation();
//     org.jfree.chart.axis.ValueAxis var24 = var16.getRangeAxis();
//     org.jfree.chart.axis.AxisLocation var26 = var16.getRangeAxisLocation(2);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var27, 1);
//     int var30 = var27.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var31 = null;
//     var27.removeChangeListener(var31);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D();
//     var33.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     var36.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var38);
//     java.text.NumberFormat var40 = var38.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var41 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var42 = var41.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, (org.jfree.chart.axis.CategoryAxis)var33, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
//     org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var47 = var46.getAlpha();
//     org.jfree.chart.util.Layer var48 = null;
//     var43.addRangeMarker(10, (org.jfree.chart.plot.Marker)var46, var48);
//     double var50 = var46.getValue();
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.RingPlot var52 = new org.jfree.chart.plot.RingPlot(var51);
//     double var53 = var52.getOuterSeparatorExtension();
//     double var54 = var52.getLabelGap();
//     org.jfree.chart.util.ShapeList var59 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
//     var59.setShape(100, var62);
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot();
//     boolean var65 = var64.isRangeGridlinesVisible();
//     var64.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var69 = null;
//     java.util.Collection var70 = var64.getDomainMarkers(100, var69);
//     org.jfree.data.xy.XYDataset var71 = null;
//     int var72 = var64.indexOf(var71);
//     java.awt.Stroke var73 = var64.getRangeGridlineStroke();
//     org.jfree.data.general.PieDataset var74 = null;
//     org.jfree.chart.plot.RingPlot var75 = new org.jfree.chart.plot.RingPlot(var74);
//     double var76 = var75.getOuterSeparatorExtension();
//     double var77 = var75.getSectionDepth();
//     java.awt.Paint var78 = var75.getLabelPaint();
//     org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var62, var73, var78);
//     var52.setLabelShadowPaint(var78);
//     var46.setPaint(var78);
//     var16.setDomainGridlinePaint(var78);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var36
//     assertTrue("Contract failed: equals-hashcode on var9 and var36", var9.equals(var36) ? var9.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var9
//     assertTrue("Contract failed: equals-hashcode on var36 and var9", var36.equals(var9) ? var36.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "February", "Multiple Pie Plot", "Multiple Pie Plot", "Multiple Pie Plot");
    var5.setVersion("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    java.lang.String[] var1 = new java.lang.String[] { "Multiple Pie Plot"};
    java.lang.Number[][] var2 = null;
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    org.jfree.data.category.DefaultIntervalCategoryDataset var5 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var2, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var5.getEndValue(0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    var1.setLowerBound(0.0d);
    org.jfree.chart.renderer.category.LayeredBarRenderer var4 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    double var5 = var4.getUpperClip();
    boolean var6 = var4.getBaseCreateEntities();
    var4.setBase(1.0d);
    java.awt.Shape var9 = var4.getBaseShape();
    org.jfree.chart.entity.AxisLabelEntity var12 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var9, "", "RangeType.FULL");
    java.lang.String var13 = var12.getToolTipText();
    var12.setToolTipText("December 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + ""+ "'", var13.equals(""));

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
//     java.awt.Stroke var4 = var0.getDomainCrosshairStroke();
//     org.jfree.chart.axis.AxisSpace var5 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var0.getDomainMarkers(var6);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, 1);
//     int var11 = var8.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var12 = null;
//     var8.removeChangeListener(var12);
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
//     var14.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     var17.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var19);
//     java.text.NumberFormat var21 = var19.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var23 = var22.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, (org.jfree.chart.axis.CategoryAxis)var14, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     java.awt.Paint var25 = var24.getDomainGridlinePaint();
//     var24.configureRangeAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var27 = var24.getDatasetRenderingOrder();
//     java.awt.Stroke var28 = var24.getRangeCrosshairStroke();
//     var24.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var31 = var24.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     var32.setUpperMargin(98.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var35 = var32.getCategoryLabelPositions();
//     int var36 = var24.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var32);
//     boolean var37 = var0.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 0.0f, 1.0f);
    java.lang.String var4 = var3.toString();
    float[] var6 = new float[] { 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getRGBComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "java.awt.Color[r=255,g=255,b=255]"+ "'", var4.equals("java.awt.Color[r=255,g=255,b=255]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var2);
    java.awt.Stroke var4 = var0.getDomainCrosshairStroke();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var0.markerChanged(var5);
    java.lang.Object var7 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(2.0d, 1.0E-8d, 10.0d, (-1.0d));
    double var5 = var4.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.ValueAxis[] var3 = new org.jfree.chart.axis.ValueAxis[] { var2};
    var0.setDomainAxes(var3);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5);
    var0.zoom(0.0d);
    java.awt.Paint var9 = var0.getDomainTickBandPaint();
    java.awt.Paint var10 = var0.getDomainTickBandPaint();
    java.awt.Stroke var11 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisLocation var13 = null;
    var0.setRangeAxisLocation(2, var13, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Font var3 = var1.getTickLabelFont((java.lang.Comparable)(-1));
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     boolean var5 = var4.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var4.setDomainAxes(var7);
//     org.jfree.chart.axis.AxisSpace var9 = null;
//     var4.setFixedDomainAxisSpace(var9);
//     var4.zoom(0.0d);
//     java.awt.Paint var13 = var4.getDomainTickBandPaint();
//     org.jfree.chart.util.Layer var14 = null;
//     java.util.Collection var15 = var4.getDomainMarkers(var14);
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart("hi!", var3, (org.jfree.chart.plot.Plot)var4, false);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var22 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var23 = var22.getUpperClip();
//     boolean var24 = var22.getBaseCreateEntities();
//     var22.setBase(1.0d);
//     java.awt.Shape var27 = var22.getBaseShape();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     org.jfree.chart.urls.PieURLGenerator var30 = var29.getURLGenerator();
//     java.awt.Stroke var31 = var29.getBaseSectionOutlineStroke();
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     boolean var33 = var32.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.ValueAxis[] var35 = new org.jfree.chart.axis.ValueAxis[] { var34};
//     var32.setDomainAxes(var35);
//     org.jfree.chart.axis.AxisSpace var37 = null;
//     var32.setFixedDomainAxisSpace(var37);
//     var32.zoom(0.0d);
//     java.awt.Paint var41 = var32.getDomainTickBandPaint();
//     java.awt.Paint var42 = var32.getDomainGridlinePaint();
//     org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("", "hi!", "poly", "DateTickUnit[DAY, 1]", var27, var31, var42);
//     var17.setBorderStroke(var31);
//     
//     // Checks the contract:  equals-hashcode on var4 and var32
//     assertTrue("Contract failed: equals-hashcode on var4 and var32", var4.equals(var32) ? var4.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var4
//     assertTrue("Contract failed: equals-hashcode on var32 and var4", var32.equals(var4) ? var32.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var1 = var0.getUpperClip();
//     boolean var2 = var0.getBaseCreateEntities();
//     java.awt.Stroke var4 = var0.getSeriesOutlineStroke(0);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var5.setBaseSeriesVisible(false, false);
//     org.jfree.chart.renderer.category.LayeredBarRenderer var10 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var11 = var10.getUpperClip();
//     boolean var12 = var10.getBaseCreateEntities();
//     java.awt.Font var13 = var10.getBaseItemLabelFont();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var10.getNegativeItemLabelPosition(100, 15);
//     var5.setSeriesPositiveItemLabelPosition(15, var16, false);
//     var0.setBasePositiveItemLabelPosition(var16);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var21 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.PieDataset var23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var21, 1);
//     int var24 = var21.getColumnCount();
//     org.jfree.data.general.DatasetChangeListener var25 = null;
//     var21.removeChangeListener(var25);
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
//     var27.setMaximumCategoryLabelWidthRatio(0.0f);
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     var30.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var32);
//     java.text.NumberFormat var34 = var32.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.LayeredBarRenderer var35 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var36 = var35.getUpperClip();
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var21, (org.jfree.chart.axis.CategoryAxis)var27, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     float var41 = var40.getAlpha();
//     org.jfree.chart.util.Layer var42 = null;
//     var37.addRangeMarker(10, (org.jfree.chart.plot.Marker)var40, var42);
//     org.jfree.chart.axis.AxisLocation var44 = var37.getRangeAxisLocation();
//     org.jfree.chart.axis.ValueAxis var45 = var37.getRangeAxis();
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     boolean var48 = var47.isRangeGridlinesVisible();
//     var47.setRangeCrosshairValue(0.2d);
//     org.jfree.chart.util.Layer var52 = null;
//     java.util.Collection var53 = var47.getDomainMarkers(100, var52);
//     org.jfree.data.xy.XYDataset var54 = null;
//     int var55 = var47.indexOf(var54);
//     org.jfree.chart.axis.AxisLocation var57 = var47.getDomainAxisLocation(1);
//     org.jfree.chart.axis.AxisLocation var58 = var47.getDomainAxisLocation();
//     var37.setRangeAxisLocation(1, var58);
//     org.jfree.chart.LegendItemCollection var60 = var37.getFixedLegendItems();
//     var37.setRangeCrosshairVisible(false);
//     int var63 = var37.getWeight();
//     org.jfree.chart.axis.CategoryAxis var64 = null;
//     org.jfree.chart.axis.NumberTickUnit var66 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     org.jfree.chart.plot.CategoryMarker var68 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)"java.awt.Color[r=255,g=255,b=255]");
//     boolean var69 = var66.equals((java.lang.Object)var68);
//     org.jfree.chart.entity.EntityCollection var70 = null;
//     org.jfree.chart.ChartRenderingInfo var71 = new org.jfree.chart.ChartRenderingInfo(var70);
//     org.jfree.chart.plot.PlotRenderingInfo var72 = var71.getPlotInfo();
//     org.jfree.chart.util.Size2D var75 = new org.jfree.chart.util.Size2D(0.0d, 100.0d);
//     double var76 = var75.getHeight();
//     org.jfree.chart.plot.ValueMarker var80 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var80.setLabel("java.awt.Color[r=255,g=255,b=255]");
//     org.jfree.chart.util.RectangleAnchor var83 = var80.getLabelAnchor();
//     java.awt.geom.Rectangle2D var84 = org.jfree.chart.util.RectangleAnchor.createRectangle(var75, 0.65d, 0.65d, var83);
//     var72.setDataArea(var84);
//     var0.drawDomainMarker(var20, var37, var64, var68, var84);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    double var2 = var1.getOuterSeparatorExtension();
    java.lang.String var3 = var1.getNoDataMessage();
    double var4 = var1.getSectionDepth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);

  }

}
