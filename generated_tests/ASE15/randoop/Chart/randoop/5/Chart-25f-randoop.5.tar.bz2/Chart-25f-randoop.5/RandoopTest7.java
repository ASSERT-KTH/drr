
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getMargin();
    var1.setHeight(0.0d);
    java.awt.Paint var5 = var1.getPaint();
    org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
    var1.setFrame((org.jfree.chart.block.BlockFrame)var6);
    org.jfree.data.general.Dataset var8 = null;
    org.jfree.data.general.DatasetChangeEvent var9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var6, var8);
    org.jfree.data.general.Dataset var10 = var9.getDataset();
    java.lang.Object var11 = var9.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)"org.jfree.chart.event.ChartProgressEvent[source=0.0]");
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    org.jfree.data.Range var3 = var0.getRange();
    java.awt.Shape var4 = var0.getLeftArrow();
    org.jfree.chart.entity.LegendItemEntity var5 = new org.jfree.chart.entity.LegendItemEntity(var4);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.clone(var4);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 1.0d);
    boolean var13 = org.jfree.chart.util.ShapeUtilities.equal(var4, var9);
    java.awt.Font var21 = null;
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getBlue();
    org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25);
    org.jfree.chart.util.HorizontalAlignment var28 = var27.getLineAlignment();
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.text.TextBlockAnchor var32 = null;
    java.awt.Shape var36 = var27.calculateBounds(var29, 10.0f, (-1.0f), var32, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var40 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var36, (java.awt.Paint)var40);
    java.text.AttributedString var42 = var41.getAttributedLabel();
    boolean var43 = var41.isShapeOutlineVisible();
    java.awt.Stroke var44 = var41.getOutlineStroke();
    java.awt.Paint var45 = var41.getOutlinePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var46 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var41.setDataset((org.jfree.data.general.Dataset)var46);
    org.jfree.data.general.DatasetGroup var48 = var46.getGroup();
    org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var46, true);
    org.jfree.chart.axis.NumberTickUnit var52 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    int var53 = var52.getMinorTickCount();
    int var54 = var52.getMinorTickCount();
    java.lang.Number var56 = var46.getStdDevValue((java.lang.Comparable)var54, (java.lang.Comparable)2.0d);
    java.lang.Number var57 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var46);
    org.jfree.chart.axis.NumberTickUnit var60 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    org.jfree.chart.entity.CategoryItemEntity var61 = new org.jfree.chart.entity.CategoryItemEntity(var9, "UnitType.ABSOLUTE", "", (org.jfree.data.category.CategoryDataset)var46, (java.lang.Comparable)2, (java.lang.Comparable)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + Double.NaN+ "'", var57.equals(Double.NaN));

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.entity.TickLabelEntity var4 = new org.jfree.chart.entity.TickLabelEntity(var1, "hi!", "");
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var6 = var4.equals((java.lang.Object)var5);
    boolean var8 = var5.isSeriesVisibleInLegend(255);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    org.jfree.chart.event.AxisChangeEvent var13 = null;
    var10.axisChanged(var13);
    var10.clearAnnotations();
    var9.addChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
    java.awt.Shape var18 = var9.getSeriesShape(1);
    java.awt.Paint var20 = var9.lookupSeriesFillPaint((-1));
    boolean var21 = var9.getIncludeBaseInRange();
    java.awt.Font var22 = var9.getBaseItemLabelFont();
    var9.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var9.getItemLabelGenerator(10, 0);
    java.awt.Stroke var30 = var9.getBaseOutlineStroke();
    boolean var32 = var9.isSeriesVisibleInLegend(0);
    org.jfree.chart.block.LabelBlock var34 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var37 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var38 = var37.darker();
    var34.setPaint((java.awt.Paint)var38);
    var9.setBaseItemLabelPaint((java.awt.Paint)var38, false);
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    var42.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var45 = var42.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var46 = var45.getItemLabelAnchor();
    var9.setNegativeItemLabelPositionFallback(var45);
    var5.setBasePositiveItemLabelPosition(var45);
    org.jfree.chart.labels.CategoryToolTipGenerator var50 = var5.getSeriesToolTipGenerator((-8372160));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.5f, 0.5f, 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesCreateEntities(0);
    int var3 = var0.getColumnCount();
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setSeriesURLGenerator(100, var5);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    float var9 = var8.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var10 = var8.getLabelInsets();
    boolean var11 = var8.isVerticalTickLabels();
    java.awt.Shape var12 = var8.getRightArrow();
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity(var12);
    var0.setSeriesShape(255, var12, false);
    org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var20 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var21 = var20.darker();
    var17.setPaint((java.awt.Paint)var21);
    var0.setBaseOutlinePaint((java.awt.Paint)var21);
    boolean var24 = var0.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    java.text.NumberFormat var3 = var0.getNumberFormatOverride();
    org.jfree.chart.plot.Plot var4 = null;
    var0.setPlot(var4);
    org.jfree.chart.axis.NumberTickUnit var6 = var0.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     java.awt.Paint var5 = var0.getRangeGridlinePaint();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var11 = java.awt.Color.getColor("", 10);
//     var8.setTickMarkPaint((java.awt.Paint)var11);
//     org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var8.setStandardTickUnits(var13);
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var18 = var17.getBounds();
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var8.lengthToJava2D((-1.0d), var18, var19);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     boolean var24 = var0.render(var6, var18, 10, var23);
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var0.setFixedDomainAxisSpace(var25);
//     org.jfree.chart.util.Layer var27 = null;
//     java.util.Collection var28 = var0.getRangeMarkers(var27);
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getPlotArea();
//     java.lang.Object var34 = var32.clone();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var36 = null;
//     var35.setOutlineStroke(var36);
//     org.jfree.chart.event.AxisChangeEvent var38 = null;
//     var35.axisChanged(var38);
//     var35.setRangeGridlinesVisible(false);
//     boolean var42 = var35.isRangeCrosshairVisible();
//     java.awt.Stroke var43 = var35.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var44 = var35.getDataset();
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     float var47 = var46.getTickMarkOutsideLength();
//     var46.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var53 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var54 = var53.getBounds();
//     org.jfree.chart.util.RectangleEdge var55 = null;
//     double var56 = var46.valueToJava2D(100.0d, var54, var55);
//     java.awt.geom.Rectangle2D var57 = null;
//     org.jfree.chart.util.RectangleAnchor var58 = null;
//     java.awt.geom.Point2D var59 = org.jfree.chart.util.RectangleAnchor.coordinates(var57, var58);
//     org.jfree.chart.plot.PlotState var60 = null;
//     org.jfree.chart.ChartRenderingInfo var61 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var62 = new org.jfree.chart.plot.PlotRenderingInfo(var61);
//     var35.draw(var45, var54, var59, var60, var62);
//     var0.zoomRangeAxes(0.5000000099999999d, 2.0d, var32, var59);
//     
//     // Checks the contract:  equals-hashcode on var17 and var53
//     assertTrue("Contract failed: equals-hashcode on var17 and var53", var17.equals(var53) ? var17.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var17
//     assertTrue("Contract failed: equals-hashcode on var53 and var17", var53.equals(var17) ? var53.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var32
//     assertTrue("Contract failed: equals-hashcode on var23 and var32", var23.equals(var32) ? var23.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var62
//     assertTrue("Contract failed: equals-hashcode on var23 and var62", var23.equals(var62) ? var23.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var23
//     assertTrue("Contract failed: equals-hashcode on var32 and var23", var32.equals(var23) ? var32.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var62
//     assertTrue("Contract failed: equals-hashcode on var32 and var62", var32.equals(var62) ? var32.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var23
//     assertTrue("Contract failed: equals-hashcode on var62 and var23", var62.equals(var23) ? var62.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var32
//     assertTrue("Contract failed: equals-hashcode on var62 and var32", var62.equals(var32) ? var62.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    float var2 = var1.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.ValueAxis[] var5 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setRangeAxes(var5);
    org.jfree.chart.util.RectangleInsets var7 = var0.getAxisOffset();
    var0.clearDomainMarkers(100);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    float var11 = var10.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var12 = var10.getLabelInsets();
    java.awt.Color var16 = java.awt.Color.getHSBColor(1.0f, 2.0f, 10.0f);
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var12, (java.awt.Paint)var16);
    var0.setRangeCrosshairPaint((java.awt.Paint)var16);
    org.jfree.chart.event.PlotChangeEvent var19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.Plot var20 = var19.getPlot();
    java.lang.Object var21 = var19.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.data.statistics.MeanAndStandardDeviation var3 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)10, (java.lang.Number)1L);
    java.lang.Number var4 = var3.getMean();
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var7 = null;
    var6.setOutlineStroke(var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var6.axisChanged(var9);
    var6.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var13);
    var6.mapDatasetToRangeAxis(0, 0);
    java.lang.String var18 = var6.getNoDataMessage();
    java.awt.Paint var19 = var6.getNoDataMessagePaint();
    boolean var20 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.block.BlockContainer var21 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var22 = null;
    var0.add((org.jfree.chart.block.Block)var21, var22);
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var25 = var24.clone();
    org.jfree.chart.util.VerticalAlignment var26 = var24.getVerticalAlignment();
    java.lang.Object var27 = var24.clone();
    java.lang.String var28 = var24.getText();
    org.jfree.chart.util.Size2D var29 = new org.jfree.chart.util.Size2D();
    double var30 = var29.getHeight();
    double var31 = var29.getHeight();
    var0.add((org.jfree.chart.block.Block)var24, (java.lang.Object)var29);
    org.jfree.data.Range var34 = null;
    org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(10.0d, var34);
    org.jfree.data.Range var36 = var35.getHeightRange();
    java.lang.String var37 = var35.toString();
    org.jfree.chart.block.RectangleConstraint var39 = var35.toFixedWidth(0.05d);
    org.jfree.chart.block.RectangleConstraint var41 = var39.toFixedWidth((-1.0d));
    boolean var42 = var0.equals((java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10+ "'", var4.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + ""+ "'", var28.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var37.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.plot.Plot var5 = var0.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    java.awt.Font var2 = null;
    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var6 = var5.darker();
    int var7 = var6.getBlue();
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var6);
    org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    java.awt.Shape var17 = var8.calculateBounds(var10, 100.0f, 1.0f, var13, 2.0f, (-1.0f), (-1.0d));
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var21 = null;
    var20.setOutlineStroke(var21);
    org.jfree.chart.event.AxisChangeEvent var23 = null;
    var20.axisChanged(var23);
    var20.clearAnnotations();
    var19.addChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
    java.awt.Shape var28 = var19.getSeriesShape(1);
    java.awt.Paint var30 = var19.lookupSeriesFillPaint((-1));
    boolean var31 = var19.getIncludeBaseInRange();
    java.awt.Font var32 = var19.getBaseItemLabelFont();
    var19.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var39 = var19.getItemLabelGenerator(10, 0);
    java.awt.Stroke var40 = var19.getBaseOutlineStroke();
    boolean var42 = var19.isSeriesVisibleInLegend(0);
    org.jfree.chart.block.LabelBlock var44 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var47 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var48 = var47.darker();
    var44.setPaint((java.awt.Paint)var48);
    var19.setBaseItemLabelPaint((java.awt.Paint)var48, false);
    org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
    var52.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var55 = var52.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var56 = var55.getItemLabelAnchor();
    var19.setNegativeItemLabelPositionFallback(var55);
    org.jfree.chart.text.TextAnchor var58 = var55.getTextAnchor();
    java.lang.String var59 = var58.toString();
    org.jfree.chart.axis.CategoryTick var61 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=1.0E-8, height=2.0]", var8, var18, var58, 4.0d);
    org.jfree.chart.text.TextAnchor var62 = var61.getRotationAnchor();
    org.jfree.chart.text.TextBlock var63 = var61.getLabel();
    org.jfree.chart.text.TextLine var64 = null;
    var63.addLine(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "TextAnchor.BOTTOM_CENTER"+ "'", var59.equals("TextAnchor.BOTTOM_CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.util.VerticalAlignment var3 = var1.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement(var0, var3, (-2.0d), 0.0d);
    java.awt.Font var12 = null;
    java.awt.Color var15 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var16 = var15.darker();
    int var17 = var16.getBlue();
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var16);
    org.jfree.chart.util.HorizontalAlignment var19 = var18.getLineAlignment();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.text.TextBlockAnchor var23 = null;
    java.awt.Shape var27 = var18.calculateBounds(var20, 10.0f, (-1.0f), var23, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var31 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var27, (java.awt.Paint)var31);
    java.text.AttributedString var33 = var32.getAttributedLabel();
    boolean var34 = var32.isShapeOutlineVisible();
    java.awt.Stroke var35 = var32.getOutlineStroke();
    java.awt.Paint var36 = var32.getOutlinePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var32.setDataset((org.jfree.data.general.Dataset)var37);
    org.jfree.data.general.DatasetGroup var39 = var37.getGroup();
    org.jfree.chart.axis.NumberTickUnit var44 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    int var45 = var44.getMinorTickCount();
    int var46 = var44.getMinorTickCount();
    var37.add(1.00000001E-8d, 4.99999995E-9d, (java.lang.Comparable)10.0f, (java.lang.Comparable)var46);
    int var48 = var37.getColumnCount();
    java.awt.Color var51 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var52 = var51.darker();
    int var53 = var52.getBlue();
    org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var52);
    org.jfree.chart.util.RectangleInsets var55 = var54.getInsets();
    boolean var56 = var37.equals((java.lang.Object)var55);
    org.jfree.chart.axis.TickUnits var57 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var59 = null;
    var58.setOutlineStroke(var59);
    org.jfree.chart.event.AxisChangeEvent var61 = null;
    var58.axisChanged(var61);
    var58.clearAnnotations();
    var58.configureDomainAxes();
    var58.setRangeCrosshairVisible(false);
    boolean var67 = var57.equals((java.lang.Object)var58);
    org.jfree.chart.axis.NumberTickUnit var69 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    int var70 = var69.getMinorTickCount();
    int var71 = var69.getMinorTickCount();
    var57.add((org.jfree.chart.axis.TickUnit)var69);
    int var73 = var57.size();
    org.jfree.chart.axis.TickUnit var75 = var57.get(0);
    org.jfree.chart.title.LegendItemBlockContainer var76 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, (org.jfree.data.general.Dataset)var37, (java.lang.Comparable)var75);
    org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis();
    float var78 = var77.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var79 = var77.getLabelInsets();
    var77.setAutoRangeMinimumSize(10.0d);
    boolean var82 = var6.equals((java.lang.Object)var77);
    var6.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    double var13 = var0.getUpperClip();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setBaseItemLabelGenerator(var14, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var0.getLegendItemURLGenerator();
    java.awt.Shape var19 = var0.lookupSeriesShape((-1));
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    int var24 = var23.getBlue();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var23);
    java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var29 = var28.darker();
    int var30 = var29.getBlue();
    float[] var34 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var35 = var29.getColorComponents(var34);
    float[] var36 = var23.getColorComponents(var35);
    org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic(var19, (java.awt.Paint)var23);
    org.jfree.chart.util.GradientPaintTransformer var38 = var37.getFillPaintTransformer();
    boolean var39 = var37.isShapeOutlineVisible();
    var37.setLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.awt.Paint var2 = var0.getBaseFillPaint();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    var3.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var8 = var3.getNegativeItemLabelPosition(1, 0);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var10 = null;
    var9.setOutlineStroke(var10);
    org.jfree.chart.event.AxisChangeEvent var12 = null;
    var9.axisChanged(var12);
    var9.setRangeGridlinesVisible(false);
    boolean var16 = var9.isRangeCrosshairVisible();
    java.awt.Font var22 = null;
    java.awt.Color var25 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var26 = var25.darker();
    int var27 = var26.getBlue();
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, (java.awt.Paint)var26);
    org.jfree.chart.util.HorizontalAlignment var29 = var28.getLineAlignment();
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.text.TextBlockAnchor var33 = null;
    java.awt.Shape var37 = var28.calculateBounds(var30, 10.0f, (-1.0f), var33, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var41 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var37, (java.awt.Paint)var41);
    var9.setRangeCrosshairPaint((java.awt.Paint)var41);
    var3.setBasePaint((java.awt.Paint)var41);
    var0.setBasePaint((java.awt.Paint)var41);
    org.jfree.chart.util.GradientPaintTransformer var46 = var0.getGradientPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.setRangeGridlinesVisible(false);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.awt.Stroke var9 = var1.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    float var13 = var12.getTickMarkOutsideLength();
    var12.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var20 = var19.getBounds();
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var12.valueToJava2D(100.0d, var20, var21);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
    org.jfree.chart.plot.PlotState var26 = null;
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    var1.draw(var11, var20, var25, var26, var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var32 = var31.getHorizontalAlignment();
    var30.setTitle(var31);
    double var34 = var31.getHeight();
    java.awt.Font var36 = null;
    java.awt.Color var39 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var40 = var39.darker();
    int var41 = var40.getBlue();
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var40);
    org.jfree.chart.util.HorizontalAlignment var43 = var42.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var44 = null;
    org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 1.0E-8d, (-1.0d));
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var49 = var48.getBaseStroke();
    org.jfree.chart.urls.CategoryURLGenerator var50 = var48.getBaseURLGenerator();
    boolean var51 = var43.equals((java.lang.Object)var48);
    var31.setTextAlignment(var43);
    java.lang.String var53 = var43.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var53.equals("HorizontalAlignment.CENTER"));

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    java.text.AttributedString var26 = var25.getAttributedLabel();
    boolean var27 = var25.isShapeOutlineVisible();
    java.lang.String var28 = var25.getURLText();
    boolean var29 = var25.isShapeOutlineVisible();
    java.awt.Paint var30 = var25.getLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var28.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var3 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var4 = var3.darker();
    var0.setLabelPaint((java.awt.Paint)var3);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    float var7 = var6.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var8 = var6.getLabelInsets();
    double var10 = var8.extendHeight(100.0d);
    var0.setTickLabelInsets(var8);
    var0.setTickMarksVisible(false);
    boolean var14 = var0.isVerticalTickLabels();
    boolean var15 = var0.isVisible();
    var0.setAutoTickUnitSelection(false, false);
    boolean var19 = var0.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var3 = var1.getSeriesCreateEntities(0);
    int var4 = var1.getColumnCount();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var1.setSeriesURLGenerator(100, var6);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    float var10 = var9.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var11 = var9.getLabelInsets();
    boolean var12 = var9.isVerticalTickLabels();
    java.awt.Shape var13 = var9.getRightArrow();
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity(var13);
    var1.setSeriesShape(255, var13, false);
    org.jfree.data.KeyedObject var17 = new org.jfree.data.KeyedObject((java.lang.Comparable)(-237), (java.lang.Object)var1);
    int var18 = var1.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    var1.setPaint((java.awt.Paint)var5);
    java.lang.String var7 = var1.getToolTipText();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var9 = var8.clone();
    boolean var10 = var1.equals((java.lang.Object)var8);
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.util.RectangleAnchor var13 = var12.getLabelAnchor();
    boolean var14 = var1.equals((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var4 = var3.getItemLabelAnchor();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var7 = var4.equals((java.lang.Object)(-1.0f));
    java.lang.Object var8 = null;
    boolean var9 = var4.equals(var8);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var12 = null;
    var11.setOutlineStroke(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var11.axisChanged(var14);
    var11.setRangeGridlinesVisible(false);
    boolean var18 = var11.isRangeCrosshairVisible();
    java.awt.Stroke var19 = var11.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var20 = var11.getDataset();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    float var23 = var22.getTickMarkOutsideLength();
    var22.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var30 = var29.getBounds();
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var22.valueToJava2D(100.0d, var30, var31);
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleAnchor var34 = null;
    java.awt.geom.Point2D var35 = org.jfree.chart.util.RectangleAnchor.coordinates(var33, var34);
    org.jfree.chart.plot.PlotState var36 = null;
    org.jfree.chart.ChartRenderingInfo var37 = null;
    org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
    var11.draw(var21, var30, var35, var36, var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var11);
    org.jfree.chart.plot.CategoryPlot var41 = var40.getCategoryPlot();
    org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var43 = var42.clone();
    org.jfree.chart.util.VerticalAlignment var44 = var42.getVerticalAlignment();
    var40.removeSubtitle((org.jfree.chart.title.Title)var42);
    java.awt.Image var46 = var40.getBackgroundImage();
    boolean var47 = var4.equals((java.lang.Object)var40);
    org.jfree.chart.title.LegendTitle var48 = var40.getLegend();
    org.jfree.chart.util.RectangleInsets var49 = var48.getItemLabelPadding();
    org.jfree.chart.util.RectangleEdge var50 = var48.getLegendItemGraphicEdge();
    java.lang.String var51 = var50.toString();
    boolean var52 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "RectangleEdge.LEFT"+ "'", var51.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Paint var5 = var0.getRangeGridlinePaint();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var11 = java.awt.Color.getColor("", 10);
    var8.setTickMarkPaint((java.awt.Paint)var11);
    org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var8.setStandardTickUnits(var13);
    org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var18 = var17.getBounds();
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var8.lengthToJava2D((-1.0d), var18, var19);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
    boolean var24 = var0.render(var6, var18, 10, var23);
    java.awt.geom.Rectangle2D var25 = var23.getDataArea();
    java.awt.geom.Rectangle2D var26 = var23.getDataArea();
    org.jfree.chart.renderer.category.CategoryItemRendererState var27 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var23);
    double var28 = var27.getBarWidth();
    var27.setBarWidth((-1.0d));
    double var31 = var27.getSeriesRunningTotal();
    double var32 = var27.getSeriesRunningTotal();
    double var33 = var27.getSeriesRunningTotal();
    double var34 = var27.getBarWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1.0d));

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    double var13 = var0.getUpperClip();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setBaseItemLabelGenerator(var14, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var0.getLegendItemURLGenerator();
    java.awt.Shape var19 = var0.lookupSeriesShape((-1));
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    int var24 = var23.getBlue();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var23);
    java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var29 = var28.darker();
    int var30 = var29.getBlue();
    float[] var34 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var35 = var29.getColorComponents(var34);
    float[] var36 = var23.getColorComponents(var35);
    org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic(var19, (java.awt.Paint)var23);
    org.jfree.chart.axis.CategoryLabelPosition var38 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var39 = var38.getCategoryAnchor();
    var37.setShapeAnchor(var39);
    org.jfree.chart.axis.CategoryLabelPosition var41 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var42 = var41.getCategoryAnchor();
    var37.setShapeLocation(var42);
    java.awt.Shape var44 = var37.getShape();
    boolean var45 = var37.isShapeOutlineVisible();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var47 = null;
    var46.setErrorIndicatorPaint(var47);
    java.lang.Object var49 = null;
    boolean var50 = var46.equals(var49);
    boolean var51 = var46.getIncludeBaseInRange();
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = var46.getToolTipGenerator((-16777209), 0);
    boolean var57 = var46.isItemLabelVisible((-855310), 10);
    boolean var58 = var37.equals((java.lang.Object)var57);
    org.jfree.chart.axis.CategoryLabelPosition var59 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var60 = var59.getCategoryAnchor();
    java.awt.Font var63 = null;
    java.awt.Color var66 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var67 = var66.darker();
    int var68 = var67.getBlue();
    org.jfree.chart.text.TextBlock var69 = org.jfree.chart.text.TextUtilities.createTextBlock("", var63, (java.awt.Paint)var67);
    org.jfree.chart.util.HorizontalAlignment var70 = var69.getLineAlignment();
    java.awt.Graphics2D var71 = null;
    org.jfree.chart.text.TextBlockAnchor var74 = null;
    java.awt.Shape var78 = var69.calculateBounds(var71, 10.0f, (-1.0f), var74, (-1.0f), 1.0f, 1.0d);
    org.jfree.chart.text.TextLine var79 = null;
    var69.addLine(var79);
    org.jfree.chart.axis.CategoryLabelPosition var81 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var82 = var81.getCategoryAnchor();
    org.jfree.chart.text.TextBlockAnchor var83 = var81.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var84 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextAnchor var85 = var84.getRotationAnchor();
    org.jfree.chart.axis.CategoryTick var87 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var69, var83, var85, 0.0d);
    java.lang.Object var88 = null;
    boolean var89 = var83.equals(var88);
    org.jfree.chart.axis.CategoryLabelPosition var90 = new org.jfree.chart.axis.CategoryLabelPosition(var60, var83);
    var37.setShapeAnchor(var60);
    java.awt.Stroke var92 = var37.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var92);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    java.text.AttributedString var26 = var25.getAttributedLabel();
    boolean var27 = var25.isShapeOutlineVisible();
    java.lang.String var28 = var25.getURLText();
    var25.setDatasetIndex((-1));
    java.text.AttributedString var31 = var25.getAttributedLabel();
    java.awt.Shape var32 = var25.getShape();
    java.awt.Font var40 = null;
    java.awt.Color var43 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var44 = var43.darker();
    int var45 = var44.getBlue();
    org.jfree.chart.text.TextBlock var46 = org.jfree.chart.text.TextUtilities.createTextBlock("", var40, (java.awt.Paint)var44);
    org.jfree.chart.util.HorizontalAlignment var47 = var46.getLineAlignment();
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.text.TextBlockAnchor var51 = null;
    java.awt.Shape var55 = var46.calculateBounds(var48, 10.0f, (-1.0f), var51, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var59 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var55, (java.awt.Paint)var59);
    java.text.AttributedString var61 = var60.getAttributedLabel();
    boolean var62 = var60.isShapeOutlineVisible();
    java.awt.Stroke var63 = var60.getOutlineStroke();
    java.awt.Paint var64 = var60.getOutlinePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var65 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var60.setDataset((org.jfree.data.general.Dataset)var65);
    org.jfree.data.general.DatasetGroup var67 = var65.getGroup();
    org.jfree.data.Range var69 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var65, true);
    org.jfree.data.Range var70 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var65);
    org.jfree.data.Range var71 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var65);
    org.jfree.chart.entity.CategoryItemEntity var74 = new org.jfree.chart.entity.CategoryItemEntity(var32, "java.awt.Color[r=0,g=0,b=1]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (org.jfree.data.category.CategoryDataset)var65, (java.lang.Comparable)(-1.0f), (java.lang.Comparable)0.5d);
    org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis();
    float var76 = var75.getTickMarkOutsideLength();
    var75.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var82 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var83 = var82.getBounds();
    org.jfree.chart.util.RectangleEdge var84 = null;
    double var85 = var75.valueToJava2D(100.0d, var83, var84);
    var75.setAutoRangeMinimumSize(100.0d, false);
    boolean var89 = var74.equals((java.lang.Object)100.0d);
    java.lang.String var90 = var74.toString();
    var74.setRowKey((java.lang.Comparable)0.8f);
    java.lang.Comparable var93 = var74.getColumnKey();
    java.awt.Shape var94 = var74.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var28.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var93 + "' != '" + 0.5d+ "'", var93.equals(0.5d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setBaseItemLabelsVisible(false);
    java.lang.Object var3 = null;
    boolean var4 = var0.equals(var3);
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(1.0d);
    float var7 = var6.getAlpha();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var12 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var13 = var12.darker();
    var9.setLabelPaint((java.awt.Paint)var12);
    float[] var18 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var19 = var12.getColorComponents(var18);
    java.awt.Color var20 = java.awt.Color.getColor("", var12);
    var6.setPaint((java.awt.Paint)var20);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    float var27 = var26.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
    boolean var29 = var26.isVerticalTickLabels();
    java.awt.Shape var30 = var26.getRightArrow();
    org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity(var30);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    float var36 = var35.getTickMarkOutsideLength();
    var35.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.axis.AxisState var41 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.util.RectangleEdge var43 = null;
    java.util.List var44 = var35.refreshTicks(var40, var41, var42, var43);
    var41.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
    float var48 = var47.getTickMarkOutsideLength();
    var47.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var55 = var54.getBounds();
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var47.valueToJava2D(100.0d, var55, var56);
    org.jfree.chart.util.RectangleEdge var58 = null;
    java.util.List var59 = var33.refreshTicks(var34, var41, var55, var58);
    java.awt.Shape var60 = var33.getLeftArrow();
    boolean var61 = var31.equals((java.lang.Object)var60);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
    var62.setTickMarksVisible(false);
    java.awt.Stroke var65 = var62.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var69 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var70 = var69.darker();
    var66.setLabelPaint((java.awt.Paint)var69);
    float[] var75 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var76 = var69.getColorComponents(var75);
    org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var60, var65, (java.awt.Paint)var69);
    var6.setOutlineStroke(var65);
    var0.setErrorIndicatorStroke(var65);
    java.awt.Paint var81 = var0.lookupSeriesFillPaint((-16777215));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

}
