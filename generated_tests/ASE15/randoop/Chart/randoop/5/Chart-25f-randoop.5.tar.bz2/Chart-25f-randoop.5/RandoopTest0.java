
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 10.0d, "hi!", var3, var4, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    float[] var5 = new float[] { 0.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var2.getColorComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var3 = null;
//     org.jfree.chart.util.Size2D var4 = var0.arrange(var1, var2, var3);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var3 = null;
//     float[] var4 = new float[] { };
//     float[] var5 = var2.getColorComponents(var3, var4);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 1.0f, 100.0f, var4, 100.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100L};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { (byte)(-1)};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getColumnKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var2, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(short)0, (java.lang.Comparable)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 10.0d);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeWidth(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    int var1 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("hi!", var1, var2, var3);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    java.lang.String var2 = var1.toString();
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var1.createOutsetRectangle(var3, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, (-1.0f), 100.0f, var4, 1.0E-8d, var6);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     float var1 = var0.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
//     double var3 = var0.getAutoRangeMinimumSize();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     org.jfree.chart.axis.AxisState var11 = var0.draw(var4, 0.0d, var6, var7, var8, var10);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     float var1 = var0.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
//     java.text.NumberFormat var3 = var0.getNumberFormatOverride();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     org.jfree.chart.axis.AxisState var11 = var0.draw(var4, 0.0d, var6, var7, var8, var10);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.axis.Axis var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.AxisChangeEvent var1 = new org.jfree.chart.event.AxisChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 2.0f, (-1.0f), 1.0d, 2.0f, 1.0f);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)0.0f);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(short)0, (java.lang.Comparable)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getColumnKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var28 = var27.darker();
    var24.setPaint((java.awt.Paint)var28);
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var35 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var36 = var35.darker();
    var32.setLabelPaint((java.awt.Paint)var35);
    float[] var41 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var42 = var35.getColorComponents(var41);
    java.awt.Color var43 = java.awt.Color.getColor("", var35);
    java.awt.Stroke var44 = null;
    java.awt.Font var47 = null;
    java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var51 = var50.darker();
    int var52 = var51.getBlue();
    org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("", var47, (java.awt.Paint)var51);
    org.jfree.chart.util.HorizontalAlignment var54 = var53.getLineAlignment();
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.text.TextBlockAnchor var58 = null;
    java.awt.Shape var62 = var53.calculateBounds(var55, 10.0f, (-1.0f), var58, (-1.0f), 1.0f, 1.0d);
    java.awt.Stroke var63 = null;
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var67 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var68 = var67.darker();
    var64.setLabelPaint((java.awt.Paint)var67);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!", true, var21, false, (java.awt.Paint)var28, false, (java.awt.Paint)var35, var44, false, var62, var63, (java.awt.Paint)var67);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, var2);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    var0.clear();

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var1, var2);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.Range var4 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(10.0d, var4);
//     org.jfree.data.Range var6 = var5.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var8 = var5.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var9 = var1.arrange(var2, var8);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.block.BlockContainer var1 = null;
    java.awt.Graphics2D var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(10.0d, var4);
    org.jfree.data.Range var6 = var5.getHeightRange();
    java.lang.String var7 = var5.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var0.arrange(var1, var2, var5);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var7.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.plot.DatasetRenderingOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    java.awt.Paint var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    float var3 = var2.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    org.jfree.chart.event.AxisChangeEvent var8 = null;
    var5.axisChanged(var8);
    var5.setRangeGridlinesVisible(false);
    boolean var12 = var5.isRangeCrosshairVisible();
    java.awt.Stroke var13 = var5.getDomainGridlineStroke();
    var2.setAxisLineStroke(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(0.05d, var1, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var7 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var9 = null;
//     var8.setOutlineStroke(var9);
//     org.jfree.chart.event.AxisChangeEvent var11 = null;
//     var8.axisChanged(var11);
//     var8.setRangeGridlinesVisible(false);
//     boolean var15 = var8.isRangeCrosshairVisible();
//     java.awt.Stroke var16 = var8.getDomainGridlineStroke();
//     var0.setRangeGridlineStroke(var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, var1);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var6 = var5.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), (java.awt.Paint)var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    float[] var3 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = java.awt.Color.RGBtoHSB(0, (-1), 100, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var5 = var4.darker();
//     int var6 = var5.getBlue();
//     org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     float var19 = var18.getTickMarkOutsideLength();
//     var18.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.AxisState var24 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     java.util.List var27 = var18.refreshTicks(var23, var24, var25, var26);
//     var24.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     float var31 = var30.getTickMarkOutsideLength();
//     var30.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var37 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var38 = var37.getBounds();
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var30.valueToJava2D(100.0d, var38, var39);
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     java.util.List var42 = var16.refreshTicks(var17, var24, var38, var41);
//     var13.draw(var14, var38);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var2 = var1.getMargin();
//     var1.setHeight(0.0d);
//     java.awt.Paint var5 = var1.getPaint();
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var8 = var7.getBounds();
//     var1.setBounds(var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainAxes();

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var2 = var1.getBounds();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var1.arrange(var3);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    var1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
    org.jfree.chart.plot.CategoryMarker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var5 = null;
//     var4.setOutlineStroke(var5);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var4.axisChanged(var7);
//     var4.setRangeGridlinesVisible(false);
//     boolean var11 = var4.isRangeCrosshairVisible();
//     java.awt.Stroke var12 = var4.getDomainGridlineStroke();
//     org.jfree.chart.axis.CategoryAxis var14 = var4.getDomainAxisForDataset(100);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var16 = var15.getBaseStroke();
//     var4.setDomainGridlineStroke(var16);
//     var0.setSeriesStroke(1, var16);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var0.", var15.equals(var0) == var0.equals(var15));
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var6 = null;
//     var5.setOutlineStroke(var6);
//     org.jfree.chart.event.AxisChangeEvent var8 = null;
//     var5.axisChanged(var8);
//     var5.clearAnnotations();
//     var4.addChangeListener((org.jfree.chart.event.RendererChangeListener)var5);
//     java.awt.Shape var13 = var4.getSeriesShape(1);
//     java.awt.Paint var15 = var4.lookupSeriesFillPaint((-1));
//     boolean var16 = var4.getIncludeBaseInRange();
//     java.awt.Font var17 = var4.getBaseItemLabelFont();
//     var0.setSeriesItemLabelFont(10, var17);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var0.", var4.equals(var0) == var0.equals(var4));
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.clearAnnotations();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePosition(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var4, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     java.util.ResourceBundle.Control var4 = null;
//     java.util.ResourceBundle var5 = java.util.ResourceBundle.getBundle("", var1, var3, var4);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var5 = var4.darker();
//     int var6 = var5.getBlue();
//     org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var12);
//     java.awt.Font var15 = null;
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var19 = var18.darker();
//     int var20 = var19.getBlue();
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, (java.awt.Paint)var19);
//     org.jfree.chart.util.HorizontalAlignment var22 = var21.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 1.0E-8d, (-1.0d));
//     var13.setArrangement((org.jfree.chart.block.Arrangement)var26);
//     
//     // Checks the contract:  equals-hashcode on var12 and var26
//     assertTrue("Contract failed: equals-hashcode on var12 and var26", var12.equals(var26) ? var12.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var12
//     assertTrue("Contract failed: equals-hashcode on var26 and var12", var26.equals(var12) ? var26.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var1, 2.0f, 1.0f, 106.0d, 0.0f, 1.0f);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var3 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var4 = var3.darker();
    var0.setLabelPaint((java.awt.Paint)var3);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    float var7 = var6.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var8 = var6.getLabelInsets();
    double var10 = var8.extendHeight(100.0d);
    var0.setTickLabelInsets(var8);
    double var12 = var8.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.0d);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    float var4 = var3.getTickMarkOutsideLength();
    var3.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    java.util.List var12 = var3.refreshTicks(var8, var9, var10, var11);
    var9.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    float var16 = var15.getTickMarkOutsideLength();
    var15.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var15.valueToJava2D(100.0d, var23, var24);
    org.jfree.chart.util.RectangleEdge var26 = null;
    java.util.List var27 = var1.refreshTicks(var2, var9, var23, var26);
    java.awt.Shape var28 = var1.getLeftArrow();
    org.jfree.data.category.CategoryDataset var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var34 = new org.jfree.chart.entity.CategoryItemEntity(var28, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var31, (java.lang.Comparable)0.0d, (java.lang.Comparable)"hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var4 = java.awt.Color.getColor("", 10);
//     var1.setTickMarkPaint((java.awt.Paint)var4);
//     org.jfree.chart.axis.TickUnitSource var6 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var1.setStandardTickUnits(var6);
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var11 = var10.getBounds();
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var1.lengthToJava2D((-1.0d), var11, var12);
//     org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var16 = var15.getBounds();
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.intersects(var11, var16);
//     
//     // Checks the contract:  equals-hashcode on var10 and var15
//     assertTrue("Contract failed: equals-hashcode on var10 and var15", var10.equals(var15) ? var10.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var10
//     assertTrue("Contract failed: equals-hashcode on var15 and var10", var15.equals(var10) ? var15.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var5 = var4.darker();
//     int var6 = var5.getBlue();
//     org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var12);
//     java.awt.Font var15 = null;
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var19 = var18.darker();
//     int var20 = var19.getBlue();
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, (java.awt.Paint)var19);
//     org.jfree.chart.util.HorizontalAlignment var22 = var21.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 1.0E-8d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.data.Range var29 = null;
//     org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(var29, 10.0d);
//     double var32 = var31.getHeight();
//     org.jfree.chart.util.Size2D var33 = var12.arrange(var27, var28, var31);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(106.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     int var3 = var2.getMinorTickCount();
//     org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)var3);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var9 = var0.getDataset();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    float var12 = var11.getTickMarkOutsideLength();
    var11.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var19 = var18.getBounds();
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var11.valueToJava2D(100.0d, var19, var20);
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleAnchor var23 = null;
    java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
    org.jfree.chart.plot.PlotState var25 = null;
    org.jfree.chart.ChartRenderingInfo var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
    var0.draw(var10, var19, var24, var25, var27);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), var30, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    double var4 = var0.getLowerMargin();
    var0.setTickMarkInsideLength(1.0f);
    var0.setRangeAboutValue(10.0d, 10.0d);
    org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    double var12 = var11.getSize();
    var0.setTickUnit(var11, false, false);
    var0.setLabelAngle(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.0d));

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var9 = null;
//     var8.setOutlineStroke(var9);
//     org.jfree.chart.event.AxisChangeEvent var11 = null;
//     var8.axisChanged(var11);
//     var8.clearAnnotations();
//     java.awt.Paint var14 = var8.getNoDataMessagePaint();
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var18 = null;
//     var17.setOutlineStroke(var18);
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var17.axisChanged(var20);
//     var17.clearAnnotations();
//     var16.addChangeListener((org.jfree.chart.event.RendererChangeListener)var17);
//     java.awt.Shape var25 = var16.getSeriesShape(1);
//     java.awt.Paint var27 = var16.lookupSeriesFillPaint((-1));
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var29 = null;
//     var28.setOutlineStroke(var29);
//     org.jfree.chart.event.AxisChangeEvent var31 = null;
//     var28.axisChanged(var31);
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var28.addChangeListener(var33);
//     org.jfree.chart.axis.ValueAxis var36 = var28.getRangeAxis((-1));
//     java.awt.Stroke var37 = var28.getRangeCrosshairStroke();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     float var40 = var39.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var41 = var39.getLabelInsets();
//     boolean var42 = var39.isVerticalTickLabels();
//     java.awt.Shape var43 = var39.getRightArrow();
//     org.jfree.chart.block.LabelBlock var45 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var46 = var45.getMargin();
//     var45.setHeight(0.0d);
//     java.awt.Paint var49 = var45.getPaint();
//     org.jfree.chart.block.LineBorder var50 = new org.jfree.chart.block.LineBorder();
//     var45.setFrame((org.jfree.chart.block.BlockFrame)var50);
//     java.awt.Stroke var52 = var50.getStroke();
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var54 = null;
//     var53.setOutlineStroke(var54);
//     org.jfree.chart.event.AxisChangeEvent var56 = null;
//     var53.axisChanged(var56);
//     java.awt.Paint var58 = var53.getRangeGridlinePaint();
//     org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("", "", "", "hi!", false, var6, false, var14, false, var27, var37, false, var43, var52, var58);
//     
//     // Checks the contract:  equals-hashcode on var8 and var17
//     assertTrue("Contract failed: equals-hashcode on var8 and var17", var8.equals(var17) ? var8.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var53
//     assertTrue("Contract failed: equals-hashcode on var8 and var53", var8.equals(var53) ? var8.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var8
//     assertTrue("Contract failed: equals-hashcode on var17 and var8", var17.equals(var8) ? var17.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var28
//     assertTrue("Contract failed: equals-hashcode on var17 and var28", var17.equals(var28) ? var17.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var53
//     assertTrue("Contract failed: equals-hashcode on var17 and var53", var17.equals(var53) ? var17.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var17
//     assertTrue("Contract failed: equals-hashcode on var28 and var17", var28.equals(var17) ? var28.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var53
//     assertTrue("Contract failed: equals-hashcode on var28 and var53", var28.equals(var53) ? var28.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var8
//     assertTrue("Contract failed: equals-hashcode on var53 and var8", var53.equals(var8) ? var53.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var17
//     assertTrue("Contract failed: equals-hashcode on var53 and var17", var53.equals(var17) ? var53.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var28
//     assertTrue("Contract failed: equals-hashcode on var53 and var28", var53.equals(var28) ? var53.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
//     boolean var12 = var0.getIncludeBaseInRange();
//     java.awt.Font var13 = var0.getBaseItemLabelFont();
//     var0.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var20 = null;
//     var19.setOutlineStroke(var20);
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var19.axisChanged(var22);
//     var19.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var26);
//     org.jfree.chart.axis.AxisLocation var29 = null;
//     var19.setDomainAxisLocation(1, var29);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     float var32 = var31.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getLabelInsets();
//     boolean var34 = var31.isVerticalTickLabels();
//     boolean var35 = var31.isNegativeArrowVisible();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     float var39 = var38.getTickMarkOutsideLength();
//     var38.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var45 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var46 = var45.getBounds();
//     org.jfree.chart.util.RectangleEdge var47 = null;
//     double var48 = var38.valueToJava2D(100.0d, var46, var47);
//     var0.drawRangeMarker(var18, var19, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.plot.Marker)var37, var46);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis var7 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    var0.setAutoTickUnitSelection(false, false);
    var0.setFixedDimension(106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    var11.setAutoPopulateSeriesOutlinePaint(false);
    var11.setBaseSeriesVisible(true, false);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.annotations.CategoryAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    java.text.AttributedString var0 = null;
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 100.0f, 1.0f, var17, 2.0f, (-1.0f), (-1.0d));
    org.jfree.chart.ChartColor var26 = new org.jfree.chart.ChartColor(0, 0, 100);
    java.awt.Color var27 = var26.brighter();
    org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var31 = var30.getMargin();
    var30.setHeight(0.0d);
    java.awt.Paint var34 = var30.getPaint();
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var37 = var36.getMargin();
    var36.setHeight(0.0d);
    java.awt.Paint var40 = var36.getPaint();
    org.jfree.chart.block.LineBorder var41 = new org.jfree.chart.block.LineBorder();
    var36.setFrame((org.jfree.chart.block.BlockFrame)var41);
    java.awt.Stroke var43 = var41.getStroke();
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.clone(var46);
    java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var47, 0.0d, 1.0d);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var52 = null;
    var51.setOutlineStroke(var52);
    org.jfree.chart.event.AxisChangeEvent var54 = null;
    var51.axisChanged(var54);
    var51.setRangeGridlinesVisible(false);
    boolean var58 = var51.isRangeCrosshairVisible();
    java.awt.Stroke var59 = var51.getDomainGridlineStroke();
    org.jfree.chart.event.ChartChangeEvent var60 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var59);
    org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis();
    float var62 = var61.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var63 = var61.getLabelInsets();
    org.jfree.data.Range var64 = var61.getRange();
    org.jfree.data.Range var65 = var61.getDefaultAutoRange();
    java.awt.Color var68 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var69 = var68.darker();
    int var70 = var69.getBlue();
    float[] var74 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var75 = var69.getColorComponents(var74);
    var61.setTickMarkPaint((java.awt.Paint)var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", true, var21, true, (java.awt.Paint)var26, false, var34, var43, false, var50, var59, (java.awt.Paint)var69);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    boolean var10 = var0.getAutoPopulateSeriesStroke();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var15 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var16 = var15.darker();
    var12.setLabelPaint((java.awt.Paint)var15);
    float[] var21 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var22 = var15.getColorComponents(var21);
    java.awt.color.ColorSpace var23 = var15.getColorSpace();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-1), (java.awt.Paint)var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 3.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.arrange(var2);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
//     var0.mapDatasetToRangeAxis(0, 0);
//     java.lang.String var12 = var0.getNoDataMessage();
//     java.awt.Paint var13 = var0.getNoDataMessagePaint();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var16 = null;
//     var15.setOutlineStroke(var16);
//     org.jfree.chart.event.AxisChangeEvent var18 = null;
//     var15.axisChanged(var18);
//     java.awt.Paint var20 = var15.getRangeGridlinePaint();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var26 = java.awt.Color.getColor("", 10);
//     var23.setTickMarkPaint((java.awt.Paint)var26);
//     org.jfree.chart.axis.TickUnitSource var28 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var23.setStandardTickUnits(var28);
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var33 = var32.getBounds();
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var23.lengthToJava2D((-1.0d), var33, var34);
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
//     boolean var39 = var15.render(var21, var33, 10, var38);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var42 = null;
//     var41.setOutlineStroke(var42);
//     org.jfree.chart.event.AxisChangeEvent var44 = null;
//     var41.axisChanged(var44);
//     java.awt.Paint var46 = var41.getRangeGridlinePaint();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var52 = java.awt.Color.getColor("", 10);
//     var49.setTickMarkPaint((java.awt.Paint)var52);
//     org.jfree.chart.axis.TickUnitSource var54 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var49.setStandardTickUnits(var54);
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var59 = var58.getBounds();
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var49.lengthToJava2D((-1.0d), var59, var60);
//     org.jfree.chart.ChartRenderingInfo var63 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var64 = new org.jfree.chart.plot.PlotRenderingInfo(var63);
//     boolean var65 = var41.render(var47, var59, 10, var64);
//     boolean var66 = var0.render(var14, var33, 1, var64);
//     
//     // Checks the contract:  equals-hashcode on var15 and var41
//     assertTrue("Contract failed: equals-hashcode on var15 and var41", var15.equals(var41) ? var15.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var15
//     assertTrue("Contract failed: equals-hashcode on var41 and var15", var41.equals(var15) ? var41.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var54
//     assertTrue("Contract failed: equals-hashcode on var28 and var54", var28.equals(var54) ? var28.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var28
//     assertTrue("Contract failed: equals-hashcode on var54 and var28", var54.equals(var28) ? var54.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var58
//     assertTrue("Contract failed: equals-hashcode on var32 and var58", var32.equals(var58) ? var32.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var32
//     assertTrue("Contract failed: equals-hashcode on var58 and var32", var58.equals(var32) ? var58.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var64
//     assertTrue("Contract failed: equals-hashcode on var38 and var64", var38.equals(var64) ? var38.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var38
//     assertTrue("Contract failed: equals-hashcode on var64 and var38", var64.equals(var38) ? var64.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var10 = null;
//     var9.setOutlineStroke(var10);
//     org.jfree.chart.event.AxisChangeEvent var12 = null;
//     var9.axisChanged(var12);
//     var9.setRangeGridlinesVisible(false);
//     boolean var16 = var9.isRangeCrosshairVisible();
//     java.awt.Stroke var17 = var9.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var19 = var9.getDomainAxisEdge(100);
//     org.jfree.chart.LegendItemCollection var20 = var9.getLegendItems();
//     var0.setFixedLegendItems(var20);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.text.TextAnchor var4 = var3.getLabelTextAnchor();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.text.TextAnchor var7 = var6.getLabelTextAnchor();
//     org.jfree.chart.axis.NumberTick var9 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100L, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var4, var7, 106.0d);
//     
//     // Checks the contract:  equals-hashcode on var3 and var6
//     assertTrue("Contract failed: equals-hashcode on var3 and var6", var3.equals(var6) ? var3.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var3
//     assertTrue("Contract failed: equals-hashcode on var6 and var3", var6.equals(var3) ? var6.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var3);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    var0.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.axis.AxisState var6 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    java.util.List var9 = var0.refreshTicks(var5, var6, var7, var8);
    double var10 = var6.getCursor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)10L, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var16 = java.awt.Color.getColor("", 10);
//     var13.setTickMarkPaint((java.awt.Paint)var16);
//     org.jfree.chart.axis.TickUnitSource var18 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var13.setStandardTickUnits(var18);
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var23 = var22.getBounds();
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var13.lengthToJava2D((-1.0d), var23, var24);
//     var0.drawBackground(var11, var23);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(short)0, (java.lang.Comparable)(byte)10);
    java.lang.Object var4 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = var0.getObject(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    double var13 = var0.getUpperClip();
    var0.setAutoPopulateSeriesFillPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.clone(var1);
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var2, "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    org.jfree.data.Range var10 = null;
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(10.0d, var10);
    double var12 = var11.getHeight();
    boolean var13 = var8.equals((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var9 = java.awt.Color.getColor("", 10);
    var6.setTickMarkPaint((java.awt.Paint)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem(var0, "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var4, (java.awt.Paint)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, 0.8f, (-1.0f), 0.0d, 0.5f, 100.0f);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    var25.setSeriesIndex(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    var11.setAutoPopulateSeriesOutlinePaint(false);
    var11.setBaseSeriesVisible(true, false);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var11.setNegativeItemLabelPositionFallback(var18);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = var11.getSeriesToolTipGenerator(100);
    org.jfree.chart.annotations.CategoryAnnotation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var3 = var2.darker();
//     int var4 = var3.getBlue();
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
//     int var6 = var3.getTransparency();
//     java.awt.color.ColorSpace var7 = null;
//     java.awt.Color var10 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var11 = var10.darker();
//     int var12 = var11.getBlue();
//     float[] var16 = new float[] { 0.0f, 1.0f, 0.0f};
//     float[] var17 = var11.getColorComponents(var16);
//     float[] var18 = var3.getColorComponents(var7, var17);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.Class var2 = null;
//     java.lang.ClassLoader var3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var2);
//     java.util.ResourceBundle.Control var4 = null;
//     java.util.ResourceBundle var5 = java.util.ResourceBundle.getBundle("AxisLocation.BOTTOM_OR_RIGHT", var1, var3, var4);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
//     org.jfree.data.Range var3 = var2.getHeightRange();
//     java.lang.String var4 = var2.toString();
//     org.jfree.chart.util.Size2D var5 = null;
//     org.jfree.chart.util.Size2D var6 = var2.calculateConstrainedSize(var5);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(0.05d);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, (-1.99999999d), 106.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.arrange(var2);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     java.awt.Paint var5 = var0.getRangeGridlinePaint();
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     int var10 = var9.getSubplotCount();
//     java.awt.geom.Rectangle2D var11 = null;
//     var9.setDataArea(var11);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var9.addSubplotInfo(var13);
//     var0.handleClick(100, 10, var9);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var7 = null;
    var6.setOutlineStroke(var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var6.axisChanged(var9);
    var6.clearAnnotations();
    var5.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
    java.awt.Shape var14 = var5.getSeriesShape(1);
    java.awt.Paint var16 = var5.lookupSeriesFillPaint((-1));
    boolean var17 = var5.getIncludeBaseInRange();
    java.awt.Font var18 = var5.getBaseItemLabelFont();
    var5.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var5.getItemLabelGenerator(10, 0);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.clone(var27);
    var5.setBaseShape(var28);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var32 = null;
    var31.setOutlineStroke(var32);
    org.jfree.chart.event.AxisChangeEvent var34 = null;
    var31.axisChanged(var34);
    java.awt.Paint var36 = var31.getRangeGridlinePaint();
    java.awt.Color var40 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var41 = var40.darker();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var43 = null;
    var42.setOutlineStroke(var43);
    org.jfree.chart.event.AxisChangeEvent var45 = null;
    var42.axisChanged(var45);
    var42.setRangeGridlinesVisible(false);
    boolean var49 = var42.isRangeCrosshairVisible();
    java.awt.Stroke var50 = var42.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var52 = var42.getDataset(10);
    java.awt.Stroke var53 = var42.getDomainGridlineStroke();
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
    float var56 = var55.getTickMarkOutsideLength();
    var55.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var63 = var62.getBounds();
    org.jfree.chart.util.RectangleEdge var64 = null;
    double var65 = var55.valueToJava2D(100.0d, var63, var64);
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
    float var67 = var66.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var68 = var66.getLabelInsets();
    boolean var69 = var66.isVerticalTickLabels();
    double var70 = var66.getLowerMargin();
    var66.setLowerBound(0.0d);
    java.awt.Stroke var73 = var66.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var78 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var79 = var78.darker();
    var75.setLabelPaint((java.awt.Paint)var78);
    float[] var84 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var85 = var78.getColorComponents(var84);
    java.awt.Color var86 = java.awt.Color.getColor("", var78);
    int var87 = var86.getGreen();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var88 = new org.jfree.chart.LegendItem(var0, "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", false, var28, true, var36, false, (java.awt.Paint)var41, var53, false, (java.awt.Shape)var63, var73, (java.awt.Paint)var86);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.99999999d), 3.0d, 1.0d, 100.0d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var11 = null;
    var0.notifyListeners(var11);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    float var14 = var13.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLabelInsets();
    boolean var16 = var13.isVerticalTickLabels();
    boolean var17 = var13.isNegativeArrowVisible();
    boolean var18 = var13.isNegativeArrowVisible();
    int var19 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
    org.jfree.chart.axis.CategoryAxis var21 = var0.getDomainAxisForDataset(100);
    org.jfree.chart.ChartRenderingInfo var23 = null;
    org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
    int var25 = var24.getSubplotCount();
    java.awt.geom.Rectangle2D var26 = null;
    var24.setDataArea(var26);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    var24.addSubplotInfo(var28);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var32 = null;
    var31.setOutlineStroke(var32);
    org.jfree.chart.event.AxisChangeEvent var34 = null;
    var31.axisChanged(var34);
    var31.clearAnnotations();
    var30.addChangeListener((org.jfree.chart.event.RendererChangeListener)var31);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    var31.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
    org.jfree.chart.util.RectangleInsets var40 = var31.getInsets();
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleAnchor var44 = null;
    java.awt.geom.Point2D var45 = org.jfree.chart.util.RectangleAnchor.coordinates(var43, var44);
    var31.zoomDomainAxes(3.0d, var42, var45);
    var0.zoomDomainAxes(10.0d, var28, var45);
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var50 = null;
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
    float var52 = var51.getTickMarkOutsideLength();
    var51.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var56 = null;
    org.jfree.chart.axis.AxisState var57 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var58 = null;
    org.jfree.chart.util.RectangleEdge var59 = null;
    java.util.List var60 = var51.refreshTicks(var56, var57, var58, var59);
    var57.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis();
    float var64 = var63.getTickMarkOutsideLength();
    var63.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var70 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var71 = var70.getBounds();
    org.jfree.chart.util.RectangleEdge var72 = null;
    double var73 = var63.valueToJava2D(100.0d, var71, var72);
    org.jfree.chart.util.RectangleEdge var74 = null;
    java.util.List var75 = var49.refreshTicks(var50, var57, var71, var74);
    java.awt.Shape var76 = var49.getLeftArrow();
    java.awt.Font var77 = var49.getLabelFont();
    org.jfree.chart.renderer.category.BarRenderer var78 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var79 = var78.getBaseStroke();
    var49.setTickMarkStroke(var79);
    var0.setDomainGridlineStroke(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    float var2 = var1.getAlpha();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var8 = var7.darker();
    var4.setLabelPaint((java.awt.Paint)var7);
    float[] var13 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var14 = var7.getColorComponents(var13);
    java.awt.Color var15 = java.awt.Color.getColor("", var7);
    var1.setPaint((java.awt.Paint)var15);
    org.jfree.chart.util.LengthAdjustmentType var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0d, 0.0f, 2.0f);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    float var2 = var1.getTickMarkOutsideLength();
    boolean var3 = var0.equals((java.lang.Object)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.text.TextAnchor var4 = var3.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var8 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var4, 3.0d, var6, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    float var2 = var1.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.ValueAxis[] var5 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setRangeAxes(var5);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var8 = null;
    var7.setOutlineStroke(var8);
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var14);
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var14);
    org.jfree.chart.plot.CategoryMarker var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    float var7 = var0.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((-1.99999999d), 1.0E-8d, 0.05d, 2.0d);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var11 = null;
    var0.notifyListeners(var11);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var0.getRenderer(100);
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    org.jfree.data.Range var3 = var0.getRange();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    var0.setRightArrow(var5);
    var0.setAutoRangeMinimumSize(100.0d);
    var0.setAutoTickUnitSelection(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    float var5 = var4.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
    boolean var7 = var4.isVerticalTickLabels();
    double var8 = var4.getLowerMargin();
    var4.setLowerBound(0.0d);
    java.awt.Stroke var11 = var4.getTickMarkStroke();
    var0.setBaseOutlineStroke(var11, false);
    org.jfree.chart.event.RendererChangeListener var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addChangeListener(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     java.awt.Stroke var11 = var0.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var12 = var0.getRangeAxisEdge();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var15 = null;
//     var14.setOutlineStroke(var15);
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var14.axisChanged(var17);
//     java.awt.Paint var19 = var14.getRangeGridlinePaint();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var25 = java.awt.Color.getColor("", 10);
//     var22.setTickMarkPaint((java.awt.Paint)var25);
//     org.jfree.chart.axis.TickUnitSource var27 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var22.setStandardTickUnits(var27);
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var32 = var31.getBounds();
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var22.lengthToJava2D((-1.0d), var32, var33);
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     boolean var38 = var14.render(var20, var32, 10, var37);
//     java.awt.geom.Point2D var39 = null;
//     var0.zoomRangeAxes(0.05d, var37, var39);
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     float var42 = var41.getTickMarkOutsideLength();
//     var41.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var49 = var48.getBounds();
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var41.valueToJava2D(100.0d, var49, var50);
//     var37.setPlotArea(var49);
//     
//     // Checks the contract:  equals-hashcode on var31 and var48
//     assertTrue("Contract failed: equals-hashcode on var31 and var48", var31.equals(var48) ? var31.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var31
//     assertTrue("Contract failed: equals-hashcode on var48 and var31", var48.equals(var31) ? var48.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
//     boolean var12 = var0.getIncludeBaseInRange();
//     java.awt.Font var13 = var0.getBaseItemLabelFont();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var15 = null;
//     var0.setSeriesItemLabelGenerator(1, var15, true);
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var21 = null;
//     var20.setOutlineStroke(var21);
//     org.jfree.chart.event.AxisChangeEvent var23 = null;
//     var20.axisChanged(var23);
//     var20.clearAnnotations();
//     var19.addChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     java.awt.Shape var28 = var19.getSeriesShape(1);
//     java.awt.Paint var30 = var19.lookupSeriesFillPaint((-1));
//     boolean var31 = var19.getIncludeBaseInRange();
//     java.awt.Font var32 = var19.getBaseItemLabelFont();
//     var0.setSeriesItemLabelFont(10, var32, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
//     
//     // Checks the contract:  equals-hashcode on var1 and var20
//     assertTrue("Contract failed: equals-hashcode on var1 and var20", var1.equals(var20) ? var1.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var1
//     assertTrue("Contract failed: equals-hashcode on var20 and var1", var20.equals(var1) ? var20.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    float var2 = var1.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isVerticalTickLabels();
    double var5 = var1.getLowerMargin();
    double var6 = var1.getFixedAutoRange();
    java.awt.Font var7 = var1.getLabelFont();
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    var8.setAutoPopulateSeriesOutlinePaint(false);
    var8.setBaseSeriesVisible(true, false);
    var8.setBaseSeriesVisibleInLegend(true, false);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    var19.setPaint((java.awt.Paint)var23);
    var8.setSeriesOutlinePaint(100, (java.awt.Paint)var23);
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var7, (java.awt.Paint)var23);
    java.awt.Color var29 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var30 = var29.darker();
    int var31 = var30.getBlue();
    float[] var35 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var36 = var30.getColorComponents(var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var37 = var23.getRGBComponents(var35);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

//  public void test151() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    java.text.AttributedString var26 = var25.getAttributedLabel();
    boolean var27 = var25.isShapeOutlineVisible();
    java.lang.String var28 = var25.getURLText();
    java.awt.Stroke var29 = var25.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var28.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBasePositiveItemLabelPosition();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     float var5 = var4.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
//     boolean var7 = var4.isVerticalTickLabels();
//     double var8 = var4.getLowerMargin();
//     var4.setLowerBound(0.0d);
//     java.awt.Stroke var11 = var4.getTickMarkStroke();
//     var0.setBaseOutlineStroke(var11, false);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var17 = null;
//     var16.setOutlineStroke(var17);
//     org.jfree.chart.event.AxisChangeEvent var19 = null;
//     var16.axisChanged(var19);
//     var16.clearAnnotations();
//     var15.addChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     java.awt.Shape var24 = var15.getSeriesShape(1);
//     java.awt.Paint var26 = var15.lookupSeriesFillPaint((-1));
//     boolean var27 = var15.getIncludeBaseInRange();
//     java.awt.Font var28 = var15.getBaseItemLabelFont();
//     var0.setSeriesItemLabelFont(255, var28);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var0.", var15.equals(var0) == var0.equals(var15));
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.VerticalAlignment var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setVerticalAlignment(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    org.jfree.chart.axis.AxisLocation var10 = null;
    var0.setDomainAxisLocation(1, var10);
    java.awt.Stroke var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlineStroke(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var9 = var0.getDataset();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    float var12 = var11.getTickMarkOutsideLength();
    var11.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var19 = var18.getBounds();
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var11.valueToJava2D(100.0d, var19, var20);
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleAnchor var23 = null;
    java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
    org.jfree.chart.plot.PlotState var25 = null;
    org.jfree.chart.ChartRenderingInfo var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
    var0.draw(var10, var19, var24, var25, var27);
    org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var19, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    java.lang.String var32 = var31.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var32.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.text.TextAnchor var2 = var1.getLabelTextAnchor();
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    var0.clearDomainMarkers(10);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var12 = null;
    var11.setOutlineStroke(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var11.axisChanged(var14);
    var11.setRangeGridlinesVisible(false);
    boolean var18 = var11.isRangeCrosshairVisible();
    java.awt.Stroke var19 = var11.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var21 = var11.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var22 = null;
    var11.notifyListeners(var22);
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = var11.getRenderer(100);
    org.jfree.chart.util.Layer var27 = null;
    java.util.Collection var28 = var11.getDomainMarkers(0, var27);
    org.jfree.chart.axis.AxisLocation var30 = var11.getRangeAxisLocation(10);
    var0.setRangeAxisLocation(var30, true);
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var35 = null;
    var34.setOutlineStroke(var35);
    org.jfree.chart.event.AxisChangeEvent var37 = null;
    var34.axisChanged(var37);
    var34.clearAnnotations();
    var33.addChangeListener((org.jfree.chart.event.RendererChangeListener)var34);
    java.awt.Shape var42 = var33.getSeriesShape(1);
    java.awt.Paint var44 = var33.lookupSeriesFillPaint((-1));
    boolean var45 = var33.getIncludeBaseInRange();
    java.awt.Font var46 = var33.getBaseItemLabelFont();
    var33.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var53 = var33.getItemLabelGenerator(10, 0);
    java.awt.Stroke var54 = var33.getBaseOutlineStroke();
    boolean var56 = var33.isSeriesVisibleInLegend(0);
    boolean var57 = var30.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var2, 100.0d, 3.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 100.0d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     java.awt.Stroke var11 = var0.getDomainGridlineStroke();
//     boolean var12 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var15 = null;
//     var14.setOutlineStroke(var15);
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var14.axisChanged(var17);
//     var14.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var21);
//     var14.clearDomainMarkers(10);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var26 = null;
//     var25.setOutlineStroke(var26);
//     org.jfree.chart.event.AxisChangeEvent var28 = null;
//     var25.axisChanged(var28);
//     var25.setRangeGridlinesVisible(false);
//     boolean var32 = var25.isRangeCrosshairVisible();
//     java.awt.Stroke var33 = var25.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var35 = var25.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var36 = null;
//     var25.notifyListeners(var36);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = var25.getRenderer(100);
//     org.jfree.chart.util.Layer var41 = null;
//     java.util.Collection var42 = var25.getDomainMarkers(0, var41);
//     org.jfree.chart.axis.AxisLocation var44 = var25.getRangeAxisLocation(10);
//     var14.setRangeAxisLocation(var44, true);
//     var0.setDomainAxisLocation(100, var44);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var25 and var0.", var25.equals(var0) == var0.equals(var25));
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setTickMarksVisible(false);
    java.awt.Stroke var3 = var0.getTickMarkStroke();
    var0.setAxisLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!", var3, "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var7.setVersion("hi!");
    var7.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.String var12 = var7.getLicenceText();
    org.jfree.chart.ui.Library var17 = new org.jfree.chart.ui.Library("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "AxisLocation.BOTTOM_OR_RIGHT");
    var7.addLibrary(var17);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var20 = null;
    var19.setOutlineStroke(var20);
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var19.axisChanged(var22);
    var19.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var26);
    var19.mapDatasetToRangeAxis(0, 0);
    java.lang.String var31 = var19.getNoDataMessage();
    java.util.List var32 = var19.getAnnotations();
    var7.setContributors(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var9 = null;
//     var8.setOutlineStroke(var9);
//     org.jfree.chart.event.AxisChangeEvent var11 = null;
//     var8.axisChanged(var11);
//     var8.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var15);
//     var8.mapDatasetToRangeAxis(0, 0);
//     java.lang.String var20 = var8.getNoDataMessage();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var22 = null;
//     var21.setOutlineStroke(var22);
//     float var24 = var21.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     var25.setAutoPopulateSeriesOutlinePaint(false);
//     var25.setBaseSeriesVisible(true, false);
//     var25.setBaseSeriesVisibleInLegend(true, false);
//     boolean var34 = var21.equals((java.lang.Object)var25);
//     var25.setSeriesVisible(100, (java.lang.Boolean)true);
//     int var38 = var8.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var8);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var25.", var0.equals(var25) == var25.equals(var0));
//     
//     // Checks the contract:  equals-hashcode on var1 and var21
//     assertTrue("Contract failed: equals-hashcode on var1 and var21", var1.equals(var21) ? var1.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var1
//     assertTrue("Contract failed: equals-hashcode on var21 and var1", var21.equals(var1) ? var21.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var6 = java.awt.Color.getColor("", 10);
//     var3.setTickMarkPaint((java.awt.Paint)var6);
//     org.jfree.chart.axis.TickUnitSource var8 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var3.setStandardTickUnits(var8);
//     org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var13 = var12.getBounds();
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var3.lengthToJava2D((-1.0d), var13, var14);
//     var0.draw(var1, var13);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.util.SortOrder var7 = var0.getColumnRenderingOrder();
    org.jfree.chart.plot.CategoryMarker var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var7 = java.awt.Color.getColor("", 10);
    var4.setTickMarkPaint((java.awt.Paint)var7);
    var1.setSeriesItemLabelPaint(100, (java.awt.Paint)var7, true);
    org.jfree.chart.LegendItem var13 = var1.getLegendItem(0, (-1));
    org.jfree.chart.urls.CategoryURLGenerator var15 = null;
    var1.setSeriesURLGenerator(1, var15, false);
    boolean var18 = var0.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var3 = new org.jfree.chart.block.RectangleConstraint(var1, 10.0d);
    boolean var4 = var0.equals((java.lang.Object)10.0d);
    org.jfree.chart.axis.TickUnits var6 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var8 = null;
    var7.setOutlineStroke(var8);
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.clearAnnotations();
    var7.configureDomainAxes();
    var7.setRangeCrosshairVisible(false);
    boolean var16 = var6.equals((java.lang.Object)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.set((-1), (java.lang.Object)var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var7.calculateBounds(var9, 10.0f, (-1.0f), var12, (-1.0f), 1.0f, 1.0d);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var21 = java.awt.Color.getColor("", 10);
    var18.setTickMarkPaint((java.awt.Paint)var21);
    org.jfree.chart.axis.TickUnitSource var23 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var18.setStandardTickUnits(var23);
    boolean var25 = var7.equals((java.lang.Object)var18);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.text.TextBlockAnchor var29 = null;
    var7.draw(var26, 1.0f, 0.0f, var29, 0.0f, 0.95f, (-1.0000000000000001E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    var11.setAutoPopulateSeriesOutlinePaint(false);
    var11.setBaseSeriesVisible(true, false);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var20 = null;
    var19.setOutlineStroke(var20);
    org.jfree.chart.event.AxisChangeEvent var22 = null;
    var19.axisChanged(var22);
    var19.setRangeGridlinesVisible(false);
    boolean var26 = var19.isRangeCrosshairVisible();
    java.awt.Stroke var27 = var19.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var29 = var19.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var30 = null;
    var19.notifyListeners(var30);
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
    float var33 = var32.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var34 = var32.getLabelInsets();
    boolean var35 = var32.isVerticalTickLabels();
    boolean var36 = var32.isNegativeArrowVisible();
    boolean var37 = var32.isNegativeArrowVisible();
    int var38 = var19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1));

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     float var4 = var3.getTickMarkOutsideLength();
//     var3.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     java.util.List var12 = var3.refreshTicks(var8, var9, var10, var11);
//     var9.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     float var16 = var15.getTickMarkOutsideLength();
//     var15.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var23 = var22.getBounds();
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var15.valueToJava2D(100.0d, var23, var24);
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     java.util.List var27 = var1.refreshTicks(var2, var9, var23, var26);
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     float var33 = var32.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var34 = var32.getLabelInsets();
//     boolean var35 = var32.isVerticalTickLabels();
//     java.awt.Shape var36 = var32.getRightArrow();
//     org.jfree.chart.entity.ChartEntity var37 = new org.jfree.chart.entity.ChartEntity(var36);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     float var42 = var41.getTickMarkOutsideLength();
//     var41.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.axis.AxisState var47 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleEdge var49 = null;
//     java.util.List var50 = var41.refreshTicks(var46, var47, var48, var49);
//     var47.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     float var54 = var53.getTickMarkOutsideLength();
//     var53.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var60 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var61 = var60.getBounds();
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     double var63 = var53.valueToJava2D(100.0d, var61, var62);
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     java.util.List var65 = var39.refreshTicks(var40, var47, var61, var64);
//     java.awt.Shape var66 = var39.getLeftArrow();
//     boolean var67 = var37.equals((java.lang.Object)var66);
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     var68.setTickMarksVisible(false);
//     java.awt.Stroke var71 = var68.getTickMarkStroke();
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var75 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var76 = var75.darker();
//     var72.setLabelPaint((java.awt.Paint)var75);
//     float[] var81 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var82 = var75.getColorComponents(var81);
//     org.jfree.chart.LegendItem var83 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var66, var71, (java.awt.Paint)var75);
//     org.jfree.chart.title.LegendGraphic var84 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var23, (java.awt.Paint)var75);
//     
//     // Checks the contract:  equals-hashcode on var22 and var60
//     assertTrue("Contract failed: equals-hashcode on var22 and var60", var22.equals(var60) ? var22.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var22
//     assertTrue("Contract failed: equals-hashcode on var60 and var22", var60.equals(var22) ? var60.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var3 = null;
    var2.setOutlineStroke(var3);
    org.jfree.chart.event.AxisChangeEvent var5 = null;
    var2.axisChanged(var5);
    var2.clearAnnotations();
    var1.addChangeListener((org.jfree.chart.event.RendererChangeListener)var2);
    java.awt.Shape var10 = var1.getSeriesShape(1);
    java.awt.Paint var12 = var1.lookupSeriesFillPaint((-1));
    boolean var13 = var1.getIncludeBaseInRange();
    java.awt.Font var14 = var1.getBaseItemLabelFont();
    java.awt.Paint var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("AxisLocation.BOTTOM_OR_RIGHT", var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var1.configureDomainAxes();
    var1.setRangeCrosshairVisible(false);
    boolean var10 = var0.equals((java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var12 = var0.getCeilingTickUnit(3.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var30.setAntiAlias(false);
//     org.jfree.chart.event.PlotChangeEvent var33 = null;
//     var30.plotChanged(var33);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     var1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
//     org.jfree.chart.util.RectangleInsets var10 = var1.getInsets();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var12 = null;
//     var11.setOutlineStroke(var12);
//     org.jfree.chart.event.AxisChangeEvent var14 = null;
//     var11.axisChanged(var14);
//     java.awt.Paint var16 = var11.getRangeGridlinePaint();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var22 = java.awt.Color.getColor("", 10);
//     var19.setTickMarkPaint((java.awt.Paint)var22);
//     org.jfree.chart.axis.TickUnitSource var24 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var19.setStandardTickUnits(var24);
//     org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var29 = var28.getBounds();
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var19.lengthToJava2D((-1.0d), var29, var30);
//     org.jfree.chart.ChartRenderingInfo var33 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var34 = new org.jfree.chart.plot.PlotRenderingInfo(var33);
//     boolean var35 = var11.render(var17, var29, 10, var34);
//     var10.trim(var29);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var38 = null;
//     var37.setOutlineStroke(var38);
//     org.jfree.chart.event.AxisChangeEvent var40 = null;
//     var37.axisChanged(var40);
//     var37.setRangeGridlinesVisible(false);
//     boolean var44 = var37.isRangeCrosshairVisible();
//     java.awt.Stroke var45 = var37.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var46 = var37.getDataset();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     float var49 = var48.getTickMarkOutsideLength();
//     var48.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var55 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var56 = var55.getBounds();
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var48.valueToJava2D(100.0d, var56, var57);
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleAnchor var60 = null;
//     java.awt.geom.Point2D var61 = org.jfree.chart.util.RectangleAnchor.coordinates(var59, var60);
//     org.jfree.chart.plot.PlotState var62 = null;
//     org.jfree.chart.ChartRenderingInfo var63 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var64 = new org.jfree.chart.plot.PlotRenderingInfo(var63);
//     var37.draw(var47, var56, var61, var62, var64);
//     boolean var66 = org.jfree.chart.util.ShapeUtilities.intersects(var29, var56);
//     
//     // Checks the contract:  equals-hashcode on var34 and var64
//     assertTrue("Contract failed: equals-hashcode on var34 and var64", var34.equals(var64) ? var34.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var34
//     assertTrue("Contract failed: equals-hashcode on var64 and var34", var64.equals(var34) ? var64.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    int var2 = var1.getSubplotCount();
    java.awt.geom.Rectangle2D var3 = null;
    var1.setDataArea(var3);
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    var1.addSubplotInfo(var5);
    java.awt.geom.Point2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var1.getSubplotIndex(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 10);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    var11.setAutoPopulateSeriesOutlinePaint(false);
    var11.setBaseSeriesVisible(true, false);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var11.setNegativeItemLabelPositionFallback(var18);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = var11.getSeriesToolTipGenerator(100);
    org.jfree.chart.annotations.CategoryAnnotation var22 = null;
    org.jfree.chart.util.Layer var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var22, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Font var6 = null;
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var10 = var9.darker();
//     int var11 = var10.getBlue();
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
//     org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var21, (java.awt.Paint)var25);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var21, 1.0d, 100.0f, 10.0f);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.0E-8d, 106.0d, 1.0E-8d, 2.0d);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var4 = var3.getItemLabelAnchor();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var7 = var4.equals((java.lang.Object)(-1.0f));
    java.lang.Object var8 = null;
    boolean var9 = var4.equals(var8);
    java.lang.String var10 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "ItemLabelAnchor.OUTSIDE12"+ "'", var10.equals("ItemLabelAnchor.OUTSIDE12"));

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", "hi!", "ThreadContext");

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.axis.CategoryLabelPositions var2 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var4 = null;
    var3.setOutlineStroke(var4);
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var3.axisChanged(var6);
    var3.setRangeGridlinesVisible(false);
    boolean var10 = var3.isRangeCrosshairVisible();
    java.awt.Stroke var11 = var3.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var13 = var3.getDomainAxisEdge(100);
    org.jfree.chart.axis.CategoryLabelPosition var14 = var2.getLabelPosition(var13);
    org.jfree.chart.text.TextAnchor var15 = var14.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var18 = new org.jfree.chart.axis.NumberTick((java.lang.Number)2.0d, "ThreadContext", var15, var16, 3.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var11 = null;
//     var0.notifyListeners(var11);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = var0.getRenderer(100);
//     var0.clearDomainMarkers();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     float var18 = var17.getTickMarkOutsideLength();
//     var17.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var25 = var24.getBounds();
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var17.valueToJava2D(100.0d, var25, var26);
//     var0.drawBackground(var16, var25);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var12 = null;
//     var11.setOutlineStroke(var12);
//     org.jfree.chart.event.AxisChangeEvent var14 = null;
//     var11.axisChanged(var14);
//     var11.setRangeGridlinesVisible(false);
//     boolean var18 = var11.isRangeCrosshairVisible();
//     java.awt.Stroke var19 = var11.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var20 = var11.getDataset();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     float var23 = var22.getTickMarkOutsideLength();
//     var22.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var30 = var29.getBounds();
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var22.valueToJava2D(100.0d, var30, var31);
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleAnchor var34 = null;
//     java.awt.geom.Point2D var35 = org.jfree.chart.util.RectangleAnchor.coordinates(var33, var34);
//     org.jfree.chart.plot.PlotState var36 = null;
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
//     var11.draw(var21, var30, var35, var36, var38);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var11);
//     var9.setChart(var40);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var1 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var3 = null;
    var2.setOutlineStroke(var3);
    org.jfree.chart.event.AxisChangeEvent var5 = null;
    var2.axisChanged(var5);
    var2.setRangeGridlinesVisible(false);
    boolean var9 = var2.isRangeCrosshairVisible();
    java.awt.Stroke var10 = var2.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var12 = var2.getDomainAxisEdge(100);
    org.jfree.chart.axis.CategoryLabelPosition var13 = var1.getLabelPosition(var12);
    org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.text.TextAnchor var17 = var16.getLabelTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var19 = new org.jfree.chart.labels.ItemLabelPosition(var0, var14, var17, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    float var3 = var2.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
    boolean var5 = var2.isVerticalTickLabels();
    double var6 = var2.getLowerMargin();
    double var7 = var2.getFixedAutoRange();
    java.awt.Font var8 = var2.getLabelFont();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    var9.setAutoPopulateSeriesOutlinePaint(false);
    var9.setBaseSeriesVisible(true, false);
    var9.setBaseSeriesVisibleInLegend(true, false);
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var24 = var23.darker();
    var20.setPaint((java.awt.Paint)var24);
    var9.setSeriesOutlinePaint(100, (java.awt.Paint)var24);
    org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var8, (java.awt.Paint)var24);
    java.awt.Paint var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("AxisLocation.BOTTOM_OR_RIGHT", var8, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("AxisLocation.BOTTOM_OR_RIGHT", var1, 2.0d, 2.0f, 0.95f);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    var1.setPaint((java.awt.Paint)var5);
    java.lang.String var7 = var1.getToolTipText();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var9 = var8.clone();
    boolean var10 = var1.equals((java.lang.Object)var8);
    java.lang.String var11 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(short)0, (java.lang.Comparable)(byte)10);
    java.lang.Object var4 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("ThreadContext", var1, var2);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    var4.setAutoPopulateSeriesOutlinePaint(false);
    var4.setBaseSeriesVisible(true, false);
    var4.setBaseSeriesVisibleInLegend(true, false);
    boolean var13 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var17 = null;
    var16.setOutlineStroke(var17);
    org.jfree.chart.event.AxisChangeEvent var19 = null;
    var16.axisChanged(var19);
    var16.clearAnnotations();
    var15.addChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
    java.awt.Shape var24 = var15.getSeriesShape(1);
    java.awt.Paint var26 = var15.lookupSeriesFillPaint((-1));
    boolean var27 = var15.getIncludeBaseInRange();
    java.awt.Font var28 = var15.getBaseItemLabelFont();
    var15.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var15.getItemLabelGenerator(10, 0);
    java.awt.Stroke var36 = var15.getBaseOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), (org.jfree.chart.renderer.category.CategoryItemRenderer)var15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var6 = java.awt.Color.getColor("", 10);
    var3.setTickMarkPaint((java.awt.Paint)var6);
    var0.setSeriesItemLabelPaint(100, (java.awt.Paint)var6, true);
    var0.setSeriesItemLabelsVisible(1, false);
    boolean var15 = var0.isItemLabelVisible(1, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    float var2 = var1.getAlpha();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var8 = var7.darker();
    var4.setLabelPaint((java.awt.Paint)var7);
    float[] var13 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var14 = var7.getColorComponents(var13);
    java.awt.Color var15 = java.awt.Color.getColor("", var7);
    var1.setPaint((java.awt.Paint)var15);
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    float var20 = var19.getTickMarkOutsideLength();
    var19.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var27 = var26.getBounds();
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var19.valueToJava2D(100.0d, var27, var28);
    java.awt.geom.AffineTransform var30 = null;
    java.awt.RenderingHints var31 = null;
    java.awt.PaintContext var32 = var15.createContext(var17, var18, var27, var30, var31);
    java.lang.String var33 = var15.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var33.equals("java.awt.Color[r=0,g=0,b=1]"));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    int var9 = var0.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     java.awt.Font var2 = null;
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var6 = var5.darker();
//     int var7 = var6.getBlue();
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var6);
//     org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 1.0E-8d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var13);
//     java.lang.Object var15 = var14.clone();
//     org.jfree.chart.block.Block var16 = null;
//     var14.add(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var14.getPadding();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.block.RectangleConstraint var20 = null;
//     org.jfree.chart.util.Size2D var21 = var0.arrange(var14, var19, var20);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var25 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var21, (java.awt.Paint)var25);
    org.jfree.chart.entity.CategoryLabelEntity var29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(-1.0f), var21, "HorizontalAlignment.CENTER", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.Comparable var30 = var29.getKey();
    java.lang.String var31 = var29.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (-1.0f)+ "'", var30.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var31.equals("CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.entity.TickLabelEntity var4 = new org.jfree.chart.entity.TickLabelEntity(var1, "hi!", "");
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var6 = var4.equals((java.lang.Object)var5);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var9 = null;
    var8.setOutlineStroke(var9);
    org.jfree.chart.event.AxisChangeEvent var11 = null;
    var8.axisChanged(var11);
    var8.setRangeGridlinesVisible(false);
    org.jfree.chart.util.SortOrder var15 = var8.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var8.setDomainAxis(10, var18, false);
    var18.setCategoryMargin(0.0d);
    org.jfree.chart.axis.TickUnits var23 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var25 = null;
    var24.setOutlineStroke(var25);
    org.jfree.chart.event.AxisChangeEvent var27 = null;
    var24.axisChanged(var27);
    var24.clearAnnotations();
    var24.configureDomainAxes();
    var24.setRangeCrosshairVisible(false);
    boolean var33 = var23.equals((java.lang.Object)var24);
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    float var35 = var34.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var36 = var34.getLabelInsets();
    org.jfree.data.Range var37 = var34.getRange();
    org.jfree.data.Range var38 = var34.getDefaultAutoRange();
    org.jfree.chart.axis.NumberTickUnit var39 = var34.getTickUnit();
    var23.add((org.jfree.chart.axis.TickUnit)var39);
    java.awt.Font var41 = var18.getTickLabelFont((java.lang.Comparable)var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setSeriesItemLabelFont((-1), var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     var0.setBaseSeriesVisible(true, false);
//     var0.setBaseSeriesVisibleInLegend(true, false);
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var14 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var15 = var14.darker();
//     var11.setPaint((java.awt.Paint)var15);
//     var0.setSeriesOutlinePaint(100, (java.awt.Paint)var15);
//     java.awt.Font var23 = null;
//     java.awt.Color var26 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var27 = var26.darker();
//     int var28 = var27.getBlue();
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var27);
//     org.jfree.chart.util.HorizontalAlignment var30 = var29.getLineAlignment();
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.text.TextBlockAnchor var34 = null;
//     java.awt.Shape var38 = var29.calculateBounds(var31, 10.0f, (-1.0f), var34, (-1.0f), 1.0f, 1.0d);
//     java.awt.Color var42 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
//     org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var38, (java.awt.Paint)var42);
//     java.text.AttributedString var44 = var43.getAttributedLabel();
//     boolean var45 = var43.isShapeOutlineVisible();
//     java.awt.Stroke var46 = var43.getOutlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var47 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var49 = null;
//     var48.setOutlineStroke(var49);
//     org.jfree.chart.event.AxisChangeEvent var51 = null;
//     var48.axisChanged(var51);
//     var48.clearAnnotations();
//     var47.addChangeListener((org.jfree.chart.event.RendererChangeListener)var48);
//     org.jfree.chart.urls.CategoryURLGenerator var56 = null;
//     var47.setSeriesURLGenerator(10, var56, false);
//     org.jfree.chart.util.GradientPaintTransformer var59 = var47.getGradientPaintTransformer();
//     var43.setFillPaintTransformer(var59);
//     var0.setGradientPaintTransformer(var59);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var47 and var0.", var47.equals(var0) == var0.equals(var47));
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    float var2 = var1.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.ValueAxis[] var5 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setRangeAxes(var5);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var8 = null;
    var7.setOutlineStroke(var8);
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var14);
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var14);
    java.awt.Paint var17 = var14.getNextOutlinePaint();
    java.lang.Object var18 = var14.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.KeyedObjects2D var14 = new org.jfree.data.KeyedObjects2D();
    java.util.List var15 = var14.getRowKeys();
    boolean var16 = var13.equals((java.lang.Object)var14);
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var13);
    java.lang.Object var18 = var13.clone();
    org.jfree.data.category.CategoryDataset var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var21 = var13.generateLabel(var19, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     float var5 = var4.getTickMarkOutsideLength();
//     var4.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var4.refreshTicks(var9, var10, var11, var12);
//     var10.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     float var17 = var16.getTickMarkOutsideLength();
//     var16.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var24 = var23.getBounds();
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var16.valueToJava2D(100.0d, var24, var25);
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     java.util.List var28 = var2.refreshTicks(var3, var10, var24, var27);
//     java.awt.Shape var29 = var2.getLeftArrow();
//     java.awt.Font var30 = var2.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var32 = null;
//     var31.setOutlineStroke(var32);
//     org.jfree.chart.event.AxisChangeEvent var34 = null;
//     var31.axisChanged(var34);
//     var31.setRangeGridlinesVisible(false);
//     org.jfree.chart.axis.CategoryAxis var38 = var31.getDomainAxis();
//     java.awt.Paint var39 = var31.getBackgroundPaint();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var30, var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.text.TextAnchor var44 = var43.getLabelTextAnchor();
//     float var45 = var40.calculateBaselineOffset(var41, var44);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    double var4 = var0.getLowerMargin();
    var0.setTickMarkInsideLength(1.0f);
    var0.setRangeAboutValue(10.0d, 10.0d);
    org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    double var12 = var11.getSize();
    var0.setTickUnit(var11, false, false);
    org.jfree.chart.axis.MarkerAxisBand var16 = var0.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    double var4 = var0.getLowerMargin();
    var0.setTickMarkInsideLength(1.0f);
    var0.setRangeAboutValue(10.0d, 10.0d);
    boolean var10 = var0.getAutoRangeStickyZero();
    java.lang.Object var11 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(-1.0f), 2.0d, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(short)0, (java.lang.Comparable)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getColumnKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    boolean var4 = var0.isNegativeArrowVisible();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var7 = null;
    var6.setOutlineStroke(var7);
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var6.axisChanged(var9);
    var6.clearAnnotations();
    var5.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
    java.awt.Shape var14 = var5.getSeriesShape(1);
    java.awt.Paint var16 = var5.lookupSeriesFillPaint((-1));
    boolean var17 = var5.getIncludeBaseInRange();
    java.awt.Font var18 = var5.getBaseItemLabelFont();
    var0.setTickLabelFont(var18);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var21 = null;
    var20.setOutlineStroke(var21);
    org.jfree.chart.event.AxisChangeEvent var23 = null;
    var20.axisChanged(var23);
    var20.setRangeGridlinesVisible(false);
    boolean var27 = var20.isRangeCrosshairVisible();
    java.awt.Stroke var28 = var20.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var30 = var20.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var31 = null;
    var20.notifyListeners(var31);
    org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var20.getRenderer(100);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var20.getDomainMarkers(0, var36);
    org.jfree.chart.axis.AxisLocation var39 = var20.getRangeAxisLocation(10);
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var43 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var44 = var43.darker();
    var40.setLabelPaint((java.awt.Paint)var43);
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
    float var47 = var46.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var48 = var46.getLabelInsets();
    double var50 = var48.extendHeight(100.0d);
    var40.setTickLabelInsets(var48);
    boolean var52 = var39.equals((java.lang.Object)var48);
    var0.setTickLabelInsets(var48);
    java.text.NumberFormat var54 = var0.getNumberFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Comparable var3 = var0.getKey(100);
    java.lang.Comparable var5 = var0.getKey(0);
    java.util.List var6 = var0.getKeys();
    int var8 = var0.getIndex((java.lang.Comparable)(byte)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var12 = var11.getBaseStroke();
    var0.setDomainGridlineStroke(var12);
    var0.setRangeCrosshairValue((-1.0d), false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.OUTSIDE12", var1, 0.0d, 0.95f, 0.0f);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//     java.util.ResourceBundle.clearCache(var2);
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("AxisLocation.BOTTOM_OR_RIGHT", var1, var2);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 10.0d);
    double var3 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, var2);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    boolean var10 = var0.getAutoPopulateSeriesStroke();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var12.axisChanged(var15);
    var12.setRangeGridlinesVisible(false);
    boolean var19 = var12.isRangeCrosshairVisible();
    java.awt.Stroke var20 = var12.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var22 = var12.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var23 = null;
    var12.notifyListeners(var23);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    float var26 = var25.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var27 = var25.getLabelInsets();
    boolean var28 = var25.isVerticalTickLabels();
    boolean var29 = var25.isNegativeArrowVisible();
    boolean var30 = var25.isNegativeArrowVisible();
    int var31 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var32 = var12.getRangeCrosshairPaint();
    var0.setSeriesFillPaint(1, var32);
    java.awt.Paint var35 = var0.getSeriesPaint(10);
    org.jfree.chart.ChartColor var39 = new org.jfree.chart.ChartColor(0, 0, 100);
    java.awt.Color var40 = var39.brighter();
    var0.setBaseOutlinePaint((java.awt.Paint)var39, false);
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var46 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var47 = var46.darker();
    var43.setLabelPaint((java.awt.Paint)var46);
    float[] var52 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var53 = var46.getColorComponents(var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var54 = var39.getRGBComponents(var53);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
//     int var2 = var1.getMinorTickCount();
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var5 = null;
//     var4.setOutlineStroke(var5);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var4.axisChanged(var7);
//     var4.clearAnnotations();
//     var3.addChangeListener((org.jfree.chart.event.RendererChangeListener)var4);
//     java.awt.Shape var12 = var3.getSeriesShape(1);
//     boolean var13 = var3.getAutoPopulateSeriesStroke();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var16 = null;
//     var15.setOutlineStroke(var16);
//     org.jfree.chart.event.AxisChangeEvent var18 = null;
//     var15.axisChanged(var18);
//     var15.setRangeGridlinesVisible(false);
//     boolean var22 = var15.isRangeCrosshairVisible();
//     java.awt.Stroke var23 = var15.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var25 = var15.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var26 = null;
//     var15.notifyListeners(var26);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     float var29 = var28.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var30 = var28.getLabelInsets();
//     boolean var31 = var28.isVerticalTickLabels();
//     boolean var32 = var28.isNegativeArrowVisible();
//     boolean var33 = var28.isNegativeArrowVisible();
//     int var34 = var15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var28);
//     java.awt.Paint var35 = var15.getRangeCrosshairPaint();
//     var3.setSeriesFillPaint(1, var35);
//     int var37 = var1.compareTo((java.lang.Object)1);
//     org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var39 = var38.getBaseStroke();
//     java.awt.Paint var40 = var38.getBaseFillPaint();
//     boolean var41 = var1.equals((java.lang.Object)var38);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var38 and var3.", var38.equals(var3) == var3.equals(var38));
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var7 = java.awt.Color.getColor("", 10);
    var4.setTickMarkPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var14 = var13.darker();
    var10.setLabelPaint((java.awt.Paint)var13);
    float[] var19 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var20 = var13.getColorComponents(var19);
    java.awt.Color var21 = java.awt.Color.getColor("", var13);
    var4.setTickLabelPaint((java.awt.Paint)var21);
    var0.setDomainGridlinePaint((java.awt.Paint)var21);
    org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var25 = var24.getInsets();
    java.lang.String var26 = var25.toString();
    double var27 = var25.getRight();
    double var29 = var25.calculateLeftInset(106.0d);
    var0.setInsets(var25, true);
    double var33 = var25.calculateTopInset((-1.99999999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var26.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0d);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var3 = var2.darker();
    int var4 = var3.getBlue();
    float[] var8 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var9 = var3.getColorComponents(var8);
    java.awt.Color var12 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var13 = var12.darker();
    java.awt.color.ColorSpace var14 = var12.getColorSpace();
    float[] var15 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var16 = var3.getColorComponents(var14, var15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     var4.setAutoPopulateSeriesOutlinePaint(false);
//     var4.setBaseSeriesVisible(true, false);
//     var4.setBaseSeriesVisibleInLegend(true, false);
//     boolean var13 = var0.equals((java.lang.Object)var4);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     float var16 = var15.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getLabelInsets();
//     boolean var18 = var15.isVerticalTickLabels();
//     double var19 = var15.getLowerMargin();
//     var15.setAutoRangeIncludesZero(false);
//     var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var15, true);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     float var26 = var25.getAlpha();
//     var25.setValue((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var30 = null;
//     var29.setOutlineStroke(var30);
//     float var32 = var29.getBackgroundImageAlpha();
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     var33.setAutoPopulateSeriesOutlinePaint(false);
//     var33.setBaseSeriesVisible(true, false);
//     var33.setBaseSeriesVisibleInLegend(true, false);
//     boolean var42 = var29.equals((java.lang.Object)var33);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     float var45 = var44.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var46 = var44.getLabelInsets();
//     boolean var47 = var44.isVerticalTickLabels();
//     double var48 = var44.getLowerMargin();
//     var44.setAutoRangeIncludesZero(false);
//     var29.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var44, true);
//     var25.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var29);
//     var15.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var29);
//     
//     // Checks the contract:  equals-hashcode on var0 and var29
//     assertTrue("Contract failed: equals-hashcode on var0 and var29", var0.equals(var29) ? var0.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var0
//     assertTrue("Contract failed: equals-hashcode on var29 and var0", var29.equals(var0) ? var29.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.CENTER");

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    java.lang.String var3 = var2.getName();
    java.lang.String var4 = var2.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "hi!"+ "'", var3.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    java.text.AttributedString var26 = var25.getAttributedLabel();
    java.lang.Comparable var27 = var25.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 2.0d, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     float var3 = var2.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var4 = var2.getLabelInsets();
//     boolean var5 = var2.isVerticalTickLabels();
//     double var6 = var2.getLowerMargin();
//     double var7 = var2.getFixedAutoRange();
//     java.awt.Font var8 = var2.getLabelFont();
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     var9.setAutoPopulateSeriesOutlinePaint(false);
//     var9.setBaseSeriesVisible(true, false);
//     var9.setBaseSeriesVisibleInLegend(true, false);
//     org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var24 = var23.darker();
//     var20.setPaint((java.awt.Paint)var24);
//     var9.setSeriesOutlinePaint(100, (java.awt.Paint)var24);
//     org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var8, (java.awt.Paint)var24);
//     java.awt.Color var30 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.text.TextMeasurer var33 = null;
//     org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var8, (java.awt.Paint)var30, 0.5f, 0, var33);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.95f, 0.5f, 2.0d, 10.0f, 10.0f);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((-1.99999999d), 3.0d, var2);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var2 = var1.getBounds();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var8 = var7.darker();
//     var4.setLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     float var11 = var10.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getLabelInsets();
//     double var14 = var12.extendHeight(100.0d);
//     var4.setTickLabelInsets(var12);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     float var17 = var16.getTickMarkOutsideLength();
//     var16.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var24 = var23.getBounds();
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var16.valueToJava2D(100.0d, var24, var25);
//     java.awt.geom.Rectangle2D var29 = var12.createInsetRectangle(var24, true, false);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     org.jfree.chart.event.AxisChangeEvent var33 = null;
//     var30.axisChanged(var33);
//     var30.setRangeGridlinesVisible(false);
//     org.jfree.chart.util.SortOrder var37 = var30.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var30.setDomainAxis(10, var40, false);
//     var40.setCategoryMargin(0.0d);
//     org.jfree.chart.axis.TickUnits var45 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var47 = null;
//     var46.setOutlineStroke(var47);
//     org.jfree.chart.event.AxisChangeEvent var49 = null;
//     var46.axisChanged(var49);
//     var46.clearAnnotations();
//     var46.configureDomainAxes();
//     var46.setRangeCrosshairVisible(false);
//     boolean var55 = var45.equals((java.lang.Object)var46);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     float var57 = var56.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var58 = var56.getLabelInsets();
//     org.jfree.data.Range var59 = var56.getRange();
//     org.jfree.data.Range var60 = var56.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberTickUnit var61 = var56.getTickUnit();
//     var45.add((org.jfree.chart.axis.TickUnit)var61);
//     java.awt.Font var63 = var40.getTickLabelFont((java.lang.Comparable)var61);
//     java.lang.Object var64 = var1.draw(var3, var29, (java.lang.Object)var40);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var0.addChangeListener(var5);
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     org.jfree.chart.event.AxisChangeEvent var13 = null;
//     var10.axisChanged(var13);
//     java.awt.Paint var15 = var10.getRangeGridlinePaint();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var21 = java.awt.Color.getColor("", 10);
//     var18.setTickMarkPaint((java.awt.Paint)var21);
//     org.jfree.chart.axis.TickUnitSource var23 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var18.setStandardTickUnits(var23);
//     org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var28 = var27.getBounds();
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     double var30 = var18.lengthToJava2D((-1.0d), var28, var29);
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
//     boolean var34 = var10.render(var16, var28, 10, var33);
//     var0.drawBackgroundImage(var9, var28);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     var11.setAutoPopulateSeriesOutlinePaint(false);
//     var11.setBaseSeriesVisible(true, false);
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
//     org.jfree.chart.labels.ItemLabelPosition var18 = null;
//     var11.setNegativeItemLabelPositionFallback(var18);
//     org.jfree.chart.labels.CategoryToolTipGenerator var22 = var11.getToolTipGenerator(255, (-1));
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.event.MarkerChangeEvent var25 = null;
//     var24.markerChanged(var25);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var28 = null;
//     var27.setOutlineStroke(var28);
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var27.axisChanged(var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var27.addChangeListener(var32);
//     org.jfree.chart.axis.ValueAxis var35 = var27.getRangeAxis((-1));
//     java.awt.Stroke var36 = var27.getRangeCrosshairStroke();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var27.setDomainAxis(100, var39);
//     var39.removeCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryMarker var43 = null;
//     org.jfree.chart.block.LabelBlock var45 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var46 = var45.getMargin();
//     var45.setPadding(0.0d, 106.0d, 100.0d, 100.0d);
//     java.lang.String var52 = var45.getToolTipText();
//     java.awt.geom.Rectangle2D var53 = var45.getBounds();
//     var11.drawDomainMarker(var23, var24, var39, var43, var53);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    java.text.NumberFormat var3 = var0.getNumberFormatOverride();
    double var4 = var0.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     boolean var10 = var0.getAutoPopulateSeriesStroke();
//     boolean var11 = var0.getAutoPopulateSeriesOutlineStroke();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var13 = null;
//     var12.setOutlineStroke(var13);
//     org.jfree.chart.event.AxisChangeEvent var15 = null;
//     var12.axisChanged(var15);
//     var12.setRangeGridlinesVisible(false);
//     org.jfree.chart.util.SortOrder var19 = var12.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var12.setDomainAxis(10, var22, false);
//     var22.setCategoryMargin(0.0d);
//     org.jfree.chart.axis.TickUnits var27 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var29 = null;
//     var28.setOutlineStroke(var29);
//     org.jfree.chart.event.AxisChangeEvent var31 = null;
//     var28.axisChanged(var31);
//     var28.clearAnnotations();
//     var28.configureDomainAxes();
//     var28.setRangeCrosshairVisible(false);
//     boolean var37 = var27.equals((java.lang.Object)var28);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     float var39 = var38.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var40 = var38.getLabelInsets();
//     org.jfree.data.Range var41 = var38.getRange();
//     org.jfree.data.Range var42 = var38.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberTickUnit var43 = var38.getTickUnit();
//     var27.add((org.jfree.chart.axis.TickUnit)var43);
//     java.awt.Font var45 = var22.getTickLabelFont((java.lang.Comparable)var43);
//     var0.setBaseItemLabelFont(var45, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Paint var4 = var0.lookupSeriesPaint(0);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBasePositiveItemLabelPosition(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    var0.setAutoRangeMinimumSize(10.0d);
    var0.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var0.resizeRange((-1.0d), 3.0d);
    var0.setTickMarksVisible(false);
    java.awt.Shape var12 = var0.getRightArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    org.jfree.chart.event.RendererChangeEvent var9 = null;
    var0.rendererChanged(var9);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
//     float var4 = var3.getTickMarkOutsideLength();
//     var3.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     java.util.List var12 = var3.refreshTicks(var8, var9, var10, var11);
//     var9.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     float var16 = var15.getTickMarkOutsideLength();
//     var15.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var23 = var22.getBounds();
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var15.valueToJava2D(100.0d, var23, var24);
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     java.util.List var27 = var1.refreshTicks(var2, var9, var23, var26);
//     org.jfree.chart.axis.CategoryLabelPositions var29 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     org.jfree.chart.event.AxisChangeEvent var33 = null;
//     var30.axisChanged(var33);
//     var30.setRangeGridlinesVisible(false);
//     boolean var37 = var30.isRangeCrosshairVisible();
//     java.awt.Stroke var38 = var30.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var40 = var30.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var41 = var29.getLabelPosition(var40);
//     double var42 = org.jfree.chart.util.RectangleEdge.coordinate(var23, var40);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var45 = null;
//     var44.setOutlineStroke(var45);
//     org.jfree.chart.event.AxisChangeEvent var47 = null;
//     var44.axisChanged(var47);
//     var44.setRangeGridlinesVisible(false);
//     boolean var51 = var44.isRangeCrosshairVisible();
//     java.awt.Stroke var52 = var44.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var54 = var44.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var55 = var43.getLabelPosition(var54);
//     boolean var56 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var54);
//     double var57 = org.jfree.chart.util.RectangleEdge.coordinate(var23, var54);
//     
//     // Checks the contract:  equals-hashcode on var30 and var44
//     assertTrue("Contract failed: equals-hashcode on var30 and var44", var30.equals(var44) ? var30.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var30
//     assertTrue("Contract failed: equals-hashcode on var44 and var30", var44.equals(var30) ? var44.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setTickMarksVisible(false);
    org.jfree.chart.event.AxisChangeEvent var3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.event.ChartChangeEventType var4 = var3.getType();
    org.jfree.chart.util.ShapeList var5 = new org.jfree.chart.util.ShapeList();
    boolean var6 = var4.equals((java.lang.Object)var5);
    java.awt.Shape var8 = null;
    var5.setShape(100, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedWidth(1.0d);
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var7 = var5.toRangeHeight(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     float var2 = var1.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
//     boolean var4 = var1.isVerticalTickLabels();
//     org.jfree.chart.axis.ValueAxis[] var5 = new org.jfree.chart.axis.ValueAxis[] { var1};
//     var0.setRangeAxes(var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var8 = null;
//     var7.setOutlineStroke(var8);
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var7.axisChanged(var10);
//     var7.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var14);
//     var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var14);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var18 = null;
//     var17.setOutlineStroke(var18);
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var17.axisChanged(var20);
//     var17.setRangeGridlinesVisible(false);
//     org.jfree.chart.util.SortOrder var24 = var17.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var24);
//     
//     // Checks the contract:  equals-hashcode on var7 and var17
//     assertTrue("Contract failed: equals-hashcode on var7 and var17", var7.equals(var17) ? var7.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var7
//     assertTrue("Contract failed: equals-hashcode on var17 and var7", var17.equals(var7) ? var17.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var5 = var4.darker();
//     var1.setPaint((java.awt.Paint)var5);
//     java.lang.String var7 = var1.getToolTipText();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var9 = null;
//     var8.setOutlineStroke(var9);
//     org.jfree.chart.event.AxisChangeEvent var11 = null;
//     var8.axisChanged(var11);
//     var8.setRangeGridlinesVisible(false);
//     org.jfree.chart.event.AxisChangeEvent var15 = null;
//     var8.axisChanged(var15);
//     java.awt.Paint var17 = var8.getRangeGridlinePaint();
//     boolean var18 = var1.equals((java.lang.Object)var8);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var22 = var21.getMargin();
//     var21.setPadding(0.0d, 106.0d, 100.0d, 100.0d);
//     java.lang.String var28 = var21.getToolTipText();
//     java.awt.geom.Rectangle2D var29 = var21.getBounds();
//     org.jfree.chart.block.LineBorder var30 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var31 = var30.getInsets();
//     java.lang.Object var32 = var1.draw(var19, var29, (java.lang.Object)var30);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var11 = null;
//     var0.notifyListeners(var11);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     var13.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var13.getBasePositiveItemLabelPosition();
//     int var17 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var21 = null;
//     var20.setOutlineStroke(var21);
//     org.jfree.chart.event.AxisChangeEvent var23 = null;
//     var20.axisChanged(var23);
//     var20.clearAnnotations();
//     var19.addChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     java.awt.Shape var28 = var19.getSeriesShape(1);
//     java.awt.Paint var30 = var19.lookupSeriesFillPaint((-1));
//     boolean var31 = var19.getIncludeBaseInRange();
//     java.awt.Font var32 = var19.getBaseItemLabelFont();
//     var19.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var39 = var19.getItemLabelGenerator(10, 0);
//     java.awt.Stroke var40 = var19.getBaseOutlineStroke();
//     boolean var42 = var19.isSeriesVisibleInLegend(0);
//     org.jfree.chart.block.LabelBlock var44 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var48 = var47.darker();
//     var44.setPaint((java.awt.Paint)var48);
//     var19.setBaseItemLabelPaint((java.awt.Paint)var48, false);
//     org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
//     var52.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var55 = var52.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var56 = var55.getItemLabelAnchor();
//     var19.setNegativeItemLabelPositionFallback(var55);
//     org.jfree.chart.text.TextAnchor var58 = var55.getTextAnchor();
//     var13.setSeriesNegativeItemLabelPosition(255, var55);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var52 and var13.", var52.equals(var13) == var13.equals(var52));
//     
//     // Checks the contract:  equals-hashcode on var16 and var55
//     assertTrue("Contract failed: equals-hashcode on var16 and var55", var16.equals(var55) ? var16.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var16
//     assertTrue("Contract failed: equals-hashcode on var55 and var16", var55.equals(var16) ? var55.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    boolean var10 = var0.getAutoPopulateSeriesStroke();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var12.axisChanged(var15);
    var12.setRangeGridlinesVisible(false);
    boolean var19 = var12.isRangeCrosshairVisible();
    java.awt.Stroke var20 = var12.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var22 = var12.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var23 = null;
    var12.notifyListeners(var23);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    float var26 = var25.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var27 = var25.getLabelInsets();
    boolean var28 = var25.isVerticalTickLabels();
    boolean var29 = var25.isNegativeArrowVisible();
    boolean var30 = var25.isNegativeArrowVisible();
    int var31 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var32 = var12.getRangeCrosshairPaint();
    var0.setSeriesFillPaint(1, var32);
    boolean var34 = var0.getIncludeBaseInRange();
    java.awt.Paint var36 = var0.lookupSeriesFillPaint(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, (-1.0000000000000001E-16d), true);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(short)0, (java.lang.Comparable)(byte)10);
    java.lang.Object var4 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = var0.getObject(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getMargin();
    var1.setPadding(0.0d, 106.0d, 100.0d, 100.0d);
    java.lang.String var8 = var1.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var33 = var32.clone();
//     org.jfree.chart.util.VerticalAlignment var34 = var32.getVerticalAlignment();
//     var30.removeSubtitle((org.jfree.chart.title.Title)var32);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var38 = null;
//     var37.setOutlineStroke(var38);
//     org.jfree.chart.event.AxisChangeEvent var40 = null;
//     var37.axisChanged(var40);
//     var37.setRangeGridlinesVisible(false);
//     boolean var44 = var37.isRangeCrosshairVisible();
//     java.awt.Stroke var45 = var37.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var47 = var37.getDataset(10);
//     java.awt.Stroke var48 = var37.getDomainGridlineStroke();
//     boolean var49 = var37.isRangeCrosshairLockedOnData();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
//     float var55 = var54.getTickMarkOutsideLength();
//     var54.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var59 = null;
//     org.jfree.chart.axis.AxisState var60 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     java.util.List var63 = var54.refreshTicks(var59, var60, var61, var62);
//     var60.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
//     float var67 = var66.getTickMarkOutsideLength();
//     var66.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var73 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var74 = var73.getBounds();
//     org.jfree.chart.util.RectangleEdge var75 = null;
//     double var76 = var66.valueToJava2D(100.0d, var74, var75);
//     org.jfree.chart.util.RectangleEdge var77 = null;
//     java.util.List var78 = var52.refreshTicks(var53, var60, var74, var77);
//     var37.drawBackgroundImage(var50, var74);
//     var30.draw(var36, var74);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.KeyedObjects2D var14 = new org.jfree.data.KeyedObjects2D();
    java.util.List var15 = var14.getRowKeys();
    boolean var16 = var13.equals((java.lang.Object)var14);
    java.util.List var17 = var14.getRowKeys();
    boolean var18 = var8.equals((java.lang.Object)var14);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var23 = java.awt.Color.getColor("", 10);
    var20.setTickMarkPaint((java.awt.Paint)var23);
    org.jfree.chart.axis.TickUnitSource var25 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var20.setStandardTickUnits(var25);
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var30 = var29.getBounds();
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var20.lengthToJava2D((-1.0d), var30, var31);
    boolean var33 = var8.equals((java.lang.Object)var32);
    java.lang.String var34 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var34.equals("HorizontalAlignment.CENTER"));

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesCreateEntities(0);
//     int var3 = var0.getColumnCount();
//     org.jfree.chart.urls.CategoryURLGenerator var5 = null;
//     var0.setSeriesURLGenerator(100, var5);
//     var0.setBaseItemLabelsVisible(true, true);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     org.jfree.chart.event.AxisChangeEvent var13 = null;
//     var10.axisChanged(var13);
//     org.jfree.chart.event.PlotChangeListener var15 = null;
//     var10.addChangeListener(var15);
//     boolean var17 = var0.hasListener((java.util.EventListener)var10);
//     var0.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     var20.setAutoPopulateSeriesOutlinePaint(false);
//     var20.setBaseSeriesVisible(true, false);
//     var20.setBaseSeriesVisibleInLegend(true, false);
//     org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var32 = null;
//     var31.setOutlineStroke(var32);
//     org.jfree.chart.event.AxisChangeEvent var34 = null;
//     var31.axisChanged(var34);
//     var31.clearAnnotations();
//     var30.addChangeListener((org.jfree.chart.event.RendererChangeListener)var31);
//     java.awt.Shape var39 = var30.getSeriesShape(1);
//     java.awt.Color var42 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var43 = var42.darker();
//     int var44 = var43.getBlue();
//     var30.setBasePaint((java.awt.Paint)var43);
//     var20.setSeriesFillPaint(1, (java.awt.Paint)var43);
//     var0.setBaseOutlinePaint((java.awt.Paint)var43);
//     
//     // Checks the contract:  equals-hashcode on var10 and var31
//     assertTrue("Contract failed: equals-hashcode on var10 and var31", var10.equals(var31) ? var10.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var10
//     assertTrue("Contract failed: equals-hashcode on var31 and var10", var31.equals(var10) ? var31.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    var1.setPaint((java.awt.Paint)var5);
    java.lang.String var7 = var1.getToolTipText();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var9 = null;
    var8.setOutlineStroke(var9);
    org.jfree.chart.event.AxisChangeEvent var11 = null;
    var8.axisChanged(var11);
    var8.setRangeGridlinesVisible(false);
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var8.axisChanged(var15);
    java.awt.Paint var17 = var8.getRangeGridlinePaint();
    boolean var18 = var1.equals((java.lang.Object)var8);
    org.jfree.chart.plot.CategoryMarker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    boolean var4 = var0.isTickMarksVisible();
    boolean var5 = var0.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    double var4 = var0.getLowerMargin();
    var0.setTickMarkInsideLength(1.0f);
    var0.setRangeAboutValue(10.0d, 10.0d);
    org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    double var12 = var11.getSize();
    var0.setTickUnit(var11, false, false);
    java.lang.String var17 = var11.valueToString((-1.0000000000000001E-16d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "-0"+ "'", var17.equals("-0"));

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getMargin();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var4 = var3.getBaseStroke();
    java.awt.Paint var5 = var3.getBaseFillPaint();
    var1.setPaint(var5);
    var1.setPadding(0.05d, 1.0d, 106.0d, (-1.0d));
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var3 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var4 = var3.darker();
    var0.setLabelPaint((java.awt.Paint)var3);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    float var7 = var6.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var8 = var6.getLabelInsets();
    double var10 = var8.extendHeight(100.0d);
    var0.setTickLabelInsets(var8);
    var0.setTickMarksVisible(false);
    boolean var14 = var0.isVerticalTickLabels();
    boolean var15 = var0.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    float var5 = var4.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
    boolean var7 = var4.isVerticalTickLabels();
    java.awt.Shape var8 = var4.getRightArrow();
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var12 = var11.darker();
    int var13 = var12.getBlue();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var15 = null;
    var14.setOutlineStroke(var15);
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var14.axisChanged(var17);
    org.jfree.chart.event.PlotChangeListener var19 = null;
    var14.addChangeListener(var19);
    org.jfree.chart.axis.ValueAxis var22 = var14.getRangeAxis((-1));
    java.awt.Stroke var23 = var14.getRangeCrosshairStroke();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var25 = null;
    var24.setOutlineStroke(var25);
    org.jfree.chart.event.AxisChangeEvent var27 = null;
    var24.axisChanged(var27);
    var24.setRangeGridlinesVisible(false);
    boolean var31 = var24.isRangeCrosshairVisible();
    java.awt.Stroke var32 = var24.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var34 = var24.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var35 = null;
    var24.notifyListeners(var35);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
    float var38 = var37.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var39 = var37.getLabelInsets();
    boolean var40 = var37.isVerticalTickLabels();
    boolean var41 = var37.isNegativeArrowVisible();
    boolean var42 = var37.isNegativeArrowVisible();
    int var43 = var24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var37);
    java.awt.Paint var44 = var24.getRangeCrosshairPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem(var0, "", "", "java.awt.Color[r=0,g=0,b=1]", var8, (java.awt.Paint)var12, var23, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.event.PlotChangeListener var5 = null;
    var0.addChangeListener(var5);
    org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
    java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisLocation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var10, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    float var2 = var1.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isVerticalTickLabels();
    org.jfree.chart.axis.ValueAxis[] var5 = new org.jfree.chart.axis.ValueAxis[] { var1};
    var0.setRangeAxes(var5);
    org.jfree.chart.util.RectangleInsets var7 = var0.getAxisOffset();
    var0.zoom(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     java.awt.Stroke var11 = var0.getDomainGridlineStroke();
//     boolean var12 = var0.isRangeCrosshairLockedOnData();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     float var18 = var17.getTickMarkOutsideLength();
//     var17.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.AxisState var23 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     java.util.List var26 = var17.refreshTicks(var22, var23, var24, var25);
//     var23.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     float var30 = var29.getTickMarkOutsideLength();
//     var29.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var37 = var36.getBounds();
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var29.valueToJava2D(100.0d, var37, var38);
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     java.util.List var41 = var15.refreshTicks(var16, var23, var37, var40);
//     var0.drawBackgroundImage(var13, var37);
//     org.jfree.data.general.DatasetGroup var43 = var0.getDatasetGroup();
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var46 = null;
//     var45.setOutlineStroke(var46);
//     org.jfree.chart.event.AxisChangeEvent var48 = null;
//     var45.axisChanged(var48);
//     java.awt.Paint var50 = var45.getRangeGridlinePaint();
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var56 = java.awt.Color.getColor("", 10);
//     var53.setTickMarkPaint((java.awt.Paint)var56);
//     org.jfree.chart.axis.TickUnitSource var58 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var53.setStandardTickUnits(var58);
//     org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var63 = var62.getBounds();
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var53.lengthToJava2D((-1.0d), var63, var64);
//     org.jfree.chart.ChartRenderingInfo var67 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var68 = new org.jfree.chart.plot.PlotRenderingInfo(var67);
//     boolean var69 = var45.render(var51, var63, 10, var68);
//     java.awt.geom.Rectangle2D var70 = null;
//     org.jfree.chart.util.RectangleAnchor var71 = null;
//     java.awt.geom.Point2D var72 = org.jfree.chart.util.RectangleAnchor.coordinates(var70, var71);
//     org.jfree.chart.plot.PlotState var73 = null;
//     org.jfree.chart.ChartRenderingInfo var74 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var75 = new org.jfree.chart.plot.PlotRenderingInfo(var74);
//     var0.draw(var44, var63, var72, var73, var75);
//     
//     // Checks the contract:  equals-hashcode on var36 and var62
//     assertTrue("Contract failed: equals-hashcode on var36 and var62", var36.equals(var62) ? var36.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var36
//     assertTrue("Contract failed: equals-hashcode on var62 and var36", var62.equals(var36) ? var62.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var75
//     assertTrue("Contract failed: equals-hashcode on var68 and var75", var68.equals(var75) ? var68.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var68
//     assertTrue("Contract failed: equals-hashcode on var75 and var68", var75.equals(var68) ? var75.hashCode() == var68.hashCode() : true);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var33 = var32.clone();
//     org.jfree.chart.util.VerticalAlignment var34 = var32.getVerticalAlignment();
//     var30.removeSubtitle((org.jfree.chart.title.Title)var32);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var38 = null;
//     var37.setOutlineStroke(var38);
//     org.jfree.chart.event.AxisChangeEvent var40 = null;
//     var37.axisChanged(var40);
//     var37.setRangeGridlinesVisible(false);
//     boolean var44 = var37.isRangeCrosshairVisible();
//     java.awt.Stroke var45 = var37.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var46 = var37.getDataset();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     float var49 = var48.getTickMarkOutsideLength();
//     var48.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var55 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var56 = var55.getBounds();
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var48.valueToJava2D(100.0d, var56, var57);
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleAnchor var60 = null;
//     java.awt.geom.Point2D var61 = org.jfree.chart.util.RectangleAnchor.coordinates(var59, var60);
//     org.jfree.chart.plot.PlotState var62 = null;
//     org.jfree.chart.ChartRenderingInfo var63 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var64 = new org.jfree.chart.plot.PlotRenderingInfo(var63);
//     var37.draw(var47, var56, var61, var62, var64);
//     org.jfree.chart.ChartRenderingInfo var66 = null;
//     var30.draw(var36, var56, var66);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.VerticalAlignment var2 = var0.getVerticalAlignment();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    float var6 = var5.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var7 = var5.getLabelInsets();
    java.text.NumberFormat var8 = var5.getNumberFormatOverride();
    boolean var9 = var5.getAutoRangeStickyZero();
    org.jfree.data.Range var12 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var15 = org.jfree.data.Range.expand(var12, 1.0E-8d, 0.0d);
    var5.setRange(var12);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(0.0d, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var18 = var0.arrange(var3, var17);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var4 = java.awt.Color.getColor("", 10);
    var1.setTickMarkPaint((java.awt.Paint)var4);
    var1.resizeRange((-1.0000000000000001E-16d), (-1.0d));
    var1.setAutoRangeIncludesZero(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize((-1.99999999d), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     java.awt.Paint var5 = var0.getRangeGridlinePaint();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var11 = java.awt.Color.getColor("", 10);
//     var8.setTickMarkPaint((java.awt.Paint)var11);
//     org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var8.setStandardTickUnits(var13);
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var18 = var17.getBounds();
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var8.lengthToJava2D((-1.0d), var18, var19);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     boolean var24 = var0.render(var6, var18, 10, var23);
//     int var25 = var23.getSubplotCount();
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     int var28 = var27.getSubplotCount();
//     java.awt.geom.Rectangle2D var29 = null;
//     var27.setDataArea(var29);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var32 = null;
//     var31.setOutlineStroke(var32);
//     org.jfree.chart.event.AxisChangeEvent var34 = null;
//     var31.axisChanged(var34);
//     java.awt.Paint var36 = var31.getRangeGridlinePaint();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var42 = java.awt.Color.getColor("", 10);
//     var39.setTickMarkPaint((java.awt.Paint)var42);
//     org.jfree.chart.axis.TickUnitSource var44 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var39.setStandardTickUnits(var44);
//     org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var49 = var48.getBounds();
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var39.lengthToJava2D((-1.0d), var49, var50);
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
//     boolean var55 = var31.render(var37, var49, 10, var54);
//     var27.addSubplotInfo(var54);
//     java.awt.Font var58 = null;
//     java.awt.Color var61 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var62 = var61.darker();
//     int var63 = var62.getBlue();
//     org.jfree.chart.text.TextBlock var64 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, (java.awt.Paint)var62);
//     org.jfree.chart.util.HorizontalAlignment var65 = var64.getLineAlignment();
//     boolean var66 = var54.equals((java.lang.Object)var65);
//     var23.addSubplotInfo(var54);
//     
//     // Checks the contract:  equals-hashcode on var0 and var31
//     assertTrue("Contract failed: equals-hashcode on var0 and var31", var0.equals(var31) ? var0.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var44
//     assertTrue("Contract failed: equals-hashcode on var13 and var44", var13.equals(var44) ? var13.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var13
//     assertTrue("Contract failed: equals-hashcode on var44 and var13", var44.equals(var13) ? var44.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var48
//     assertTrue("Contract failed: equals-hashcode on var17 and var48", var17.equals(var48) ? var17.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var17
//     assertTrue("Contract failed: equals-hashcode on var48 and var17", var48.equals(var17) ? var48.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.event.PlotChangeListener var5 = null;
    var0.addChangeListener(var5);
    org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
    java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var0.setDomainAxis(100, var12);
    org.jfree.chart.LegendItemCollection var14 = var0.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     java.awt.Stroke var11 = var0.getDomainGridlineStroke();
//     boolean var12 = var0.isRangeCrosshairLockedOnData();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     float var18 = var17.getTickMarkOutsideLength();
//     var17.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.AxisState var23 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     java.util.List var26 = var17.refreshTicks(var22, var23, var24, var25);
//     var23.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     float var30 = var29.getTickMarkOutsideLength();
//     var29.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var37 = var36.getBounds();
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var29.valueToJava2D(100.0d, var37, var38);
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     java.util.List var41 = var15.refreshTicks(var16, var23, var37, var40);
//     var0.drawBackgroundImage(var13, var37);
//     org.jfree.data.general.DatasetGroup var43 = var0.getDatasetGroup();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var45 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     org.jfree.data.KeyedObjects2D var46 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var47 = var46.getRowKeys();
//     boolean var48 = var45.equals((java.lang.Object)var46);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var50 = null;
//     var49.setOutlineStroke(var50);
//     org.jfree.chart.event.AxisChangeEvent var52 = null;
//     var49.axisChanged(var52);
//     var49.setRangeGridlinesVisible(false);
//     boolean var56 = var49.isRangeCrosshairVisible();
//     java.awt.Stroke var57 = var49.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var59 = var49.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var60 = null;
//     var49.notifyListeners(var60);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = var49.getRenderer(100);
//     org.jfree.chart.util.Layer var65 = null;
//     java.util.Collection var66 = var49.getDomainMarkers(0, var65);
//     org.jfree.chart.axis.AxisLocation var68 = var49.getRangeAxisLocation(10);
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var72 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var73 = var72.darker();
//     var69.setLabelPaint((java.awt.Paint)var72);
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis();
//     float var76 = var75.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var77 = var75.getLabelInsets();
//     double var79 = var77.extendHeight(100.0d);
//     var69.setTickLabelInsets(var77);
//     boolean var81 = var68.equals((java.lang.Object)var77);
//     boolean var82 = var45.equals((java.lang.Object)var68);
//     var0.setRangeAxisLocation(15, var68);
//     
//     // Checks the contract:  equals-hashcode on var49 and var0
//     assertTrue("Contract failed: equals-hashcode on var49 and var0", var49.equals(var0) ? var49.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var49 and var0.", var49.equals(var0) == var0.equals(var49));
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.KeyedObjects2D var14 = new org.jfree.data.KeyedObjects2D();
    java.util.List var15 = var14.getRowKeys();
    boolean var16 = var13.equals((java.lang.Object)var14);
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var13);
    org.jfree.data.category.CategoryDataset var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var20 = var13.generateLabel(var18, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     float var2 = var1.getAlpha();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var8 = var7.darker();
//     var4.setLabelPaint((java.awt.Paint)var7);
//     float[] var13 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var14 = var7.getColorComponents(var13);
//     java.awt.Color var15 = java.awt.Color.getColor("", var7);
//     var1.setPaint((java.awt.Paint)var15);
//     java.lang.Class var17 = null;
//     java.util.EventListener[] var18 = var1.getListeners(var17);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, (-1.99999999d), 0.2d, 0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var30.setAntiAlias(false);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     float var35 = var34.getAlpha();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var40 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var41 = var40.darker();
//     var37.setLabelPaint((java.awt.Paint)var40);
//     float[] var46 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var47 = var40.getColorComponents(var46);
//     java.awt.Color var48 = java.awt.Color.getColor("", var40);
//     var34.setPaint((java.awt.Paint)var48);
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     float var53 = var52.getTickMarkOutsideLength();
//     var52.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var60 = var59.getBounds();
//     org.jfree.chart.util.RectangleEdge var61 = null;
//     double var62 = var52.valueToJava2D(100.0d, var60, var61);
//     java.awt.geom.AffineTransform var63 = null;
//     java.awt.RenderingHints var64 = null;
//     java.awt.PaintContext var65 = var48.createContext(var50, var51, var60, var63, var64);
//     var30.setBackgroundPaint((java.awt.Paint)var48);
//     
//     // Checks the contract:  equals-hashcode on var19 and var59
//     assertTrue("Contract failed: equals-hashcode on var19 and var59", var19.equals(var59) ? var19.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var19
//     assertTrue("Contract failed: equals-hashcode on var59 and var19", var59.equals(var19) ? var59.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.data.statistics.MeanAndStandardDeviation var3 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)10, (java.lang.Number)1L);
    java.lang.Number var4 = var3.getMean();
    boolean var5 = var0.equals((java.lang.Object)var3);
    java.awt.Font var7 = null;
    java.awt.Color var10 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var11 = var10.darker();
    int var12 = var11.getBlue();
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, (java.awt.Paint)var11);
    org.jfree.chart.util.HorizontalAlignment var14 = var13.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 1.0E-8d, (-1.0d));
    org.jfree.chart.block.BlockContainer var19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var18);
    java.util.List var20 = var19.getBlocks();
    java.awt.Graphics2D var21 = null;
    org.jfree.data.Range var23 = null;
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(10.0d, var23);
    double var25 = var24.getHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var26 = var0.arrange(var19, var21, var24);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 10+ "'", var4.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     java.awt.RenderingHints var31 = null;
//     var30.setRenderingHints(var31);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.setRangeGridlinesVisible(false);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.awt.Stroke var9 = var1.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    float var13 = var12.getTickMarkOutsideLength();
    var12.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var20 = var19.getBounds();
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var12.valueToJava2D(100.0d, var20, var21);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
    org.jfree.chart.plot.PlotState var26 = null;
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    var1.draw(var11, var20, var25, var26, var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
    org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var33 = var32.clone();
    org.jfree.chart.util.VerticalAlignment var34 = var32.getVerticalAlignment();
    var30.removeSubtitle((org.jfree.chart.title.Title)var32);
    org.jfree.chart.ChartRenderingInfo var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var39 = var30.createBufferedImage(100, 0, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!", var3, "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var7.setVersion("hi!");
    var7.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.String var12 = var7.getVersion();
    java.lang.String var13 = var7.getInfo();
    java.lang.String var14 = var7.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "hi!"+ "'", var12.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "hi!"+ "'", var13.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    java.lang.String var3 = var2.getEmail();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"+ "'", var3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]"));

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
//     java.awt.Paint var32 = var30.getBackgroundPaint();
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     var30.handleClick(0, (-1), var35);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    var25.setDatasetIndex(0);
    var25.setSeriesKey((java.lang.Comparable)"RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.String var30 = var25.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var30.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var30.setAntiAlias(false);
//     org.jfree.chart.title.LegendTitle var34 = var30.getLegend(255);
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle();
//     var35.setToolTipText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis();
//     float var42 = var41.getTickMarkOutsideLength();
//     var41.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var46 = null;
//     org.jfree.chart.axis.AxisState var47 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleEdge var49 = null;
//     java.util.List var50 = var41.refreshTicks(var46, var47, var48, var49);
//     var47.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     float var54 = var53.getTickMarkOutsideLength();
//     var53.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var60 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var61 = var60.getBounds();
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     double var63 = var53.valueToJava2D(100.0d, var61, var62);
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     java.util.List var65 = var39.refreshTicks(var40, var47, var61, var64);
//     java.awt.Shape var66 = var39.getLeftArrow();
//     java.awt.Font var67 = var39.getLabelFont();
//     var35.setFont(var67);
//     var30.setTitle(var35);
//     
//     // Checks the contract:  equals-hashcode on var19 and var60
//     assertTrue("Contract failed: equals-hashcode on var19 and var60", var19.equals(var60) ? var19.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var19
//     assertTrue("Contract failed: equals-hashcode on var60 and var19", var60.equals(var19) ? var60.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.event.PlotChangeListener var5 = null;
    var0.addChangeListener(var5);
    org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
    java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var0.setDomainAxis(100, var12);
    var12.addCategoryLabelToolTip((java.lang.Comparable)1.0f, "AxisLocation.BOTTOM_OR_RIGHT");
    double var17 = var12.getCategoryMargin();
    java.lang.Comparable var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Font var19 = var12.getTickLabelFont(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var3 = null;
//     var2.setOutlineStroke(var3);
//     org.jfree.chart.event.AxisChangeEvent var5 = null;
//     var2.axisChanged(var5);
//     var2.clearAnnotations();
//     var1.addChangeListener((org.jfree.chart.event.RendererChangeListener)var2);
//     java.awt.Shape var10 = var1.getSeriesShape(1);
//     java.awt.Paint var12 = var1.lookupSeriesFillPaint((-1));
//     boolean var13 = var1.getIncludeBaseInRange();
//     java.awt.Font var14 = var1.getBaseItemLabelFont();
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var17 = null;
//     var16.setOutlineStroke(var17);
//     org.jfree.chart.event.AxisChangeEvent var19 = null;
//     var16.axisChanged(var19);
//     var16.clearAnnotations();
//     var15.addChangeListener((org.jfree.chart.event.RendererChangeListener)var16);
//     java.awt.Shape var24 = var15.getSeriesShape(1);
//     java.awt.Paint var26 = var15.lookupSeriesFillPaint((-1));
//     boolean var27 = var15.getIncludeBaseInRange();
//     java.awt.Font var28 = var15.getBaseItemLabelFont();
//     org.jfree.chart.ChartColor var32 = new org.jfree.chart.ChartColor(0, 0, 100);
//     var15.setBaseItemLabelPaint((java.awt.Paint)var32);
//     java.awt.Paint var35 = var15.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.text.TextLine var36 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var14, var35);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    var0.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.event.MarkerChangeEvent var12 = null;
    var0.markerChanged(var12);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    float var15 = var14.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var16 = var14.getLabelInsets();
    org.jfree.data.Range var17 = var14.getRange();
    org.jfree.data.Range var18 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    java.awt.Paint var19 = var14.getLabelPaint();
    var14.resizeRange(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     float var5 = var4.getTickMarkOutsideLength();
//     var4.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var4.refreshTicks(var9, var10, var11, var12);
//     var10.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     float var17 = var16.getTickMarkOutsideLength();
//     var16.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var24 = var23.getBounds();
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var16.valueToJava2D(100.0d, var24, var25);
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     java.util.List var28 = var2.refreshTicks(var3, var10, var24, var27);
//     java.awt.Shape var29 = var2.getLeftArrow();
//     java.awt.Font var30 = var2.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var32 = null;
//     var31.setOutlineStroke(var32);
//     org.jfree.chart.event.AxisChangeEvent var34 = null;
//     var31.axisChanged(var34);
//     var31.setRangeGridlinesVisible(false);
//     org.jfree.chart.axis.CategoryAxis var38 = var31.getDomainAxis();
//     java.awt.Paint var39 = var31.getBackgroundPaint();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var30, var39);
//     java.awt.Font var41 = var40.getFont();
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var45 = null;
//     var44.setOutlineStroke(var45);
//     org.jfree.chart.event.AxisChangeEvent var47 = null;
//     var44.axisChanged(var47);
//     var44.clearAnnotations();
//     var43.addChangeListener((org.jfree.chart.event.RendererChangeListener)var44);
//     java.awt.Shape var52 = var43.getSeriesShape(1);
//     java.awt.Paint var54 = var43.lookupSeriesFillPaint((-1));
//     boolean var55 = var43.getIncludeBaseInRange();
//     java.awt.Font var56 = var43.getBaseItemLabelFont();
//     var43.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var63 = var43.getItemLabelGenerator(10, 0);
//     java.awt.Stroke var64 = var43.getBaseOutlineStroke();
//     boolean var66 = var43.isSeriesVisibleInLegend(0);
//     org.jfree.chart.block.LabelBlock var68 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var71 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var72 = var71.darker();
//     var68.setPaint((java.awt.Paint)var72);
//     var43.setBaseItemLabelPaint((java.awt.Paint)var72, false);
//     org.jfree.chart.renderer.category.BarRenderer var76 = new org.jfree.chart.renderer.category.BarRenderer();
//     var76.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var79 = var76.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var80 = var79.getItemLabelAnchor();
//     var43.setNegativeItemLabelPositionFallback(var79);
//     org.jfree.chart.text.TextAnchor var82 = var79.getTextAnchor();
//     float var83 = var40.calculateBaselineOffset(var42, var82);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var6 = java.awt.Color.getColor("", 10);
//     var3.setTickMarkPaint((java.awt.Paint)var6);
//     var0.setSeriesItemLabelPaint(100, (java.awt.Paint)var6, true);
//     org.jfree.chart.LegendItem var12 = var0.getLegendItem(0, (-1));
//     org.jfree.chart.urls.CategoryURLGenerator var14 = null;
//     var0.setSeriesURLGenerator(1, var14, false);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var0.getBasePositiveItemLabelPosition();
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var20 = null;
//     var19.setOutlineStroke(var20);
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var19.axisChanged(var22);
//     var19.clearAnnotations();
//     var18.addChangeListener((org.jfree.chart.event.RendererChangeListener)var19);
//     java.awt.Shape var27 = var18.getSeriesShape(1);
//     java.awt.Paint var29 = var18.lookupSeriesFillPaint((-1));
//     boolean var30 = var18.getIncludeBaseInRange();
//     java.awt.Font var31 = var18.getBaseItemLabelFont();
//     var18.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var38 = var18.getItemLabelGenerator(10, 0);
//     java.awt.Stroke var39 = var18.getBaseOutlineStroke();
//     boolean var41 = var18.isSeriesVisibleInLegend(0);
//     org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var47 = var46.darker();
//     var43.setPaint((java.awt.Paint)var47);
//     var18.setBaseItemLabelPaint((java.awt.Paint)var47, false);
//     org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
//     var51.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var54 = var51.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var55 = var54.getItemLabelAnchor();
//     var18.setNegativeItemLabelPositionFallback(var54);
//     org.jfree.chart.text.TextAnchor var57 = var54.getTextAnchor();
//     boolean var58 = var17.equals((java.lang.Object)var57);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var51 and var0.", var51.equals(var0) == var0.equals(var51));
//     
//     // Checks the contract:  equals-hashcode on var17 and var54
//     assertTrue("Contract failed: equals-hashcode on var17 and var54", var17.equals(var54) ? var17.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var17
//     assertTrue("Contract failed: equals-hashcode on var54 and var17", var54.equals(var17) ? var54.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    java.awt.Font var13 = var0.getBaseItemLabelFont();
    var0.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    var19.setLabelPaint((java.awt.Paint)var22);
    var0.setSeriesItemLabelPaint(255, (java.awt.Paint)var22);
    java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var29 = var28.darker();
    int var30 = var29.getBlue();
    float[] var34 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var35 = var29.getColorComponents(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var36 = var22.getComponents(var35);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.KeyedObjects2D var1 = new org.jfree.data.KeyedObjects2D();
    java.util.List var2 = var1.getRowKeys();
    boolean var3 = var0.equals((java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeColumn((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var0.addChangeListener(var5);
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
//     java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var0.setDomainAxis(100, var12);
//     var12.removeCategoryLabelToolTip((java.lang.Comparable)1.0d);
//     java.awt.Font var16 = var12.getTickLabelFont();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     var17.setToolTipText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     float var24 = var23.getTickMarkOutsideLength();
//     var23.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.axis.AxisState var29 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     java.util.List var32 = var23.refreshTicks(var28, var29, var30, var31);
//     var29.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
//     float var36 = var35.getTickMarkOutsideLength();
//     var35.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var42 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var43 = var42.getBounds();
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var35.valueToJava2D(100.0d, var43, var44);
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     java.util.List var47 = var21.refreshTicks(var22, var29, var43, var46);
//     java.awt.Shape var48 = var21.getLeftArrow();
//     java.awt.Font var49 = var21.getLabelFont();
//     var17.setFont(var49);
//     var12.setTickLabelFont(var49);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis();
//     float var54 = var53.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var55 = var53.getLabelInsets();
//     boolean var56 = var53.isVerticalTickLabels();
//     boolean var57 = var53.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var60 = null;
//     var59.setOutlineStroke(var60);
//     org.jfree.chart.event.AxisChangeEvent var62 = null;
//     var59.axisChanged(var62);
//     var59.clearAnnotations();
//     var58.addChangeListener((org.jfree.chart.event.RendererChangeListener)var59);
//     java.awt.Shape var67 = var58.getSeriesShape(1);
//     java.awt.Paint var69 = var58.lookupSeriesFillPaint((-1));
//     boolean var70 = var58.getIncludeBaseInRange();
//     java.awt.Font var71 = var58.getBaseItemLabelFont();
//     var53.setTickLabelFont(var71);
//     var12.setTickLabelFont((java.lang.Comparable)(byte)(-1), var71);
//     
//     // Checks the contract:  equals-hashcode on var59 and var0
//     assertTrue("Contract failed: equals-hashcode on var59 and var0", var59.equals(var0) ? var59.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var59 and var0.", var59.equals(var0) == var0.equals(var59));
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var5 = org.jfree.data.Range.expand(var2, 1.0E-8d, 0.0d);
    org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var11 = org.jfree.data.Range.expand(var8, 1.0E-8d, 0.0d);
    org.jfree.data.Range var12 = org.jfree.data.Range.combine(var5, var11);
    double var13 = var12.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.99999995E-9d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!", var3, "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var7.setVersion("hi!");
    var7.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.String var12 = var7.getLicenceText();
    org.jfree.chart.ui.Library var17 = new org.jfree.chart.ui.Library("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "AxisLocation.BOTTOM_OR_RIGHT");
    var7.addLibrary(var17);
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var21 = var20.getMargin();
    var20.setHeight(0.0d);
    java.awt.Paint var24 = var20.getPaint();
    boolean var25 = var7.equals((java.lang.Object)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     var1.setToolTipText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     float var8 = var7.getTickMarkOutsideLength();
//     var7.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.AxisState var13 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     java.util.List var16 = var7.refreshTicks(var12, var13, var14, var15);
//     var13.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
//     float var20 = var19.getTickMarkOutsideLength();
//     var19.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var27 = var26.getBounds();
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var19.valueToJava2D(100.0d, var27, var28);
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     java.util.List var31 = var5.refreshTicks(var6, var13, var27, var30);
//     java.awt.Shape var32 = var5.getLeftArrow();
//     java.awt.Font var33 = var5.getLabelFont();
//     var1.setFont(var33);
//     org.jfree.chart.ChartColor var38 = new org.jfree.chart.ChartColor(0, 0, 100);
//     org.jfree.chart.text.TextMeasurer var40 = null;
//     org.jfree.chart.text.TextBlock var41 = org.jfree.chart.text.TextUtilities.createTextBlock("[size=1]", var33, (java.awt.Paint)var38, 0.0f, var40);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var0.addChangeListener(var5);
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
//     java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var0.setDomainAxis(100, var12);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var20 = var19.darker();
//     var16.setLabelPaint((java.awt.Paint)var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
//     float var23 = var22.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var24 = var22.getLabelInsets();
//     double var26 = var24.extendHeight(100.0d);
//     var16.setTickLabelInsets(var24);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     float var29 = var28.getTickMarkOutsideLength();
//     var28.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var36 = var35.getBounds();
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var28.valueToJava2D(100.0d, var36, var37);
//     java.awt.geom.Rectangle2D var41 = var24.createInsetRectangle(var36, true, false);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis();
//     float var43 = var42.getTickMarkOutsideLength();
//     org.jfree.chart.block.LineBorder var45 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var46 = var45.getInsets();
//     java.lang.String var47 = var46.toString();
//     double var48 = var46.getRight();
//     org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var51 = null;
//     var50.setOutlineStroke(var51);
//     org.jfree.chart.event.AxisChangeEvent var53 = null;
//     var50.axisChanged(var53);
//     var50.clearAnnotations();
//     var49.addChangeListener((org.jfree.chart.event.RendererChangeListener)var50);
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     var50.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
//     org.jfree.chart.util.RectangleInsets var59 = var50.getInsets();
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var61 = null;
//     var60.setOutlineStroke(var61);
//     org.jfree.chart.event.AxisChangeEvent var63 = null;
//     var60.axisChanged(var63);
//     java.awt.Paint var65 = var60.getRangeGridlinePaint();
//     java.awt.Graphics2D var66 = null;
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var71 = java.awt.Color.getColor("", 10);
//     var68.setTickMarkPaint((java.awt.Paint)var71);
//     org.jfree.chart.axis.TickUnitSource var73 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var68.setStandardTickUnits(var73);
//     org.jfree.chart.block.LabelBlock var77 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var78 = var77.getBounds();
//     org.jfree.chart.util.RectangleEdge var79 = null;
//     double var80 = var68.lengthToJava2D((-1.0d), var78, var79);
//     org.jfree.chart.ChartRenderingInfo var82 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var83 = new org.jfree.chart.plot.PlotRenderingInfo(var82);
//     boolean var84 = var60.render(var66, var78, 10, var83);
//     var59.trim(var78);
//     var46.trim(var78);
//     org.jfree.chart.plot.CategoryPlot var87 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var88 = null;
//     var87.setOutlineStroke(var88);
//     org.jfree.chart.event.AxisChangeEvent var90 = null;
//     var87.axisChanged(var90);
//     var87.setRangeGridlinesVisible(false);
//     boolean var94 = var87.isRangeCrosshairVisible();
//     java.awt.Stroke var95 = var87.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var97 = var87.getDomainAxisEdge(100);
//     double var98 = var42.java2DToValue(0.0d, var78, var97);
//     double var99 = var12.getCategoryEnd(100, 0, var36, var97);
//     
//     // Checks the contract:  equals-hashcode on var60 and var0
//     assertTrue("Contract failed: equals-hashcode on var60 and var0", var60.equals(var0) ? var60.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var60 and var0.", var60.equals(var0) == var0.equals(var60));
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var3 = null;
//     var2.setOutlineStroke(var3);
//     org.jfree.chart.event.AxisChangeEvent var5 = null;
//     var2.axisChanged(var5);
//     var2.setRangeGridlinesVisible(false);
//     boolean var9 = var2.isRangeCrosshairVisible();
//     java.awt.Stroke var10 = var2.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var12 = var2.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var13 = var1.getLabelPosition(var12);
//     org.jfree.chart.axis.CategoryLabelPosition var14 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.util.RectangleAnchor var15 = var14.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var19 = null;
//     var18.setOutlineStroke(var19);
//     org.jfree.chart.event.AxisChangeEvent var21 = null;
//     var18.axisChanged(var21);
//     var18.setRangeGridlinesVisible(false);
//     boolean var25 = var18.isRangeCrosshairVisible();
//     java.awt.Stroke var26 = var18.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var28 = var18.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var29 = var17.getLabelPosition(var28);
//     org.jfree.chart.axis.CategoryLabelPositions var30 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var32 = null;
//     var31.setOutlineStroke(var32);
//     org.jfree.chart.event.AxisChangeEvent var34 = null;
//     var31.axisChanged(var34);
//     var31.setRangeGridlinesVisible(false);
//     boolean var38 = var31.isRangeCrosshairVisible();
//     java.awt.Stroke var39 = var31.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var41 = var31.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var42 = var30.getLabelPosition(var41);
//     float var43 = var42.getWidthRatio();
//     org.jfree.chart.axis.CategoryLabelPositions var44 = new org.jfree.chart.axis.CategoryLabelPositions(var13, var14, var29, var42);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var31
//     assertTrue("Contract failed: equals-hashcode on var2 and var31", var2.equals(var31) ? var2.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var31
//     assertTrue("Contract failed: equals-hashcode on var18 and var31", var18.equals(var31) ? var18.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var2
//     assertTrue("Contract failed: equals-hashcode on var31 and var2", var31.equals(var2) ? var31.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var18
//     assertTrue("Contract failed: equals-hashcode on var31 and var18", var31.equals(var18) ? var31.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject(15, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getHorizontalAlignment();
    java.awt.Font var2 = var0.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    var0.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var8 = var7.getBounds();
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var0.valueToJava2D(100.0d, var8, var9);
    java.text.NumberFormat var11 = null;
    var0.setNumberFormatOverride(var11);
    org.jfree.data.Range var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDefaultAutoRange(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
//     boolean var12 = var0.getIncludeBaseInRange();
//     java.awt.Font var13 = var0.getBaseItemLabelFont();
//     var0.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var20 = var0.getItemLabelGenerator(10, 0);
//     java.awt.Stroke var21 = var0.getBaseOutlineStroke();
//     boolean var23 = var0.isSeriesVisibleInLegend(0);
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var29 = var28.darker();
//     var25.setPaint((java.awt.Paint)var29);
//     var0.setBaseItemLabelPaint((java.awt.Paint)var29, false);
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     var33.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var36 = var33.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var37 = var36.getItemLabelAnchor();
//     var0.setNegativeItemLabelPositionFallback(var36);
//     org.jfree.chart.text.TextAnchor var39 = var36.getTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
//     var40.setAutoPopulateSeriesOutlinePaint(false);
//     var40.setBaseSeriesVisible(true, false);
//     var40.setBaseSeriesVisibleInLegend(true, false);
//     org.jfree.chart.block.LabelBlock var51 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var54 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var55 = var54.darker();
//     var51.setPaint((java.awt.Paint)var55);
//     var40.setSeriesOutlinePaint(100, (java.awt.Paint)var55);
//     var40.setAutoPopulateSeriesStroke(false);
//     boolean var60 = var39.equals((java.lang.Object)false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var40.", var33.equals(var40) == var40.equals(var33));
//     
//     // Checks the contract:  equals-hashcode on var25 and var51
//     assertTrue("Contract failed: equals-hashcode on var25 and var51", var25.equals(var51) ? var25.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var25
//     assertTrue("Contract failed: equals-hashcode on var51 and var25", var51.equals(var25) ? var51.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Size2D[width=0.0, height=-1.99999999]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, (-4.0d), 2.0d, 0.5d, 106.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    java.lang.Comparable var0 = null;
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var4 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var1, "", "[size=1]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var5 = var4.darker();
//     var1.setPaint((java.awt.Paint)var5);
//     java.lang.String var7 = var1.getToolTipText();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var9 = var8.clone();
//     boolean var10 = var1.equals((java.lang.Object)var8);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.util.Size2D var12 = var1.arrange(var11);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var11 = null;
    var0.notifyListeners(var11);
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    var13.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var16 = var13.getBasePositiveItemLabelPosition();
    int var17 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    boolean var18 = var13.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     float var2 = var1.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
//     org.jfree.data.Range var4 = var1.getRange();
//     org.jfree.data.Range var5 = var1.getDefaultAutoRange();
//     java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var9 = var8.darker();
//     int var10 = var9.getBlue();
//     float[] var14 = new float[] { 0.0f, 1.0f, 0.0f};
//     float[] var15 = var9.getColorComponents(var14);
//     var1.setTickMarkPaint((java.awt.Paint)var9);
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var9};
//     java.awt.Paint[] var18 = null;
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var22 = var21.darker();
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var21};
//     java.awt.Font var25 = null;
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var29 = var28.darker();
//     int var30 = var29.getBlue();
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, (java.awt.Paint)var29);
//     java.awt.Paint[] var32 = new java.awt.Paint[] { var29};
//     java.awt.Stroke var33 = null;
//     java.awt.Stroke[] var34 = new java.awt.Stroke[] { var33};
//     java.awt.Stroke var35 = null;
//     java.awt.Stroke[] var36 = new java.awt.Stroke[] { var35};
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
//     java.awt.Shape[] var39 = new java.awt.Shape[] { var38};
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var18, var23, var32, var34, var36, var39);
//     java.awt.Paint[] var41 = null;
//     java.awt.Color var44 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var45 = var44.darker();
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var44};
//     java.awt.Font var48 = null;
//     java.awt.Color var51 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var52 = var51.darker();
//     int var53 = var52.getBlue();
//     org.jfree.chart.text.TextBlock var54 = org.jfree.chart.text.TextUtilities.createTextBlock("", var48, (java.awt.Paint)var52);
//     java.awt.Paint[] var55 = new java.awt.Paint[] { var52};
//     java.awt.Stroke var56 = null;
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
//     java.awt.Stroke var58 = null;
//     java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
//     java.awt.Shape[] var62 = new java.awt.Shape[] { var61};
//     org.jfree.chart.plot.DefaultDrawingSupplier var63 = new org.jfree.chart.plot.DefaultDrawingSupplier(var41, var46, var55, var57, var59, var62);
//     java.awt.Paint[] var64 = null;
//     java.awt.Color var67 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var68 = var67.darker();
//     java.awt.Paint[] var69 = new java.awt.Paint[] { var67};
//     java.awt.Font var71 = null;
//     java.awt.Color var74 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var75 = var74.darker();
//     int var76 = var75.getBlue();
//     org.jfree.chart.text.TextBlock var77 = org.jfree.chart.text.TextUtilities.createTextBlock("", var71, (java.awt.Paint)var75);
//     java.awt.Paint[] var78 = new java.awt.Paint[] { var75};
//     java.awt.Stroke var79 = null;
//     java.awt.Stroke[] var80 = new java.awt.Stroke[] { var79};
//     java.awt.Stroke var81 = null;
//     java.awt.Stroke[] var82 = new java.awt.Stroke[] { var81};
//     java.awt.Shape var84 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
//     java.awt.Shape[] var85 = new java.awt.Shape[] { var84};
//     org.jfree.chart.plot.DefaultDrawingSupplier var86 = new org.jfree.chart.plot.DefaultDrawingSupplier(var64, var69, var78, var80, var82, var85);
//     org.jfree.chart.plot.DefaultDrawingSupplier var87 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var17, var36, var59, var85);
//     
//     // Checks the contract:  equals-hashcode on var40 and var63
//     assertTrue("Contract failed: equals-hashcode on var40 and var63", var40.equals(var63) ? var40.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var86
//     assertTrue("Contract failed: equals-hashcode on var40 and var86", var40.equals(var86) ? var40.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var40
//     assertTrue("Contract failed: equals-hashcode on var63 and var40", var63.equals(var40) ? var63.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var86
//     assertTrue("Contract failed: equals-hashcode on var63 and var86", var63.equals(var86) ? var63.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var40
//     assertTrue("Contract failed: equals-hashcode on var86 and var40", var86.equals(var40) ? var86.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var63
//     assertTrue("Contract failed: equals-hashcode on var86 and var63", var86.equals(var63) ? var86.hashCode() == var63.hashCode() : true);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset(100);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    var11.setAutoPopulateSeriesOutlinePaint(false);
    var11.setBaseSeriesVisible(true, false);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var11.setNegativeItemLabelPositionFallback(var18);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setLegendItemLabelGenerator(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var3 = new org.jfree.chart.axis.CategoryLabelPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var6 = var5.darker();
    int var7 = var6.getBlue();
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var6);
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var12.axisChanged(var15);
    var12.clearAnnotations();
    var11.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    var12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.util.RectangleInsets var21 = var12.getInsets();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var23 = null;
    var22.setOutlineStroke(var23);
    org.jfree.chart.event.AxisChangeEvent var25 = null;
    var22.axisChanged(var25);
    java.awt.Paint var27 = var22.getRangeGridlinePaint();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var33 = java.awt.Color.getColor("", 10);
    var30.setTickMarkPaint((java.awt.Paint)var33);
    org.jfree.chart.axis.TickUnitSource var35 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var30.setStandardTickUnits(var35);
    org.jfree.chart.block.LabelBlock var39 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var40 = var39.getBounds();
    org.jfree.chart.util.RectangleEdge var41 = null;
    double var42 = var30.lengthToJava2D((-1.0d), var40, var41);
    org.jfree.chart.ChartRenderingInfo var44 = null;
    org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
    boolean var46 = var22.render(var28, var40, 10, var45);
    var21.trim(var40);
    java.awt.geom.AffineTransform var48 = null;
    java.awt.RenderingHints var49 = null;
    java.awt.PaintContext var50 = var6.createContext(var9, var10, var40, var48, var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var53 = var2.createInsetRectangle((java.awt.geom.Rectangle2D)var10, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    java.text.NumberFormat var3 = var0.getNumberFormatOverride();
    var0.setTickMarkOutsideLength((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var33 = var32.clone();
//     org.jfree.chart.util.VerticalAlignment var34 = var32.getVerticalAlignment();
//     var30.removeSubtitle((org.jfree.chart.title.Title)var32);
//     org.jfree.chart.event.PlotChangeEvent var36 = null;
//     var30.plotChanged(var36);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var2 = var1.getMargin();
//     var1.setHeight(0.0d);
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var7 = null;
//     var6.setOutlineStroke(var7);
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var6.axisChanged(var9);
//     var6.clearAnnotations();
//     var5.addChangeListener((org.jfree.chart.event.RendererChangeListener)var6);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     var6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.util.RectangleInsets var15 = var6.getInsets();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var17 = null;
//     var16.setOutlineStroke(var17);
//     org.jfree.chart.event.AxisChangeEvent var19 = null;
//     var16.axisChanged(var19);
//     java.awt.Paint var21 = var16.getRangeGridlinePaint();
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var27 = java.awt.Color.getColor("", 10);
//     var24.setTickMarkPaint((java.awt.Paint)var27);
//     org.jfree.chart.axis.TickUnitSource var29 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var24.setStandardTickUnits(var29);
//     org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var34 = var33.getBounds();
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var24.lengthToJava2D((-1.0d), var34, var35);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     boolean var40 = var16.render(var22, var34, 10, var39);
//     var15.trim(var34);
//     var1.setBounds(var34);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.setRangeGridlinesVisible(false);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.awt.Stroke var9 = var1.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    float var13 = var12.getTickMarkOutsideLength();
    var12.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var20 = var19.getBounds();
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var12.valueToJava2D(100.0d, var20, var21);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
    org.jfree.chart.plot.PlotState var26 = null;
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    var1.draw(var11, var20, var25, var26, var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
    java.awt.Paint var32 = var30.getBackgroundPaint();
    boolean var33 = var30.isBorderVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPositions var1 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var3 = null;
    var2.setOutlineStroke(var3);
    org.jfree.chart.event.AxisChangeEvent var5 = null;
    var2.axisChanged(var5);
    var2.setRangeGridlinesVisible(false);
    boolean var9 = var2.isRangeCrosshairVisible();
    java.awt.Stroke var10 = var2.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var12 = var2.getDomainAxisEdge(100);
    org.jfree.chart.axis.CategoryLabelPosition var13 = var1.getLabelPosition(var12);
    float var14 = var13.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var13);
    org.jfree.chart.axis.CategoryLabelPosition var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.setRangeGridlinesVisible(false);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.awt.Stroke var9 = var1.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    float var13 = var12.getTickMarkOutsideLength();
    var12.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var20 = var19.getBounds();
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var12.valueToJava2D(100.0d, var20, var21);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
    org.jfree.chart.plot.PlotState var26 = null;
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    var1.draw(var11, var20, var25, var26, var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var32 = var31.getHorizontalAlignment();
    var30.setTitle(var31);
    double var34 = var31.getHeight();
    java.awt.Font var36 = null;
    java.awt.Color var39 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var40 = var39.darker();
    int var41 = var40.getBlue();
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var40);
    org.jfree.chart.util.HorizontalAlignment var43 = var42.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var44 = null;
    org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 1.0E-8d, (-1.0d));
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var49 = var48.getBaseStroke();
    org.jfree.chart.urls.CategoryURLGenerator var50 = var48.getBaseURLGenerator();
    boolean var51 = var43.equals((java.lang.Object)var48);
    var31.setTextAlignment(var43);
    java.awt.Graphics2D var53 = null;
    org.jfree.data.Range var55 = null;
    org.jfree.chart.block.RectangleConstraint var56 = new org.jfree.chart.block.RectangleConstraint(10.0d, var55);
    double var57 = var56.getHeight();
    org.jfree.chart.block.RectangleConstraint var58 = var56.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var59 = var31.arrange(var53, var58);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var8 = null;
    var7.setOutlineStroke(var8);
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.clearAnnotations();
    var6.addChangeListener((org.jfree.chart.event.RendererChangeListener)var7);
    java.awt.Shape var15 = var6.getSeriesShape(1);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var19 = var18.darker();
    int var20 = var19.getBlue();
    var6.setBasePaint((java.awt.Paint)var19);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    float var27 = var26.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
    boolean var29 = var26.isVerticalTickLabels();
    java.awt.Shape var30 = var26.getRightArrow();
    org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity(var30);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    float var36 = var35.getTickMarkOutsideLength();
    var35.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.axis.AxisState var41 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.util.RectangleEdge var43 = null;
    java.util.List var44 = var35.refreshTicks(var40, var41, var42, var43);
    var41.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
    float var48 = var47.getTickMarkOutsideLength();
    var47.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var54 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var55 = var54.getBounds();
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var47.valueToJava2D(100.0d, var55, var56);
    org.jfree.chart.util.RectangleEdge var58 = null;
    java.util.List var59 = var33.refreshTicks(var34, var41, var55, var58);
    java.awt.Shape var60 = var33.getLeftArrow();
    boolean var61 = var31.equals((java.lang.Object)var60);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis();
    var62.setTickMarksVisible(false);
    java.awt.Stroke var65 = var62.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var69 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var70 = var69.darker();
    var66.setLabelPaint((java.awt.Paint)var69);
    float[] var75 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var76 = var69.getColorComponents(var75);
    org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var60, var65, (java.awt.Paint)var69);
    java.awt.Color var80 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var81 = var80.darker();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "", "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var5, (java.awt.Paint)var19, var65, (java.awt.Paint)var81);
    java.lang.String var83 = var82.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var83 + "' != '" + "hi!"+ "'", var83.equals("hi!"));

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var32 = var31.getHorizontalAlignment();
//     var30.setTitle(var31);
//     var30.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var38 = var37.clone();
//     org.jfree.chart.util.VerticalAlignment var39 = var37.getVerticalAlignment();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var42 = null;
//     var41.setOutlineStroke(var42);
//     org.jfree.chart.event.AxisChangeEvent var44 = null;
//     var41.axisChanged(var44);
//     var41.setRangeGridlinesVisible(false);
//     boolean var48 = var41.isRangeCrosshairVisible();
//     java.awt.Stroke var49 = var41.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var50 = var41.getDataset();
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     float var53 = var52.getTickMarkOutsideLength();
//     var52.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var60 = var59.getBounds();
//     org.jfree.chart.util.RectangleEdge var61 = null;
//     double var62 = var52.valueToJava2D(100.0d, var60, var61);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleAnchor var64 = null;
//     java.awt.geom.Point2D var65 = org.jfree.chart.util.RectangleAnchor.coordinates(var63, var64);
//     org.jfree.chart.plot.PlotState var66 = null;
//     org.jfree.chart.ChartRenderingInfo var67 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var68 = new org.jfree.chart.plot.PlotRenderingInfo(var67);
//     var41.draw(var51, var60, var65, var66, var68);
//     org.jfree.chart.JFreeChart var70 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var41);
//     org.jfree.chart.title.TextTitle var71 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var72 = var71.getHorizontalAlignment();
//     var70.setTitle(var71);
//     var37.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var70);
//     var30.addSubtitle(0, (org.jfree.chart.title.Title)var37);
//     
//     // Checks the contract:  equals-hashcode on var1 and var41
//     assertTrue("Contract failed: equals-hashcode on var1 and var41", var1.equals(var41) ? var1.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var1
//     assertTrue("Contract failed: equals-hashcode on var41 and var1", var41.equals(var1) ? var41.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var59
//     assertTrue("Contract failed: equals-hashcode on var19 and var59", var19.equals(var59) ? var19.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var19
//     assertTrue("Contract failed: equals-hashcode on var59 and var19", var59.equals(var19) ? var59.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var68
//     assertTrue("Contract failed: equals-hashcode on var28 and var68", var28.equals(var68) ? var28.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var28
//     assertTrue("Contract failed: equals-hashcode on var68 and var28", var68.equals(var28) ? var68.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    boolean var10 = var0.getAutoPopulateSeriesStroke();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var12.axisChanged(var15);
    var12.setRangeGridlinesVisible(false);
    boolean var19 = var12.isRangeCrosshairVisible();
    java.awt.Stroke var20 = var12.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var22 = var12.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var23 = null;
    var12.notifyListeners(var23);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
    float var26 = var25.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var27 = var25.getLabelInsets();
    boolean var28 = var25.isVerticalTickLabels();
    boolean var29 = var25.isNegativeArrowVisible();
    boolean var30 = var25.isNegativeArrowVisible();
    int var31 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Paint var32 = var12.getRangeCrosshairPaint();
    var0.setSeriesFillPaint(1, var32);
    org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var41 = java.awt.Color.getColor("", 10);
    var38.setTickMarkPaint((java.awt.Paint)var41);
    var35.setSeriesItemLabelPaint(100, (java.awt.Paint)var41, true);
    var35.setSeriesItemLabelsVisible(1, false);
    org.jfree.chart.labels.ItemLabelPosition var50 = var35.getNegativeItemLabelPosition(100, 1);
    var0.setSeriesNegativeItemLabelPosition(0, var50, true);
    double var53 = var50.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtBottom();
    java.util.List var2 = var0.getAxesAtBottom();
    java.util.List var3 = var0.getAxesAtRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     float var5 = var4.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getLabelInsets();
//     boolean var7 = var4.isVerticalTickLabels();
//     java.awt.Shape var8 = var4.getRightArrow();
//     org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
//     float var14 = var13.getTickMarkOutsideLength();
//     var13.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.axis.AxisState var19 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     java.util.List var22 = var13.refreshTicks(var18, var19, var20, var21);
//     var19.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     float var26 = var25.getTickMarkOutsideLength();
//     var25.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var33 = var32.getBounds();
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var25.valueToJava2D(100.0d, var33, var34);
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     java.util.List var37 = var11.refreshTicks(var12, var19, var33, var36);
//     java.awt.Shape var38 = var11.getLeftArrow();
//     boolean var39 = var9.equals((java.lang.Object)var38);
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     var40.setTickMarksVisible(false);
//     java.awt.Stroke var43 = var40.getTickMarkStroke();
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var48 = var47.darker();
//     var44.setLabelPaint((java.awt.Paint)var47);
//     float[] var53 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var54 = var47.getColorComponents(var53);
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var38, var43, (java.awt.Paint)var47);
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var58 = null;
//     var57.setOutlineStroke(var58);
//     org.jfree.chart.event.AxisChangeEvent var60 = null;
//     var57.axisChanged(var60);
//     var57.setRangeGridlinesVisible(false);
//     boolean var64 = var57.isRangeCrosshairVisible();
//     java.awt.Stroke var65 = var57.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var66 = var57.getDataset();
//     java.awt.Graphics2D var67 = null;
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis();
//     float var69 = var68.getTickMarkOutsideLength();
//     var68.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var76 = var75.getBounds();
//     org.jfree.chart.util.RectangleEdge var77 = null;
//     double var78 = var68.valueToJava2D(100.0d, var76, var77);
//     java.awt.geom.Rectangle2D var79 = null;
//     org.jfree.chart.util.RectangleAnchor var80 = null;
//     java.awt.geom.Point2D var81 = org.jfree.chart.util.RectangleAnchor.coordinates(var79, var80);
//     org.jfree.chart.plot.PlotState var82 = null;
//     org.jfree.chart.ChartRenderingInfo var83 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var84 = new org.jfree.chart.plot.PlotRenderingInfo(var83);
//     var57.draw(var67, var76, var81, var82, var84);
//     org.jfree.chart.JFreeChart var86 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var57);
//     org.jfree.chart.plot.CategoryPlot var87 = var86.getCategoryPlot();
//     var86.setBackgroundImageAlignment(1);
//     org.jfree.chart.event.ChartProgressEvent var92 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var47, var86, (-1), (-1));
//     
//     // Checks the contract:  equals-hashcode on var32 and var75
//     assertTrue("Contract failed: equals-hashcode on var32 and var75", var32.equals(var75) ? var32.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var32
//     assertTrue("Contract failed: equals-hashcode on var75 and var32", var75.equals(var32) ? var75.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var4 = var3.darker();
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var3};
//     java.awt.Font var7 = null;
//     java.awt.Color var10 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var11 = var10.darker();
//     int var12 = var11.getBlue();
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, (java.awt.Paint)var11);
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var11};
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
//     java.awt.Shape[] var21 = new java.awt.Shape[] { var20};
//     org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var5, var14, var16, var18, var21);
//     java.awt.Paint[] var23 = null;
//     java.awt.Color var26 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var27 = var26.darker();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var26};
//     java.awt.Font var30 = null;
//     java.awt.Color var33 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var34 = var33.darker();
//     int var35 = var34.getBlue();
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, (java.awt.Paint)var34);
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var34};
//     java.awt.Stroke var38 = null;
//     java.awt.Stroke[] var39 = new java.awt.Stroke[] { var38};
//     java.awt.Stroke var40 = null;
//     java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
//     java.awt.Shape[] var44 = new java.awt.Shape[] { var43};
//     org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier(var23, var28, var37, var39, var41, var44);
//     java.awt.Stroke[] var46 = null;
//     java.awt.Font var52 = null;
//     java.awt.Color var55 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var56 = var55.darker();
//     int var57 = var56.getBlue();
//     org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("", var52, (java.awt.Paint)var56);
//     org.jfree.chart.util.HorizontalAlignment var59 = var58.getLineAlignment();
//     java.awt.Graphics2D var60 = null;
//     org.jfree.chart.text.TextBlockAnchor var63 = null;
//     java.awt.Shape var67 = var58.calculateBounds(var60, 10.0f, (-1.0f), var63, (-1.0f), 1.0f, 1.0d);
//     java.awt.Color var71 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var67, (java.awt.Paint)var71);
//     java.text.AttributedString var73 = var72.getAttributedLabel();
//     boolean var74 = var72.isShapeOutlineVisible();
//     java.lang.String var75 = var72.getURLText();
//     java.awt.Stroke var76 = var72.getLineStroke();
//     java.awt.Stroke[] var77 = new java.awt.Stroke[] { var76};
//     java.awt.Shape[] var78 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var79 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var28, var46, var77, var78);
//     
//     // Checks the contract:  equals-hashcode on var22 and var45
//     assertTrue("Contract failed: equals-hashcode on var22 and var45", var22.equals(var45) ? var22.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var22
//     assertTrue("Contract failed: equals-hashcode on var45 and var22", var45.equals(var22) ? var45.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    var0.setAutoTickUnitSelection(false, false);
    java.lang.String var5 = var0.getLabel();
    var0.setAutoRangeMinimumSize(0.5d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    var0.removeObject((java.lang.Comparable)10.0d, (java.lang.Comparable)100);
    int var5 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)0.5f);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var7 = java.awt.Color.getColor("", 10);
//     var4.setTickMarkPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var14 = var13.darker();
//     var10.setLabelPaint((java.awt.Paint)var13);
//     float[] var19 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var20 = var13.getColorComponents(var19);
//     java.awt.Color var21 = java.awt.Color.getColor("", var13);
//     var4.setTickLabelPaint((java.awt.Paint)var21);
//     var0.setDomainGridlinePaint((java.awt.Paint)var21);
//     org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var25 = var24.getInsets();
//     java.lang.String var26 = var25.toString();
//     double var27 = var25.getRight();
//     double var29 = var25.calculateLeftInset(106.0d);
//     var0.setInsets(var25, true);
//     org.jfree.chart.util.RectangleInsets var32 = var0.getInsets();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     float var34 = var33.getTickMarkOutsideLength();
//     var33.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var40 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var41 = var40.getBounds();
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var33.valueToJava2D(100.0d, var41, var42);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.text.TextAnchor var46 = var45.getLabelTextAnchor();
//     org.jfree.chart.util.LengthAdjustmentType var47 = var45.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.text.TextAnchor var50 = var49.getLabelTextAnchor();
//     org.jfree.chart.util.LengthAdjustmentType var51 = var49.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var52 = var32.createAdjustedRectangle(var41, var47, var51);
//     
//     // Checks the contract:  equals-hashcode on var45 and var49
//     assertTrue("Contract failed: equals-hashcode on var45 and var49", var45.equals(var49) ? var45.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var45
//     assertTrue("Contract failed: equals-hashcode on var49 and var45", var49.equals(var45) ? var49.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    java.util.Set var3 = var0.keySet();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getMargin();
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var2.createInsetRectangle(var3, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var5 = null;
//     var4.setOutlineStroke(var5);
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var4.axisChanged(var7);
//     var4.setRangeGridlinesVisible(false);
//     boolean var11 = var4.isRangeCrosshairVisible();
//     java.awt.Stroke var12 = var4.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var14 = var4.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var15 = var3.getLabelPosition(var14);
//     org.jfree.chart.axis.CategoryLabelPositions var16 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var18 = null;
//     var17.setOutlineStroke(var18);
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var17.axisChanged(var20);
//     var17.setRangeGridlinesVisible(false);
//     boolean var24 = var17.isRangeCrosshairVisible();
//     java.awt.Stroke var25 = var17.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var27 = var17.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var28 = var16.getLabelPosition(var27);
//     org.jfree.chart.text.TextAnchor var29 = var28.getRotationAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var30 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var15, var28);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    java.lang.Object var4 = var0.handleGetObject("AxisLocation.BOTTOM_OR_RIGHT");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject("CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var10 = null;
//     var9.setOutlineStroke(var10);
//     org.jfree.chart.event.AxisChangeEvent var12 = null;
//     var9.axisChanged(var12);
//     var9.clearAnnotations();
//     var8.addChangeListener((org.jfree.chart.event.RendererChangeListener)var9);
//     java.awt.Shape var17 = var8.getSeriesShape(1);
//     java.awt.Paint var19 = var8.lookupSeriesFillPaint((-1));
//     boolean var20 = var8.getIncludeBaseInRange();
//     java.awt.Font var21 = var8.getBaseItemLabelFont();
//     var8.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var28 = var8.getItemLabelGenerator(10, 0);
//     java.awt.Stroke var29 = var8.getBaseOutlineStroke();
//     boolean var31 = var8.isSeriesVisibleInLegend(0);
//     org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var36 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var37 = var36.darker();
//     var33.setPaint((java.awt.Paint)var37);
//     var8.setBaseItemLabelPaint((java.awt.Paint)var37, false);
//     org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
//     var41.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var44 = var41.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var45 = var44.getItemLabelAnchor();
//     var8.setNegativeItemLabelPositionFallback(var44);
//     org.jfree.chart.text.TextAnchor var47 = var44.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=0.0, height=-1.99999999]", var1, 10.0f, 1.0f, var6, 10.0d, var47);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     float var2 = var1.getAlpha();
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var8 = var7.darker();
//     var4.setLabelPaint((java.awt.Paint)var7);
//     float[] var13 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var14 = var7.getColorComponents(var13);
//     java.awt.Color var15 = java.awt.Color.getColor("", var7);
//     var1.setPaint((java.awt.Paint)var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.text.TextAnchor var19 = var18.getLabelTextAnchor();
//     java.awt.Stroke var20 = var18.getStroke();
//     var1.setStroke(var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var23 = null;
//     var22.setOutlineStroke(var23);
//     org.jfree.chart.event.AxisChangeEvent var25 = null;
//     var22.axisChanged(var25);
//     var22.setRangeGridlinesVisible(false);
//     org.jfree.chart.event.AxisChangeEvent var29 = null;
//     var22.axisChanged(var29);
//     var1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var22);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var33 = null;
//     var32.setOutlineStroke(var33);
//     org.jfree.chart.event.AxisChangeEvent var35 = null;
//     var32.axisChanged(var35);
//     var32.setRangeGridlinesVisible(false);
//     boolean var39 = var32.isRangeCrosshairVisible();
//     java.awt.Stroke var40 = var32.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var42 = var32.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var43 = null;
//     var32.notifyListeners(var43);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     float var46 = var45.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var47 = var45.getLabelInsets();
//     boolean var48 = var45.isVerticalTickLabels();
//     boolean var49 = var45.isNegativeArrowVisible();
//     boolean var50 = var45.isNegativeArrowVisible();
//     int var51 = var32.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var45);
//     java.awt.Paint var52 = var32.getRangeCrosshairPaint();
//     var1.setOutlinePaint(var52);
//     
//     // Checks the contract:  equals-hashcode on var22 and var32
//     assertTrue("Contract failed: equals-hashcode on var22 and var32", var22.equals(var32) ? var22.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var22
//     assertTrue("Contract failed: equals-hashcode on var32 and var22", var32.equals(var22) ? var32.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     float var1 = var0.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
//     boolean var3 = var0.isVerticalTickLabels();
//     double var4 = var0.getLowerMargin();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
//     float var7 = var6.getTickMarkOutsideLength();
//     var6.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.AxisState var12 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     java.util.List var15 = var6.refreshTicks(var11, var12, var13, var14);
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var18 = null;
//     var17.setOutlineStroke(var18);
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var17.axisChanged(var20);
//     var17.setRangeGridlinesVisible(false);
//     boolean var24 = var17.isRangeCrosshairVisible();
//     java.awt.Stroke var25 = var17.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var27 = var17.getDataset(10);
//     java.awt.Stroke var28 = var17.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var29 = var17.getRangeAxisEdge();
//     boolean var30 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var29);
//     java.util.List var31 = var0.refreshTicks(var5, var12, var16, var29);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis var7 = var0.getDomainAxis();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var13 = java.awt.Color.getColor("", 10);
    var10.setTickMarkPaint((java.awt.Paint)var13);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var20 = var19.darker();
    var16.setLabelPaint((java.awt.Paint)var19);
    float[] var25 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var26 = var19.getColorComponents(var25);
    java.awt.Color var27 = java.awt.Color.getColor("", var19);
    var10.setTickLabelPaint((java.awt.Paint)var27);
    var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var10);
    var10.setRangeAboutValue(3.0d, 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
//     java.awt.RenderingHints var32 = null;
//     var30.setRenderingHints(var32);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    org.jfree.chart.event.AxisChangeEvent var8 = null;
    var5.axisChanged(var8);
    var5.clearAnnotations();
    var4.addChangeListener((org.jfree.chart.event.RendererChangeListener)var5);
    java.awt.Shape var13 = var4.getSeriesShape(1);
    java.awt.Paint var15 = var4.lookupSeriesFillPaint((-1));
    boolean var16 = var4.getIncludeBaseInRange();
    double var17 = var4.getUpperClip();
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var4.setBaseItemLabelGenerator(var18, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var21 = var4.getLegendItemURLGenerator();
    java.awt.Shape var23 = var4.lookupSeriesShape((-1));
    java.awt.Color var26 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var27 = var26.darker();
    java.awt.color.ColorSpace var28 = var26.getColorSpace();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem(var0, "CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "[size=1]", "[size=1]", var23, (java.awt.Paint)var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesCreateEntities(0);
    int var3 = var0.getColumnCount();
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setSeriesURLGenerator(100, var5);
    var0.setBaseItemLabelsVisible(true, true);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    org.jfree.chart.event.AxisChangeEvent var13 = null;
    var10.axisChanged(var13);
    org.jfree.chart.event.PlotChangeListener var15 = null;
    var10.addChangeListener(var15);
    boolean var17 = var0.hasListener((java.util.EventListener)var10);
    var0.setBaseSeriesVisible(true);
    java.lang.Boolean var21 = var0.getSeriesItemLabelsVisible((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.VerticalAlignment var2 = var0.getVerticalAlignment();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var5 = null;
    var4.setOutlineStroke(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    var4.setRangeGridlinesVisible(false);
    boolean var11 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var12 = var4.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var13 = var4.getDataset();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    float var16 = var15.getTickMarkOutsideLength();
    var15.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var15.valueToJava2D(100.0d, var23, var24);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleAnchor var27 = null;
    java.awt.geom.Point2D var28 = org.jfree.chart.util.RectangleAnchor.coordinates(var26, var27);
    org.jfree.chart.plot.PlotState var29 = null;
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    var4.draw(var14, var23, var28, var29, var31);
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var35 = var34.getHorizontalAlignment();
    var33.setTitle(var34);
    var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var33);
    org.jfree.chart.title.TextTitle var38 = var33.getTitle();
    org.jfree.chart.event.ChartChangeListener var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addChangeListener(var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var30.setAntiAlias(false);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     var30.handleClick((-1), (-1), var35);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     float var9 = var8.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var10 = var8.getLabelInsets();
//     boolean var11 = var8.isVerticalTickLabels();
//     double var12 = var8.getLowerMargin();
//     double var13 = var8.getFixedAutoRange();
//     java.awt.Font var14 = var8.getLabelFont();
//     org.jfree.data.Range var15 = var1.getDataRange((org.jfree.chart.axis.ValueAxis)var8);
//     var1.zoom(106.0d);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.lang.Boolean var2 = var0.getSeriesCreateEntities(0);
    double var3 = var0.getLowerClip();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    float var10 = var9.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var11 = var9.getLabelInsets();
    boolean var12 = var9.isVerticalTickLabels();
    java.awt.Shape var13 = var9.getRightArrow();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var15 = null;
    var14.setOutlineStroke(var15);
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var14.axisChanged(var17);
    var14.setRangeGridlinesVisible(false);
    boolean var21 = var14.isRangeCrosshairVisible();
    java.awt.Stroke var22 = var14.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var24 = var14.getDataset(10);
    java.awt.Stroke var25 = var14.getDomainGridlineStroke();
    java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "CategoryLabelEntity: category=-1.0, tooltip=HorizontalAlignment.CENTER, url=RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", "ItemLabelAnchor.OUTSIDE12", var13, var25, (java.awt.Paint)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), (java.awt.Paint)var28, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var30.setAntiAlias(false);
//     org.jfree.chart.title.LegendTitle var34 = var30.getLegend(255);
//     var30.setBackgroundImageAlignment(10);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.block.LineBorder var38 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var39 = var38.getInsets();
//     double var41 = var39.calculateBottomInset(0.0d);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var43 = null;
//     var42.setOutlineStroke(var43);
//     org.jfree.chart.event.AxisChangeEvent var45 = null;
//     var42.axisChanged(var45);
//     java.awt.Paint var47 = var42.getRangeGridlinePaint();
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var53 = java.awt.Color.getColor("", 10);
//     var50.setTickMarkPaint((java.awt.Paint)var53);
//     org.jfree.chart.axis.TickUnitSource var55 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var50.setStandardTickUnits(var55);
//     org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var60 = var59.getBounds();
//     org.jfree.chart.util.RectangleEdge var61 = null;
//     double var62 = var50.lengthToJava2D((-1.0d), var60, var61);
//     org.jfree.chart.ChartRenderingInfo var64 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var65 = new org.jfree.chart.plot.PlotRenderingInfo(var64);
//     boolean var66 = var42.render(var48, var60, 10, var65);
//     java.awt.geom.Rectangle2D var67 = var39.createOutsetRectangle(var60);
//     java.awt.geom.Point2D var68 = null;
//     org.jfree.chart.ChartRenderingInfo var69 = null;
//     var30.draw(var37, var67, var68, var69);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     boolean var10 = var0.getAutoPopulateSeriesStroke();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var13 = null;
//     var12.setOutlineStroke(var13);
//     org.jfree.chart.event.AxisChangeEvent var15 = null;
//     var12.axisChanged(var15);
//     var12.setRangeGridlinesVisible(false);
//     boolean var19 = var12.isRangeCrosshairVisible();
//     java.awt.Stroke var20 = var12.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var22 = var12.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var23 = null;
//     var12.notifyListeners(var23);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     float var26 = var25.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var27 = var25.getLabelInsets();
//     boolean var28 = var25.isVerticalTickLabels();
//     boolean var29 = var25.isNegativeArrowVisible();
//     boolean var30 = var25.isNegativeArrowVisible();
//     int var31 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
//     java.awt.Paint var32 = var12.getRangeCrosshairPaint();
//     var0.setSeriesFillPaint(1, var32);
//     java.awt.Paint var35 = var0.getSeriesPaint(10);
//     org.jfree.chart.ChartColor var39 = new org.jfree.chart.ChartColor(0, 0, 100);
//     java.awt.Color var40 = var39.brighter();
//     var0.setBaseOutlinePaint((java.awt.Paint)var39, false);
//     org.jfree.chart.urls.CategoryURLGenerator var44 = null;
//     var0.setSeriesURLGenerator(1, var44);
//     org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var48 = null;
//     var47.setOutlineStroke(var48);
//     org.jfree.chart.event.AxisChangeEvent var50 = null;
//     var47.axisChanged(var50);
//     var47.clearAnnotations();
//     var46.addChangeListener((org.jfree.chart.event.RendererChangeListener)var47);
//     java.awt.Shape var55 = var46.getSeriesShape(1);
//     org.jfree.chart.labels.ItemLabelPosition var58 = var46.getPositiveItemLabelPosition(0, 100);
//     org.jfree.chart.labels.ItemLabelAnchor var59 = var58.getItemLabelAnchor();
//     var0.setNegativeItemLabelPositionFallback(var58);
//     
//     // Checks the contract:  equals-hashcode on var1 and var47
//     assertTrue("Contract failed: equals-hashcode on var1 and var47", var1.equals(var47) ? var1.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var1
//     assertTrue("Contract failed: equals-hashcode on var47 and var1", var47.equals(var1) ? var47.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     org.jfree.chart.axis.CategoryAxis var7 = var0.getDomainAxis();
//     org.jfree.chart.util.RectangleEdge var9 = var0.getRangeAxisEdge((-1));
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
//     float var12 = var11.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var13 = var11.getLabelInsets();
//     boolean var14 = var11.isVerticalTickLabels();
//     org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var11};
//     var10.setRangeAxes(var15);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var18 = null;
//     var17.setOutlineStroke(var18);
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var17.axisChanged(var20);
//     var17.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var24);
//     var10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var24);
//     java.awt.Paint var27 = var24.getNextOutlinePaint();
//     var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var24);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    org.jfree.data.Range var3 = var0.getRange();
    org.jfree.data.Range var4 = var0.getDefaultAutoRange();
    org.jfree.chart.axis.NumberTickUnit var5 = var0.getTickUnit();
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Paint var5 = var0.getRangeGridlinePaint();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var11 = java.awt.Color.getColor("", 10);
    var8.setTickMarkPaint((java.awt.Paint)var11);
    org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var8.setStandardTickUnits(var13);
    org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var18 = var17.getBounds();
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var8.lengthToJava2D((-1.0d), var18, var19);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
    boolean var24 = var0.render(var6, var18, 10, var23);
    int var25 = var23.getSubplotCount();
    java.lang.Object var26 = var23.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
    java.awt.Graphics2D var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, 10.0d);
    double var7 = var6.getHeight();
    double var8 = var6.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var9 = var0.arrange(var1, var3, var6);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var3 = var2.darker();
    int var4 = var3.getBlue();
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
    org.jfree.chart.ChartColor var9 = new org.jfree.chart.ChartColor(0, 0, 100);
    java.awt.Color var10 = var9.brighter();
    float[] var14 = new float[] { (-1.0f), 0.0f, 1.0f};
    float[] var15 = var10.getRGBColorComponents(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var16 = var3.getComponents(var14);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var4 = java.awt.Color.getColor("", 10);
    var1.setTickMarkPaint((java.awt.Paint)var4);
    org.jfree.chart.axis.TickUnitSource var6 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var1.setStandardTickUnits(var6);
    var1.setVerticalTickLabels(false);
    boolean var10 = var1.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    var1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
    org.jfree.chart.util.RectangleInsets var10 = var1.getInsets();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleAnchor var14 = null;
    java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var14);
    var1.zoomDomainAxes(3.0d, var12, var15);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    float var18 = var17.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var19 = var17.getLabelInsets();
    org.jfree.data.Range var20 = var17.getRange();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    var17.setRightArrow(var22);
    boolean var24 = var1.equals((java.lang.Object)var22);
    java.awt.Stroke var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeCrosshairStroke(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var5 = null;
    var4.setOutlineStroke(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    var4.setRangeGridlinesVisible(false);
    boolean var11 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var12 = var4.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var14 = var4.getDomainAxisEdge(100);
    org.jfree.chart.axis.CategoryLabelPosition var15 = var3.getLabelPosition(var14);
    org.jfree.chart.text.TextAnchor var16 = var15.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition(var1, var2, var16, 3.0d, var18, 0.8f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    java.awt.Color var3 = java.awt.Color.getColor("", 10);
    java.awt.Font var9 = null;
    java.awt.Color var12 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var13 = var12.darker();
    int var14 = var13.getBlue();
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13);
    org.jfree.chart.util.HorizontalAlignment var16 = var15.getLineAlignment();
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.text.TextBlockAnchor var20 = null;
    java.awt.Shape var24 = var15.calculateBounds(var17, 10.0f, (-1.0f), var20, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var28 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var24, (java.awt.Paint)var28);
    java.text.AttributedString var30 = var29.getAttributedLabel();
    boolean var31 = var29.isShapeOutlineVisible();
    java.awt.Stroke var32 = var29.getOutlineStroke();
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var35 = null;
    var34.setOutlineStroke(var35);
    org.jfree.chart.event.AxisChangeEvent var37 = null;
    var34.axisChanged(var37);
    var34.clearAnnotations();
    var33.addChangeListener((org.jfree.chart.event.RendererChangeListener)var34);
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var46 = java.awt.Color.getColor("", 10);
    var43.setTickMarkPaint((java.awt.Paint)var46);
    var33.setSeriesFillPaint(15, (java.awt.Paint)var46, true);
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var51 = null;
    var50.setOutlineStroke(var51);
    org.jfree.chart.event.AxisChangeEvent var53 = null;
    var50.axisChanged(var53);
    var50.setRangeGridlinesVisible(false);
    boolean var57 = var50.isRangeCrosshairVisible();
    java.awt.Stroke var58 = var50.getDomainGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var3, var32, (java.awt.Paint)var46, var58, 2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("java.awt.Color[r=0,g=0,b=1]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var5 = null;
    var4.setOutlineStroke(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    java.awt.Paint var9 = var4.getRangeGridlinePaint();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var15 = java.awt.Color.getColor("", 10);
    var12.setTickMarkPaint((java.awt.Paint)var15);
    org.jfree.chart.axis.TickUnitSource var17 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var12.setStandardTickUnits(var17);
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var22 = var21.getBounds();
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var12.lengthToJava2D((-1.0d), var22, var23);
    org.jfree.chart.ChartRenderingInfo var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
    boolean var28 = var4.render(var10, var22, 10, var27);
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var31 = null;
    var30.setOutlineStroke(var31);
    org.jfree.chart.event.AxisChangeEvent var33 = null;
    var30.axisChanged(var33);
    var30.clearAnnotations();
    var29.addChangeListener((org.jfree.chart.event.RendererChangeListener)var30);
    org.jfree.chart.annotations.CategoryAnnotation var37 = null;
    boolean var38 = var29.removeAnnotation(var37);
    java.awt.Paint var41 = var29.getItemFillPaint(0, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem(var0, "HorizontalAlignment.CENTER", "RangeType.FULL", "", (java.awt.Shape)var22, var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var1 = var0.getHorizontalAlignment();
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     var0.setPaint((java.awt.Paint)var4);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var8 = null;
//     var7.setOutlineStroke(var8);
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var7.axisChanged(var10);
//     var7.setRangeGridlinesVisible(false);
//     boolean var14 = var7.isRangeCrosshairVisible();
//     java.awt.Stroke var15 = var7.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var16 = var7.getDataset();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
//     float var19 = var18.getTickMarkOutsideLength();
//     var18.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var26 = var25.getBounds();
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var18.valueToJava2D(100.0d, var26, var27);
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleAnchor var30 = null;
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
//     org.jfree.chart.plot.PlotState var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var34 = new org.jfree.chart.plot.PlotRenderingInfo(var33);
//     var7.draw(var17, var26, var31, var32, var34);
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.plot.CategoryPlot var37 = var36.getCategoryPlot();
//     java.awt.Paint var38 = var36.getBackgroundPaint();
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var45 = java.awt.Color.getColor("", 10);
//     var42.setTickMarkPaint((java.awt.Paint)var45);
//     var39.setSeriesItemLabelPaint(100, (java.awt.Paint)var45, true);
//     org.jfree.chart.LegendItem var51 = var39.getLegendItem(0, (-1));
//     org.jfree.chart.urls.CategoryURLGenerator var53 = null;
//     var39.setSeriesURLGenerator(1, var53, false);
//     org.jfree.chart.labels.ItemLabelPosition var56 = var39.getBasePositiveItemLabelPosition();
//     boolean var57 = var36.equals((java.lang.Object)var56);
//     org.jfree.chart.event.ChartProgressEvent var60 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var36, 100, 15);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var63 = null;
//     var62.setOutlineStroke(var63);
//     org.jfree.chart.event.AxisChangeEvent var65 = null;
//     var62.axisChanged(var65);
//     var62.setRangeGridlinesVisible(false);
//     boolean var69 = var62.isRangeCrosshairVisible();
//     java.awt.Stroke var70 = var62.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var71 = var62.getDataset();
//     java.awt.Graphics2D var72 = null;
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis();
//     float var74 = var73.getTickMarkOutsideLength();
//     var73.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var80 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var81 = var80.getBounds();
//     org.jfree.chart.util.RectangleEdge var82 = null;
//     double var83 = var73.valueToJava2D(100.0d, var81, var82);
//     java.awt.geom.Rectangle2D var84 = null;
//     org.jfree.chart.util.RectangleAnchor var85 = null;
//     java.awt.geom.Point2D var86 = org.jfree.chart.util.RectangleAnchor.coordinates(var84, var85);
//     org.jfree.chart.plot.PlotState var87 = null;
//     org.jfree.chart.ChartRenderingInfo var88 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var89 = new org.jfree.chart.plot.PlotRenderingInfo(var88);
//     var62.draw(var72, var81, var86, var87, var89);
//     org.jfree.chart.JFreeChart var91 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var62);
//     org.jfree.chart.plot.CategoryPlot var92 = var91.getCategoryPlot();
//     java.awt.Paint var93 = var91.getBackgroundPaint();
//     var60.setChart(var91);
//     
//     // Checks the contract:  equals-hashcode on var7 and var62
//     assertTrue("Contract failed: equals-hashcode on var7 and var62", var7.equals(var62) ? var7.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var92
//     assertTrue("Contract failed: equals-hashcode on var7 and var92", var7.equals(var92) ? var7.hashCode() == var92.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var62
//     assertTrue("Contract failed: equals-hashcode on var37 and var62", var37.equals(var62) ? var37.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var92
//     assertTrue("Contract failed: equals-hashcode on var37 and var92", var37.equals(var92) ? var37.hashCode() == var92.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var7
//     assertTrue("Contract failed: equals-hashcode on var62 and var7", var62.equals(var7) ? var62.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var37
//     assertTrue("Contract failed: equals-hashcode on var62 and var37", var62.equals(var37) ? var62.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var92 and var7
//     assertTrue("Contract failed: equals-hashcode on var92 and var7", var92.equals(var7) ? var92.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var92 and var37
//     assertTrue("Contract failed: equals-hashcode on var92 and var37", var92.equals(var37) ? var92.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var80
//     assertTrue("Contract failed: equals-hashcode on var25 and var80", var25.equals(var80) ? var25.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var25
//     assertTrue("Contract failed: equals-hashcode on var80 and var25", var80.equals(var25) ? var80.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var89
//     assertTrue("Contract failed: equals-hashcode on var34 and var89", var34.equals(var89) ? var34.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var34
//     assertTrue("Contract failed: equals-hashcode on var89 and var34", var89.equals(var34) ? var89.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var91
//     assertTrue("Contract failed: equals-hashcode on var36 and var91", var36.equals(var91) ? var36.hashCode() == var91.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var91 and var36
//     assertTrue("Contract failed: equals-hashcode on var91 and var36", var91.equals(var36) ? var91.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     var1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
//     org.jfree.chart.util.RectangleInsets var10 = var1.getInsets();
//     org.jfree.chart.block.LineBorder var11 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     double var14 = var12.calculateBottomInset(0.0d);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var16 = null;
//     var15.setOutlineStroke(var16);
//     org.jfree.chart.event.AxisChangeEvent var18 = null;
//     var15.axisChanged(var18);
//     java.awt.Paint var20 = var15.getRangeGridlinePaint();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var26 = java.awt.Color.getColor("", 10);
//     var23.setTickMarkPaint((java.awt.Paint)var26);
//     org.jfree.chart.axis.TickUnitSource var28 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var23.setStandardTickUnits(var28);
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var33 = var32.getBounds();
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var23.lengthToJava2D((-1.0d), var33, var34);
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
//     boolean var39 = var15.render(var21, var33, 10, var38);
//     java.awt.geom.Rectangle2D var40 = var12.createOutsetRectangle(var33);
//     java.awt.geom.Rectangle2D var41 = var10.createInsetRectangle(var33);
//     org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var44 = null;
//     var43.setOutlineStroke(var44);
//     org.jfree.chart.event.AxisChangeEvent var46 = null;
//     var43.axisChanged(var46);
//     var43.clearAnnotations();
//     var42.addChangeListener((org.jfree.chart.event.RendererChangeListener)var43);
//     java.awt.Shape var51 = var42.getSeriesShape(1);
//     java.awt.Paint var53 = var42.lookupSeriesFillPaint((-1));
//     boolean var54 = var42.getIncludeBaseInRange();
//     double var55 = var42.getUpperClip();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var56 = null;
//     var42.setBaseItemLabelGenerator(var56, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var59 = var42.getLegendItemURLGenerator();
//     java.awt.Shape var61 = var42.lookupSeriesShape((-1));
//     boolean var62 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape)var41, var61);
//     
//     // Checks the contract:  equals-hashcode on var15 and var43
//     assertTrue("Contract failed: equals-hashcode on var15 and var43", var15.equals(var43) ? var15.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var15
//     assertTrue("Contract failed: equals-hashcode on var43 and var15", var43.equals(var15) ? var43.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var7.calculateBounds(var9, 10.0f, (-1.0f), var12, (-1.0f), 1.0f, 1.0d);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var21 = java.awt.Color.getColor("", 10);
    var18.setTickMarkPaint((java.awt.Paint)var21);
    org.jfree.chart.axis.TickUnitSource var23 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var18.setStandardTickUnits(var23);
    boolean var25 = var7.equals((java.lang.Object)var18);
    java.awt.Shape var26 = var18.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setTickMarksVisible(false);
    java.awt.Stroke var3 = var0.getTickMarkStroke();
    float var4 = var0.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     boolean var10 = var0.getAutoPopulateSeriesStroke();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var11 = var0.getLegendItemToolTipGenerator();
//     var0.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     var14.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var14.getBasePositiveItemLabelPosition();
//     var0.setBaseNegativeItemLabelPosition(var17);
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var21 = null;
//     var20.setOutlineStroke(var21);
//     org.jfree.chart.event.AxisChangeEvent var23 = null;
//     var20.axisChanged(var23);
//     var20.clearAnnotations();
//     var19.addChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     java.awt.Shape var28 = var19.getSeriesShape(1);
//     java.awt.Paint var30 = var19.lookupSeriesFillPaint((-1));
//     boolean var31 = var19.getIncludeBaseInRange();
//     java.awt.Font var32 = var19.getBaseItemLabelFont();
//     org.jfree.chart.ChartColor var36 = new org.jfree.chart.ChartColor(0, 0, 100);
//     var19.setBaseItemLabelPaint((java.awt.Paint)var36);
//     java.awt.Paint var39 = var19.lookupSeriesOutlinePaint(0);
//     double var40 = var19.getUpperClip();
//     boolean var41 = var17.equals((java.lang.Object)var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var20
//     assertTrue("Contract failed: equals-hashcode on var1 and var20", var1.equals(var20) ? var1.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var1
//     assertTrue("Contract failed: equals-hashcode on var20 and var1", var20.equals(var1) ? var20.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var1.configureDomainAxes();
    var1.setRangeCrosshairVisible(false);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartChangeListener var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addChangeListener(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    double var13 = var0.getUpperClip();
    double var14 = var0.getMinimumBarLength();
    int var15 = var0.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Paint var5 = var0.getRangeGridlinePaint();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var11 = java.awt.Color.getColor("", 10);
    var8.setTickMarkPaint((java.awt.Paint)var11);
    org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var8.setStandardTickUnits(var13);
    org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var18 = var17.getBounds();
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var8.lengthToJava2D((-1.0d), var18, var19);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
    boolean var24 = var0.render(var6, var18, 10, var23);
    int var25 = var23.getSubplotCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var27 = var23.getSubplotInfo(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("HorizontalAlignment.CENTER", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    double var4 = var0.getLowerMargin();
    var0.setTickMarkInsideLength(1.0f);
    var0.setRangeAboutValue(10.0d, 10.0d);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    float var15 = var14.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var16 = var14.getLabelInsets();
    boolean var17 = var14.isVerticalTickLabels();
    java.awt.Shape var18 = var14.getRightArrow();
    org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var18);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    float var24 = var23.getTickMarkOutsideLength();
    var23.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.AxisState var29 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    java.util.List var32 = var23.refreshTicks(var28, var29, var30, var31);
    var29.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis();
    float var36 = var35.getTickMarkOutsideLength();
    var35.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var42 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var43 = var42.getBounds();
    org.jfree.chart.util.RectangleEdge var44 = null;
    double var45 = var35.valueToJava2D(100.0d, var43, var44);
    org.jfree.chart.util.RectangleEdge var46 = null;
    java.util.List var47 = var21.refreshTicks(var22, var29, var43, var46);
    java.awt.Shape var48 = var21.getLeftArrow();
    boolean var49 = var19.equals((java.lang.Object)var48);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis();
    var50.setTickMarksVisible(false);
    java.awt.Stroke var53 = var50.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var57 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var58 = var57.darker();
    var54.setLabelPaint((java.awt.Paint)var57);
    float[] var63 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var64 = var57.getColorComponents(var63);
    org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var48, var53, (java.awt.Paint)var57);
    var0.setUpArrow(var48);
    java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.rotateShape(var48, 0.0d, 0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.util.VerticalAlignment var2 = var0.getVerticalAlignment();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var5 = null;
    var4.setOutlineStroke(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    var4.setRangeGridlinesVisible(false);
    boolean var11 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var12 = var4.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var13 = var4.getDataset();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    float var16 = var15.getTickMarkOutsideLength();
    var15.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var15.valueToJava2D(100.0d, var23, var24);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleAnchor var27 = null;
    java.awt.geom.Point2D var28 = org.jfree.chart.util.RectangleAnchor.coordinates(var26, var27);
    org.jfree.chart.plot.PlotState var29 = null;
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    var4.draw(var14, var23, var28, var29, var31);
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var35 = var34.getHorizontalAlignment();
    var33.setTitle(var34);
    var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var33);
    java.awt.Image var38 = var33.getBackgroundImage();
    org.jfree.chart.event.ChartChangeListener var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.removeChangeListener(var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(4.99999995E-9d, 1.0d);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    java.awt.Font var13 = var0.getBaseItemLabelFont();
    var0.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    var19.setLabelPaint((java.awt.Paint)var22);
    var0.setSeriesItemLabelPaint(255, (java.awt.Paint)var22);
    boolean var26 = var0.getBaseCreateEntities();
    var0.setMinimumBarLength((-1.0d));
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    float var35 = var34.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var36 = var34.getLabelInsets();
    boolean var37 = var34.isVerticalTickLabels();
    java.awt.Shape var38 = var34.getRightArrow();
    org.jfree.chart.entity.ChartEntity var39 = new org.jfree.chart.entity.ChartEntity(var38);
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var42 = null;
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    float var44 = var43.getTickMarkOutsideLength();
    var43.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.axis.AxisState var49 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var50 = null;
    org.jfree.chart.util.RectangleEdge var51 = null;
    java.util.List var52 = var43.refreshTicks(var48, var49, var50, var51);
    var49.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
    float var56 = var55.getTickMarkOutsideLength();
    var55.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var63 = var62.getBounds();
    org.jfree.chart.util.RectangleEdge var64 = null;
    double var65 = var55.valueToJava2D(100.0d, var63, var64);
    org.jfree.chart.util.RectangleEdge var66 = null;
    java.util.List var67 = var41.refreshTicks(var42, var49, var63, var66);
    java.awt.Shape var68 = var41.getLeftArrow();
    boolean var69 = var39.equals((java.lang.Object)var68);
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
    var70.setTickMarksVisible(false);
    java.awt.Stroke var73 = var70.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var77 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var78 = var77.darker();
    var74.setLabelPaint((java.awt.Paint)var77);
    float[] var83 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var84 = var77.getColorComponents(var83);
    org.jfree.chart.LegendItem var85 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var68, var73, (java.awt.Paint)var77);
    var0.setSeriesStroke(15, var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
    float var2 = var1.getAlpha();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var8 = var7.darker();
    var4.setLabelPaint((java.awt.Paint)var7);
    float[] var13 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var14 = var7.getColorComponents(var13);
    java.awt.Color var15 = java.awt.Color.getColor("", var7);
    var1.setPaint((java.awt.Paint)var15);
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis();
    float var20 = var19.getTickMarkOutsideLength();
    var19.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var26 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var27 = var26.getBounds();
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var19.valueToJava2D(100.0d, var27, var28);
    java.awt.geom.AffineTransform var30 = null;
    java.awt.RenderingHints var31 = null;
    java.awt.PaintContext var32 = var15.createContext(var17, var18, var27, var30, var31);
    org.jfree.chart.util.RectangleAnchor var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var18, var33, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     boolean var10 = var0.getAutoPopulateSeriesStroke();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var0.getNegativeItemLabelPositionFallback();
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var21 = null;
//     var20.setOutlineStroke(var21);
//     org.jfree.chart.event.AxisChangeEvent var23 = null;
//     var20.axisChanged(var23);
//     var20.clearAnnotations();
//     var19.addChangeListener((org.jfree.chart.event.RendererChangeListener)var20);
//     java.awt.Shape var28 = var19.getSeriesShape(1);
//     java.awt.Color var31 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var32 = var31.darker();
//     int var33 = var32.getBlue();
//     var19.setBasePaint((java.awt.Paint)var32);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     float var40 = var39.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var41 = var39.getLabelInsets();
//     boolean var42 = var39.isVerticalTickLabels();
//     java.awt.Shape var43 = var39.getRightArrow();
//     org.jfree.chart.entity.ChartEntity var44 = new org.jfree.chart.entity.ChartEntity(var43);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     float var49 = var48.getTickMarkOutsideLength();
//     var48.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.AxisState var54 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     java.util.List var57 = var48.refreshTicks(var53, var54, var55, var56);
//     var54.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis();
//     float var61 = var60.getTickMarkOutsideLength();
//     var60.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var67 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var68 = var67.getBounds();
//     org.jfree.chart.util.RectangleEdge var69 = null;
//     double var70 = var60.valueToJava2D(100.0d, var68, var69);
//     org.jfree.chart.util.RectangleEdge var71 = null;
//     java.util.List var72 = var46.refreshTicks(var47, var54, var68, var71);
//     java.awt.Shape var73 = var46.getLeftArrow();
//     boolean var74 = var44.equals((java.lang.Object)var73);
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis();
//     var75.setTickMarksVisible(false);
//     java.awt.Stroke var78 = var75.getTickMarkStroke();
//     org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var82 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var83 = var82.darker();
//     var79.setLabelPaint((java.awt.Paint)var82);
//     float[] var88 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var89 = var82.getColorComponents(var88);
//     org.jfree.chart.LegendItem var90 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var73, var78, (java.awt.Paint)var82);
//     java.awt.Color var93 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var94 = var93.darker();
//     org.jfree.chart.LegendItem var95 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "", "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var18, (java.awt.Paint)var32, var78, (java.awt.Paint)var94);
//     var0.setSeriesItemLabelPaint(0, (java.awt.Paint)var94, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var20
//     assertTrue("Contract failed: equals-hashcode on var1 and var20", var1.equals(var20) ? var1.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var1
//     assertTrue("Contract failed: equals-hashcode on var20 and var1", var20.equals(var1) ? var20.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var32 = var31.getHorizontalAlignment();
//     var30.setTitle(var31);
//     org.jfree.chart.title.LegendTitle var34 = var30.getLegend();
//     org.jfree.chart.util.RectangleInsets var35 = var34.getLegendItemGraphicPadding();
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     var38.setTickMarksVisible(false);
//     java.awt.Stroke var41 = var38.getTickMarkStroke();
//     java.lang.Object var42 = var34.draw(var36, var37, (java.lang.Object)var38);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var11 = null;
//     var0.notifyListeners(var11);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var15 = null;
//     var14.setOutlineStroke(var15);
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var14.axisChanged(var17);
//     java.awt.Paint var19 = var14.getRangeGridlinePaint();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var25 = java.awt.Color.getColor("", 10);
//     var22.setTickMarkPaint((java.awt.Paint)var25);
//     org.jfree.chart.axis.TickUnitSource var27 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var22.setStandardTickUnits(var27);
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var32 = var31.getBounds();
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var22.lengthToJava2D((-1.0d), var32, var33);
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     boolean var38 = var14.render(var20, var32, 10, var37);
//     java.awt.geom.Rectangle2D var39 = var37.getDataArea();
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleAnchor var41 = null;
//     java.awt.geom.Point2D var42 = org.jfree.chart.util.RectangleAnchor.coordinates(var40, var41);
//     var0.zoomRangeAxes(0.0d, var37, var42);
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.block.LineBorder var45 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var46 = var45.getInsets();
//     double var48 = var46.calculateBottomInset(0.0d);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var50 = null;
//     var49.setOutlineStroke(var50);
//     org.jfree.chart.event.AxisChangeEvent var52 = null;
//     var49.axisChanged(var52);
//     java.awt.Paint var54 = var49.getRangeGridlinePaint();
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var60 = java.awt.Color.getColor("", 10);
//     var57.setTickMarkPaint((java.awt.Paint)var60);
//     org.jfree.chart.axis.TickUnitSource var62 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var57.setStandardTickUnits(var62);
//     org.jfree.chart.block.LabelBlock var66 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var67 = var66.getBounds();
//     org.jfree.chart.util.RectangleEdge var68 = null;
//     double var69 = var57.lengthToJava2D((-1.0d), var67, var68);
//     org.jfree.chart.ChartRenderingInfo var71 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var72 = new org.jfree.chart.plot.PlotRenderingInfo(var71);
//     boolean var73 = var49.render(var55, var67, 10, var72);
//     java.awt.geom.Rectangle2D var74 = var46.createOutsetRectangle(var67);
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     boolean var77 = var0.render(var44, var67, 1, var76);
//     
//     // Checks the contract:  equals-hashcode on var14 and var49
//     assertTrue("Contract failed: equals-hashcode on var14 and var49", var14.equals(var49) ? var14.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var14
//     assertTrue("Contract failed: equals-hashcode on var49 and var14", var49.equals(var14) ? var49.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var62
//     assertTrue("Contract failed: equals-hashcode on var27 and var62", var27.equals(var62) ? var27.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var27
//     assertTrue("Contract failed: equals-hashcode on var62 and var27", var62.equals(var27) ? var62.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var66
//     assertTrue("Contract failed: equals-hashcode on var31 and var66", var31.equals(var66) ? var31.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var31
//     assertTrue("Contract failed: equals-hashcode on var66 and var31", var66.equals(var31) ? var66.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var72
//     assertTrue("Contract failed: equals-hashcode on var37 and var72", var37.equals(var72) ? var37.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var37
//     assertTrue("Contract failed: equals-hashcode on var72 and var37", var72.equals(var37) ? var72.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
//     var0.clearDomainMarkers(10);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var12 = null;
//     var11.setOutlineStroke(var12);
//     org.jfree.chart.event.AxisChangeEvent var14 = null;
//     var11.axisChanged(var14);
//     var11.setRangeGridlinesVisible(false);
//     boolean var18 = var11.isRangeCrosshairVisible();
//     java.awt.Stroke var19 = var11.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var21 = var11.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var22 = null;
//     var11.notifyListeners(var22);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = var11.getRenderer(100);
//     org.jfree.chart.util.Layer var27 = null;
//     java.util.Collection var28 = var11.getDomainMarkers(0, var27);
//     org.jfree.chart.axis.AxisLocation var30 = var11.getRangeAxisLocation(10);
//     var0.setRangeAxisLocation(var30, true);
//     org.jfree.chart.util.Layer var34 = null;
//     java.util.Collection var35 = var0.getDomainMarkers(10, var34);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.util.VerticalAlignment var38 = var36.getVerticalAlignment();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var41 = null;
//     var40.setOutlineStroke(var41);
//     org.jfree.chart.event.AxisChangeEvent var43 = null;
//     var40.axisChanged(var43);
//     var40.setRangeGridlinesVisible(false);
//     boolean var47 = var40.isRangeCrosshairVisible();
//     java.awt.Stroke var48 = var40.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var49 = var40.getDataset();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     float var52 = var51.getTickMarkOutsideLength();
//     var51.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var59 = var58.getBounds();
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var51.valueToJava2D(100.0d, var59, var60);
//     java.awt.geom.Rectangle2D var62 = null;
//     org.jfree.chart.util.RectangleAnchor var63 = null;
//     java.awt.geom.Point2D var64 = org.jfree.chart.util.RectangleAnchor.coordinates(var62, var63);
//     org.jfree.chart.plot.PlotState var65 = null;
//     org.jfree.chart.ChartRenderingInfo var66 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var67 = new org.jfree.chart.plot.PlotRenderingInfo(var66);
//     var40.draw(var50, var59, var64, var65, var67);
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var40);
//     org.jfree.chart.title.TextTitle var70 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var71 = var70.getHorizontalAlignment();
//     var69.setTitle(var70);
//     var36.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var69);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var69);
//     
//     // Checks the contract:  equals-hashcode on var11 and var40
//     assertTrue("Contract failed: equals-hashcode on var11 and var40", var11.equals(var40) ? var11.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var11
//     assertTrue("Contract failed: equals-hashcode on var40 and var11", var40.equals(var11) ? var40.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    org.jfree.data.Range var3 = var0.getRange();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var12 = null;
    var11.setOutlineStroke(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var11.axisChanged(var14);
    var11.clearAnnotations();
    var10.addChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
    java.awt.Shape var19 = var10.getSeriesShape(1);
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    int var24 = var23.getBlue();
    var10.setBasePaint((java.awt.Paint)var23);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
    float var31 = var30.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isVerticalTickLabels();
    java.awt.Shape var34 = var30.getRightArrow();
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var34);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
    float var40 = var39.getTickMarkOutsideLength();
    var39.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.axis.AxisState var45 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var46 = null;
    org.jfree.chart.util.RectangleEdge var47 = null;
    java.util.List var48 = var39.refreshTicks(var44, var45, var46, var47);
    var45.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
    float var52 = var51.getTickMarkOutsideLength();
    var51.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var59 = var58.getBounds();
    org.jfree.chart.util.RectangleEdge var60 = null;
    double var61 = var51.valueToJava2D(100.0d, var59, var60);
    org.jfree.chart.util.RectangleEdge var62 = null;
    java.util.List var63 = var37.refreshTicks(var38, var45, var59, var62);
    java.awt.Shape var64 = var37.getLeftArrow();
    boolean var65 = var35.equals((java.lang.Object)var64);
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
    var66.setTickMarksVisible(false);
    java.awt.Stroke var69 = var66.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var73 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var74 = var73.darker();
    var70.setLabelPaint((java.awt.Paint)var73);
    float[] var79 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var80 = var73.getColorComponents(var79);
    org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var64, var69, (java.awt.Paint)var73);
    java.awt.Color var84 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var85 = var84.darker();
    org.jfree.chart.LegendItem var86 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "", "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var9, (java.awt.Paint)var23, var69, (java.awt.Paint)var85);
    var0.setAxisLineStroke(var69);
    org.jfree.chart.axis.NumberTickUnit var88 = var0.getTickUnit();
    var0.setLabelURL("TextAnchor.BOTTOM_CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     float var2 = var1.getAlpha();
//     var1.setLabel("");
//     double var5 = var1.getValue();
//     java.lang.Class var6 = null;
//     java.util.EventListener[] var7 = var1.getListeners(var6);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
    java.awt.Font var14 = null;
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var18 = var17.darker();
    int var19 = var18.getBlue();
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
    org.jfree.chart.util.HorizontalAlignment var21 = var20.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var22 = null;
    org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var21, var22, 1.0E-8d, (-1.0d));
    org.jfree.chart.block.BlockContainer var26 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var25);
    org.jfree.chart.block.Arrangement var27 = var26.getArrangement();
    var26.clear();
    java.awt.Graphics2D var29 = null;
    org.jfree.data.Range var31 = null;
    org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(10.0d, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var33 = var12.arrange(var26, var29, var32);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     java.awt.Paint var5 = var0.getRangeGridlinePaint();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var11 = java.awt.Color.getColor("", 10);
//     var8.setTickMarkPaint((java.awt.Paint)var11);
//     org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var8.setStandardTickUnits(var13);
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var18 = var17.getBounds();
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var8.lengthToJava2D((-1.0d), var18, var19);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     boolean var24 = var0.render(var6, var18, 10, var23);
//     java.awt.geom.Rectangle2D var25 = var23.getDataArea();
//     java.awt.geom.Rectangle2D var26 = var23.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var29 = null;
//     var28.setOutlineStroke(var29);
//     org.jfree.chart.event.AxisChangeEvent var31 = null;
//     var28.axisChanged(var31);
//     var28.clearAnnotations();
//     var28.configureDomainAxes();
//     var28.setRangeCrosshairVisible(false);
//     org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var28
//     assertTrue("Contract failed: equals-hashcode on var0 and var28", var0.equals(var28) ? var0.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var0.addChangeListener(var5);
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
//     java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var0.setDomainAxis(100, var12);
//     var12.addCategoryLabelToolTip((java.lang.Comparable)1.0f, "AxisLocation.BOTTOM_OR_RIGHT");
//     float var17 = var12.getMaximumCategoryLabelWidthRatio();
//     var12.setCategoryLabelPositionOffset((-1));
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var24 = null;
//     var23.setOutlineStroke(var24);
//     org.jfree.chart.event.AxisChangeEvent var26 = null;
//     var23.axisChanged(var26);
//     var23.clearAnnotations();
//     var22.addChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
//     org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
//     var23.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
//     org.jfree.chart.util.RectangleInsets var32 = var23.getInsets();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var34 = null;
//     var33.setOutlineStroke(var34);
//     org.jfree.chart.event.AxisChangeEvent var36 = null;
//     var33.axisChanged(var36);
//     java.awt.Paint var38 = var33.getRangeGridlinePaint();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var44 = java.awt.Color.getColor("", 10);
//     var41.setTickMarkPaint((java.awt.Paint)var44);
//     org.jfree.chart.axis.TickUnitSource var46 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var41.setStandardTickUnits(var46);
//     org.jfree.chart.block.LabelBlock var50 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var51 = var50.getBounds();
//     org.jfree.chart.util.RectangleEdge var52 = null;
//     double var53 = var41.lengthToJava2D((-1.0d), var51, var52);
//     org.jfree.chart.ChartRenderingInfo var55 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var56 = new org.jfree.chart.plot.PlotRenderingInfo(var55);
//     boolean var57 = var33.render(var39, var51, 10, var56);
//     var32.trim(var51);
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var12.getCategoryMiddle(255, 15, var51, var59);
//     
//     // Checks the contract:  equals-hashcode on var33 and var0
//     assertTrue("Contract failed: equals-hashcode on var33 and var0", var33.equals(var0) ? var33.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var0.", var33.equals(var0) == var0.equals(var33));
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesCreateEntities(0);
//     int var3 = var0.getColumnCount();
//     org.jfree.chart.urls.CategoryURLGenerator var5 = null;
//     var0.setSeriesURLGenerator(100, var5);
//     java.lang.Boolean var8 = var0.getSeriesVisibleInLegend(10);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var12 = null;
//     var11.setOutlineStroke(var12);
//     org.jfree.chart.event.AxisChangeEvent var14 = null;
//     var11.axisChanged(var14);
//     var11.clearAnnotations();
//     var10.addChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     var11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.util.RectangleInsets var20 = var11.getInsets();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var22 = null;
//     var21.setOutlineStroke(var22);
//     org.jfree.chart.event.AxisChangeEvent var24 = null;
//     var21.axisChanged(var24);
//     java.awt.Paint var26 = var21.getRangeGridlinePaint();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var32 = java.awt.Color.getColor("", 10);
//     var29.setTickMarkPaint((java.awt.Paint)var32);
//     org.jfree.chart.axis.TickUnitSource var34 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var29.setStandardTickUnits(var34);
//     org.jfree.chart.block.LabelBlock var38 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var39 = var38.getBounds();
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var29.lengthToJava2D((-1.0d), var39, var40);
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     boolean var45 = var21.render(var27, var39, 10, var44);
//     var20.trim(var39);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var48 = null;
//     var47.setOutlineStroke(var48);
//     org.jfree.chart.event.AxisChangeEvent var50 = null;
//     var47.axisChanged(var50);
//     var47.setRangeGridlinesVisible(false);
//     boolean var54 = var47.isRangeCrosshairVisible();
//     java.awt.Stroke var55 = var47.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var57 = var47.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var58 = null;
//     var47.notifyListeners(var58);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = var47.getRenderer(100);
//     org.jfree.chart.util.Layer var63 = null;
//     java.util.Collection var64 = var47.getDomainMarkers(0, var63);
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var67 = null;
//     var66.setOutlineStroke(var67);
//     org.jfree.chart.event.AxisChangeEvent var69 = null;
//     var66.axisChanged(var69);
//     java.awt.Paint var71 = var66.getRangeGridlinePaint();
//     java.awt.Graphics2D var72 = null;
//     org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var77 = java.awt.Color.getColor("", 10);
//     var74.setTickMarkPaint((java.awt.Paint)var77);
//     org.jfree.chart.axis.TickUnitSource var79 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var74.setStandardTickUnits(var79);
//     org.jfree.chart.block.LabelBlock var83 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var84 = var83.getBounds();
//     org.jfree.chart.util.RectangleEdge var85 = null;
//     double var86 = var74.lengthToJava2D((-1.0d), var84, var85);
//     org.jfree.chart.ChartRenderingInfo var88 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var89 = new org.jfree.chart.plot.PlotRenderingInfo(var88);
//     boolean var90 = var66.render(var72, var84, 10, var89);
//     java.awt.geom.Rectangle2D var91 = var89.getDataArea();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var92 = var0.initialise(var9, var39, var47, 10, var89);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    var1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
    org.jfree.chart.util.RectangleInsets var10 = var1.getInsets();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleAnchor var14 = null;
    java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var14);
    var1.zoomDomainAxes(3.0d, var12, var15);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    float var18 = var17.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var19 = var17.getLabelInsets();
    org.jfree.data.Range var20 = var17.getRange();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    var17.setRightArrow(var22);
    boolean var24 = var1.equals((java.lang.Object)var22);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    float var27 = var26.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var28 = var26.getLabelInsets();
    boolean var29 = var26.isVerticalTickLabels();
    org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var26};
    var25.setRangeAxes(var30);
    org.jfree.chart.util.RectangleInsets var32 = var25.getAxisOffset();
    var25.clearDomainMarkers(100);
    java.awt.Stroke var35 = var25.getOutlineStroke();
    var1.setRangeGridlineStroke(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//     java.util.ResourceBundle.clearCache(var2);
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.clearAnnotations();
    var0.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var7 = var0.getDomainAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis var7 = var0.getDomainAxis();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var13 = java.awt.Color.getColor("", 10);
    var10.setTickMarkPaint((java.awt.Paint)var13);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var20 = var19.darker();
    var16.setLabelPaint((java.awt.Paint)var19);
    float[] var25 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var26 = var19.getColorComponents(var25);
    java.awt.Color var27 = java.awt.Color.getColor("", var19);
    var10.setTickLabelPaint((java.awt.Paint)var27);
    var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.data.Range var32 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var35 = org.jfree.data.Range.expand(var32, 1.0E-8d, 0.0d);
    org.jfree.data.Range var38 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var41 = org.jfree.data.Range.expand(var38, 1.0E-8d, 0.0d);
    org.jfree.data.Range var42 = org.jfree.data.Range.combine(var35, var41);
    var10.setRangeWithMargins(var35, true, true);
    double var46 = var35.getLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.00000001E-8d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var25 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var21, (java.awt.Paint)var25);
    var26.setDatasetIndex(0);
    var0.add(var26);
    org.jfree.chart.LegendItemCollection var30 = new org.jfree.chart.LegendItemCollection();
    java.awt.Font var36 = null;
    java.awt.Color var39 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var40 = var39.darker();
    int var41 = var40.getBlue();
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var40);
    org.jfree.chart.util.HorizontalAlignment var43 = var42.getLineAlignment();
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.text.TextBlockAnchor var47 = null;
    java.awt.Shape var51 = var42.calculateBounds(var44, 10.0f, (-1.0f), var47, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var55 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var51, (java.awt.Paint)var55);
    var56.setDatasetIndex(0);
    var30.add(var56);
    var0.addAll(var30);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var62 = null;
    var61.setOutlineStroke(var62);
    org.jfree.chart.event.AxisChangeEvent var64 = null;
    var61.axisChanged(var64);
    var61.setRangeGridlinesVisible(false);
    boolean var68 = var61.isRangeCrosshairVisible();
    java.awt.Stroke var69 = var61.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var71 = var61.getDataset(10);
    java.awt.Stroke var72 = var61.getDomainGridlineStroke();
    float var73 = var61.getForegroundAlpha();
    boolean var74 = var0.equals((java.lang.Object)var61);
    org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var76 = null;
    var75.setOutlineStroke(var76);
    org.jfree.chart.event.AxisChangeEvent var78 = null;
    var75.axisChanged(var78);
    var75.setRangeGridlinesVisible(false);
    boolean var82 = var75.isRangeCrosshairVisible();
    java.awt.Stroke var83 = var75.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var85 = var75.getDomainAxisForDataset(100);
    org.jfree.chart.event.MarkerChangeEvent var86 = null;
    var75.markerChanged(var86);
    float var88 = var75.getBackgroundAlpha();
    org.jfree.chart.axis.AxisLocation var90 = var75.getDomainAxisLocation(10);
    var61.setDomainAxisLocation(var90, true);
    org.jfree.chart.plot.PlotOrientation var93 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var94 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var90, var93);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.util.VerticalAlignment var15 = var13.getVerticalAlignment();
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var8, var15, 0.05d, (-1.0d));
    java.awt.Font var20 = null;
    java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var24 = var23.darker();
    int var25 = var24.getBlue();
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var20, (java.awt.Paint)var24);
    org.jfree.chart.util.HorizontalAlignment var27 = var26.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var28 = null;
    org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 1.0E-8d, (-1.0d));
    org.jfree.chart.block.BlockContainer var32 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var31);
    org.jfree.chart.block.LabelBlock var34 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var35 = var34.getMargin();
    var34.setHeight(0.0d);
    java.awt.Paint var38 = var34.getPaint();
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var40 = null;
    var39.setOutlineStroke(var40);
    org.jfree.chart.event.AxisChangeEvent var42 = null;
    var39.axisChanged(var42);
    var39.setRangeGridlinesVisible(false);
    boolean var46 = var39.isRangeCrosshairVisible();
    java.awt.Stroke var47 = var39.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var49 = var39.getDomainAxisEdge(100);
    org.jfree.chart.LegendItemCollection var50 = var39.getLegendItems();
    var32.add((org.jfree.chart.block.Block)var34, (java.lang.Object)var39);
    java.awt.Graphics2D var52 = null;
    org.jfree.data.Range var54 = null;
    org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(10.0d, var54);
    double var56 = var55.getHeight();
    org.jfree.chart.block.RectangleConstraint var57 = var55.toUnconstrainedWidth();
    double var58 = var57.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var59 = var18.arrange(var32, var52, var57);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 10.0d);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    var0.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.axis.AxisSpace var12 = var0.getFixedRangeAxisSpace();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    float var15 = var14.getTickMarkOutsideLength();
    var14.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var22 = var21.getBounds();
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var14.valueToJava2D(100.0d, var22, var23);
    var0.drawOutline(var13, var22);
    org.jfree.chart.plot.PlotOrientation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    java.awt.Shape var4 = var0.getRightArrow();
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var4);
    java.awt.Shape var6 = var5.getArea();
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "ItemLabelAnchor.OUTSIDE12", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.String var10 = var9.getURLText();
    java.awt.Shape var11 = var9.getArea();
    java.lang.Object var12 = var9.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var10.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 100.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-10289251));

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    var0.mapDatasetToRangeAxis(0, 0);
    java.lang.String var12 = var0.getNoDataMessage();
    java.awt.Paint var13 = var0.getNoDataMessagePaint();
    org.jfree.chart.util.SortOrder var14 = var0.getColumnRenderingOrder();
    org.jfree.chart.plot.CategoryMarker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(15, var16, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Paint var5 = var0.getRangeGridlinePaint();
    org.jfree.chart.LegendItemCollection var6 = var0.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 100.0f, 1.0f, var17, 2.0f, (-1.0f), (-1.0d));
    org.jfree.chart.text.TextBlockAnchor var22 = null;
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var25 = null;
    var24.setOutlineStroke(var25);
    org.jfree.chart.event.AxisChangeEvent var27 = null;
    var24.axisChanged(var27);
    var24.clearAnnotations();
    var23.addChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
    java.awt.Shape var32 = var23.getSeriesShape(1);
    java.awt.Paint var34 = var23.lookupSeriesFillPaint((-1));
    boolean var35 = var23.getIncludeBaseInRange();
    java.awt.Font var36 = var23.getBaseItemLabelFont();
    var23.setSeriesCreateEntities(10, (java.lang.Boolean)false, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var43 = var23.getItemLabelGenerator(10, 0);
    java.awt.Stroke var44 = var23.getBaseOutlineStroke();
    boolean var46 = var23.isSeriesVisibleInLegend(0);
    org.jfree.chart.block.LabelBlock var48 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Color var51 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var52 = var51.darker();
    var48.setPaint((java.awt.Paint)var52);
    var23.setBaseItemLabelPaint((java.awt.Paint)var52, false);
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    var56.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var59 = var56.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var60 = var59.getItemLabelAnchor();
    var23.setNegativeItemLabelPositionFallback(var59);
    org.jfree.chart.text.TextAnchor var62 = var59.getTextAnchor();
    java.lang.String var63 = var62.toString();
    org.jfree.chart.axis.CategoryTick var65 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"RectangleConstraint[LengthConstraintType.FIXED: width=1.0E-8, height=2.0]", var12, var22, var62, 4.0d);
    org.jfree.chart.text.TextAnchor var66 = var65.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var68 = new org.jfree.chart.axis.NumberTick(var0, 0.0d, "[size=1]", var3, var66, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + "TextAnchor.BOTTOM_CENTER"+ "'", var63.equals("TextAnchor.BOTTOM_CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    double var3 = var1.calculateBottomInset(0.0d);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var5 = null;
    var4.setOutlineStroke(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    java.awt.Paint var9 = var4.getRangeGridlinePaint();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var15 = java.awt.Color.getColor("", 10);
    var12.setTickMarkPaint((java.awt.Paint)var15);
    org.jfree.chart.axis.TickUnitSource var17 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var12.setStandardTickUnits(var17);
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var22 = var21.getBounds();
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var12.lengthToJava2D((-1.0d), var22, var23);
    org.jfree.chart.ChartRenderingInfo var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
    boolean var28 = var4.render(var10, var22, 10, var27);
    java.awt.geom.Rectangle2D var29 = var1.createOutsetRectangle(var22);
    double var31 = var1.calculateRightInset((-1.99999999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "ThreadContext", "", "", "TextAnchor.BOTTOM_CENTER");

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    java.lang.String var2 = var1.toString();
    double var3 = var1.getRight();
    double var5 = var1.calculateLeftInset(106.0d);
    double var7 = var1.calculateBottomOutset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    org.jfree.chart.event.AxisChangeEvent var13 = null;
    var10.axisChanged(var13);
    var10.clearAnnotations();
    var9.addChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
    java.awt.Shape var18 = var9.getSeriesShape(1);
    boolean var19 = var9.getAutoPopulateSeriesStroke();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var22 = null;
    var21.setOutlineStroke(var22);
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var21.axisChanged(var24);
    var21.setRangeGridlinesVisible(false);
    boolean var28 = var21.isRangeCrosshairVisible();
    java.awt.Stroke var29 = var21.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var31 = var21.getDataset(10);
    org.jfree.chart.event.PlotChangeEvent var32 = null;
    var21.notifyListeners(var32);
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    float var35 = var34.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var36 = var34.getLabelInsets();
    boolean var37 = var34.isVerticalTickLabels();
    boolean var38 = var34.isNegativeArrowVisible();
    boolean var39 = var34.isNegativeArrowVisible();
    int var40 = var21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var34);
    java.awt.Paint var41 = var21.getRangeCrosshairPaint();
    var9.setSeriesFillPaint(1, var41);
    var9.setBaseCreateEntities(true);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var32 = var31.getHorizontalAlignment();
//     var30.setTitle(var31);
//     org.jfree.chart.title.LegendTitle var34 = var30.getLegend();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var36 = null;
//     var35.setOutlineStroke(var36);
//     org.jfree.chart.event.AxisChangeEvent var38 = null;
//     var35.axisChanged(var38);
//     var35.setRangeGridlinesVisible(false);
//     boolean var42 = var35.isRangeCrosshairVisible();
//     java.awt.Stroke var43 = var35.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var45 = var35.getDomainAxisEdge(100);
//     var34.setLegendItemGraphicEdge(var45);
//     
//     // Checks the contract:  equals-hashcode on var1 and var35
//     assertTrue("Contract failed: equals-hashcode on var1 and var35", var1.equals(var35) ? var1.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var1
//     assertTrue("Contract failed: equals-hashcode on var35 and var1", var35.equals(var1) ? var35.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    java.awt.Shape var4 = var0.getRightArrow();
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var4);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    float var10 = var9.getTickMarkOutsideLength();
    var9.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.AxisState var15 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    java.util.List var18 = var9.refreshTicks(var14, var15, var16, var17);
    var15.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis();
    float var22 = var21.getTickMarkOutsideLength();
    var21.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var28 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var29 = var28.getBounds();
    org.jfree.chart.util.RectangleEdge var30 = null;
    double var31 = var21.valueToJava2D(100.0d, var29, var30);
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var7.refreshTicks(var8, var15, var29, var32);
    java.awt.Shape var34 = var7.getLeftArrow();
    boolean var35 = var5.equals((java.lang.Object)var34);
    var5.setToolTipText("ThreadContext");
    java.lang.String var38 = var5.getURLText();
    java.lang.String var39 = var5.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "0,0,-2,-2,-2,2,-2,2"+ "'", var39.equals("0,0,-2,-2,-2,2,-2,2"));

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(byte)100);
    java.util.List var4 = var0.getKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var6 = java.awt.Color.getColor("", 10);
//     var3.setTickMarkPaint((java.awt.Paint)var6);
//     var0.setSeriesItemLabelPaint(100, (java.awt.Paint)var6, true);
//     org.jfree.chart.LegendItem var12 = var0.getLegendItem(0, (-1));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var0.getLegendItemLabelGenerator();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var16 = null;
//     var15.setOutlineStroke(var16);
//     org.jfree.chart.event.AxisChangeEvent var18 = null;
//     var15.axisChanged(var18);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     org.jfree.chart.axis.ValueAxis var23 = var15.getRangeAxis((-1));
//     java.awt.Stroke var24 = var15.getRangeCrosshairStroke();
//     java.awt.geom.Rectangle2D var25 = null;
//     var0.drawDomainGridline(var14, var15, var25, (-1.0000000000000001E-16d));
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.clone(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.lang.Object var3 = var0.handleGetObject("ItemLabelAnchor.OUTSIDE12");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var3 = null;
//     var2.setOutlineStroke(var3);
//     org.jfree.chart.event.AxisChangeEvent var5 = null;
//     var2.axisChanged(var5);
//     var2.clearAnnotations();
//     var2.configureDomainAxes();
//     var2.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var12 = var2.getRangeAxisEdge(0);
//     var0.add(0.0d, var12);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     float var18 = var17.getTickMarkOutsideLength();
//     var17.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.AxisState var23 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     java.util.List var26 = var17.refreshTicks(var22, var23, var24, var25);
//     var23.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis();
//     float var30 = var29.getTickMarkOutsideLength();
//     var29.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var37 = var36.getBounds();
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var29.valueToJava2D(100.0d, var37, var38);
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     java.util.List var41 = var15.refreshTicks(var16, var23, var37, var40);
//     org.jfree.chart.axis.CategoryLabelPositions var43 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var45 = null;
//     var44.setOutlineStroke(var45);
//     org.jfree.chart.event.AxisChangeEvent var47 = null;
//     var44.axisChanged(var47);
//     var44.setRangeGridlinesVisible(false);
//     boolean var51 = var44.isRangeCrosshairVisible();
//     java.awt.Stroke var52 = var44.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var54 = var44.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var55 = var43.getLabelPosition(var54);
//     double var56 = org.jfree.chart.util.RectangleEdge.coordinate(var37, var54);
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var59 = var58.getMargin();
//     var58.setPadding(0.0d, 106.0d, 100.0d, 100.0d);
//     java.lang.String var65 = var58.getToolTipText();
//     java.awt.geom.Rectangle2D var66 = var58.getBounds();
//     boolean var67 = org.jfree.chart.util.ShapeUtilities.intersects(var37, var66);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var69 = null;
//     var68.setOutlineStroke(var69);
//     org.jfree.chart.event.AxisChangeEvent var71 = null;
//     var68.axisChanged(var71);
//     java.awt.Paint var73 = var68.getRangeGridlinePaint();
//     java.awt.Graphics2D var74 = null;
//     org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var79 = java.awt.Color.getColor("", 10);
//     var76.setTickMarkPaint((java.awt.Paint)var79);
//     org.jfree.chart.axis.TickUnitSource var81 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var76.setStandardTickUnits(var81);
//     org.jfree.chart.block.LabelBlock var85 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var86 = var85.getBounds();
//     org.jfree.chart.util.RectangleEdge var87 = null;
//     double var88 = var76.lengthToJava2D((-1.0d), var86, var87);
//     org.jfree.chart.ChartRenderingInfo var90 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var91 = new org.jfree.chart.plot.PlotRenderingInfo(var90);
//     boolean var92 = var68.render(var74, var86, 10, var91);
//     java.awt.geom.Rectangle2D var93 = var91.getDataArea();
//     java.awt.geom.Rectangle2D var94 = var0.shrink(var66, var93);
//     
//     // Checks the contract:  equals-hashcode on var2 and var68
//     assertTrue("Contract failed: equals-hashcode on var2 and var68", var2.equals(var68) ? var2.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var2
//     assertTrue("Contract failed: equals-hashcode on var68 and var2", var68.equals(var2) ? var68.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var85
//     assertTrue("Contract failed: equals-hashcode on var36 and var85", var36.equals(var85) ? var36.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var36
//     assertTrue("Contract failed: equals-hashcode on var85 and var36", var85.equals(var36) ? var85.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    float var2 = var1.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    org.jfree.data.Range var4 = var1.getRange();
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var12.axisChanged(var15);
    var12.clearAnnotations();
    var11.addChangeListener((org.jfree.chart.event.RendererChangeListener)var12);
    java.awt.Shape var20 = var11.getSeriesShape(1);
    java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var24 = var23.darker();
    int var25 = var24.getBlue();
    var11.setBasePaint((java.awt.Paint)var24);
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
    float var32 = var31.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var33 = var31.getLabelInsets();
    boolean var34 = var31.isVerticalTickLabels();
    java.awt.Shape var35 = var31.getRightArrow();
    org.jfree.chart.entity.ChartEntity var36 = new org.jfree.chart.entity.ChartEntity(var35);
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
    float var41 = var40.getTickMarkOutsideLength();
    var40.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.axis.AxisState var46 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.util.RectangleEdge var48 = null;
    java.util.List var49 = var40.refreshTicks(var45, var46, var47, var48);
    var46.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
    float var53 = var52.getTickMarkOutsideLength();
    var52.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var59 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var60 = var59.getBounds();
    org.jfree.chart.util.RectangleEdge var61 = null;
    double var62 = var52.valueToJava2D(100.0d, var60, var61);
    org.jfree.chart.util.RectangleEdge var63 = null;
    java.util.List var64 = var38.refreshTicks(var39, var46, var60, var63);
    java.awt.Shape var65 = var38.getLeftArrow();
    boolean var66 = var36.equals((java.lang.Object)var65);
    org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis();
    var67.setTickMarksVisible(false);
    java.awt.Stroke var70 = var67.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var74 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var75 = var74.darker();
    var71.setLabelPaint((java.awt.Paint)var74);
    float[] var80 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var81 = var74.getColorComponents(var80);
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var65, var70, (java.awt.Paint)var74);
    java.awt.Color var85 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var86 = var85.darker();
    org.jfree.chart.LegendItem var87 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "", "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var10, (java.awt.Paint)var24, var70, (java.awt.Paint)var86);
    var1.setAxisLineStroke(var70);
    org.jfree.chart.axis.NumberTickUnit var89 = var1.getTickUnit();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var91 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)var89, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     var1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
//     java.awt.Paint var10 = var8.getBaseOutlinePaint();
//     java.awt.Font var17 = null;
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var21 = var20.darker();
//     int var22 = var21.getBlue();
//     org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21);
//     org.jfree.chart.util.HorizontalAlignment var24 = var23.getLineAlignment();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.text.TextBlockAnchor var28 = null;
//     java.awt.Shape var32 = var23.calculateBounds(var25, 10.0f, (-1.0f), var28, (-1.0f), 1.0f, 1.0d);
//     java.awt.Color var36 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var32, (java.awt.Paint)var36);
//     java.text.AttributedString var38 = var37.getAttributedLabel();
//     boolean var39 = var37.isShapeOutlineVisible();
//     java.awt.Stroke var40 = var37.getOutlineStroke();
//     var8.setSeriesStroke(0, var40, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var8.", var0.equals(var8) == var8.equals(var0));
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("HorizontalAlignment.CENTER", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var29 = var28.darker();
    int var30 = var29.getBlue();
    float[] var34 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var35 = var29.getColorComponents(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var36 = var24.getRGBComponents(var34);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 1);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RangeType.FULL", "LengthConstraintType.FIXED", var3);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("CONTRACT");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    var0.setAutoRangeMinimumSize(10.0d);
    var0.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var0.resizeRange((-1.0d), 3.0d);
    var0.setTickMarksVisible(false);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    float var13 = var12.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var14 = var12.getLabelInsets();
    org.jfree.data.Range var15 = var12.getRange();
    org.jfree.data.Range var16 = var12.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    float var19 = var18.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var20 = var18.getLabelInsets();
    java.text.NumberFormat var21 = var18.getNumberFormatOverride();
    boolean var22 = var18.getAutoRangeStickyZero();
    org.jfree.data.Range var25 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var28 = org.jfree.data.Range.expand(var25, 1.0E-8d, 0.0d);
    var18.setRange(var25);
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(0.0d, var25);
    org.jfree.data.Range var31 = org.jfree.data.Range.combine(var16, var25);
    double var32 = var16.getCentralValue();
    org.jfree.data.Range var35 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var38 = org.jfree.data.Range.expand(var35, 1.0E-8d, 0.0d);
    org.jfree.data.Range var41 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var44 = org.jfree.data.Range.expand(var41, 1.0E-8d, 0.0d);
    org.jfree.data.Range var45 = org.jfree.data.Range.combine(var38, var44);
    java.lang.Object var46 = null;
    boolean var47 = var44.equals(var46);
    org.jfree.data.Range var48 = org.jfree.data.Range.combine(var16, var44);
    var0.setRange(var44, false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    boolean var10 = var0.getAutoPopulateSeriesStroke();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var11 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = var0.getBaseToolTipGenerator();
    org.jfree.chart.event.RendererChangeListener var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeChangeListener(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    var0.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.event.MarkerChangeEvent var12 = null;
    var0.markerChanged(var12);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    float var15 = var14.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var16 = var14.getLabelInsets();
    org.jfree.data.Range var17 = var14.getRange();
    org.jfree.data.Range var18 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.axis.AxisLocation var20 = null;
    var0.setRangeAxisLocation(10, var20, true);
    org.jfree.chart.axis.CategoryAnchor var23 = var0.getDomainGridlinePosition();
    java.util.List var24 = var0.getAnnotations();
    org.jfree.chart.plot.CategoryMarker var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    double var4 = var0.getLowerMargin();
    var0.setTickMarkInsideLength(1.0f);
    var0.setRangeAboutValue(10.0d, 10.0d);
    java.awt.Shape var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLeftArrow(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.setRangeGridlinesVisible(false);
    boolean var8 = var1.isRangeCrosshairVisible();
    java.awt.Stroke var9 = var1.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    float var13 = var12.getTickMarkOutsideLength();
    var12.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var20 = var19.getBounds();
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var12.valueToJava2D(100.0d, var20, var21);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleAnchor var24 = null;
    java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
    org.jfree.chart.plot.PlotState var26 = null;
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    var1.draw(var11, var20, var25, var26, var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.CategoryPlot var31 = var30.getCategoryPlot();
    java.awt.Paint var32 = var30.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var35 = var30.createBufferedImage((-10289251), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var3 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var4 = var3.darker();
//     var0.setLabelPaint((java.awt.Paint)var3);
//     var0.setLabelToolTip("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     var0.setTickLabelsVisible(false);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
//     float var15 = var14.getTickMarkOutsideLength();
//     var14.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.AxisState var20 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     java.util.List var23 = var14.refreshTicks(var19, var20, var21, var22);
//     var20.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     float var27 = var26.getTickMarkOutsideLength();
//     var26.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var34 = var33.getBounds();
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var26.valueToJava2D(100.0d, var34, var35);
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     java.util.List var38 = var12.refreshTicks(var13, var20, var34, var37);
//     double var39 = var20.getMax();
//     org.jfree.chart.block.LineBorder var40 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var41 = var40.getInsets();
//     double var43 = var41.calculateBottomInset(0.0d);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var45 = null;
//     var44.setOutlineStroke(var45);
//     org.jfree.chart.event.AxisChangeEvent var47 = null;
//     var44.axisChanged(var47);
//     java.awt.Paint var49 = var44.getRangeGridlinePaint();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var55 = java.awt.Color.getColor("", 10);
//     var52.setTickMarkPaint((java.awt.Paint)var55);
//     org.jfree.chart.axis.TickUnitSource var57 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var52.setStandardTickUnits(var57);
//     org.jfree.chart.block.LabelBlock var61 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var62 = var61.getBounds();
//     org.jfree.chart.util.RectangleEdge var63 = null;
//     double var64 = var52.lengthToJava2D((-1.0d), var62, var63);
//     org.jfree.chart.ChartRenderingInfo var66 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var67 = new org.jfree.chart.plot.PlotRenderingInfo(var66);
//     boolean var68 = var44.render(var50, var62, 10, var67);
//     java.awt.geom.Rectangle2D var69 = var41.createOutsetRectangle(var62);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var71 = null;
//     var70.setOutlineStroke(var71);
//     org.jfree.chart.event.AxisChangeEvent var73 = null;
//     var70.axisChanged(var73);
//     var70.clearAnnotations();
//     var70.configureDomainAxes();
//     var70.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var80 = var70.getRangeAxisEdge(0);
//     java.util.List var81 = var0.refreshTicks(var10, var20, var62, var80);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.5d, 10.0d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    java.util.List var1 = var0.getTicks();
    var0.cursorLeft((-4.0d));
    double var4 = var0.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 0.5f, 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-8372160));

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    float var6 = var5.getTickMarkOutsideLength();
    var5.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.AxisState var11 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleEdge var13 = null;
    java.util.List var14 = var5.refreshTicks(var10, var11, var12, var13);
    var11.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
    float var18 = var17.getTickMarkOutsideLength();
    var17.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var25 = var24.getBounds();
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var17.valueToJava2D(100.0d, var25, var26);
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var3.refreshTicks(var4, var11, var25, var28);
    java.awt.Shape var30 = var3.getLeftArrow();
    java.awt.Font var31 = var3.getLabelFont();
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var33 = null;
    var32.setOutlineStroke(var33);
    org.jfree.chart.event.AxisChangeEvent var35 = null;
    var32.axisChanged(var35);
    var32.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.CategoryAxis var39 = var32.getDomainAxis();
    java.awt.Paint var40 = var32.getBackgroundPaint();
    org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("", var31, var40);
    org.jfree.chart.axis.NumberTickUnit var43 = new org.jfree.chart.axis.NumberTickUnit((-1.0d));
    int var44 = var43.getMinorTickCount();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
    float var46 = var45.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var47 = var45.getLabelInsets();
    boolean var48 = var45.isVerticalTickLabels();
    java.awt.Shape var49 = var45.getRightArrow();
    int var50 = var43.compareTo((java.lang.Object)var49);
    boolean var51 = var41.equals((java.lang.Object)var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var52 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     java.awt.Font var6 = null;
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var10 = var9.darker();
//     int var11 = var10.getBlue();
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
//     org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
//     java.awt.Color var25 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var21, (java.awt.Paint)var25);
//     var26.setDatasetIndex(0);
//     var0.add(var26);
//     org.jfree.chart.LegendItemCollection var30 = new org.jfree.chart.LegendItemCollection();
//     java.awt.Font var36 = null;
//     java.awt.Color var39 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var40 = var39.darker();
//     int var41 = var40.getBlue();
//     org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var40);
//     org.jfree.chart.util.HorizontalAlignment var43 = var42.getLineAlignment();
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.text.TextBlockAnchor var47 = null;
//     java.awt.Shape var51 = var42.calculateBounds(var44, 10.0f, (-1.0f), var47, (-1.0f), 1.0f, 1.0d);
//     java.awt.Color var55 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var51, (java.awt.Paint)var55);
//     var56.setDatasetIndex(0);
//     var30.add(var56);
//     var0.addAll(var30);
//     org.jfree.chart.LegendItem var62 = var30.get(0);
//     java.lang.Object var63 = var30.clone();
//     java.lang.Object var64 = var30.clone();
//     
//     // Checks the contract:  equals-hashcode on var63 and var64
//     assertTrue("Contract failed: equals-hashcode on var63 and var64", var63.equals(var64) ? var63.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var63
//     assertTrue("Contract failed: equals-hashcode on var64 and var63", var64.equals(var63) ? var64.hashCode() == var63.hashCode() : true);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var6 = java.awt.Color.getColor("", 10);
    var3.setTickMarkPaint((java.awt.Paint)var6);
    var0.setSeriesItemLabelPaint(100, (java.awt.Paint)var6, true);
    java.awt.Color var12 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var13 = var12.darker();
    int var14 = var13.getBlue();
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var13);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var19 = var18.darker();
    int var20 = var19.getBlue();
    float[] var24 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var25 = var19.getColorComponents(var24);
    float[] var26 = var13.getColorComponents(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var27 = var6.getRGBComponents(var25);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var6 = java.awt.Color.getColor("", 10);
    var3.setTickMarkPaint((java.awt.Paint)var6);
    var0.setSeriesItemLabelPaint(100, (java.awt.Paint)var6, true);
    var0.setSeriesItemLabelsVisible(1, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var0.getNegativeItemLabelPosition(100, 1);
    var0.setIncludeBaseInRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var32 = var31.getHorizontalAlignment();
//     var30.setTitle(var31);
//     var30.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.event.ChartProgressListener var36 = null;
//     var30.removeProgressListener(var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     float var40 = var39.getTickMarkOutsideLength();
//     var39.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var47 = var46.getBounds();
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = var39.valueToJava2D(100.0d, var47, var48);
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleAnchor var51 = null;
//     java.awt.geom.Point2D var52 = org.jfree.chart.util.RectangleAnchor.coordinates(var50, var51);
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     var30.draw(var38, var47, var52, var53);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    java.lang.Object var0 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var3 = null;
    var2.setOutlineStroke(var3);
    org.jfree.chart.event.AxisChangeEvent var5 = null;
    var2.axisChanged(var5);
    var2.setRangeGridlinesVisible(false);
    boolean var9 = var2.isRangeCrosshairVisible();
    java.awt.Stroke var10 = var2.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var11 = var2.getDataset();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis();
    float var14 = var13.getTickMarkOutsideLength();
    var13.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var21 = var20.getBounds();
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var13.valueToJava2D(100.0d, var21, var22);
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleAnchor var25 = null;
    java.awt.geom.Point2D var26 = org.jfree.chart.util.RectangleAnchor.coordinates(var24, var25);
    org.jfree.chart.plot.PlotState var27 = null;
    org.jfree.chart.ChartRenderingInfo var28 = null;
    org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
    var2.draw(var12, var21, var26, var27, var29);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.plot.CategoryPlot var32 = var31.getCategoryPlot();
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var34 = var33.clone();
    org.jfree.chart.util.VerticalAlignment var35 = var33.getVerticalAlignment();
    var31.removeSubtitle((org.jfree.chart.title.Title)var33);
    java.awt.Image var37 = var31.getBackgroundImage();
    java.awt.Paint var38 = var31.getBorderPaint();
    java.awt.Paint var39 = var31.getBorderPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var40 = new org.jfree.chart.event.ChartChangeEvent(var0, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var30.setAntiAlias(false);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var34 = null;
//     var33.setOutlineStroke(var34);
//     org.jfree.chart.event.AxisChangeEvent var36 = null;
//     var33.axisChanged(var36);
//     var33.setRangeGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var40 = var33.getFixedRangeAxisSpace();
//     double var41 = var33.getRangeCrosshairValue();
//     boolean var42 = var33.isDomainGridlinesVisible();
//     org.jfree.chart.event.PlotChangeEvent var43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var33);
//     var30.plotChanged(var43);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    boolean var7 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var9 = var0.getDataset();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    float var12 = var11.getTickMarkOutsideLength();
    var11.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var18 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var19 = var18.getBounds();
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var11.valueToJava2D(100.0d, var19, var20);
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleAnchor var23 = null;
    java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
    org.jfree.chart.plot.PlotState var25 = null;
    org.jfree.chart.ChartRenderingInfo var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
    var0.draw(var10, var19, var24, var25, var27);
    int var29 = var27.getSubplotCount();
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    int var32 = var31.getSubplotCount();
    java.awt.geom.Rectangle2D var33 = null;
    var31.setDataArea(var33);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    var31.addSubplotInfo(var35);
    var27.addSubplotInfo(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var14 = null;
    var13.setOutlineStroke(var14);
    boolean var16 = var12.equals((java.lang.Object)var13);
    org.jfree.data.KeyedObjects2D var17 = new org.jfree.data.KeyedObjects2D();
    java.util.List var18 = var17.getRowKeys();
    var17.removeObject((java.lang.Comparable)10.0d, (java.lang.Comparable)100);
    int var22 = var17.getRowCount();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
    float var24 = var23.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var25 = var23.getLabelInsets();
    org.jfree.data.Range var26 = var23.getRange();
    org.jfree.data.Range var27 = var23.getDefaultAutoRange();
    var17.setObject((java.lang.Object)var23, (java.lang.Comparable)4.0d, (java.lang.Comparable)0.2d);
    boolean var31 = var12.equals((java.lang.Object)4.0d);
    java.awt.Font var33 = null;
    java.awt.Color var36 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var37 = var36.darker();
    int var38 = var37.getBlue();
    org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("", var33, (java.awt.Paint)var37);
    org.jfree.chart.util.HorizontalAlignment var40 = var39.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 1.0E-8d, (-1.0d));
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var48 = var47.getMargin();
    var47.setHeight(0.0d);
    java.awt.Paint var51 = var47.getPaint();
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var53 = null;
    var52.setOutlineStroke(var53);
    org.jfree.chart.event.AxisChangeEvent var55 = null;
    var52.axisChanged(var55);
    var52.setRangeGridlinesVisible(false);
    boolean var59 = var52.isRangeCrosshairVisible();
    java.awt.Stroke var60 = var52.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var62 = var52.getDomainAxisEdge(100);
    org.jfree.chart.LegendItemCollection var63 = var52.getLegendItems();
    var45.add((org.jfree.chart.block.Block)var47, (java.lang.Object)var52);
    java.awt.Graphics2D var65 = null;
    org.jfree.data.Range var67 = null;
    org.jfree.chart.block.RectangleConstraint var68 = new org.jfree.chart.block.RectangleConstraint(10.0d, var67);
    org.jfree.chart.block.LengthConstraintType var69 = var68.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var70 = var68.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var71 = var12.arrange(var45, var65, var70);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 2.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 2.0d};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    org.jfree.data.Range var3 = var0.getRange();
    org.jfree.data.Range var4 = var0.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    float var7 = var6.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var8 = var6.getLabelInsets();
    java.text.NumberFormat var9 = var6.getNumberFormatOverride();
    boolean var10 = var6.getAutoRangeStickyZero();
    org.jfree.data.Range var13 = new org.jfree.data.Range(0.0d, 1.0E-8d);
    org.jfree.data.Range var16 = org.jfree.data.Range.expand(var13, 1.0E-8d, 0.0d);
    var6.setRange(var13);
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(0.0d, var13);
    org.jfree.data.Range var19 = org.jfree.data.Range.combine(var4, var13);
    org.jfree.data.Range var22 = org.jfree.data.Range.shift(var19, 0.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     var0.configureRangeAxes();
//     var0.clearDomainAxes();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     float var17 = var16.getTickMarkOutsideLength();
//     var16.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.AxisState var22 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     java.util.List var25 = var16.refreshTicks(var21, var22, var23, var24);
//     var22.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     float var29 = var28.getTickMarkOutsideLength();
//     var28.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var36 = var35.getBounds();
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var28.valueToJava2D(100.0d, var36, var37);
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     java.util.List var40 = var14.refreshTicks(var15, var22, var36, var39);
//     double var41 = var14.getLowerBound();
//     org.jfree.data.Range var42 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var44 = null;
//     var43.setOutlineStroke(var44);
//     org.jfree.chart.event.AxisChangeEvent var46 = null;
//     var43.axisChanged(var46);
//     var43.setRangeGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var50 = var43.getFixedRangeAxisSpace();
//     var14.addChangeListener((org.jfree.chart.event.AxisChangeListener)var43);
//     
//     // Checks the contract:  equals-hashcode on var0 and var43
//     assertTrue("Contract failed: equals-hashcode on var0 and var43", var0.equals(var43) ? var0.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var0
//     assertTrue("Contract failed: equals-hashcode on var43 and var0", var43.equals(var0) ? var43.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.util.VerticalAlignment var3 = var1.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement(var0, var3, 0.05d, (-4.0d));
//     java.awt.Font var8 = null;
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var12 = var11.darker();
//     int var13 = var12.getBlue();
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var8, (java.awt.Paint)var12);
//     org.jfree.chart.util.HorizontalAlignment var15 = var14.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 1.0E-8d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var20 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var19);
//     java.lang.Object var21 = var20.clone();
//     org.jfree.chart.block.Block var22 = null;
//     var20.add(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var20.getPadding();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.data.Range var26 = null;
//     org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, 10.0d);
//     double var29 = var28.getHeight();
//     org.jfree.chart.util.Size2D var30 = var6.arrange(var20, var25, var28);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    var0.mapDatasetToRangeAxis(0, 0);
    java.lang.String var12 = var0.getNoDataMessage();
    java.awt.Stroke var13 = var0.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.event.PlotChangeListener var5 = null;
    var0.addChangeListener(var5);
    org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
    java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var0.setDomainAxis(100, var12);
    var12.setMaximumCategoryLabelWidthRatio(0.8f);
    var12.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis();
    float var4 = var3.getTickMarkOutsideLength();
    var3.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var9 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    java.util.List var12 = var3.refreshTicks(var8, var9, var10, var11);
    var9.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    float var16 = var15.getTickMarkOutsideLength();
    var15.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var15.valueToJava2D(100.0d, var23, var24);
    org.jfree.chart.util.RectangleEdge var26 = null;
    java.util.List var27 = var1.refreshTicks(var2, var9, var23, var26);
    double var28 = var1.getLowerBound();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(0.05d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var25 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var21, (java.awt.Paint)var25);
    org.jfree.chart.entity.CategoryLabelEntity var29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(-1.0f), var21, "HorizontalAlignment.CENTER", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.Object var30 = var29.clone();
    var29.setToolTipText("LengthConstraintType.FIXED");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     boolean var10 = var0.getAutoPopulateSeriesStroke();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var13 = null;
//     var12.setOutlineStroke(var13);
//     org.jfree.chart.event.AxisChangeEvent var15 = null;
//     var12.axisChanged(var15);
//     var12.setRangeGridlinesVisible(false);
//     boolean var19 = var12.isRangeCrosshairVisible();
//     java.awt.Stroke var20 = var12.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var22 = var12.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var23 = null;
//     var12.notifyListeners(var23);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     float var26 = var25.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var27 = var25.getLabelInsets();
//     boolean var28 = var25.isVerticalTickLabels();
//     boolean var29 = var25.isNegativeArrowVisible();
//     boolean var30 = var25.isNegativeArrowVisible();
//     int var31 = var12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
//     java.awt.Paint var32 = var12.getRangeCrosshairPaint();
//     var0.setSeriesFillPaint(1, var32);
//     org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var41 = java.awt.Color.getColor("", 10);
//     var38.setTickMarkPaint((java.awt.Paint)var41);
//     var35.setSeriesItemLabelPaint(100, (java.awt.Paint)var41, true);
//     var35.setSeriesItemLabelsVisible(1, false);
//     org.jfree.chart.labels.ItemLabelPosition var50 = var35.getNegativeItemLabelPosition(100, 1);
//     var0.setSeriesNegativeItemLabelPosition(0, var50, true);
//     org.jfree.chart.labels.ItemLabelPosition var55 = var0.getNegativeItemLabelPosition(10, (-1));
//     
//     // Checks the contract:  equals-hashcode on var50 and var55
//     assertTrue("Contract failed: equals-hashcode on var50 and var55", var50.equals(var55) ? var50.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var50
//     assertTrue("Contract failed: equals-hashcode on var55 and var50", var55.equals(var50) ? var55.hashCode() == var50.hashCode() : true);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.lang.String var2 = var1.getID();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var5 = null;
    var4.setOutlineStroke(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    var4.setRangeGridlinesVisible(false);
    boolean var11 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var12 = var4.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var14 = var4.getDomainAxisEdge(100);
    org.jfree.chart.axis.CategoryLabelPosition var15 = var3.getLabelPosition(var14);
    float var16 = var15.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelWidthType var17 = var15.getWidthType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition(var1, var2, var17, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.95f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "LengthConstraintType.FIXED", var3);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     int var6 = var0.getDomainAxisIndex(var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var9 = null;
//     var8.setOutlineStroke(var9);
//     org.jfree.chart.event.AxisChangeEvent var11 = null;
//     var8.axisChanged(var11);
//     java.awt.Paint var13 = var8.getRangeGridlinePaint();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Color var19 = java.awt.Color.getColor("", 10);
//     var16.setTickMarkPaint((java.awt.Paint)var19);
//     org.jfree.chart.axis.TickUnitSource var21 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
//     var16.setStandardTickUnits(var21);
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var26 = var25.getBounds();
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var16.lengthToJava2D((-1.0d), var26, var27);
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     boolean var32 = var8.render(var14, var26, 10, var31);
//     java.awt.geom.Rectangle2D var33 = var31.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.event.MarkerChangeEvent var35 = null;
//     var34.markerChanged(var35);
//     org.jfree.chart.util.RectangleEdge var38 = var34.getDomainAxisEdge(1);
//     double var39 = org.jfree.chart.util.RectangleEdge.coordinate(var33, var38);
//     var0.drawBackgroundImage(var7, var33);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    int var6 = var5.getBlue();
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
    org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.util.VerticalAlignment var15 = var13.getVerticalAlignment();
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var8, var15, 0.05d, (-1.0d));
    org.jfree.chart.util.HorizontalAlignment var19 = null;
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var21 = var20.clone();
    org.jfree.chart.util.VerticalAlignment var22 = var20.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement(var19, var22, 0.05d, (-4.0d));
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var8, var22, Double.POSITIVE_INFINITY, 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    java.awt.Font var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var9 = var8.darker();
    int var10 = var9.getBlue();
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9);
    org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var11.calculateBounds(var13, 10.0f, (-1.0f), var16, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var24 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var20, (java.awt.Paint)var24);
    java.text.AttributedString var26 = var25.getAttributedLabel();
    boolean var27 = var25.isShapeOutlineVisible();
    java.awt.Stroke var28 = var25.getOutlineStroke();
    java.awt.Paint var29 = var25.getOutlinePaint();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var25.setDataset((org.jfree.data.general.Dataset)var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var34 = var30.getMeanValue(100, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     org.jfree.chart.event.PlotChangeListener var5 = null;
//     var0.addChangeListener(var5);
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxis((-1));
//     java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var0.setDomainAxis(100, var12);
//     var12.addCategoryLabelToolTip((java.lang.Comparable)1.0f, "AxisLocation.BOTTOM_OR_RIGHT");
//     double var17 = var12.getCategoryMargin();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.axis.AxisState var19 = new org.jfree.chart.axis.AxisState();
//     java.util.List var20 = var19.getTicks();
//     org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var22 = var21.getInsets();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var28 = var27.darker();
//     var24.setLabelPaint((java.awt.Paint)var27);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     float var31 = var30.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
//     double var34 = var32.extendHeight(100.0d);
//     var24.setTickLabelInsets(var32);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     float var37 = var36.getTickMarkOutsideLength();
//     var36.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var44 = var43.getBounds();
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var36.valueToJava2D(100.0d, var44, var45);
//     java.awt.geom.Rectangle2D var49 = var32.createInsetRectangle(var44, true, false);
//     var21.draw(var23, var49);
//     org.jfree.chart.axis.CategoryLabelPositions var51 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var53 = null;
//     var52.setOutlineStroke(var53);
//     org.jfree.chart.event.AxisChangeEvent var55 = null;
//     var52.axisChanged(var55);
//     var52.setRangeGridlinesVisible(false);
//     boolean var59 = var52.isRangeCrosshairVisible();
//     java.awt.Stroke var60 = var52.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var62 = var52.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var63 = var51.getLabelPosition(var62);
//     boolean var64 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var62);
//     java.util.List var65 = var12.refreshTicks(var18, var19, var49, var62);
//     org.jfree.chart.axis.CategoryLabelPositions var67 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var69 = null;
//     var68.setOutlineStroke(var69);
//     org.jfree.chart.event.AxisChangeEvent var71 = null;
//     var68.axisChanged(var71);
//     var68.setRangeGridlinesVisible(false);
//     boolean var75 = var68.isRangeCrosshairVisible();
//     java.awt.Stroke var76 = var68.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var78 = var68.getDomainAxisEdge(100);
//     org.jfree.chart.axis.CategoryLabelPosition var79 = var67.getLabelPosition(var78);
//     org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis();
//     float var81 = var80.getTickMarkOutsideLength();
//     var80.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var85 = null;
//     org.jfree.chart.axis.AxisState var86 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var87 = null;
//     org.jfree.chart.util.RectangleEdge var88 = null;
//     java.util.List var89 = var80.refreshTicks(var85, var86, var87, var88);
//     boolean var90 = var67.equals((java.lang.Object)var86);
//     var12.setCategoryLabelPositions(var67);
//     
//     // Checks the contract:  equals-hashcode on var52 and var68
//     assertTrue("Contract failed: equals-hashcode on var52 and var68", var52.equals(var68) ? var52.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var52
//     assertTrue("Contract failed: equals-hashcode on var68 and var52", var68.equals(var52) ? var68.hashCode() == var52.hashCode() : true);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    java.awt.Shape var4 = var0.getRightArrow();
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var4);
    java.awt.Shape var6 = var5.getArea();
    java.lang.Object var7 = var5.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    org.jfree.chart.labels.ItemLabelPosition var8 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var15 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var16 = var15.darker();
    var12.setLabelPaint((java.awt.Paint)var15);
    float[] var21 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var22 = var15.getColorComponents(var21);
    java.awt.Color var23 = java.awt.Color.getColor("", var15);
    java.awt.Color var24 = var23.darker();
    var0.setBaseOutlinePaint((java.awt.Paint)var23);
    java.awt.Stroke var26 = var0.getBaseStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     float var2 = var1.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
//     boolean var4 = var1.isVerticalTickLabels();
//     boolean var5 = var1.isNegativeArrowVisible();
//     java.awt.Font var6 = var1.getLabelFont();
//     org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("java.awt.Color[r=0,g=0,b=1]", var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var7.calculateDimensions(var8);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var1.getCategoryLabelToolTip(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var7);
    var0.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.event.MarkerChangeEvent var12 = null;
    var0.markerChanged(var12);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    float var15 = var14.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var16 = var14.getLabelInsets();
    org.jfree.data.Range var17 = var14.getRange();
    org.jfree.data.Range var18 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    org.jfree.chart.axis.AxisLocation var20 = null;
    var0.setRangeAxisLocation(10, var20, true);
    org.jfree.chart.axis.CategoryAnchor var23 = var0.getDomainGridlinePosition();
    java.util.List var24 = var0.getAnnotations();
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var27 = null;
    var26.setOutlineStroke(var27);
    org.jfree.chart.event.AxisChangeEvent var29 = null;
    var26.axisChanged(var29);
    var26.setRangeGridlinesVisible(false);
    org.jfree.chart.util.SortOrder var33 = var26.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var26.setDomainAxis(10, var36, false);
    var36.setCategoryMargin(0.0d);
    var0.setDomainAxis(1, var36, false);
    java.awt.Paint var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePaint(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var7 = var0.getFixedRangeAxisSpace();
    double var8 = var0.getRangeCrosshairValue();
    boolean var9 = var0.isDomainGridlinesVisible();
    org.jfree.chart.event.PlotChangeEvent var10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     int var2 = var1.getSubplotCount();
//     java.awt.geom.Rectangle2D var3 = null;
//     var1.setDataArea(var3);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var6 = null;
//     var5.setOutlineStroke(var6);
//     org.jfree.chart.event.AxisChangeEvent var8 = null;
//     var5.axisChanged(var8);
//     var5.setRangeGridlinesVisible(false);
//     boolean var12 = var5.isRangeCrosshairVisible();
//     java.awt.Stroke var13 = var5.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var14 = var5.getDataset();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     float var17 = var16.getTickMarkOutsideLength();
//     var16.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var24 = var23.getBounds();
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var16.valueToJava2D(100.0d, var24, var25);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleAnchor var28 = null;
//     java.awt.geom.Point2D var29 = org.jfree.chart.util.RectangleAnchor.coordinates(var27, var28);
//     org.jfree.chart.plot.PlotState var30 = null;
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     var5.draw(var15, var24, var29, var30, var32);
//     org.jfree.chart.util.RectangleAnchor var34 = null;
//     java.awt.geom.Point2D var35 = org.jfree.chart.util.RectangleAnchor.coordinates(var24, var34);
//     var1.setDataArea(var24);
//     
//     // Checks the contract:  equals-hashcode on var1 and var32
//     assertTrue("Contract failed: equals-hashcode on var1 and var32", var1.equals(var32) ? var1.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var1
//     assertTrue("Contract failed: equals-hashcode on var32 and var1", var32.equals(var1) ? var32.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getMargin();
    var1.setHeight(0.0d);
    var1.setURLText("RangeType.FULL");
    org.jfree.chart.util.RectangleInsets var7 = var1.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var4 = var3.getItemLabelAnchor();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    boolean var7 = var4.equals((java.lang.Object)(-1.0f));
    java.lang.Object var8 = null;
    boolean var9 = var4.equals(var8);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var12 = null;
    var11.setOutlineStroke(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var11.axisChanged(var14);
    var11.setRangeGridlinesVisible(false);
    boolean var18 = var11.isRangeCrosshairVisible();
    java.awt.Stroke var19 = var11.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var20 = var11.getDataset();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis();
    float var23 = var22.getTickMarkOutsideLength();
    var22.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var30 = var29.getBounds();
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var22.valueToJava2D(100.0d, var30, var31);
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleAnchor var34 = null;
    java.awt.geom.Point2D var35 = org.jfree.chart.util.RectangleAnchor.coordinates(var33, var34);
    org.jfree.chart.plot.PlotState var36 = null;
    org.jfree.chart.ChartRenderingInfo var37 = null;
    org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
    var11.draw(var21, var30, var35, var36, var38);
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var11);
    org.jfree.chart.plot.CategoryPlot var41 = var40.getCategoryPlot();
    org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var43 = var42.clone();
    org.jfree.chart.util.VerticalAlignment var44 = var42.getVerticalAlignment();
    var40.removeSubtitle((org.jfree.chart.title.Title)var42);
    java.awt.Image var46 = var40.getBackgroundImage();
    boolean var47 = var4.equals((java.lang.Object)var40);
    org.jfree.chart.title.LegendTitle var48 = var40.getLegend();
    org.jfree.chart.event.ChartChangeListener var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var40.removeChangeListener(var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
//     boolean var12 = var0.getIncludeBaseInRange();
//     double var13 = var0.getUpperClip();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
//     var0.setBaseItemLabelGenerator(var14, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var0.getLegendItemURLGenerator();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var19 = null;
//     var18.setOutlineStroke(var19);
//     org.jfree.chart.event.AxisChangeEvent var21 = null;
//     var18.axisChanged(var21);
//     var18.setRangeGridlinesVisible(false);
//     boolean var25 = var18.isRangeCrosshairVisible();
//     java.awt.Stroke var26 = var18.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var28 = var18.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var29 = null;
//     var18.notifyListeners(var29);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     float var32 = var31.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getLabelInsets();
//     boolean var34 = var31.isVerticalTickLabels();
//     boolean var35 = var31.isNegativeArrowVisible();
//     boolean var36 = var31.isNegativeArrowVisible();
//     int var37 = var18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var31);
//     var18.setWeight(0);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var18);
//     org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var44 = null;
//     var43.setOutlineStroke(var44);
//     org.jfree.chart.event.AxisChangeEvent var46 = null;
//     var43.axisChanged(var46);
//     var43.clearAnnotations();
//     var42.addChangeListener((org.jfree.chart.event.RendererChangeListener)var43);
//     java.awt.Shape var51 = var42.getSeriesShape(1);
//     org.jfree.chart.labels.ItemLabelPosition var54 = var42.getPositiveItemLabelPosition(0, 100);
//     var0.setSeriesPositiveItemLabelPosition(255, var54, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var42 and var0.", var42.equals(var0) == var0.equals(var42));
//     
//     // Checks the contract:  equals-hashcode on var1 and var43
//     assertTrue("Contract failed: equals-hashcode on var1 and var43", var1.equals(var43) ? var1.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var1
//     assertTrue("Contract failed: equals-hashcode on var43 and var1", var43.equals(var1) ? var43.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var25 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var21, (java.awt.Paint)var25);
    var26.setDatasetIndex(0);
    var0.add(var26);
    org.jfree.chart.LegendItemCollection var30 = new org.jfree.chart.LegendItemCollection();
    java.awt.Font var36 = null;
    java.awt.Color var39 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var40 = var39.darker();
    int var41 = var40.getBlue();
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var40);
    org.jfree.chart.util.HorizontalAlignment var43 = var42.getLineAlignment();
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.text.TextBlockAnchor var47 = null;
    java.awt.Shape var51 = var42.calculateBounds(var44, 10.0f, (-1.0f), var47, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var55 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var51, (java.awt.Paint)var55);
    var56.setDatasetIndex(0);
    var30.add(var56);
    var0.addAll(var30);
    java.util.Iterator var61 = var0.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Paint var5 = var0.getRangeGridlinePaint();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var11 = java.awt.Color.getColor("", 10);
    var8.setTickMarkPaint((java.awt.Paint)var11);
    org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var8.setStandardTickUnits(var13);
    org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var18 = var17.getBounds();
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var8.lengthToJava2D((-1.0d), var18, var19);
    org.jfree.chart.ChartRenderingInfo var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
    boolean var24 = var0.render(var6, var18, 10, var23);
    org.jfree.chart.axis.AxisSpace var25 = null;
    var0.setFixedDomainAxisSpace(var25);
    org.jfree.chart.plot.Plot var27 = null;
    var0.setParent(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    java.awt.Shape var4 = var0.getRightArrow();
    org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var4);
    java.lang.String var6 = var5.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "0,0,-2,-2,-2,2,-2,2"+ "'", var6.equals("0,0,-2,-2,-2,2,-2,2"));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    var0.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var8 = var7.getBounds();
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var0.valueToJava2D(100.0d, var8, var9);
    boolean var11 = var0.isNegativeArrowVisible();
    var0.setRangeWithMargins(0.05d, 0.05d);
    org.jfree.chart.event.AxisChangeEvent var15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.axis.Axis var16 = var15.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.KeyedObjects2D var1 = new org.jfree.data.KeyedObjects2D();
    java.util.List var2 = var1.getRowKeys();
    boolean var3 = var0.equals((java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var1.getObject((-10289251), 255);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     float var1 = var0.getTickMarkOutsideLength();
//     var0.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var8 = var7.getBounds();
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var0.valueToJava2D(100.0d, var8, var9);
//     boolean var11 = var0.isNegativeArrowVisible();
//     var0.setVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var16 = null;
//     var15.setOutlineStroke(var16);
//     org.jfree.chart.event.AxisChangeEvent var18 = null;
//     var15.axisChanged(var18);
//     var15.clearAnnotations();
//     var14.addChangeListener((org.jfree.chart.event.RendererChangeListener)var15);
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     var15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var29 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var30 = var29.darker();
//     var26.setLabelPaint((java.awt.Paint)var29);
//     float[] var35 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var36 = var29.getColorComponents(var35);
//     java.awt.Color var37 = java.awt.Color.getColor("", var29);
//     java.awt.Color var38 = var37.darker();
//     var15.setNoDataMessagePaint((java.awt.Paint)var38);
//     org.jfree.chart.block.LabelBlock var41 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.Color var44 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var45 = var44.darker();
//     var41.setPaint((java.awt.Paint)var45);
//     java.lang.String var47 = var41.getToolTipText();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var49 = null;
//     var48.setOutlineStroke(var49);
//     org.jfree.chart.event.AxisChangeEvent var51 = null;
//     var48.axisChanged(var51);
//     var48.setRangeGridlinesVisible(false);
//     org.jfree.chart.event.AxisChangeEvent var55 = null;
//     var48.axisChanged(var55);
//     java.awt.Paint var57 = var48.getRangeGridlinePaint();
//     boolean var58 = var41.equals((java.lang.Object)var48);
//     java.lang.String var59 = var48.getPlotType();
//     org.jfree.chart.axis.CategoryAnchor var60 = var48.getDomainGridlinePosition();
//     var15.setDomainGridlinePosition(var60);
//     
//     // Checks the contract:  equals-hashcode on var7 and var41
//     assertTrue("Contract failed: equals-hashcode on var7 and var41", var7.equals(var41) ? var7.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var7
//     assertTrue("Contract failed: equals-hashcode on var41 and var7", var41.equals(var7) ? var41.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    float[] var15 = new float[] { 0.0f, 1.0f, 0.0f};
    float[] var16 = var10.getColorComponents(var15);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var24 = var23.darker();
    var20.setLabelPaint((java.awt.Paint)var23);
    float[] var29 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var30 = var23.getColorComponents(var29);
    java.awt.Color var31 = java.awt.Color.getColor("", var23);
    java.awt.Color var32 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var31);
    java.lang.String var33 = var32.toString();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis();
    var34.setTickMarksVisible(false);
    java.awt.Stroke var37 = var34.getTickMarkStroke();
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var41 = null;
    var40.setOutlineStroke(var41);
    org.jfree.chart.event.AxisChangeEvent var43 = null;
    var40.axisChanged(var43);
    var40.clearAnnotations();
    var39.addChangeListener((org.jfree.chart.event.RendererChangeListener)var40);
    org.jfree.chart.renderer.category.BarRenderer var47 = new org.jfree.chart.renderer.category.BarRenderer();
    var40.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var47);
    org.jfree.chart.util.RectangleInsets var49 = var40.getInsets();
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    java.awt.geom.Rectangle2D var52 = null;
    org.jfree.chart.util.RectangleAnchor var53 = null;
    java.awt.geom.Point2D var54 = org.jfree.chart.util.RectangleAnchor.coordinates(var52, var53);
    var40.zoomDomainAxes(3.0d, var51, var54);
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
    float var57 = var56.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var58 = var56.getLabelInsets();
    org.jfree.data.Range var59 = var56.getRange();
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    var56.setRightArrow(var61);
    boolean var63 = var40.equals((java.lang.Object)var61);
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var65 = null;
    var64.setOutlineStroke(var65);
    org.jfree.chart.event.AxisChangeEvent var67 = null;
    var64.axisChanged(var67);
    var64.setRangeGridlinesVisible(false);
    boolean var71 = var64.isRangeCrosshairVisible();
    java.awt.Stroke var72 = var64.getDomainGridlineStroke();
    org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis();
    float var75 = var74.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var76 = var74.getLabelInsets();
    boolean var77 = var74.isVerticalTickLabels();
    org.jfree.chart.axis.ValueAxis[] var78 = new org.jfree.chart.axis.ValueAxis[] { var74};
    var73.setRangeAxes(var78);
    org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var81 = null;
    var80.setOutlineStroke(var81);
    org.jfree.chart.event.AxisChangeEvent var83 = null;
    var80.axisChanged(var83);
    var80.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var87 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var80.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var87);
    var73.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var87);
    java.awt.Paint var90 = var87.getNextOutlinePaint();
    java.awt.Paint var91 = var87.getNextOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var92 = new org.jfree.chart.LegendItem(var0, "", "AxisLocation.BOTTOM_OR_RIGHT", "", true, var5, false, (java.awt.Paint)var10, true, (java.awt.Paint)var32, var37, true, var61, var72, var91);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var33.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    java.awt.Shape var9 = var0.getSeriesShape(1);
    java.awt.Paint var11 = var0.lookupSeriesFillPaint((-1));
    boolean var12 = var0.getIncludeBaseInRange();
    java.awt.Font var13 = var0.getBaseItemLabelFont();
    org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(0, 0, 100);
    var0.setBaseItemLabelPaint((java.awt.Paint)var17);
    java.awt.Stroke var21 = var0.getItemStroke(255, (-8372160));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    var0.setAutoTickUnitSelection(false, false);
    var0.setAutoRangeMinimumSize(100.0d, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.awt.Font var6 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var10 = var9.darker();
    int var11 = var10.getBlue();
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10);
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var12.calculateBounds(var14, 10.0f, (-1.0f), var17, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var25 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var21, (java.awt.Paint)var25);
    var26.setDatasetIndex(0);
    var0.add(var26);
    org.jfree.chart.LegendItemCollection var30 = new org.jfree.chart.LegendItemCollection();
    java.awt.Font var36 = null;
    java.awt.Color var39 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var40 = var39.darker();
    int var41 = var40.getBlue();
    org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, (java.awt.Paint)var40);
    org.jfree.chart.util.HorizontalAlignment var43 = var42.getLineAlignment();
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.text.TextBlockAnchor var47 = null;
    java.awt.Shape var51 = var42.calculateBounds(var44, 10.0f, (-1.0f), var47, (-1.0f), 1.0f, 1.0d);
    java.awt.Color var55 = java.awt.Color.getHSBColor(2.0f, 2.0f, 0.0f);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var51, (java.awt.Paint)var55);
    var56.setDatasetIndex(0);
    var30.add(var56);
    var0.addAll(var30);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var62 = null;
    var61.setOutlineStroke(var62);
    org.jfree.chart.event.AxisChangeEvent var64 = null;
    var61.axisChanged(var64);
    var61.setRangeGridlinesVisible(false);
    boolean var68 = var61.isRangeCrosshairVisible();
    java.awt.Stroke var69 = var61.getDomainGridlineStroke();
    org.jfree.data.category.CategoryDataset var71 = var61.getDataset(10);
    java.awt.Stroke var72 = var61.getDomainGridlineStroke();
    float var73 = var61.getForegroundAlpha();
    boolean var74 = var0.equals((java.lang.Object)var61);
    org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var76 = null;
    var75.setOutlineStroke(var76);
    org.jfree.chart.event.AxisChangeEvent var78 = null;
    var75.axisChanged(var78);
    var75.setRangeGridlinesVisible(false);
    boolean var82 = var75.isRangeCrosshairVisible();
    java.awt.Stroke var83 = var75.getDomainGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var85 = var75.getDomainAxisForDataset(100);
    org.jfree.chart.event.MarkerChangeEvent var86 = null;
    var75.markerChanged(var86);
    float var88 = var75.getBackgroundAlpha();
    org.jfree.chart.axis.AxisLocation var90 = var75.getDomainAxisLocation(10);
    var61.setDomainAxisLocation(var90, true);
    org.jfree.chart.axis.AxisLocation var93 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var61.setRangeAxisLocation(var93);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var5 = var4.darker();
//     int var6 = var5.getBlue();
//     org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5);
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement(var8, var9, 1.0E-8d, (-1.0d));
//     org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var12);
//     org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var16 = var15.getMargin();
//     var15.setHeight(0.0d);
//     java.awt.Paint var19 = var15.getPaint();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var21 = null;
//     var20.setOutlineStroke(var21);
//     org.jfree.chart.event.AxisChangeEvent var23 = null;
//     var20.axisChanged(var23);
//     var20.setRangeGridlinesVisible(false);
//     boolean var27 = var20.isRangeCrosshairVisible();
//     java.awt.Stroke var28 = var20.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var30 = var20.getDomainAxisEdge(100);
//     org.jfree.chart.LegendItemCollection var31 = var20.getLegendItems();
//     var13.add((org.jfree.chart.block.Block)var15, (java.lang.Object)var20);
//     org.jfree.chart.block.LabelBlock var34 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     org.jfree.chart.util.RectangleInsets var35 = var34.getMargin();
//     var34.setHeight(0.0d);
//     org.jfree.chart.block.BlockFrame var38 = var34.getFrame();
//     var13.add((org.jfree.chart.block.Block)var34, (java.lang.Object)10);
//     
//     // Checks the contract:  equals-hashcode on var15 and var34
//     assertTrue("Contract failed: equals-hashcode on var15 and var34", var15.equals(var34) ? var15.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var15
//     assertTrue("Contract failed: equals-hashcode on var34 and var15", var34.equals(var15) ? var34.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var1 = null;
//     var0.setOutlineStroke(var1);
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(false);
//     boolean var7 = var0.isRangeCrosshairVisible();
//     java.awt.Stroke var8 = var0.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var0.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var11 = null;
//     var0.notifyListeners(var11);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     var13.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var13.getBasePositiveItemLabelPosition();
//     int var17 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var20 = null;
//     var19.setOutlineStroke(var20);
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var19.axisChanged(var22);
//     var19.setRangeGridlinesVisible(false);
//     org.jfree.chart.plot.DefaultDrawingSupplier var26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var26);
//     var19.clearDomainMarkers(10);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     org.jfree.chart.event.AxisChangeEvent var33 = null;
//     var30.axisChanged(var33);
//     var30.setRangeGridlinesVisible(false);
//     boolean var37 = var30.isRangeCrosshairVisible();
//     java.awt.Stroke var38 = var30.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var40 = var30.getDataset(10);
//     org.jfree.chart.event.PlotChangeEvent var41 = null;
//     var30.notifyListeners(var41);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = var30.getRenderer(100);
//     org.jfree.chart.util.Layer var46 = null;
//     java.util.Collection var47 = var30.getDomainMarkers(0, var46);
//     org.jfree.chart.axis.AxisLocation var49 = var30.getRangeAxisLocation(10);
//     var19.setRangeAxisLocation(var49, true);
//     var0.setDomainAxisLocation(10, var49, false);
//     
//     // Checks the contract:  equals-hashcode on var30 and var0
//     assertTrue("Contract failed: equals-hashcode on var30 and var0", var30.equals(var0) ? var30.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var30 and var0.", var30.equals(var0) == var0.equals(var30));
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.lang.Comparable var3 = var0.getKey(100);
    java.lang.Comparable var5 = var0.getKey(0);
    int var6 = var0.getItemCount();
    java.lang.Comparable var8 = var0.getKey(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)(short)1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var1.configureDomainAxes();
    var1.setRangeCrosshairVisible(false);
    boolean var10 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis();
    float var12 = var11.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var13 = var11.getLabelInsets();
    org.jfree.data.Range var14 = var11.getRange();
    org.jfree.data.Range var15 = var11.getDefaultAutoRange();
    org.jfree.chart.axis.NumberTickUnit var16 = var11.getTickUnit();
    var0.add((org.jfree.chart.axis.TickUnit)var16);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    float var19 = var18.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var20 = var18.getLabelInsets();
    org.jfree.data.Range var21 = var18.getRange();
    org.jfree.data.Range var22 = var18.getDefaultAutoRange();
    org.jfree.chart.axis.NumberTickUnit var23 = var18.getTickUnit();
    org.jfree.chart.axis.TickUnit var24 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var23);
    org.jfree.chart.axis.TickUnit var26 = var0.getCeilingTickUnit(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.entity.TickLabelEntity var4 = new org.jfree.chart.entity.TickLabelEntity(var1, "hi!", "");
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var6 = var4.equals((java.lang.Object)var5);
    java.awt.Paint var9 = var5.getItemPaint(0, 10);
    java.awt.Paint var12 = var5.getItemPaint(255, (-8372160));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var6 = var5.darker();
    var2.setLabelPaint((java.awt.Paint)var5);
    float[] var11 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var12 = var5.getColorComponents(var11);
    java.awt.Color var13 = java.awt.Color.getColor("", var5);
    java.awt.Color var14 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var13);
    java.lang.String var15 = var14.toString();
    int var16 = var14.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var15.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-16777215));

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    var0.setAutoRangeMinimumSize(10.0d);
    var0.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var0.resizeRange(1.0E-8d, 106.0d);
    boolean var10 = var0.isTickMarksVisible();
    java.lang.Object var11 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    int var2 = var1.getSubplotCount();
    java.awt.geom.Rectangle2D var3 = null;
    var1.setDataArea(var3);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    org.jfree.chart.event.AxisChangeEvent var8 = null;
    var5.axisChanged(var8);
    java.awt.Paint var10 = var5.getRangeGridlinePaint();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Color var16 = java.awt.Color.getColor("", 10);
    var13.setTickMarkPaint((java.awt.Paint)var16);
    org.jfree.chart.axis.TickUnitSource var18 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var13.setStandardTickUnits(var18);
    org.jfree.chart.block.LabelBlock var22 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var23 = var22.getBounds();
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var13.lengthToJava2D((-1.0d), var23, var24);
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    boolean var29 = var5.render(var11, var23, 10, var28);
    var1.addSubplotInfo(var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var32 = var1.getSubplotInfo(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.event.AxisChangeEvent var4 = null;
    var1.axisChanged(var4);
    var1.clearAnnotations();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    var1.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
    org.jfree.chart.util.RectangleInsets var10 = var1.getInsets();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleAnchor var14 = null;
    java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var14);
    var1.zoomDomainAxes(3.0d, var12, var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var18 = null;
    var17.setOutlineStroke(var18);
    org.jfree.chart.event.AxisChangeEvent var20 = null;
    var17.axisChanged(var20);
    var17.setRangeGridlinesVisible(false);
    org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var24);
    var17.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.event.MarkerChangeEvent var29 = null;
    var17.markerChanged(var29);
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
    float var32 = var31.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var33 = var31.getLabelInsets();
    org.jfree.data.Range var34 = var31.getRange();
    org.jfree.data.Range var35 = var17.getDataRange((org.jfree.chart.axis.ValueAxis)var31);
    java.awt.Paint var36 = var31.getLabelPaint();
    var1.setDomainGridlinePaint(var36);
    org.jfree.chart.axis.ValueAxis var39 = var1.getRangeAxis(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.entity.TickLabelEntity var4 = new org.jfree.chart.entity.TickLabelEntity(var1, "hi!", "");
    java.lang.String var5 = var4.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.setRangeGridlinesVisible(false);
//     boolean var8 = var1.isRangeCrosshairVisible();
//     java.awt.Stroke var9 = var1.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var10 = var1.getDataset();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     float var13 = var12.getTickMarkOutsideLength();
//     var12.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var20 = var19.getBounds();
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(100.0d, var20, var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var1.draw(var11, var20, var25, var26, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     var30.setAntiAlias(false);
//     org.jfree.chart.title.LegendTitle var34 = var30.getLegend(255);
//     float var35 = var30.getBackgroundImageAlpha();
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var38 = null;
//     var37.setOutlineStroke(var38);
//     org.jfree.chart.event.AxisChangeEvent var40 = null;
//     var37.axisChanged(var40);
//     var37.setRangeGridlinesVisible(false);
//     boolean var44 = var37.isRangeCrosshairVisible();
//     java.awt.Stroke var45 = var37.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var46 = var37.getDataset();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis();
//     float var49 = var48.getTickMarkOutsideLength();
//     var48.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var55 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var56 = var55.getBounds();
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var48.valueToJava2D(100.0d, var56, var57);
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleAnchor var60 = null;
//     java.awt.geom.Point2D var61 = org.jfree.chart.util.RectangleAnchor.coordinates(var59, var60);
//     org.jfree.chart.plot.PlotState var62 = null;
//     org.jfree.chart.ChartRenderingInfo var63 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var64 = new org.jfree.chart.plot.PlotRenderingInfo(var63);
//     var37.draw(var47, var56, var61, var62, var64);
//     org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var37);
//     org.jfree.chart.plot.CategoryPlot var67 = var66.getCategoryPlot();
//     org.jfree.chart.title.TextTitle var68 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var69 = var68.clone();
//     org.jfree.chart.util.VerticalAlignment var70 = var68.getVerticalAlignment();
//     var66.removeSubtitle((org.jfree.chart.title.Title)var68);
//     java.awt.Image var72 = var66.getBackgroundImage();
//     java.awt.Paint var73 = var66.getBorderPaint();
//     java.awt.Paint var74 = var66.getBorderPaint();
//     java.awt.RenderingHints var75 = var66.getRenderingHints();
//     var30.setRenderingHints(var75);
//     
//     // Checks the contract:  equals-hashcode on var1 and var37
//     assertTrue("Contract failed: equals-hashcode on var1 and var37", var1.equals(var37) ? var1.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var67
//     assertTrue("Contract failed: equals-hashcode on var1 and var67", var1.equals(var67) ? var1.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var1
//     assertTrue("Contract failed: equals-hashcode on var37 and var1", var37.equals(var1) ? var37.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var1
//     assertTrue("Contract failed: equals-hashcode on var67 and var1", var67.equals(var1) ? var67.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var55
//     assertTrue("Contract failed: equals-hashcode on var19 and var55", var19.equals(var55) ? var19.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var19
//     assertTrue("Contract failed: equals-hashcode on var55 and var19", var55.equals(var19) ? var55.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var64
//     assertTrue("Contract failed: equals-hashcode on var28 and var64", var28.equals(var64) ? var28.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var28
//     assertTrue("Contract failed: equals-hashcode on var64 and var28", var64.equals(var28) ? var64.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var66
//     assertTrue("Contract failed: equals-hashcode on var30 and var66", var30.equals(var66) ? var30.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var30
//     assertTrue("Contract failed: equals-hashcode on var66 and var30", var66.equals(var30) ? var66.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
//     float var5 = var4.getTickMarkOutsideLength();
//     var4.setAutoTickUnitSelection(false, false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = new org.jfree.chart.axis.AxisState();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var4.refreshTicks(var9, var10, var11, var12);
//     var10.setMax(0.05d);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis();
//     float var17 = var16.getTickMarkOutsideLength();
//     var16.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var24 = var23.getBounds();
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var16.valueToJava2D(100.0d, var24, var25);
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     java.util.List var28 = var2.refreshTicks(var3, var10, var24, var27);
//     java.awt.Shape var29 = var2.getLeftArrow();
//     java.awt.Font var30 = var2.getLabelFont();
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("RangeType.FULL", var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.data.Range var34 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(10.0d, var34);
//     org.jfree.data.Range var36 = var35.getHeightRange();
//     java.lang.String var37 = var35.toString();
//     org.jfree.chart.block.LengthConstraintType var38 = var35.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var39 = var31.arrange(var32, var35);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var3 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var5 = null;
    var4.setOutlineStroke(var5);
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var4.axisChanged(var7);
    var4.setRangeGridlinesVisible(false);
    boolean var11 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var12 = var4.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var14 = var4.getDomainAxisEdge(100);
    org.jfree.chart.axis.CategoryLabelPosition var15 = var3.getLabelPosition(var14);
    org.jfree.chart.text.TextAnchor var16 = var15.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var19 = new org.jfree.chart.axis.NumberTick(var0, (-1.99999999d), "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var16, var17, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var12 = null;
    var11.setOutlineStroke(var12);
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var11.axisChanged(var14);
    var11.clearAnnotations();
    var10.addChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
    java.awt.Shape var19 = var10.getSeriesShape(1);
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    int var24 = var23.getBlue();
    var10.setBasePaint((java.awt.Paint)var23);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
    float var31 = var30.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var32 = var30.getLabelInsets();
    boolean var33 = var30.isVerticalTickLabels();
    java.awt.Shape var34 = var30.getRightArrow();
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var34);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
    float var40 = var39.getTickMarkOutsideLength();
    var39.setAutoTickUnitSelection(false, false);
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.axis.AxisState var45 = new org.jfree.chart.axis.AxisState();
    java.awt.geom.Rectangle2D var46 = null;
    org.jfree.chart.util.RectangleEdge var47 = null;
    java.util.List var48 = var39.refreshTicks(var44, var45, var46, var47);
    var45.setMax(0.05d);
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
    float var52 = var51.getTickMarkOutsideLength();
    var51.setAutoTickUnitSelection(false, false);
    org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.geom.Rectangle2D var59 = var58.getBounds();
    org.jfree.chart.util.RectangleEdge var60 = null;
    double var61 = var51.valueToJava2D(100.0d, var59, var60);
    org.jfree.chart.util.RectangleEdge var62 = null;
    java.util.List var63 = var37.refreshTicks(var38, var45, var59, var62);
    java.awt.Shape var64 = var37.getLeftArrow();
    boolean var65 = var35.equals((java.lang.Object)var64);
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis();
    var66.setTickMarksVisible(false);
    java.awt.Stroke var69 = var66.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Color var73 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var74 = var73.darker();
    var70.setLabelPaint((java.awt.Paint)var73);
    float[] var79 = new float[] { 0.0f, (-1.0f), (-1.0f)};
    float[] var80 = var73.getColorComponents(var79);
    org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_RIGHT", "", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", "hi!", var64, var69, (java.awt.Paint)var73);
    java.awt.Color var84 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var85 = var84.darker();
    org.jfree.chart.LegendItem var86 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "", "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var9, (java.awt.Paint)var23, var69, (java.awt.Paint)var85);
    org.jfree.chart.plot.CategoryPlot var87 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var88 = null;
    var87.setOutlineStroke(var88);
    org.jfree.chart.event.AxisChangeEvent var90 = null;
    var87.axisChanged(var90);
    var87.clearAnnotations();
    java.awt.Paint var93 = var87.getNoDataMessagePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var94 = new org.jfree.chart.LegendItem(var0, "", "ThreadContext", "CONTRACT", var9, var93);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.util.RectangleInsets var2 = var0.getLabelInsets();
    boolean var3 = var0.isVerticalTickLabels();
    double var4 = var0.getLowerMargin();
    var0.setAutoRangeIncludesZero(false);
    boolean var7 = var0.isAutoTickUnitSelection();
    boolean var8 = var0.isAutoTickUnitSelection();
    var0.setUpperMargin(4.99999995E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
    org.jfree.chart.entity.TickLabelEntity var4 = new org.jfree.chart.entity.TickLabelEntity(var1, "hi!", "");
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var6 = var4.equals((java.lang.Object)var5);
    boolean var8 = var5.isSeriesVisibleInLegend(255);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setSeriesVisible((-16777215), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    boolean var2 = var0.containsKey("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 1.00000001E-8d, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "Size2D[width=0.0, height=-1.99999999]", "0,0,-2,-2,-2,2,-2,2", var3, "-0", "LengthConstraintType.FIXED", "java.awt.Color[r=0,g=0,b=1]");

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Stroke var1 = null;
    var0.setOutlineStroke(var1);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(false);
    org.jfree.chart.util.SortOrder var7 = var0.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    var0.setDomainAxis(10, var10, false);
    double var13 = var10.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.event.AxisChangeEvent var4 = null;
//     var1.axisChanged(var4);
//     var1.clearAnnotations();
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var1);
//     java.awt.Shape var9 = var0.getSeriesShape(1);
//     boolean var10 = var0.getAutoPopulateSeriesStroke();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var11 = var0.getLegendItemToolTipGenerator();
//     var0.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     var14.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var14.getBasePositiveItemLabelPosition();
//     var0.setBaseNegativeItemLabelPosition(var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Stroke var22 = null;
//     var21.setOutlineStroke(var22);
//     org.jfree.chart.event.AxisChangeEvent var24 = null;
//     var21.axisChanged(var24);
//     var21.setRangeGridlinesVisible(false);
//     org.jfree.chart.util.SortOrder var28 = var21.getColumnRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     var21.setDomainAxis(10, var31, false);
//     org.jfree.chart.plot.CategoryMarker var34 = null;
//     org.jfree.chart.axis.AxisSpace var35 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.util.RectangleInsets var37 = var36.getInsets();
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Color var42 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var43 = var42.darker();
//     var39.setLabelPaint((java.awt.Paint)var42);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis();
//     float var46 = var45.getTickMarkOutsideLength();
//     org.jfree.chart.util.RectangleInsets var47 = var45.getLabelInsets();
//     double var49 = var47.extendHeight(100.0d);
//     var39.setTickLabelInsets(var47);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     float var52 = var51.getTickMarkOutsideLength();
//     var51.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.block.LabelBlock var58 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     java.awt.geom.Rectangle2D var59 = var58.getBounds();
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var51.valueToJava2D(100.0d, var59, var60);
//     java.awt.geom.Rectangle2D var64 = var47.createInsetRectangle(var59, true, false);
//     var36.draw(var38, var64);
//     java.awt.geom.Rectangle2D var66 = null;
//     java.awt.geom.Rectangle2D var67 = var35.expand(var64, var66);
//     var0.drawDomainMarker(var19, var20, var31, var34, var64);
// 
//   }

}
