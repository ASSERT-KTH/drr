
import junit.framework.*;

public class RandoopTest1 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test1"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
    long var7 = var1.getLastMillisecond();
    java.util.Date var8 = var1.getStart();
    java.util.Calendar var9 = null;
    var1.peg(var9);
    int var12 = var1.compareTo((java.lang.Object)"17-December-2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test2"); }


    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
    long var6 = var5.getSerialIndex();
    java.util.Date var7 = var5.getTime();
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(0, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(31, var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(31, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-435), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test3"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, (-457));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var3 = var2.getYear();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test4"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(7, var1);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test5"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     long var9 = var7.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, var17);
//     boolean var19 = var7.equals((java.lang.Object)var17);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getFirstMillisecond();
//     java.util.Calendar var23 = null;
//     long var24 = var21.getMiddleMillisecond(var23);
//     java.util.Calendar var25 = null;
//     long var26 = var21.getFirstMillisecond(var25);
//     org.jfree.data.time.RegularTimePeriod var27 = var21.next();
//     java.util.Date var28 = var21.getTime();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(var28);
//     int var30 = var29.getYearValue();
//     java.util.Date var31 = var29.getStart();
//     int var32 = var29.getYearValue();
//     boolean var33 = var7.equals((java.lang.Object)var29);
//     java.lang.Number var34 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var7);
//     org.jfree.data.time.RegularTimePeriod var35 = var7.previous();
//     java.util.Date var36 = var7.getEnd();
//     java.util.TimeZone var37 = null;
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year(var36, var37);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test6"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     var2.setMaximumItemCount(100);
//     long var32 = var2.getMaximumItemAge();
//     var2.setDescription("Sun Dec 21 01:14:32 PST 2014");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var36 = var2.getTimePeriod(21);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 9223372036854775807L);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test7"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     var2.setMaximumItemAge(28799999L);
//     var2.setRangeDescription("ThreadContext");
//     java.lang.String var11 = var2.getDescription();
//     java.beans.PropertyChangeListener var12 = null;
//     var2.removePropertyChangeListener(var12);
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
//     boolean var17 = var16.getNotify();
//     var16.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var16.getDataItem((org.jfree.data.time.RegularTimePeriod)var20);
//     var16.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var26 = var25.getFirstMillisecond();
//     java.util.Calendar var27 = null;
//     long var28 = var25.getMiddleMillisecond(var27);
//     java.util.Calendar var29 = null;
//     long var30 = var25.getFirstMillisecond(var29);
//     org.jfree.data.time.RegularTimePeriod var31 = var25.next();
//     java.util.Date var32 = var25.getTime();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var32);
//     long var34 = var33.getFirstMillisecond();
//     int var35 = var33.getMonth();
//     java.lang.Number var36 = var16.getValue((org.jfree.data.time.RegularTimePeriod)var33);
//     java.lang.Number var37 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var33, var37);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test8"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 100.0d);
//     org.jfree.data.time.RegularTimePeriod var14 = var9.previous();
//     int var15 = var9.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test9"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     org.jfree.data.general.SeriesChangeEvent var23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     java.util.List var31 = var26.getItems();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var33.getMiddleMillisecond(var39);
//     org.jfree.data.time.TimeSeriesDataItem var42 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var43 = var33.previous();
//     org.jfree.data.time.TimeSeries var44 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var22, var43);
//     java.beans.PropertyChangeListener var45 = null;
//     var44.addPropertyChangeListener(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test10"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     java.util.Calendar var13 = null;
//     long var14 = var11.getFirstMillisecond(var13);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test11"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     var10.setDescription("");
//     var10.setDescription("Time");
//     boolean var15 = var6.equals((java.lang.Object)var10);
//     int var16 = var6.getMonth();
//     long var17 = var6.getFirstMillisecond();
//     long var18 = var6.getFirstMillisecond();
//     long var19 = var6.getSerialIndex();
//     java.lang.Number var20 = null;
//     var2.add((org.jfree.data.time.RegularTimePeriod)var6, var20, true);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test12"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.String var3 = var2.getDomainDescription();
    var2.removeAgedItems(false);
    java.util.Collection var6 = var2.getTimePeriods();
    org.jfree.data.time.RegularTimePeriod var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var2.getValue(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test13"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     long var3 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 24180L);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, (-435), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test15"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    java.lang.String var8 = var2.getDomainDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Time"+ "'", var8.equals("Time"));

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test16"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     var10.setDescription("");
//     var10.setDescription("Time");
//     boolean var15 = var6.equals((java.lang.Object)var10);
//     int var16 = var6.getMonth();
//     long var17 = var6.getSerialIndex();
//     java.util.Date var18 = var6.getEnd();
//     int var19 = var0.compareTo((java.lang.Object)var6);
//     int var20 = var6.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 12);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test17"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setNotify(false);
//     java.lang.String var12 = var2.getDomainDescription();
//     boolean var13 = var2.isEmpty();
//     java.beans.PropertyChangeListener var14 = null;
//     var2.addPropertyChangeListener(var14);
//     var2.setRangeDescription("Sun Dec 21 01:14:31 PST 2014");
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var2.addChangeListener(var18);
//     var2.removeAgedItems(1419153274341L, false);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test19"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     var3.setValue((java.lang.Number)1388563200000L);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "org.jfree.data.general.SeriesChangeEvent[source=10.0]", "org.jfree.data.general.SeriesException: ThreadContext", var10);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     long var13 = var12.getFirstMillisecond();
//     org.jfree.data.time.Year var14 = var12.getYear();
//     var11.add((org.jfree.data.time.RegularTimePeriod)var14, 100.0d, true);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test20"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths(0, var4);
//     var4.setDescription("Sun Dec 21 01:14:30 PST 2014");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = var4.getFollowingDayOfWeek(1969);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test21"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Date var13 = var6.getTime();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
//     boolean var16 = var3.isAfter(var15);
//     boolean var17 = var1.isBefore(var15);
//     int var18 = var1.getYYYY();
//     org.jfree.data.time.SerialDate var19 = null;
//     boolean var20 = var1.isBefore(var19);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test22"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     boolean var8 = var2.getNotify();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     boolean var12 = var11.getNotify();
//     boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)true);
//     var11.clear();
//     boolean var16 = var11.getNotify();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     boolean var20 = var19.getNotify();
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)true);
//     var19.clear();
//     java.util.Collection var24 = var11.getTimePeriodsUniqueToOtherSeries(var19);
//     org.jfree.data.general.SeriesChangeListener var25 = null;
//     var11.removeChangeListener(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var30);
//     var31.setDescription("");
//     var31.setDescription("Time");
//     boolean var36 = var27.equals((java.lang.Object)var31);
//     int var37 = var27.getMonth();
//     var11.setKey((java.lang.Comparable)var37);
//     org.jfree.data.time.TimeSeries var39 = var2.addAndOrUpdate(var11);
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     var42.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var47 = var42.getDataItem((org.jfree.data.time.RegularTimePeriod)var46);
//     long var48 = var46.getMiddleMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var46, 100.0d, true);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test23"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Date var3 = var2.getEnd();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var3);
//     org.jfree.data.time.Year var5 = var4.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test24"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var13 = var10.getNearestDayOfWeek((-455));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test25"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     var2.setMaximumItemAge(28799999L);
//     var2.setRangeDescription("ThreadContext");
//     java.lang.String var11 = var2.getDescription();
//     java.beans.PropertyChangeListener var12 = null;
//     var2.removePropertyChangeListener(var12);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var17);
//     var18.setDescription("");
//     var18.setDescription("Time");
//     boolean var23 = var14.equals((java.lang.Object)var18);
//     org.jfree.data.time.RegularTimePeriod var24 = var14.next();
//     var2.add(var24, (java.lang.Number)1419153269426L);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test26"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var7 = null;
    long var8 = var6.getLastMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
    java.util.Calendar var11 = null;
    long var12 = var6.getMiddleMillisecond(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test27"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
    org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10);
    var10.setDescription("Sun Dec 21 01:14:34 PST 2014");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var16 = var10.getFollowingDayOfWeek(20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test28"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var2);
//     boolean var4 = var3.getNotify();
//     var3.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var3.getDataItem((org.jfree.data.time.RegularTimePeriod)var7);
//     long var9 = var7.getMiddleMillisecond();
//     java.util.Date var10 = var7.getTime();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
//     java.lang.String var14 = var13.toString();
//     int var15 = var11.compareTo((java.lang.Object)var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(17, var11);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419153280392L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10.0]"+ "'", var14.equals("org.jfree.data.general.SeriesChangeEvent[source=10.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test29"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test30"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getFirstMillisecond();
    java.util.Calendar var9 = null;
    long var10 = var7.getMiddleMillisecond(var9);
    java.util.Calendar var11 = null;
    long var12 = var7.getFirstMillisecond(var11);
    org.jfree.data.time.RegularTimePeriod var13 = var7.next();
    java.util.Date var14 = var7.getTime();
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
    boolean var17 = var4.isAfter(var16);
    boolean var18 = var2.isBefore(var16);
    int var19 = var2.getYYYY();
    int var20 = var2.toSerial();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 21);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test31"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Calendar var13 = null;
//     long var14 = var6.getFirstMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var6.previous();
//     int var16 = var4.compareTo((java.lang.Object)var6);
//     java.util.Calendar var17 = null;
//     long var18 = var4.getLastMillisecond(var17);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test32"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)100);
//     boolean var7 = var2.equals((java.lang.Object)(-571));
//     org.jfree.data.time.RegularTimePeriod var8 = var2.previous();
//     int var9 = var0.compareTo((java.lang.Object)var8);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var11);
//     long var13 = var12.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var12.addChangeListener(var14);
//     var12.fireSeriesChanged();
//     java.lang.String var17 = var12.getDescription();
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var19);
//     boolean var21 = var20.getNotify();
//     var20.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var20.getDataItem((org.jfree.data.time.RegularTimePeriod)var24);
//     var20.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var28 = var12.addAndOrUpdate(var20);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     long var30 = var29.getFirstMillisecond();
//     org.jfree.data.time.Year var31 = var29.getYear();
//     org.jfree.data.time.Year var32 = var29.getYear();
//     org.jfree.data.general.SeriesChangeEvent var33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var32);
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var35);
//     var36.setDescription("");
//     var36.setDescription("Time");
//     java.util.List var41 = var36.getItems();
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var44 = var43.getFirstMillisecond();
//     java.util.Calendar var45 = null;
//     long var46 = var43.getMiddleMillisecond(var45);
//     java.util.Calendar var47 = null;
//     long var48 = var43.getFirstMillisecond(var47);
//     java.util.Calendar var49 = null;
//     long var50 = var43.getMiddleMillisecond(var49);
//     org.jfree.data.time.TimeSeriesDataItem var52 = var36.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var43, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var53 = var43.previous();
//     org.jfree.data.time.TimeSeries var54 = var20.createCopy((org.jfree.data.time.RegularTimePeriod)var32, var53);
//     org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var57 = var56.getSerialIndex();
//     java.util.Date var58 = var56.getTime();
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year(var58);
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year(var58);
//     org.jfree.data.time.TimeSeriesDataItem var62 = var54.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var60, 100.0d);
//     boolean var63 = var0.equals((java.lang.Object)100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test33"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setDescription("Sun Dec 21 01:14:33 PST 2014");
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     java.lang.String var9 = var8.getDomainDescription();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var11);
//     long var13 = var12.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var12.addChangeListener(var14);
//     var12.fireSeriesChanged();
//     java.lang.String var17 = var12.getDescription();
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var19);
//     boolean var21 = var20.getNotify();
//     var20.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var20.getDataItem((org.jfree.data.time.RegularTimePeriod)var24);
//     var20.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var28 = var12.addAndOrUpdate(var20);
//     org.jfree.data.time.TimeSeries var29 = var8.addAndOrUpdate(var28);
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)100);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     int var35 = var33.compareTo((java.lang.Object)var34);
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var37);
//     long var39 = var38.getMaximumItemAge();
//     int var40 = var33.compareTo((java.lang.Object)var38);
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day();
//     boolean var42 = var33.equals((java.lang.Object)var41);
//     org.jfree.data.time.SerialDate var43 = var41.getSerialDate();
//     org.jfree.data.time.RegularTimePeriod var44 = var41.previous();
//     org.jfree.data.time.TimeSeriesDataItem var46 = var28.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)1419153270690L);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)12, false);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test34"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     var2.setDescription("");
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)100);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     int var11 = var9.compareTo((java.lang.Object)var10);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     long var15 = var14.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var14.addChangeListener(var16);
//     var14.fireSeriesChanged();
//     int var19 = var9.compareTo((java.lang.Object)var14);
//     boolean var21 = var9.equals((java.lang.Object)1.0f);
//     var2.add(var9);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test35"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesException: Preceding");

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test36"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)31);
    org.jfree.data.general.SeriesChangeListener var2 = null;
    var1.removeChangeListener(var2);
    var1.setDomainDescription("Fourth");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(7, (java.lang.Number)1419153270011L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test37"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test38"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(12, (-455));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test39"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Sun Dec 21 01:14:32 PST 2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test40"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test41"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var24 = var23.getSerialIndex();
//     java.util.Date var25 = var23.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(0, var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addYears(31, var27);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var31 = var30.getSerialIndex();
//     java.util.Date var32 = var30.getTime();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var37 = var36.getFirstMillisecond();
//     java.util.Calendar var38 = null;
//     long var39 = var36.getMiddleMillisecond(var38);
//     java.util.Calendar var40 = null;
//     long var41 = var36.getFirstMillisecond(var40);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.next();
//     java.util.Date var43 = var36.getTime();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(var43);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var44);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day(var44);
//     org.jfree.data.time.SerialDate var47 = var33.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.SerialDate var48 = var27.getEndOfCurrentMonth(var47);
//     boolean var49 = var2.isOn(var27);
//     java.lang.String var50 = var27.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(12, var27);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "31-December-1969"+ "'", var50.equals("31-December-1969"));
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test42"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     long var3 = var1.getFirstMillisecond();
//     int var4 = var1.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var6);
//     boolean var8 = var7.getNotify();
//     boolean var10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)true);
//     var7.clear();
//     boolean var12 = var7.getNotify();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var14);
//     boolean var16 = var15.getNotify();
//     boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var15, (java.lang.Object)true);
//     var15.clear();
//     java.util.Collection var20 = var7.getTimePeriodsUniqueToOtherSeries(var15);
//     org.jfree.data.general.SeriesChangeListener var21 = null;
//     var7.removeChangeListener(var21);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     var27.setDescription("");
//     var27.setDescription("Time");
//     boolean var32 = var23.equals((java.lang.Object)var27);
//     int var33 = var23.getMonth();
//     var7.setKey((java.lang.Comparable)var33);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var36 = var35.next();
//     java.lang.Class var38 = null;
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var38);
//     var39.setDescription("");
//     var39.setDescription("Time");
//     boolean var44 = var35.equals((java.lang.Object)var39);
//     java.util.Collection var45 = var7.getTimePeriodsUniqueToOtherSeries(var39);
//     org.jfree.data.general.SeriesChangeEvent var46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var7);
//     boolean var47 = var1.equals((java.lang.Object)var46);
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     java.lang.String var51 = var50.getDomainDescription();
//     boolean var52 = var1.equals((java.lang.Object)var50);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var53 = new org.jfree.data.time.Month((-25547), var1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2014"+ "'", var2.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "Time"+ "'", var51.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test43"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sun Dec 21 01:14:40 PST 2014", var1);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test44"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("21-December-2014", var1);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 16:00:00 PST 1969");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test46"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("January");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test47"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Following", var1);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test48"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     long var8 = var5.getSerialIndex();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, var9);
//     int var11 = var5.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 23640L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1969);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test49"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-571), 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test51"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419153275639L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1419153275639L);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test52"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)100);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     int var25 = var23.compareTo((java.lang.Object)var24);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     long var29 = var28.getMaximumItemAge();
//     int var30 = var23.compareTo((java.lang.Object)var28);
//     boolean var31 = var2.equals((java.lang.Object)var28);
//     int var32 = var2.getMonth();
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var34 = var33.next();
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var36);
//     var37.setDescription("");
//     var37.setDescription("Time");
//     boolean var42 = var33.equals((java.lang.Object)var37);
//     int var43 = var33.getMonth();
//     long var44 = var33.getFirstMillisecond();
//     long var45 = var33.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var46 = var33.getSerialDate();
//     boolean var47 = var2.isBefore(var46);
//     org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var51 = var50.getSerialIndex();
//     java.util.Date var52 = var50.getTime();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addYears(0, var53);
//     boolean var55 = var2.isOnOrBefore(var54);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(31, var54);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == true);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test53"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var2 = var1.getDayOfWeek();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var6);
//     var7.setDescription("");
//     var7.setDescription("Time");
//     boolean var12 = var3.equals((java.lang.Object)var7);
//     int var13 = var3.getMonth();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
//     boolean var17 = var3.equals((java.lang.Object)var15);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond((-1L));
//     boolean var20 = var3.equals((java.lang.Object)var19);
//     java.util.Calendar var21 = null;
//     long var22 = var19.getMiddleMillisecond(var21);
//     long var23 = var19.getLastMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var24 = var1.compareTo((java.lang.Object)var19);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1L));
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test55"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Date var8 = var1.getTime();
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var8);
    long var12 = var11.getFirstMillisecond();
    org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
    org.jfree.data.time.RegularTimePeriod var14 = var13.next();
    java.lang.Class var16 = null;
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
    var17.setDescription("");
    var17.setDescription("Time");
    boolean var22 = var13.equals((java.lang.Object)var17);
    var17.fireSeriesChanged();
    boolean var24 = var17.isEmpty();
    java.util.List var25 = var17.getItems();
    int var26 = var11.compareTo((java.lang.Object)var17);
    org.jfree.data.general.SeriesChangeListener var27 = null;
    var17.removeChangeListener(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test56"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     java.lang.String var16 = var10.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var19 = var18.getFirstMillisecond();
//     java.util.Calendar var20 = null;
//     long var21 = var18.getMiddleMillisecond(var20);
//     java.util.Calendar var22 = null;
//     long var23 = var18.getFirstMillisecond(var22);
//     org.jfree.data.time.RegularTimePeriod var24 = var18.next();
//     java.util.Date var25 = var18.getTime();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month(var25);
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var28 = var26.next();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 100.0d);
//     org.jfree.data.time.RegularTimePeriod var31 = var26.previous();
//     var10.add(var31, (java.lang.Number)10.0f);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test57"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test58"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var9);
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var9);
    java.util.TimeZone var13 = null;
    org.jfree.data.time.RegularTimePeriod var14 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var9, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test59"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     java.lang.String var13 = var11.toString();
//     long var14 = var11.getLastMillisecond();
//     org.jfree.data.time.Year var15 = var11.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(100, var15);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "December 1969"+ "'", var13.equals("December 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test60"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2147483647, 7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test62"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getYear();
//     java.util.Calendar var14 = null;
//     long var15 = var0.getFirstMillisecond(var14);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test63"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test64"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-25547), (-459), 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test65"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)100);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     int var29 = var27.compareTo((java.lang.Object)var28);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     long var33 = var32.getMaximumItemAge();
//     int var34 = var27.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     boolean var36 = var27.equals((java.lang.Object)var35);
//     org.jfree.data.time.SerialDate var37 = var35.getSerialDate();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.TimeSeriesDataItem var40 = var22.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)1419153270690L);
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month();
//     long var42 = var41.getFirstMillisecond();
//     org.jfree.data.time.Year var43 = var41.getYear();
//     org.jfree.data.time.Year var44 = var41.getYear();
//     java.lang.Object var45 = null;
//     boolean var46 = var41.equals(var45);
//     org.jfree.data.time.TimeSeriesDataItem var48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)1419153269727L);
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var48, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var51);
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var54 = var53.next();
//     org.jfree.data.time.TimeSeriesDataItem var56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var53, (java.lang.Number)100);
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year();
//     int var58 = var56.compareTo((java.lang.Object)var57);
//     java.lang.Class var60 = null;
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var60);
//     long var62 = var61.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var63 = null;
//     var61.addChangeListener(var63);
//     var61.fireSeriesChanged();
//     int var66 = var56.compareTo((java.lang.Object)var61);
//     int var67 = var61.getItemCount();
//     int var68 = var48.compareTo((java.lang.Object)var67);
//     java.lang.Class var70 = null;
//     org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var70);
//     var71.setDescription("");
//     java.lang.String var74 = var71.getDescription();
//     java.lang.Class var76 = null;
//     org.jfree.data.time.TimeSeries var77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var76);
//     boolean var78 = var77.getNotify();
//     boolean var80 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var77, (java.lang.Object)true);
//     java.lang.Comparable var81 = var77.getKey();
//     org.jfree.data.time.TimeSeries var82 = var71.addAndOrUpdate(var77);
//     boolean var83 = var48.equals((java.lang.Object)var71);
//     var22.add(var48);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test66"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getLastMillisecond();
//     org.jfree.data.time.SerialDate var5 = var2.getSerialDate();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-435), var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test67"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)' ');
//     var1.setRangeDescription("31-December-3938");
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     long var24 = var23.getFirstMillisecond();
//     org.jfree.data.time.Year var25 = var23.getYear();
//     org.jfree.data.time.Year var26 = var23.getYear();
//     org.jfree.data.general.SeriesChangeEvent var27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var26);
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var29);
//     var30.setDescription("");
//     var30.setDescription("Time");
//     java.util.List var35 = var30.getItems();
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var38 = var37.getFirstMillisecond();
//     java.util.Calendar var39 = null;
//     long var40 = var37.getMiddleMillisecond(var39);
//     java.util.Calendar var41 = null;
//     long var42 = var37.getFirstMillisecond(var41);
//     java.util.Calendar var43 = null;
//     long var44 = var37.getMiddleMillisecond(var43);
//     org.jfree.data.time.TimeSeriesDataItem var46 = var30.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var47 = var37.previous();
//     org.jfree.data.time.TimeSeries var48 = var14.createCopy((org.jfree.data.time.RegularTimePeriod)var26, var47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var47, 10.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test68"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = var10.getYear();
//     org.jfree.data.time.Year var13 = var10.getYear();
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     int var15 = var10.getMonth();
//     int var16 = var10.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test69"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getSerialIndex();
//     java.util.Calendar var12 = null;
//     long var13 = var0.getLastMillisecond(var12);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test70"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.String var4 = var1.toString();
//     java.util.Calendar var5 = null;
//     long var6 = var1.getLastMillisecond(var5);
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var8);
//     var9.setDescription("");
//     java.lang.Class var12 = var9.getTimePeriodClass();
//     java.lang.Class var13 = var9.getTimePeriodClass();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     long var16 = var14.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var14.next();
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     long var21 = var19.getLastMillisecond();
//     org.jfree.data.time.SerialDate var22 = var19.getSerialDate();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var22);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var22, var24);
//     boolean var26 = var14.equals((java.lang.Object)var24);
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var29 = var28.getFirstMillisecond();
//     java.util.Calendar var30 = null;
//     long var31 = var28.getMiddleMillisecond(var30);
//     java.util.Calendar var32 = null;
//     long var33 = var28.getFirstMillisecond(var32);
//     org.jfree.data.time.RegularTimePeriod var34 = var28.next();
//     java.util.Date var35 = var28.getTime();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(var35);
//     int var37 = var36.getYearValue();
//     java.util.Date var38 = var36.getStart();
//     int var39 = var36.getYearValue();
//     boolean var40 = var14.equals((java.lang.Object)var36);
//     java.lang.Number var41 = var9.getValue((org.jfree.data.time.RegularTimePeriod)var14);
//     int var42 = var1.compareTo((java.lang.Object)var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var4.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test71"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     org.jfree.data.general.SeriesChangeEvent var23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     java.util.List var31 = var26.getItems();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var33.getMiddleMillisecond(var39);
//     org.jfree.data.time.TimeSeriesDataItem var42 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var43 = var33.previous();
//     org.jfree.data.time.TimeSeries var44 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var22, var43);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var47 = var46.getSerialIndex();
//     java.util.Date var48 = var46.getTime();
//     org.jfree.data.time.Year var49 = new org.jfree.data.time.Year(var48);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year(var48);
//     org.jfree.data.time.TimeSeriesDataItem var52 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var50, 100.0d);
//     java.lang.String var53 = var44.getDomainDescription();
//     org.jfree.data.general.SeriesChangeListener var54 = null;
//     var44.addChangeListener(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "Time"+ "'", var53.equals("Time"));
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test72"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test73"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     java.util.Collection var40 = var2.getTimePeriodsUniqueToOtherSeries(var34);
//     org.jfree.data.general.SeriesChangeEvent var41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
//     java.lang.String var42 = var2.getDomainDescription();
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var45 = var44.getSerialIndex();
//     java.util.Date var46 = var44.getTime();
//     java.util.Date var47 = var44.getTime();
//     org.jfree.data.time.Month var48 = new org.jfree.data.time.Month(var47);
//     long var49 = var48.getLastMillisecond();
//     org.jfree.data.time.Year var50 = var48.getYear();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var48, (java.lang.Number)1419153273057L);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test74"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    int var10 = var3.compareTo((java.lang.Object)var8);
    org.jfree.data.time.RegularTimePeriod var11 = var3.getPeriod();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test75"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Date var13 = var6.getTime();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
//     boolean var16 = var3.isAfter(var15);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getSerialIndex();
//     java.util.Date var23 = var21.getTime();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(0, var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(31, var25);
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var29 = var28.getSerialIndex();
//     java.util.Date var30 = var28.getTime();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getFirstMillisecond();
//     java.util.Calendar var36 = null;
//     long var37 = var34.getMiddleMillisecond(var36);
//     java.util.Calendar var38 = null;
//     long var39 = var34.getFirstMillisecond(var38);
//     org.jfree.data.time.RegularTimePeriod var40 = var34.next();
//     java.util.Date var41 = var34.getTime();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var42);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day(var42);
//     org.jfree.data.time.SerialDate var45 = var31.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.SerialDate var46 = var25.getEndOfCurrentMonth(var45);
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.addYears(1969, var25);
//     java.lang.String var48 = var47.toString();
//     org.jfree.data.time.SerialDate var49 = var3.getEndOfCurrentMonth(var47);
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate)var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2014, (org.jfree.data.time.SerialDate)var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "31-December-3938"+ "'", var48.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test76"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Following");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test77"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
    boolean var11 = var10.getNotify();
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
    var10.clear();
    java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
    org.jfree.data.time.TimeSeries var18 = var10.createCopy(10, 10);
    boolean var19 = var18.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.update((-460), (java.lang.Number)1.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test78"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.String var5 = var2.getDescription();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     boolean var9 = var8.getNotify();
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
//     boolean var14 = var8.getNotify();
//     java.lang.String var15 = var8.getDescription();
//     var8.removeAgedItems(1419153271278L, true);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test79"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test80"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.String var10 = var2.getDomainDescription();
    java.beans.PropertyChangeListener var11 = null;
    var2.removePropertyChangeListener(var11);
    var2.setRangeDescription("Wednesday");
    var2.setRangeDescription("October");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var10.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test81"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sun Dec 21 01:14:30 PST 2014");

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test82"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.util.List var7 = var2.getItems();
    org.jfree.data.general.SeriesChangeEvent var8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
    java.lang.String var9 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test83"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test84"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(20);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test85"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test86"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     int var2 = var0.getMonth();
//     long var3 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 24180L);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test87"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var3);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getFirstMillisecond(var7);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test88"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     long var14 = var0.getFirstMillisecond();
//     java.util.Calendar var15 = null;
//     long var16 = var0.getFirstMillisecond(var15);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test89"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Jan"+ "'", var2.equals("Jan"));

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test90"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.time.TimeSeries var18 = var10.createCopy(10, 10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     java.lang.Object var23 = null;
//     boolean var24 = var19.equals(var23);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1419153269727L);
//     var18.delete((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getFirstMillisecond();
//     java.util.Calendar var31 = null;
//     long var32 = var29.getMiddleMillisecond(var31);
//     java.util.Calendar var33 = null;
//     var29.peg(var33);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var18.getDataItem((org.jfree.data.time.RegularTimePeriod)var29);
//     org.jfree.data.general.SeriesChangeListener var36 = null;
//     var18.addChangeListener(var36);
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     long var39 = var38.getFirstMillisecond();
//     org.jfree.data.time.Year var40 = var38.getYear();
//     org.jfree.data.time.Year var41 = var38.getYear();
//     java.lang.Object var42 = null;
//     boolean var43 = var38.equals(var42);
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, (java.lang.Number)1419153269727L);
//     var18.add(var45, false);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test91"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getLastMillisecond();
//     org.jfree.data.time.SerialDate var5 = var2.getSerialDate();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(0, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-25544), var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test92"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
    long var15 = var14.getFirstMillisecond();
    java.util.Calendar var16 = null;
    long var17 = var14.getMiddleMillisecond(var16);
    java.util.Calendar var18 = null;
    long var19 = var14.getFirstMillisecond(var18);
    org.jfree.data.time.RegularTimePeriod var20 = var14.next();
    java.util.Date var21 = var14.getTime();
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var22);
    org.jfree.data.time.SerialDate var24 = var11.getEndOfCurrentMonth(var23);
    java.lang.String var25 = var24.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test93"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     boolean var5 = var0.equals((java.lang.Object)(-571));
//     long var6 = var0.getFirstMillisecond();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = var9.getYear();
//     org.jfree.data.time.Year var12 = var9.getYear();
//     java.lang.Object var13 = null;
//     boolean var14 = var9.equals(var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419153269727L);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var16, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)100);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     int var26 = var24.compareTo((java.lang.Object)var25);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var28);
//     long var30 = var29.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var29.addChangeListener(var31);
//     var29.fireSeriesChanged();
//     int var34 = var24.compareTo((java.lang.Object)var29);
//     int var35 = var29.getItemCount();
//     int var36 = var16.compareTo((java.lang.Object)var35);
//     var8.add(var16);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test94"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     java.lang.String var4 = var0.toString();
//     java.lang.String var5 = var0.toString();
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test95"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getSerialIndex();
    java.util.Date var5 = var3.getTime();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(0, var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(31, var7);
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
    long var11 = var10.getSerialIndex();
    java.util.Date var12 = var10.getTime();
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
    org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
    long var17 = var16.getFirstMillisecond();
    java.util.Calendar var18 = null;
    long var19 = var16.getMiddleMillisecond(var18);
    java.util.Calendar var20 = null;
    long var21 = var16.getFirstMillisecond(var20);
    org.jfree.data.time.RegularTimePeriod var22 = var16.next();
    java.util.Date var23 = var16.getTime();
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var24);
    org.jfree.data.time.Day var26 = new org.jfree.data.time.Day(var24);
    org.jfree.data.time.SerialDate var27 = var13.getEndOfCurrentMonth(var24);
    org.jfree.data.time.SerialDate var28 = var7.getEndOfCurrentMonth(var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var30 = var27.getFollowingDayOfWeek((-571));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test96"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, (-457));
//     java.util.Calendar var3 = null;
//     long var4 = var2.getLastMillisecond(var3);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test97"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     java.util.List var12 = var2.getItems();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     java.lang.String var14 = var13.toString();
//     org.jfree.data.time.RegularTimePeriod var15 = var13.previous();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var19);
//     var20.setDescription("");
//     var20.setDescription("Time");
//     boolean var25 = var16.equals((java.lang.Object)var20);
//     int var26 = var16.getMonth();
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var28);
//     boolean var30 = var16.equals((java.lang.Object)var28);
//     boolean var31 = var13.equals((java.lang.Object)var28);
//     int var32 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var13);
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var34);
//     boolean var36 = var35.getNotify();
//     boolean var38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, (java.lang.Object)true);
//     var35.clear();
//     boolean var40 = var35.getNotify();
//     java.lang.Class var42 = null;
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var42);
//     boolean var44 = var43.getNotify();
//     boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var43, (java.lang.Object)true);
//     var43.clear();
//     java.util.Collection var48 = var35.getTimePeriodsUniqueToOtherSeries(var43);
//     org.jfree.data.time.TimeSeries var51 = var43.createCopy(10, 10);
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     long var53 = var52.getFirstMillisecond();
//     org.jfree.data.time.Year var54 = var52.getYear();
//     org.jfree.data.time.Year var55 = var52.getYear();
//     java.lang.Object var56 = null;
//     boolean var57 = var52.equals(var56);
//     org.jfree.data.time.TimeSeriesDataItem var59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var52, (java.lang.Number)1419153269727L);
//     var51.delete((org.jfree.data.time.RegularTimePeriod)var52);
//     org.jfree.data.time.FixedMillisecond var62 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var63 = var62.getFirstMillisecond();
//     java.util.Calendar var64 = null;
//     long var65 = var62.getMiddleMillisecond(var64);
//     java.util.Calendar var66 = null;
//     var62.peg(var66);
//     org.jfree.data.time.TimeSeriesDataItem var68 = var51.getDataItem((org.jfree.data.time.RegularTimePeriod)var62);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var62, (java.lang.Number)(-1L));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "2014"+ "'", var14.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var68);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test98"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getFirstMillisecond();
//     int var3 = var0.getYear();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     boolean var7 = var6.getNotify();
//     boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)true);
//     var6.clear();
//     boolean var11 = var6.getNotify();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)true);
//     var14.clear();
//     java.util.Collection var19 = var6.getTimePeriodsUniqueToOtherSeries(var14);
//     org.jfree.data.general.SeriesChangeListener var20 = null;
//     var6.removeChangeListener(var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     boolean var31 = var22.equals((java.lang.Object)var26);
//     int var32 = var22.getMonth();
//     var6.setKey((java.lang.Comparable)var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var37);
//     var38.setDescription("");
//     var38.setDescription("Time");
//     boolean var43 = var34.equals((java.lang.Object)var38);
//     java.util.Collection var44 = var6.getTimePeriodsUniqueToOtherSeries(var38);
//     org.jfree.data.general.SeriesChangeEvent var45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
//     boolean var46 = var0.equals((java.lang.Object)var45);
//     java.lang.Object var47 = var45.getSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test99"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.next();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     long var18 = var16.getLastMillisecond();
//     org.jfree.data.time.SerialDate var19 = var16.getSerialDate();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var19);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var19, var21);
//     boolean var23 = var11.equals((java.lang.Object)var21);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var26 = var25.getFirstMillisecond();
//     java.util.Calendar var27 = null;
//     long var28 = var25.getMiddleMillisecond(var27);
//     java.util.Calendar var29 = null;
//     long var30 = var25.getFirstMillisecond(var29);
//     org.jfree.data.time.RegularTimePeriod var31 = var25.next();
//     java.util.Date var32 = var25.getTime();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var32);
//     int var34 = var33.getYearValue();
//     java.util.Date var35 = var33.getStart();
//     int var36 = var33.getYearValue();
//     boolean var37 = var11.equals((java.lang.Object)var33);
//     org.jfree.data.time.TimeSeriesDataItem var38 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     java.lang.Number var39 = var38.getValue();
//     java.lang.Number var40 = var38.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + 0.0d+ "'", var39.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + 0.0d+ "'", var40.equals(0.0d));
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test100"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test101"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test102"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test103"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     int var19 = var2.getMaximumItemCount();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getFirstMillisecond();
//     java.util.Calendar var24 = null;
//     long var25 = var22.getMiddleMillisecond(var24);
//     java.util.Calendar var26 = null;
//     long var27 = var22.getFirstMillisecond(var26);
//     org.jfree.data.time.RegularTimePeriod var28 = var22.next();
//     java.util.Date var29 = var22.getTime();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(var29);
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var29);
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var29);
//     java.util.TimeZone var33 = null;
//     org.jfree.data.time.RegularTimePeriod var34 = org.jfree.data.time.RegularTimePeriod.createInstance(var20, var29, var33);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(var29);
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day(var29);
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var38 = var37.next();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var40);
//     var41.setDescription("");
//     var41.setDescription("Time");
//     boolean var46 = var37.equals((java.lang.Object)var41);
//     org.jfree.data.time.RegularTimePeriod var47 = var37.previous();
//     org.jfree.data.time.TimeSeries var48 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var36, var47);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test104"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     var2.setDomainDescription("org.jfree.data.general.SeriesException: ThreadContext");
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     boolean var12 = var11.getNotify();
//     var11.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var11.getDataItem((org.jfree.data.time.RegularTimePeriod)var15);
//     long var17 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var19 = var15.previous();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (-1.0d));
//     java.util.List var22 = var2.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var24 = var2.getDataItem(12);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419153284006L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test105"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test106"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sun Dec 21 01:14:43 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test107"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
    boolean var11 = var10.getNotify();
    boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
    var10.clear();
    java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
    long var16 = var10.getMaximumItemAge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var18 = var10.getValue(2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 9223372036854775807L);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test108"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test109"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var16 = var15.getSerialIndex();
//     java.util.Date var17 = var15.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getFirstMillisecond();
//     java.util.Calendar var23 = null;
//     long var24 = var21.getMiddleMillisecond(var23);
//     java.util.Calendar var25 = null;
//     long var26 = var21.getFirstMillisecond(var25);
//     org.jfree.data.time.RegularTimePeriod var27 = var21.next();
//     java.util.Date var28 = var21.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var29);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var29);
//     org.jfree.data.time.SerialDate var32 = var18.getEndOfCurrentMonth(var29);
//     boolean var33 = var0.equals((java.lang.Object)var29);
//     java.util.Calendar var34 = null;
//     long var35 = var0.getLastMillisecond(var34);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test110"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
    var4.setDescription("");
    var4.setDescription("Time");
    boolean var9 = var0.equals((java.lang.Object)var4);
    var4.fireSeriesChanged();
    boolean var11 = var4.isEmpty();
    java.util.List var12 = var4.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var15 = var4.createCopy((-459), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test111"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     java.lang.Comparable var6 = var2.getKey();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var8);
//     java.lang.String var10 = var9.getDomainDescription();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     long var14 = var13.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var13.addChangeListener(var15);
//     var13.fireSeriesChanged();
//     java.lang.String var18 = var13.getDescription();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var20);
//     boolean var22 = var21.getNotify();
//     var21.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = var21.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     var21.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var29 = var13.addAndOrUpdate(var21);
//     org.jfree.data.time.TimeSeries var30 = var9.addAndOrUpdate(var29);
//     java.util.Collection var31 = var2.getTimePeriodsUniqueToOtherSeries(var29);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)100);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     int var37 = var35.compareTo((java.lang.Object)var36);
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var39);
//     long var41 = var40.getMaximumItemAge();
//     int var42 = var35.compareTo((java.lang.Object)var40);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     boolean var44 = var35.equals((java.lang.Object)var43);
//     org.jfree.data.time.RegularTimePeriod var45 = var35.getPeriod();
//     var29.add(var35);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test112"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(31);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test113"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.next();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     long var18 = var16.getLastMillisecond();
//     org.jfree.data.time.SerialDate var19 = var16.getSerialDate();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var19);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var19, var21);
//     boolean var23 = var11.equals((java.lang.Object)var21);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var26 = var25.getFirstMillisecond();
//     java.util.Calendar var27 = null;
//     long var28 = var25.getMiddleMillisecond(var27);
//     java.util.Calendar var29 = null;
//     long var30 = var25.getFirstMillisecond(var29);
//     org.jfree.data.time.RegularTimePeriod var31 = var25.next();
//     java.util.Date var32 = var25.getTime();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var32);
//     int var34 = var33.getYearValue();
//     java.util.Date var35 = var33.getStart();
//     int var36 = var33.getYearValue();
//     boolean var37 = var11.equals((java.lang.Object)var33);
//     org.jfree.data.time.TimeSeriesDataItem var38 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     var2.removeAgedItems(false);
//     java.beans.PropertyChangeListener var41 = null;
//     var2.addPropertyChangeListener(var41);
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var44 = var43.next();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var43, (-1.0d), false);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test114"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test115"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-6654));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test116"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test117"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    int var3 = var2.getItemCount();
    var2.setNotify(false);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
    var10.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var13 = var10.getDataItem(13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test118"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, (-457));
//     java.lang.String var3 = var2.toString();
//     long var4 = var2.getFirstMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var2.getLastMillisecond(var5);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test119"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var15 = var14.getSerialIndex();
//     java.util.Date var16 = var14.getTime();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addYears(0, var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addYears(31, var18);
//     int var20 = var9.compareTo((java.lang.Object)31);
//     java.util.Calendar var21 = null;
//     long var22 = var9.getLastMillisecond(var21);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test120"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 1900, 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test121"); }


    java.lang.Class var0 = null;
    java.lang.Class var1 = null;
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getFirstMillisecond();
    java.util.Calendar var5 = null;
    long var6 = var3.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var3.getFirstMillisecond(var7);
    org.jfree.data.time.RegularTimePeriod var9 = var3.next();
    java.util.Date var10 = var3.getTime();
    org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var10);
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
    org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var10);
    java.util.TimeZone var14 = null;
    org.jfree.data.time.RegularTimePeriod var15 = org.jfree.data.time.RegularTimePeriod.createInstance(var1, var10, var14);
    java.util.TimeZone var16 = null;
    org.jfree.data.time.RegularTimePeriod var17 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var10, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test122"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Following");

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test123"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=2014]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test124"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.clear();
    java.beans.PropertyChangeListener var9 = null;
    var2.addPropertyChangeListener(var9);
    java.util.Collection var11 = var2.getTimePeriods();
    java.lang.String var12 = var2.getDescription();
    java.lang.String var13 = var2.getDomainDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Time"+ "'", var13.equals("Time"));

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test125"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var32 = var1.getNearestDayOfWeek((-571));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-25544), (-6654));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test127"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     var2.clear();
//     var2.setMaximumItemAge(1419153269727L);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     var11.setDescription("");
//     var11.setDescription("Time");
//     boolean var16 = var7.equals((java.lang.Object)var11);
//     int var17 = var7.getMonth();
//     long var18 = var7.getFirstMillisecond();
//     long var19 = var7.getFirstMillisecond();
//     int var20 = var7.getDayOfMonth();
//     java.lang.Number var21 = null;
//     org.jfree.data.time.TimeSeriesDataItem var22 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, var21);
//     long var23 = var7.getFirstMillisecond();
//     long var24 = var7.getFirstMillisecond();
//     java.util.Calendar var25 = null;
//     long var26 = var7.getLastMillisecond(var25);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test128"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, (-460), 17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test130"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test131"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     var17.setDescription("");
//     var17.setDescription("Time");
//     boolean var22 = var13.equals((java.lang.Object)var17);
//     long var23 = var13.getSerialIndex();
//     long var24 = var13.getSerialIndex();
//     org.jfree.data.time.TimeSeries var25 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, (org.jfree.data.time.RegularTimePeriod)var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.delete(2014, 7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test132"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test133"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    boolean var8 = var2.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(1969, (-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test134"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     long var8 = var6.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var9 = var6.next();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     var11.setValue((java.lang.Number)1419153270723L);
//     var2.add(var11);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test135"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getSerialIndex();
//     java.util.Date var4 = var2.getTime();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var9 = var8.getFirstMillisecond();
//     java.util.Calendar var10 = null;
//     long var11 = var8.getMiddleMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var8.getFirstMillisecond(var12);
//     org.jfree.data.time.RegularTimePeriod var14 = var8.next();
//     java.util.Date var15 = var8.getTime();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var16);
//     org.jfree.data.time.SerialDate var19 = var5.getEndOfCurrentMonth(var16);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addMonths(100, var16);
//     java.lang.String var21 = var16.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "31-December-1969"+ "'", var21.equals("31-December-1969"));
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test136"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Wed Dec 31 16:00:00 PST 1969", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test137"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test138"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.String var3 = var2.getDomainDescription();
    var2.clear();
    var2.setMaximumItemAge(1419153269727L);
    java.lang.String var7 = var2.getDomainDescription();
    java.lang.String var8 = var2.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Time"+ "'", var7.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Value"+ "'", var8.equals("Value"));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test139"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test140"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     java.util.TimeZone var12 = null;
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var11, var12);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test141"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "17-December-2014", "Wed Dec 31 16:00:00 PST 1969", var3);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Date var13 = var6.getTime();
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(var13);
//     long var15 = var14.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var16 = var14.next();
//     org.jfree.data.time.RegularTimePeriod var17 = var14.previous();
//     int var18 = var0.compareTo((java.lang.Object)var14);
//     long var19 = var14.getLastMillisecond();
//     java.util.Calendar var20 = null;
//     long var21 = var14.getFirstMillisecond(var20);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test142"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Calendar var8 = null;
    long var9 = var1.getFirstMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var1.previous();
    java.util.Date var11 = var1.getTime();
    java.lang.Class var14 = null;
    org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11, "Wed Dec 31 16:00:00 PST 1969", "January -457", var14);
    org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test143"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     var2.setMaximumItemCount(100);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var33.next();
//     java.util.Date var40 = var33.getTime();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(var40);
//     long var42 = var41.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var43 = var41.next();
//     org.jfree.data.time.RegularTimePeriod var44 = var41.previous();
//     int var45 = var41.getYearValue();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)(byte)1);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test144"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addMonths((-457), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test145"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(20, 0, 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test146"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var9 = var8.next();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var11);
//     var12.setDescription("");
//     var12.setDescription("Time");
//     boolean var17 = var8.equals((java.lang.Object)var12);
//     int var18 = var8.getMonth();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var20);
//     boolean var22 = var8.equals((java.lang.Object)var20);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond((-1L));
//     boolean var25 = var8.equals((java.lang.Object)var24);
//     long var26 = var24.getSerialIndex();
//     var2.setKey((java.lang.Comparable)var26);
//     java.lang.String var28 = var2.getRangeDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var31 = var2.createCopy((-6654), (-571));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "Value"+ "'", var28.equals("Value"));
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test147"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var2 = var1.getMonth();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     long var4 = var3.getMiddleMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var3.getMiddleMillisecond(var5);
//     boolean var7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419153285094L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419153285094L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test148"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("17-December-2014", var1);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test149"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.String var12 = var10.toString();
//     java.util.Calendar var13 = null;
//     long var14 = var10.getMiddleMillisecond(var13);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test150"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     long var5 = var3.getLastMillisecond();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.general.SeriesChangeEvent var8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1420099199999L);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test151"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     var14.setDescription("");
//     var14.setDescription("Time");
//     boolean var19 = var10.equals((java.lang.Object)var14);
//     int var20 = var10.getMonth();
//     long var21 = var10.getLastMillisecond();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     long var23 = var22.getFirstMillisecond();
//     org.jfree.data.time.Year var24 = var22.getYear();
//     long var25 = var22.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var26 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var10, (org.jfree.data.time.RegularTimePeriod)var22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update(4, (java.lang.Number)(-6654));
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test152"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)' ');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMaximumItemCount((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test153"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-455));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test154"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     int var19 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     long var26 = var24.getLastMillisecond();
//     org.jfree.data.time.SerialDate var27 = var24.getSerialDate();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addMonths(0, var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addYears(1, var27);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     long var33 = var31.getLastMillisecond();
//     org.jfree.data.time.SerialDate var34 = var31.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(0, var34);
//     org.jfree.data.time.SerialDate var37 = var35.getPreviousDayOfWeek(4);
//     boolean var38 = var21.isInRange(var27, var35);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var40 = var39.next();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)100);
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     int var44 = var42.compareTo((java.lang.Object)var43);
//     java.lang.Class var46 = null;
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var46);
//     long var48 = var47.getMaximumItemAge();
//     int var49 = var42.compareTo((java.lang.Object)var47);
//     boolean var50 = var21.equals((java.lang.Object)var47);
//     int var51 = var21.getMonth();
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var53 = var52.next();
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var55);
//     var56.setDescription("");
//     var56.setDescription("Time");
//     boolean var61 = var52.equals((java.lang.Object)var56);
//     int var62 = var52.getMonth();
//     long var63 = var52.getFirstMillisecond();
//     long var64 = var52.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var65 = var52.getSerialDate();
//     boolean var66 = var21.isBefore(var65);
//     var21.setDescription("Sun Dec 21 01:14:33 PST 2014");
//     boolean var69 = var1.isAfter((org.jfree.data.time.SerialDate)var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test155"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-460), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test156"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2147483647, 7, 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test157"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var24 = var23.getSerialIndex();
//     java.util.Date var25 = var23.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(0, var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addYears(31, var27);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var31 = var30.getSerialIndex();
//     java.util.Date var32 = var30.getTime();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var37 = var36.getFirstMillisecond();
//     java.util.Calendar var38 = null;
//     long var39 = var36.getMiddleMillisecond(var38);
//     java.util.Calendar var40 = null;
//     long var41 = var36.getFirstMillisecond(var40);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.next();
//     java.util.Date var43 = var36.getTime();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(var43);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var44);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day(var44);
//     org.jfree.data.time.SerialDate var47 = var33.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.SerialDate var48 = var27.getEndOfCurrentMonth(var47);
//     boolean var49 = var2.isOn(var27);
//     int var50 = var2.getYYYY();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1900);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test158"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.setMaximumItemAge(1417420800000L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(31, (java.lang.Number)1419153275639L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test159"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-25547));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test160"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=1419148800000]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test161"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-6654));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test162"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test163"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(13, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test164"); }


    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
    long var6 = var5.getSerialIndex();
    java.util.Date var7 = var5.getTime();
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(0, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(31, var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(31, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-570), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test165"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     int var11 = var0.getYear();
//     java.lang.String var12 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "21-December-2014"+ "'", var12.equals("21-December-2014"));
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test166"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=false]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test167"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test168"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-41973), (-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test169"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-455));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test170"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     long var3 = var0.getFirstMillisecond();
//     int var5 = var0.compareTo((java.lang.Object)0.0f);
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test171"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getSerialIndex();
    java.util.Date var4 = var2.getTime();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    long var9 = var8.getFirstMillisecond();
    java.util.Calendar var10 = null;
    long var11 = var8.getMiddleMillisecond(var10);
    java.util.Calendar var12 = null;
    long var13 = var8.getFirstMillisecond(var12);
    org.jfree.data.time.RegularTimePeriod var14 = var8.next();
    java.util.Date var15 = var8.getTime();
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var16);
    org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var16);
    org.jfree.data.time.SerialDate var19 = var5.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var21 = var19.getFollowingDayOfWeek(4);
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays((-455), var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test172"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     var2.setDescription("");
//     java.lang.Object var32 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     long var34 = var33.getLastMillisecond();
//     long var35 = var33.getLastMillisecond();
//     long var36 = var33.getLastMillisecond();
//     java.lang.String var37 = var33.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)(short)1);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "21-December-2014"+ "'", var37.equals("21-December-2014"));
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test173"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     org.jfree.data.general.SeriesChangeEvent var23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     java.util.List var31 = var26.getItems();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var33.getMiddleMillisecond(var39);
//     org.jfree.data.time.TimeSeriesDataItem var42 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var43 = var33.previous();
//     org.jfree.data.time.TimeSeries var44 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var22, var43);
//     var10.setMaximumItemAge(1419153270690L);
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var49 = var48.getFirstMillisecond();
//     long var50 = var48.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, 0.0d);
//     var52.setValue((java.lang.Number)1.0f);
//     var10.add(var52, false);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test174"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.beans.PropertyChangeListener var7 = null;
    var2.removePropertyChangeListener(var7);
    long var9 = var2.getMaximumItemAge();
    java.util.List var10 = var2.getItems();
    var2.setDescription("Sun Dec 21 01:14:44 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test175"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var2.removeChangeListener(var30);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var33.next();
//     java.util.Date var40 = var33.getTime();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(var40);
//     long var42 = var41.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var43 = var41.next();
//     org.jfree.data.time.RegularTimePeriod var44 = var41.previous();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.RegularTimePeriod var46 = var41.next();
//     int var47 = var41.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1969);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test176"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test177"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var4, var6);
//     var7.setRangeDescription("Sun Dec 21 01:14:39 PST 2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test178"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.String var4 = var1.toString();
//     long var5 = var1.getFirstMillisecond();
//     java.util.Date var6 = var1.getStart();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(var6);
//     java.util.Date var8 = var7.getTime();
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var8, var9);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test179"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
//     org.jfree.data.time.RegularTimePeriod var11 = var5.next();
//     java.util.Date var12 = var5.getTime();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var13);
//     boolean var15 = var2.isAfter(var14);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var21 = var20.getSerialIndex();
//     java.util.Date var22 = var20.getTime();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(31, var24);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getSerialIndex();
//     java.util.Date var29 = var27.getTime();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var33.next();
//     java.util.Date var40 = var33.getTime();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var41);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day(var41);
//     org.jfree.data.time.SerialDate var44 = var30.getEndOfCurrentMonth(var41);
//     org.jfree.data.time.SerialDate var45 = var24.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addYears(1969, var24);
//     java.lang.String var47 = var46.toString();
//     org.jfree.data.time.SerialDate var48 = var2.getEndOfCurrentMonth(var46);
//     var2.setDescription("Wednesday");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-25544), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "31-December-3938"+ "'", var47.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test180"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     var14.setDescription("");
//     var14.setDescription("Time");
//     boolean var19 = var10.equals((java.lang.Object)var14);
//     int var20 = var10.getMonth();
//     long var21 = var10.getLastMillisecond();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     long var23 = var22.getFirstMillisecond();
//     org.jfree.data.time.Year var24 = var22.getYear();
//     long var25 = var22.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var26 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var10, (org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var28 = var27.getEnd();
//     java.util.Calendar var29 = null;
//     long var30 = var27.getLastMillisecond(var29);
//     java.util.Calendar var31 = null;
//     long var32 = var27.getLastMillisecond(var31);
//     org.jfree.data.time.RegularTimePeriod var33 = var27.next();
//     var26.delete((org.jfree.data.time.RegularTimePeriod)var27);
//     java.util.Date var35 = var27.getStart();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1419153286452L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1419153286452L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test181"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     int var11 = var9.getMonth();
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9);
//     java.util.Calendar var13 = null;
//     var9.peg(var13);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test182"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test183"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    java.lang.Class var15 = var8.getTimePeriodClass();
    var8.setMaximumItemAge(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test184"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     java.util.Collection var40 = var2.getTimePeriodsUniqueToOtherSeries(var34);
//     java.util.Collection var41 = org.jfree.chart.util.ObjectUtilities.deepClone(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test185"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, (-25544), (-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test186"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var6);
//     var7.setDescription("");
//     var7.setDescription("Time");
//     boolean var12 = var3.equals((java.lang.Object)var7);
//     int var13 = var3.getMonth();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
//     boolean var17 = var3.equals((java.lang.Object)var15);
//     boolean var18 = var0.equals((java.lang.Object)var15);
//     java.util.Calendar var19 = null;
//     var0.peg(var19);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test187"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.delete((-457), (-25544));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test188"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    org.jfree.data.time.RegularTimePeriod var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.update(var15, (java.lang.Number)24180L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test189"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     java.lang.Comparable var11 = var2.getKey();
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.previous();
//     java.lang.String var14 = var12.toString();
//     org.jfree.data.time.RegularTimePeriod var15 = var12.next();
//     var2.setKey((java.lang.Comparable)var12);
//     long var17 = var12.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 100.0f+ "'", var11.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "Sun Dec 21 01:14:46 PST 2014"+ "'", var14.equals("Sun Dec 21 01:14:46 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419153286553L);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test190"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)31);
    java.lang.Comparable var2 = var1.getKey();
    var1.removeAgedItems(1419191999999L, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 31+ "'", var2.equals(31));

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test191"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     int var33 = var2.toSerial();
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var39 = var38.next();
//     long var40 = var38.getLastMillisecond();
//     org.jfree.data.time.SerialDate var41 = var38.getSerialDate();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths(0, var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addYears(1, var41);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var46 = var45.next();
//     long var47 = var45.getLastMillisecond();
//     org.jfree.data.time.SerialDate var48 = var45.getSerialDate();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addMonths(0, var48);
//     org.jfree.data.time.SerialDate var51 = var49.getPreviousDayOfWeek(4);
//     boolean var52 = var35.isInRange(var41, var49);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     long var56 = var54.getLastMillisecond();
//     org.jfree.data.time.SerialDate var57 = var54.getSerialDate();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addMonths(0, var57);
//     org.jfree.data.time.SerialDate var60 = var58.getPreviousDayOfWeek(4);
//     java.lang.String var61 = var60.toString();
//     java.lang.String var62 = var60.toString();
//     org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var65 = var35.isInRange(var60, (org.jfree.data.time.SerialDate)var64);
//     org.jfree.data.time.FixedMillisecond var68 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var69 = var68.getFirstMillisecond();
//     java.util.Calendar var70 = null;
//     long var71 = var68.getMiddleMillisecond(var70);
//     java.util.Calendar var72 = null;
//     long var73 = var68.getFirstMillisecond(var72);
//     org.jfree.data.time.RegularTimePeriod var74 = var68.next();
//     java.util.Date var75 = var68.getTime();
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.createInstance(var75);
//     org.jfree.data.time.SerialDate var77 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var76);
//     int var78 = var35.compare(var77);
//     org.jfree.data.time.Day var80 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var81 = var80.next();
//     long var82 = var80.getLastMillisecond();
//     org.jfree.data.time.SerialDate var83 = var80.getSerialDate();
//     org.jfree.data.time.SerialDate var84 = org.jfree.data.time.SerialDate.addMonths(0, var83);
//     var83.setDescription("Sun Dec 21 01:14:30 PST 2014");
//     boolean var87 = var2.isInRange((org.jfree.data.time.SerialDate)var35, var83);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1969, var83);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "17-December-2014"+ "'", var61.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "17-December-2014"+ "'", var62.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == (-25544));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == true);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test192"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     java.lang.String var15 = var14.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test193"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getSerialIndex();
//     java.util.Date var24 = var22.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(0, var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(31, var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var36 = var35.getFirstMillisecond();
//     java.util.Calendar var37 = null;
//     long var38 = var35.getMiddleMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var35.getFirstMillisecond(var39);
//     org.jfree.data.time.RegularTimePeriod var41 = var35.next();
//     java.util.Date var42 = var35.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day(var43);
//     org.jfree.data.time.SerialDate var46 = var32.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var47 = var26.getEndOfCurrentMonth(var46);
//     boolean var48 = var1.isOn(var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var50 = var26.getNearestDayOfWeek(31);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test194"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: ThreadContext");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test195"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     var23.setMaximumItemCount(1);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     var28.setDescription("");
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var33 = null;
//     long var34 = var32.getLastMillisecond(var33);
//     org.jfree.data.time.TimeSeriesDataItem var36 = var28.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var32, 0.0d);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var38 = var37.next();
//     long var39 = var37.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var40 = var37.next();
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     long var44 = var42.getLastMillisecond();
//     org.jfree.data.time.SerialDate var45 = var42.getSerialDate();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var45);
//     java.lang.Class var47 = null;
//     org.jfree.data.time.TimeSeries var48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var45, var47);
//     boolean var49 = var37.equals((java.lang.Object)var47);
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var52 = var51.getFirstMillisecond();
//     java.util.Calendar var53 = null;
//     long var54 = var51.getMiddleMillisecond(var53);
//     java.util.Calendar var55 = null;
//     long var56 = var51.getFirstMillisecond(var55);
//     org.jfree.data.time.RegularTimePeriod var57 = var51.next();
//     java.util.Date var58 = var51.getTime();
//     org.jfree.data.time.Month var59 = new org.jfree.data.time.Month(var58);
//     int var60 = var59.getYearValue();
//     java.util.Date var61 = var59.getStart();
//     int var62 = var59.getYearValue();
//     boolean var63 = var37.equals((java.lang.Object)var59);
//     org.jfree.data.time.TimeSeriesDataItem var64 = var28.getDataItem((org.jfree.data.time.RegularTimePeriod)var59);
//     var23.add(var64, false);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test196"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(1, (-457));
//     java.lang.String var7 = var6.toString();
//     long var8 = var6.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)(-1));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "January -457"+ "'", var7.equals("January -457"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-62150212800001L));
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test197"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var8);
//     java.lang.String var12 = var11.toString();
//     java.util.Calendar var13 = null;
//     long var14 = var11.getFirstMillisecond(var13);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test198"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     var17.setDescription("");
//     var17.setDescription("Time");
//     boolean var22 = var13.equals((java.lang.Object)var17);
//     long var23 = var13.getSerialIndex();
//     long var24 = var13.getSerialIndex();
//     org.jfree.data.time.TimeSeries var25 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, (org.jfree.data.time.RegularTimePeriod)var13);
//     java.util.Calendar var26 = null;
//     long var27 = var13.getLastMillisecond(var26);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test199"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Nearest");

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test200"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.next();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     long var18 = var16.getLastMillisecond();
//     org.jfree.data.time.SerialDate var19 = var16.getSerialDate();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var19);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var19, var21);
//     boolean var23 = var11.equals((java.lang.Object)var21);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var26 = var25.getFirstMillisecond();
//     java.util.Calendar var27 = null;
//     long var28 = var25.getMiddleMillisecond(var27);
//     java.util.Calendar var29 = null;
//     long var30 = var25.getFirstMillisecond(var29);
//     org.jfree.data.time.RegularTimePeriod var31 = var25.next();
//     java.util.Date var32 = var25.getTime();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var32);
//     int var34 = var33.getYearValue();
//     java.util.Date var35 = var33.getStart();
//     int var36 = var33.getYearValue();
//     boolean var37 = var11.equals((java.lang.Object)var33);
//     org.jfree.data.time.TimeSeriesDataItem var38 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.FixedMillisecond var40 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var41 = null;
//     long var42 = var40.getLastMillisecond(var41);
//     java.lang.String var43 = var40.toString();
//     long var44 = var40.getFirstMillisecond();
//     boolean var45 = var38.equals((java.lang.Object)var40);
//     java.lang.Number var46 = var38.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var43.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + 0.0d+ "'", var46.equals(0.0d));
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test201"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     org.jfree.data.time.SerialDate var13 = var11.getSerialDate();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.previous();
//     java.util.Calendar var15 = null;
//     long var16 = var11.getLastMillisecond(var15);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test202"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sun Dec 21 01:14:31 PST 2014", var1);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test203"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     org.jfree.data.general.SeriesChangeEvent var23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     java.util.List var31 = var26.getItems();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var33.getMiddleMillisecond(var39);
//     org.jfree.data.time.TimeSeriesDataItem var42 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var43 = var33.previous();
//     org.jfree.data.time.TimeSeries var44 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var22, var43);
//     var44.fireSeriesChanged();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var46, (java.lang.Number)100);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     int var51 = var49.compareTo((java.lang.Object)var50);
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     long var55 = var54.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var56 = null;
//     var54.addChangeListener(var56);
//     var54.fireSeriesChanged();
//     int var59 = var49.compareTo((java.lang.Object)var54);
//     org.jfree.data.time.TimeSeries var60 = var44.addAndOrUpdate(var54);
//     var44.fireSeriesChanged();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test204"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test205"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: ");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test206"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     var17.setDescription("");
//     var17.setDescription("Time");
//     boolean var22 = var13.equals((java.lang.Object)var17);
//     long var23 = var13.getSerialIndex();
//     long var24 = var13.getSerialIndex();
//     org.jfree.data.time.TimeSeries var25 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, (org.jfree.data.time.RegularTimePeriod)var13);
//     var2.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test207"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=2014]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test208"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("31-December-3938", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test209"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getSerialIndex();
//     java.util.Date var24 = var22.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(0, var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(31, var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var36 = var35.getFirstMillisecond();
//     java.util.Calendar var37 = null;
//     long var38 = var35.getMiddleMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var35.getFirstMillisecond(var39);
//     org.jfree.data.time.RegularTimePeriod var41 = var35.next();
//     java.util.Date var42 = var35.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day(var43);
//     org.jfree.data.time.SerialDate var46 = var32.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var47 = var26.getEndOfCurrentMonth(var46);
//     boolean var48 = var1.isOn(var26);
//     int var49 = var1.getMonth();
//     var1.setDescription("December 1969");
//     org.jfree.data.time.FixedMillisecond var53 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var54 = var53.getFirstMillisecond();
//     boolean var55 = var1.equals((java.lang.Object)var53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var57 = var1.compareTo((java.lang.Object)(-76589164800000L));
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test210"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-452));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test211"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.String var12 = var10.toString();
//     org.jfree.data.time.RegularTimePeriod var13 = var10.previous();
//     org.jfree.data.time.RegularTimePeriod var14 = var10.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "December 1969"+ "'", var12.equals("December 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test212"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test213"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test214"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     boolean var33 = var32.getNotify();
//     boolean var35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)true);
//     var32.clear();
//     boolean var37 = var32.getNotify();
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     org.jfree.data.general.SeriesChangeListener var40 = null;
//     var32.addChangeListener(var40);
//     java.util.List var42 = var32.getItems();
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     java.lang.String var44 = var43.toString();
//     org.jfree.data.time.RegularTimePeriod var45 = var43.previous();
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     var50.setDescription("");
//     var50.setDescription("Time");
//     boolean var55 = var46.equals((java.lang.Object)var50);
//     int var56 = var46.getMonth();
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var58);
//     boolean var60 = var46.equals((java.lang.Object)var58);
//     boolean var61 = var43.equals((java.lang.Object)var58);
//     int var62 = var32.getIndex((org.jfree.data.time.RegularTimePeriod)var43);
//     java.util.Collection var63 = var2.getTimePeriodsUniqueToOtherSeries(var32);
//     java.lang.Class var64 = var32.getTimePeriodClass();
//     java.beans.PropertyChangeListener var65 = null;
//     var32.addPropertyChangeListener(var65);
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var68 = var67.next();
//     org.jfree.data.time.TimeSeriesDataItem var70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var67, (java.lang.Number)100);
//     org.jfree.data.time.Year var71 = new org.jfree.data.time.Year();
//     int var72 = var70.compareTo((java.lang.Object)var71);
//     java.lang.Class var74 = null;
//     org.jfree.data.time.TimeSeries var75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var74);
//     long var76 = var75.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var77 = null;
//     var75.addChangeListener(var77);
//     var75.fireSeriesChanged();
//     int var80 = var70.compareTo((java.lang.Object)var75);
//     var32.add(var70, true);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test215"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)1419153269727L);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var10);
//     java.lang.Object var12 = var7.clone();
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     var17.setDescription("");
//     var17.setDescription("Time");
//     boolean var22 = var13.equals((java.lang.Object)var17);
//     int var23 = var13.getYear();
//     long var24 = var13.getSerialIndex();
//     int var25 = var7.compareTo((java.lang.Object)var13);
//     java.util.Calendar var26 = null;
//     long var27 = var13.getLastMillisecond(var26);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test216"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test217"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var2 = var1.toDate();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2, var3);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test218"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-459), (-41973), (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test219"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
    org.jfree.data.time.RegularTimePeriod var2 = var1.next();
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
    var5.setDescription("");
    var5.setDescription("Time");
    boolean var10 = var1.equals((java.lang.Object)var5);
    org.jfree.data.time.RegularTimePeriod var11 = var1.previous();
    java.util.Date var12 = var1.getStart();
    java.util.TimeZone var13 = null;
    org.jfree.data.time.RegularTimePeriod var14 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var12, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test220"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getSerialIndex();
    java.util.Date var4 = var2.getTime();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    long var9 = var8.getFirstMillisecond();
    java.util.Calendar var10 = null;
    long var11 = var8.getMiddleMillisecond(var10);
    java.util.Calendar var12 = null;
    long var13 = var8.getFirstMillisecond(var12);
    org.jfree.data.time.RegularTimePeriod var14 = var8.next();
    java.util.Date var15 = var8.getTime();
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var16);
    org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var16);
    org.jfree.data.time.SerialDate var19 = var5.getEndOfCurrentMonth(var16);
    org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test221"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     long var10 = var0.getSerialIndex();
//     long var11 = var0.getSerialIndex();
//     long var12 = var0.getSerialIndex();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     java.lang.String var14 = var13.toString();
//     long var15 = var13.getFirstMillisecond();
//     int var16 = var13.getYear();
//     int var17 = var0.compareTo((java.lang.Object)var16);
//     java.lang.String var18 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "2014"+ "'", var14.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "21-December-2014"+ "'", var18.equals("21-December-2014"));
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test222"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getFirstMillisecond();
    java.util.Calendar var5 = null;
    long var6 = var3.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var3.getFirstMillisecond(var7);
    org.jfree.data.time.RegularTimePeriod var9 = var3.next();
    java.util.Date var10 = var3.getTime();
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var11);
    org.jfree.data.time.Day var13 = new org.jfree.data.time.Day(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test223"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.time.TimePeriodFormatException: 20-January-1900");

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test224"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.String var4 = var1.toString();
//     long var5 = var1.getFirstMillisecond();
//     java.util.Date var6 = var1.getStart();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var10 = var8.getDataItem((-571));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var4.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test225"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     long var2 = var0.getSerialIndex();
//     long var3 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419153287945L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419153287945L);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test226"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     var3.setKey((java.lang.Comparable)1417420800000L);
//     java.lang.String var6 = var3.getDomainDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var9 = var3.createCopy(4, (-570));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "Time"+ "'", var6.equals("Time"));
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test227"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=1419148800000]", var1);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test228"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     var3.setKey((java.lang.Comparable)1417420800000L);
//     java.lang.String var6 = var3.getDomainDescription();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     long var8 = var7.getMiddleMillisecond();
//     long var9 = var7.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.add((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-41973), false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "Time"+ "'", var6.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419153288290L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419153288290L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test229"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
//     int var21 = var20.getYearValue();
//     long var22 = var20.getLastMillisecond();
//     long var23 = var20.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, 0.0d);
//     java.util.Calendar var26 = null;
//     long var27 = var20.getFirstMillisecond(var26);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test230"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, (-460), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test231"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.String var4 = var1.toString();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Date var13 = var6.getTime();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var13);
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     boolean var17 = var1.equals((java.lang.Object)var16);
//     long var18 = var1.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var4.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-452), 1, 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test233"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-570));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test234"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Fourth");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test235"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var2 = var1.toDate();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var8 = var7.getSerialIndex();
//     java.util.Date var9 = var7.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(31, var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(31, var11);
//     boolean var14 = var1.isOnOrAfter(var13);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var17 = var16.getSerialIndex();
//     java.util.Date var18 = var16.getTime();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getFirstMillisecond();
//     java.util.Calendar var24 = null;
//     long var25 = var22.getMiddleMillisecond(var24);
//     java.util.Calendar var26 = null;
//     long var27 = var22.getFirstMillisecond(var26);
//     org.jfree.data.time.RegularTimePeriod var28 = var22.next();
//     java.util.Date var29 = var22.getTime();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var30);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var30);
//     org.jfree.data.time.SerialDate var33 = var19.getEndOfCurrentMonth(var30);
//     boolean var34 = var1.isOn(var30);
//     int var35 = var1.getMonth();
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var38 = var37.next();
//     long var39 = var37.getLastMillisecond();
//     org.jfree.data.time.SerialDate var40 = var37.getSerialDate();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var40);
//     int var42 = var1.compare(var40);
//     java.lang.Object var43 = null;
//     int var44 = var1.compareTo(var43);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test236"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     int var4 = var0.getYearValue();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getFirstMillisecond(var5);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test237"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     long var8 = var6.getMiddleMillisecond();
//     long var9 = var6.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419153288786L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419153288786L);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test238"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3);
//     org.jfree.data.time.TimeSeries var7 = var4.createCopy(100, 100);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var9 = var8.next();
//     long var10 = var8.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var8.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 0.0d);
//     int var14 = var8.getYear();
//     java.lang.Number var15 = var4.getValue((org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     long var17 = var16.getFirstMillisecond();
//     org.jfree.data.time.Year var18 = var16.getYear();
//     org.jfree.data.time.Year var19 = var16.getYear();
//     java.lang.Object var20 = null;
//     boolean var21 = var16.equals(var20);
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1419153269727L);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var23, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var26);
//     java.lang.Object var28 = var23.clone();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.add(var23);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test239"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var0.previous();
//     org.jfree.data.time.SerialDate var14 = var0.getSerialDate();
//     java.lang.String var15 = var0.toString();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "org.jfree.data.general.SeriesChangeEvent[source=false]", "October", var18);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getFirstMillisecond();
//     long var23 = var21.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var26 = var25.getPeriod();
//     java.lang.Object var27 = var25.clone();
//     java.lang.Object var28 = var25.clone();
//     var19.add(var25);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test240"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test241"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     long var2 = var0.getLastMillisecond();
//     boolean var4 = var0.equals((java.lang.Object)12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test242"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test243"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
    var1.addSuppressed((java.lang.Throwable)var3);
    java.lang.String var5 = var1.toString();
    java.lang.Throwable[] var6 = var1.getSuppressed();
    java.lang.Throwable[] var7 = var1.getSuppressed();
    java.lang.String var8 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var5.equals("org.jfree.data.general.SeriesException: ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var8.equals("org.jfree.data.general.SeriesException: ThreadContext"));

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test244"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.String var12 = var10.toString();
//     java.lang.String var13 = var10.toString();
//     java.util.Calendar var14 = null;
//     long var15 = var10.getLastMillisecond(var14);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test245"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    var2.clear();
    var2.fireSeriesChanged();

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test246"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sun Dec 21 01:14:44 PST 2014");

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test247"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     java.lang.String var4 = var2.getRangeDescription();
//     java.util.Collection var5 = var2.getTimePeriods();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var8 = var7.getFirstMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var7.getMiddleMillisecond(var9);
//     java.util.Calendar var11 = null;
//     long var12 = var7.getFirstMillisecond(var11);
//     org.jfree.data.time.RegularTimePeriod var13 = var7.next();
//     java.util.Date var14 = var7.getTime();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     int var16 = var15.getYearValue();
//     java.util.Date var17 = var15.getStart();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     long var19 = var18.getMiddleMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)7);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test248"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test249"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test250"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     boolean var6 = var2.isEmpty();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     var11.setDescription("");
//     var11.setDescription("Time");
//     boolean var16 = var7.equals((java.lang.Object)var11);
//     int var17 = var7.getMonth();
//     long var18 = var7.getFirstMillisecond();
//     long var19 = var7.getFirstMillisecond();
//     int var20 = var7.getYear();
//     long var21 = var7.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var22 = var7.next();
//     var2.add(var22, (java.lang.Number)10L, false);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test251"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Sun Dec 21 01:14:39 PST 2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test252"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    java.lang.Class var15 = var8.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var17 = var8.getValue(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test253"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     boolean var9 = var2.equals((java.lang.Object)1.0d);
//     var2.setRangeDescription("");
//     java.lang.String var12 = var2.getRangeDescription();
//     var2.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var17 = var16.getSerialIndex();
//     java.util.Date var18 = var16.getTime();
//     java.util.Date var19 = var16.getTime();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (-1.0d));
//     var2.add(var22);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test254"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    var2.setNotify(false);
    java.lang.String var12 = var2.getDomainDescription();
    java.lang.String var13 = var2.getDomainDescription();
    java.util.Collection var14 = var2.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var15 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Time"+ "'", var12.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Time"+ "'", var13.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test255"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
//     long var13 = var12.getMiddleMillisecond();
//     boolean var15 = var12.equals((java.lang.Object)100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1310400001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test256"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test257"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
    java.util.TimeZone var11 = null;
    org.jfree.data.time.RegularTimePeriod var12 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var9, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test258"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test259"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var9);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var9);
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.RegularTimePeriod var14 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var9, var13);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var9);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day(var9);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year(var9);
//     java.util.Calendar var18 = null;
//     long var19 = var17.getLastMillisecond(var18);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test260"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var11);
//     int var13 = var12.getItemCount();
//     var12.setNotify(false);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var17);
//     long var19 = var18.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var20 = var12.addAndOrUpdate(var18);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var24);
//     var25.setDescription("");
//     var25.setDescription("Time");
//     boolean var30 = var21.equals((java.lang.Object)var25);
//     int var31 = var21.getMonth();
//     long var32 = var21.getFirstMillisecond();
//     long var33 = var21.getFirstMillisecond();
//     long var34 = var21.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var20.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)1419153275639L);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var21, 0.0d, true);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test261"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = var10.getYear();
//     org.jfree.data.time.Year var13 = var10.getYear();
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     boolean var18 = var17.getNotify();
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)true);
//     var17.clear();
//     boolean var22 = var17.getNotify();
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var24);
//     boolean var26 = var25.getNotify();
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var25, (java.lang.Object)true);
//     var25.clear();
//     java.util.Collection var30 = var17.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.TimeSeries var33 = var25.createCopy(10, 10);
//     boolean var34 = var0.equals((java.lang.Object)var25);
//     org.jfree.data.time.RegularTimePeriod var35 = var0.next();
//     int var36 = var0.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 21);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test262"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var7 = var4.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
//     boolean var10 = var2.equals((java.lang.Object)var9);
//     org.jfree.data.time.RegularTimePeriod var11 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.getIndex(var11);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test263"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.time.TimeSeries var18 = var10.createCopy(10, 10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var21 = var19.previous();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)100);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)var27);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var30);
//     long var32 = var31.getMaximumItemAge();
//     int var33 = var26.compareTo((java.lang.Object)var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     boolean var35 = var26.equals((java.lang.Object)var34);
//     org.jfree.data.time.TimeSeries var36 = var18.createCopy((org.jfree.data.time.RegularTimePeriod)var22, (org.jfree.data.time.RegularTimePeriod)var34);
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var38 = null;
//     long var39 = var37.getLastMillisecond(var38);
//     long var40 = var37.getMiddleMillisecond();
//     java.util.Date var41 = var37.getTime();
//     long var42 = var37.getMiddleMillisecond();
//     var18.add((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)1419153279942L);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test264"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.lang.Object var3 = null;
//     boolean var4 = var2.equals(var3);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getSerialIndex();
//     java.util.Date var8 = var6.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day(var20);
//     org.jfree.data.time.SerialDate var23 = var9.getEndOfCurrentMonth(var20);
//     int var24 = var2.compareTo((java.lang.Object)var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test265"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(21, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test266"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getLastMillisecond();
//     long var21 = var19.getLastMillisecond();
//     long var22 = var19.getLastMillisecond();
//     java.lang.String var23 = var19.toString();
//     int var24 = var19.getMonth();
//     int var25 = var9.compareTo((java.lang.Object)var19);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9, "SerialDate.weekInMonthToString(): invalid code.", "December 2014", var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     int var40 = var30.getMonth();
//     long var41 = var30.getFirstMillisecond();
//     long var42 = var30.getFirstMillisecond();
//     int var43 = var30.getYear();
//     long var44 = var30.getLastMillisecond();
//     var29.delete((org.jfree.data.time.RegularTimePeriod)var30);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var47 = var46.getEnd();
//     java.util.Calendar var48 = null;
//     long var49 = var46.getLastMillisecond(var48);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var29.update((org.jfree.data.time.RegularTimePeriod)var46, (java.lang.Number)1419153271073L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "21-December-2014"+ "'", var23.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419153289394L);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test267"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test268"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     var17.setDescription("");
//     var17.setDescription("Time");
//     boolean var22 = var13.equals((java.lang.Object)var17);
//     long var23 = var13.getSerialIndex();
//     long var24 = var13.getSerialIndex();
//     org.jfree.data.time.TimeSeries var25 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, (org.jfree.data.time.RegularTimePeriod)var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var28 = var2.createCopy((-452), 2014);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test269"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.previous();
//     java.lang.String var21 = var19.toString();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     long var29 = var27.getLastMillisecond();
//     org.jfree.data.time.SerialDate var30 = var27.getSerialDate();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addMonths(0, var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(1, var30);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getLastMillisecond();
//     org.jfree.data.time.SerialDate var37 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addMonths(0, var37);
//     org.jfree.data.time.SerialDate var40 = var38.getPreviousDayOfWeek(4);
//     boolean var41 = var24.isInRange(var30, var38);
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, (java.lang.Number)100);
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     int var47 = var45.compareTo((java.lang.Object)var46);
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     long var51 = var50.getMaximumItemAge();
//     int var52 = var45.compareTo((java.lang.Object)var50);
//     boolean var53 = var24.equals((java.lang.Object)var50);
//     int var54 = var24.getMonth();
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var56 = var55.next();
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var58);
//     var59.setDescription("");
//     var59.setDescription("Time");
//     boolean var64 = var55.equals((java.lang.Object)var59);
//     int var65 = var55.getMonth();
//     long var66 = var55.getFirstMillisecond();
//     long var67 = var55.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var68 = var55.getSerialDate();
//     boolean var69 = var24.isBefore(var68);
//     org.jfree.data.time.FixedMillisecond var72 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var73 = var72.getSerialIndex();
//     java.util.Date var74 = var72.getTime();
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(var74);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.addYears(0, var75);
//     boolean var77 = var24.isOnOrBefore(var76);
//     java.util.Date var78 = var24.toDate();
//     int var79 = var19.compareTo((java.lang.Object)var24);
//     org.jfree.data.time.FixedMillisecond var82 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var83 = var82.getFirstMillisecond();
//     java.util.Calendar var84 = null;
//     long var85 = var82.getMiddleMillisecond(var84);
//     java.util.Calendar var86 = null;
//     long var87 = var82.getFirstMillisecond(var86);
//     org.jfree.data.time.RegularTimePeriod var88 = var82.next();
//     java.util.Date var89 = var82.getTime();
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.createInstance(var89);
//     org.jfree.data.time.SerialDate var91 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var90);
//     org.jfree.data.time.Day var92 = new org.jfree.data.time.Day(var90);
//     boolean var93 = var1.isInRange((org.jfree.data.time.SerialDate)var24, var90);
//     org.jfree.data.general.SeriesChangeEvent var94 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Sun Dec 21 01:14:49 PST 2014"+ "'", var21.equals("Sun Dec 21 01:14:49 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == true);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test270"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getFirstMillisecond();
    java.util.Calendar var6 = null;
    long var7 = var4.getMiddleMillisecond(var6);
    java.util.Calendar var8 = null;
    long var9 = var4.getFirstMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var4.next();
    java.util.Date var11 = var4.getTime();
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
    boolean var14 = var1.isAfter(var13);
    java.lang.String var15 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "20-January-1900"+ "'", var15.equals("20-January-1900"));

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test271"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getLastMillisecond();
//     long var21 = var19.getLastMillisecond();
//     long var22 = var19.getLastMillisecond();
//     java.lang.String var23 = var19.toString();
//     int var24 = var19.getMonth();
//     int var25 = var9.compareTo((java.lang.Object)var19);
//     long var26 = var19.getFirstMillisecond();
//     java.util.Calendar var27 = null;
//     long var28 = var19.getFirstMillisecond(var27);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test272"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     long var5 = var3.getLastMillisecond();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, var6);
//     var7.setMaximumItemCount(0);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond((-1L));
//     java.util.Calendar var12 = null;
//     var11.peg(var12);
//     var7.add((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d), true);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test273"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     int var15 = var14.getItemCount();
//     var14.setDescription("");
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)100);
//     boolean var23 = var18.equals((java.lang.Object)(-571));
//     long var24 = var18.getSerialIndex();
//     int var25 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var18);
//     int var26 = var0.compareTo((java.lang.Object)var14);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     long var29 = var27.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 0.0d);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var35 = null;
//     long var36 = var34.getLastMillisecond(var35);
//     long var37 = var34.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, 1.0d);
//     long var40 = var34.getLastMillisecond();
//     java.util.Date var41 = var34.getStart();
//     int var42 = var32.compareTo((java.lang.Object)var34);
//     var14.add(var32);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test274"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var2.removeChangeListener(var30);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var33.next();
//     java.util.Date var40 = var33.getTime();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(var40);
//     long var42 = var41.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var43 = var41.next();
//     org.jfree.data.time.RegularTimePeriod var44 = var41.previous();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.Year var46 = var41.getYear();
//     java.lang.Class var47 = null;
//     org.jfree.data.time.TimeSeries var48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var41, var47);
//     org.jfree.data.time.Year var49 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var50 = var49.next();
//     long var51 = var49.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var52 = var49.next();
//     org.jfree.data.time.TimeSeriesDataItem var54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 0.0d);
//     org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var57 = null;
//     long var58 = var56.getLastMillisecond(var57);
//     long var59 = var56.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var56, 1.0d);
//     long var62 = var56.getLastMillisecond();
//     java.util.Date var63 = var56.getStart();
//     int var64 = var54.compareTo((java.lang.Object)var56);
//     java.lang.Object var65 = var54.clone();
//     var48.add(var54);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test275"); }


    org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "17-December-2014", "Wed Dec 31 16:00:00 PST 1969", var3);
    org.jfree.data.time.TimeSeries var7 = var4.createCopy(0, 13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.update(13, (java.lang.Number)1419153271281L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test276"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(21, (-459), (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test277"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-571));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-598));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test278"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
    long var7 = var1.getLastMillisecond();
    java.util.Date var8 = var1.getStart();
    org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (-1.0d));
    org.jfree.data.time.RegularTimePeriod var11 = var10.getPeriod();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test279"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Jan");

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test280"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     int var5 = var0.getMonth();
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test281"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var0.previous();
//     org.jfree.data.time.SerialDate var14 = var0.getSerialDate();
//     java.lang.String var15 = var0.toString();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "org.jfree.data.general.SeriesChangeEvent[source=false]", "October", var18);
//     org.jfree.data.general.SeriesChangeEvent var20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "21-December-2014"+ "'", var15.equals("21-December-2014"));
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test282"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-458));

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test283"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)10);
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test284"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
    boolean var11 = var10.getNotify();
    var10.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
    var10.setMaximumItemAge(1417420800000L);
    org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
    org.jfree.data.time.RegularTimePeriod var19 = null;
    org.jfree.data.time.RegularTimePeriod var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var21 = var2.createCopy(var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test285"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getFirstMillisecond(var5);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test286"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", var1);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test287"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 01:14:34 PST 2014", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test288"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesException: ThreadContext", var1);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test289"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     java.util.Date var12 = var11.getEnd();
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(var12, var13);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test290"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test291"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Value");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test292"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     long var14 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var15 = var0.next();
//     java.util.Calendar var16 = null;
//     long var17 = var0.getLastMillisecond(var16);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test293"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     var2.setDomainDescription("org.jfree.data.general.SeriesException: ThreadContext");
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     boolean var12 = var11.getNotify();
//     var11.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var11.getDataItem((org.jfree.data.time.RegularTimePeriod)var15);
//     long var17 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var19 = var15.previous();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (-1.0d));
//     java.util.List var22 = var2.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var23 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var22);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419153290104L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test294"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     java.lang.String var2 = var0.toString();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getFirstMillisecond();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getMiddleMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var4.getFirstMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var4.next();
//     java.util.Date var11 = var4.getTime();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
//     int var13 = var12.getYearValue();
//     java.util.Date var14 = var12.getStart();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     org.jfree.data.time.Year var16 = var15.getYear();
//     int var17 = var0.compareTo((java.lang.Object)var15);
//     java.util.Calendar var18 = null;
//     long var19 = var15.getFirstMillisecond(var18);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test295"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     var2.setDescription("");
//     java.lang.Object var32 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var34 = var2.getTimePeriod(13);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test296"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test297"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("31-December-3938");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test298"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
//     int var21 = var20.getYearValue();
//     java.util.Date var22 = var20.getStart();
//     int var23 = var20.getYearValue();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.lang.String var26 = var20.toString();
//     long var27 = var20.getFirstMillisecond();
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var29);
//     var30.setDescription("");
//     java.lang.String var33 = var30.getDescription();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var35);
//     boolean var37 = var36.getNotify();
//     boolean var39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var36, (java.lang.Object)true);
//     java.lang.Comparable var40 = var36.getKey();
//     org.jfree.data.time.TimeSeries var41 = var30.addAndOrUpdate(var36);
//     boolean var42 = var36.getNotify();
//     java.lang.Class var44 = null;
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var44);
//     long var46 = var45.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var47 = null;
//     var45.addChangeListener(var47);
//     var45.fireSeriesChanged();
//     java.lang.String var50 = var45.getDescription();
//     java.util.Collection var51 = var45.getTimePeriods();
//     org.jfree.data.general.SeriesChangeListener var52 = null;
//     var45.addChangeListener(var52);
//     java.util.Collection var54 = var36.getTimePeriodsUniqueToOtherSeries(var45);
//     boolean var55 = var20.equals((java.lang.Object)var36);
//     org.jfree.data.time.RegularTimePeriod var56 = var20.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "December 1969"+ "'", var26.equals("December 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + ""+ "'", var33.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + 100.0f+ "'", var40.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test299"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    boolean var8 = var2.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test300"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     var2.setMaximumItemCount(12);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var17);
//     var18.setDescription("");
//     var18.setDescription("Time");
//     boolean var23 = var14.equals((java.lang.Object)var18);
//     int var24 = var14.getMonth();
//     long var25 = var14.getFirstMillisecond();
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     int var29 = var28.getItemCount();
//     var28.setDescription("");
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)100);
//     boolean var37 = var32.equals((java.lang.Object)(-571));
//     long var38 = var32.getSerialIndex();
//     int var39 = var28.getIndex((org.jfree.data.time.RegularTimePeriod)var32);
//     int var40 = var14.compareTo((java.lang.Object)var28);
//     java.util.Collection var41 = var2.getTimePeriodsUniqueToOtherSeries(var28);
//     java.util.Collection var42 = org.jfree.chart.util.ObjectUtilities.deepClone(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test301"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.String var4 = var1.toString();
//     long var5 = var1.getFirstMillisecond();
//     java.util.Date var6 = var1.getStart();
//     java.util.TimeZone var7 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var6, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var4.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test302"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-455));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test303"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.beans.PropertyChangeListener var7 = null;
//     var2.removePropertyChangeListener(var7);
//     java.util.List var9 = var2.getItems();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var11);
//     java.lang.String var13 = var12.getDomainDescription();
//     var12.clear();
//     var12.setMaximumItemAge(1419153269727L);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var20);
//     var21.setDescription("");
//     var21.setDescription("Time");
//     boolean var26 = var17.equals((java.lang.Object)var21);
//     int var27 = var17.getMonth();
//     long var28 = var17.getFirstMillisecond();
//     long var29 = var17.getFirstMillisecond();
//     int var30 = var17.getDayOfMonth();
//     java.lang.Number var31 = null;
//     org.jfree.data.time.TimeSeriesDataItem var32 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, var31);
//     long var33 = var17.getFirstMillisecond();
//     long var34 = var17.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var37 = null;
//     long var38 = var36.getLastMillisecond(var37);
//     long var39 = var36.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var36, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.next();
//     boolean var43 = var17.equals((java.lang.Object)var42);
//     var2.delete(var42);
//     var2.setMaximumItemCount(20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "Time"+ "'", var13.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test304"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.next();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(1, var1);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getMiddleMillisecond(var5);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test305"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getLastMillisecond();
//     long var12 = var10.getLastMillisecond();
//     long var13 = var10.getLastMillisecond();
//     java.lang.String var14 = var10.toString();
//     int var15 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     boolean var17 = var2.equals((java.lang.Object)28799999L);
//     var2.setMaximumItemAge(1419153274341L);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     org.jfree.data.general.SeriesChangeListener var27 = null;
//     var22.removeChangeListener(var27);
//     java.lang.Comparable var29 = var22.getKey();
//     long var30 = var22.getMaximumItemAge();
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var32);
//     long var34 = var33.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var35 = null;
//     var33.addChangeListener(var35);
//     var33.fireSeriesChanged();
//     java.lang.String var38 = var33.getDescription();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var40);
//     boolean var42 = var41.getNotify();
//     var41.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var46 = var41.getDataItem((org.jfree.data.time.RegularTimePeriod)var45);
//     var41.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var49 = var33.addAndOrUpdate(var41);
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     long var51 = var50.getFirstMillisecond();
//     org.jfree.data.time.Year var52 = var50.getYear();
//     org.jfree.data.time.Year var53 = var50.getYear();
//     org.jfree.data.general.SeriesChangeEvent var54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var53);
//     java.lang.Class var56 = null;
//     org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var56);
//     var57.setDescription("");
//     var57.setDescription("Time");
//     java.util.List var62 = var57.getItems();
//     org.jfree.data.time.FixedMillisecond var64 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var65 = var64.getFirstMillisecond();
//     java.util.Calendar var66 = null;
//     long var67 = var64.getMiddleMillisecond(var66);
//     java.util.Calendar var68 = null;
//     long var69 = var64.getFirstMillisecond(var68);
//     java.util.Calendar var70 = null;
//     long var71 = var64.getMiddleMillisecond(var70);
//     org.jfree.data.time.TimeSeriesDataItem var73 = var57.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var64, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var74 = var64.previous();
//     org.jfree.data.time.TimeSeries var75 = var41.createCopy((org.jfree.data.time.RegularTimePeriod)var53, var74);
//     org.jfree.data.time.TimeSeries var76 = var22.addAndOrUpdate(var41);
//     org.jfree.data.time.TimeSeries var77 = var2.addAndOrUpdate(var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var78 = var77.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "21-December-2014"+ "'", var14.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + 100.0f+ "'", var29.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test306"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(20, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test307"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     java.lang.String var2 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     org.jfree.data.general.SeriesException var5 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var7 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var5.addSuppressed((java.lang.Throwable)var7);
//     java.lang.String var9 = var7.toString();
//     java.lang.String var10 = var7.toString();
//     org.jfree.data.general.SeriesException var12 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var12.addSuppressed((java.lang.Throwable)var14);
//     org.jfree.data.general.SeriesException var17 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var19 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var17.addSuppressed((java.lang.Throwable)var19);
//     var14.addSuppressed((java.lang.Throwable)var17);
//     java.lang.Throwable[] var22 = var17.getSuppressed();
//     java.lang.String var23 = var17.toString();
//     var7.addSuppressed((java.lang.Throwable)var17);
//     org.jfree.data.general.SeriesException var26 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var28 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var26.addSuppressed((java.lang.Throwable)var28);
//     java.lang.String var30 = var28.toString();
//     java.lang.String var31 = var28.toString();
//     org.jfree.data.general.SeriesException var33 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var35 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var33.addSuppressed((java.lang.Throwable)var35);
//     org.jfree.data.general.SeriesException var38 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var40 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var38.addSuppressed((java.lang.Throwable)var40);
//     var35.addSuppressed((java.lang.Throwable)var38);
//     java.lang.Throwable[] var43 = var38.getSuppressed();
//     java.lang.String var44 = var38.toString();
//     var28.addSuppressed((java.lang.Throwable)var38);
//     var17.addSuppressed((java.lang.Throwable)var38);
//     int var47 = var0.compareTo((java.lang.Object)var17);
//     java.lang.Throwable[] var48 = var17.getSuppressed();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "December 2014"+ "'", var2.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var9.equals("org.jfree.data.general.SeriesException: ThreadContext"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var10.equals("org.jfree.data.general.SeriesException: ThreadContext"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var23.equals("org.jfree.data.general.SeriesException: ThreadContext"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var30.equals("org.jfree.data.general.SeriesException: ThreadContext"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var31.equals("org.jfree.data.general.SeriesException: ThreadContext"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var44.equals("org.jfree.data.general.SeriesException: ThreadContext"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test308"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getSerialIndex();
//     java.util.Date var7 = var5.getTime();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(31, var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(31, var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths((-25544), var11);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test309"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getYear();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var8);
//     var9.setDescription("");
//     var9.setDescription("Time");
//     boolean var14 = var5.equals((java.lang.Object)var9);
//     int var15 = var5.getMonth();
//     long var16 = var5.getFirstMillisecond();
//     long var17 = var5.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var18 = var5.getSerialDate();
//     boolean var19 = var0.equals((java.lang.Object)var5);
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test310"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Last"+ "'", var1.equals("Last"));

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test311"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     boolean var27 = var26.getNotify();
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, (java.lang.Object)true);
//     var26.clear();
//     boolean var31 = var26.getNotify();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     java.util.Collection var39 = var26.getTimePeriodsUniqueToOtherSeries(var34);
//     org.jfree.data.general.SeriesChangeListener var40 = null;
//     var26.removeChangeListener(var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     java.lang.Class var45 = null;
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var45);
//     var46.setDescription("");
//     var46.setDescription("Time");
//     boolean var51 = var42.equals((java.lang.Object)var46);
//     int var52 = var42.getMonth();
//     var26.setKey((java.lang.Comparable)var52);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     java.lang.Class var57 = null;
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var57);
//     var58.setDescription("");
//     var58.setDescription("Time");
//     boolean var63 = var54.equals((java.lang.Object)var58);
//     java.util.Collection var64 = var26.getTimePeriodsUniqueToOtherSeries(var58);
//     org.jfree.data.general.SeriesChangeEvent var65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var26);
//     org.jfree.data.time.TimeSeries var66 = var23.addAndOrUpdate(var26);
//     org.jfree.data.time.Day var67 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var68 = var67.next();
//     java.lang.Class var70 = null;
//     org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var70);
//     var71.setDescription("");
//     var71.setDescription("Time");
//     boolean var76 = var67.equals((java.lang.Object)var71);
//     int var77 = var67.getMonth();
//     long var78 = var67.getFirstMillisecond();
//     long var79 = var67.getFirstMillisecond();
//     long var80 = var67.getSerialIndex();
//     java.lang.Object var81 = null;
//     int var82 = var67.compareTo(var81);
//     var26.setKey((java.lang.Comparable)var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 1);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test312"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     var2.setMaximumItemCount(12);
//     var2.setDescription("21-December-2014");
//     java.util.Collection var16 = var2.getTimePeriods();
//     org.jfree.data.general.SeriesChangeListener var17 = null;
//     var2.removeChangeListener(var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     java.lang.Class var22 = null;
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var22);
//     var23.setDescription("");
//     var23.setDescription("Time");
//     boolean var28 = var19.equals((java.lang.Object)var23);
//     long var29 = var19.getSerialIndex();
//     java.lang.String var30 = var19.toString();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var19);
//     java.util.Calendar var32 = null;
//     long var33 = var19.getLastMillisecond(var32);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test313"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     var2.setMaximumItemAge(28799999L);
//     var2.setRangeDescription("ThreadContext");
//     java.lang.String var11 = var2.getDescription();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     long var13 = var12.getFirstMillisecond();
//     org.jfree.data.time.Year var14 = var12.getYear();
//     org.jfree.data.time.Year var15 = var12.getYear();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var18 = var17.getFirstMillisecond();
//     java.util.Calendar var19 = null;
//     long var20 = var17.getMiddleMillisecond(var19);
//     java.util.Calendar var21 = null;
//     long var22 = var17.getFirstMillisecond(var21);
//     org.jfree.data.time.RegularTimePeriod var23 = var17.next();
//     java.util.Date var24 = var17.getTime();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(var24);
//     long var26 = var25.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var27 = var25.next();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 100.0d);
//     org.jfree.data.time.RegularTimePeriod var30 = var25.previous();
//     java.util.Date var31 = var30.getStart();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var32 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, var30);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test314"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var7 = null;
    long var8 = var6.getLastMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
    java.lang.String var11 = var2.getDescription();
    java.lang.String var12 = var2.getDescription();
    long var13 = var2.getMaximumItemAge();
    boolean var14 = var2.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test315"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
    var1.addSuppressed((java.lang.Throwable)var3);
    java.lang.String var5 = var1.toString();
    org.jfree.data.time.TimePeriodFormatException var7 = new org.jfree.data.time.TimePeriodFormatException("17-December-2014");
    var1.addSuppressed((java.lang.Throwable)var7);
    java.lang.String var9 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var5.equals("org.jfree.data.general.SeriesException: ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 17-December-2014"+ "'", var9.equals("org.jfree.data.time.TimePeriodFormatException: 17-December-2014"));

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test316"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test317"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
//     int var21 = var20.getYearValue();
//     java.util.Date var22 = var20.getStart();
//     int var23 = var20.getYearValue();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.lang.String var26 = var20.toString();
//     java.lang.String var27 = var20.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "December 1969"+ "'", var26.equals("December 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "December 1969"+ "'", var27.equals("December 1969"));
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test318"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-455));

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test319"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-605));

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test320"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sun Dec 21 01:14:46 PST 2014", var1);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test321"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = var10.getYear();
//     org.jfree.data.time.Year var13 = var10.getYear();
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     boolean var18 = var17.getNotify();
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)true);
//     var17.clear();
//     boolean var22 = var17.getNotify();
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var24);
//     boolean var26 = var25.getNotify();
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var25, (java.lang.Object)true);
//     var25.clear();
//     java.util.Collection var30 = var17.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.TimeSeries var33 = var25.createCopy(10, 10);
//     boolean var34 = var0.equals((java.lang.Object)var25);
//     org.jfree.data.time.RegularTimePeriod var35 = var0.next();
//     org.jfree.data.time.SerialDate var36 = var0.getSerialDate();
//     org.jfree.data.time.SerialDate var37 = var0.getSerialDate();
//     int var39 = var0.compareTo((java.lang.Object)"Wednesday");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test322"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     boolean var11 = var2.isEmpty();
//     long var12 = var2.getMaximumItemAge();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var14);
//     var15.setDescription("");
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     long var19 = var18.getLastMillisecond();
//     long var20 = var18.getLastMillisecond();
//     int var21 = var18.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var18.next();
//     java.lang.String var23 = var18.toString();
//     var15.setKey((java.lang.Comparable)var18);
//     org.jfree.data.general.SeriesChangeEvent var25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var18);
//     org.jfree.data.time.RegularTimePeriod var26 = var18.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update(var26, (java.lang.Number)(short)(-1));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "21-December-2014"+ "'", var23.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test323"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Sun Dec 21 01:14:32 PST 2014", var1);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test324"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var37 = var36.getSerialIndex();
//     java.util.Date var38 = var36.getTime();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addYears(0, var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.addYears(31, var40);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var44 = var43.getSerialIndex();
//     java.util.Date var45 = var43.getTime();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getFirstMillisecond();
//     java.util.Calendar var51 = null;
//     long var52 = var49.getMiddleMillisecond(var51);
//     java.util.Calendar var53 = null;
//     long var54 = var49.getFirstMillisecond(var53);
//     org.jfree.data.time.RegularTimePeriod var55 = var49.next();
//     java.util.Date var56 = var49.getTime();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var57);
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day(var57);
//     org.jfree.data.time.SerialDate var60 = var46.getEndOfCurrentMonth(var57);
//     org.jfree.data.time.SerialDate var61 = var40.getEndOfCurrentMonth(var60);
//     boolean var62 = var2.isBefore(var60);
//     java.lang.String var63 = var60.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addYears((-571), var60);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "31-December-1969"+ "'", var63.equals("31-December-1969"));
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test325"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     int var4 = var0.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var5 = var0.previous();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     boolean var9 = var8.getNotify();
//     var8.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = var8.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     long var14 = var12.getMiddleMillisecond();
//     java.util.Calendar var15 = null;
//     long var16 = var12.getLastMillisecond(var15);
//     java.lang.String var17 = var12.toString();
//     int var19 = var12.compareTo((java.lang.Object)(byte)0);
//     java.util.Calendar var20 = null;
//     long var21 = var12.getMiddleMillisecond(var20);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var23);
//     boolean var25 = var24.getNotify();
//     boolean var27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var24, (java.lang.Object)true);
//     var24.clear();
//     boolean var29 = var24.getNotify();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     boolean var33 = var32.getNotify();
//     boolean var35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)true);
//     var32.clear();
//     java.util.Collection var37 = var24.getTimePeriodsUniqueToOtherSeries(var32);
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var24.removeChangeListener(var38);
//     org.jfree.data.time.Day var40 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var41 = var40.next();
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var43);
//     var44.setDescription("");
//     var44.setDescription("Time");
//     boolean var49 = var40.equals((java.lang.Object)var44);
//     int var50 = var40.getMonth();
//     var24.setKey((java.lang.Comparable)var50);
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var53 = var52.next();
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var55);
//     var56.setDescription("");
//     var56.setDescription("Time");
//     boolean var61 = var52.equals((java.lang.Object)var56);
//     java.util.Collection var62 = var24.getTimePeriodsUniqueToOtherSeries(var56);
//     java.lang.String var63 = var24.getDomainDescription();
//     java.util.Collection var64 = var24.getTimePeriods();
//     java.beans.PropertyChangeListener var65 = null;
//     var24.removePropertyChangeListener(var65);
//     int var67 = var12.compareTo((java.lang.Object)var24);
//     int var68 = var0.compareTo((java.lang.Object)var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419153291104L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419153291104L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "Sun Dec 21 01:14:51 PST 2014"+ "'", var17.equals("Sun Dec 21 01:14:51 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419153291104L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "Time"+ "'", var63.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test326"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setNotify(false);
//     java.lang.String var12 = var2.getDomainDescription();
//     java.lang.String var13 = var2.getDomainDescription();
//     java.util.Collection var14 = var2.getTimePeriods();
//     var2.removeAgedItems(1419153271073L, false);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test327"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("20-January-1900");
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 20-January-1900"+ "'", var2.equals("org.jfree.data.time.TimePeriodFormatException: 20-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 20-January-1900"+ "'", var3.equals("org.jfree.data.time.TimePeriodFormatException: 20-January-1900"));

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test328"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     long var10 = var0.getSerialIndex();
//     long var11 = var0.getSerialIndex();
//     long var12 = var0.getSerialIndex();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     java.lang.String var14 = var13.toString();
//     long var15 = var13.getFirstMillisecond();
//     int var16 = var13.getYear();
//     int var17 = var0.compareTo((java.lang.Object)var16);
//     long var18 = var0.getFirstMillisecond();
//     java.util.Calendar var19 = null;
//     long var20 = var0.getFirstMillisecond(var19);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test329"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("2014");

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test330"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getMiddleMillisecond();
//     long var2 = var0.getMiddleMillisecond();
//     long var3 = var0.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
//     org.jfree.data.time.RegularTimePeriod var11 = var5.next();
//     java.util.Date var12 = var5.getTime();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var12);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(var12);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var12);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(var12);
//     long var17 = var16.getFirstMillisecond();
//     int var18 = var16.getYear();
//     org.jfree.data.time.RegularTimePeriod var19 = var16.next();
//     boolean var20 = var0.equals((java.lang.Object)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419153291257L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419153291257L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419153291257L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-31507200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test331"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Sun Dec 21 01:14:40 PST 2014", var1);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test332"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test333"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Sun Dec 21 01:14:40 PST 2014");

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test334"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     long var8 = var6.getMiddleMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var6.getLastMillisecond(var9);
//     java.lang.String var11 = var6.toString();
//     int var13 = var6.compareTo((java.lang.Object)(byte)0);
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)1419153271278L);
//     long var16 = var6.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419153291301L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419153291301L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Sun Dec 21 01:14:51 PST 2014"+ "'", var11.equals("Sun Dec 21 01:14:51 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419153291301L);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test335"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getSerialIndex();
    java.util.Date var4 = var2.getTime();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    long var9 = var8.getFirstMillisecond();
    java.util.Calendar var10 = null;
    long var11 = var8.getMiddleMillisecond(var10);
    java.util.Calendar var12 = null;
    long var13 = var8.getFirstMillisecond(var12);
    org.jfree.data.time.RegularTimePeriod var14 = var8.next();
    java.util.Date var15 = var8.getTime();
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var16);
    org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var16);
    org.jfree.data.time.SerialDate var19 = var5.getEndOfCurrentMonth(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test336"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    var2.setNotify(false);
    java.lang.String var12 = var2.getDomainDescription();
    boolean var13 = var2.isEmpty();
    java.beans.PropertyChangeListener var14 = null;
    var2.addPropertyChangeListener(var14);
    var2.setRangeDescription("Sun Dec 21 01:14:31 PST 2014");
    var2.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=false]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Time"+ "'", var12.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test337"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.lang.String var2 = var0.toString();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
//     org.jfree.data.time.RegularTimePeriod var5 = var0.previous();
//     java.lang.String var6 = var5.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Sun Dec 21 01:14:51 PST 2014"+ "'", var2.equals("Sun Dec 21 01:14:51 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "Sun Dec 21 01:14:51 PST 2014"+ "'", var6.equals("Sun Dec 21 01:14:51 PST 2014"));
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test338"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
    boolean var6 = var5.getNotify();
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)true);
    var5.setMaximumItemCount(0);
    java.util.Collection var11 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    java.util.Collection var12 = org.jfree.chart.util.ObjectUtilities.deepClone(var11);
    java.util.Collection var13 = org.jfree.chart.util.ObjectUtilities.deepClone(var12);
    java.util.Collection var14 = org.jfree.chart.util.ObjectUtilities.deepClone(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test339"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test340"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.String var3 = var2.getDomainDescription();
    var2.clear();
    var2.setMaximumItemAge(1419153269727L);
    java.lang.String var7 = var2.getDomainDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((-1), (java.lang.Number)1419153271073L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Time"+ "'", var7.equals("Time"));

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test341"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     var2.removeAgedItems(false);
//     java.util.Collection var6 = var2.getTimePeriods();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     long var9 = var7.getLastMillisecond();
//     org.jfree.data.time.SerialDate var10 = var7.getSerialDate();
//     int var11 = var7.getMonth();
//     int var12 = var7.getDayOfMonth();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(-1L), true);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test342"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test343"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getLastMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var1.getLastMillisecond(var7);
    long var9 = var1.getMiddleMillisecond();
    java.util.Calendar var10 = null;
    long var11 = var1.getFirstMillisecond(var10);
    org.jfree.data.time.RegularTimePeriod var12 = var1.previous();
    org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var14 = var13.next();
    org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)100);
    java.lang.Number var17 = null;
    var16.setValue(var17);
    var16.setValue((java.lang.Number)1417420800000L);
    java.lang.Number var21 = var16.getValue();
    boolean var22 = var1.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 1417420800000L+ "'", var21.equals(1417420800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test344"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
//     org.jfree.data.time.RegularTimePeriod var11 = var5.next();
//     java.util.Date var12 = var5.getTime();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var13);
//     boolean var15 = var2.isAfter(var14);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var21 = var20.getSerialIndex();
//     java.util.Date var22 = var20.getTime();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(31, var24);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getSerialIndex();
//     java.util.Date var29 = var27.getTime();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var33.next();
//     java.util.Date var40 = var33.getTime();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var41);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day(var41);
//     org.jfree.data.time.SerialDate var44 = var30.getEndOfCurrentMonth(var41);
//     org.jfree.data.time.SerialDate var45 = var24.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addYears(1969, var24);
//     java.lang.String var47 = var46.toString();
//     org.jfree.data.time.SerialDate var48 = var2.getEndOfCurrentMonth(var46);
//     var2.setDescription("Wednesday");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "31-December-3938"+ "'", var47.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test345"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var1.previous();
//     org.jfree.data.time.Year var4 = var1.getYear();
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var4);
//     org.jfree.data.time.TimeSeries var8 = var5.createCopy(100, 100);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     long var11 = var9.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 0.0d);
//     int var15 = var9.getYear();
//     java.lang.Number var16 = var5.getValue((org.jfree.data.time.RegularTimePeriod)var9);
//     boolean var18 = var9.equals((java.lang.Object)1419153288789L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var19 = new org.jfree.data.time.Month((-6654), var9);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test346"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     long var12 = var9.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var9.previous();
//     org.jfree.data.time.RegularTimePeriod var14 = var9.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test347"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     java.util.Calendar var12 = null;
//     var9.peg(var12);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test348"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getLastMillisecond();
//     long var12 = var10.getLastMillisecond();
//     long var13 = var10.getLastMillisecond();
//     java.lang.String var14 = var10.toString();
//     int var15 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     boolean var17 = var2.equals((java.lang.Object)28799999L);
//     var2.setMaximumItemAge(1419153274341L);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     org.jfree.data.general.SeriesChangeListener var27 = null;
//     var22.removeChangeListener(var27);
//     java.lang.Comparable var29 = var22.getKey();
//     long var30 = var22.getMaximumItemAge();
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var32);
//     long var34 = var33.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var35 = null;
//     var33.addChangeListener(var35);
//     var33.fireSeriesChanged();
//     java.lang.String var38 = var33.getDescription();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var40);
//     boolean var42 = var41.getNotify();
//     var41.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var46 = var41.getDataItem((org.jfree.data.time.RegularTimePeriod)var45);
//     var41.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var49 = var33.addAndOrUpdate(var41);
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     long var51 = var50.getFirstMillisecond();
//     org.jfree.data.time.Year var52 = var50.getYear();
//     org.jfree.data.time.Year var53 = var50.getYear();
//     org.jfree.data.general.SeriesChangeEvent var54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var53);
//     java.lang.Class var56 = null;
//     org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var56);
//     var57.setDescription("");
//     var57.setDescription("Time");
//     java.util.List var62 = var57.getItems();
//     org.jfree.data.time.FixedMillisecond var64 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var65 = var64.getFirstMillisecond();
//     java.util.Calendar var66 = null;
//     long var67 = var64.getMiddleMillisecond(var66);
//     java.util.Calendar var68 = null;
//     long var69 = var64.getFirstMillisecond(var68);
//     java.util.Calendar var70 = null;
//     long var71 = var64.getMiddleMillisecond(var70);
//     org.jfree.data.time.TimeSeriesDataItem var73 = var57.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var64, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var74 = var64.previous();
//     org.jfree.data.time.TimeSeries var75 = var41.createCopy((org.jfree.data.time.RegularTimePeriod)var53, var74);
//     org.jfree.data.time.TimeSeries var76 = var22.addAndOrUpdate(var41);
//     org.jfree.data.time.TimeSeries var77 = var2.addAndOrUpdate(var76);
//     java.beans.PropertyChangeListener var78 = null;
//     var76.addPropertyChangeListener(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "21-December-2014"+ "'", var14.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + 100.0f+ "'", var29.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test349"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
    var1.addSuppressed((java.lang.Throwable)var3);
    java.lang.String var5 = var1.toString();
    org.jfree.data.general.SeriesException var7 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var9 = new org.jfree.data.general.SeriesException("ThreadContext");
    var7.addSuppressed((java.lang.Throwable)var9);
    org.jfree.data.general.SeriesException var12 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var14 = new org.jfree.data.general.SeriesException("ThreadContext");
    var12.addSuppressed((java.lang.Throwable)var14);
    var9.addSuppressed((java.lang.Throwable)var12);
    var1.addSuppressed((java.lang.Throwable)var12);
    org.jfree.data.time.TimePeriodFormatException var19 = new org.jfree.data.time.TimePeriodFormatException("2014");
    org.jfree.data.general.SeriesException var21 = new org.jfree.data.general.SeriesException("Preceding");
    java.lang.Throwable[] var22 = var21.getSuppressed();
    java.lang.Throwable[] var23 = var21.getSuppressed();
    var19.addSuppressed((java.lang.Throwable)var21);
    var12.addSuppressed((java.lang.Throwable)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var5.equals("org.jfree.data.general.SeriesException: ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test350"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-570), 12, (-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test351"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     var17.setDescription("");
//     var17.setDescription("Time");
//     boolean var22 = var13.equals((java.lang.Object)var17);
//     long var23 = var13.getSerialIndex();
//     long var24 = var13.getSerialIndex();
//     org.jfree.data.time.TimeSeries var25 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, (org.jfree.data.time.RegularTimePeriod)var13);
//     java.util.Calendar var26 = null;
//     long var27 = var13.getMiddleMillisecond(var26);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test352"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     long var11 = var9.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
//     org.jfree.data.time.RegularTimePeriod var13 = var9.next();
//     java.util.Calendar var14 = null;
//     long var15 = var13.getMiddleMillisecond(var14);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test353"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getFirstMillisecond();
//     int var3 = var0.getYear();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     boolean var7 = var6.getNotify();
//     boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)true);
//     var6.clear();
//     boolean var11 = var6.getNotify();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)true);
//     var14.clear();
//     java.util.Collection var19 = var6.getTimePeriodsUniqueToOtherSeries(var14);
//     org.jfree.data.general.SeriesChangeListener var20 = null;
//     var6.removeChangeListener(var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     boolean var31 = var22.equals((java.lang.Object)var26);
//     int var32 = var22.getMonth();
//     var6.setKey((java.lang.Comparable)var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var37);
//     var38.setDescription("");
//     var38.setDescription("Time");
//     boolean var43 = var34.equals((java.lang.Object)var38);
//     java.util.Collection var44 = var6.getTimePeriodsUniqueToOtherSeries(var38);
//     org.jfree.data.general.SeriesChangeEvent var45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
//     boolean var46 = var0.equals((java.lang.Object)var45);
//     java.lang.Class var48 = null;
//     org.jfree.data.time.TimeSeries var49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var48);
//     java.lang.String var50 = var49.getDomainDescription();
//     boolean var51 = var0.equals((java.lang.Object)var49);
//     java.util.Collection var52 = var49.getTimePeriods();
//     java.util.Collection var53 = org.jfree.chart.util.ObjectUtilities.deepClone(var52);
//     java.util.Collection var54 = org.jfree.chart.util.ObjectUtilities.deepClone(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "Time"+ "'", var50.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test354"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test355"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Sun Dec 21 01:14:50 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test356"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     long var14 = var0.getLastMillisecond();
//     java.util.Calendar var15 = null;
//     long var16 = var0.getLastMillisecond(var15);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test357"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.String var10 = var2.getDomainDescription();
//     java.beans.PropertyChangeListener var11 = null;
//     var2.removePropertyChangeListener(var11);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var14);
//     boolean var16 = var15.getNotify();
//     var15.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var15.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     var15.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     long var24 = var23.getLastMillisecond();
//     long var25 = var23.getLastMillisecond();
//     long var26 = var23.getLastMillisecond();
//     java.lang.String var27 = var23.toString();
//     int var28 = var15.getIndex((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.general.SeriesException var30 = new org.jfree.data.general.SeriesException("hi!");
//     int var31 = var23.compareTo((java.lang.Object)"hi!");
//     long var32 = var23.getSerialIndex();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)1419153270723L, false);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test358"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.beans.PropertyChangeListener var7 = null;
    var2.removePropertyChangeListener(var7);
    java.util.List var9 = var2.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var10 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var9);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, (-452), (-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test360"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(12, 1969);
//     java.util.Calendar var3 = null;
//     var2.peg(var3);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test361"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.next();
//     java.util.Date var5 = var0.getEnd();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var5);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getFirstMillisecond(var7);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test362"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getFirstMillisecond();
    java.util.Calendar var6 = null;
    long var7 = var4.getMiddleMillisecond(var6);
    java.util.Calendar var8 = null;
    long var9 = var4.getFirstMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var4.next();
    java.util.Date var11 = var4.getTime();
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
    boolean var14 = var1.isAfter(var13);
    org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(1L);
    long var19 = var18.getSerialIndex();
    java.util.Date var20 = var18.getTime();
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addYears(0, var21);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(31, var22);
    org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
    long var26 = var25.getSerialIndex();
    java.util.Date var27 = var25.getTime();
    org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
    org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(1L);
    long var32 = var31.getFirstMillisecond();
    java.util.Calendar var33 = null;
    long var34 = var31.getMiddleMillisecond(var33);
    java.util.Calendar var35 = null;
    long var36 = var31.getFirstMillisecond(var35);
    org.jfree.data.time.RegularTimePeriod var37 = var31.next();
    java.util.Date var38 = var31.getTime();
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
    org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var39);
    org.jfree.data.time.Day var41 = new org.jfree.data.time.Day(var39);
    org.jfree.data.time.SerialDate var42 = var28.getEndOfCurrentMonth(var39);
    org.jfree.data.time.SerialDate var43 = var22.getEndOfCurrentMonth(var42);
    org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond(1L);
    long var48 = var47.getSerialIndex();
    java.util.Date var49 = var47.getTime();
    org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addYears(0, var50);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.addYears(31, var51);
    org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(1L);
    long var55 = var54.getSerialIndex();
    java.util.Date var56 = var54.getTime();
    org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
    org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond(1L);
    long var61 = var60.getFirstMillisecond();
    java.util.Calendar var62 = null;
    long var63 = var60.getMiddleMillisecond(var62);
    java.util.Calendar var64 = null;
    long var65 = var60.getFirstMillisecond(var64);
    org.jfree.data.time.RegularTimePeriod var66 = var60.next();
    java.util.Date var67 = var60.getTime();
    org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
    org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var68);
    org.jfree.data.time.Day var70 = new org.jfree.data.time.Day(var68);
    org.jfree.data.time.SerialDate var71 = var57.getEndOfCurrentMonth(var68);
    org.jfree.data.time.SerialDate var72 = var51.getEndOfCurrentMonth(var71);
    boolean var73 = var1.isInRange(var43, var51);
    org.jfree.data.time.Day var74 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
    int var75 = var1.getYYYY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1900);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test363"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test364"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     int var31 = var1.getMonth();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var35);
//     var36.setDescription("");
//     var36.setDescription("Time");
//     boolean var41 = var32.equals((java.lang.Object)var36);
//     int var42 = var32.getMonth();
//     long var43 = var32.getFirstMillisecond();
//     long var44 = var32.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var45 = var32.getSerialDate();
//     boolean var46 = var1.isBefore(var45);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getSerialIndex();
//     java.util.Date var51 = var49.getTime();
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var51);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
//     boolean var54 = var1.isOnOrBefore(var53);
//     java.lang.String var55 = var1.getDescription();
//     int var56 = var1.getDayOfWeek();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 7);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test365"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test366"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (-1.0d));
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var8);
//     java.lang.String var10 = var9.getDomainDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.next();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 0.0d);
//     boolean var17 = var9.equals((java.lang.Object)var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var9.addChangeListener(var18);
//     int var20 = var6.compareTo((java.lang.Object)var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Time"+ "'", var10.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test367"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test368"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-458));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test369"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    java.util.Date var2 = var1.toDate();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getSerialIndex();
    java.util.Date var9 = var7.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(31, var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(31, var11);
    boolean var14 = var1.isOnOrAfter(var13);
    org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
    long var17 = var16.getSerialIndex();
    java.util.Date var18 = var16.getTime();
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
    org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
    long var23 = var22.getFirstMillisecond();
    java.util.Calendar var24 = null;
    long var25 = var22.getMiddleMillisecond(var24);
    java.util.Calendar var26 = null;
    long var27 = var22.getFirstMillisecond(var26);
    org.jfree.data.time.RegularTimePeriod var28 = var22.next();
    java.util.Date var29 = var22.getTime();
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
    org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var30);
    org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var30);
    org.jfree.data.time.SerialDate var33 = var19.getEndOfCurrentMonth(var30);
    boolean var34 = var1.isOn(var30);
    int var35 = var1.getMonth();
    java.lang.Class var38 = null;
    org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1, "org.jfree.data.general.SeriesException: ThreadContext", "January -457", var38);
    java.lang.Class var40 = var39.getTimePeriodClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test370"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var8 = var2.getDataItem((-605));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test371"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test372"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    java.lang.String var15 = var8.getDescription();
    org.jfree.data.general.SeriesChangeListener var16 = null;
    var8.removeChangeListener(var16);
    java.lang.Comparable var18 = var8.getKey();
    var8.setRangeDescription("21-December-2014");
    var8.setDomainDescription("31-December-3938");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + 100.0f+ "'", var18.equals(100.0f));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test373"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    int var10 = var3.compareTo((java.lang.Object)var8);
    org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
    boolean var12 = var3.equals((java.lang.Object)var11);
    var3.setValue((java.lang.Number)(-570));
    org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
    org.jfree.data.time.RegularTimePeriod var16 = var15.next();
    java.lang.Class var18 = null;
    org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
    var19.setDescription("");
    var19.setDescription("Time");
    boolean var24 = var15.equals((java.lang.Object)var19);
    var19.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var26 = null;
    var19.addChangeListener(var26);
    int var28 = var3.compareTo((java.lang.Object)var26);
    var3.setValue((java.lang.Number)20);
    org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(1L);
    long var33 = var32.getFirstMillisecond();
    java.util.Calendar var34 = null;
    long var35 = var32.getMiddleMillisecond(var34);
    java.util.Calendar var36 = null;
    long var37 = var32.getFirstMillisecond(var36);
    java.util.Calendar var38 = null;
    long var39 = var32.getMiddleMillisecond(var38);
    boolean var40 = var3.equals((java.lang.Object)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test374"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var9);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var9);
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.RegularTimePeriod var14 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var9, var13);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var9);
//     java.util.Date var16 = var15.getTime();
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year(var16, var17);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test375"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("2014");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("Preceding");
    java.lang.Throwable[] var4 = var3.getSuppressed();
    java.lang.Throwable[] var5 = var3.getSuppressed();
    var1.addSuppressed((java.lang.Throwable)var3);
    java.lang.Throwable[] var7 = var3.getSuppressed();
    java.lang.Throwable[] var8 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test376"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getLastMillisecond();
//     long var12 = var10.getLastMillisecond();
//     long var13 = var10.getLastMillisecond();
//     java.lang.String var14 = var10.toString();
//     int var15 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     boolean var17 = var2.equals((java.lang.Object)28799999L);
//     var2.setMaximumItemAge(1419153274341L);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     org.jfree.data.general.SeriesChangeListener var27 = null;
//     var22.removeChangeListener(var27);
//     java.lang.Comparable var29 = var22.getKey();
//     long var30 = var22.getMaximumItemAge();
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var32);
//     long var34 = var33.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var35 = null;
//     var33.addChangeListener(var35);
//     var33.fireSeriesChanged();
//     java.lang.String var38 = var33.getDescription();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var40);
//     boolean var42 = var41.getNotify();
//     var41.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var46 = var41.getDataItem((org.jfree.data.time.RegularTimePeriod)var45);
//     var41.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var49 = var33.addAndOrUpdate(var41);
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     long var51 = var50.getFirstMillisecond();
//     org.jfree.data.time.Year var52 = var50.getYear();
//     org.jfree.data.time.Year var53 = var50.getYear();
//     org.jfree.data.general.SeriesChangeEvent var54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var53);
//     java.lang.Class var56 = null;
//     org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var56);
//     var57.setDescription("");
//     var57.setDescription("Time");
//     java.util.List var62 = var57.getItems();
//     org.jfree.data.time.FixedMillisecond var64 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var65 = var64.getFirstMillisecond();
//     java.util.Calendar var66 = null;
//     long var67 = var64.getMiddleMillisecond(var66);
//     java.util.Calendar var68 = null;
//     long var69 = var64.getFirstMillisecond(var68);
//     java.util.Calendar var70 = null;
//     long var71 = var64.getMiddleMillisecond(var70);
//     org.jfree.data.time.TimeSeriesDataItem var73 = var57.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var64, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var74 = var64.previous();
//     org.jfree.data.time.TimeSeries var75 = var41.createCopy((org.jfree.data.time.RegularTimePeriod)var53, var74);
//     org.jfree.data.time.TimeSeries var76 = var22.addAndOrUpdate(var41);
//     org.jfree.data.time.TimeSeries var77 = var2.addAndOrUpdate(var76);
//     var76.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "21-December-2014"+ "'", var14.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + 100.0f+ "'", var29.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test377"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Saturday"+ "'", var1.equals("Saturday"));

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test378"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var1);
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var1, var3);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test379"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.time.TimeSeries var18 = var10.createCopy(10, 10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     java.lang.Object var23 = null;
//     boolean var24 = var19.equals(var23);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1419153269727L);
//     var18.delete((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getFirstMillisecond();
//     java.util.Calendar var31 = null;
//     long var32 = var29.getMiddleMillisecond(var31);
//     java.util.Calendar var33 = null;
//     var29.peg(var33);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var18.getDataItem((org.jfree.data.time.RegularTimePeriod)var29);
//     java.util.Date var36 = var29.getTime();
//     java.util.TimeZone var37 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var38 = new org.jfree.data.time.Day(var36, var37);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test380"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
    java.util.Date var3 = var2.toDate();
    java.util.TimeZone var4 = null;
    org.jfree.data.time.RegularTimePeriod var5 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var3, var4);
    org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var3);
    java.util.TimeZone var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var3, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test381"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test382"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-605));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test383"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     boolean var8 = var2.getNotify();
//     java.lang.String var9 = var2.getRangeDescription();
//     var2.fireSeriesChanged();
//     var2.setRangeDescription("Sun Dec 21 01:14:49 PST 2014");
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var15 = var14.getFirstMillisecond();
//     long var16 = var14.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
//     java.lang.Number var19 = var18.getValue();
//     var2.add(var18);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test384"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     long var9 = var7.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, var17);
//     boolean var19 = var7.equals((java.lang.Object)var17);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getFirstMillisecond();
//     java.util.Calendar var23 = null;
//     long var24 = var21.getMiddleMillisecond(var23);
//     java.util.Calendar var25 = null;
//     long var26 = var21.getFirstMillisecond(var25);
//     org.jfree.data.time.RegularTimePeriod var27 = var21.next();
//     java.util.Date var28 = var21.getTime();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(var28);
//     int var30 = var29.getYearValue();
//     java.util.Date var31 = var29.getStart();
//     int var32 = var29.getYearValue();
//     boolean var33 = var7.equals((java.lang.Object)var29);
//     java.lang.Number var34 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var7);
//     var2.removeAgedItems(0L, false);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test385"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10, 10, (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test386"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("December 2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test387"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getSerialIndex();
//     java.util.Date var6 = var4.getTime();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getMiddleMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var10.getFirstMillisecond(var14);
//     org.jfree.data.time.RegularTimePeriod var16 = var10.next();
//     java.util.Date var17 = var10.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var18);
//     org.jfree.data.time.SerialDate var21 = var7.getEndOfCurrentMonth(var18);
//     int var22 = var0.compareTo((java.lang.Object)var21);
//     java.util.Calendar var23 = null;
//     long var24 = var0.getFirstMillisecond(var23);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test388"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test389"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getSerialIndex();
//     java.util.Date var6 = var4.getTime();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getMiddleMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var10.getFirstMillisecond(var14);
//     org.jfree.data.time.RegularTimePeriod var16 = var10.next();
//     java.util.Date var17 = var10.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var18);
//     org.jfree.data.time.SerialDate var21 = var7.getEndOfCurrentMonth(var18);
//     int var22 = var0.compareTo((java.lang.Object)var21);
//     java.util.Calendar var23 = null;
//     long var24 = var0.getLastMillisecond(var23);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test390"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     long var5 = var3.getLastMillisecond();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, var6);
//     java.lang.String var8 = var7.getRangeDescription();
//     var7.setDomainDescription("Fourth");
//     var7.removeAgedItems((-76589164800000L), true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test391"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test392"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     java.lang.String var6 = var5.getDomainDescription();
//     var5.clear();
//     boolean var8 = var2.equals((java.lang.Object)var5);
//     long var9 = var2.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var10 = var2.previous();
//     java.util.Calendar var11 = null;
//     var2.peg(var11);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test393"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
    var4.setDescription("");
    var4.setDescription("Time");
    boolean var9 = var0.equals((java.lang.Object)var4);
    var4.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.addChangeListener(var11);
    java.util.List var13 = var4.getItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test394"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    java.beans.PropertyChangeListener var15 = null;
    var8.addPropertyChangeListener(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var17 = var8.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test395"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var34.removeChangeListener(var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     var54.setDescription("");
//     var54.setDescription("Time");
//     boolean var59 = var50.equals((java.lang.Object)var54);
//     int var60 = var50.getMonth();
//     var34.setKey((java.lang.Comparable)var60);
//     var34.setMaximumItemCount(100);
//     boolean var64 = var1.equals((java.lang.Object)var34);
//     int var65 = var1.toSerial();
//     var1.setDescription("Value");
//     org.jfree.data.time.FixedMillisecond var70 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var71 = var70.getFirstMillisecond();
//     java.util.Calendar var72 = null;
//     long var73 = var70.getMiddleMillisecond(var72);
//     java.util.Calendar var74 = null;
//     long var75 = var70.getFirstMillisecond(var74);
//     org.jfree.data.time.RegularTimePeriod var76 = var70.next();
//     java.util.Date var77 = var70.getTime();
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var77);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var78);
//     org.jfree.data.time.FixedMillisecond var82 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var83 = var82.getFirstMillisecond();
//     java.util.Calendar var84 = null;
//     long var85 = var82.getMiddleMillisecond(var84);
//     java.util.Calendar var86 = null;
//     long var87 = var82.getFirstMillisecond(var86);
//     org.jfree.data.time.RegularTimePeriod var88 = var82.next();
//     java.util.Date var89 = var82.getTime();
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.createInstance(var89);
//     org.jfree.data.time.SerialDate var91 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var90);
//     org.jfree.data.time.SerialDate var92 = var79.getEndOfCurrentMonth(var91);
//     boolean var93 = var1.isAfter(var79);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var95 = var1.getNearestDayOfWeek(1900);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
// 
//   }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test396"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getSerialIndex();
//     java.util.Date var6 = var4.getTime();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getMiddleMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var10.getFirstMillisecond(var14);
//     org.jfree.data.time.RegularTimePeriod var16 = var10.next();
//     java.util.Date var17 = var10.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var18);
//     org.jfree.data.time.SerialDate var21 = var7.getEndOfCurrentMonth(var18);
//     int var22 = var0.compareTo((java.lang.Object)var21);
//     long var23 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 2014L);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test397"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test398"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     int var12 = var9.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-1310400001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 12);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test399"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test400"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var6 = var2.getTimePeriod(1969);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test401"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var8);
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(var8, var13);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test402"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var34 = var30.getFollowingDayOfWeek(2014);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test403"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     var5.setDescription("");
//     var5.setDescription("Time");
//     boolean var10 = var1.equals((java.lang.Object)var5);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     long var12 = var11.getFirstMillisecond();
//     org.jfree.data.time.Year var13 = var11.getYear();
//     org.jfree.data.time.Year var14 = var11.getYear();
//     boolean var15 = var1.equals((java.lang.Object)var11);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var17);
//     boolean var19 = var18.getNotify();
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)true);
//     var18.clear();
//     boolean var23 = var18.getNotify();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     boolean var27 = var26.getNotify();
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, (java.lang.Object)true);
//     var26.clear();
//     java.util.Collection var31 = var18.getTimePeriodsUniqueToOtherSeries(var26);
//     org.jfree.data.time.TimeSeries var34 = var26.createCopy(10, 10);
//     boolean var35 = var1.equals((java.lang.Object)var26);
//     org.jfree.data.time.RegularTimePeriod var36 = var1.next();
//     org.jfree.data.time.SerialDate var37 = var1.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-25544), var37);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test404"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test405"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(10, var1);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test406"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(1900);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.addYears((-452), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test407"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     java.lang.Comparable var6 = var2.getKey();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var8);
//     java.lang.String var10 = var9.getDomainDescription();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     long var14 = var13.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var13.addChangeListener(var15);
//     var13.fireSeriesChanged();
//     java.lang.String var18 = var13.getDescription();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var20);
//     boolean var22 = var21.getNotify();
//     var21.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = var21.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     var21.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var29 = var13.addAndOrUpdate(var21);
//     org.jfree.data.time.TimeSeries var30 = var9.addAndOrUpdate(var29);
//     java.util.Collection var31 = var2.getTimePeriodsUniqueToOtherSeries(var29);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getFirstMillisecond();
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getMiddleMillisecond();
//     long var37 = var34.getLastMillisecond();
//     boolean var38 = var32.equals((java.lang.Object)var37);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var32, (-1.0d), false);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test408"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Date var8 = var1.getTime();
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
    java.util.TimeZone var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var11 = new org.jfree.data.time.Day(var8, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test409"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     java.lang.String var9 = var8.getDomainDescription();
//     var8.clear();
//     var8.setMaximumItemAge(1419153269727L);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     var17.setDescription("");
//     var17.setDescription("Time");
//     boolean var22 = var13.equals((java.lang.Object)var17);
//     int var23 = var13.getMonth();
//     long var24 = var13.getFirstMillisecond();
//     long var25 = var13.getFirstMillisecond();
//     int var26 = var13.getDayOfMonth();
//     java.lang.Number var27 = null;
//     org.jfree.data.time.TimeSeriesDataItem var28 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, var27);
//     long var29 = var13.getFirstMillisecond();
//     long var30 = var13.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var33 = null;
//     long var34 = var32.getLastMillisecond(var33);
//     long var35 = var32.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var38 = var32.next();
//     boolean var39 = var13.equals((java.lang.Object)var38);
//     org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var45 = var44.next();
//     long var46 = var44.getLastMillisecond();
//     org.jfree.data.time.SerialDate var47 = var44.getSerialDate();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addMonths(0, var47);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addYears(1, var47);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var52 = var51.next();
//     long var53 = var51.getLastMillisecond();
//     org.jfree.data.time.SerialDate var54 = var51.getSerialDate();
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.addMonths(0, var54);
//     org.jfree.data.time.SerialDate var57 = var55.getPreviousDayOfWeek(4);
//     boolean var58 = var41.isInRange(var47, var55);
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var41);
//     org.jfree.data.time.RegularTimePeriod var60 = var59.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var61 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var59);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "Time"+ "'", var9.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test410"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     java.util.Calendar var15 = null;
//     long var16 = var11.getMiddleMillisecond(var15);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test411"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test412"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", var1);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test413"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)1417420800000L);
//     java.lang.Number var15 = var14.getValue();
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(1, var23);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     long var29 = var27.getLastMillisecond();
//     org.jfree.data.time.SerialDate var30 = var27.getSerialDate();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addMonths(0, var30);
//     org.jfree.data.time.SerialDate var33 = var31.getPreviousDayOfWeek(4);
//     boolean var34 = var17.isInRange(var23, var31);
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var36 = var35.next();
//     org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)100);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     int var40 = var38.compareTo((java.lang.Object)var39);
//     java.lang.Class var42 = null;
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var42);
//     long var44 = var43.getMaximumItemAge();
//     int var45 = var38.compareTo((java.lang.Object)var43);
//     boolean var46 = var17.equals((java.lang.Object)var43);
//     int var47 = var17.getMonth();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var49 = var48.next();
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var51);
//     var52.setDescription("");
//     var52.setDescription("Time");
//     boolean var57 = var48.equals((java.lang.Object)var52);
//     int var58 = var48.getMonth();
//     long var59 = var48.getFirstMillisecond();
//     long var60 = var48.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var61 = var48.getSerialDate();
//     boolean var62 = var17.isBefore(var61);
//     java.lang.Class var63 = null;
//     org.jfree.data.time.TimeSeries var64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var17, var63);
//     boolean var65 = var14.equals((java.lang.Object)var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + 1417420800000L+ "'", var15.equals(1417420800000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test414"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-41973));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test415"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getFirstMillisecond();
//     java.util.Calendar var36 = null;
//     long var37 = var34.getMiddleMillisecond(var36);
//     java.util.Calendar var38 = null;
//     long var39 = var34.getFirstMillisecond(var38);
//     org.jfree.data.time.RegularTimePeriod var40 = var34.next();
//     java.util.Date var41 = var34.getTime();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var42);
//     int var44 = var1.compare(var43);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var46 = var43.getNearestDayOfWeek((-452));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-25544));
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test416"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test417"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     boolean var6 = var5.getNotify();
//     boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)true);
//     var5.setMaximumItemCount(0);
//     java.util.Collection var11 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.lang.String var13 = var12.toString();
//     long var14 = var12.getFirstMillisecond();
//     int var15 = var12.getYear();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var17);
//     boolean var19 = var18.getNotify();
//     boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)true);
//     var18.clear();
//     boolean var23 = var18.getNotify();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     boolean var27 = var26.getNotify();
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, (java.lang.Object)true);
//     var26.clear();
//     java.util.Collection var31 = var18.getTimePeriodsUniqueToOtherSeries(var26);
//     org.jfree.data.general.SeriesChangeListener var32 = null;
//     var18.removeChangeListener(var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var37);
//     var38.setDescription("");
//     var38.setDescription("Time");
//     boolean var43 = var34.equals((java.lang.Object)var38);
//     int var44 = var34.getMonth();
//     var18.setKey((java.lang.Comparable)var44);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     var50.setDescription("");
//     var50.setDescription("Time");
//     boolean var55 = var46.equals((java.lang.Object)var50);
//     java.util.Collection var56 = var18.getTimePeriodsUniqueToOtherSeries(var50);
//     org.jfree.data.general.SeriesChangeEvent var57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var18);
//     boolean var58 = var12.equals((java.lang.Object)var57);
//     long var59 = var12.getMiddleMillisecond();
//     int var60 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "2014"+ "'", var13.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == (-1));
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test418"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3);
//     org.jfree.data.time.TimeSeries var7 = var4.createCopy(100, 100);
//     var7.setNotify(false);
//     java.util.List var10 = var7.getItems();
//     java.lang.String var11 = var7.getRangeDescription();
//     java.beans.PropertyChangeListener var12 = null;
//     var7.removePropertyChangeListener(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test419"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    java.lang.String var15 = var8.getDescription();
    int var16 = var8.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2147483647);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test420"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
    var1.addSuppressed((java.lang.Throwable)var3);
    java.lang.String var5 = var1.toString();
    java.lang.Throwable[] var6 = var1.getSuppressed();
    java.lang.Throwable[] var7 = var1.getSuppressed();
    java.lang.Throwable[] var8 = var1.getSuppressed();
    java.lang.String var9 = var1.toString();
    java.lang.String var10 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var5.equals("org.jfree.data.general.SeriesException: ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var9.equals("org.jfree.data.general.SeriesException: ThreadContext"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var10.equals("org.jfree.data.general.SeriesException: ThreadContext"));

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test421"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.beans.PropertyChangeListener var7 = null;
    var2.removePropertyChangeListener(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test422"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var8);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var8, var10);
//     boolean var12 = var0.equals((java.lang.Object)var10);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var15 = var14.getFirstMillisecond();
//     java.util.Calendar var16 = null;
//     long var17 = var14.getMiddleMillisecond(var16);
//     java.util.Calendar var18 = null;
//     long var19 = var14.getFirstMillisecond(var18);
//     org.jfree.data.time.RegularTimePeriod var20 = var14.next();
//     java.util.Date var21 = var14.getTime();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(var21);
//     int var23 = var22.getYearValue();
//     java.util.Date var24 = var22.getStart();
//     int var25 = var22.getYearValue();
//     boolean var26 = var0.equals((java.lang.Object)var22);
//     org.jfree.data.time.RegularTimePeriod var27 = var22.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test423"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var34);
//     boolean var36 = var35.getNotify();
//     boolean var38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, (java.lang.Object)true);
//     var35.clear();
//     boolean var40 = var35.getNotify();
//     java.lang.Class var42 = null;
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var42);
//     boolean var44 = var43.getNotify();
//     boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var43, (java.lang.Object)true);
//     var43.clear();
//     java.util.Collection var48 = var35.getTimePeriodsUniqueToOtherSeries(var43);
//     org.jfree.data.general.SeriesChangeListener var49 = null;
//     var35.removeChangeListener(var49);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var52 = var51.next();
//     java.lang.Class var54 = null;
//     org.jfree.data.time.TimeSeries var55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var54);
//     var55.setDescription("");
//     var55.setDescription("Time");
//     boolean var60 = var51.equals((java.lang.Object)var55);
//     int var61 = var51.getMonth();
//     var35.setKey((java.lang.Comparable)var61);
//     var35.setMaximumItemCount(100);
//     boolean var65 = var2.equals((java.lang.Object)var35);
//     int var66 = var2.toSerial();
//     org.jfree.data.time.FixedMillisecond var69 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var70 = var69.getFirstMillisecond();
//     java.util.Calendar var71 = null;
//     long var72 = var69.getMiddleMillisecond(var71);
//     java.util.Calendar var73 = null;
//     long var74 = var69.getFirstMillisecond(var73);
//     org.jfree.data.time.RegularTimePeriod var75 = var69.next();
//     java.util.Date var76 = var69.getTime();
//     org.jfree.data.time.SerialDate var77 = org.jfree.data.time.SerialDate.createInstance(var76);
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var77);
//     org.jfree.data.time.FixedMillisecond var81 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var82 = var81.getFirstMillisecond();
//     java.util.Calendar var83 = null;
//     long var84 = var81.getMiddleMillisecond(var83);
//     java.util.Calendar var85 = null;
//     long var86 = var81.getFirstMillisecond(var85);
//     org.jfree.data.time.RegularTimePeriod var87 = var81.next();
//     java.util.Date var88 = var81.getTime();
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.createInstance(var88);
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var89);
//     org.jfree.data.time.SerialDate var91 = var78.getEndOfCurrentMonth(var90);
//     boolean var92 = var2.isAfter(var90);
//     int var93 = var2.toSerial();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var94 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == 21);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test424"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Saturday", var1);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test425"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.util.List var7 = var2.getItems();
    boolean var9 = var2.equals((java.lang.Object)1.0d);
    var2.setRangeDescription("");
    java.lang.String var12 = var2.getRangeDescription();
    boolean var13 = var2.getNotify();
    java.lang.Class var15 = null;
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
    int var17 = var16.getItemCount();
    java.beans.PropertyChangeListener var18 = null;
    var16.addPropertyChangeListener(var18);
    java.lang.String var20 = var16.getRangeDescription();
    org.jfree.data.time.TimeSeries var21 = var2.addAndOrUpdate(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(1, 1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Value"+ "'", var20.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test426"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     long var5 = var3.getLastMillisecond();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, var6);
//     java.lang.String var8 = var7.getRangeDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var10 = var7.getValue(1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "Value"+ "'", var8.equals("Value"));
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test427"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test428"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", var1);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test429"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     long var6 = var5.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var5.addChangeListener(var7);
//     var5.fireSeriesChanged();
//     java.lang.String var10 = var5.getDescription();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     boolean var14 = var13.getNotify();
//     var13.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var13.getDataItem((org.jfree.data.time.RegularTimePeriod)var17);
//     var13.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var21 = var5.addAndOrUpdate(var13);
//     boolean var22 = var0.equals((java.lang.Object)var13);
//     long var23 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 41994L);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test430"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test432"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getFirstMillisecond();
//     int var3 = var0.getYear();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     boolean var7 = var6.getNotify();
//     boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)true);
//     var6.clear();
//     boolean var11 = var6.getNotify();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)true);
//     var14.clear();
//     java.util.Collection var19 = var6.getTimePeriodsUniqueToOtherSeries(var14);
//     org.jfree.data.general.SeriesChangeListener var20 = null;
//     var6.removeChangeListener(var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     boolean var31 = var22.equals((java.lang.Object)var26);
//     int var32 = var22.getMonth();
//     var6.setKey((java.lang.Comparable)var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var37);
//     var38.setDescription("");
//     var38.setDescription("Time");
//     boolean var43 = var34.equals((java.lang.Object)var38);
//     java.util.Collection var44 = var6.getTimePeriodsUniqueToOtherSeries(var38);
//     org.jfree.data.general.SeriesChangeEvent var45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
//     boolean var46 = var0.equals((java.lang.Object)var45);
//     long var47 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var48 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test433"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var34);
//     boolean var36 = var35.getNotify();
//     boolean var38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, (java.lang.Object)true);
//     var35.clear();
//     boolean var40 = var35.getNotify();
//     java.lang.Class var42 = null;
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var42);
//     boolean var44 = var43.getNotify();
//     boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var43, (java.lang.Object)true);
//     var43.clear();
//     java.util.Collection var48 = var35.getTimePeriodsUniqueToOtherSeries(var43);
//     org.jfree.data.general.SeriesChangeListener var49 = null;
//     var35.removeChangeListener(var49);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var52 = var51.next();
//     java.lang.Class var54 = null;
//     org.jfree.data.time.TimeSeries var55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var54);
//     var55.setDescription("");
//     var55.setDescription("Time");
//     boolean var60 = var51.equals((java.lang.Object)var55);
//     int var61 = var51.getMonth();
//     var35.setKey((java.lang.Comparable)var61);
//     var35.setMaximumItemCount(100);
//     boolean var65 = var2.equals((java.lang.Object)var35);
//     int var66 = var2.toSerial();
//     org.jfree.data.time.FixedMillisecond var68 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var69 = var68.getSerialIndex();
//     java.util.Date var70 = var68.getTime();
//     java.util.Date var71 = var68.getTime();
//     org.jfree.data.time.Month var72 = new org.jfree.data.time.Month(var71);
//     org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.createInstance(var71);
//     int var74 = var2.compare(var73);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-435), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == (-25547));
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test434"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var34.removeChangeListener(var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     var54.setDescription("");
//     var54.setDescription("Time");
//     boolean var59 = var50.equals((java.lang.Object)var54);
//     int var60 = var50.getMonth();
//     var34.setKey((java.lang.Comparable)var60);
//     var34.setMaximumItemCount(100);
//     boolean var64 = var1.equals((java.lang.Object)var34);
//     int var65 = var1.toSerial();
//     var1.setDescription("Value");
//     org.jfree.data.time.FixedMillisecond var70 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var71 = var70.getFirstMillisecond();
//     java.util.Calendar var72 = null;
//     long var73 = var70.getMiddleMillisecond(var72);
//     java.util.Calendar var74 = null;
//     long var75 = var70.getFirstMillisecond(var74);
//     org.jfree.data.time.RegularTimePeriod var76 = var70.next();
//     java.util.Date var77 = var70.getTime();
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var77);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var78);
//     org.jfree.data.time.FixedMillisecond var82 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var83 = var82.getFirstMillisecond();
//     java.util.Calendar var84 = null;
//     long var85 = var82.getMiddleMillisecond(var84);
//     java.util.Calendar var86 = null;
//     long var87 = var82.getFirstMillisecond(var86);
//     org.jfree.data.time.RegularTimePeriod var88 = var82.next();
//     java.util.Date var89 = var82.getTime();
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.createInstance(var89);
//     org.jfree.data.time.SerialDate var91 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var90);
//     org.jfree.data.time.SerialDate var92 = var79.getEndOfCurrentMonth(var91);
//     boolean var93 = var1.isAfter(var79);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var95 = var79.getNearestDayOfWeek((-458));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test435"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Jan");

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test436"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January -457");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test437"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-571));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test438"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var2.removeChangeListener(var7);
//     java.lang.Comparable var9 = var2.getKey();
//     var2.fireSeriesChanged();
//     var2.removeAgedItems(0L, false);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test439"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     int var27 = var26.getItemCount();
//     var26.setNotify(false);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     long var33 = var32.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var34 = var26.addAndOrUpdate(var32);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var37 = var36.getFirstMillisecond();
//     java.util.Calendar var38 = null;
//     long var39 = var36.getMiddleMillisecond(var38);
//     java.util.Calendar var40 = null;
//     long var41 = var36.getFirstMillisecond(var40);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.next();
//     java.util.Date var43 = var36.getTime();
//     org.jfree.data.time.Month var44 = new org.jfree.data.time.Month(var43);
//     int var45 = var44.getYearValue();
//     java.util.Date var46 = var44.getStart();
//     int var47 = var44.getYearValue();
//     org.jfree.data.time.TimeSeriesDataItem var49 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var44, 1.0d);
//     org.jfree.data.general.SeriesChangeListener var50 = null;
//     var26.removeChangeListener(var50);
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var53 = var52.next();
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var55);
//     var56.setDescription("");
//     var56.setDescription("Time");
//     boolean var61 = var52.equals((java.lang.Object)var56);
//     org.jfree.data.time.Month var62 = new org.jfree.data.time.Month();
//     long var63 = var62.getFirstMillisecond();
//     org.jfree.data.time.Year var64 = var62.getYear();
//     org.jfree.data.time.Year var65 = var62.getYear();
//     boolean var66 = var52.equals((java.lang.Object)var62);
//     java.lang.Class var68 = null;
//     org.jfree.data.time.TimeSeries var69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var68);
//     boolean var70 = var69.getNotify();
//     boolean var72 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var69, (java.lang.Object)true);
//     var69.clear();
//     boolean var74 = var69.getNotify();
//     java.lang.Class var76 = null;
//     org.jfree.data.time.TimeSeries var77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var76);
//     boolean var78 = var77.getNotify();
//     boolean var80 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var77, (java.lang.Object)true);
//     var77.clear();
//     java.util.Collection var82 = var69.getTimePeriodsUniqueToOtherSeries(var77);
//     org.jfree.data.time.TimeSeries var85 = var77.createCopy(10, 10);
//     boolean var86 = var52.equals((java.lang.Object)var77);
//     int var87 = var52.getDayOfMonth();
//     long var88 = var52.getSerialIndex();
//     long var89 = var52.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var90 = var26.getDataItem((org.jfree.data.time.RegularTimePeriod)var52);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var52, 10.0d);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test440"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Value", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test441"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getSerialIndex();
//     java.util.Date var24 = var22.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(0, var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(31, var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var36 = var35.getFirstMillisecond();
//     java.util.Calendar var37 = null;
//     long var38 = var35.getMiddleMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var35.getFirstMillisecond(var39);
//     org.jfree.data.time.RegularTimePeriod var41 = var35.next();
//     java.util.Date var42 = var35.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day(var43);
//     org.jfree.data.time.SerialDate var46 = var32.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var47 = var26.getEndOfCurrentMonth(var46);
//     boolean var48 = var1.isOn(var26);
//     int var49 = var1.getMonth();
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var53 = var52.next();
//     long var54 = var52.getLastMillisecond();
//     org.jfree.data.time.SerialDate var55 = var52.getSerialDate();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.addMonths(0, var55);
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addYears(1, var55);
//     boolean var58 = var1.isBefore(var57);
//     int var59 = var1.getDayOfWeek();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var61 = var1.getPreviousDayOfWeek((-41973));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 7);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test442"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getDayOfMonth();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getLastMillisecond(var5);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test443"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.lang.Object var7 = var2.clone();
    var2.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test444"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     boolean var6 = var5.getNotify();
//     boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)true);
//     var5.setMaximumItemCount(0);
//     java.util.Collection var11 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     java.beans.PropertyChangeListener var12 = null;
//     var5.addPropertyChangeListener(var12);
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
//     boolean var17 = var16.getNotify();
//     var16.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var16.getDataItem((org.jfree.data.time.RegularTimePeriod)var20);
//     var16.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.String var24 = var16.getDomainDescription();
//     java.beans.PropertyChangeListener var25 = null;
//     var16.removePropertyChangeListener(var25);
//     org.jfree.data.time.TimeSeries var27 = var5.addAndOrUpdate(var16);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getFirstMillisecond();
//     long var31 = var29.getSerialIndex();
//     int var32 = var27.getIndex((org.jfree.data.time.RegularTimePeriod)var29);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getFirstMillisecond();
//     java.util.Calendar var36 = null;
//     long var37 = var34.getMiddleMillisecond(var36);
//     java.util.Calendar var38 = null;
//     long var39 = var34.getFirstMillisecond(var38);
//     org.jfree.data.time.RegularTimePeriod var40 = var34.next();
//     java.util.Date var41 = var34.getTime();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month(var41);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond(var41);
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond(var41);
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year(var41);
//     long var46 = var45.getFirstMillisecond();
//     int var47 = var45.getYear();
//     var27.add((org.jfree.data.time.RegularTimePeriod)var45, 100.0d, false);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test445"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     long var12 = var9.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var9.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test446"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getLastMillisecond();
//     long var21 = var19.getLastMillisecond();
//     long var22 = var19.getLastMillisecond();
//     java.lang.String var23 = var19.toString();
//     int var24 = var19.getMonth();
//     int var25 = var9.compareTo((java.lang.Object)var19);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9, "SerialDate.weekInMonthToString(): invalid code.", "December 2014", var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var29.addChangeListener(var30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var32 = var29.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "21-December-2014"+ "'", var23.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test447"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     java.lang.String var20 = var19.toString();
//     long var21 = var19.getLastMillisecond();
//     java.util.Calendar var22 = null;
//     var19.peg(var22);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, (-25544), 17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test449"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     org.jfree.data.general.SeriesChangeEvent var23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     java.util.List var31 = var26.getItems();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var33.getMiddleMillisecond(var39);
//     org.jfree.data.time.TimeSeriesDataItem var42 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var43 = var33.previous();
//     org.jfree.data.time.TimeSeries var44 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var22, var43);
//     var44.fireSeriesChanged();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var46, (java.lang.Number)100);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     int var51 = var49.compareTo((java.lang.Object)var50);
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     long var55 = var54.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var56 = null;
//     var54.addChangeListener(var56);
//     var54.fireSeriesChanged();
//     int var59 = var49.compareTo((java.lang.Object)var54);
//     org.jfree.data.time.TimeSeries var60 = var44.addAndOrUpdate(var54);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var63 = var54.createCopy(12, (-41973));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test450"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Sun Dec 21 01:14:38 PST 2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test451"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
    java.lang.String var2 = var1.toString();
    java.lang.Object var3 = var1.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10.0]"+ "'", var2.equals("org.jfree.data.general.SeriesChangeEvent[source=10.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0f+ "'", var3.equals(10.0f));

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test452"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     long var6 = var5.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var7 = var5.previous();
//     int var8 = var5.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test453"); }


    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getSerialIndex();
    java.util.Date var6 = var4.getTime();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(31, var8);
    var8.setDescription("Time");
    org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var8);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(0, var8);
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var13);
    java.lang.String var15 = var13.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test454"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     boolean var8 = var2.getNotify();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     boolean var12 = var11.getNotify();
//     boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)true);
//     var11.clear();
//     boolean var16 = var11.getNotify();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     boolean var20 = var19.getNotify();
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)true);
//     var19.clear();
//     java.util.Collection var24 = var11.getTimePeriodsUniqueToOtherSeries(var19);
//     org.jfree.data.general.SeriesChangeListener var25 = null;
//     var11.removeChangeListener(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var30);
//     var31.setDescription("");
//     var31.setDescription("Time");
//     boolean var36 = var27.equals((java.lang.Object)var31);
//     int var37 = var27.getMonth();
//     var11.setKey((java.lang.Comparable)var37);
//     org.jfree.data.time.TimeSeries var39 = var2.addAndOrUpdate(var11);
//     var2.removeAgedItems(1419153270582L, true);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test455"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2147483647, 10, 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test456"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var16 = var15.getSerialIndex();
//     java.util.Date var17 = var15.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getFirstMillisecond();
//     java.util.Calendar var23 = null;
//     long var24 = var21.getMiddleMillisecond(var23);
//     java.util.Calendar var25 = null;
//     long var26 = var21.getFirstMillisecond(var25);
//     org.jfree.data.time.RegularTimePeriod var27 = var21.next();
//     java.util.Date var28 = var21.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var29);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var29);
//     org.jfree.data.time.SerialDate var32 = var18.getEndOfCurrentMonth(var29);
//     boolean var33 = var0.equals((java.lang.Object)var29);
//     org.jfree.data.time.RegularTimePeriod var34 = var0.next();
//     java.lang.String var35 = var0.toString();
//     java.lang.String var36 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "21-December-2014"+ "'", var35.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "21-December-2014"+ "'", var36.equals("21-December-2014"));
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test457"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test458"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
    java.util.Date var3 = var2.toDate();
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
    long var9 = var8.getSerialIndex();
    java.util.Date var10 = var8.getTime();
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(0, var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addYears(31, var12);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(31, var12);
    boolean var15 = var2.isOnOrAfter(var14);
    org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
    long var18 = var17.getSerialIndex();
    java.util.Date var19 = var17.getTime();
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
    org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1L);
    long var24 = var23.getFirstMillisecond();
    java.util.Calendar var25 = null;
    long var26 = var23.getMiddleMillisecond(var25);
    java.util.Calendar var27 = null;
    long var28 = var23.getFirstMillisecond(var27);
    org.jfree.data.time.RegularTimePeriod var29 = var23.next();
    java.util.Date var30 = var23.getTime();
    org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
    org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var31);
    org.jfree.data.time.Day var33 = new org.jfree.data.time.Day(var31);
    org.jfree.data.time.SerialDate var34 = var20.getEndOfCurrentMonth(var31);
    boolean var35 = var2.isOn(var31);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addDays(21, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test459"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setNotify(false);
//     var2.removeAgedItems(true);
//     java.util.List var14 = var2.getItems();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var18 = var17.getFirstMillisecond();
//     java.util.Calendar var19 = null;
//     long var20 = var17.getMiddleMillisecond(var19);
//     java.util.Calendar var21 = null;
//     long var22 = var17.getFirstMillisecond(var21);
//     org.jfree.data.time.RegularTimePeriod var23 = var17.next();
//     java.util.Date var24 = var17.getTime();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(var24);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(var24);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month(var24);
//     java.util.TimeZone var28 = null;
//     org.jfree.data.time.RegularTimePeriod var29 = org.jfree.data.time.RegularTimePeriod.createInstance(var15, var24, var28);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(var24);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var24);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year(var24);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)17, true);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test460"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     boolean var8 = var2.getNotify();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     boolean var12 = var11.getNotify();
//     boolean var14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)true);
//     var11.clear();
//     boolean var16 = var11.getNotify();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     boolean var20 = var19.getNotify();
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)true);
//     var19.clear();
//     java.util.Collection var24 = var11.getTimePeriodsUniqueToOtherSeries(var19);
//     org.jfree.data.general.SeriesChangeListener var25 = null;
//     var11.removeChangeListener(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var30);
//     var31.setDescription("");
//     var31.setDescription("Time");
//     boolean var36 = var27.equals((java.lang.Object)var31);
//     int var37 = var27.getMonth();
//     var11.setKey((java.lang.Comparable)var37);
//     org.jfree.data.time.TimeSeries var39 = var2.addAndOrUpdate(var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var41 = var39.getValue((-570));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test461"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.clear();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getMiddleMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var10.getFirstMillisecond(var14);
//     org.jfree.data.time.RegularTimePeriod var16 = var10.next();
//     java.util.Date var17 = var10.getTime();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var17);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(var17);
//     long var21 = var20.getFirstMillisecond();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     boolean var31 = var22.equals((java.lang.Object)var26);
//     var26.fireSeriesChanged();
//     boolean var33 = var26.isEmpty();
//     java.util.List var34 = var26.getItems();
//     int var35 = var20.compareTo((java.lang.Object)var26);
//     org.jfree.data.time.RegularTimePeriod var36 = var20.next();
//     var2.add(var36, 10.0d, false);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test462"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.String var12 = var10.toString();
//     org.jfree.data.time.RegularTimePeriod var13 = var10.previous();
//     int var14 = var10.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "December 1969"+ "'", var12.equals("December 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 12);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test463"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test464"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("31-December-1969");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
    var1.addSuppressed((java.lang.Throwable)var3);
    java.lang.Throwable[] var5 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test465"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getLastMillisecond();
//     long var21 = var19.getLastMillisecond();
//     long var22 = var19.getLastMillisecond();
//     java.lang.String var23 = var19.toString();
//     int var24 = var19.getMonth();
//     int var25 = var9.compareTo((java.lang.Object)var19);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9, "SerialDate.weekInMonthToString(): invalid code.", "December 2014", var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     int var40 = var30.getMonth();
//     long var41 = var30.getFirstMillisecond();
//     long var42 = var30.getFirstMillisecond();
//     int var43 = var30.getYear();
//     long var44 = var30.getLastMillisecond();
//     var29.delete((org.jfree.data.time.RegularTimePeriod)var30);
//     long var46 = var30.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "21-December-2014"+ "'", var23.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1419235199999L);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test466"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test467"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     var2.setMaximumItemAge(28799999L);
//     boolean var9 = var2.getNotify();
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     var14.setDescription("");
//     var14.setDescription("Time");
//     boolean var19 = var10.equals((java.lang.Object)var14);
//     int var20 = var10.getMonth();
//     long var21 = var10.getFirstMillisecond();
//     long var22 = var10.getFirstMillisecond();
//     int var23 = var10.getDayOfMonth();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var10, 0.0d, false);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test468"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var14);
//     var15.setDescription("");
//     var15.setDescription("Time");
//     boolean var20 = var11.equals((java.lang.Object)var15);
//     int var21 = var11.getMonth();
//     long var22 = var11.getFirstMillisecond();
//     long var23 = var11.getFirstMillisecond();
//     int var24 = var11.getDayOfMonth();
//     long var25 = var11.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var26 = var11.next();
//     var8.setKey((java.lang.Comparable)var11);
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var29);
//     java.lang.String var31 = var30.getDomainDescription();
//     var30.clear();
//     var30.setMaximumItemAge(1419153269727L);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var36 = var35.next();
//     java.lang.Class var38 = null;
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var38);
//     var39.setDescription("");
//     var39.setDescription("Time");
//     boolean var44 = var35.equals((java.lang.Object)var39);
//     int var45 = var35.getMonth();
//     long var46 = var35.getFirstMillisecond();
//     long var47 = var35.getFirstMillisecond();
//     int var48 = var35.getDayOfMonth();
//     java.lang.Number var49 = null;
//     org.jfree.data.time.TimeSeriesDataItem var50 = var30.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, var49);
//     long var51 = var35.getFirstMillisecond();
//     int var52 = var35.getMonth();
//     java.lang.Number var53 = null;
//     var8.add((org.jfree.data.time.RegularTimePeriod)var35, var53, true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test470"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.String var5 = var2.getDescription();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     boolean var9 = var8.getNotify();
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
//     boolean var14 = var8.getNotify();
//     java.lang.Class var15 = var8.getTimePeriodClass();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)100);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     int var21 = var19.compareTo((java.lang.Object)var20);
//     org.jfree.data.time.RegularTimePeriod var22 = var19.getPeriod();
//     var8.add(var19, false);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test471"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sun Dec 21 01:14:50 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test472"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sun Dec 21 01:14:55 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test473"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getFirstMillisecond();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getMiddleMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var4.getFirstMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var4.next();
//     java.util.Date var11 = var4.getTime();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
//     boolean var14 = var1.isAfter(var13);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var20 = var19.getSerialIndex();
//     java.util.Date var21 = var19.getTime();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(0, var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(31, var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var27 = var26.getSerialIndex();
//     java.util.Date var28 = var26.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var33 = var32.getFirstMillisecond();
//     java.util.Calendar var34 = null;
//     long var35 = var32.getMiddleMillisecond(var34);
//     java.util.Calendar var36 = null;
//     long var37 = var32.getFirstMillisecond(var36);
//     org.jfree.data.time.RegularTimePeriod var38 = var32.next();
//     java.util.Date var39 = var32.getTime();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day(var40);
//     org.jfree.data.time.SerialDate var43 = var29.getEndOfCurrentMonth(var40);
//     org.jfree.data.time.SerialDate var44 = var23.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addYears(1969, var23);
//     java.lang.String var46 = var45.toString();
//     org.jfree.data.time.SerialDate var47 = var1.getEndOfCurrentMonth(var45);
//     int var48 = var1.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var53 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var54 = var53.getSerialIndex();
//     java.util.Date var55 = var53.getTime();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addYears(0, var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addYears(31, var57);
//     org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var61 = var60.getSerialIndex();
//     java.util.Date var62 = var60.getTime();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var67 = var66.getFirstMillisecond();
//     java.util.Calendar var68 = null;
//     long var69 = var66.getMiddleMillisecond(var68);
//     java.util.Calendar var70 = null;
//     long var71 = var66.getFirstMillisecond(var70);
//     org.jfree.data.time.RegularTimePeriod var72 = var66.next();
//     java.util.Date var73 = var66.getTime();
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var73);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var74);
//     org.jfree.data.time.Day var76 = new org.jfree.data.time.Day(var74);
//     org.jfree.data.time.SerialDate var77 = var63.getEndOfCurrentMonth(var74);
//     org.jfree.data.time.SerialDate var78 = var57.getEndOfCurrentMonth(var77);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.addYears(1969, var57);
//     java.lang.String var80 = var79.toString();
//     boolean var81 = var1.isOnOrAfter(var79);
//     int var82 = var1.getMonth();
//     boolean var84 = var1.equals((java.lang.Object)9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "31-December-3938"+ "'", var46.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var80 + "' != '" + "31-December-3938"+ "'", var80.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test474"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths(0, var4);
//     var5.setDescription("Following");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test475"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var6);
//     var7.setDescription("");
//     var7.setDescription("Time");
//     boolean var12 = var3.equals((java.lang.Object)var7);
//     int var13 = var3.getMonth();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
//     boolean var17 = var3.equals((java.lang.Object)var15);
//     boolean var18 = var0.equals((java.lang.Object)var15);
//     java.util.Calendar var19 = null;
//     long var20 = var0.getLastMillisecond(var19);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test476"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     java.lang.String var6 = var2.getDescription();
//     int var7 = var2.getItemCount();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.next();
//     java.util.Date var16 = var9.getTime();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(var16);
//     long var18 = var17.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var19 = var17.next();
//     org.jfree.data.time.RegularTimePeriod var20 = var17.previous();
//     java.lang.Number var21 = var2.getValue(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test477"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test478"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.time.TimeSeries var50 = var42.createCopy(10, 10);
//     boolean var51 = var30.equals((java.lang.Object)var50);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     long var56 = var54.getLastMillisecond();
//     org.jfree.data.time.SerialDate var57 = var54.getSerialDate();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addMonths(0, var57);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.addYears(1, var57);
//     var59.setDescription("Sun Dec 21 01:14:31 PST 2014");
//     boolean var62 = var30.isAfter(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test479"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     java.lang.String var6 = var2.getDescription();
//     int var7 = var2.getItemCount();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.String var18 = var10.getDomainDescription();
//     java.beans.PropertyChangeListener var19 = null;
//     var10.removePropertyChangeListener(var19);
//     java.util.Collection var21 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, (-457));
//     java.lang.String var25 = var24.toString();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1419153273057L);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test480"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var9);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var9);
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.RegularTimePeriod var14 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var9, var13);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var9);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     long var17 = var16.getFirstMillisecond();
//     org.jfree.data.time.Year var18 = var16.getYear();
//     org.jfree.data.time.Year var19 = var16.getYear();
//     java.lang.Object var20 = null;
//     boolean var21 = var16.equals(var20);
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1419153269727L);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var23, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var26);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var29 = var28.next();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)100);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     int var33 = var31.compareTo((java.lang.Object)var32);
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var35);
//     long var37 = var36.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var36.addChangeListener(var38);
//     var36.fireSeriesChanged();
//     int var41 = var31.compareTo((java.lang.Object)var36);
//     int var42 = var36.getItemCount();
//     int var43 = var23.compareTo((java.lang.Object)var42);
//     boolean var44 = var15.equals((java.lang.Object)var43);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var47 = var46.getFirstMillisecond();
//     java.util.Calendar var48 = null;
//     long var49 = var46.getMiddleMillisecond(var48);
//     java.util.Calendar var50 = null;
//     long var51 = var46.getFirstMillisecond(var50);
//     org.jfree.data.time.RegularTimePeriod var52 = var46.next();
//     java.util.Date var53 = var46.getTime();
//     java.util.Calendar var54 = null;
//     var46.peg(var54);
//     int var56 = var15.compareTo((java.lang.Object)var46);
//     long var57 = var46.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1L);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test481"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var34.removeChangeListener(var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     var54.setDescription("");
//     var54.setDescription("Time");
//     boolean var59 = var50.equals((java.lang.Object)var54);
//     int var60 = var50.getMonth();
//     var34.setKey((java.lang.Comparable)var60);
//     var34.setMaximumItemCount(100);
//     boolean var64 = var1.equals((java.lang.Object)var34);
//     int var65 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var67 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var68 = var67.getSerialIndex();
//     java.util.Date var69 = var67.getTime();
//     java.util.Date var70 = var67.getTime();
//     org.jfree.data.time.Month var71 = new org.jfree.data.time.Month(var70);
//     org.jfree.data.time.SerialDate var72 = org.jfree.data.time.SerialDate.createInstance(var70);
//     int var73 = var1.compare(var72);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var75 = var72.getPreviousDayOfWeek((-452));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == (-25547));
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test482"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var24 = var23.getSerialIndex();
//     java.util.Date var25 = var23.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(0, var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addYears(31, var27);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var31 = var30.getSerialIndex();
//     java.util.Date var32 = var30.getTime();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var37 = var36.getFirstMillisecond();
//     java.util.Calendar var38 = null;
//     long var39 = var36.getMiddleMillisecond(var38);
//     java.util.Calendar var40 = null;
//     long var41 = var36.getFirstMillisecond(var40);
//     org.jfree.data.time.RegularTimePeriod var42 = var36.next();
//     java.util.Date var43 = var36.getTime();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(var43);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var44);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day(var44);
//     org.jfree.data.time.SerialDate var47 = var33.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.SerialDate var48 = var27.getEndOfCurrentMonth(var47);
//     boolean var49 = var2.isOn(var27);
//     int var50 = var2.getMonth();
//     org.jfree.data.time.Day var53 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var54 = var53.next();
//     long var55 = var53.getLastMillisecond();
//     org.jfree.data.time.SerialDate var56 = var53.getSerialDate();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addMonths(0, var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addYears(1, var56);
//     boolean var59 = var2.isBefore(var58);
//     int var60 = var2.getDayOfMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-41973), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 20);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test483"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
// 
//   }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test484"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-598));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test485"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = var10.getYear();
//     org.jfree.data.time.Year var13 = var10.getYear();
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     boolean var18 = var17.getNotify();
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)true);
//     var17.clear();
//     boolean var22 = var17.getNotify();
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var24);
//     boolean var26 = var25.getNotify();
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var25, (java.lang.Object)true);
//     var25.clear();
//     java.util.Collection var30 = var17.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.TimeSeries var33 = var25.createCopy(10, 10);
//     boolean var34 = var0.equals((java.lang.Object)var25);
//     org.jfree.data.time.RegularTimePeriod var35 = var0.next();
//     org.jfree.data.time.SerialDate var36 = var0.getSerialDate();
//     org.jfree.data.time.SerialDate var37 = var0.getSerialDate();
//     java.util.Calendar var38 = null;
//     var0.peg(var38);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test486"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.String var10 = var2.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(0, (-6654));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test487"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.beans.PropertyChangeListener var7 = null;
    var2.addPropertyChangeListener(var7);
    var2.removeAgedItems(false);
    var2.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test488"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Last");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test489"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     int var8 = var2.getItemCount();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var11 = null;
//     long var12 = var10.getLastMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var10.getLastMillisecond(var13);
//     boolean var15 = var2.equals((java.lang.Object)var10);
//     java.util.Date var16 = var10.getTime();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(var16);
//     long var18 = var17.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 23640L);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test490"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     long var8 = var6.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var9 = var6.next();
//     java.util.Date var10 = var9.getStart();
//     java.util.TimeZone var11 = null;
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var10, var11);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test491"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     java.lang.String var6 = var5.getDomainDescription();
//     var5.clear();
//     boolean var8 = var2.equals((java.lang.Object)var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var11 = var5.createCopy((-1), 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "Time"+ "'", var6.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test492"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test493"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    java.util.Calendar var4 = null;
    long var5 = var1.getLastMillisecond(var4);
    long var6 = var1.getMiddleMillisecond();
    java.util.Date var7 = var1.getStart();
    long var8 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-76589164800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-76589164800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-76589164800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-76589164800000L));

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test494"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     var10.setDescription("");
//     var10.setDescription("Time");
//     boolean var15 = var6.equals((java.lang.Object)var10);
//     int var16 = var6.getMonth();
//     long var17 = var6.getSerialIndex();
//     java.util.Date var18 = var6.getEnd();
//     int var19 = var0.compareTo((java.lang.Object)var6);
//     long var20 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var21 = var0.next();
//     java.util.Calendar var22 = null;
//     long var23 = var0.getFirstMillisecond(var22);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test495"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     boolean var6 = var5.getNotify();
//     boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)true);
//     var5.setMaximumItemCount(0);
//     java.util.Collection var11 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     java.beans.PropertyChangeListener var12 = null;
//     var5.addPropertyChangeListener(var12);
//     java.lang.String var14 = var5.getDescription();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     long var17 = var15.getLastMillisecond();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var20 = var19.getSerialIndex();
//     java.util.Date var21 = var19.getTime();
//     java.util.Date var22 = var19.getTime();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var22);
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (-1.0d));
//     org.jfree.data.time.RegularTimePeriod var26 = var23.previous();
//     int var27 = var15.compareTo((java.lang.Object)var23);
//     int var28 = var5.getIndex((org.jfree.data.time.RegularTimePeriod)var15);
//     org.jfree.data.time.RegularTimePeriod var29 = var15.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test496"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var2.addChangeListener(var10);
    var2.setMaximumItemCount(12);
    var2.setDescription("21-December-2014");
    java.util.Collection var16 = var2.getTimePeriods();
    java.util.Collection var17 = org.jfree.chart.util.ObjectUtilities.deepClone(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test497"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var7 = var4.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
//     boolean var10 = var2.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var14);
//     var15.setDescription("");
//     var15.setDescription("Time");
//     boolean var20 = var11.equals((java.lang.Object)var15);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     long var22 = var21.getFirstMillisecond();
//     org.jfree.data.time.Year var23 = var21.getYear();
//     org.jfree.data.time.Year var24 = var21.getYear();
//     boolean var25 = var11.equals((java.lang.Object)var21);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     int var29 = var28.getItemCount();
//     var28.setNotify(false);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     long var35 = var34.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var36 = var28.addAndOrUpdate(var34);
//     java.lang.Comparable var37 = var28.getKey();
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var39 = var38.previous();
//     java.lang.String var40 = var38.toString();
//     org.jfree.data.time.RegularTimePeriod var41 = var38.next();
//     var28.setKey((java.lang.Comparable)var38);
//     var28.setDomainDescription("");
//     int var45 = var21.compareTo((java.lang.Object)var28);
//     int var46 = var21.getYearValue();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)1969L);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test498"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var0.previous();
//     org.jfree.data.time.SerialDate var14 = var0.getSerialDate();
//     java.lang.String var15 = var0.toString();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "org.jfree.data.general.SeriesChangeEvent[source=false]", "October", var18);
//     int var20 = var0.getMonth();
//     java.util.Calendar var21 = null;
//     var0.peg(var21);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest1.test499"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var4 = var2.getTimePeriod(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest1.test500"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var37 = var36.getSerialIndex();
//     java.util.Date var38 = var36.getTime();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addYears(0, var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.addYears(31, var40);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var44 = var43.getSerialIndex();
//     java.util.Date var45 = var43.getTime();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getFirstMillisecond();
//     java.util.Calendar var51 = null;
//     long var52 = var49.getMiddleMillisecond(var51);
//     java.util.Calendar var53 = null;
//     long var54 = var49.getFirstMillisecond(var53);
//     org.jfree.data.time.RegularTimePeriod var55 = var49.next();
//     java.util.Date var56 = var49.getTime();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var57);
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day(var57);
//     org.jfree.data.time.SerialDate var60 = var46.getEndOfCurrentMonth(var57);
//     org.jfree.data.time.SerialDate var61 = var40.getEndOfCurrentMonth(var60);
//     boolean var62 = var2.isBefore(var60);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addYears((-455), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
// 
//   }

}
