
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var8);
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     int var14 = var12.getYear();
//     org.jfree.data.time.RegularTimePeriod var15 = var12.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    var2.setMaximumItemCount(0);
    var2.clear();
    int var13 = var2.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Date var13 = var6.getTime();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
//     boolean var16 = var3.isAfter(var15);
//     boolean var17 = var1.isBefore(var15);
//     int var18 = var1.getYYYY();
//     int var19 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     long var26 = var24.getLastMillisecond();
//     org.jfree.data.time.SerialDate var27 = var24.getSerialDate();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addMonths(0, var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addYears(1, var27);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     long var33 = var31.getLastMillisecond();
//     org.jfree.data.time.SerialDate var34 = var31.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(0, var34);
//     org.jfree.data.time.SerialDate var37 = var35.getPreviousDayOfWeek(4);
//     boolean var38 = var21.isInRange(var27, var35);
//     org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var42 = var41.toDate();
//     org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var48 = var47.getSerialIndex();
//     java.util.Date var49 = var47.getTime();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addYears(0, var50);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.addYears(31, var51);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addMonths(31, var51);
//     boolean var54 = var41.isOnOrAfter(var53);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.addMonths((-455), var53);
//     boolean var56 = var21.isOn(var55);
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var60 = var59.toDate();
//     org.jfree.data.time.FixedMillisecond var65 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var66 = var65.getSerialIndex();
//     java.util.Date var67 = var65.getTime();
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.addYears(0, var68);
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.addYears(31, var69);
//     org.jfree.data.time.SerialDate var71 = org.jfree.data.time.SerialDate.addMonths(31, var69);
//     boolean var72 = var59.isOnOrAfter(var71);
//     org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.addMonths((-455), var71);
//     boolean var75 = var1.isInRange((org.jfree.data.time.SerialDate)var21, var73, (-455));
//     int var76 = var21.toSerial();
//     int var77 = var21.getMonth();
//     int var78 = var21.getMonth();
//     org.jfree.data.time.Day var79 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var80 = var79.next();
//     long var81 = var79.getLastMillisecond();
//     org.jfree.data.time.SerialDate var82 = var79.getSerialDate();
//     boolean var83 = var21.isOnOrAfter(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
// 
//   }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     long var10 = var0.getLastMillisecond();
//     int var11 = var0.getMonth();
//     org.jfree.data.time.SerialDate var12 = var0.getSerialDate();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     java.lang.Number var13 = null;
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, var13);
//     org.jfree.data.time.SerialDate var15 = var11.getSerialDate();
//     java.util.Calendar var16 = null;
//     long var17 = var11.getFirstMillisecond(var16);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.next();
//     org.jfree.data.time.SerialDate var5 = var0.getSerialDate();
//     java.lang.String var6 = var5.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
    long var7 = var1.getLastMillisecond();
    java.util.Date var8 = var1.getStart();
    java.util.Calendar var9 = null;
    var1.peg(var9);
    java.util.Date var11 = var1.getTime();
    java.util.Calendar var12 = null;
    long var13 = var1.getFirstMillisecond(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)1419153269727L);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var13 = var11.getTimePeriod(6);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     var10.setDescription("");
//     var10.setDescription("Time");
//     boolean var15 = var6.equals((java.lang.Object)var10);
//     int var16 = var6.getMonth();
//     long var17 = var6.getSerialIndex();
//     java.util.Date var18 = var6.getEnd();
//     int var19 = var0.compareTo((java.lang.Object)var6);
//     long var20 = var0.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var21 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var22 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-454));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     var5.setValue((java.lang.Number)1419153270723L);
//     java.lang.Object var8 = var5.clone();
//     org.jfree.data.time.RegularTimePeriod var9 = var5.getPeriod();
//     org.jfree.data.time.RegularTimePeriod var10 = var5.getPeriod();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     var10.setNotify(false);
//     var10.setDomainDescription("Sun Dec 21 01:14:34 PST 2014");
//     int var15 = var10.getItemCount();
//     int var16 = var10.getMaximumItemCount();
//     java.util.Collection var17 = var10.getTimePeriods();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     long var29 = var18.getFirstMillisecond();
//     long var30 = var18.getFirstMillisecond();
//     int var31 = var18.getYear();
//     long var32 = var18.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var33 = var18.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.update(var33, (java.lang.Number)1419153293121L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var10 = var2.getDataItem(1948);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    java.lang.Comparable var9 = var2.getKey();
    java.lang.Class var10 = var2.getTimePeriodClass();
    java.beans.PropertyChangeListener var11 = null;
    var2.removePropertyChangeListener(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 100.0f+ "'", var9.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    long var3 = var1.getMiddleMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
    var5.setValue((java.lang.Number)1.0f);
    var5.setValue((java.lang.Number)31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var4 = var3.getSerialIndex();
//     java.util.Date var5 = var3.getTime();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.next();
//     java.util.Date var16 = var9.getTime();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.SerialDate var20 = var6.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.SerialDate var22 = var20.getFollowingDayOfWeek(4);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)100);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)var27);
//     var26.setValue((java.lang.Number)1388563200000L);
//     var26.setValue((java.lang.Number)(byte)0);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getLastMillisecond();
//     org.jfree.data.time.SerialDate var37 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var37);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var46 = var45.getFirstMillisecond();
//     java.util.Calendar var47 = null;
//     long var48 = var45.getMiddleMillisecond(var47);
//     java.util.Calendar var49 = null;
//     long var50 = var45.getFirstMillisecond(var49);
//     org.jfree.data.time.RegularTimePeriod var51 = var45.next();
//     java.util.Date var52 = var45.getTime();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var53);
//     boolean var55 = var42.isAfter(var54);
//     boolean var56 = var40.isBefore(var54);
//     org.jfree.data.time.SerialDate var57 = var37.getEndOfCurrentMonth(var54);
//     int var58 = var26.compareTo((java.lang.Object)var37);
//     boolean var60 = var1.isInRange(var20, var37, (-459));
//     java.lang.String var61 = var1.toString();
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var63 = var62.next();
//     java.lang.Class var65 = null;
//     org.jfree.data.time.TimeSeries var66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var65);
//     var66.setDescription("");
//     var66.setDescription("Time");
//     boolean var71 = var62.equals((java.lang.Object)var66);
//     int var72 = var62.getMonth();
//     long var73 = var62.getFirstMillisecond();
//     long var74 = var62.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var75 = var62.previous();
//     org.jfree.data.time.SerialDate var76 = var62.getSerialDate();
//     boolean var77 = var1.equals((java.lang.Object)var76);
//     int var78 = var1.getDayOfWeek();
//     int var79 = var1.getYYYY();
//     org.jfree.data.time.Day var80 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     var1.setDescription("Sun Dec 21 01:15:26 PST 2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-January-1900"+ "'", var61.equals("20-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1900);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"org.jfree.data.general.SeriesException: Sun Dec 21 01:14:33 PST 2014");

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)100);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     int var25 = var23.compareTo((java.lang.Object)var24);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     long var29 = var28.getMaximumItemAge();
//     int var30 = var23.compareTo((java.lang.Object)var28);
//     boolean var31 = var2.equals((java.lang.Object)var28);
//     int var32 = var2.getMonth();
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var34 = var33.next();
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var36);
//     var37.setDescription("");
//     var37.setDescription("Time");
//     boolean var42 = var33.equals((java.lang.Object)var37);
//     int var43 = var33.getMonth();
//     long var44 = var33.getFirstMillisecond();
//     long var45 = var33.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var46 = var33.getSerialDate();
//     boolean var47 = var2.isBefore(var46);
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addDays(17, (org.jfree.data.time.SerialDate)var2);
//     var48.setDescription("Time");
//     org.jfree.data.time.FixedMillisecond var52 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var53 = var52.getSerialIndex();
//     java.util.Date var54 = var52.getTime();
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(var54);
//     org.jfree.data.time.FixedMillisecond var58 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var59 = var58.getFirstMillisecond();
//     java.util.Calendar var60 = null;
//     long var61 = var58.getMiddleMillisecond(var60);
//     java.util.Calendar var62 = null;
//     long var63 = var58.getFirstMillisecond(var62);
//     org.jfree.data.time.RegularTimePeriod var64 = var58.next();
//     java.util.Date var65 = var58.getTime();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var65);
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var66);
//     org.jfree.data.time.Day var68 = new org.jfree.data.time.Day(var66);
//     org.jfree.data.time.SerialDate var69 = var55.getEndOfCurrentMonth(var66);
//     org.jfree.data.time.SerialDate var71 = var69.getFollowingDayOfWeek(4);
//     org.jfree.data.time.SerialDate var72 = var48.getEndOfCurrentMonth(var71);
//     java.lang.Class var73 = null;
//     org.jfree.data.time.TimeSeries var74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var48, var73);
//     java.beans.PropertyChangeListener var75 = null;
//     var74.addPropertyChangeListener(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var4, var6);
//     java.beans.PropertyChangeListener var8 = null;
//     var7.removePropertyChangeListener(var8);
//     boolean var10 = var7.isEmpty();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     var13.setDescription("");
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var18 = null;
//     long var19 = var17.getLastMillisecond(var18);
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, 0.0d);
//     java.util.Date var22 = var17.getTime();
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var25 = null;
//     long var26 = var24.getLastMillisecond(var25);
//     java.lang.String var27 = var24.toString();
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getFirstMillisecond();
//     java.util.Calendar var31 = null;
//     long var32 = var29.getMiddleMillisecond(var31);
//     java.util.Calendar var33 = null;
//     long var34 = var29.getFirstMillisecond(var33);
//     org.jfree.data.time.RegularTimePeriod var35 = var29.next();
//     java.util.Date var36 = var29.getTime();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(var36);
//     org.jfree.data.time.RegularTimePeriod var39 = var38.next();
//     boolean var40 = var24.equals((java.lang.Object)var39);
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1L);
//     java.lang.Object var43 = var42.clone();
//     org.jfree.data.time.RegularTimePeriod var44 = var42.getPeriod();
//     boolean var45 = var17.equals((java.lang.Object)var42);
//     var7.add(var42);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     long var12 = var10.getSerialIndex();
//     java.util.Calendar var13 = null;
//     long var14 = var10.getFirstMillisecond(var13);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var3 = var2.toDate();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var9 = var8.getSerialIndex();
//     java.util.Date var10 = var8.getTime();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(0, var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addYears(31, var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(31, var12);
//     boolean var15 = var2.isOnOrAfter(var14);
//     var2.setDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     long var21 = var19.getLastMillisecond();
//     org.jfree.data.time.SerialDate var22 = var19.getSerialDate();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addMonths(0, var22);
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var29 = var28.getSerialIndex();
//     java.util.Date var30 = var28.getTime();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(0, var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addYears(31, var32);
//     var32.setDescription("Time");
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day(var32);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addMonths(0, var32);
//     boolean var39 = var2.isInRange(var22, var37, 1993);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1948);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getYear();
//     long var14 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 41994L);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Sun Dec 21 01:14:46 PST 2014", var1);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var4 = var3.getSerialIndex();
//     java.util.Date var5 = var3.getTime();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.next();
//     java.util.Date var16 = var9.getTime();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.SerialDate var20 = var6.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.SerialDate var22 = var20.getFollowingDayOfWeek(4);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)100);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)var27);
//     var26.setValue((java.lang.Number)1388563200000L);
//     var26.setValue((java.lang.Number)(byte)0);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getLastMillisecond();
//     org.jfree.data.time.SerialDate var37 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var37);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var46 = var45.getFirstMillisecond();
//     java.util.Calendar var47 = null;
//     long var48 = var45.getMiddleMillisecond(var47);
//     java.util.Calendar var49 = null;
//     long var50 = var45.getFirstMillisecond(var49);
//     org.jfree.data.time.RegularTimePeriod var51 = var45.next();
//     java.util.Date var52 = var45.getTime();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var53);
//     boolean var55 = var42.isAfter(var54);
//     boolean var56 = var40.isBefore(var54);
//     org.jfree.data.time.SerialDate var57 = var37.getEndOfCurrentMonth(var54);
//     int var58 = var26.compareTo((java.lang.Object)var37);
//     boolean var60 = var1.isInRange(var20, var37, (-459));
//     java.lang.String var61 = var1.toString();
//     int var62 = var1.toSerial();
//     java.lang.String var63 = var1.toString();
//     java.lang.Class var66 = null;
//     org.jfree.data.time.TimeSeries var67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var63, "Sun Dec 21 01:16:00 PST 2014", "", var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-January-1900"+ "'", var61.equals("20-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "20-January-1900"+ "'", var63.equals("20-January-1900"));
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var34.removeChangeListener(var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     var54.setDescription("");
//     var54.setDescription("Time");
//     boolean var59 = var50.equals((java.lang.Object)var54);
//     int var60 = var50.getMonth();
//     var34.setKey((java.lang.Comparable)var60);
//     var34.setMaximumItemCount(100);
//     boolean var64 = var1.equals((java.lang.Object)var34);
//     int var65 = var1.toSerial();
//     var1.setDescription("Value");
//     org.jfree.data.time.SerialDate var69 = var1.getFollowingDayOfWeek(2);
//     var1.setDescription("Sun Dec 21 01:14:56 PST 2014");
//     java.lang.Class var72 = null;
//     org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1, var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(20);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.addDays(1948, var2);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1948, var4);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getFirstMillisecond();
//     long var8 = var6.getLastMillisecond();
//     int var9 = var6.getMonth();
//     org.jfree.data.time.Year var10 = var6.getYear();
//     java.lang.Number var11 = var5.getValue((org.jfree.data.time.RegularTimePeriod)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getSerialIndex();
//     java.util.Date var6 = var4.getTime();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getMiddleMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var10.getFirstMillisecond(var14);
//     org.jfree.data.time.RegularTimePeriod var16 = var10.next();
//     java.util.Date var17 = var10.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var18);
//     org.jfree.data.time.SerialDate var21 = var7.getEndOfCurrentMonth(var18);
//     org.jfree.data.time.SerialDate var23 = var21.getFollowingDayOfWeek(4);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)100);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     int var29 = var27.compareTo((java.lang.Object)var28);
//     var27.setValue((java.lang.Number)1388563200000L);
//     var27.setValue((java.lang.Number)(byte)0);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var36 = var35.next();
//     long var37 = var35.getLastMillisecond();
//     org.jfree.data.time.SerialDate var38 = var35.getSerialDate();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var38);
//     org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var47 = var46.getFirstMillisecond();
//     java.util.Calendar var48 = null;
//     long var49 = var46.getMiddleMillisecond(var48);
//     java.util.Calendar var50 = null;
//     long var51 = var46.getFirstMillisecond(var50);
//     org.jfree.data.time.RegularTimePeriod var52 = var46.next();
//     java.util.Date var53 = var46.getTime();
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.createInstance(var53);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var54);
//     boolean var56 = var43.isAfter(var55);
//     boolean var57 = var41.isBefore(var55);
//     org.jfree.data.time.SerialDate var58 = var38.getEndOfCurrentMonth(var55);
//     int var59 = var27.compareTo((java.lang.Object)var38);
//     boolean var61 = var2.isInRange(var21, var38, (-459));
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     java.lang.String var63 = var62.toString();
//     org.jfree.data.time.RegularTimePeriod var64 = var62.previous();
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var67 = var66.getSerialIndex();
//     java.util.Date var68 = var66.getTime();
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.createInstance(var68);
//     org.jfree.data.time.FixedMillisecond var72 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var73 = var72.getFirstMillisecond();
//     java.util.Calendar var74 = null;
//     long var75 = var72.getMiddleMillisecond(var74);
//     java.util.Calendar var76 = null;
//     long var77 = var72.getFirstMillisecond(var76);
//     org.jfree.data.time.RegularTimePeriod var78 = var72.next();
//     java.util.Date var79 = var72.getTime();
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(var79);
//     org.jfree.data.time.SerialDate var81 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var80);
//     org.jfree.data.time.Day var82 = new org.jfree.data.time.Day(var80);
//     org.jfree.data.time.SerialDate var83 = var69.getEndOfCurrentMonth(var80);
//     int var84 = var62.compareTo((java.lang.Object)var83);
//     org.jfree.data.time.Day var85 = new org.jfree.data.time.Day(var83);
//     boolean var86 = var2.isOnOrAfter(var83);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var87 = org.jfree.data.time.SerialDate.addMonths((-10638), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "2014"+ "'", var63.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == false);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.next();
//     java.util.Date var5 = var0.getEnd();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var5);
//     int var7 = var6.getYear();
//     long var8 = var6.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var9 = var6.next();
//     java.util.Calendar var10 = null;
//     long var11 = var9.getMiddleMillisecond(var10);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     long var3 = var2.getFirstMillisecond();
//     org.jfree.data.time.Year var4 = var2.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var6);
//     java.lang.String var8 = var7.getDomainDescription();
//     var7.clear();
//     boolean var10 = var4.equals((java.lang.Object)var7);
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 10.0d);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)100);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     int var18 = var16.compareTo((java.lang.Object)var17);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var20);
//     long var22 = var21.getMaximumItemAge();
//     int var23 = var16.compareTo((java.lang.Object)var21);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     java.lang.String var27 = var26.getDomainDescription();
//     var26.clear();
//     boolean var29 = var16.equals((java.lang.Object)var26);
//     java.lang.Object var30 = var16.clone();
//     var16.setValue((java.lang.Number)1419153292657L);
//     int var33 = var12.compareTo((java.lang.Object)var16);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var36 = var35.getSerialIndex();
//     java.util.Date var37 = var35.getTime();
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year(var37);
//     org.jfree.data.time.FixedMillisecond var40 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var41 = var40.getFirstMillisecond();
//     java.util.Calendar var42 = null;
//     long var43 = var40.getMiddleMillisecond(var42);
//     java.util.Calendar var44 = null;
//     long var45 = var40.getFirstMillisecond(var44);
//     org.jfree.data.time.RegularTimePeriod var46 = var40.next();
//     java.util.Calendar var47 = null;
//     long var48 = var40.getFirstMillisecond(var47);
//     org.jfree.data.time.RegularTimePeriod var49 = var40.previous();
//     int var50 = var38.compareTo((java.lang.Object)var40);
//     long var51 = var40.getMiddleMillisecond();
//     java.util.Date var52 = var40.getTime();
//     boolean var53 = var12.equals((java.lang.Object)var52);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year(var52);
//     boolean var55 = var0.equals((java.lang.Object)var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "Time"+ "'", var8.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "Time"+ "'", var27.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     var14.setDescription("");
//     var14.setDescription("Time");
//     boolean var19 = var10.equals((java.lang.Object)var14);
//     int var20 = var10.getMonth();
//     long var21 = var10.getLastMillisecond();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     long var23 = var22.getFirstMillisecond();
//     org.jfree.data.time.Year var24 = var22.getYear();
//     long var25 = var22.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var26 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var10, (org.jfree.data.time.RegularTimePeriod)var22);
//     java.lang.Comparable var27 = var26.getKey();
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var26.addChangeListener(var28);
//     int var30 = var26.getItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + 100.0f+ "'", var27.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)' ');
    var1.setRangeDescription("31-December-3938");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete(4, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     boolean var27 = var26.getNotify();
//     boolean var29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, (java.lang.Object)true);
//     var26.clear();
//     boolean var31 = var26.getNotify();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     java.util.Collection var39 = var26.getTimePeriodsUniqueToOtherSeries(var34);
//     org.jfree.data.general.SeriesChangeListener var40 = null;
//     var26.removeChangeListener(var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     java.lang.Class var45 = null;
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var45);
//     var46.setDescription("");
//     var46.setDescription("Time");
//     boolean var51 = var42.equals((java.lang.Object)var46);
//     int var52 = var42.getMonth();
//     var26.setKey((java.lang.Comparable)var52);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     java.lang.Class var57 = null;
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var57);
//     var58.setDescription("");
//     var58.setDescription("Time");
//     boolean var63 = var54.equals((java.lang.Object)var58);
//     java.util.Collection var64 = var26.getTimePeriodsUniqueToOtherSeries(var58);
//     org.jfree.data.general.SeriesChangeEvent var65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var26);
//     org.jfree.data.time.TimeSeries var66 = var23.addAndOrUpdate(var26);
//     java.lang.String var67 = var26.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419153325057L);
//     java.util.Date var2 = var1.getTime();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2, var3);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     long var2 = var1.getFirstMillisecond();
//     org.jfree.data.time.Year var3 = var1.getYear();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     java.lang.String var7 = var6.getDomainDescription();
//     var6.clear();
//     boolean var9 = var3.equals((java.lang.Object)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var10 = new org.jfree.data.time.Month((-605), var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "Time"+ "'", var7.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     java.lang.Comparable var11 = var2.getKey();
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.previous();
//     java.lang.String var14 = var12.toString();
//     org.jfree.data.time.RegularTimePeriod var15 = var12.next();
//     var2.setKey((java.lang.Comparable)var12);
//     var2.removeAgedItems(true);
//     java.lang.String var19 = var2.getRangeDescription();
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var23);
//     var24.setDescription("");
//     var24.setDescription("Time");
//     boolean var29 = var20.equals((java.lang.Object)var24);
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month();
//     long var31 = var30.getFirstMillisecond();
//     org.jfree.data.time.Year var32 = var30.getYear();
//     org.jfree.data.time.Year var33 = var30.getYear();
//     boolean var34 = var20.equals((java.lang.Object)var30);
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var36);
//     boolean var38 = var37.getNotify();
//     boolean var40 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var37, (java.lang.Object)true);
//     var37.clear();
//     boolean var42 = var37.getNotify();
//     java.lang.Class var44 = null;
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var44);
//     boolean var46 = var45.getNotify();
//     boolean var48 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var45, (java.lang.Object)true);
//     var45.clear();
//     java.util.Collection var50 = var37.getTimePeriodsUniqueToOtherSeries(var45);
//     org.jfree.data.time.TimeSeries var53 = var45.createCopy(10, 10);
//     boolean var54 = var20.equals((java.lang.Object)var45);
//     org.jfree.data.time.RegularTimePeriod var55 = var20.next();
//     long var56 = var20.getMiddleMillisecond();
//     int var57 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var20);
//     java.beans.PropertyChangeListener var58 = null;
//     var2.addPropertyChangeListener(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 100.0f+ "'", var11.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "Sun Dec 21 01:16:07 PST 2014"+ "'", var14.equals("Sun Dec 21 01:16:07 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "Value"+ "'", var19.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419191999999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == (-1));
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.previous();
//     java.lang.String var21 = var19.toString();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     long var29 = var27.getLastMillisecond();
//     org.jfree.data.time.SerialDate var30 = var27.getSerialDate();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addMonths(0, var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(1, var30);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getLastMillisecond();
//     org.jfree.data.time.SerialDate var37 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addMonths(0, var37);
//     org.jfree.data.time.SerialDate var40 = var38.getPreviousDayOfWeek(4);
//     boolean var41 = var24.isInRange(var30, var38);
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, (java.lang.Number)100);
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     int var47 = var45.compareTo((java.lang.Object)var46);
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     long var51 = var50.getMaximumItemAge();
//     int var52 = var45.compareTo((java.lang.Object)var50);
//     boolean var53 = var24.equals((java.lang.Object)var50);
//     int var54 = var24.getMonth();
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var56 = var55.next();
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var58);
//     var59.setDescription("");
//     var59.setDescription("Time");
//     boolean var64 = var55.equals((java.lang.Object)var59);
//     int var65 = var55.getMonth();
//     long var66 = var55.getFirstMillisecond();
//     long var67 = var55.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var68 = var55.getSerialDate();
//     boolean var69 = var24.isBefore(var68);
//     org.jfree.data.time.FixedMillisecond var72 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var73 = var72.getSerialIndex();
//     java.util.Date var74 = var72.getTime();
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(var74);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.addYears(0, var75);
//     boolean var77 = var24.isOnOrBefore(var76);
//     java.util.Date var78 = var24.toDate();
//     int var79 = var19.compareTo((java.lang.Object)var24);
//     org.jfree.data.time.FixedMillisecond var82 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var83 = var82.getFirstMillisecond();
//     java.util.Calendar var84 = null;
//     long var85 = var82.getMiddleMillisecond(var84);
//     java.util.Calendar var86 = null;
//     long var87 = var82.getFirstMillisecond(var86);
//     org.jfree.data.time.RegularTimePeriod var88 = var82.next();
//     java.util.Date var89 = var82.getTime();
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.createInstance(var89);
//     org.jfree.data.time.SerialDate var91 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var90);
//     org.jfree.data.time.Day var92 = new org.jfree.data.time.Day(var90);
//     boolean var93 = var1.isInRange((org.jfree.data.time.SerialDate)var24, var90);
//     java.lang.String var94 = var1.getDescription();
//     int var95 = var1.getDayOfWeek();
//     int var96 = var1.toSerial();
//     java.lang.String var97 = var1.toString();
//     org.jfree.data.time.SerialDate var98 = null;
//     boolean var99 = var1.isOnOrBefore(var98);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getSerialIndex();
//     java.util.Date var24 = var22.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(0, var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(31, var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var36 = var35.getFirstMillisecond();
//     java.util.Calendar var37 = null;
//     long var38 = var35.getMiddleMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var35.getFirstMillisecond(var39);
//     org.jfree.data.time.RegularTimePeriod var41 = var35.next();
//     java.util.Date var42 = var35.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day(var43);
//     org.jfree.data.time.SerialDate var46 = var32.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var47 = var26.getEndOfCurrentMonth(var46);
//     boolean var48 = var1.isOn(var26);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     long var52 = var50.getLastMillisecond();
//     org.jfree.data.time.SerialDate var53 = var50.getSerialDate();
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var53);
//     int var55 = var1.compare(var53);
//     java.util.Date var56 = var1.toDate();
//     org.jfree.data.time.SerialDate var57 = null;
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var63 = var62.next();
//     long var64 = var62.getLastMillisecond();
//     org.jfree.data.time.SerialDate var65 = var62.getSerialDate();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addMonths(0, var65);
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.addYears(1, var65);
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var70 = var69.next();
//     long var71 = var69.getLastMillisecond();
//     org.jfree.data.time.SerialDate var72 = var69.getSerialDate();
//     org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.addMonths(0, var72);
//     org.jfree.data.time.SerialDate var75 = var73.getPreviousDayOfWeek(4);
//     boolean var76 = var59.isInRange(var65, var73);
//     int var77 = var59.getMonth();
//     int var78 = var59.getYYYY();
//     boolean var79 = var1.isInRange(var57, (org.jfree.data.time.SerialDate)var59);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     long var3 = var2.getMiddleMillisecond();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1372795199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2014);
//     var1.setDescription("Sun Dec 21 01:14:51 PST 2014");
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var9 = var8.getFirstMillisecond();
//     java.util.Calendar var10 = null;
//     long var11 = var8.getMiddleMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var8.getFirstMillisecond(var12);
//     org.jfree.data.time.RegularTimePeriod var14 = var8.next();
//     java.util.Date var15 = var8.getTime();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var16);
//     boolean var18 = var5.isAfter(var17);
//     boolean var19 = var1.isAfter((org.jfree.data.time.SerialDate)var5);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     long var26 = var24.getLastMillisecond();
//     org.jfree.data.time.SerialDate var27 = var24.getSerialDate();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addMonths(0, var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addYears(1, var27);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     long var33 = var31.getLastMillisecond();
//     org.jfree.data.time.SerialDate var34 = var31.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(0, var34);
//     org.jfree.data.time.SerialDate var37 = var35.getPreviousDayOfWeek(4);
//     boolean var38 = var21.isInRange(var27, var35);
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var43 = var42.getSerialIndex();
//     java.util.Date var44 = var42.getTime();
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(var44);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addYears(0, var45);
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.addYears(31, var46);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getSerialIndex();
//     java.util.Date var51 = var49.getTime();
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var51);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var56 = var55.getFirstMillisecond();
//     java.util.Calendar var57 = null;
//     long var58 = var55.getMiddleMillisecond(var57);
//     java.util.Calendar var59 = null;
//     long var60 = var55.getFirstMillisecond(var59);
//     org.jfree.data.time.RegularTimePeriod var61 = var55.next();
//     java.util.Date var62 = var55.getTime();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var63);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day(var63);
//     org.jfree.data.time.SerialDate var66 = var52.getEndOfCurrentMonth(var63);
//     org.jfree.data.time.SerialDate var67 = var46.getEndOfCurrentMonth(var66);
//     boolean var68 = var21.isOn(var46);
//     var21.setDescription("");
//     int var71 = var21.getMonth();
//     org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.createInstance(1900);
//     boolean var74 = var21.isOn(var73);
//     boolean var75 = var1.isBefore((org.jfree.data.time.SerialDate)var21);
//     int var76 = var1.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 7);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Sun Dec 21 01:15:13 PST 2014");
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     var2.removeAgedItems(false);
//     java.beans.PropertyChangeListener var6 = null;
//     var2.addPropertyChangeListener(var6);
//     boolean var8 = var2.isEmpty();
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     var13.setDescription("");
//     var13.setDescription("Time");
//     boolean var18 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.RegularTimePeriod var19 = var9.next();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var9, 10.0d);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 31-December-1969"+ "'", var2.equals("org.jfree.data.time.TimePeriodFormatException: 31-December-1969"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 31-December-1969"+ "'", var3.equals("org.jfree.data.time.TimePeriodFormatException: 31-December-1969"));

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     boolean var8 = var2.getNotify();
//     java.lang.String var9 = var2.getRangeDescription();
//     var2.fireSeriesChanged();
//     var2.setRangeDescription("Sun Dec 21 01:14:49 PST 2014");
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var14);
//     boolean var16 = var15.getNotify();
//     boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var15, (java.lang.Object)true);
//     var15.clear();
//     boolean var20 = var15.getNotify();
//     java.lang.Class var22 = null;
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var22);
//     boolean var24 = var23.getNotify();
//     boolean var26 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var23, (java.lang.Object)true);
//     var23.clear();
//     java.util.Collection var28 = var15.getTimePeriodsUniqueToOtherSeries(var23);
//     org.jfree.data.general.SeriesChangeListener var29 = null;
//     var15.removeChangeListener(var29);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var34);
//     var35.setDescription("");
//     var35.setDescription("Time");
//     boolean var40 = var31.equals((java.lang.Object)var35);
//     int var41 = var31.getMonth();
//     var15.setKey((java.lang.Comparable)var41);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var44 = var43.next();
//     java.lang.Class var46 = null;
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var46);
//     var47.setDescription("");
//     var47.setDescription("Time");
//     boolean var52 = var43.equals((java.lang.Object)var47);
//     java.util.Collection var53 = var15.getTimePeriodsUniqueToOtherSeries(var47);
//     org.jfree.data.general.SeriesChangeEvent var54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var15);
//     java.beans.PropertyChangeListener var55 = null;
//     var15.addPropertyChangeListener(var55);
//     boolean var57 = var15.getNotify();
//     var15.setMaximumItemCount(20);
//     org.jfree.data.general.SeriesChangeListener var60 = null;
//     var15.removeChangeListener(var60);
//     var15.setDomainDescription("Sun Dec 21 01:15:22 PST 2014");
//     org.jfree.data.time.TimeSeries var64 = var2.addAndOrUpdate(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "Value"+ "'", var9.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Sun Dec 21 01:15:08 PST 2014");
    java.lang.Throwable[] var2 = var1.getSuppressed();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.String var12 = var10.toString();
//     org.jfree.data.time.RegularTimePeriod var13 = var10.previous();
//     java.lang.String var14 = var10.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "December 1969"+ "'", var12.equals("December 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "December 1969"+ "'", var14.equals("December 1969"));
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.next();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     long var18 = var16.getLastMillisecond();
//     org.jfree.data.time.SerialDate var19 = var16.getSerialDate();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var19);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var19, var21);
//     boolean var23 = var11.equals((java.lang.Object)var21);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var26 = var25.getFirstMillisecond();
//     java.util.Calendar var27 = null;
//     long var28 = var25.getMiddleMillisecond(var27);
//     java.util.Calendar var29 = null;
//     long var30 = var25.getFirstMillisecond(var29);
//     org.jfree.data.time.RegularTimePeriod var31 = var25.next();
//     java.util.Date var32 = var25.getTime();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var32);
//     int var34 = var33.getYearValue();
//     java.util.Date var35 = var33.getStart();
//     int var36 = var33.getYearValue();
//     boolean var37 = var11.equals((java.lang.Object)var33);
//     org.jfree.data.time.TimeSeriesDataItem var38 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     var2.removeAgedItems(false);
//     java.lang.Comparable var41 = var2.getKey();
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond();
//     long var43 = var42.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var44 = var42.next();
//     var2.delete(var44);
//     java.lang.Class var46 = null;
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var44, var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + 100.0f+ "'", var41.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419153367411L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419153365206L);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var4 = var3.getSerialIndex();
//     java.util.Date var5 = var3.getTime();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.next();
//     java.util.Date var16 = var9.getTime();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.SerialDate var20 = var6.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.SerialDate var22 = var20.getFollowingDayOfWeek(4);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)100);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)var27);
//     var26.setValue((java.lang.Number)1388563200000L);
//     var26.setValue((java.lang.Number)(byte)0);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getLastMillisecond();
//     org.jfree.data.time.SerialDate var37 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var37);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var46 = var45.getFirstMillisecond();
//     java.util.Calendar var47 = null;
//     long var48 = var45.getMiddleMillisecond(var47);
//     java.util.Calendar var49 = null;
//     long var50 = var45.getFirstMillisecond(var49);
//     org.jfree.data.time.RegularTimePeriod var51 = var45.next();
//     java.util.Date var52 = var45.getTime();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var53);
//     boolean var55 = var42.isAfter(var54);
//     boolean var56 = var40.isBefore(var54);
//     org.jfree.data.time.SerialDate var57 = var37.getEndOfCurrentMonth(var54);
//     int var58 = var26.compareTo((java.lang.Object)var37);
//     boolean var60 = var1.isInRange(var20, var37, (-459));
//     java.lang.String var61 = var1.toString();
//     org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var67 = var66.getFirstMillisecond();
//     java.util.Calendar var68 = null;
//     long var69 = var66.getMiddleMillisecond(var68);
//     java.util.Calendar var70 = null;
//     long var71 = var66.getFirstMillisecond(var70);
//     org.jfree.data.time.RegularTimePeriod var72 = var66.next();
//     java.util.Date var73 = var66.getTime();
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var73);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var74);
//     boolean var76 = var63.isAfter(var75);
//     int var77 = var63.toSerial();
//     boolean var78 = var1.isAfter((org.jfree.data.time.SerialDate)var63);
//     java.lang.String var79 = var1.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-January-1900"+ "'", var61.equals("20-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.util.List var7 = var2.getItems();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
    long var10 = var9.getFirstMillisecond();
    java.util.Calendar var11 = null;
    long var12 = var9.getMiddleMillisecond(var11);
    java.util.Calendar var13 = null;
    long var14 = var9.getFirstMillisecond(var13);
    java.util.Calendar var15 = null;
    long var16 = var9.getMiddleMillisecond(var15);
    org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
    org.jfree.data.time.RegularTimePeriod var19 = var9.previous();
    java.lang.Class var21 = null;
    org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
    boolean var23 = var22.getNotify();
    boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)true);
    var22.clear();
    boolean var27 = var22.getNotify();
    java.beans.PropertyChangeListener var28 = null;
    var22.removePropertyChangeListener(var28);
    var22.setNotify(false);
    java.lang.String var32 = var22.getDomainDescription();
    java.lang.String var33 = var22.getDomainDescription();
    java.util.Collection var34 = var22.getTimePeriods();
    boolean var35 = var9.equals((java.lang.Object)var34);
    java.util.Calendar var36 = null;
    long var37 = var9.getMiddleMillisecond(var36);
    org.jfree.data.time.RegularTimePeriod var38 = var9.next();
    java.util.Calendar var39 = null;
    var9.peg(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "Time"+ "'", var32.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "Time"+ "'", var33.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     java.util.Date var5 = var3.getEnd();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "17-December-2014", "Wed Dec 31 16:00:00 PST 1969", var3);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Date var13 = var6.getTime();
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(var13);
//     long var15 = var14.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var16 = var14.next();
//     org.jfree.data.time.RegularTimePeriod var17 = var14.previous();
//     int var18 = var0.compareTo((java.lang.Object)var14);
//     long var19 = var14.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var14.next();
//     java.util.Calendar var21 = null;
//     var14.peg(var21);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     boolean var8 = var2.getNotify();
//     java.lang.String var9 = var2.getRangeDescription();
//     java.util.List var10 = var2.getItems();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     int var15 = var11.getMonth();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var11);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     long var20 = var19.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var21 = null;
//     var19.addChangeListener(var21);
//     var19.fireSeriesChanged();
//     java.lang.String var24 = var19.getDescription();
//     var19.removeAgedItems(false);
//     org.jfree.data.time.TimeSeries var27 = var2.addAndOrUpdate(var19);
//     var19.setNotify(false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "Value"+ "'", var9.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     var5.setDescription("");
//     var5.setDescription("Time");
//     boolean var10 = var1.equals((java.lang.Object)var5);
//     int var11 = var1.getMonth();
//     long var12 = var1.getFirstMillisecond();
//     long var13 = var1.getFirstMillisecond();
//     int var14 = var1.getDayOfMonth();
//     long var15 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var16 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addYears(12, var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sun Dec 21 01:14:46 PST 2014", var1);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getLastMillisecond();
//     long var12 = var10.getLastMillisecond();
//     long var13 = var10.getLastMillisecond();
//     java.lang.String var14 = var10.toString();
//     int var15 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var10);
//     boolean var17 = var2.equals((java.lang.Object)28799999L);
//     java.lang.String var18 = var2.getDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var20 = var2.getTimePeriod(6);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "21-December-2014"+ "'", var14.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     var2.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=false]");
//     java.lang.String var14 = var2.getRangeDescription();
//     boolean var15 = var2.isEmpty();
//     long var16 = var2.getMaximumItemAge();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     long var18 = var17.getFirstMillisecond();
//     org.jfree.data.time.Year var19 = var17.getYear();
//     org.jfree.data.time.Year var20 = var17.getYear();
//     java.lang.Object var21 = null;
//     boolean var22 = var17.equals(var21);
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)1419153269727L);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var24);
//     boolean var26 = var2.equals((java.lang.Object)var24);
//     org.jfree.data.general.SeriesChangeListener var27 = null;
//     var2.removeChangeListener(var27);
//     java.util.List var29 = var2.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "Value"+ "'", var14.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getMiddleMillisecond();
//     long var5 = var2.getLastMillisecond();
//     boolean var6 = var0.equals((java.lang.Object)var5);
//     java.util.Calendar var7 = null;
//     long var8 = var0.getFirstMillisecond(var7);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var2 = var1.toDate();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var8 = var7.getSerialIndex();
//     java.util.Date var9 = var7.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(31, var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(31, var11);
//     boolean var14 = var1.isOnOrAfter(var13);
//     var1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var19 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     long var21 = var20.getLastMillisecond();
//     long var22 = var20.getLastMillisecond();
//     int var23 = var20.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var24 = var20.next();
//     java.util.Date var25 = var20.getEnd();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year(var25);
//     int var27 = var26.getYear();
//     long var28 = var26.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var29 = var26.next();
//     boolean var30 = var18.equals((java.lang.Object)var26);
//     int var31 = var18.toSerial();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 13);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "17-December-2014", "Wed Dec 31 16:00:00 PST 1969", var3);
//     org.jfree.data.time.TimeSeries var7 = var4.createCopy(0, 13);
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var7.removeChangeListener(var8);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var11);
//     boolean var13 = var12.getNotify();
//     var12.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var12.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
//     var12.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     long var21 = var20.getLastMillisecond();
//     long var22 = var20.getLastMillisecond();
//     long var23 = var20.getLastMillisecond();
//     java.lang.String var24 = var20.toString();
//     int var25 = var12.getIndex((org.jfree.data.time.RegularTimePeriod)var20);
//     boolean var27 = var12.equals((java.lang.Object)28799999L);
//     var12.setRangeDescription("Last");
//     int var30 = var12.getItemCount();
//     java.lang.String var31 = var12.getDomainDescription();
//     org.jfree.data.time.TimeSeries var32 = var7.addAndOrUpdate(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "21-December-2014"+ "'", var24.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "Time"+ "'", var31.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
//     org.jfree.data.time.RegularTimePeriod var11 = var5.next();
//     java.util.Date var12 = var5.getTime();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var13);
//     boolean var15 = var2.isAfter(var14);
//     int var16 = var2.toSerial();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     long var20 = var18.getLastMillisecond();
//     org.jfree.data.time.SerialDate var21 = var18.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var21, var23);
//     java.lang.String var25 = var21.getDescription();
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     long var32 = var30.getLastMillisecond();
//     org.jfree.data.time.SerialDate var33 = var30.getSerialDate();
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addMonths(0, var33);
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addYears(1, var33);
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var38 = var37.next();
//     long var39 = var37.getLastMillisecond();
//     org.jfree.data.time.SerialDate var40 = var37.getSerialDate();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.addMonths(0, var40);
//     org.jfree.data.time.SerialDate var43 = var41.getPreviousDayOfWeek(4);
//     boolean var44 = var27.isInRange(var33, var41);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     long var48 = var46.getLastMillisecond();
//     org.jfree.data.time.SerialDate var49 = var46.getSerialDate();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.addMonths(0, var49);
//     org.jfree.data.time.SerialDate var52 = var50.getPreviousDayOfWeek(4);
//     java.lang.String var53 = var52.toString();
//     java.lang.String var54 = var52.toString();
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var57 = var27.isInRange(var52, (org.jfree.data.time.SerialDate)var56);
//     java.util.Date var58 = var27.toDate();
//     boolean var59 = var2.isInRange(var21, (org.jfree.data.time.SerialDate)var27);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-459), var21);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "17-December-2014"+ "'", var53.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "17-December-2014"+ "'", var54.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == true);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var2.removeChangeListener(var30);
//     java.lang.Class var32 = var2.getTimePeriodClass();
//     java.lang.Class var33 = var2.getTimePeriodClass();
//     java.lang.Object var34 = var2.clone();
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var36);
//     java.lang.String var38 = var37.getDomainDescription();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var40 = var39.next();
//     long var41 = var39.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var42 = var39.next();
//     org.jfree.data.time.TimeSeriesDataItem var44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, 0.0d);
//     boolean var45 = var37.equals((java.lang.Object)var44);
//     org.jfree.data.time.TimeSeries var46 = var2.addAndOrUpdate(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "Time"+ "'", var38.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.previous();
//     java.lang.String var21 = var19.toString();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     long var29 = var27.getLastMillisecond();
//     org.jfree.data.time.SerialDate var30 = var27.getSerialDate();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addMonths(0, var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(1, var30);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getLastMillisecond();
//     org.jfree.data.time.SerialDate var37 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addMonths(0, var37);
//     org.jfree.data.time.SerialDate var40 = var38.getPreviousDayOfWeek(4);
//     boolean var41 = var24.isInRange(var30, var38);
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, (java.lang.Number)100);
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     int var47 = var45.compareTo((java.lang.Object)var46);
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     long var51 = var50.getMaximumItemAge();
//     int var52 = var45.compareTo((java.lang.Object)var50);
//     boolean var53 = var24.equals((java.lang.Object)var50);
//     int var54 = var24.getMonth();
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var56 = var55.next();
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var58);
//     var59.setDescription("");
//     var59.setDescription("Time");
//     boolean var64 = var55.equals((java.lang.Object)var59);
//     int var65 = var55.getMonth();
//     long var66 = var55.getFirstMillisecond();
//     long var67 = var55.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var68 = var55.getSerialDate();
//     boolean var69 = var24.isBefore(var68);
//     org.jfree.data.time.FixedMillisecond var72 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var73 = var72.getSerialIndex();
//     java.util.Date var74 = var72.getTime();
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(var74);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.addYears(0, var75);
//     boolean var77 = var24.isOnOrBefore(var76);
//     java.util.Date var78 = var24.toDate();
//     int var79 = var19.compareTo((java.lang.Object)var24);
//     org.jfree.data.time.FixedMillisecond var82 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var83 = var82.getFirstMillisecond();
//     java.util.Calendar var84 = null;
//     long var85 = var82.getMiddleMillisecond(var84);
//     java.util.Calendar var86 = null;
//     long var87 = var82.getFirstMillisecond(var86);
//     org.jfree.data.time.RegularTimePeriod var88 = var82.next();
//     java.util.Date var89 = var82.getTime();
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.createInstance(var89);
//     org.jfree.data.time.SerialDate var91 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var90);
//     org.jfree.data.time.Day var92 = new org.jfree.data.time.Day(var90);
//     boolean var93 = var1.isInRange((org.jfree.data.time.SerialDate)var24, var90);
//     java.lang.String var94 = var1.getDescription();
//     var1.setDescription("org.jfree.data.time.TimePeriodFormatException: 2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Sun Dec 21 01:16:07 PST 2014"+ "'", var21.equals("Sun Dec 21 01:16:07 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var94);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: ");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.util.List var7 = var2.getItems();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
    long var10 = var9.getFirstMillisecond();
    java.util.Calendar var11 = null;
    long var12 = var9.getMiddleMillisecond(var11);
    java.util.Calendar var13 = null;
    long var14 = var9.getFirstMillisecond(var13);
    java.util.Calendar var15 = null;
    long var16 = var9.getMiddleMillisecond(var15);
    org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
    int var19 = var2.getMaximumItemCount();
    var2.fireSeriesChanged();
    java.util.Collection var21 = var2.getTimePeriods();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getFirstMillisecond(var11);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     long var10 = var0.getSerialIndex();
//     org.jfree.data.time.SerialDate var11 = var0.getSerialDate();
//     int var12 = var0.getMonth();
//     long var13 = var0.getFirstMillisecond();
//     int var15 = var0.compareTo((java.lang.Object)"Sun Dec 21 01:14:36 PST 2014");
//     long var16 = var0.getMiddleMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419191999999L);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     java.lang.String var7 = var6.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = var6.getNearestDayOfWeek(1969);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "31-December-1969"+ "'", var7.equals("31-December-1969"));
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)1L);
    java.util.Calendar var4 = null;
    long var5 = var1.getFirstMillisecond(var4);
    java.util.Date var6 = var1.getEnd();
    java.util.Calendar var7 = null;
    long var8 = var1.getFirstMillisecond(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(12, (-452));
    long var3 = var2.getSerialIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-5412L));

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Year var22 = var19.getYear();
//     org.jfree.data.general.SeriesChangeEvent var23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     java.util.List var31 = var26.getItems();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var33.getMiddleMillisecond(var39);
//     org.jfree.data.time.TimeSeriesDataItem var42 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var43 = var33.previous();
//     org.jfree.data.time.TimeSeries var44 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var22, var43);
//     var44.fireSeriesChanged();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var44.update(6, (java.lang.Number)1419153334474L);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     long var34 = var32.getLastMillisecond();
//     org.jfree.data.time.SerialDate var35 = var32.getSerialDate();
//     boolean var36 = var30.isOnOrAfter(var35);
//     java.lang.String var37 = var30.toString();
//     java.lang.String var38 = var30.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "20-January-1900"+ "'", var37.equals("20-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "20-January-1900"+ "'", var38.equals("20-January-1900"));
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)1419153269727L);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var15 = var12.next();
//     int var16 = var12.getYear();
//     var11.add((org.jfree.data.time.RegularTimePeriod)var12, 0.0d);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     java.lang.Comparable var11 = var2.getKey();
//     boolean var12 = var2.getNotify();
//     java.lang.Comparable var13 = var2.getKey();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
//     java.lang.String var17 = var16.getDomainDescription();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     long var20 = var18.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var21 = var18.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 0.0d);
//     boolean var24 = var16.equals((java.lang.Object)var23);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var30 = var29.next();
//     long var31 = var29.getLastMillisecond();
//     org.jfree.data.time.SerialDate var32 = var29.getSerialDate();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addMonths(0, var32);
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addYears(1, var32);
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var37 = var36.next();
//     long var38 = var36.getLastMillisecond();
//     org.jfree.data.time.SerialDate var39 = var36.getSerialDate();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addMonths(0, var39);
//     org.jfree.data.time.SerialDate var42 = var40.getPreviousDayOfWeek(4);
//     boolean var43 = var26.isInRange(var32, var40);
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var45 = var44.next();
//     org.jfree.data.time.TimeSeriesDataItem var47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (java.lang.Number)100);
//     org.jfree.data.time.Year var48 = new org.jfree.data.time.Year();
//     int var49 = var47.compareTo((java.lang.Object)var48);
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var51);
//     long var53 = var52.getMaximumItemAge();
//     int var54 = var47.compareTo((java.lang.Object)var52);
//     boolean var55 = var26.equals((java.lang.Object)var52);
//     int var56 = var23.compareTo((java.lang.Object)var55);
//     var2.add(var23, false);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var23 = var22.toDate();
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var29 = var28.getSerialIndex();
//     java.util.Date var30 = var28.getTime();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addYears(0, var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addYears(31, var32);
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addMonths(31, var32);
//     boolean var35 = var22.isOnOrAfter(var34);
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addMonths((-455), var34);
//     boolean var37 = var2.isOn(var36);
//     int var38 = var2.getYYYY();
//     int var39 = var2.getDayOfWeek();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(29, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 7);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    var2.setKey((java.lang.Comparable)10L);
    var2.setRangeDescription("");
    var2.setDescription("org.jfree.data.general.SeriesException: ThreadContext");
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(1L);
    long var15 = var14.getFirstMillisecond();
    java.util.Calendar var16 = null;
    long var17 = var14.getMiddleMillisecond(var16);
    java.util.Calendar var18 = null;
    long var19 = var14.getFirstMillisecond(var18);
    java.lang.Number var20 = null;
    org.jfree.data.time.TimeSeriesDataItem var21 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, var20);
    org.jfree.data.time.RegularTimePeriod var22 = var14.next();
    java.util.Calendar var23 = null;
    long var24 = var14.getLastMillisecond(var23);
    java.util.Calendar var25 = null;
    var14.peg(var25);
    java.util.Calendar var27 = null;
    long var28 = var14.getMiddleMillisecond(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1L);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     long var3 = var1.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     org.jfree.data.time.RegularTimePeriod var9 = var7.next();
//     boolean var10 = var5.equals((java.lang.Object)var7);
//     int var11 = var7.getYear();
//     java.util.Calendar var12 = null;
//     long var13 = var7.getFirstMillisecond(var12);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }
// 
// 
//     org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
//     org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var5 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var3.addSuppressed((java.lang.Throwable)var5);
//     org.jfree.data.general.SeriesException var8 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var10 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var8.addSuppressed((java.lang.Throwable)var10);
//     var5.addSuppressed((java.lang.Throwable)var8);
//     java.lang.Throwable[] var13 = var5.getSuppressed();
//     var1.addSuppressed((java.lang.Throwable)var5);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(1, var23);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     long var29 = var27.getLastMillisecond();
//     org.jfree.data.time.SerialDate var30 = var27.getSerialDate();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addMonths(0, var30);
//     org.jfree.data.time.SerialDate var33 = var31.getPreviousDayOfWeek(4);
//     boolean var34 = var17.isInRange(var23, var31);
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var36 = var35.next();
//     org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)100);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     int var40 = var38.compareTo((java.lang.Object)var39);
//     java.lang.Class var42 = null;
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var42);
//     long var44 = var43.getMaximumItemAge();
//     int var45 = var38.compareTo((java.lang.Object)var43);
//     boolean var46 = var17.equals((java.lang.Object)var43);
//     int var47 = var17.getMonth();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var49 = var48.next();
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var51);
//     var52.setDescription("");
//     var52.setDescription("Time");
//     boolean var57 = var48.equals((java.lang.Object)var52);
//     int var58 = var48.getMonth();
//     long var59 = var48.getFirstMillisecond();
//     long var60 = var48.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var61 = var48.getSerialDate();
//     boolean var62 = var17.isBefore(var61);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, (org.jfree.data.time.SerialDate)var17);
//     org.jfree.data.general.SeriesException var65 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var67 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var65.addSuppressed((java.lang.Throwable)var67);
//     java.lang.String var69 = var65.toString();
//     org.jfree.data.general.SeriesException var71 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var73 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var71.addSuppressed((java.lang.Throwable)var73);
//     org.jfree.data.general.SeriesException var76 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var78 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var76.addSuppressed((java.lang.Throwable)var78);
//     var73.addSuppressed((java.lang.Throwable)var76);
//     var65.addSuppressed((java.lang.Throwable)var76);
//     java.lang.Throwable[] var82 = var65.getSuppressed();
//     boolean var83 = var17.equals((java.lang.Object)var65);
//     var1.addSuppressed((java.lang.Throwable)var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var69 + "' != '" + "org.jfree.data.general.SeriesException: ThreadContext"+ "'", var69.equals("org.jfree.data.general.SeriesException: ThreadContext"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     long var4 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var9);
    org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var9);
    java.util.TimeZone var13 = null;
    org.jfree.data.time.RegularTimePeriod var14 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var9, var13);
    org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var9);
    java.util.Date var16 = var15.getTime();
    long var17 = var15.getLastMillisecond();
    java.util.Calendar var18 = null;
    long var19 = var15.getFirstMillisecond(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     boolean var8 = var2.getNotify();
//     java.lang.String var9 = var2.getRangeDescription();
//     java.util.List var10 = var2.getItems();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     int var15 = var11.getMonth();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var11);
//     int var17 = var11.getYear();
//     int var18 = var11.getDayOfMonth();
//     long var19 = var11.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "Value"+ "'", var9.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1419148800000L);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     var2.setDomainDescription("org.jfree.data.general.SeriesException: ThreadContext");
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     boolean var12 = var11.getNotify();
//     var11.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var11.getDataItem((org.jfree.data.time.RegularTimePeriod)var15);
//     long var17 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var19 = var15.previous();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (-1.0d));
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var2.addChangeListener(var22);
//     var2.fireSeriesChanged();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419153367951L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     boolean var4 = var0.equals((java.lang.Object)1419235199999L);
//     long var5 = var0.getSerialIndex();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     long var7 = var6.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var8 = var6.previous();
//     org.jfree.data.time.Year var9 = var6.getYear();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9);
//     org.jfree.data.time.TimeSeries var13 = var10.createCopy(100, 100);
//     var10.fireSeriesChanged();
//     int var15 = var0.compareTo((java.lang.Object)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)100);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     int var29 = var27.compareTo((java.lang.Object)var28);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     long var33 = var32.getMaximumItemAge();
//     int var34 = var27.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     boolean var36 = var27.equals((java.lang.Object)var35);
//     org.jfree.data.time.SerialDate var37 = var35.getSerialDate();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.TimeSeriesDataItem var40 = var22.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)1419153270690L);
//     long var41 = var35.getFirstMillisecond();
//     java.lang.String var42 = var35.toString();
//     org.jfree.data.time.RegularTimePeriod var43 = var35.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "21-December-2014"+ "'", var42.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("April");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     boolean var5 = var0.equals((java.lang.Object)(-571));
//     long var6 = var0.getFirstMillisecond();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var9 = var8.getSerialIndex();
//     java.util.Date var10 = var8.getTime();
//     java.util.Date var11 = var8.getTime();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var11);
//     boolean var15 = var0.equals((java.lang.Object)var11);
//     java.util.Date var16 = var0.getStart();
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var16, var17);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getSerialIndex();
    java.util.Date var3 = var1.getTime();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getFirstMillisecond();
    java.util.Calendar var9 = null;
    long var10 = var7.getMiddleMillisecond(var9);
    java.util.Calendar var11 = null;
    long var12 = var7.getFirstMillisecond(var11);
    org.jfree.data.time.RegularTimePeriod var13 = var7.next();
    java.util.Date var14 = var7.getTime();
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var4.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var20 = var18.getFollowingDayOfWeek(4);
    java.lang.String var21 = var20.getDescription();
    var20.setDescription("org.jfree.data.general.SeriesChangeEvent[source=10.0]");
    org.jfree.data.time.SerialDate var25 = var20.getNearestDayOfWeek(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    var2.setMaximumItemAge(28799999L);
    var2.setRangeDescription("ThreadContext");
    java.lang.String var11 = var2.getDescription();
    var2.setMaximumItemCount(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Time"+ "'", var11.equals("Time"));

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     boolean var33 = var32.getNotify();
//     boolean var35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)true);
//     var32.clear();
//     boolean var37 = var32.getNotify();
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     org.jfree.data.general.SeriesChangeListener var40 = null;
//     var32.addChangeListener(var40);
//     java.util.List var42 = var32.getItems();
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     java.lang.String var44 = var43.toString();
//     org.jfree.data.time.RegularTimePeriod var45 = var43.previous();
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     var50.setDescription("");
//     var50.setDescription("Time");
//     boolean var55 = var46.equals((java.lang.Object)var50);
//     int var56 = var46.getMonth();
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var58);
//     boolean var60 = var46.equals((java.lang.Object)var58);
//     boolean var61 = var43.equals((java.lang.Object)var58);
//     int var62 = var32.getIndex((org.jfree.data.time.RegularTimePeriod)var43);
//     java.util.Collection var63 = var2.getTimePeriodsUniqueToOtherSeries(var32);
//     java.lang.Class var64 = var32.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var65 = null;
//     var32.addChangeListener(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "2014"+ "'", var44.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getSerialIndex();
//     java.util.Date var24 = var22.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(0, var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(31, var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var36 = var35.getFirstMillisecond();
//     java.util.Calendar var37 = null;
//     long var38 = var35.getMiddleMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var35.getFirstMillisecond(var39);
//     org.jfree.data.time.RegularTimePeriod var41 = var35.next();
//     java.util.Date var42 = var35.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day(var43);
//     org.jfree.data.time.SerialDate var46 = var32.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var47 = var26.getEndOfCurrentMonth(var46);
//     boolean var48 = var1.isOn(var26);
//     var1.setDescription("");
//     int var51 = var1.getMonth();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(1900);
//     boolean var54 = var1.isOn(var53);
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var56 = var1.getMonth();
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     org.jfree.data.time.SerialDate var58 = var57.getSerialDate();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var2 = var1.getDayOfWeek();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var8 = null;
//     long var9 = var7.getLastMillisecond(var8);
//     java.lang.String var10 = var7.toString();
//     long var11 = var7.getFirstMillisecond();
//     long var12 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)1419153270585L);
//     java.util.Calendar var15 = null;
//     var7.peg(var15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var1.compareTo((java.lang.Object)var7);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    int var8 = var2.getItemCount();
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var11 = null;
    long var12 = var10.getLastMillisecond(var11);
    java.util.Calendar var13 = null;
    long var14 = var10.getLastMillisecond(var13);
    boolean var15 = var2.equals((java.lang.Object)var10);
    java.util.Date var16 = var10.getTime();
    long var17 = var10.getFirstMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     long var8 = var6.getMiddleMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var6.getLastMillisecond(var9);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     boolean var14 = var13.getNotify();
//     boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)true);
//     var13.clear();
//     boolean var18 = var13.getNotify();
//     java.beans.PropertyChangeListener var19 = null;
//     var13.removePropertyChangeListener(var19);
//     org.jfree.data.general.SeriesChangeListener var21 = null;
//     var13.addChangeListener(var21);
//     java.util.List var23 = var13.getItems();
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.lang.String var25 = var24.toString();
//     org.jfree.data.time.RegularTimePeriod var26 = var24.previous();
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var28 = var27.next();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var30);
//     var31.setDescription("");
//     var31.setDescription("Time");
//     boolean var36 = var27.equals((java.lang.Object)var31);
//     int var37 = var27.getMonth();
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var39);
//     boolean var41 = var27.equals((java.lang.Object)var39);
//     boolean var42 = var24.equals((java.lang.Object)var39);
//     int var43 = var13.getIndex((org.jfree.data.time.RegularTimePeriod)var24);
//     int var44 = var6.compareTo((java.lang.Object)var43);
//     long var45 = var6.getLastMillisecond();
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     long var52 = var50.getLastMillisecond();
//     org.jfree.data.time.SerialDate var53 = var50.getSerialDate();
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addMonths(0, var53);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.addYears(1, var53);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var58 = var57.next();
//     long var59 = var57.getLastMillisecond();
//     org.jfree.data.time.SerialDate var60 = var57.getSerialDate();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.addMonths(0, var60);
//     org.jfree.data.time.SerialDate var63 = var61.getPreviousDayOfWeek(4);
//     boolean var64 = var47.isInRange(var53, var61);
//     int var65 = var47.getMonth();
//     int var66 = var47.toSerial();
//     int var67 = var47.getDayOfWeek();
//     boolean var68 = var6.equals((java.lang.Object)var47);
//     java.lang.String var69 = var6.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419153368179L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419153368179L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "2014"+ "'", var25.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419153368179L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var69 + "' != '" + "Sun Dec 21 01:16:08 PST 2014"+ "'", var69.equals("Sun Dec 21 01:16:08 PST 2014"));
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.next();
//     java.util.Date var5 = var0.getEnd();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var5);
//     int var7 = var6.getYear();
//     long var8 = var6.getFirstMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var6.getFirstMillisecond(var9);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
    java.util.Calendar var2 = null;
    var1.peg(var2);
    java.util.Date var4 = var1.getTime();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
    java.util.Date var7 = var1.getTime();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var8.addChangeListener(var10);
    var8.fireSeriesChanged();
    int var13 = var3.compareTo((java.lang.Object)var8);
    org.jfree.data.time.RegularTimePeriod var14 = var3.getPeriod();
    boolean var16 = var3.equals((java.lang.Object)1419153277541L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(17, 45, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getSerialIndex();
    java.util.Date var3 = var1.getTime();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var3);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    long var7 = var6.getFirstMillisecond();
    java.util.Calendar var8 = null;
    long var9 = var6.getMiddleMillisecond(var8);
    java.util.Calendar var10 = null;
    long var11 = var6.getFirstMillisecond(var10);
    org.jfree.data.time.RegularTimePeriod var12 = var6.next();
    java.util.Calendar var13 = null;
    long var14 = var6.getFirstMillisecond(var13);
    org.jfree.data.time.RegularTimePeriod var15 = var6.previous();
    int var16 = var4.compareTo((java.lang.Object)var6);
    long var17 = var6.getMiddleMillisecond();
    java.util.Calendar var18 = null;
    long var19 = var6.getFirstMillisecond(var18);
    java.util.Calendar var20 = null;
    long var21 = var6.getMiddleMillisecond(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1L);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
    long var7 = var1.getLastMillisecond();
    java.util.Calendar var8 = null;
    long var9 = var1.getMiddleMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var1.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Sun Dec 21 01:14:56 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var8);
//     long var13 = var12.getLastMillisecond();
//     long var14 = var12.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1969L);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2014);
//     var1.setDescription("Sun Dec 21 01:14:51 PST 2014");
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var9 = var8.getFirstMillisecond();
//     java.util.Calendar var10 = null;
//     long var11 = var8.getMiddleMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var8.getFirstMillisecond(var12);
//     org.jfree.data.time.RegularTimePeriod var14 = var8.next();
//     java.util.Date var15 = var8.getTime();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var16);
//     boolean var18 = var5.isAfter(var17);
//     boolean var19 = var1.isAfter((org.jfree.data.time.SerialDate)var5);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     long var26 = var24.getLastMillisecond();
//     org.jfree.data.time.SerialDate var27 = var24.getSerialDate();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addMonths(0, var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addYears(1, var27);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var32 = var31.next();
//     long var33 = var31.getLastMillisecond();
//     org.jfree.data.time.SerialDate var34 = var31.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addMonths(0, var34);
//     org.jfree.data.time.SerialDate var37 = var35.getPreviousDayOfWeek(4);
//     boolean var38 = var21.isInRange(var27, var35);
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var43 = var42.getSerialIndex();
//     java.util.Date var44 = var42.getTime();
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(var44);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addYears(0, var45);
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.addYears(31, var46);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getSerialIndex();
//     java.util.Date var51 = var49.getTime();
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var51);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var56 = var55.getFirstMillisecond();
//     java.util.Calendar var57 = null;
//     long var58 = var55.getMiddleMillisecond(var57);
//     java.util.Calendar var59 = null;
//     long var60 = var55.getFirstMillisecond(var59);
//     org.jfree.data.time.RegularTimePeriod var61 = var55.next();
//     java.util.Date var62 = var55.getTime();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var63);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day(var63);
//     org.jfree.data.time.SerialDate var66 = var52.getEndOfCurrentMonth(var63);
//     org.jfree.data.time.SerialDate var67 = var46.getEndOfCurrentMonth(var66);
//     boolean var68 = var21.isOn(var46);
//     var21.setDescription("");
//     int var71 = var21.getMonth();
//     org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.createInstance(1900);
//     boolean var74 = var21.isOn(var73);
//     boolean var75 = var1.isBefore((org.jfree.data.time.SerialDate)var21);
//     org.jfree.data.time.Month var76 = new org.jfree.data.time.Month();
//     long var77 = var76.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var78 = var76.previous();
//     org.jfree.data.time.Year var79 = var76.getYear();
//     org.jfree.data.time.TimeSeries var80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var79);
//     org.jfree.data.time.TimeSeries var83 = var80.createCopy(100, 100);
//     var80.fireSeriesChanged();
//     boolean var85 = var1.equals((java.lang.Object)var80);
//     org.jfree.data.time.Month var86 = new org.jfree.data.time.Month();
//     long var87 = var86.getFirstMillisecond();
//     org.jfree.data.time.Year var88 = var86.getYear();
//     org.jfree.data.time.Year var89 = var86.getYear();
//     java.lang.Object var90 = null;
//     boolean var91 = var86.equals(var90);
//     org.jfree.data.time.TimeSeriesDataItem var93 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var86, (java.lang.Number)1419153269727L);
//     boolean var95 = var93.equals((java.lang.Object)12);
//     java.lang.Number var96 = null;
//     var93.setValue(var96);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var80.add(var93);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == false);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     long var3 = var0.getLastMillisecond();
//     java.lang.String var4 = var0.toString();
//     int var5 = var0.getMonth();
//     long var6 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "21-December-2014"+ "'", var4.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419148800000L);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    java.util.Calendar var4 = null;
    long var5 = var1.getLastMillisecond(var4);
    java.util.Date var6 = var1.getStart();
    long var7 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     int var4 = var0.getYear();
//     long var5 = var0.getSerialIndex();
//     java.util.Calendar var6 = null;
//     long var7 = var0.getLastMillisecond(var6);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("31-December-1969");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     java.util.Calendar var12 = null;
//     long var13 = var9.getFirstMillisecond(var12);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2014, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var16 = var15.getSerialIndex();
//     java.util.Date var17 = var15.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getFirstMillisecond();
//     java.util.Calendar var23 = null;
//     long var24 = var21.getMiddleMillisecond(var23);
//     java.util.Calendar var25 = null;
//     long var26 = var21.getFirstMillisecond(var25);
//     org.jfree.data.time.RegularTimePeriod var27 = var21.next();
//     java.util.Date var28 = var21.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var29);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var29);
//     org.jfree.data.time.SerialDate var32 = var18.getEndOfCurrentMonth(var29);
//     boolean var33 = var0.equals((java.lang.Object)var29);
//     org.jfree.data.general.SeriesChangeEvent var34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var33);
//     java.lang.String var35 = var34.toString();
//     java.lang.String var36 = var34.toString();
//     java.lang.String var37 = var34.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]"+ "'", var35.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]"+ "'", var36.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]"+ "'", var37.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    java.lang.Class var0 = null;
    java.lang.Class var1 = null;
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getFirstMillisecond();
    java.util.Calendar var5 = null;
    long var6 = var3.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var3.getFirstMillisecond(var7);
    org.jfree.data.time.RegularTimePeriod var9 = var3.next();
    java.util.Date var10 = var3.getTime();
    org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var10);
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
    org.jfree.data.time.Month var13 = new org.jfree.data.time.Month(var10);
    java.util.TimeZone var14 = null;
    org.jfree.data.time.RegularTimePeriod var15 = org.jfree.data.time.RegularTimePeriod.createInstance(var1, var10, var14);
    org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var10);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var10);
    java.util.TimeZone var18 = null;
    org.jfree.data.time.RegularTimePeriod var19 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var10, var18);
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var10);
    org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }


    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getSerialIndex();
    java.util.Date var6 = var4.getTime();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(31, var8);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1L);
    long var12 = var11.getSerialIndex();
    java.util.Date var13 = var11.getTime();
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
    org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
    long var18 = var17.getFirstMillisecond();
    java.util.Calendar var19 = null;
    long var20 = var17.getMiddleMillisecond(var19);
    java.util.Calendar var21 = null;
    long var22 = var17.getFirstMillisecond(var21);
    org.jfree.data.time.RegularTimePeriod var23 = var17.next();
    java.util.Date var24 = var17.getTime();
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var25);
    org.jfree.data.time.Day var27 = new org.jfree.data.time.Day(var25);
    org.jfree.data.time.SerialDate var28 = var14.getEndOfCurrentMonth(var25);
    org.jfree.data.time.SerialDate var29 = var8.getEndOfCurrentMonth(var28);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addYears(1969, var8);
    java.lang.Class var33 = null;
    org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var8, "Nearest", "December 1969", var33);
    org.jfree.data.general.SeriesChangeListener var35 = null;
    var34.removeChangeListener(var35);
    java.lang.Class var37 = null;
    org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(1L);
    long var40 = var39.getFirstMillisecond();
    java.util.Calendar var41 = null;
    long var42 = var39.getMiddleMillisecond(var41);
    java.util.Calendar var43 = null;
    long var44 = var39.getFirstMillisecond(var43);
    org.jfree.data.time.RegularTimePeriod var45 = var39.next();
    java.util.Date var46 = var39.getTime();
    org.jfree.data.time.Month var47 = new org.jfree.data.time.Month(var46);
    org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(var46);
    org.jfree.data.time.Month var49 = new org.jfree.data.time.Month(var46);
    java.util.TimeZone var50 = null;
    org.jfree.data.time.RegularTimePeriod var51 = org.jfree.data.time.RegularTimePeriod.createInstance(var37, var46, var50);
    org.jfree.data.time.FixedMillisecond var52 = new org.jfree.data.time.FixedMillisecond(var46);
    org.jfree.data.time.Day var53 = new org.jfree.data.time.Day(var46);
    org.jfree.data.time.TimeSeriesDataItem var54 = var34.getDataItem((org.jfree.data.time.RegularTimePeriod)var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    long var7 = var6.getFirstMillisecond();
    java.util.Calendar var8 = null;
    long var9 = var6.getMiddleMillisecond(var8);
    java.util.Calendar var10 = null;
    long var11 = var6.getFirstMillisecond(var10);
    org.jfree.data.time.RegularTimePeriod var12 = var6.next();
    java.util.Date var13 = var6.getTime();
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
    boolean var16 = var3.isAfter(var15);
    org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
    long var21 = var20.getSerialIndex();
    java.util.Date var22 = var20.getTime();
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(31, var24);
    org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
    long var28 = var27.getSerialIndex();
    java.util.Date var29 = var27.getTime();
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
    org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
    long var34 = var33.getFirstMillisecond();
    java.util.Calendar var35 = null;
    long var36 = var33.getMiddleMillisecond(var35);
    java.util.Calendar var37 = null;
    long var38 = var33.getFirstMillisecond(var37);
    org.jfree.data.time.RegularTimePeriod var39 = var33.next();
    java.util.Date var40 = var33.getTime();
    org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
    org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var41);
    org.jfree.data.time.Day var43 = new org.jfree.data.time.Day(var41);
    org.jfree.data.time.SerialDate var44 = var30.getEndOfCurrentMonth(var41);
    org.jfree.data.time.SerialDate var45 = var24.getEndOfCurrentMonth(var44);
    org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
    long var50 = var49.getSerialIndex();
    java.util.Date var51 = var49.getTime();
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var51);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
    org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addYears(31, var53);
    org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond(1L);
    long var57 = var56.getSerialIndex();
    java.util.Date var58 = var56.getTime();
    org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.createInstance(var58);
    org.jfree.data.time.FixedMillisecond var62 = new org.jfree.data.time.FixedMillisecond(1L);
    long var63 = var62.getFirstMillisecond();
    java.util.Calendar var64 = null;
    long var65 = var62.getMiddleMillisecond(var64);
    java.util.Calendar var66 = null;
    long var67 = var62.getFirstMillisecond(var66);
    org.jfree.data.time.RegularTimePeriod var68 = var62.next();
    java.util.Date var69 = var62.getTime();
    org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.createInstance(var69);
    org.jfree.data.time.SerialDate var71 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var70);
    org.jfree.data.time.Day var72 = new org.jfree.data.time.Day(var70);
    org.jfree.data.time.SerialDate var73 = var59.getEndOfCurrentMonth(var70);
    org.jfree.data.time.SerialDate var74 = var53.getEndOfCurrentMonth(var73);
    boolean var75 = var3.isInRange(var45, var53);
    int var76 = var3.getDayOfMonth();
    org.jfree.data.time.FixedMillisecond var78 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var79 = null;
    long var80 = var78.getLastMillisecond(var79);
    long var81 = var78.getSerialIndex();
    org.jfree.data.time.TimeSeriesDataItem var83 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var78, 1.0d);
    long var84 = var78.getLastMillisecond();
    java.util.Date var85 = var78.getStart();
    org.jfree.data.time.SerialDate var86 = org.jfree.data.time.SerialDate.createInstance(var85);
    boolean var87 = var3.isOnOrBefore(var86);
    boolean var88 = var1.isOnOrAfter(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     int var14 = var0.getDayOfMonth();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var14, var15);
//     java.beans.PropertyChangeListener var17 = null;
//     var16.removePropertyChangeListener(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.beans.PropertyChangeListener var5 = null;
    var2.addPropertyChangeListener(var5);
    var2.setRangeDescription("");
    int var9 = var2.getItemCount();
    long var10 = var2.getMaximumItemAge();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 9223372036854775807L);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getSerialIndex();
    java.util.Date var4 = var2.getTime();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    var5.setDescription("Sun Dec 21 01:15:00 PST 2014");
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(7, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var8.addChangeListener(var10);
    var8.fireSeriesChanged();
    int var13 = var3.compareTo((java.lang.Object)var8);
    java.lang.Class var15 = null;
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
    boolean var17 = var16.getNotify();
    boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)true);
    var16.clear();
    boolean var21 = var16.getNotify();
    java.beans.PropertyChangeListener var22 = null;
    var16.removePropertyChangeListener(var22);
    var16.setNotify(false);
    var16.removeAgedItems(true);
    java.lang.String var28 = var16.getDescription();
    boolean var29 = var3.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getFirstMillisecond();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getMiddleMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var4.getFirstMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var4.next();
//     java.util.Date var11 = var4.getTime();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
//     boolean var14 = var1.isAfter(var13);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var20 = var19.getSerialIndex();
//     java.util.Date var21 = var19.getTime();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(0, var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(31, var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var27 = var26.getSerialIndex();
//     java.util.Date var28 = var26.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var33 = var32.getFirstMillisecond();
//     java.util.Calendar var34 = null;
//     long var35 = var32.getMiddleMillisecond(var34);
//     java.util.Calendar var36 = null;
//     long var37 = var32.getFirstMillisecond(var36);
//     org.jfree.data.time.RegularTimePeriod var38 = var32.next();
//     java.util.Date var39 = var32.getTime();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day(var40);
//     org.jfree.data.time.SerialDate var43 = var29.getEndOfCurrentMonth(var40);
//     org.jfree.data.time.SerialDate var44 = var23.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addYears(1969, var23);
//     java.lang.String var46 = var45.toString();
//     org.jfree.data.time.SerialDate var47 = var1.getEndOfCurrentMonth(var45);
//     var1.setDescription("Wednesday");
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(2014);
//     var51.setDescription("Sun Dec 21 01:14:51 PST 2014");
//     int var54 = var1.compare((org.jfree.data.time.SerialDate)var51);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var56 = var1.getNearestDayOfWeek((-571));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "31-December-3938"+ "'", var46.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == (-1993));
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     long var11 = var9.getLastMillisecond();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9, "October", "org.jfree.data.general.SeriesChangeEvent[source=1419148800000]", var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var17 = var15.getValue((-3039));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 28799999L);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     int var33 = var31.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var39 = var38.next();
//     long var40 = var38.getLastMillisecond();
//     org.jfree.data.time.SerialDate var41 = var38.getSerialDate();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths(0, var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addYears(1, var41);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var46 = var45.next();
//     long var47 = var45.getLastMillisecond();
//     org.jfree.data.time.SerialDate var48 = var45.getSerialDate();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addMonths(0, var48);
//     org.jfree.data.time.SerialDate var51 = var49.getPreviousDayOfWeek(4);
//     boolean var52 = var35.isInRange(var41, var49);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var55 = var54.next();
//     long var56 = var54.getLastMillisecond();
//     org.jfree.data.time.SerialDate var57 = var54.getSerialDate();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addMonths(0, var57);
//     org.jfree.data.time.SerialDate var60 = var58.getPreviousDayOfWeek(4);
//     java.lang.String var61 = var60.toString();
//     java.lang.String var62 = var60.toString();
//     org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var65 = var35.isInRange(var60, (org.jfree.data.time.SerialDate)var64);
//     int var66 = var35.getYYYY();
//     java.lang.String var67 = var35.getDescription();
//     int var68 = var35.getMonth();
//     org.jfree.data.time.SpreadsheetDate var70 = new org.jfree.data.time.SpreadsheetDate(2014);
//     boolean var72 = var31.isInRange((org.jfree.data.time.SerialDate)var35, (org.jfree.data.time.SerialDate)var70, (-605));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.addMonths((-457), (org.jfree.data.time.SerialDate)var70);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "17-December-2014"+ "'", var61.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "17-December-2014"+ "'", var62.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    int var10 = var3.compareTo((java.lang.Object)var8);
    var8.setRangeDescription("");
    java.util.List var13 = var8.getItems();
    var8.setRangeDescription("org.jfree.data.general.SeriesException: Preceding");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = var10.getYear();
//     org.jfree.data.time.Year var13 = var10.getYear();
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     int var15 = var10.getMonth();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var18 = var17.getSerialIndex();
//     java.util.Date var19 = var17.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day(var19);
//     boolean var23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var15, (java.lang.Object)var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.String var4 = var1.toString();
//     long var5 = var1.getFirstMillisecond();
//     java.util.Date var6 = var1.getStart();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var6);
//     org.jfree.data.general.SeriesChangeEvent var8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var4.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var2.removeChangeListener(var7);
//     java.lang.Comparable var9 = var2.getKey();
//     long var10 = var2.getMaximumItemAge();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     long var14 = var13.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var13.addChangeListener(var15);
//     var13.fireSeriesChanged();
//     java.lang.String var18 = var13.getDescription();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var20);
//     boolean var22 = var21.getNotify();
//     var21.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = var21.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     var21.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var29 = var13.addAndOrUpdate(var21);
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month();
//     long var31 = var30.getFirstMillisecond();
//     org.jfree.data.time.Year var32 = var30.getYear();
//     org.jfree.data.time.Year var33 = var30.getYear();
//     org.jfree.data.general.SeriesChangeEvent var34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var33);
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var36);
//     var37.setDescription("");
//     var37.setDescription("Time");
//     java.util.List var42 = var37.getItems();
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var45 = var44.getFirstMillisecond();
//     java.util.Calendar var46 = null;
//     long var47 = var44.getMiddleMillisecond(var46);
//     java.util.Calendar var48 = null;
//     long var49 = var44.getFirstMillisecond(var48);
//     java.util.Calendar var50 = null;
//     long var51 = var44.getMiddleMillisecond(var50);
//     org.jfree.data.time.TimeSeriesDataItem var53 = var37.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var44, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.RegularTimePeriod var54 = var44.previous();
//     org.jfree.data.time.TimeSeries var55 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var33, var54);
//     org.jfree.data.time.TimeSeries var56 = var2.addAndOrUpdate(var21);
//     org.jfree.data.time.Month var57 = new org.jfree.data.time.Month();
//     long var58 = var57.getFirstMillisecond();
//     org.jfree.data.time.Year var59 = var57.getYear();
//     long var60 = var59.getFirstMillisecond();
//     java.lang.Number var61 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var59);
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var63 = var62.next();
//     org.jfree.data.time.TimeSeriesDataItem var65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var62, (java.lang.Number)100);
//     org.jfree.data.time.Year var66 = new org.jfree.data.time.Year();
//     int var67 = var65.compareTo((java.lang.Object)var66);
//     java.lang.Class var69 = null;
//     org.jfree.data.time.TimeSeries var70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var69);
//     long var71 = var70.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var72 = null;
//     var70.addChangeListener(var72);
//     var70.fireSeriesChanged();
//     int var75 = var65.compareTo((java.lang.Object)var70);
//     boolean var77 = var65.equals((java.lang.Object)1.0f);
//     org.jfree.data.time.Day var78 = new org.jfree.data.time.Day();
//     long var79 = var78.getLastMillisecond();
//     long var80 = var78.getLastMillisecond();
//     long var81 = var78.getLastMillisecond();
//     java.util.Date var82 = var78.getEnd();
//     java.lang.Class var83 = null;
//     org.jfree.data.time.TimeSeries var84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var78, var83);
//     int var85 = var65.compareTo((java.lang.Object)var84);
//     org.jfree.data.time.RegularTimePeriod var86 = var65.getPeriod();
//     var2.add(var65, true);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Comparable var8 = var2.getKey();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = var9.getYear();
//     org.jfree.data.time.Year var12 = var9.getYear();
//     org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var12);
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var12, var16);
//     long var18 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var22 = var21.getFirstMillisecond();
//     long var23 = var21.getMiddleMillisecond();
//     long var24 = var21.getFirstMillisecond();
//     long var25 = var21.getLastMillisecond();
//     java.util.Date var26 = var21.getTime();
//     boolean var27 = var12.equals((java.lang.Object)var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + 100.0f+ "'", var8.equals(100.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var20);
//     boolean var22 = var9.isAfter(var21);
//     boolean var23 = var7.isBefore(var21);
//     org.jfree.data.time.SerialDate var24 = var4.getEndOfCurrentMonth(var21);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day(var4);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day(var4);
//     long var27 = var26.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var28 = var26.next();
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var26);
//     var29.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-435), 0, (-6654));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    java.util.Date var2 = var1.toDate();
    int var3 = var1.getDayOfMonth();
    int var4 = var1.getYYYY();
    java.util.Date var5 = var1.toDate();
    java.util.Date var6 = var1.toDate();
    var1.setDescription("");
    int var9 = var1.getDayOfWeek();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 7);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     boolean var9 = var2.equals((java.lang.Object)1.0d);
//     var2.setRangeDescription("");
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var14 = var13.getFirstMillisecond();
//     java.util.Calendar var15 = null;
//     long var16 = var13.getMiddleMillisecond(var15);
//     java.util.Calendar var17 = null;
//     long var18 = var13.getFirstMillisecond(var17);
//     org.jfree.data.time.RegularTimePeriod var19 = var13.next();
//     java.util.Date var20 = var13.getTime();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var20);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(var20);
//     long var24 = var23.getFirstMillisecond();
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var26 = var25.next();
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var28);
//     var29.setDescription("");
//     var29.setDescription("Time");
//     boolean var34 = var25.equals((java.lang.Object)var29);
//     var29.fireSeriesChanged();
//     boolean var36 = var29.isEmpty();
//     java.util.List var37 = var29.getItems();
//     int var38 = var23.compareTo((java.lang.Object)var29);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var40 = null;
//     long var41 = var39.getLastMillisecond(var40);
//     long var42 = var39.getMiddleMillisecond();
//     java.util.Date var43 = var39.getTime();
//     long var44 = var39.getMiddleMillisecond();
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month();
//     long var46 = var45.getFirstMillisecond();
//     org.jfree.data.time.Year var47 = var45.getYear();
//     long var48 = var47.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var49 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var39, (org.jfree.data.time.RegularTimePeriod)var47);
//     java.lang.String var50 = var49.getDescription();
//     org.jfree.data.time.TimeSeries var51 = var2.addAndOrUpdate(var49);
//     boolean var53 = var2.equals((java.lang.Object)1419153275424L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419153368609L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1419153368609L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419153368609L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "Time"+ "'", var50.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.String var3 = var2.getDomainDescription();
    var2.setDescription("");
    boolean var6 = var2.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.clear();
    var2.setRangeDescription("");
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var2.removeChangeListener(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.beans.PropertyChangeListener var7 = null;
//     var2.addPropertyChangeListener(var7);
//     var2.removeAgedItems(false);
//     long var11 = var2.getMaximumItemAge();
//     java.beans.PropertyChangeListener var12 = null;
//     var2.removePropertyChangeListener(var12);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     long var15 = var14.getLastMillisecond();
//     long var16 = var14.getLastMillisecond();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     long var20 = var19.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var21 = null;
//     var19.addChangeListener(var21);
//     var19.fireSeriesChanged();
//     java.lang.String var24 = var19.getDescription();
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     boolean var28 = var27.getNotify();
//     var27.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var27.getDataItem((org.jfree.data.time.RegularTimePeriod)var31);
//     var27.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var35 = var19.addAndOrUpdate(var27);
//     boolean var36 = var14.equals((java.lang.Object)var27);
//     org.jfree.data.time.TimeSeries var37 = var2.addAndOrUpdate(var27);
//     long var38 = var37.getMaximumItemAge();
//     org.jfree.data.time.FixedMillisecond var40 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var41 = var40.getFirstMillisecond();
//     long var42 = var40.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var40, 0.0d);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var47 = var46.getFirstMillisecond();
//     java.util.Calendar var48 = null;
//     long var49 = var46.getMiddleMillisecond(var48);
//     java.util.Calendar var50 = null;
//     long var51 = var46.getFirstMillisecond(var50);
//     org.jfree.data.time.RegularTimePeriod var52 = var46.next();
//     java.util.Date var53 = var46.getTime();
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month(var53);
//     int var55 = var54.getYearValue();
//     long var56 = var54.getLastMillisecond();
//     java.lang.Class var59 = null;
//     org.jfree.data.time.TimeSeries var60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var54, "October", "org.jfree.data.general.SeriesChangeEvent[source=1419148800000]", var59);
//     org.jfree.data.time.FixedMillisecond var63 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var64 = var63.getFirstMillisecond();
//     java.util.Calendar var65 = null;
//     long var66 = var63.getMiddleMillisecond(var65);
//     java.util.Calendar var67 = null;
//     long var68 = var63.getFirstMillisecond(var67);
//     org.jfree.data.time.RegularTimePeriod var69 = var63.next();
//     java.util.Date var70 = var63.getTime();
//     org.jfree.data.time.Month var71 = new org.jfree.data.time.Month(var70);
//     int var72 = var71.getYearValue();
//     java.util.Date var73 = var71.getStart();
//     org.jfree.data.time.Month var74 = new org.jfree.data.time.Month(var73);
//     org.jfree.data.time.Year var75 = var74.getYear();
//     int var76 = var75.getYear();
//     org.jfree.data.time.Month var77 = new org.jfree.data.time.Month(1, var75);
//     java.lang.Number var78 = var60.getValue((org.jfree.data.time.RegularTimePeriod)var75);
//     boolean var79 = var40.equals((java.lang.Object)var60);
//     org.jfree.data.time.RegularTimePeriod var80 = var40.next();
//     org.jfree.data.time.TimeSeriesDataItem var82 = var37.addOrUpdate(var80, 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var82);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     org.jfree.data.time.RegularTimePeriod var6 = var3.getPeriod();
//     java.lang.String var7 = var6.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "2014"+ "'", var7.equals("2014"));
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test136"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = var10.getYear();
//     org.jfree.data.time.Year var13 = var10.getYear();
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     boolean var18 = var17.getNotify();
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)true);
//     var17.clear();
//     boolean var22 = var17.getNotify();
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var24);
//     boolean var26 = var25.getNotify();
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var25, (java.lang.Object)true);
//     var25.clear();
//     java.util.Collection var30 = var17.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.TimeSeries var33 = var25.createCopy(10, 10);
//     boolean var34 = var0.equals((java.lang.Object)var25);
//     org.jfree.data.time.RegularTimePeriod var35 = var0.next();
//     org.jfree.data.time.SerialDate var36 = var0.getSerialDate();
//     int var37 = var0.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 21);
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test137"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     long var3 = var1.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
//     java.lang.Number var6 = var5.getValue();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var8);
//     boolean var10 = var9.getNotify();
//     boolean var12 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var9, (java.lang.Object)true);
//     var9.clear();
//     boolean var14 = var9.getNotify();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     boolean var18 = var17.getNotify();
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)true);
//     var17.clear();
//     java.util.Collection var22 = var9.getTimePeriodsUniqueToOtherSeries(var17);
//     org.jfree.data.time.TimeSeries var25 = var17.createCopy(10, 10);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = var26.getYear();
//     org.jfree.data.time.Year var29 = var26.getYear();
//     java.lang.Object var30 = null;
//     boolean var31 = var26.equals(var30);
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)1419153269727L);
//     var25.delete((org.jfree.data.time.RegularTimePeriod)var26);
//     int var35 = var5.compareTo((java.lang.Object)var26);
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var37);
//     boolean var39 = var38.getNotify();
//     var38.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var43 = var38.getDataItem((org.jfree.data.time.RegularTimePeriod)var42);
//     int var44 = var38.getItemCount();
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var47 = null;
//     long var48 = var46.getLastMillisecond(var47);
//     java.util.Calendar var49 = null;
//     long var50 = var46.getLastMillisecond(var49);
//     boolean var51 = var38.equals((java.lang.Object)var46);
//     org.jfree.data.time.TimeSeries var53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
//     org.jfree.data.time.TimeSeries var54 = var38.addAndOrUpdate(var53);
//     int var55 = var26.compareTo((java.lang.Object)var53);
//     java.lang.Class var57 = null;
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var57);
//     boolean var59 = var58.getNotify();
//     boolean var61 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var58, (java.lang.Object)true);
//     var58.clear();
//     boolean var63 = var58.getNotify();
//     java.beans.PropertyChangeListener var64 = null;
//     var58.removePropertyChangeListener(var64);
//     org.jfree.data.general.SeriesChangeListener var66 = null;
//     var58.addChangeListener(var66);
//     var58.setMaximumItemCount(12);
//     org.jfree.data.time.Day var70 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var71 = var70.next();
//     java.lang.Class var73 = null;
//     org.jfree.data.time.TimeSeries var74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var73);
//     var74.setDescription("");
//     var74.setDescription("Time");
//     boolean var79 = var70.equals((java.lang.Object)var74);
//     int var80 = var70.getMonth();
//     long var81 = var70.getFirstMillisecond();
//     java.lang.Class var83 = null;
//     org.jfree.data.time.TimeSeries var84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var83);
//     int var85 = var84.getItemCount();
//     var84.setDescription("");
//     org.jfree.data.time.Year var88 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var89 = var88.next();
//     org.jfree.data.time.TimeSeriesDataItem var91 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var88, (java.lang.Number)100);
//     boolean var93 = var88.equals((java.lang.Object)(-571));
//     long var94 = var88.getSerialIndex();
//     int var95 = var84.getIndex((org.jfree.data.time.RegularTimePeriod)var88);
//     int var96 = var70.compareTo((java.lang.Object)var84);
//     java.util.Collection var97 = var58.getTimePeriodsUniqueToOtherSeries(var84);
//     boolean var98 = var53.equals((java.lang.Object)var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 0.0d+ "'", var6.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == false);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test138"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     long var3 = var1.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var8 = var7.getFirstMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var7.getMiddleMillisecond(var9);
//     java.util.Calendar var11 = null;
//     long var12 = var7.getFirstMillisecond(var11);
//     org.jfree.data.time.RegularTimePeriod var13 = var7.next();
//     java.util.Date var14 = var7.getTime();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     int var16 = var15.getYearValue();
//     long var17 = var15.getLastMillisecond();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, "October", "org.jfree.data.general.SeriesChangeEvent[source=1419148800000]", var20);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var25 = var24.getFirstMillisecond();
//     java.util.Calendar var26 = null;
//     long var27 = var24.getMiddleMillisecond(var26);
//     java.util.Calendar var28 = null;
//     long var29 = var24.getFirstMillisecond(var28);
//     org.jfree.data.time.RegularTimePeriod var30 = var24.next();
//     java.util.Date var31 = var24.getTime();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var31);
//     int var33 = var32.getYearValue();
//     java.util.Date var34 = var32.getStart();
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month(var34);
//     org.jfree.data.time.Year var36 = var35.getYear();
//     int var37 = var36.getYear();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(1, var36);
//     java.lang.Number var39 = var21.getValue((org.jfree.data.time.RegularTimePeriod)var36);
//     boolean var40 = var1.equals((java.lang.Object)var21);
//     java.beans.PropertyChangeListener var41 = null;
//     var21.removePropertyChangeListener(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test139"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    int var3 = var2.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete((-457), (-25544));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test140"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getFirstMillisecond();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getMiddleMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var4.getFirstMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var4.next();
//     java.util.Date var11 = var4.getTime();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
//     boolean var14 = var1.isAfter(var13);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var20 = var19.getSerialIndex();
//     java.util.Date var21 = var19.getTime();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(0, var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(31, var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var27 = var26.getSerialIndex();
//     java.util.Date var28 = var26.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var33 = var32.getFirstMillisecond();
//     java.util.Calendar var34 = null;
//     long var35 = var32.getMiddleMillisecond(var34);
//     java.util.Calendar var36 = null;
//     long var37 = var32.getFirstMillisecond(var36);
//     org.jfree.data.time.RegularTimePeriod var38 = var32.next();
//     java.util.Date var39 = var32.getTime();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day(var40);
//     org.jfree.data.time.SerialDate var43 = var29.getEndOfCurrentMonth(var40);
//     org.jfree.data.time.SerialDate var44 = var23.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addYears(1969, var23);
//     java.lang.String var46 = var45.toString();
//     org.jfree.data.time.SerialDate var47 = var1.getEndOfCurrentMonth(var45);
//     var1.setDescription("Wednesday");
//     java.util.Date var50 = var1.toDate();
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var52 = var51.next();
//     boolean var53 = var1.equals((java.lang.Object)var52);
//     java.util.Date var54 = var1.toDate();
//     java.util.TimeZone var55 = null;
//     org.jfree.data.time.Month var56 = new org.jfree.data.time.Month(var54, var55);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test141"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     var2.setMaximumItemCount(12);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var17);
//     var18.setDescription("");
//     var18.setDescription("Time");
//     boolean var23 = var14.equals((java.lang.Object)var18);
//     int var24 = var14.getMonth();
//     long var25 = var14.getFirstMillisecond();
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     int var29 = var28.getItemCount();
//     var28.setDescription("");
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)100);
//     boolean var37 = var32.equals((java.lang.Object)(-571));
//     long var38 = var32.getSerialIndex();
//     int var39 = var28.getIndex((org.jfree.data.time.RegularTimePeriod)var32);
//     int var40 = var14.compareTo((java.lang.Object)var28);
//     java.util.Collection var41 = var2.getTimePeriodsUniqueToOtherSeries(var28);
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var43);
//     boolean var45 = var44.getNotify();
//     boolean var47 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var44, (java.lang.Object)true);
//     var44.clear();
//     boolean var49 = var44.getNotify();
//     java.lang.Class var51 = null;
//     org.jfree.data.time.TimeSeries var52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var51);
//     boolean var53 = var52.getNotify();
//     boolean var55 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var52, (java.lang.Object)true);
//     var52.clear();
//     java.util.Collection var57 = var44.getTimePeriodsUniqueToOtherSeries(var52);
//     org.jfree.data.time.TimeSeries var60 = var52.createCopy(10, 10);
//     org.jfree.data.time.Month var61 = new org.jfree.data.time.Month();
//     long var62 = var61.getFirstMillisecond();
//     org.jfree.data.time.Year var63 = var61.getYear();
//     org.jfree.data.time.Year var64 = var61.getYear();
//     java.lang.Object var65 = null;
//     boolean var66 = var61.equals(var65);
//     org.jfree.data.time.TimeSeriesDataItem var68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var61, (java.lang.Number)1419153269727L);
//     var60.delete((org.jfree.data.time.RegularTimePeriod)var61);
//     java.lang.String var70 = var61.toString();
//     org.jfree.data.time.Year var71 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var72 = var71.next();
//     long var73 = var71.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var74 = var71.next();
//     int var75 = var71.getYear();
//     org.jfree.data.time.Day var76 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var77 = var76.next();
//     java.lang.Class var79 = null;
//     org.jfree.data.time.TimeSeries var80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var79);
//     var80.setDescription("");
//     var80.setDescription("Time");
//     boolean var85 = var76.equals((java.lang.Object)var80);
//     int var86 = var76.getMonth();
//     long var87 = var76.getFirstMillisecond();
//     long var88 = var76.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var89 = var76.getSerialDate();
//     boolean var90 = var71.equals((java.lang.Object)var76);
//     int var91 = var76.getYear();
//     org.jfree.data.time.TimeSeries var92 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var61, (org.jfree.data.time.RegularTimePeriod)var76);
//     java.util.Calendar var93 = null;
//     var76.peg(var93);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test142"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
//     org.jfree.data.time.RegularTimePeriod var11 = var5.next();
//     java.util.Date var12 = var5.getTime();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var13);
//     boolean var15 = var2.isAfter(var14);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var21 = var20.getSerialIndex();
//     java.util.Date var22 = var20.getTime();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(0, var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(31, var24);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getSerialIndex();
//     java.util.Date var29 = var27.getTime();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var33.next();
//     java.util.Date var40 = var33.getTime();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var41);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day(var41);
//     org.jfree.data.time.SerialDate var44 = var30.getEndOfCurrentMonth(var41);
//     org.jfree.data.time.SerialDate var45 = var24.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addYears(1969, var24);
//     java.lang.String var47 = var46.toString();
//     org.jfree.data.time.SerialDate var48 = var2.getEndOfCurrentMonth(var46);
//     int var49 = var2.getDayOfMonth();
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var55 = var54.getSerialIndex();
//     java.util.Date var56 = var54.getTime();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addYears(0, var57);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.addYears(31, var58);
//     org.jfree.data.time.FixedMillisecond var61 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var62 = var61.getSerialIndex();
//     java.util.Date var63 = var61.getTime();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(var63);
//     org.jfree.data.time.FixedMillisecond var67 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var68 = var67.getFirstMillisecond();
//     java.util.Calendar var69 = null;
//     long var70 = var67.getMiddleMillisecond(var69);
//     java.util.Calendar var71 = null;
//     long var72 = var67.getFirstMillisecond(var71);
//     org.jfree.data.time.RegularTimePeriod var73 = var67.next();
//     java.util.Date var74 = var67.getTime();
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(var74);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var75);
//     org.jfree.data.time.Day var77 = new org.jfree.data.time.Day(var75);
//     org.jfree.data.time.SerialDate var78 = var64.getEndOfCurrentMonth(var75);
//     org.jfree.data.time.SerialDate var79 = var58.getEndOfCurrentMonth(var78);
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.addYears(1969, var58);
//     java.lang.String var81 = var80.toString();
//     boolean var82 = var2.isOnOrAfter(var80);
//     int var83 = var2.getMonth();
//     int var84 = var2.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var85 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "31-December-3938"+ "'", var47.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var81 + "' != '" + "31-December-3938"+ "'", var81.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test143"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     var14.setDescription("");
//     var14.setDescription("Time");
//     boolean var19 = var10.equals((java.lang.Object)var14);
//     int var20 = var10.getMonth();
//     long var21 = var10.getLastMillisecond();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     long var23 = var22.getFirstMillisecond();
//     org.jfree.data.time.Year var24 = var22.getYear();
//     long var25 = var22.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var26 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var10, (org.jfree.data.time.RegularTimePeriod)var22);
//     var26.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.Comparable var29 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var26.setKey(var29);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test144"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 20-January-1900");

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test145"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     long var3 = var0.getLastMillisecond();
//     long var4 = var0.getLastMillisecond();
//     int var5 = var0.getYear();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)100);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     int var11 = var9.compareTo((java.lang.Object)var10);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     long var15 = var14.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var14.addChangeListener(var16);
//     var14.fireSeriesChanged();
//     int var19 = var9.compareTo((java.lang.Object)var14);
//     boolean var21 = var9.equals((java.lang.Object)1.0f);
//     boolean var22 = var0.equals((java.lang.Object)var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test146"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var7 = var6.getFirstMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var6.next();
//     java.util.Date var13 = var6.getTime();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var14);
//     boolean var16 = var3.isAfter(var15);
//     boolean var17 = var1.isBefore(var15);
//     int var18 = var1.getYYYY();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     long var20 = var19.getFirstMillisecond();
//     long var21 = var19.getLastMillisecond();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     long var23 = var22.getFirstMillisecond();
//     org.jfree.data.time.Year var24 = var22.getYear();
//     org.jfree.data.time.Year var25 = var22.getYear();
//     org.jfree.data.general.SeriesChangeEvent var26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     long var27 = var25.getLastMillisecond();
//     int var28 = var19.compareTo((java.lang.Object)var25);
//     boolean var29 = var1.equals((java.lang.Object)var19);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var31 = var1.toSerial();
//     int var32 = var1.getYYYY();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1900);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test147"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var4);
//     int var7 = var6.getYear();
//     long var8 = var6.getLastMillisecond();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     var11.setDescription("");
//     var11.setDescription("Time");
//     var11.setMaximumItemAge(28799999L);
//     boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var11);
//     java.lang.Class var19 = var11.getTimePeriodClass();
//     var11.setMaximumItemAge(1419153270645L);
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var11.addChangeListener(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test148"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Calendar var8 = null;
    long var9 = var1.getFirstMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var1.previous();
    org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
    long var13 = var12.getFirstMillisecond();
    java.util.Calendar var14 = null;
    long var15 = var12.getMiddleMillisecond(var14);
    java.util.Calendar var16 = null;
    long var17 = var12.getFirstMillisecond(var16);
    org.jfree.data.time.RegularTimePeriod var18 = var12.next();
    java.util.Date var19 = var12.getTime();
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
    org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var19);
    org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var19);
    org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var19);
    org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var19);
    org.jfree.data.time.Day var25 = new org.jfree.data.time.Day(var19);
    boolean var26 = var1.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test149"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    int var3 = var2.getItemCount();
    var2.setNotify(false);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
    var10.clear();
    org.jfree.data.general.SeriesChangeListener var12 = null;
    var10.removeChangeListener(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var15 = var10.getValue((-455));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test150"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     int var32 = var1.getYYYY();
//     java.lang.String var33 = var1.getDescription();
//     int var34 = var1.getMonth();
//     java.lang.Object var35 = null;
//     boolean var36 = var1.equals(var35);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var40 = var39.getFirstMillisecond();
//     java.util.Calendar var41 = null;
//     long var42 = var39.getMiddleMillisecond(var41);
//     java.util.Calendar var43 = null;
//     long var44 = var39.getFirstMillisecond(var43);
//     org.jfree.data.time.RegularTimePeriod var45 = var39.next();
//     java.util.Date var46 = var39.getTime();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var46);
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var47);
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var52 = var51.getFirstMillisecond();
//     java.util.Calendar var53 = null;
//     long var54 = var51.getMiddleMillisecond(var53);
//     java.util.Calendar var55 = null;
//     long var56 = var51.getFirstMillisecond(var55);
//     org.jfree.data.time.RegularTimePeriod var57 = var51.next();
//     java.util.Date var58 = var51.getTime();
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.createInstance(var58);
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var59);
//     org.jfree.data.time.SerialDate var61 = var48.getEndOfCurrentMonth(var60);
//     boolean var62 = var1.isOn(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test151"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     java.lang.String var11 = var2.getDescription();
//     java.lang.String var12 = var2.getDescription();
//     long var13 = var2.getMaximumItemAge();
//     java.util.Collection var14 = var2.getTimePeriods();
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     var19.setDescription("");
//     var19.setDescription("Time");
//     boolean var24 = var15.equals((java.lang.Object)var19);
//     int var25 = var15.getMonth();
//     long var26 = var15.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var27 = var15.previous();
//     int var28 = var15.getDayOfMonth();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)1419153305511L);
//     java.util.Calendar var31 = null;
//     var15.peg(var31);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test152"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     int var1 = var0.getYearValue();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getYearValue();
//     long var4 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 24180L);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test153"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    var2.setKey((java.lang.Comparable)10L);
    var2.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test154"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.clear();
    java.beans.PropertyChangeListener var9 = null;
    var2.addPropertyChangeListener(var9);
    java.util.Collection var11 = var2.getTimePeriods();
    java.lang.String var12 = var2.getDescription();
    var2.clear();
    java.lang.Class var14 = var2.getTimePeriodClass();
    int var15 = var2.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test155"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     int var5 = var0.getMonth();
//     int var6 = var0.getDayOfMonth();
//     java.util.Calendar var7 = null;
//     var0.peg(var7);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test156"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     var2.setNotify(false);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
//     int var21 = var20.getYearValue();
//     long var22 = var20.getLastMillisecond();
//     long var23 = var20.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, 0.0d);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var28 = var27.getSerialIndex();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var30);
//     boolean var32 = var31.getNotify();
//     var31.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var36 = var31.getDataItem((org.jfree.data.time.RegularTimePeriod)var35);
//     long var37 = var35.getMiddleMillisecond();
//     java.util.Calendar var38 = null;
//     long var39 = var35.getLastMillisecond(var38);
//     java.lang.String var40 = var35.toString();
//     int var42 = var35.compareTo((java.lang.Object)(byte)0);
//     org.jfree.data.time.TimeSeriesDataItem var44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)1419153271278L);
//     boolean var45 = var27.equals((java.lang.Object)var44);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var27);
//     var2.setMaximumItemAge(1419153326653L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 28799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419153368941L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419153368941L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "Sun Dec 21 01:16:08 PST 2014"+ "'", var40.equals("Sun Dec 21 01:16:08 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test157"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("31-December-3938", var1);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test158"); }
// 
// 
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     long var5 = var3.getLastMillisecond();
//     org.jfree.data.time.SerialDate var6 = var3.getSerialDate();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(0, var6);
//     org.jfree.data.time.SerialDate var9 = var7.getPreviousDayOfWeek(4);
//     java.lang.String var10 = var9.toString();
//     java.lang.String var11 = var9.toString();
//     java.lang.String var12 = var9.toString();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addYears(21, var9);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addDays((-1), var9);
//     java.lang.String var15 = var9.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "17-December-2014"+ "'", var10.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "17-December-2014"+ "'", var11.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "17-December-2014"+ "'", var12.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "17-December-2014"+ "'", var15.equals("17-December-2014"));
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test159"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var36 = var35.next();
//     long var37 = var35.getLastMillisecond();
//     org.jfree.data.time.SerialDate var38 = var35.getSerialDate();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addMonths(0, var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addYears(1, var38);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     long var44 = var42.getLastMillisecond();
//     org.jfree.data.time.SerialDate var45 = var42.getSerialDate();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addMonths(0, var45);
//     org.jfree.data.time.SerialDate var48 = var46.getPreviousDayOfWeek(4);
//     boolean var49 = var32.isInRange(var38, var46);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var50, (java.lang.Number)100);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     int var55 = var53.compareTo((java.lang.Object)var54);
//     java.lang.Class var57 = null;
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var57);
//     long var59 = var58.getMaximumItemAge();
//     int var60 = var53.compareTo((java.lang.Object)var58);
//     org.jfree.data.time.Day var61 = new org.jfree.data.time.Day();
//     boolean var62 = var53.equals((java.lang.Object)var61);
//     org.jfree.data.time.TimeSeriesDataItem var64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var61, (java.lang.Number)1417420800000L);
//     int var65 = var61.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var66 = var61.next();
//     boolean var67 = var32.equals((java.lang.Object)var66);
//     boolean var68 = var1.isAfter((org.jfree.data.time.SerialDate)var32);
//     int var69 = var1.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 20);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test160"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     long var3 = var1.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     org.jfree.data.time.RegularTimePeriod var9 = var7.next();
//     boolean var10 = var5.equals((java.lang.Object)var7);
//     int var11 = var7.getYear();
//     java.util.Date var12 = var7.getStart();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     long var14 = var13.getFirstMillisecond();
//     org.jfree.data.time.Year var15 = var13.getYear();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var17);
//     java.lang.String var19 = var18.getDomainDescription();
//     var18.clear();
//     boolean var21 = var15.equals((java.lang.Object)var18);
//     var18.setRangeDescription("21-December-2014");
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var27 = var26.next();
//     long var28 = var26.getLastMillisecond();
//     org.jfree.data.time.SerialDate var29 = var26.getSerialDate();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addMonths(0, var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.addYears(1, var29);
//     boolean var32 = var18.equals((java.lang.Object)var29);
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var32, "Sun Dec 21 01:14:32 PST 2014", "21-December-2014", var35);
//     int var37 = var7.compareTo((java.lang.Object)"Sun Dec 21 01:14:32 PST 2014");
//     java.util.Calendar var38 = null;
//     long var39 = var7.getFirstMillisecond(var38);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test161"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.next();
//     org.jfree.data.time.SerialDate var5 = var0.getSerialDate();
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test162"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     long var5 = var3.getLastMillisecond();
//     long var6 = var3.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var9 = var8.getPeriod();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.getPeriod();
//     java.util.Date var11 = var10.getEnd();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test163"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.lang.String var2 = var0.toString();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
//     org.jfree.data.time.RegularTimePeriod var5 = var0.previous();
//     long var6 = var0.getMiddleMillisecond();
//     java.util.Date var7 = var0.getEnd();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Sun Dec 21 01:16:09 PST 2014"+ "'", var2.equals("Sun Dec 21 01:16:09 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419153369064L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test164"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
    long var7 = var1.getLastMillisecond();
    java.util.Date var8 = var1.getStart();
    java.util.Calendar var9 = null;
    var1.peg(var9);
    java.util.Date var11 = var1.getTime();
    long var12 = var1.getMiddleMillisecond();
    java.util.Calendar var13 = null;
    long var14 = var1.getMiddleMillisecond(var13);
    org.jfree.data.time.RegularTimePeriod var15 = var1.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test165"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sun Dec 21 01:15:00 PST 2014", var1);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test166"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.util.List var7 = var2.getItems();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
    long var10 = var9.getFirstMillisecond();
    java.util.Calendar var11 = null;
    long var12 = var9.getMiddleMillisecond(var11);
    java.util.Calendar var13 = null;
    long var14 = var9.getFirstMillisecond(var13);
    java.util.Calendar var15 = null;
    long var16 = var9.getMiddleMillisecond(var15);
    org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
    int var19 = var2.getMaximumItemCount();
    java.lang.String var20 = var2.getDomainDescription();
    java.lang.String var21 = var2.getDomainDescription();
    var2.setDomainDescription("Sun Dec 21 01:14:33 PST 2014");
    var2.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(1969, (java.lang.Number)1419153359705L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "Time"+ "'", var20.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Time"+ "'", var21.equals("Time"));

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test167"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January 13", var1);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test168"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
    boolean var6 = var5.getNotify();
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)true);
    var5.setMaximumItemCount(0);
    java.util.Collection var11 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    java.beans.PropertyChangeListener var12 = null;
    var5.addPropertyChangeListener(var12);
    java.lang.Class var15 = null;
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var15);
    boolean var17 = var16.getNotify();
    var16.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var21 = var16.getDataItem((org.jfree.data.time.RegularTimePeriod)var20);
    var16.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.String var24 = var16.getDomainDescription();
    java.beans.PropertyChangeListener var25 = null;
    var16.removePropertyChangeListener(var25);
    org.jfree.data.time.TimeSeries var27 = var5.addAndOrUpdate(var16);
    var27.setDomainDescription("org.jfree.data.general.SeriesException: ");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var24.equals("SerialDate.weekInMonthToString(): invalid code."));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test169"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var8);
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     int var14 = var12.getYear();
//     java.util.Date var15 = var12.getEnd();
//     org.jfree.data.time.RegularTimePeriod var16 = var12.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test170"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     long var3 = var1.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     org.jfree.data.time.RegularTimePeriod var9 = var7.next();
//     boolean var10 = var5.equals((java.lang.Object)var7);
//     int var11 = var7.getYear();
//     java.util.Date var12 = var7.getStart();
//     int var13 = var7.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test171"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var4 = var3.getSerialIndex();
//     java.util.Date var5 = var3.getTime();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.next();
//     java.util.Date var16 = var9.getTime();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var17);
//     org.jfree.data.time.SerialDate var20 = var6.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.SerialDate var22 = var20.getFollowingDayOfWeek(4);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)100);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)var27);
//     var26.setValue((java.lang.Number)1388563200000L);
//     var26.setValue((java.lang.Number)(byte)0);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     long var36 = var34.getLastMillisecond();
//     org.jfree.data.time.SerialDate var37 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var37);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var46 = var45.getFirstMillisecond();
//     java.util.Calendar var47 = null;
//     long var48 = var45.getMiddleMillisecond(var47);
//     java.util.Calendar var49 = null;
//     long var50 = var45.getFirstMillisecond(var49);
//     org.jfree.data.time.RegularTimePeriod var51 = var45.next();
//     java.util.Date var52 = var45.getTime();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var53);
//     boolean var55 = var42.isAfter(var54);
//     boolean var56 = var40.isBefore(var54);
//     org.jfree.data.time.SerialDate var57 = var37.getEndOfCurrentMonth(var54);
//     int var58 = var26.compareTo((java.lang.Object)var37);
//     boolean var60 = var1.isInRange(var20, var37, (-459));
//     int var61 = var1.getDayOfMonth();
//     java.lang.String var62 = var1.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test172"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     long var9 = var7.getLastMillisecond();
//     org.jfree.data.time.SerialDate var10 = var7.getSerialDate();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(0, var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(1, var10);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     long var16 = var14.getLastMillisecond();
//     org.jfree.data.time.SerialDate var17 = var14.getSerialDate();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addMonths(0, var17);
//     org.jfree.data.time.SerialDate var20 = var18.getPreviousDayOfWeek(4);
//     boolean var21 = var4.isInRange(var10, var18);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)100);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     int var27 = var25.compareTo((java.lang.Object)var26);
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var29);
//     long var31 = var30.getMaximumItemAge();
//     int var32 = var25.compareTo((java.lang.Object)var30);
//     boolean var33 = var4.equals((java.lang.Object)var30);
//     int var34 = var4.getMonth();
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var36 = var35.next();
//     java.lang.Class var38 = null;
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var38);
//     var39.setDescription("");
//     var39.setDescription("Time");
//     boolean var44 = var35.equals((java.lang.Object)var39);
//     int var45 = var35.getMonth();
//     long var46 = var35.getFirstMillisecond();
//     long var47 = var35.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var48 = var35.getSerialDate();
//     boolean var49 = var4.isBefore(var48);
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.addDays(17, (org.jfree.data.time.SerialDate)var4);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addYears(100, (org.jfree.data.time.SerialDate)var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1948, (org.jfree.data.time.SerialDate)var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test173"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test174"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(6, 2014, (-455));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test175"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var2.removeChangeListener(var30);
//     java.lang.Class var32 = var2.getTimePeriodClass();
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var34);
//     var35.setDescription("");
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     long var39 = var38.getLastMillisecond();
//     long var40 = var38.getLastMillisecond();
//     int var41 = var38.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var42 = var38.next();
//     java.lang.String var43 = var38.toString();
//     var35.setKey((java.lang.Comparable)var38);
//     org.jfree.data.general.SeriesChangeEvent var45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var38);
//     org.jfree.data.time.RegularTimePeriod var46 = var38.previous();
//     java.lang.Number var47 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var38);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getFirstMillisecond();
//     java.util.Calendar var51 = null;
//     long var52 = var49.getMiddleMillisecond(var51);
//     java.util.Calendar var53 = null;
//     long var54 = var49.getFirstMillisecond(var53);
//     org.jfree.data.time.RegularTimePeriod var55 = var49.next();
//     java.util.Date var56 = var49.getTime();
//     org.jfree.data.time.Month var57 = new org.jfree.data.time.Month(var56);
//     org.jfree.data.time.FixedMillisecond var58 = new org.jfree.data.time.FixedMillisecond(var56);
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond(var56);
//     long var60 = var59.getFirstMillisecond();
//     org.jfree.data.time.Day var61 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var62 = var61.next();
//     java.lang.Class var64 = null;
//     org.jfree.data.time.TimeSeries var65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var64);
//     var65.setDescription("");
//     var65.setDescription("Time");
//     boolean var70 = var61.equals((java.lang.Object)var65);
//     var65.fireSeriesChanged();
//     boolean var72 = var65.isEmpty();
//     java.util.List var73 = var65.getItems();
//     int var74 = var59.compareTo((java.lang.Object)var65);
//     org.jfree.data.time.TimeSeriesDataItem var76 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var59, (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "21-December-2014"+ "'", var43.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var76);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test176"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Sun Dec 21 01:14:39 PST 2014", var1);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test177"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var0.previous();
//     org.jfree.data.time.SerialDate var14 = var0.getSerialDate();
//     java.lang.String var15 = var0.toString();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "org.jfree.data.general.SeriesChangeEvent[source=false]", "October", var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var19.delete((-570), (-452));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "21-December-2014"+ "'", var15.equals("21-December-2014"));
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test178"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    int var3 = var2.getItemCount();
    var2.setNotify(false);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
    java.lang.Comparable var11 = var2.getKey();
    boolean var12 = var2.getNotify();
    java.lang.Comparable var13 = var2.getKey();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var15 = var2.getValue(45);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 100.0f+ "'", var11.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 100.0f+ "'", var13.equals(100.0f));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test179"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-10638), (-457), (-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test180"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var2);
//     java.lang.String var4 = var3.getDomainDescription();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var6);
//     long var8 = var7.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var7.addChangeListener(var9);
//     var7.fireSeriesChanged();
//     java.lang.String var12 = var7.getDescription();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var14);
//     boolean var16 = var15.getNotify();
//     var15.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var15.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     var15.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var23 = var7.addAndOrUpdate(var15);
//     org.jfree.data.time.TimeSeries var24 = var3.addAndOrUpdate(var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     boolean var28 = var27.getNotify();
//     boolean var30 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)true);
//     var27.clear();
//     boolean var32 = var27.getNotify();
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var34);
//     boolean var36 = var35.getNotify();
//     boolean var38 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, (java.lang.Object)true);
//     var35.clear();
//     java.util.Collection var40 = var27.getTimePeriodsUniqueToOtherSeries(var35);
//     org.jfree.data.general.SeriesChangeListener var41 = null;
//     var27.removeChangeListener(var41);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var44 = var43.next();
//     java.lang.Class var46 = null;
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var46);
//     var47.setDescription("");
//     var47.setDescription("Time");
//     boolean var52 = var43.equals((java.lang.Object)var47);
//     int var53 = var43.getMonth();
//     var27.setKey((java.lang.Comparable)var53);
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var56 = var55.next();
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var58);
//     var59.setDescription("");
//     var59.setDescription("Time");
//     boolean var64 = var55.equals((java.lang.Object)var59);
//     java.util.Collection var65 = var27.getTimePeriodsUniqueToOtherSeries(var59);
//     org.jfree.data.general.SeriesChangeEvent var66 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var27);
//     org.jfree.data.time.TimeSeries var67 = var24.addAndOrUpdate(var27);
//     int var68 = var24.getItemCount();
//     boolean var69 = var24.isEmpty();
//     java.beans.PropertyChangeListener var70 = null;
//     var24.addPropertyChangeListener(var70);
//     java.lang.Class var73 = null;
//     org.jfree.data.time.TimeSeries var74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var73);
//     boolean var75 = var74.getNotify();
//     var74.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var78 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var79 = var74.getDataItem((org.jfree.data.time.RegularTimePeriod)var78);
//     var74.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.Day var82 = new org.jfree.data.time.Day();
//     long var83 = var82.getLastMillisecond();
//     long var84 = var82.getLastMillisecond();
//     long var85 = var82.getLastMillisecond();
//     java.lang.String var86 = var82.toString();
//     int var87 = var74.getIndex((org.jfree.data.time.RegularTimePeriod)var82);
//     org.jfree.data.general.SeriesException var89 = new org.jfree.data.general.SeriesException("hi!");
//     int var90 = var82.compareTo((java.lang.Object)"hi!");
//     long var91 = var82.getSerialIndex();
//     org.jfree.data.time.SerialDate var92 = var82.getSerialDate();
//     boolean var93 = var24.equals((java.lang.Object)var92);
//     org.jfree.data.time.SerialDate var94 = org.jfree.data.time.SerialDate.addDays((-605), var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "Time"+ "'", var4.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var86 + "' != '" + "21-December-2014"+ "'", var86.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 41994L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
// 
//   }

}
