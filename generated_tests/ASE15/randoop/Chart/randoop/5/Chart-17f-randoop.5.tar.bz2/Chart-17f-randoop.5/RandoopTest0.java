
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)'#');
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    java.util.Date var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(31, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-435));

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays((-1), var1);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(31, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-435), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-457));

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("ThreadContext");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-457), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeries var6 = var2.addAndOrUpdate(var5);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(31, (-435), (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    org.jfree.data.time.RegularTimePeriod var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var7 = var2.addOrUpdate(var5, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Preceding"+ "'", var1.equals("Preceding"));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     int var3 = var2.getItemCount();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var6 = var5.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
//     java.util.Calendar var11 = null;
//     long var12 = var5.getMiddleMillisecond(var11);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1.0f);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears((-1), var1);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var7 = null;
    long var8 = var6.getLastMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var13 = var2.createCopy(13, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var9 = null;
//     long var10 = var8.getMiddleMillisecond(var9);
//     java.util.Calendar var11 = null;
//     var8.peg(var11);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var8, 10.0d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var9 = var8.next();
//     long var10 = var8.getMiddleMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)(-1.0d));
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)100);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8, var9);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-435), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Following"+ "'", var1.equals("Following"));

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears((-435), var1);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(1, 13, 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "January"+ "'", var2.equals("January"));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears((-457), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Nearest");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var2.getValue((-435));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     java.util.Calendar var11 = null;
//     var0.peg(var11);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var0.getLastMillisecond(var12);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Date var8 = var1.getTime();
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = var9.getNearestDayOfWeek((-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-457), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setMaximumItemCount((-457));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    var2.setNotify(false);
    org.jfree.data.time.TimeSeriesDataItem var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add(var12, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var9.getFirstMillisecond(var10);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getSerialIndex();
    java.util.Date var3 = var1.getTime();
    java.util.Date var4 = var1.getTime();
    long var5 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-459), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears((-459), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Preceding");

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    var2.setNotify(false);
    java.lang.String var12 = var2.getDomainDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var2.getValue(12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Time"+ "'", var12.equals("Time"));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.time.TimeSeries var18 = var10.createCopy(10, 10);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     long var21 = var19.getMiddleMillisecond();
//     long var22 = var19.getLastMillisecond();
//     var10.add((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1));
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Date var8 = var1.getTime();
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = var9.getFollowingDayOfWeek(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var7 = null;
    long var8 = var6.getLastMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0.0d);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.setMaximumItemAge(1417420800000L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var11 = var2.getDataItem((-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: ThreadContext", var1);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-435), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 17);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     java.util.Calendar var5 = null;
//     long var6 = var3.getLastMillisecond(var5);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.delete((-459), 17);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     java.lang.String var5 = var4.toString();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var4, 100.0d, true);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-571));

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = var5.getNearestDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     java.util.Calendar var10 = null;
//     var9.peg(var10);
// 
//   }

//  public void test106() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
//
//
//    java.lang.Class var0 = null;
//    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//
//  }
//
  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, 2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     var0.peg(var12);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, (-1), 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     long var18 = var16.getMiddleMillisecond();
//     long var19 = var16.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(byte)10);
//     var2.add(var21);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var11 = var10.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)100);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     int var15 = var13.compareTo((java.lang.Object)var14);
//     org.jfree.data.time.RegularTimePeriod var16 = var13.getPeriod();
//     var4.add(var16, (java.lang.Number)1419153269727L);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     java.util.Calendar var11 = null;
//     long var12 = var10.getFirstMillisecond(var11);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(1969, 10, 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var4 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

//  public void test118() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("21-December-2014", var1);
//
//  }
//
  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(17, 12, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)1419148800000L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
//     java.util.Calendar var13 = null;
//     long var14 = var9.getLastMillisecond(var13);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var2.addChangeListener(var10);
    java.util.List var12 = var2.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var13 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var12);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1404331199999L);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.next();
//     long var5 = var3.getLastMillisecond();
//     org.jfree.data.time.SerialDate var6 = var3.getSerialDate();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(0, var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(1, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears((-457), var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     var2.setMaximumItemCount(100);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var34 = var33.getFirstMillisecond();
//     java.util.Calendar var35 = null;
//     long var36 = var33.getMiddleMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var33.getFirstMillisecond(var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var33.next();
//     java.util.Date var40 = var33.getTime();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(var40);
//     int var42 = var41.getYearValue();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)13);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1969);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
    boolean var11 = var10.getNotify();
    var10.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
    var10.setMaximumItemAge(1417420800000L);
    org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var20 = var2.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var2.removeAgedItems(1419153269426L, false);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = var5.getFollowingDayOfWeek((-457));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Date var8 = var1.getTime();
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
    java.lang.String var10 = var9.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = var9.getFollowingDayOfWeek(17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
    boolean var6 = var5.getNotify();
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)true);
    var5.setMaximumItemCount(0);
    java.util.Collection var11 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.delete(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     var10.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     var10.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getLastMillisecond();
//     var10.add((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(byte)1, false);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-457), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)10);
    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var3 = var2.next();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)100);
    java.lang.Number var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var2, var6);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     int var14 = var0.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 12);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var5 = var3.getPreviousDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var2.getValue(12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     int var5 = var0.getMonth();
//     java.util.Calendar var6 = null;
//     long var7 = var0.getLastMillisecond(var6);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Nearest");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(byte)(-1));
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var16 = var8.getValue((-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     var2.removeAgedItems(1419153269426L, false);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-457), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     java.util.Calendar var14 = null;
//     long var15 = var0.getLastMillisecond(var14);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     long var19 = var18.getFirstMillisecond();
//     org.jfree.data.time.Year var20 = var18.getYear();
//     long var21 = var18.getLastMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)1417420800000L, true);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var4, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = var4.getNearestDayOfWeek(31);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getFirstMillisecond();
    java.util.Calendar var5 = null;
    long var6 = var3.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var3.getFirstMillisecond(var7);
    org.jfree.data.time.RegularTimePeriod var9 = var3.next();
    java.util.Date var10 = var3.getTime();
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var11);
    org.jfree.data.time.Day var13 = new org.jfree.data.time.Day(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-457), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     int var5 = var0.getMonth();
//     long var6 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41994L);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-435), 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     var2.setRangeDescription("");
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     long var34 = var32.getMiddleMillisecond();
//     long var35 = var32.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)(byte)10);
//     var2.setKey((java.lang.Comparable)(byte)10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1420099199999L);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     java.util.TimeZone var11 = null;
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var8, var11);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(17, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Nearest", var1);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     java.util.Calendar var11 = null;
//     long var12 = var0.getLastMillisecond(var11);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("21-December-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getFirstMillisecond();
//     int var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     var0.peg(var4);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getLastMillisecond(var11);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var7 = var4.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
//     boolean var10 = var2.equals((java.lang.Object)var9);
//     org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var10);
//     java.lang.Object var12 = var11.getSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + false+ "'", var12.equals(false));
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10);
//     java.util.Calendar var13 = null;
//     var12.peg(var13);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    int var10 = var3.compareTo((java.lang.Object)var8);
    org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
    boolean var12 = var3.equals((java.lang.Object)var11);
    java.lang.Number var13 = var3.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 100+ "'", var13.equals(100));

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     long var3 = var0.getLastMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.lang.Class var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var3, "Following", "Following", var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=1419148800000]");

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     java.util.TimeZone var11 = null;
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var8, var11);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(2147483647, var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getFirstMillisecond();
    java.util.Calendar var4 = null;
    long var5 = var2.getMiddleMillisecond(var4);
    java.util.Calendar var6 = null;
    long var7 = var2.getFirstMillisecond(var6);
    org.jfree.data.time.RegularTimePeriod var8 = var2.next();
    java.util.Date var9 = var2.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
    org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var14 = var10.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)"hi!");

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
    var1.addSuppressed((java.lang.Throwable)var3);
    org.jfree.data.general.SeriesException var6 = new org.jfree.data.general.SeriesException("ThreadContext");
    org.jfree.data.general.SeriesException var8 = new org.jfree.data.general.SeriesException("ThreadContext");
    var6.addSuppressed((java.lang.Throwable)var8);
    var3.addSuppressed((java.lang.Throwable)var6);
    java.lang.Throwable[] var11 = var3.getSuppressed();
    java.lang.Throwable[] var12 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var4);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getLastMillisecond();
//     org.jfree.data.time.SerialDate var5 = var2.getSerialDate();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(0, var5);
//     org.jfree.data.time.SerialDate var8 = var6.getPreviousDayOfWeek(4);
//     java.lang.String var9 = var8.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-459), var8);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "17-December-2014"+ "'", var9.equals("17-December-2014"));
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.beans.PropertyChangeListener var5 = null;
    var2.addPropertyChangeListener(var5);
    org.jfree.data.time.RegularTimePeriod var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate(var7, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("January");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("January -457", var1);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.String var3 = var2.getDomainDescription();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
    long var6 = var5.getFirstMillisecond();
    java.util.Calendar var7 = null;
    long var8 = var5.getMiddleMillisecond(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setKey((java.lang.Comparable)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.lang.Comparable var8 = var2.getKey();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var11 = var2.createCopy((-459), 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 100.0f+ "'", var8.equals(100.0f));

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setNotify(false);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.previous();
//     var2.add(var13, (java.lang.Number)1419153269727L);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 0.0d);
//     long var6 = var0.getFirstMillisecond();
//     java.util.Calendar var7 = null;
//     var0.peg(var7);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(var8, var10);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    long var3 = var1.getMiddleMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
    java.lang.Number var6 = var5.getValue();
    java.lang.Number var7 = var5.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0d+ "'", var6.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.0d+ "'", var7.equals(0.0d));

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     long var3 = var0.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    java.lang.Comparable var6 = var2.getKey();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var9 = var2.createCopy((-435), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 100.0f+ "'", var6.equals(100.0f));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    boolean var7 = var3.equals((java.lang.Object)(-459));
    java.lang.Object var8 = var3.clone();
    java.lang.Object var9 = var3.clone();
    var3.setValue((java.lang.Number)(-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths(0, var4);
//     org.jfree.data.time.SerialDate var7 = var5.getPreviousDayOfWeek(4);
//     org.jfree.data.time.SerialDate var8 = null;
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths(0, var4);
//     org.jfree.data.time.SerialDate var7 = var5.getPreviousDayOfWeek(4);
//     java.lang.String var8 = var7.toString();
//     var7.setDescription("");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "17-December-2014"+ "'", var8.equals("17-December-2014"));
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("31-December-1969", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var5 = var3.getNearestDayOfWeek(12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    boolean var8 = var2.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var10 = var2.getDataItem((-457));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond((-76589164800000L));
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-76589164800000L));

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     long var8 = var6.getMiddleMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var6.getLastMillisecond(var9);
//     java.util.Calendar var11 = null;
//     var6.peg(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419153271278L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419153271278L);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-452));

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     long var2 = var0.getSerialIndex();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getMiddleMillisecond(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419153271281L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419153271281L);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     int var11 = var9.getMonth();
//     java.util.Calendar var12 = null;
//     long var13 = var9.getLastMillisecond(var12);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
    var4.setDescription("");
    var4.setDescription("Time");
    boolean var9 = var0.equals((java.lang.Object)var4);
    var4.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var4.getValue((-452));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)100);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     int var9 = var7.compareTo((java.lang.Object)var8);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var11);
//     long var13 = var12.getMaximumItemAge();
//     int var14 = var7.compareTo((java.lang.Object)var12);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     boolean var16 = var7.equals((java.lang.Object)var15);
//     long var17 = var15.getLastMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var15, 1.0d, true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     long var3 = var0.getLastMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    int var3 = var2.getItemCount();
    var2.setNotify(false);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
    var10.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.update(17, (java.lang.Number)1419153270366L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    java.util.Collection var8 = var2.getTimePeriods();
    org.jfree.data.general.SeriesChangeListener var9 = null;
    var2.addChangeListener(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var2.getValue((-435));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=1419148800000]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("21-December-2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     int var19 = var2.getMaximumItemCount();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)100);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     int var25 = var23.compareTo((java.lang.Object)var24);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     long var29 = var28.getMaximumItemAge();
//     int var30 = var23.compareTo((java.lang.Object)var28);
//     var2.add(var23);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10.0]");

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getLastMillisecond();
//     org.jfree.data.time.SerialDate var5 = var2.getSerialDate();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(0, var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = var5.getFollowingDayOfWeek(12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     long var3 = var1.getFirstMillisecond();
//     int var4 = var1.getYear();
//     int var5 = var1.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(0, var1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2014"+ "'", var2.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    java.util.Collection var8 = var2.getTimePeriods();
    org.jfree.data.general.SeriesChangeListener var9 = null;
    var2.addChangeListener(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var2.getValue(31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var5.getLastMillisecond(var6);
// 
//   }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.String var5 = var2.getDescription();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     boolean var9 = var8.getNotify();
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.TimeSeries var14 = null;
//     org.jfree.data.time.TimeSeries var15 = var2.addAndOrUpdate(var14);
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var14 = var13.getFirstMillisecond();
//     java.util.Calendar var15 = null;
//     long var16 = var13.getMiddleMillisecond(var15);
//     java.util.Calendar var17 = null;
//     var13.peg(var17);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var13, 0.0d);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getSerialIndex();
//     java.util.Date var4 = var2.getTime();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var4);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.RegularTimePeriod var7 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var4, var6);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var4);
//     java.util.Calendar var9 = null;
//     long var10 = var8.getLastMillisecond(var9);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getLastMillisecond(var5);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     int var5 = var0.getDayOfMonth();
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getSerialIndex();
    java.util.Date var5 = var3.getTime();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(0, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-459), var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-571));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getFirstMillisecond();
    java.util.Calendar var5 = null;
    long var6 = var3.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var3.getFirstMillisecond(var7);
    org.jfree.data.time.RegularTimePeriod var9 = var3.next();
    java.util.Date var10 = var3.getTime();
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-435), var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     long var9 = var7.getMiddleMillisecond();
//     long var10 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)10);
//     var2.add(var12, true);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getSerialIndex();
    java.util.Date var4 = var2.getTime();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    java.lang.String var6 = var5.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(17, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("January -457", var1);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-452));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-455));

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     long var3 = var0.getLastMillisecond();
//     java.util.Calendar var4 = null;
//     var0.peg(var4);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-455), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-571));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.String var3 = var2.getDomainDescription();
    var2.removeAgedItems(false);
    java.util.Collection var6 = var2.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var8 = var2.getDataItem((-455));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sun Dec 21 01:14:31 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     java.lang.String var2 = var0.toString();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("January -457");

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     java.util.Calendar var13 = null;
//     var11.peg(var13);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     java.util.Calendar var14 = null;
//     long var15 = var0.getMiddleMillisecond(var14);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.removeAgedItems(1420099199999L, true);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.setMaximumItemCount(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(1969, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setNotify(false);
//     org.jfree.data.time.RegularTimePeriod var12 = null;
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     long var14 = var13.getFirstMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var15 = var2.createCopy(var12, (org.jfree.data.time.RegularTimePeriod)var13);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     var2.setMaximumItemCount(12);
//     var2.setDescription("21-December-2014");
//     var2.removeAgedItems(1419153270882L, false);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 01:14:32 PST 2014", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (-435));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Wednesday"+ "'", var1.equals("Wednesday"));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(1L);
    long var4 = var3.getFirstMillisecond();
    java.util.Calendar var5 = null;
    long var6 = var3.getMiddleMillisecond(var5);
    java.util.Calendar var7 = null;
    long var8 = var3.getFirstMillisecond(var7);
    org.jfree.data.time.RegularTimePeriod var9 = var3.next();
    java.util.Date var10 = var3.getTime();
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var11);
    org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(1L);
    long var16 = var15.getFirstMillisecond();
    java.util.Calendar var17 = null;
    long var18 = var15.getMiddleMillisecond(var17);
    java.util.Calendar var19 = null;
    long var20 = var15.getFirstMillisecond(var19);
    org.jfree.data.time.RegularTimePeriod var21 = var15.next();
    java.util.Date var22 = var15.getTime();
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var23);
    org.jfree.data.time.SerialDate var25 = var12.getEndOfCurrentMonth(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears((-435), var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, 2147483647);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.Year var9 = var7.getYear();
//     org.jfree.data.time.Year var10 = var7.getYear();
//     java.lang.Object var11 = null;
//     boolean var12 = var7.equals(var11);
//     boolean var13 = var2.equals((java.lang.Object)var12);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)100);
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     int var19 = var17.compareTo((java.lang.Object)var18);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     long var23 = var22.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var24 = null;
//     var22.addChangeListener(var24);
//     var22.fireSeriesChanged();
//     int var27 = var17.compareTo((java.lang.Object)var22);
//     var2.add(var17, true);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     long var9 = var8.getMaximumItemAge();
//     int var10 = var3.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     boolean var12 = var3.equals((java.lang.Object)var11);
//     long var13 = var11.getLastMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var11.getLastMillisecond(var14);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     java.lang.String var6 = var2.getDescription();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getLastMillisecond();
//     long var9 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)1419153270894L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419235199999L);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var7 = var4.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
//     boolean var10 = var2.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)1404331199999L, true);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, 0.0d);
//     java.lang.String var11 = var2.getDescription();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var14 = var13.getFirstMillisecond();
//     long var15 = var13.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 0.0d);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(-459));
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-457), (-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "October"+ "'", var1.equals("October"));

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("December 1969", var1);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var12);
//     boolean var14 = var0.equals((java.lang.Object)var12);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond((-1L));
//     boolean var17 = var0.equals((java.lang.Object)var16);
//     java.util.Calendar var18 = null;
//     var0.peg(var18);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(21, 0, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getDayOfMonth();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var4, var6);
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var9 = var8.next();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)100);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     int var13 = var11.compareTo((java.lang.Object)var12);
//     var11.setValue((java.lang.Number)1388563200000L);
//     java.lang.Number var16 = var11.getValue();
//     var7.add(var11);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-460), 17, 1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var9);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var9);
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.RegularTimePeriod var14 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var9, var13);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var9);
//     java.util.TimeZone var16 = null;
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year(var9, var16);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ThreadContext");
//     org.jfree.data.general.SeriesException var3 = new org.jfree.data.general.SeriesException("ThreadContext");
//     var1.addSuppressed((java.lang.Throwable)var3);
//     java.lang.String var5 = var1.toString();
//     java.lang.Throwable var6 = null;
//     var1.addSuppressed(var6);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-455));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("17-December-2014", var1);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths(0, var4);
//     org.jfree.data.time.SerialDate var7 = var5.getPreviousDayOfWeek(4);
//     java.lang.String var8 = var7.toString();
//     java.lang.String var9 = var7.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var11 = var7.getNearestDayOfWeek(12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "17-December-2014"+ "'", var8.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "17-December-2014"+ "'", var9.equals("17-December-2014"));
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: ThreadContext", var1);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var4, var6);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    long var3 = var1.getMiddleMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
    org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
    java.lang.Object var7 = var5.clone();
    org.jfree.data.general.SeriesChangeEvent var8 = new org.jfree.data.general.SeriesChangeEvent(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Following");

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=10.0]");

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.Year var9 = var7.getYear();
//     org.jfree.data.time.Year var10 = var7.getYear();
//     java.lang.Object var11 = null;
//     boolean var12 = var7.equals(var11);
//     boolean var13 = var2.equals((java.lang.Object)var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var2.addChangeListener(var14);
//     var2.fireSeriesChanged();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var18 = var2.getTimePeriod(2014);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Sun Dec 21 01:14:31 PST 2014", var1);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    boolean var6 = var2.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(var8);
//     java.util.Calendar var13 = null;
//     long var14 = var12.getFirstMillisecond(var13);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
    boolean var11 = var10.getNotify();
    var10.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
    var10.setMaximumItemAge(1417420800000L);
    org.jfree.data.time.TimeSeries var18 = var2.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var20 = var18.getDataItem(13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    var2.setNotify(false);
    java.lang.String var12 = var2.getDomainDescription();
    boolean var13 = var2.isEmpty();
    org.jfree.data.time.RegularTimePeriod var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add(var14, (java.lang.Number)0L, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Time"+ "'", var12.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.time.TimeSeries var50 = var42.createCopy(10, 10);
//     boolean var51 = var30.equals((java.lang.Object)var50);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var54 = var50.createCopy(2014, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
//     java.util.Calendar var13 = null;
//     long var14 = var9.getMiddleMillisecond(var13);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.String var2 = var1.toString();
//     long var3 = var1.getFirstMillisecond();
//     int var4 = var1.getYear();
//     int var5 = var1.getYear();
//     long var6 = var1.getLastMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(0, var1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "2014"+ "'", var2.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1420099199999L);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     var3.peg(var4);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     int var2 = var0.getDayOfMonth();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     org.jfree.data.time.TimeSeriesDataItem var31 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var27.add(var31);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
// 
//   }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("December 2014");

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Preceding", var1);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Wednesday", var1);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    java.lang.String var5 = var2.getDescription();
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    boolean var9 = var8.getNotify();
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
    java.lang.Comparable var12 = var8.getKey();
    org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
    boolean var14 = var8.getNotify();
    java.lang.String var15 = var8.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.update(0, (java.lang.Number)1388563200000L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 100.0f+ "'", var12.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January", var1);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Nearest", var1);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getSerialIndex();
//     java.util.Date var3 = var1.getTime();
//     java.util.Date var4 = var1.getTime();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     java.util.Calendar var8 = null;
//     long var9 = var5.getFirstMillisecond(var8);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setMaximumItemCount(0);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)true);
//     var14.clear();
//     boolean var19 = var14.getNotify();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     boolean var23 = var22.getNotify();
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)true);
//     var22.clear();
//     java.util.Collection var27 = var14.getTimePeriodsUniqueToOtherSeries(var22);
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var14.removeChangeListener(var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     int var40 = var30.getMonth();
//     var14.setKey((java.lang.Comparable)var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     java.lang.Class var45 = null;
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var45);
//     var46.setDescription("");
//     var46.setDescription("Time");
//     boolean var51 = var42.equals((java.lang.Object)var46);
//     java.util.Collection var52 = var14.getTimePeriodsUniqueToOtherSeries(var46);
//     java.util.Collection var53 = var2.getTimePeriodsUniqueToOtherSeries(var14);
//     int var54 = var14.getItemCount();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var56 = var14.getValue(21);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-452));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-570));

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     boolean var5 = var0.equals((java.lang.Object)(-571));
//     long var6 = var0.getFirstMillisecond();
//     int var7 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2014);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addYears(1900, var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getFirstMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    org.jfree.data.time.RegularTimePeriod var7 = var1.next();
    java.util.Date var8 = var1.getTime();
    java.util.Calendar var9 = null;
    var1.peg(var9);
    java.lang.Class var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    boolean var8 = var2.getNotify();
    java.lang.String var9 = var2.getRangeDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((-435), (java.lang.Number)(short)1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Value"+ "'", var9.equals("Value"));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "January"+ "'", var1.equals("January"));

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     int var14 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var15 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var11 = var2.createCopy((-1), 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getMiddleMillisecond();
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)10);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getFirstMillisecond(var6);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 100.0d);
//     org.jfree.data.time.RegularTimePeriod var14 = var9.previous();
//     java.util.Calendar var15 = null;
//     var9.peg(var15);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = var10.getYear();
//     org.jfree.data.time.Year var13 = var10.getYear();
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     boolean var18 = var17.getNotify();
//     boolean var20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var17, (java.lang.Object)true);
//     var17.clear();
//     boolean var22 = var17.getNotify();
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var24);
//     boolean var26 = var25.getNotify();
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var25, (java.lang.Object)true);
//     var25.clear();
//     java.util.Collection var30 = var17.getTimePeriodsUniqueToOtherSeries(var25);
//     org.jfree.data.time.TimeSeries var33 = var25.createCopy(10, 10);
//     boolean var34 = var0.equals((java.lang.Object)var25);
//     java.util.Calendar var35 = null;
//     long var36 = var0.getLastMillisecond(var35);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    java.util.Collection var8 = var2.getTimePeriods();
    long var9 = var2.getMaximumItemAge();
    long var10 = var2.getMaximumItemAge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(1, (java.lang.Number)23640L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 9223372036854775807L);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
//     org.jfree.data.time.Year var13 = var12.getYear();
//     java.util.Calendar var14 = null;
//     long var15 = var13.getFirstMillisecond(var14);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-571));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getFirstMillisecond();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getMiddleMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var4.getFirstMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var4.next();
//     java.util.Date var11 = var4.getTime();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
//     boolean var14 = var1.isAfter(var13);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var16);
//     java.lang.String var18 = var17.getDomainDescription();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     long var21 = var19.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, 0.0d);
//     boolean var25 = var17.equals((java.lang.Object)var24);
//     org.jfree.data.general.SeriesChangeEvent var26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     java.lang.String var27 = var26.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var28 = var1.compareTo((java.lang.Object)var26);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "Time"+ "'", var18.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=false]"+ "'", var27.equals("org.jfree.data.general.SeriesChangeEvent[source=false]"));
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    java.lang.String var3 = var2.getDomainDescription();
    java.lang.Class var5 = null;
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
    long var7 = var6.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var8 = null;
    var6.addChangeListener(var8);
    var6.fireSeriesChanged();
    java.lang.String var11 = var6.getDescription();
    java.lang.Class var13 = null;
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
    boolean var15 = var14.getNotify();
    var14.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
    var14.setMaximumItemAge(1417420800000L);
    org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
    org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
    org.jfree.data.time.TimeSeriesDataItem var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add(var24, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     var5.setDescription("");
//     var5.setDescription("Time");
//     boolean var10 = var1.equals((java.lang.Object)var5);
//     int var11 = var1.getMonth();
//     long var12 = var1.getFirstMillisecond();
//     long var13 = var1.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var14 = var1.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-457), var14);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     long var10 = var0.getSerialIndex();
//     long var11 = var0.getSerialIndex();
//     long var12 = var0.getSerialIndex();
//     java.util.Calendar var13 = null;
//     var0.peg(var13);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-570), 13, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.Year var9 = var7.getYear();
//     org.jfree.data.time.Year var10 = var7.getYear();
//     java.lang.Object var11 = null;
//     boolean var12 = var7.equals(var11);
//     boolean var13 = var2.equals((java.lang.Object)var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var2.addChangeListener(var14);
//     java.lang.Object var16 = var2.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addMonths(0, var4);
//     var4.setDescription("Sun Dec 21 01:14:30 PST 2014");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = var4.getPreviousDayOfWeek(13);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var8.addChangeListener(var10);
    var8.fireSeriesChanged();
    int var13 = var3.compareTo((java.lang.Object)var8);
    int var14 = var8.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var16 = var8.getTimePeriod(1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.String var4 = var1.toString();
//     long var5 = var1.getFirstMillisecond();
//     java.util.Date var6 = var1.getStart();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var6, var9);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.util.List var7 = var2.getItems();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
    long var10 = var9.getFirstMillisecond();
    java.util.Calendar var11 = null;
    long var12 = var9.getMiddleMillisecond(var11);
    java.util.Calendar var13 = null;
    long var14 = var9.getFirstMillisecond(var13);
    java.util.Calendar var15 = null;
    long var16 = var9.getMiddleMillisecond(var15);
    org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
    java.lang.Class var19 = null;
    org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1419148800000L, var19);
    java.lang.String var21 = var20.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Value"+ "'", var21.equals("Value"));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.beans.PropertyChangeListener var7 = null;
    var2.removePropertyChangeListener(var7);
    long var9 = var2.getMaximumItemAge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var11 = var2.getDataItem((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(2014);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.addMonths((-455), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)100);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     int var29 = var27.compareTo((java.lang.Object)var28);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     long var33 = var32.getMaximumItemAge();
//     int var34 = var27.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     boolean var36 = var27.equals((java.lang.Object)var35);
//     org.jfree.data.time.SerialDate var37 = var35.getSerialDate();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.previous();
//     org.jfree.data.time.TimeSeriesDataItem var40 = var22.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)1419153270690L);
//     java.util.Calendar var41 = null;
//     var35.peg(var41);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    int var8 = var2.getItemCount();
    var2.setDomainDescription("17-December-2014");
    var2.setRangeDescription("Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var8);
//     java.util.Calendar var12 = null;
//     var11.peg(var12);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(21, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(100, 2014, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     int var31 = var1.getMonth();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var35);
//     var36.setDescription("");
//     var36.setDescription("Time");
//     boolean var41 = var32.equals((java.lang.Object)var36);
//     int var42 = var32.getMonth();
//     long var43 = var32.getFirstMillisecond();
//     long var44 = var32.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var45 = var32.getSerialDate();
//     boolean var46 = var1.isBefore(var45);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getSerialIndex();
//     java.util.Date var51 = var49.getTime();
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var51);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
//     boolean var54 = var1.isOnOrBefore(var53);
//     java.lang.Class var56 = null;
//     org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var56);
//     java.lang.String var58 = var57.getDomainDescription();
//     var57.clear();
//     var57.setMaximumItemAge(1419153269727L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var62 = var1.compareTo((java.lang.Object)var57);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "Time"+ "'", var58.equals("Time"));
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(12, var1);
//     java.util.Calendar var3 = null;
//     var1.peg(var3);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getDayOfMonth();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getMiddleMillisecond(var4);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     var2.removeAgedItems(false);
//     java.util.Collection var6 = var2.getTimePeriods();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var9.next();
//     java.util.Date var16 = var9.getTime();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var17);
//     java.lang.String var20 = var19.toString();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d), true);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)1419153270882L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    int var3 = var2.getItemCount();
    var2.setNotify(false);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
    var10.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.update((-455), (java.lang.Number)1419153270656L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-571), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var13.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 28799999L);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     boolean var8 = var2.isEmpty();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getFirstMillisecond();
//     long var12 = var10.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var15 = var14.getPeriod();
//     java.lang.Object var16 = var14.clone();
//     java.lang.Object var17 = var14.clone();
//     var2.add(var14);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     int var15 = var14.getItemCount();
//     var14.setDescription("");
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)100);
//     boolean var23 = var18.equals((java.lang.Object)(-571));
//     long var24 = var18.getSerialIndex();
//     int var25 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var18);
//     int var26 = var0.compareTo((java.lang.Object)var14);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var28);
//     var29.setDescription("");
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(1L);
//     java.util.Calendar var34 = null;
//     long var35 = var33.getLastMillisecond(var34);
//     org.jfree.data.time.TimeSeriesDataItem var37 = var29.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, 0.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var14.update((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)0);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
//     org.jfree.data.time.Year var13 = var12.getYear();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getLastMillisecond(var14);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-570), 17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    int var3 = var2.getItemCount();
    var2.setNotify(false);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var8);
    var10.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setMaximumItemAge((-76589164800000L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    int var10 = var3.compareTo((java.lang.Object)var8);
    var8.setDescription("Sun Dec 21 01:14:31 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     long var14 = var0.getFirstMillisecond();
//     int var16 = var0.compareTo((java.lang.Object)(short)10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-460), var16);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=1419148800000]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, (-571));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var2.addChangeListener(var10);
    java.util.List var12 = var2.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var14 = var2.getTimePeriod(31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setMaximumItemCount(0);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)true);
//     var14.clear();
//     boolean var19 = var14.getNotify();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     boolean var23 = var22.getNotify();
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)true);
//     var22.clear();
//     java.util.Collection var27 = var14.getTimePeriodsUniqueToOtherSeries(var22);
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var14.removeChangeListener(var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     int var40 = var30.getMonth();
//     var14.setKey((java.lang.Comparable)var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     java.lang.Class var45 = null;
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var45);
//     var46.setDescription("");
//     var46.setDescription("Time");
//     boolean var51 = var42.equals((java.lang.Object)var46);
//     java.util.Collection var52 = var14.getTimePeriodsUniqueToOtherSeries(var46);
//     java.util.Collection var53 = var2.getTimePeriodsUniqueToOtherSeries(var14);
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var55);
//     var56.setDescription("");
//     var56.setDescription("Time");
//     java.util.List var61 = var56.getItems();
//     java.util.Collection var62 = var2.getTimePeriodsUniqueToOtherSeries(var56);
//     org.jfree.data.time.Month var65 = new org.jfree.data.time.Month(1, (-457));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var56.update((org.jfree.data.time.RegularTimePeriod)var65, (java.lang.Number)1419153269727L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    long var2 = var1.getSerialIndex();
    java.util.Date var3 = var1.getTime();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getFirstMillisecond();
    java.util.Calendar var9 = null;
    long var10 = var7.getMiddleMillisecond(var9);
    java.util.Calendar var11 = null;
    long var12 = var7.getFirstMillisecond(var11);
    org.jfree.data.time.RegularTimePeriod var13 = var7.next();
    java.util.Date var14 = var7.getTime();
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var4.getEndOfCurrentMonth(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var20 = var15.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-457), 10, (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(1L);
    long var6 = var5.getSerialIndex();
    java.util.Date var7 = var5.getTime();
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(0, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(31, var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(31, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     int var31 = var1.getMonth();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var35);
//     var36.setDescription("");
//     var36.setDescription("Time");
//     boolean var41 = var32.equals((java.lang.Object)var36);
//     int var42 = var32.getMonth();
//     long var43 = var32.getFirstMillisecond();
//     long var44 = var32.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var45 = var32.getSerialDate();
//     boolean var46 = var1.isBefore(var45);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var50 = var49.getSerialIndex();
//     java.util.Date var51 = var49.getTime();
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var51);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.addYears(0, var52);
//     boolean var54 = var1.isOnOrBefore(var53);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var56 = var1.getPreviousDayOfWeek(1900);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getFirstMillisecond();
    java.util.Calendar var6 = null;
    long var7 = var4.getMiddleMillisecond(var6);
    java.util.Calendar var8 = null;
    long var9 = var4.getFirstMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var4.next();
    java.util.Date var11 = var4.getTime();
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
    boolean var14 = var1.isAfter(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var16 = var1.getNearestDayOfWeek(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    int var5 = var3.compareTo((java.lang.Object)var4);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
    long var9 = var8.getMaximumItemAge();
    int var10 = var3.compareTo((java.lang.Object)var8);
    var8.setRangeDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.delete(0, 1969);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     int var13 = var0.getDayOfMonth();
//     long var14 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var15 = var0.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var15);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("December 1969");

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     long var3 = var1.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.getPeriod();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     org.jfree.data.time.RegularTimePeriod var9 = var7.next();
//     boolean var10 = var5.equals((java.lang.Object)var7);
//     java.util.Calendar var11 = null;
//     long var12 = var7.getLastMillisecond(var11);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var32 = var1.getPreviousDayOfWeek(1900);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
    java.util.Date var3 = var2.toDate();
    java.util.TimeZone var4 = null;
    org.jfree.data.time.RegularTimePeriod var5 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var3, var4);
    java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)100);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var20);
//     boolean var22 = var9.isAfter(var21);
//     boolean var23 = var7.isBefore(var21);
//     org.jfree.data.time.SerialDate var24 = var4.getEndOfCurrentMonth(var21);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day(var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var27 = var4.getPreviousDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var23 = var22.getSerialIndex();
//     java.util.Date var24 = var22.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addYears(0, var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(31, var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var30 = var29.getSerialIndex();
//     java.util.Date var31 = var29.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var36 = var35.getFirstMillisecond();
//     java.util.Calendar var37 = null;
//     long var38 = var35.getMiddleMillisecond(var37);
//     java.util.Calendar var39 = null;
//     long var40 = var35.getFirstMillisecond(var39);
//     org.jfree.data.time.RegularTimePeriod var41 = var35.next();
//     java.util.Date var42 = var35.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day(var43);
//     org.jfree.data.time.SerialDate var46 = var32.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var47 = var26.getEndOfCurrentMonth(var46);
//     boolean var48 = var1.isOn(var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var50 = var1.compareTo((java.lang.Object)1419153274341L);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.beans.PropertyChangeListener var5 = null;
//     var2.addPropertyChangeListener(var5);
//     var2.setRangeDescription("");
//     java.beans.PropertyChangeListener var9 = null;
//     var2.removePropertyChangeListener(var9);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)100);
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     int var16 = var14.compareTo((java.lang.Object)var15);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     long var20 = var19.getMaximumItemAge();
//     int var21 = var14.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     boolean var23 = var14.equals((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)1417420800000L);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)25568L, true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-435));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     long var3 = var1.getLastMillisecond();
//     org.jfree.data.time.SerialDate var4 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var13 = var12.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var12.getMiddleMillisecond(var14);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var12.next();
//     java.util.Date var19 = var12.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var20);
//     boolean var22 = var9.isAfter(var21);
//     boolean var23 = var7.isBefore(var21);
//     org.jfree.data.time.SerialDate var24 = var4.getEndOfCurrentMonth(var21);
//     org.jfree.data.time.SerialDate var25 = null;
//     org.jfree.data.time.SerialDate var26 = var21.getEndOfCurrentMonth(var25);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var8);
//     java.util.TimeZone var12 = null;
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var8, var12);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getLastMillisecond();
//     org.jfree.data.time.SerialDate var5 = var2.getSerialDate();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(17, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var4);
//     java.lang.String var6 = var5.getDomainDescription();
//     var5.clear();
//     boolean var8 = var2.equals((java.lang.Object)var5);
//     org.jfree.data.time.TimeSeries var9 = null;
//     java.util.Collection var10 = var5.getTimePeriodsUniqueToOtherSeries(var9);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var8);
//     long var12 = var11.getFirstMillisecond();
//     org.jfree.data.time.Year var13 = var11.getYear();
//     long var14 = var13.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-31507200000L));
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getFirstMillisecond();
//     java.util.Calendar var36 = null;
//     long var37 = var34.getMiddleMillisecond(var36);
//     java.util.Calendar var38 = null;
//     long var39 = var34.getFirstMillisecond(var38);
//     org.jfree.data.time.RegularTimePeriod var40 = var34.next();
//     java.util.Date var41 = var34.getTime();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var42);
//     int var44 = var1.compare(var43);
//     java.lang.Object var45 = null;
//     int var46 = var1.compareTo(var45);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.String var10 = var2.getDomainDescription();
    java.beans.PropertyChangeListener var11 = null;
    var2.removePropertyChangeListener(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var2.getValue((-455));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var10.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
//     java.lang.String var3 = var1.toString();
//     org.jfree.data.time.RegularTimePeriod var4 = var1.next();
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     long var11 = var9.getLastMillisecond();
//     org.jfree.data.time.SerialDate var12 = var9.getSerialDate();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(0, var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addYears(1, var12);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var17 = var16.next();
//     long var18 = var16.getLastMillisecond();
//     org.jfree.data.time.SerialDate var19 = var16.getSerialDate();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addMonths(0, var19);
//     org.jfree.data.time.SerialDate var22 = var20.getPreviousDayOfWeek(4);
//     boolean var23 = var6.isInRange(var12, var20);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)100);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     int var29 = var27.compareTo((java.lang.Object)var28);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     long var33 = var32.getMaximumItemAge();
//     int var34 = var27.compareTo((java.lang.Object)var32);
//     boolean var35 = var6.equals((java.lang.Object)var32);
//     int var36 = var6.getMonth();
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var38 = var37.next();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var40);
//     var41.setDescription("");
//     var41.setDescription("Time");
//     boolean var46 = var37.equals((java.lang.Object)var41);
//     int var47 = var37.getMonth();
//     long var48 = var37.getFirstMillisecond();
//     long var49 = var37.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var50 = var37.getSerialDate();
//     boolean var51 = var6.isBefore(var50);
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var55 = var54.getSerialIndex();
//     java.util.Date var56 = var54.getTime();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addYears(0, var57);
//     boolean var59 = var6.isOnOrBefore(var58);
//     java.util.Date var60 = var6.toDate();
//     int var61 = var1.compareTo((java.lang.Object)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, (org.jfree.data.time.SerialDate)var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Sun Dec 21 01:14:35 PST 2014"+ "'", var3.equals("Sun Dec 21 01:14:35 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 1);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(4, 21, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 01:14:30 PST 2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=false]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getSerialIndex();
//     java.util.Date var4 = var2.getTime();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var4);
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.RegularTimePeriod var8 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var4, var7);
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var4, var9);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     java.util.Collection var40 = var2.getTimePeriodsUniqueToOtherSeries(var34);
//     org.jfree.data.general.SeriesChangeEvent var41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
//     java.beans.PropertyChangeListener var42 = null;
//     var2.addPropertyChangeListener(var42);
//     java.lang.Comparable var44 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.setKey(var44);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(17, (-457), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    java.util.Date var2 = var1.toDate();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getSerialIndex();
    java.util.Date var9 = var7.getTime();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addYears(0, var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addYears(31, var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(31, var11);
    boolean var14 = var1.isOnOrAfter(var13);
    org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(1L);
    long var17 = var16.getSerialIndex();
    java.util.Date var18 = var16.getTime();
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
    org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(1L);
    long var23 = var22.getFirstMillisecond();
    java.util.Calendar var24 = null;
    long var25 = var22.getMiddleMillisecond(var24);
    java.util.Calendar var26 = null;
    long var27 = var22.getFirstMillisecond(var26);
    org.jfree.data.time.RegularTimePeriod var28 = var22.next();
    java.util.Date var29 = var22.getTime();
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
    org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var30);
    org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var30);
    org.jfree.data.time.SerialDate var33 = var19.getEndOfCurrentMonth(var30);
    boolean var34 = var1.isOn(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var36 = var1.getNearestDayOfWeek((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Time", var1);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)100);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     int var5 = var3.compareTo((java.lang.Object)var4);
//     var3.setValue((java.lang.Number)1388563200000L);
//     java.lang.Number var8 = var3.getValue();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var11 = var10.getFirstMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getMiddleMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var10.getFirstMillisecond(var14);
//     org.jfree.data.time.RegularTimePeriod var16 = var10.next();
//     java.util.Date var17 = var10.getTime();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     long var19 = var18.getFirstMillisecond();
//     long var20 = var18.getFirstMillisecond();
//     int var21 = var3.compareTo((java.lang.Object)var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + 1388563200000L+ "'", var8.equals(1388563200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-2649600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var1);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getMiddleMillisecond(var3);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var8, var9);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Preceding");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesException: Preceding"+ "'", var2.equals("org.jfree.data.general.SeriesException: Preceding"));

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     long var2 = var0.getLastMillisecond();
//     org.jfree.data.time.SerialDate var3 = var0.getSerialDate();
//     int var4 = var0.getMonth();
//     int var5 = var0.getDayOfMonth();
//     int var6 = var0.getYear();
//     java.util.Calendar var7 = null;
//     long var8 = var0.getMiddleMillisecond(var7);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.time.TimePeriodFormatException: ");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Fourth"+ "'", var1.equals("Fourth"));

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getSerialIndex();
    java.util.Date var4 = var2.getTime();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var4);
    java.util.TimeZone var6 = null;
    org.jfree.data.time.RegularTimePeriod var7 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var4, var6);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var4);
    long var9 = var8.getLastMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10);
//     java.lang.String var13 = var10.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "31-December-1969"+ "'", var13.equals("31-December-1969"));
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
    long var8 = var7.getFirstMillisecond();
    java.util.Calendar var9 = null;
    long var10 = var7.getMiddleMillisecond(var9);
    java.util.Calendar var11 = null;
    long var12 = var7.getFirstMillisecond(var11);
    org.jfree.data.time.RegularTimePeriod var13 = var7.next();
    java.util.Date var14 = var7.getTime();
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var15);
    boolean var17 = var4.isAfter(var16);
    boolean var18 = var2.isBefore(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1900, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries(var0, "org.jfree.data.general.SeriesException: ThreadContext", "ThreadContext", var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var34.removeChangeListener(var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     var54.setDescription("");
//     var54.setDescription("Time");
//     boolean var59 = var50.equals((java.lang.Object)var54);
//     int var60 = var50.getMonth();
//     var34.setKey((java.lang.Comparable)var60);
//     var34.setMaximumItemCount(100);
//     boolean var64 = var1.equals((java.lang.Object)var34);
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var67 = var66.getFirstMillisecond();
//     java.util.Calendar var68 = null;
//     long var69 = var66.getMiddleMillisecond(var68);
//     java.util.Calendar var70 = null;
//     long var71 = var66.getFirstMillisecond(var70);
//     org.jfree.data.time.RegularTimePeriod var72 = var66.next();
//     java.util.Date var73 = var66.getTime();
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var73);
//     org.jfree.data.time.Month var75 = new org.jfree.data.time.Month(var73);
//     org.jfree.data.time.FixedMillisecond var76 = new org.jfree.data.time.FixedMillisecond(var73);
//     var34.add((org.jfree.data.time.RegularTimePeriod)var76, (java.lang.Number)(-1));
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
    var2.clear();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var2.addChangeListener(var10);
    var2.setMaximumItemCount(12);
    var2.setDescription("21-December-2014");
    boolean var16 = var2.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var18 = var2.getDataItem(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    long var3 = var2.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.addChangeListener(var4);
    var2.fireSeriesChanged();
    java.lang.String var7 = var2.getDescription();
    java.util.Collection var8 = var2.getTimePeriods();
    org.jfree.data.general.SeriesChangeListener var9 = null;
    var2.addChangeListener(var9);
    java.lang.String var11 = var2.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Value"+ "'", var11.equals("Value"));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getSerialIndex();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
    long var7 = var1.getLastMillisecond();
    java.util.Date var8 = var1.getStart();
    long var9 = var1.getMiddleMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("20-January-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     var2.setDomainDescription("org.jfree.data.general.SeriesException: ThreadContext");
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var10);
//     boolean var12 = var11.getNotify();
//     var11.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var11.getDataItem((org.jfree.data.time.RegularTimePeriod)var15);
//     long var17 = var15.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.next();
//     org.jfree.data.time.RegularTimePeriod var19 = var15.previous();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (-1.0d));
//     java.lang.Class var22 = null;
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var25 = var24.getSerialIndex();
//     java.util.Date var26 = var24.getTime();
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year(var26);
//     java.util.TimeZone var28 = null;
//     org.jfree.data.time.RegularTimePeriod var29 = org.jfree.data.time.RegularTimePeriod.createInstance(var22, var26, var28);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)0);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419153277274L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Wednesday");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(20, 1, 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-457), 0, (-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     java.lang.String var4 = var3.toString();
//     java.lang.String var5 = var3.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "2014"+ "'", var4.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "2014"+ "'", var5.equals("2014"));
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     var2.setMaximumItemCount(0);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)true);
//     var14.clear();
//     boolean var19 = var14.getNotify();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     boolean var23 = var22.getNotify();
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)true);
//     var22.clear();
//     java.util.Collection var27 = var14.getTimePeriodsUniqueToOtherSeries(var22);
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var14.removeChangeListener(var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var31 = var30.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     var34.setDescription("");
//     var34.setDescription("Time");
//     boolean var39 = var30.equals((java.lang.Object)var34);
//     int var40 = var30.getMonth();
//     var14.setKey((java.lang.Comparable)var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var43 = var42.next();
//     java.lang.Class var45 = null;
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var45);
//     var46.setDescription("");
//     var46.setDescription("Time");
//     boolean var51 = var42.equals((java.lang.Object)var46);
//     java.util.Collection var52 = var14.getTimePeriodsUniqueToOtherSeries(var46);
//     java.util.Collection var53 = var2.getTimePeriodsUniqueToOtherSeries(var14);
//     int var54 = var14.getItemCount();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var14.delete((-452), 1900);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 0);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var3);
//     java.lang.String var5 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2014]"+ "'", var5.equals("org.jfree.data.general.SeriesChangeEvent[source=2014]"));
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.Year var3 = var0.getYear();
//     int var4 = var0.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var5 = var0.previous();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var8 = var7.getSerialIndex();
//     java.util.Date var9 = var7.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var14 = var13.getFirstMillisecond();
//     java.util.Calendar var15 = null;
//     long var16 = var13.getMiddleMillisecond(var15);
//     java.util.Calendar var17 = null;
//     long var18 = var13.getFirstMillisecond(var17);
//     org.jfree.data.time.RegularTimePeriod var19 = var13.next();
//     java.util.Date var20 = var13.getTime();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var21);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day(var21);
//     org.jfree.data.time.SerialDate var24 = var10.getEndOfCurrentMonth(var21);
//     boolean var25 = var0.equals((java.lang.Object)var21);
//     org.jfree.data.time.RegularTimePeriod var26 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.previous();
//     int var13 = var9.getMonth();
//     java.util.Calendar var14 = null;
//     var9.peg(var14);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    var2.setDescription("");
    var2.setDescription("Time");
    java.util.List var7 = var2.getItems();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
    long var10 = var9.getFirstMillisecond();
    java.util.Calendar var11 = null;
    long var12 = var9.getMiddleMillisecond(var11);
    java.util.Calendar var13 = null;
    long var14 = var9.getFirstMillisecond(var13);
    java.util.Calendar var15 = null;
    long var16 = var9.getMiddleMillisecond(var15);
    org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
    int var19 = var2.getMaximumItemCount();
    var2.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setMaximumItemCount((-571));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2147483647);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getFirstMillisecond();
    java.util.Calendar var6 = null;
    long var7 = var4.getMiddleMillisecond(var6);
    java.util.Calendar var8 = null;
    long var9 = var4.getFirstMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var4.next();
    java.util.Date var11 = var4.getTime();
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
    boolean var14 = var1.isAfter(var13);
    org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(1L);
    long var19 = var18.getSerialIndex();
    java.util.Date var20 = var18.getTime();
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addYears(0, var21);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(31, var22);
    org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(1L);
    long var26 = var25.getSerialIndex();
    java.util.Date var27 = var25.getTime();
    org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
    org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(1L);
    long var32 = var31.getFirstMillisecond();
    java.util.Calendar var33 = null;
    long var34 = var31.getMiddleMillisecond(var33);
    java.util.Calendar var35 = null;
    long var36 = var31.getFirstMillisecond(var35);
    org.jfree.data.time.RegularTimePeriod var37 = var31.next();
    java.util.Date var38 = var31.getTime();
    org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
    org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var39);
    org.jfree.data.time.Day var41 = new org.jfree.data.time.Day(var39);
    org.jfree.data.time.SerialDate var42 = var28.getEndOfCurrentMonth(var39);
    org.jfree.data.time.SerialDate var43 = var22.getEndOfCurrentMonth(var42);
    org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond(1L);
    long var48 = var47.getSerialIndex();
    java.util.Date var49 = var47.getTime();
    org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addYears(0, var50);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.addYears(31, var51);
    org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(1L);
    long var55 = var54.getSerialIndex();
    java.util.Date var56 = var54.getTime();
    org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
    org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond(1L);
    long var61 = var60.getFirstMillisecond();
    java.util.Calendar var62 = null;
    long var63 = var60.getMiddleMillisecond(var62);
    java.util.Calendar var64 = null;
    long var65 = var60.getFirstMillisecond(var64);
    org.jfree.data.time.RegularTimePeriod var66 = var60.next();
    java.util.Date var67 = var60.getTime();
    org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
    org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var68);
    org.jfree.data.time.Day var70 = new org.jfree.data.time.Day(var68);
    org.jfree.data.time.SerialDate var71 = var57.getEndOfCurrentMonth(var68);
    org.jfree.data.time.SerialDate var72 = var51.getEndOfCurrentMonth(var71);
    boolean var73 = var1.isInRange(var43, var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var75 = var43.getPreviousDayOfWeek((-570));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     long var7 = var6.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var6.addChangeListener(var8);
//     var6.fireSeriesChanged();
//     java.lang.String var11 = var6.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     var14.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var14.setMaximumItemAge(1417420800000L);
//     org.jfree.data.time.TimeSeries var22 = var6.addAndOrUpdate(var14);
//     org.jfree.data.time.TimeSeries var23 = var2.addAndOrUpdate(var22);
//     var2.removeAgedItems(1419153274341L, false);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-457), 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var9 = var8.getFirstMillisecond();
//     java.util.Calendar var10 = null;
//     long var11 = var8.getMiddleMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var8.getFirstMillisecond(var12);
//     org.jfree.data.time.RegularTimePeriod var14 = var8.next();
//     java.util.Date var15 = var8.getTime();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(var15);
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)(-1.0d));
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var34.removeChangeListener(var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     var54.setDescription("");
//     var54.setDescription("Time");
//     boolean var59 = var50.equals((java.lang.Object)var54);
//     int var60 = var50.getMonth();
//     var34.setKey((java.lang.Comparable)var60);
//     var34.setMaximumItemCount(100);
//     boolean var64 = var1.equals((java.lang.Object)var34);
//     int var65 = var1.toSerial();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var67 = var1.getPreviousDayOfWeek((-452));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(20, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.String var5 = var2.getDescription();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     boolean var9 = var8.getNotify();
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
//     boolean var14 = var8.getNotify();
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var18);
//     var19.setDescription("");
//     var19.setDescription("Time");
//     boolean var24 = var15.equals((java.lang.Object)var19);
//     int var25 = var15.getMonth();
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var27);
//     boolean var29 = var15.equals((java.lang.Object)var27);
//     var8.add((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)1419153276498L);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("2014", var1);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.beans.PropertyChangeListener var8 = null;
//     var2.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.previous();
//     long var14 = var12.getSerialIndex();
//     long var15 = var12.getSerialIndex();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)100, true);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: ThreadContext", var1);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
    var2.clear();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var2.getValue(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-571));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
//     var4.setDescription("");
//     var4.setDescription("Time");
//     boolean var9 = var0.equals((java.lang.Object)var4);
//     int var10 = var0.getMonth();
//     long var11 = var0.getFirstMillisecond();
//     long var12 = var0.getFirstMillisecond();
//     long var13 = var0.getFirstMillisecond();
//     java.util.Calendar var14 = null;
//     long var15 = var0.getFirstMillisecond(var14);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.Year var9 = var7.getYear();
//     org.jfree.data.time.Year var10 = var7.getYear();
//     java.lang.Object var11 = null;
//     boolean var12 = var7.equals(var11);
//     boolean var13 = var2.equals((java.lang.Object)var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var2.addChangeListener(var14);
//     boolean var16 = var2.isEmpty();
//     var2.removeAgedItems(1419153270565L, false);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=10.0]", var1);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(4, 0, (-25544));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(31, (-1), 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-25544));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-6654));

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getLastMillisecond();
//     long var21 = var19.getLastMillisecond();
//     long var22 = var19.getLastMillisecond();
//     java.lang.String var23 = var19.toString();
//     int var24 = var19.getMonth();
//     int var25 = var9.compareTo((java.lang.Object)var19);
//     long var26 = var9.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "21-December-2014"+ "'", var23.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1L);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(13, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    org.jfree.data.time.RegularTimePeriod var1 = var0.next();
    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var3);
    var4.setDescription("");
    var4.setDescription("Time");
    boolean var9 = var0.equals((java.lang.Object)var4);
    var4.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.addChangeListener(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var33);
//     boolean var35 = var34.getNotify();
//     boolean var37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)true);
//     var34.clear();
//     boolean var39 = var34.getNotify();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var41);
//     boolean var43 = var42.getNotify();
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var42, (java.lang.Object)true);
//     var42.clear();
//     java.util.Collection var47 = var34.getTimePeriodsUniqueToOtherSeries(var42);
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var34.removeChangeListener(var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var51 = var50.next();
//     java.lang.Class var53 = null;
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var53);
//     var54.setDescription("");
//     var54.setDescription("Time");
//     boolean var59 = var50.equals((java.lang.Object)var54);
//     int var60 = var50.getMonth();
//     var34.setKey((java.lang.Comparable)var60);
//     var34.setMaximumItemCount(100);
//     boolean var64 = var1.equals((java.lang.Object)var34);
//     int var65 = var1.toSerial();
//     org.jfree.data.time.FixedMillisecond var68 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var69 = var68.getFirstMillisecond();
//     java.util.Calendar var70 = null;
//     long var71 = var68.getMiddleMillisecond(var70);
//     java.util.Calendar var72 = null;
//     long var73 = var68.getFirstMillisecond(var72);
//     org.jfree.data.time.RegularTimePeriod var74 = var68.next();
//     java.util.Date var75 = var68.getTime();
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.createInstance(var75);
//     org.jfree.data.time.SerialDate var77 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var76);
//     org.jfree.data.time.FixedMillisecond var80 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var81 = var80.getFirstMillisecond();
//     java.util.Calendar var82 = null;
//     long var83 = var80.getMiddleMillisecond(var82);
//     java.util.Calendar var84 = null;
//     long var85 = var80.getFirstMillisecond(var84);
//     org.jfree.data.time.RegularTimePeriod var86 = var80.next();
//     java.util.Date var87 = var80.getTime();
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.createInstance(var87);
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var88);
//     org.jfree.data.time.SerialDate var90 = var77.getEndOfCurrentMonth(var89);
//     boolean var91 = var1.isAfter(var89);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var93 = var1.getPreviousDayOfWeek(13);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "17-December-2014"+ "'", var27.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == false);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var20 = var19.next();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)100);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     int var24 = var22.compareTo((java.lang.Object)var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var26);
//     long var28 = var27.getMaximumItemAge();
//     int var29 = var22.compareTo((java.lang.Object)var27);
//     boolean var30 = var1.equals((java.lang.Object)var27);
//     int var31 = var1.getMonth();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var35);
//     var36.setDescription("");
//     var36.setDescription("Time");
//     boolean var41 = var32.equals((java.lang.Object)var36);
//     int var42 = var32.getMonth();
//     long var43 = var32.getFirstMillisecond();
//     long var44 = var32.getFirstMillisecond();
//     org.jfree.data.time.SerialDate var45 = var32.getSerialDate();
//     boolean var46 = var1.isBefore(var45);
//     java.util.Date var47 = var1.toDate();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     long var8 = var6.getMiddleMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var6.getLastMillisecond(var9);
//     java.lang.String var11 = var6.toString();
//     int var13 = var6.compareTo((java.lang.Object)(byte)0);
//     java.util.Calendar var14 = null;
//     long var15 = var6.getMiddleMillisecond(var14);
//     long var16 = var6.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419153278915L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419153278915L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Sun Dec 21 01:14:38 PST 2014"+ "'", var11.equals("Sun Dec 21 01:14:38 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419153278915L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419153278915L);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getSerialIndex();
    java.util.Date var6 = var4.getTime();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(31, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addMonths(31, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = var10.getPreviousDayOfWeek((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getLastMillisecond();
//     org.jfree.data.time.SerialDate var7 = var4.getSerialDate();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(1, var7);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.SerialDate var14 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(0, var14);
//     org.jfree.data.time.SerialDate var17 = var15.getPreviousDayOfWeek(4);
//     boolean var18 = var1.isInRange(var7, var15);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     long var22 = var20.getLastMillisecond();
//     org.jfree.data.time.SerialDate var23 = var20.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(0, var23);
//     org.jfree.data.time.SerialDate var26 = var24.getPreviousDayOfWeek(4);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var31 = var1.isInRange(var26, (org.jfree.data.time.SerialDate)var30);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var35 = var34.getFirstMillisecond();
//     java.util.Calendar var36 = null;
//     long var37 = var34.getMiddleMillisecond(var36);
//     java.util.Calendar var38 = null;
//     long var39 = var34.getFirstMillisecond(var38);
//     org.jfree.data.time.RegularTimePeriod var40 = var34.next();
//     java.util.Date var41 = var34.getTime();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var42);
//     int var44 = var1.compare(var43);
//     org.jfree.data.time.SerialDate var45 = null;
//     int var46 = var1.compare(var45);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-455), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Value");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getLastMillisecond();
//     long var2 = var0.getLastMillisecond();
//     int var3 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.next();
//     java.util.Date var5 = var0.getEnd();
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var5, var6);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4, 0, (-25544));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1969, (-25547), 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 31, (-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     long var3 = var2.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.addChangeListener(var4);
//     var2.fireSeriesChanged();
//     java.lang.String var7 = var2.getDescription();
//     var2.removeAgedItems(false);
//     var2.removeAgedItems(1419153274341L, true);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var2.next();
//     java.util.Date var9 = var2.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var10);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10);
//     int var13 = var12.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1969);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-570), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     boolean var3 = var2.getNotify();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)true);
//     var2.clear();
//     boolean var7 = var2.getNotify();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var9);
//     boolean var11 = var10.getNotify();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var10, (java.lang.Object)true);
//     var10.clear();
//     java.util.Collection var15 = var2.getTimePeriodsUniqueToOtherSeries(var10);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var2.removeChangeListener(var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var19 = var18.next();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var21);
//     var22.setDescription("");
//     var22.setDescription("Time");
//     boolean var27 = var18.equals((java.lang.Object)var22);
//     int var28 = var18.getMonth();
//     var2.setKey((java.lang.Comparable)var28);
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var31);
//     boolean var33 = var32.getNotify();
//     boolean var35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)true);
//     var32.clear();
//     boolean var37 = var32.getNotify();
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     org.jfree.data.general.SeriesChangeListener var40 = null;
//     var32.addChangeListener(var40);
//     java.util.List var42 = var32.getItems();
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     java.lang.String var44 = var43.toString();
//     org.jfree.data.time.RegularTimePeriod var45 = var43.previous();
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var49);
//     var50.setDescription("");
//     var50.setDescription("Time");
//     boolean var55 = var46.equals((java.lang.Object)var50);
//     int var56 = var46.getMonth();
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var58);
//     boolean var60 = var46.equals((java.lang.Object)var58);
//     boolean var61 = var43.equals((java.lang.Object)var58);
//     int var62 = var32.getIndex((org.jfree.data.time.RegularTimePeriod)var43);
//     java.util.Collection var63 = var2.getTimePeriodsUniqueToOtherSeries(var32);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var65 = var2.getValue(12);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "2014"+ "'", var44.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Value");

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Fourth", var1);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     java.lang.String var5 = var2.getDescription();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var7);
//     boolean var9 = var8.getNotify();
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var8, (java.lang.Object)true);
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.TimeSeries var13 = var2.addAndOrUpdate(var8);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond((-2649600000L));
//     var8.add((org.jfree.data.time.RegularTimePeriod)var15, 100.0d);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     var2.setDescription("");
//     var2.setDescription("Time");
//     java.util.List var7 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var10 = var9.getFirstMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var9.getMiddleMillisecond(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getMiddleMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419148800000L);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getLastMillisecond();
//     long var21 = var19.getLastMillisecond();
//     long var22 = var19.getLastMillisecond();
//     java.lang.String var23 = var19.toString();
//     int var24 = var19.getMonth();
//     int var25 = var9.compareTo((java.lang.Object)var19);
//     int var26 = var19.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "21-December-2014"+ "'", var23.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 21);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sun Dec 21 01:14:32 PST 2014");

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     java.util.Calendar var10 = null;
//     long var11 = var9.getLastMillisecond(var10);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     long var7 = var5.getLastMillisecond();
//     org.jfree.data.time.SerialDate var8 = var5.getSerialDate();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addYears(1, var8);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.next();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.SerialDate var15 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(0, var15);
//     org.jfree.data.time.SerialDate var18 = var16.getPreviousDayOfWeek(4);
//     boolean var19 = var2.isInRange(var8, var16);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     long var23 = var21.getLastMillisecond();
//     org.jfree.data.time.SerialDate var24 = var21.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths(0, var24);
//     org.jfree.data.time.SerialDate var27 = var25.getPreviousDayOfWeek(4);
//     java.lang.String var28 = var27.toString();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     boolean var32 = var2.isInRange(var27, (org.jfree.data.time.SerialDate)var31);
//     int var33 = var2.toSerial();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addMonths((-457), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "17-December-2014"+ "'", var28.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "17-December-2014"+ "'", var29.equals("17-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 21);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     java.util.Date var2 = var1.toDate();
//     org.jfree.data.time.SerialDate var3 = null;
//     boolean var4 = var1.isAfter(var3);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
    long var5 = var4.getSerialIndex();
    java.util.Date var6 = var4.getTime();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addYears(0, var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addYears(31, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2147483647, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var5 = var4.next();
//     long var6 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var7 = var4.next();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
//     boolean var10 = var2.equals((java.lang.Object)var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     long var12 = var11.getFirstMillisecond();
//     org.jfree.data.time.Year var13 = var11.getYear();
//     org.jfree.data.time.Year var14 = var11.getYear();
//     java.lang.Object var15 = null;
//     boolean var16 = var11.equals(var15);
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)1419153269727L);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var18, "Sun Dec 21 01:14:31 PST 2014", "Preceding", var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)100);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     int var28 = var26.compareTo((java.lang.Object)var27);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var30);
//     long var32 = var31.getMaximumItemAge();
//     org.jfree.data.general.SeriesChangeListener var33 = null;
//     var31.addChangeListener(var33);
//     var31.fireSeriesChanged();
//     int var36 = var26.compareTo((java.lang.Object)var31);
//     int var37 = var31.getItemCount();
//     int var38 = var18.compareTo((java.lang.Object)var37);
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var40);
//     var41.setDescription("");
//     java.lang.String var44 = var41.getDescription();
//     java.lang.Class var46 = null;
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var46);
//     boolean var48 = var47.getNotify();
//     boolean var50 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var47, (java.lang.Object)true);
//     java.lang.Comparable var51 = var47.getKey();
//     org.jfree.data.time.TimeSeries var52 = var41.addAndOrUpdate(var47);
//     boolean var53 = var18.equals((java.lang.Object)var41);
//     var2.add(var18);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getFirstMillisecond();
//     int var3 = var0.getYear();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var5);
//     boolean var7 = var6.getNotify();
//     boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)true);
//     var6.clear();
//     boolean var11 = var6.getNotify();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var13);
//     boolean var15 = var14.getNotify();
//     boolean var17 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, (java.lang.Object)true);
//     var14.clear();
//     java.util.Collection var19 = var6.getTimePeriodsUniqueToOtherSeries(var14);
//     org.jfree.data.general.SeriesChangeListener var20 = null;
//     var6.removeChangeListener(var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var25);
//     var26.setDescription("");
//     var26.setDescription("Time");
//     boolean var31 = var22.equals((java.lang.Object)var26);
//     int var32 = var22.getMonth();
//     var6.setKey((java.lang.Comparable)var32);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.next();
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var37);
//     var38.setDescription("");
//     var38.setDescription("Time");
//     boolean var43 = var34.equals((java.lang.Object)var38);
//     java.util.Collection var44 = var6.getTimePeriodsUniqueToOtherSeries(var38);
//     org.jfree.data.general.SeriesChangeEvent var45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
//     boolean var46 = var0.equals((java.lang.Object)var45);
//     java.lang.Class var48 = null;
//     org.jfree.data.time.TimeSeries var49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0f, var48);
//     java.lang.String var50 = var49.getDomainDescription();
//     boolean var51 = var0.equals((java.lang.Object)var49);
//     java.util.Collection var52 = var49.getTimePeriods();
//     org.jfree.data.time.RegularTimePeriod var53 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var54 = var49.getIndex(var53);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "Time"+ "'", var50.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(2014);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-571), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1L);
    long var3 = var2.getSerialIndex();
    java.util.Date var4 = var2.getTime();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var4);
    java.util.TimeZone var6 = null;
    org.jfree.data.time.RegularTimePeriod var7 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var4, var6);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var4);
    org.jfree.data.time.RegularTimePeriod var9 = var8.previous();
    java.util.Calendar var10 = null;
    long var11 = var8.getMiddleMillisecond(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1L);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
    org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)1L);
    java.lang.Object var4 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var2 = var1.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var1.next();
//     java.util.Date var8 = var1.getTime();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     int var10 = var9.getYearValue();
//     java.util.Date var11 = var9.getStart();
//     long var12 = var9.getLastMillisecond();
//     java.util.Calendar var13 = null;
//     var9.peg(var13);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Date var3 = var2.getEnd();
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var3, var4);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var5 = var4.getFirstMillisecond();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getMiddleMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var4.getFirstMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var4.next();
//     java.util.Date var11 = var4.getTime();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var12);
//     boolean var14 = var1.isAfter(var13);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var20 = var19.getSerialIndex();
//     java.util.Date var21 = var19.getTime();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(0, var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addYears(31, var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var27 = var26.getSerialIndex();
//     java.util.Date var28 = var26.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(1L);
//     long var33 = var32.getFirstMillisecond();
//     java.util.Calendar var34 = null;
//     long var35 = var32.getMiddleMillisecond(var34);
//     java.util.Calendar var36 = null;
//     long var37 = var32.getFirstMillisecond(var36);
//     org.jfree.data.time.RegularTimePeriod var38 = var32.next();
//     java.util.Date var39 = var32.getTime();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day(var40);
//     org.jfree.data.time.SerialDate var43 = var29.getEndOfCurrentMonth(var40);
//     org.jfree.data.time.SerialDate var44 = var23.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addYears(1969, var23);
//     java.lang.String var46 = var45.toString();
//     org.jfree.data.time.SerialDate var47 = var1.getEndOfCurrentMonth(var45);
//     java.lang.String var48 = var47.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "31-December-3938"+ "'", var46.equals("31-December-3938"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "31-December-3938"+ "'", var48.equals("31-December-3938"));
// 
//   }

}
