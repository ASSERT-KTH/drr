
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 100.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)'a');
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("hi!", var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 0.0d, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    java.awt.Paint var3 = null;
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker((-1.0d), var1, var2, var3, var4, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)100.0f, 1.0d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.setInverted(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelPaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setFixedDimension((-1.0d));
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    java.awt.Shape var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setUpArrow(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var6 = null;
    var0.setMarkerBand(var6);
    java.awt.Paint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickMarkPaint(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setFixedDimension((-1.0d));
    var0.setAutoRange(true);
    org.jfree.data.Range var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var2 = var1.getLabel();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    java.text.AttributedString var3 = var1.getAttributedLabel((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
    java.awt.Font var4 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
    java.awt.Paint var6 = null;
    org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, var6);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setLineAlignment(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.VerticalAlignment var6 = var4.getVerticalAlignment();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     java.awt.Font var10 = var8.getLabelFont();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
//     boolean var12 = var6.equals((java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!", var1);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setMargin(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var1, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var3.setLabel("");
//     org.jfree.chart.util.Layer var6 = null;
//     boolean var7 = var0.removeDomainMarker(10, (org.jfree.chart.plot.Marker)var3, var6);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     var0.zoom(100.0d);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var3 = var2.getLabel();
//     boolean var4 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var2);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.getDomainAxisIndex(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.AxisState var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     java.util.List var6 = var1.refreshTicks(var2, var3, var4, var5);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
    java.awt.Font var4 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var4);
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"", (java.lang.Object)"hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    java.lang.String var6 = var5.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 10.0d, 10.0d, var3);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.lang.String var6 = var4.getText();
    org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var7.createOutsetRectangle(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    var0.setNegativeArrowVisible(false);
    java.awt.Shape var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setUpArrow(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Stroke var2 = var0.getSectionOutlineStroke((java.lang.Comparable)(-1.0f));
    java.awt.Shape var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemShape(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.VerticalAlignment var6 = var4.getVerticalAlignment();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     java.awt.Font var10 = var8.getLabelFont();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
//     java.lang.Object var12 = var11.clone();
//     java.lang.String var13 = var11.getText();
//     org.jfree.chart.util.RectangleInsets var14 = var11.getPadding();
//     var4.setPadding(var14);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.AxisLocation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(0, var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var13 = var12.getStandardTickUnits();
//     java.awt.Font var14 = var12.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var17 = var16.getAlpha();
//     java.awt.Paint var18 = var16.getPaint();
//     org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("", var14, var18);
//     var5.setNoDataMessagePaint(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.data.category.CategoryDataset var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var1.getCategorySeriesMiddle((java.lang.Comparable)10.0f, (java.lang.Comparable)true, var4, 1.0E-5d, var6, var7);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 15);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.util.RectangleAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(byte)0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedWidth(10.0d);
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var7 = var2.toRangeHeight(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     boolean var1 = var0.getSectionOutlinesVisible();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     org.jfree.chart.plot.PlotState var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var0.draw(var2, var3, var4, var5, var6);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var13 = var12.getAlpha();
    java.awt.Paint var14 = var12.getPaint();
    org.jfree.chart.util.RectangleEdge var15 = null;
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
    java.awt.Font var20 = var18.getLabelFont();
    org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("", var20);
    java.lang.Object var22 = var21.clone();
    org.jfree.chart.util.VerticalAlignment var23 = var21.getVerticalAlignment();
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
    java.awt.Font var26 = var24.getLabelFont();
    var24.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var29 = new org.jfree.chart.plot.MultiplePiePlot();
    var29.setBackgroundAlpha(1.0f);
    java.awt.Stroke var32 = var29.getOutlineStroke();
    var24.setPlot((org.jfree.chart.plot.Plot)var29);
    java.awt.Image var34 = var29.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var36 = null;
    org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29, (org.jfree.chart.block.Arrangement)var35, var36);
    org.jfree.chart.util.RectangleInsets var38 = var37.getLegendItemGraphicPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("hi!", var6, var14, var15, var16, var23, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var4 = var3.getAlpha();
//     boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0d, (java.lang.Object)var4);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
//     boolean var17 = var13.equals((java.lang.Object)var15);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var1 = var0.getLabelURL();
//     java.util.EventListener var2 = null;
//     boolean var3 = var0.hasListener(var2);
//     var0.setInverted(true);
//     java.awt.Paint var6 = var0.getAxisLinePaint();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.axis.AxisState var13 = var0.draw(var7, (-1.0d), var9, var10, var11, var12);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
    org.jfree.chart.event.TitleChangeListener var7 = null;
    var4.removeChangeListener(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.data.Range var13 = var12.getHeightRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var14 = var4.arrange(var9, var12);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var4 = var3.getAlpha();
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var3, var5);
    org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation();
    org.jfree.chart.util.SortOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var2, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 100.0d, 0.0d, 0.0d, 1.0E-5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 10.0d, 100.0d, 0, (java.lang.Comparable)1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.lang.String var6 = var4.getText();
    org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
    double var8 = var4.getContentYOffset();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setHorizontalAlignment(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.setInverted(true);
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLeftArrow(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    double var4 = var0.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var4 = var3.getAlpha();
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var3, var5);
    org.jfree.chart.text.TextAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setLabelTextAnchor(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     double var7 = var6.getBottom();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.block.BlockFrame var14 = var12.getFrame();
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var12.removeChangeListener(var15);
//     java.awt.geom.Rectangle2D var17 = var12.getBounds();
//     java.awt.geom.Rectangle2D var20 = var6.createInsetRectangle(var17, false, false);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var1 = var0.getLabelURL();
//     java.util.EventListener var2 = null;
//     boolean var3 = var0.hasListener(var2);
//     var0.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
//     var7.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var10 = var7.getOutlineStroke();
//     var0.setAxisLineStroke(var10);
//     java.awt.Shape var12 = var0.getLeftArrow();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
//     java.lang.Object var20 = var19.clone();
//     org.jfree.chart.block.BlockFrame var21 = var19.getFrame();
//     org.jfree.chart.event.TitleChangeListener var22 = null;
//     var19.removeChangeListener(var22);
//     java.awt.geom.Rectangle2D var24 = var19.getBounds();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var27 = var26.getStandardTickUnits();
//     java.awt.Font var28 = var26.getLabelFont();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("", var28);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.block.BlockFrame var31 = var29.getFrame();
//     org.jfree.chart.event.TitleChangeListener var32 = null;
//     var29.removeChangeListener(var32);
//     java.awt.geom.Rectangle2D var34 = var29.getBounds();
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.chart.axis.AxisState var37 = var0.draw(var13, 100.0d, var24, var34, var35, var36);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.urls.PieURLGenerator var1 = null;
//     var0.setLegendLabelURLGenerator(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     java.lang.Object var9 = var8.clone();
//     org.jfree.chart.block.BlockFrame var10 = var8.getFrame();
//     org.jfree.chart.event.TitleChangeListener var11 = null;
//     var8.removeChangeListener(var11);
//     java.awt.geom.Rectangle2D var13 = var8.getBounds();
//     java.awt.geom.Point2D var14 = null;
//     org.jfree.chart.plot.PlotState var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var0.draw(var3, var13, var14, var15, var16);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)100);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     java.awt.Paint var6 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var8.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var12 = var11.getAlpha();
//     org.jfree.chart.util.Layer var13 = null;
//     boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
//     var0.setRangeAxisLocation(var15, false);
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var20 = var0.removeDomainMarker(var18, var19);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.awt.Color var1 = java.awt.Color.getColor("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    boolean var5 = var0.isAxisLineVisible();
    java.awt.Paint var6 = var0.getTickLabelPaint();
    java.awt.Stroke var7 = null;
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
    java.awt.Font var11 = var9.getLabelFont();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.util.RectangleInsets var14 = var12.getPadding();
    double var15 = var14.getBottom();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var16 = new org.jfree.chart.block.LineBorder(var6, var7, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
    java.awt.Font var4 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var4);
    var6.setToolTipText("");
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.data.Range var13 = var12.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var15 = var12.toFixedWidth(10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var16 = var6.arrange(var9, var12);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     boolean var5 = var0.isAxisLineVisible();
//     java.awt.Font var6 = var0.getTickLabelFont();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var13.removeChangeListener(var16);
//     java.awt.geom.Rectangle2D var18 = var13.getBounds();
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
//     java.awt.Font var22 = var20.getLabelFont();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.block.BlockFrame var25 = var23.getFrame();
//     org.jfree.chart.event.TitleChangeListener var26 = null;
//     var23.removeChangeListener(var26);
//     java.awt.geom.Rectangle2D var28 = var23.getBounds();
//     org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var28, "", "");
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.setWeight(100);
//     org.jfree.data.category.CategoryDataset var36 = var32.getDataset(0);
//     var32.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var39 = var38.getLabelURL();
//     java.util.EventListener var40 = null;
//     boolean var41 = var38.hasListener(var40);
//     var38.setInverted(true);
//     java.awt.Paint var44 = var38.getAxisLinePaint();
//     org.jfree.data.Range var45 = var32.getDataRange((org.jfree.chart.axis.ValueAxis)var38);
//     org.jfree.chart.util.RectangleEdge var46 = var32.getDomainAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     org.jfree.chart.axis.AxisState var48 = var0.draw(var7, 102.0d, var18, var28, var46, var47);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var23 = var22.getStandardTickUnits();
//     java.awt.Font var24 = var22.getLabelFont();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var24);
//     java.lang.Object var26 = var25.clone();
//     org.jfree.chart.block.BlockFrame var27 = var25.getFrame();
//     org.jfree.chart.event.TitleChangeListener var28 = null;
//     var25.removeChangeListener(var28);
//     java.awt.geom.Rectangle2D var30 = var25.getBounds();
//     var19.addSubtitle((org.jfree.chart.title.Title)var25);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
//     java.lang.Object var20 = var19.clone();
//     org.jfree.chart.block.BlockFrame var21 = var19.getFrame();
//     var13.setFrame(var21);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    var0.setBackgroundAlpha(1.0f);
    var0.setBackgroundImageAlignment(1);
    org.jfree.data.category.CategoryDataset var5 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)0.0f, 1.0E-5d, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setWeight(100);
//     org.jfree.data.category.CategoryDataset var10 = var6.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var11 = var6.getDomainAxis();
//     java.awt.Paint var12 = var6.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var13 = var6.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var15 = var14.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var18 = var17.getAlpha();
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var20 = var14.removeRangeMarker((org.jfree.chart.plot.Marker)var17, var19);
//     org.jfree.chart.axis.AxisLocation var21 = var14.getRangeAxisLocation();
//     var6.setRangeAxisLocation(var21, false);
//     var0.setRangeAxisLocation(10, var21);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var14 and var0.", var14.equals(var0) == var0.equals(var14));
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", var3);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot();
//     boolean var12 = var11.getSectionOutlinesVisible();
//     var11.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
//     java.lang.Object var20 = var19.clone();
//     org.jfree.chart.block.BlockFrame var21 = var19.getFrame();
//     org.jfree.chart.event.TitleChangeListener var22 = null;
//     var19.removeChangeListener(var22);
//     java.awt.geom.Rectangle2D var24 = var19.getBounds();
//     var11.setLegendItemShape((java.awt.Shape)var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.setWeight(100);
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset(0);
//     var26.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var33 = var32.getLabelURL();
//     java.util.EventListener var34 = null;
//     boolean var35 = var32.hasListener(var34);
//     var32.setInverted(true);
//     java.awt.Paint var38 = var32.getAxisLinePaint();
//     org.jfree.data.Range var39 = var26.getDataRange((org.jfree.chart.axis.ValueAxis)var32);
//     org.jfree.chart.util.RectangleEdge var40 = var26.getDomainAxisEdge();
//     double var41 = var0.valueToJava2D(12.0d, var24, var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextLine var1 = null;
    var0.addLine(var1);
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLineAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.setInverted(true);
    java.awt.Paint var9 = var3.getAxisLinePaint();
    var0.setTickMarkPaint(var9);
    java.awt.Font var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     org.jfree.chart.renderer.PolarItemRenderer var2 = var0.getRenderer();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     org.jfree.chart.plot.PlotState var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var0.draw(var3, var4, var5, var6, var7);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.plot.PiePlotState var17 = new org.jfree.chart.plot.PiePlotState(var16);
//     java.awt.geom.Rectangle2D var18 = var17.getExplodedPieArea();
//     double var19 = var17.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var22 = var21.getStandardTickUnits();
//     java.awt.Font var23 = var21.getLabelFont();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var23);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.block.BlockFrame var26 = var24.getFrame();
//     org.jfree.chart.event.TitleChangeListener var27 = null;
//     var24.removeChangeListener(var27);
//     java.awt.geom.Rectangle2D var29 = var24.getBounds();
//     var17.setLinkArea(var29);
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var32 = var31.getStandardTickUnits();
//     java.awt.Font var33 = var31.getLabelFont();
//     var31.setLabel("");
//     boolean var36 = var31.isAxisLineVisible();
//     java.lang.Object var37 = var13.draw(var15, var29, (java.lang.Object)var31);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    boolean var9 = var8.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var12 = var11.getAlpha();
    org.jfree.chart.util.Layer var13 = null;
    boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
    org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
    var0.setRangeAxisLocation(var15, false);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var0.getRendererForDataset(var18);
    org.jfree.chart.LegendItemCollection var20 = var0.getLegendItems();
    org.jfree.data.category.CategoryDataset var22 = null;
    var0.setDataset(0, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, (-1.0f), 0.8f, var4, 12.0d, var6);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var2.rendererChanged(var3);
//     org.jfree.data.general.WaferMapDataset var5 = var2.getDataset();
//     org.jfree.chart.LegendItemCollection var6 = var2.getLegendItems();
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.awt.Graphics2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var6 = var4.arrange(var5);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.awt.Font var6 = var4.getFont();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.data.Range var11 = var10.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var13 = var10.toFixedWidth(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var14 = var4.arrange(var7, var10);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.block.BlockContainer var15 = var13.getItemContainer();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var18 = var17.getStandardTickUnits();
//     java.awt.Font var19 = var17.getLabelFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     java.lang.Object var21 = var20.clone();
//     java.lang.String var22 = var20.getText();
//     org.jfree.chart.util.RectangleInsets var23 = var20.getPadding();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var27);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.util.VerticalAlignment var30 = var28.getVerticalAlignment();
//     var15.add((org.jfree.chart.block.Block)var20, (java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var26
//     assertTrue("Contract failed: equals-hashcode on var18 and var26", var18.equals(var26) ? var18.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var18
//     assertTrue("Contract failed: equals-hashcode on var26 and var18", var26.equals(var18) ? var26.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7);
    org.jfree.chart.axis.CategoryAxis var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var0.getDomainAxisIndex(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAnchor var5 = var0.getDomainGridlinePosition();
    org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxisForDataset(1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var17 = var11.getQuadrantPaint((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    var11.clearRangeMarkers(15);
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
    boolean var18 = var17.getSectionOutlinesVisible();
    double var19 = var17.getMaximumExplodePercent();
    var17.setSectionOutlinesVisible(false);
    var17.setLabelLinkMargin(10.0d);
    java.awt.Paint var24 = var17.getShadowPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setQuadrantPaint(10, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
    java.awt.Font var4 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var4);
    var6.setToolTipText("");
    var6.setExpandToFitSpace(false);
    java.lang.String var11 = var6.getID();
    java.awt.geom.Rectangle2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setBounds(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     var0.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
//     var0.setNoDataMessage("hi!");
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var13.removeChangeListener(var16);
//     java.awt.geom.Rectangle2D var18 = var13.getBounds();
//     java.awt.geom.Point2D var19 = null;
//     org.jfree.chart.plot.PlotState var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var0.draw(var8, var18, var19, var20, var21);
//     java.awt.Paint var23 = null;
//     var0.setRadiusGridlinePaint(var23);
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var28 = var27.getStandardTickUnits();
//     java.awt.Font var29 = var27.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var32 = var31.getAlpha();
//     java.awt.Paint var33 = var31.getPaint();
//     org.jfree.chart.text.TextLine var34 = new org.jfree.chart.text.TextLine("", var29, var33);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var37 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var38 = var37.getPaint();
//     var36.setOutlinePaint(var38);
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("hi!", var29, var38);
//     var0.setAngleLabelFont(var29);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     java.lang.String var5 = var0.getLabel();
//     java.awt.Stroke var6 = var0.getAxisLineStroke();
//     java.lang.String var7 = var0.getLabelToolTip();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.PiePlotState var10 = new org.jfree.chart.plot.PiePlotState(var9);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.PiePlotState var12 = new org.jfree.chart.plot.PiePlotState(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getExplodedPieArea();
//     double var14 = var12.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
//     java.lang.Object var20 = var19.clone();
//     org.jfree.chart.block.BlockFrame var21 = var19.getFrame();
//     org.jfree.chart.event.TitleChangeListener var22 = null;
//     var19.removeChangeListener(var22);
//     java.awt.geom.Rectangle2D var24 = var19.getBounds();
//     var12.setLinkArea(var24);
//     var10.setPieArea(var24);
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var29 = var28.getCategoryMargin();
//     var28.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var35 = var34.getAngleTickUnit();
//     var34.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     var34.setAxis((org.jfree.chart.axis.ValueAxis)var38);
//     var34.setNoDataMessage("hi!");
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var45 = var44.getStandardTickUnits();
//     java.awt.Font var46 = var44.getLabelFont();
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("", var46);
//     java.lang.Object var48 = var47.clone();
//     org.jfree.chart.block.BlockFrame var49 = var47.getFrame();
//     org.jfree.chart.event.TitleChangeListener var50 = null;
//     var47.removeChangeListener(var50);
//     java.awt.geom.Rectangle2D var52 = var47.getBounds();
//     java.awt.geom.Point2D var53 = null;
//     org.jfree.chart.plot.PlotState var54 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var55 = null;
//     var34.draw(var42, var52, var53, var54, var55);
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     var57.setWeight(100);
//     org.jfree.data.category.CategoryDataset var61 = var57.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var62 = var57.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var63 = var57.getRangeAxisEdge();
//     double var64 = var28.getCategoryStart(15, 10, var52, var63);
//     double var65 = var0.valueToJava2D(0.0d, var24, var63);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var45
//     assertTrue("Contract failed: equals-hashcode on var1 and var45", var1.equals(var45) ? var1.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var45
//     assertTrue("Contract failed: equals-hashcode on var17 and var45", var17.equals(var45) ? var17.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var1
//     assertTrue("Contract failed: equals-hashcode on var45 and var1", var45.equals(var1) ? var45.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var17
//     assertTrue("Contract failed: equals-hashcode on var45 and var17", var45.equals(var17) ? var45.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var1.setValue((-1.0d));
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffset(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     double var7 = var6.getBottom();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var10 = var9.getCategoryMargin();
//     var9.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var16 = var15.getAngleTickUnit();
//     var15.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     var15.setAxis((org.jfree.chart.axis.ValueAxis)var19);
//     var15.setNoDataMessage("hi!");
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var27);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.block.BlockFrame var30 = var28.getFrame();
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var28.removeChangeListener(var31);
//     java.awt.geom.Rectangle2D var33 = var28.getBounds();
//     java.awt.geom.Point2D var34 = null;
//     org.jfree.chart.plot.PlotState var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var15.draw(var23, var33, var34, var35, var36);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.setWeight(100);
//     org.jfree.data.category.CategoryDataset var42 = var38.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var43 = var38.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var44 = var38.getRangeAxisEdge();
//     double var45 = var9.getCategoryStart(15, 10, var33, var44);
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var48 = var47.getAlpha();
//     java.awt.Paint var49 = var47.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var50 = var47.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var53 = var52.getAlpha();
//     java.awt.Paint var54 = var52.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var55 = var52.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var56 = var6.createAdjustedRectangle(var33, var50, var55);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var52
//     assertTrue("Contract failed: equals-hashcode on var47 and var52", var47.equals(var52) ? var47.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var47
//     assertTrue("Contract failed: equals-hashcode on var52 and var47", var52.equals(var47) ? var52.hashCode() == var47.hashCode() : true);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    java.util.EventListener var8 = null;
    boolean var9 = var6.hasListener(var8);
    var6.setInverted(true);
    java.awt.Paint var12 = var6.getAxisLinePaint();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.plot.PlotOrientation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    var5.setBackgroundImageAlpha(1.0f);
    var5.setBackgroundAlpha(0.8f);
    java.lang.Object var14 = null;
    boolean var15 = var5.equals(var14);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
    java.awt.Font var22 = var20.getLabelFont();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var22);
    java.awt.Paint var25 = null;
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var25);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.setWeight(100);
    org.jfree.data.category.CategoryDataset var31 = var27.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var32 = var27.getDomainAxis();
    java.awt.Paint var33 = var27.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("", var22, (org.jfree.chart.plot.Plot)var27, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setPieChart(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var2 = var0.getStroke(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     java.lang.String var3 = var2.getNoDataMessage();
//     org.jfree.chart.LegendItemCollection var4 = var2.getLegendItems();
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setAutoRangeIncludesZero(true);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     java.lang.String var5 = var0.getLabel();
//     java.awt.Stroke var6 = var0.getAxisLineStroke();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var9 = var8.getCategoryMargin();
//     var8.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var15 = var14.getAngleTickUnit();
//     var14.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var14.setAxis((org.jfree.chart.axis.ValueAxis)var18);
//     var14.setNoDataMessage("hi!");
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
//     java.awt.Font var26 = var24.getLabelFont();
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("", var26);
//     java.lang.Object var28 = var27.clone();
//     org.jfree.chart.block.BlockFrame var29 = var27.getFrame();
//     org.jfree.chart.event.TitleChangeListener var30 = null;
//     var27.removeChangeListener(var30);
//     java.awt.geom.Rectangle2D var32 = var27.getBounds();
//     java.awt.geom.Point2D var33 = null;
//     org.jfree.chart.plot.PlotState var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     var14.draw(var22, var32, var33, var34, var35);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     var37.setWeight(100);
//     org.jfree.data.category.CategoryDataset var41 = var37.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var42 = var37.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var43 = var37.getRangeAxisEdge();
//     double var44 = var8.getCategoryStart(15, 10, var32, var43);
//     var0.setDownArrow((java.awt.Shape)var32);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
//     boolean var8 = var7.getSectionOutlinesVisible();
//     var7.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var13 = var12.getStandardTickUnits();
//     java.awt.Font var14 = var12.getLabelFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("", var14);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.block.BlockFrame var17 = var15.getFrame();
//     org.jfree.chart.event.TitleChangeListener var18 = null;
//     var15.removeChangeListener(var18);
//     java.awt.geom.Rectangle2D var20 = var15.getBounds();
//     var7.setLegendItemShape((java.awt.Shape)var20);
//     var6.trim(var20);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.lang.String var6 = var4.getText();
//     org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
//     double var8 = var4.getContentYOffset();
//     double var9 = var4.getContentYOffset();
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
//     java.awt.Font var16 = var14.getLabelFont();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
//     java.awt.Paint var19 = null;
//     org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setWeight(100);
//     org.jfree.data.category.CategoryDataset var25 = var21.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var26 = var21.getDomainAxis();
//     java.awt.Paint var27 = var21.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("", var16, (org.jfree.chart.plot.Plot)var21, false);
//     boolean var30 = var29.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var31 = null;
//     var29.removeProgressListener(var31);
//     org.jfree.chart.plot.Plot var33 = var29.getPlot();
//     var4.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     boolean var2 = var0.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var3 = null;
//     var0.setDataset(var3);
//     boolean var5 = var0.isRangeZoomable();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.PiePlotState var9 = new org.jfree.chart.plot.PiePlotState(var8);
//     java.awt.geom.Rectangle2D var10 = var9.getExplodedPieArea();
//     double var11 = var9.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
//     java.awt.Font var15 = var13.getLabelFont();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.block.BlockFrame var18 = var16.getFrame();
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var16.removeChangeListener(var19);
//     java.awt.geom.Rectangle2D var21 = var16.getBounds();
//     var9.setLinkArea(var21);
//     java.awt.Point var23 = var0.translateValueThetaRadiusToJava2D(0.0d, 0.0d, var21);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var6 = var5.getCategoryMargin();
//     var5.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var12 = var11.getAngleTickUnit();
//     var11.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     var11.setAxis((org.jfree.chart.axis.ValueAxis)var15);
//     var11.setNoDataMessage("hi!");
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var22 = var21.getStandardTickUnits();
//     java.awt.Font var23 = var21.getLabelFont();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var23);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.block.BlockFrame var26 = var24.getFrame();
//     org.jfree.chart.event.TitleChangeListener var27 = null;
//     var24.removeChangeListener(var27);
//     java.awt.geom.Rectangle2D var29 = var24.getBounds();
//     java.awt.geom.Point2D var30 = null;
//     org.jfree.chart.plot.PlotState var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     var11.draw(var19, var29, var30, var31, var32);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.setWeight(100);
//     org.jfree.data.category.CategoryDataset var38 = var34.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var39 = var34.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var40 = var34.getRangeAxisEdge();
//     double var41 = var5.getCategoryStart(15, 10, var29, var40);
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var45 = var44.getStandardTickUnits();
//     java.awt.Font var46 = var44.getLabelFont();
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("", var46);
//     java.lang.Object var48 = var47.clone();
//     org.jfree.chart.block.BlockFrame var49 = var47.getFrame();
//     var47.setText("hi!");
//     org.jfree.chart.util.RectangleEdge var52 = var47.getPosition();
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     org.jfree.chart.axis.AxisState var54 = var0.draw(var2, 0.0d, var29, var42, var52, var53);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     java.awt.Paint var6 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var8.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var12 = var11.getAlpha();
//     org.jfree.chart.util.Layer var13 = null;
//     boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
//     var0.setRangeAxisLocation(var15, false);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var0.getRendererForDataset(var18);
//     org.jfree.chart.LegendItemCollection var20 = var0.getLegendItems();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var25 = var24.getLabel();
//     org.jfree.chart.util.Layer var26 = null;
//     var21.addRangeMarker(1, (org.jfree.chart.plot.Marker)var24, var26);
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot();
//     boolean var29 = var28.getSectionOutlinesVisible();
//     double var30 = var28.getMaximumExplodePercent();
//     var28.setSectionOutlinesVisible(false);
//     var28.setLabelLinkMargin(10.0d);
//     java.awt.Paint var35 = var28.getShadowPaint();
//     java.awt.Paint var36 = var28.getLabelOutlinePaint();
//     boolean var37 = var24.equals((java.lang.Object)var36);
//     var0.setBackgroundPaint(var36);
//     
//     // Checks the contract:  equals-hashcode on var8 and var21
//     assertTrue("Contract failed: equals-hashcode on var8 and var21", var8.equals(var21) ? var8.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var8
//     assertTrue("Contract failed: equals-hashcode on var21 and var8", var21.equals(var8) ? var21.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var24
//     assertTrue("Contract failed: equals-hashcode on var11 and var24", var11.equals(var24) ? var11.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var11
//     assertTrue("Contract failed: equals-hashcode on var24 and var11", var24.equals(var11) ? var24.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
    var15.setFixedDimension((-1.0d));
    java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var15);
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
    java.awt.Font var25 = var23.getLabelFont();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var25);
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("", var25);
    java.awt.Paint var28 = null;
    org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var25, var28);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    var30.setWeight(100);
    org.jfree.data.category.CategoryDataset var34 = var30.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var35 = var30.getDomainAxis();
    java.awt.Paint var36 = var30.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("", var25, (org.jfree.chart.plot.Plot)var30, false);
    boolean var39 = var38.getAntiAlias();
    org.jfree.chart.event.ChartChangeEventType var40 = null;
    org.jfree.chart.event.ChartChangeEvent var41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var38, var40);
    double var42 = var15.getAutoRangeMinimumSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis)var15, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0E-8d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    java.awt.Color var1 = java.awt.Color.getColor("Category Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
//     java.lang.Comparable var1 = null;
//     boolean var2 = var0.containsKey(var1);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     double var8 = var6.extendHeight(10.0d);
//     double var9 = var6.getTop();
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     boolean var11 = var10.getSectionOutlinesVisible();
//     var10.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
//     java.awt.Font var17 = var15.getLabelFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var17);
//     java.lang.Object var19 = var18.clone();
//     org.jfree.chart.block.BlockFrame var20 = var18.getFrame();
//     org.jfree.chart.event.TitleChangeListener var21 = null;
//     var18.removeChangeListener(var21);
//     java.awt.geom.Rectangle2D var23 = var18.getBounds();
//     var10.setLegendItemShape((java.awt.Shape)var23);
//     org.jfree.chart.util.LengthAdjustmentType var25 = null;
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var28 = var27.getAlpha();
//     java.awt.Paint var29 = var27.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var30 = var27.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var31 = var6.createAdjustedRectangle(var23, var25, var30);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setFixedDimension((-1.0d));
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    var0.setInverted(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
    java.awt.Paint var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setWeight(100);
    org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
    java.awt.Paint var18 = var12.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
    boolean var21 = var20.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var22 = null;
    var20.removeProgressListener(var22);
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
    org.jfree.chart.util.RectangleInsets var27 = var20.getPadding();
    java.awt.geom.Rectangle2D var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var31 = var27.createOutsetRectangle(var28, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)' ');
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("WMAP_Plot", var1, 100.0f, 1.0f, var4, 0.0d, var6);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var21 = null;
//     var19.removeProgressListener(var21);
//     var19.setBackgroundImageAlpha(100.0f);
//     var19.removeLegend();
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var28 = var27.getStandardTickUnits();
//     java.awt.Font var29 = var27.getLabelFont();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var29);
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getPadding();
//     org.jfree.chart.block.BlockFrame var33 = var30.getFrame();
//     var19.removeSubtitle((org.jfree.chart.title.Title)var30);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var4 = var3.getLabelURL();
//     java.util.EventListener var5 = null;
//     boolean var6 = var3.hasListener(var5);
//     var3.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
//     var10.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var13 = var10.getOutlineStroke();
//     var3.setAxisLineStroke(var13);
//     java.awt.Shape var15 = var3.getLeftArrow();
//     boolean var16 = var0.equals((java.lang.Object)var15);
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     var0.handleClick((-1), 10, var19);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setWeight(100);
    org.jfree.data.category.CategoryDataset var5 = var1.getDataset(0);
    var1.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
    java.awt.Font var11 = var9.getLabelFont();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var14 = var13.getAlpha();
    java.awt.Paint var15 = var13.getPaint();
    org.jfree.chart.text.TextLine var16 = new org.jfree.chart.text.TextLine("", var11, var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("hi!", var11, var20);
    var1.setRangeGridlinePaint(var20);
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var25 = var24.getAngleTickUnit();
    boolean var26 = var24.isDomainZoomable();
    org.jfree.data.xy.XYDataset var27 = null;
    var24.setDataset(var27);
    java.awt.Stroke var29 = var24.getRadiusGridlineStroke();
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var32 = var31.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    var33.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var37 = var36.getLabelURL();
    java.util.EventListener var38 = null;
    boolean var39 = var36.hasListener(var38);
    var36.setInverted(true);
    java.awt.Paint var42 = var36.getAxisLinePaint();
    var33.setTickMarkPaint(var42);
    var31.setPaint(var42);
    org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var46 = var45.getStandardTickUnits();
    java.awt.Font var47 = var45.getLabelFont();
    var45.setLabel("");
    java.lang.String var50 = var45.getLabel();
    java.awt.Stroke var51 = var45.getAxisLineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(1.0E-5d, var20, var29, var42, var51, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + ""+ "'", var50.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("WMAP_Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(10.0d, false);
//     var0.clearAnnotations();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var7 = var6.getAngleTickUnit();
//     var6.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     var6.setAxis((org.jfree.chart.axis.ValueAxis)var10);
//     var6.setNoDataMessage("hi!");
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
//     java.lang.Object var20 = var19.clone();
//     org.jfree.chart.block.BlockFrame var21 = var19.getFrame();
//     org.jfree.chart.event.TitleChangeListener var22 = null;
//     var19.removeChangeListener(var22);
//     java.awt.geom.Rectangle2D var24 = var19.getBounds();
//     java.awt.geom.Point2D var25 = null;
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     var6.draw(var14, var24, var25, var26, var27);
//     var0.drawBackground(var5, var24);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var16 = var15.getAlpha();
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var15, var17);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var24.setCategoryMargin((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setTextAntiAlias((java.lang.Object)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     java.awt.Font var4 = var2.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var7 = var6.getAlpha();
//     java.awt.Paint var8 = var6.getPaint();
//     org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("", var4, var8);
//     var0.setAggregatedItemsPaint(var8);
//     var0.setAggregatedItemsKey((java.lang.Comparable)(byte)10);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     var13.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var17 = var16.getLabelURL();
//     java.util.EventListener var18 = null;
//     boolean var19 = var16.hasListener(var18);
//     var16.setInverted(true);
//     java.awt.Paint var22 = var16.getAxisLinePaint();
//     var13.setTickMarkPaint(var22);
//     var0.setAggregatedItemsPaint(var22);
//     org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var28 = var27.getStandardTickUnits();
//     java.awt.Font var29 = var27.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var32 = var31.getAlpha();
//     java.awt.Paint var33 = var31.getPaint();
//     org.jfree.chart.text.TextLine var34 = new org.jfree.chart.text.TextLine("", var29, var33);
//     var25.setAggregatedItemsPaint(var33);
//     var25.setAggregatedItemsKey((java.lang.Comparable)(byte)10);
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     var38.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var42 = var41.getLabelURL();
//     java.util.EventListener var43 = null;
//     boolean var44 = var41.hasListener(var43);
//     var41.setInverted(true);
//     java.awt.Paint var47 = var41.getAxisLinePaint();
//     var38.setTickMarkPaint(var47);
//     var25.setAggregatedItemsPaint(var47);
//     var0.setBackgroundPaint(var47);
//     
//     // Checks the contract:  equals-hashcode on var3 and var28
//     assertTrue("Contract failed: equals-hashcode on var3 and var28", var3.equals(var28) ? var3.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var3
//     assertTrue("Contract failed: equals-hashcode on var28 and var3", var28.equals(var3) ? var28.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var31
//     assertTrue("Contract failed: equals-hashcode on var6 and var31", var6.equals(var31) ? var6.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var6
//     assertTrue("Contract failed: equals-hashcode on var31 and var6", var31.equals(var6) ? var31.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.8f, 100.0f, 0.05d, 100.0f, 0.8f);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.AxisLocation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeAxisLocation(var17, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(short)100);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     boolean var16 = var11.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var23 = var22.getLabelURL();
//     var22.setNegativeArrowVisible(false);
//     java.awt.Font var26 = var22.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var37 = var36.getPaint();
//     var35.setOutlinePaint(var37);
//     var28.setRangeGridlinePaint(var37);
//     org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
//     var11.setRangeAxisLocation(var40, false);
//     org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var45 = var44.getLabelURL();
//     java.util.EventListener var46 = null;
//     boolean var47 = var44.hasListener(var46);
//     var44.setLabel("");
//     boolean var50 = var44.isVerticalTickLabels();
//     org.jfree.chart.axis.MarkerAxisBand var51 = null;
//     var44.setMarkerBand(var51);
//     var11.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var44);
//     org.jfree.chart.plot.Marker var54 = null;
//     org.jfree.chart.util.Layer var55 = null;
//     boolean var56 = var11.removeDomainMarker(var54, var55);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var1 = var0.getLabelURL();
//     java.util.EventListener var2 = null;
//     boolean var3 = var0.hasListener(var2);
//     var0.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
//     var7.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var10 = var7.getOutlineStroke();
//     var0.setAxisLineStroke(var10);
//     boolean var12 = var0.getAutoRangeStickyZero();
//     org.jfree.chart.axis.TickUnitSource var13 = var0.getStandardTickUnits();
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var16 = var15.getAngleTickUnit();
//     var15.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     var15.setAxis((org.jfree.chart.axis.ValueAxis)var19);
//     var15.setNoDataMessage("hi!");
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var27);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.block.BlockFrame var30 = var28.getFrame();
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var28.removeChangeListener(var31);
//     java.awt.geom.Rectangle2D var33 = var28.getBounds();
//     java.awt.geom.Point2D var34 = null;
//     org.jfree.chart.plot.PlotState var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var15.draw(var23, var33, var34, var35, var36);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var40 = var39.getCategoryMargin();
//     var39.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var46 = var45.getAngleTickUnit();
//     var45.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D();
//     var45.setAxis((org.jfree.chart.axis.ValueAxis)var49);
//     var45.setNoDataMessage("hi!");
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var56 = var55.getStandardTickUnits();
//     java.awt.Font var57 = var55.getLabelFont();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("", var57);
//     java.lang.Object var59 = var58.clone();
//     org.jfree.chart.block.BlockFrame var60 = var58.getFrame();
//     org.jfree.chart.event.TitleChangeListener var61 = null;
//     var58.removeChangeListener(var61);
//     java.awt.geom.Rectangle2D var63 = var58.getBounds();
//     java.awt.geom.Point2D var64 = null;
//     org.jfree.chart.plot.PlotState var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     var45.draw(var53, var63, var64, var65, var66);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     var68.setWeight(100);
//     org.jfree.data.category.CategoryDataset var72 = var68.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var73 = var68.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var74 = var68.getRangeAxisEdge();
//     double var75 = var39.getCategoryStart(15, 10, var63, var74);
//     double var76 = var0.valueToJava2D(0.0d, var33, var74);
//     
//     // Checks the contract:  equals-hashcode on var13 and var26
//     assertTrue("Contract failed: equals-hashcode on var13 and var26", var13.equals(var26) ? var13.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var56
//     assertTrue("Contract failed: equals-hashcode on var13 and var56", var13.equals(var56) ? var13.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var13
//     assertTrue("Contract failed: equals-hashcode on var26 and var13", var26.equals(var13) ? var26.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var56
//     assertTrue("Contract failed: equals-hashcode on var26 and var56", var26.equals(var56) ? var26.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var13
//     assertTrue("Contract failed: equals-hashcode on var56 and var13", var56.equals(var13) ? var56.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var26
//     assertTrue("Contract failed: equals-hashcode on var56 and var26", var56.equals(var26) ? var56.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var45
//     assertTrue("Contract failed: equals-hashcode on var15 and var45", var15.equals(var45) ? var15.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var15
//     assertTrue("Contract failed: equals-hashcode on var45 and var15", var45.equals(var15) ? var45.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     org.jfree.chart.renderer.PolarItemRenderer var2 = var0.getRenderer();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomRangeAxes(102.0d, var4, var5, false);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     var0.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
//     var0.setNoDataMessage("hi!");
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var13.removeChangeListener(var16);
//     java.awt.geom.Rectangle2D var18 = var13.getBounds();
//     java.awt.geom.Point2D var19 = null;
//     org.jfree.chart.plot.PlotState var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var0.draw(var8, var18, var19, var20, var21);
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
//     java.awt.Font var25 = var23.getLabelFont();
//     var23.setLabel("");
//     boolean var28 = var23.isAxisLineVisible();
//     org.jfree.data.Range var29 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var23);
//     
//     // Checks the contract:  equals-hashcode on var11 and var24
//     assertTrue("Contract failed: equals-hashcode on var11 and var24", var11.equals(var24) ? var11.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var11
//     assertTrue("Contract failed: equals-hashcode on var24 and var11", var24.equals(var11) ? var24.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    java.awt.Paint var3 = null;
    var0.setSectionPaint((java.lang.Comparable)10, var3);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    var5.setLabel("");
    java.lang.String var10 = var5.getLabel();
    java.awt.Stroke var11 = var5.getAxisLineStroke();
    var0.setLabelOutlineStroke(var11);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.setWeight(100);
    org.jfree.data.category.CategoryDataset var17 = var13.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var18 = var13.getDomainAxis();
    java.awt.Paint var19 = var13.getRangeCrosshairPaint();
    var0.setLabelPaint(var19);
    java.awt.Font var21 = var0.getLabelFont();
    java.awt.Stroke var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelLinkStroke(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var2 = var1.getAlpha();
//     java.awt.Paint var3 = var1.getPaint();
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     boolean var5 = var4.getSectionOutlinesVisible();
//     double var6 = var4.getMaximumExplodePercent();
//     var4.setSectionOutlinesVisible(false);
//     var4.setLabelLinkMargin(10.0d);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     int var12 = var4.getPieIndex();
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
//     java.awt.Font var16 = var14.getLabelFont();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
//     java.lang.Object var18 = var17.clone();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     boolean var21 = var17.equals((java.lang.Object)var20);
//     var4.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
//     double var23 = var4.getInteriorGap();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var30 = var29.getAlpha();
//     java.awt.Paint var31 = var29.getPaint();
//     org.jfree.chart.text.TextLine var32 = new org.jfree.chart.text.TextLine("", var27, var31);
//     var4.setLabelPaint(var31);
//     
//     // Checks the contract:  equals-hashcode on var1 and var29
//     assertTrue("Contract failed: equals-hashcode on var1 and var29", var1.equals(var29) ? var1.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var1
//     assertTrue("Contract failed: equals-hashcode on var29 and var1", var29.equals(var1) ? var29.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var26
//     assertTrue("Contract failed: equals-hashcode on var15 and var26", var15.equals(var26) ? var15.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var15
//     assertTrue("Contract failed: equals-hashcode on var26 and var15", var26.equals(var15) ? var26.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    java.awt.Paint var3 = null;
    var0.setSectionPaint((java.lang.Comparable)10, var3);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseSectionPaint(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     double var8 = var6.extendHeight(10.0d);
//     double var10 = var6.extendWidth(0.2d);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var13 = var12.getCategoryMargin();
//     var12.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var19 = var18.getAngleTickUnit();
//     var18.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setAxis((org.jfree.chart.axis.ValueAxis)var22);
//     var18.setNoDataMessage("hi!");
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var29 = var28.getStandardTickUnits();
//     java.awt.Font var30 = var28.getLabelFont();
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var30);
//     java.lang.Object var32 = var31.clone();
//     org.jfree.chart.block.BlockFrame var33 = var31.getFrame();
//     org.jfree.chart.event.TitleChangeListener var34 = null;
//     var31.removeChangeListener(var34);
//     java.awt.geom.Rectangle2D var36 = var31.getBounds();
//     java.awt.geom.Point2D var37 = null;
//     org.jfree.chart.plot.PlotState var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     var18.draw(var26, var36, var37, var38, var39);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.setWeight(100);
//     org.jfree.data.category.CategoryDataset var45 = var41.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var46 = var41.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var47 = var41.getRangeAxisEdge();
//     double var48 = var12.getCategoryStart(15, 10, var36, var47);
//     java.awt.geom.Rectangle2D var49 = var6.createInsetRectangle(var36);
//     
//     // Checks the contract:  equals-hashcode on var2 and var29
//     assertTrue("Contract failed: equals-hashcode on var2 and var29", var2.equals(var29) ? var2.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var2
//     assertTrue("Contract failed: equals-hashcode on var29 and var2", var29.equals(var2) ? var29.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getCategoryMargin();
//     var1.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var8 = var7.getAngleTickUnit();
//     var7.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     var7.setAxis((org.jfree.chart.axis.ValueAxis)var11);
//     var7.setNoDataMessage("hi!");
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var18 = var17.getStandardTickUnits();
//     java.awt.Font var19 = var17.getLabelFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     java.lang.Object var21 = var20.clone();
//     org.jfree.chart.block.BlockFrame var22 = var20.getFrame();
//     org.jfree.chart.event.TitleChangeListener var23 = null;
//     var20.removeChangeListener(var23);
//     java.awt.geom.Rectangle2D var25 = var20.getBounds();
//     java.awt.geom.Point2D var26 = null;
//     org.jfree.chart.plot.PlotState var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     var7.draw(var15, var25, var26, var27, var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.setWeight(100);
//     org.jfree.data.category.CategoryDataset var34 = var30.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var35 = var30.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var36 = var30.getRangeAxisEdge();
//     double var37 = var1.getCategoryStart(15, 10, var25, var36);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.axis.AxisState var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     org.jfree.chart.plot.PiePlotState var41 = new org.jfree.chart.plot.PiePlotState(var40);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     org.jfree.chart.plot.PiePlotState var43 = new org.jfree.chart.plot.PiePlotState(var42);
//     java.awt.geom.Rectangle2D var44 = var43.getExplodedPieArea();
//     double var45 = var43.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var47 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var48 = var47.getStandardTickUnits();
//     java.awt.Font var49 = var47.getLabelFont();
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("", var49);
//     java.lang.Object var51 = var50.clone();
//     org.jfree.chart.block.BlockFrame var52 = var50.getFrame();
//     org.jfree.chart.event.TitleChangeListener var53 = null;
//     var50.removeChangeListener(var53);
//     java.awt.geom.Rectangle2D var55 = var50.getBounds();
//     var43.setLinkArea(var55);
//     var41.setPieArea(var55);
//     org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var60 = var59.getStandardTickUnits();
//     java.awt.Font var61 = var59.getLabelFont();
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle("", var61);
//     java.lang.Object var63 = var62.clone();
//     org.jfree.chart.block.BlockFrame var64 = var62.getFrame();
//     var62.setText("hi!");
//     org.jfree.chart.util.RectangleEdge var67 = var62.getPosition();
//     java.util.List var68 = var1.refreshTicks(var38, var39, var55, var67);
//     
//     // Checks the contract:  equals-hashcode on var18 and var48
//     assertTrue("Contract failed: equals-hashcode on var18 and var48", var18.equals(var48) ? var18.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var60
//     assertTrue("Contract failed: equals-hashcode on var18 and var60", var18.equals(var60) ? var18.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var18
//     assertTrue("Contract failed: equals-hashcode on var48 and var18", var48.equals(var18) ? var48.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var60
//     assertTrue("Contract failed: equals-hashcode on var48 and var60", var48.equals(var60) ? var48.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var18
//     assertTrue("Contract failed: equals-hashcode on var60 and var18", var60.equals(var18) ? var60.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var48
//     assertTrue("Contract failed: equals-hashcode on var60 and var48", var60.equals(var48) ? var60.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.axis.AxisSpace var14 = null;
//     var11.setFixedRangeAxisSpace(var14, true);
//     double var17 = var11.getRangeCrosshairValue();
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     var11.setRenderer(var18);
//     org.jfree.chart.plot.Marker var21 = null;
//     org.jfree.chart.util.Layer var22 = null;
//     var11.addRangeMarker(1, var21, var22);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.plot.PlotOrientation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var23, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    boolean var9 = var8.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var12 = var11.getAlpha();
    org.jfree.chart.util.Layer var13 = null;
    boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
    org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
    var0.setRangeAxisLocation(var15, false);
    org.jfree.chart.annotations.CategoryAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var19 = var0.removeAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var19 = var18.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var22 = var21.getAlpha();
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
//     java.util.List var26 = var18.getAnnotations();
//     var11.drawRangeTickBands(var16, var17, var26);
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     var11.setFixedRangeAxisSpace(var28);
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     var11.handleClick(0, 4, var32);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicAnchor();
//     org.jfree.chart.LegendItemSource[] var16 = var13.getSources();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var18 = var17.getStandardTickUnits();
//     java.awt.Font var19 = var17.getLabelFont();
//     var17.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var22 = new org.jfree.chart.plot.MultiplePiePlot();
//     var22.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var25 = var22.getOutlineStroke();
//     var17.setPlot((org.jfree.chart.plot.Plot)var22);
//     java.awt.Image var27 = var22.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var29 = null;
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var28, var29);
//     org.jfree.chart.util.RectangleInsets var31 = var30.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var32 = var30.getLegendItemGraphicAnchor();
//     var13.setLegendItemGraphicLocation(var32);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var22
//     assertTrue("Contract failed: equals-hashcode on var5 and var22", var5.equals(var22) ? var5.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var5
//     assertTrue("Contract failed: equals-hashcode on var22 and var5", var22.equals(var5) ? var22.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
    var7.setBackgroundAlpha(1.0f);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    var0.setAxisLineStroke(var10);
    boolean var12 = var0.getAutoRangeStickyZero();
    var0.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    var0.setPieIndex(0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var4 = var0.getLabelDistributor();
    boolean var5 = var0.getLabelLinksVisible();
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var8 = var7.getAlpha();
    java.awt.Paint var9 = var7.getPaint();
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
    boolean var11 = var10.getSectionOutlinesVisible();
    double var12 = var10.getMaximumExplodePercent();
    var10.setSectionOutlinesVisible(false);
    var10.setLabelLinkMargin(10.0d);
    var7.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var10);
    int var18 = var10.getPieIndex();
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
    java.awt.Font var22 = var20.getLabelFont();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
    java.lang.Object var24 = var23.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var26 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var27 = var23.equals((java.lang.Object)var26);
    var10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var26);
    java.lang.String var29 = var26.getLabelFormat();
    var0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var26);
    java.awt.Stroke var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseSectionOutlineStroke(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "hi!"+ "'", var29.equals("hi!"));

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Polar Plot", var1, var2);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
    double var8 = var6.extendHeight(10.0d);
    double var9 = var6.getTop();
    java.lang.String var10 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var10.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setFixedDimension((-1.0d));
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
    java.awt.Font var10 = var8.getLabelFont();
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var10);
    java.awt.Paint var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.setWeight(100);
    org.jfree.data.category.CategoryDataset var19 = var15.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxis();
    java.awt.Paint var21 = var15.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", var10, (org.jfree.chart.plot.Plot)var15, false);
    boolean var24 = var23.getAntiAlias();
    org.jfree.chart.event.ChartChangeEventType var25 = null;
    org.jfree.chart.event.ChartChangeEvent var26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var23, var25);
    java.awt.Image var27 = var23.getBackgroundImage();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var28 = var23.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("WMAP_Plot", var1, 0.0d, 0.8f, 0.0f);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin((-1.0d));
//     float var5 = var2.getMaximumCategoryLabelWidthRatio();
//     var2.setMaximumCategoryLabelWidthRatio(1.0f);
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var9 = var8.getLabelURL();
//     java.util.EventListener var10 = null;
//     boolean var11 = var8.hasListener(var10);
//     var8.setLabel("");
//     org.jfree.chart.axis.MarkerAxisBand var14 = null;
//     var8.setMarkerBand(var14);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var8, var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     var19.setFixedDimension((-1.0d));
//     java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var24 = var23.getLabelURL();
//     var23.setNegativeArrowVisible(false);
//     java.awt.Font var27 = var23.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     org.jfree.chart.axis.ValueAxis var31 = var29.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = var29.getRenderer();
//     java.awt.Paint var33 = var29.getDomainZeroBaselinePaint();
//     boolean var34 = var29.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     var36.setFixedDimension((-1.0d));
//     java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var36);
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var41 = var40.getLabelURL();
//     var40.setNegativeArrowVisible(false);
//     java.awt.Font var44 = var40.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var45);
//     org.jfree.chart.axis.ValueAxis var48 = var46.getDomainAxis(100);
//     org.jfree.chart.util.Layer var50 = null;
//     java.util.Collection var51 = var46.getDomainMarkers((-1), var50);
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var55 = var54.getPaint();
//     var53.setOutlinePaint(var55);
//     var46.setRangeGridlinePaint(var55);
//     org.jfree.chart.axis.AxisLocation var58 = var46.getDomainAxisLocation();
//     var29.setRangeAxisLocation(var58, false);
//     var17.setRangeAxisLocation(var58, true);
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var17.handleClick(1, 100, var65);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.VerticalAlignment var6 = var4.getVerticalAlignment();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     java.awt.Font var10 = var8.getLabelFont();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
//     java.lang.Object var12 = var11.clone();
//     org.jfree.chart.util.VerticalAlignment var13 = var11.getVerticalAlignment();
//     java.lang.String var14 = var13.toString();
//     var4.setVerticalAlignment(var13);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.awt.Font var6 = var4.getFont();
//     java.lang.String var7 = var4.getURLText();
//     boolean var8 = var4.getNotify();
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
//     java.awt.Font var13 = var11.getLabelFont();
//     var10.setLabelFont(var13);
//     var4.setFont(var13);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var3 = var2.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     var4.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var8 = var7.getLabelURL();
//     java.util.EventListener var9 = null;
//     boolean var10 = var7.hasListener(var9);
//     var7.setInverted(true);
//     java.awt.Paint var13 = var7.getAxisLinePaint();
//     var4.setTickMarkPaint(var13);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, var15);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
//     java.awt.Font var25 = var23.getLabelFont();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var25);
//     java.lang.Object var27 = var26.clone();
//     org.jfree.chart.block.BlockFrame var28 = var26.getFrame();
//     org.jfree.chart.event.TitleChangeListener var29 = null;
//     var26.removeChangeListener(var29);
//     java.awt.geom.Rectangle2D var31 = var26.getBounds();
//     org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var31, "", "");
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var20.valueToJava2D(1.0E-8d, var31, var35);
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var39 = var38.getCategoryMargin();
//     var38.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var45 = var44.getAngleTickUnit();
//     var44.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var48 = new org.jfree.chart.axis.NumberAxis3D();
//     var44.setAxis((org.jfree.chart.axis.ValueAxis)var48);
//     var44.setNoDataMessage("hi!");
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var55 = var54.getStandardTickUnits();
//     java.awt.Font var56 = var54.getLabelFont();
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle("", var56);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.chart.block.BlockFrame var59 = var57.getFrame();
//     org.jfree.chart.event.TitleChangeListener var60 = null;
//     var57.removeChangeListener(var60);
//     java.awt.geom.Rectangle2D var62 = var57.getBounds();
//     java.awt.geom.Point2D var63 = null;
//     org.jfree.chart.plot.PlotState var64 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var44.draw(var52, var62, var63, var64, var65);
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot();
//     var67.setWeight(100);
//     org.jfree.data.category.CategoryDataset var71 = var67.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var72 = var67.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var73 = var67.getRangeAxisEdge();
//     double var74 = var38.getCategoryStart(15, 10, var62, var73);
//     double var75 = var2.getCategoryEnd(10, 10, var31, var73);
//     
//     // Checks the contract:  equals-hashcode on var24 and var55
//     assertTrue("Contract failed: equals-hashcode on var24 and var55", var24.equals(var55) ? var24.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var24
//     assertTrue("Contract failed: equals-hashcode on var55 and var24", var55.equals(var24) ? var55.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    var15.setAutoRangeMinimumSize(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setFixedDimension((-1.0d));
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.NumberTickUnit var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var4, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.AxisSpace var14 = null;
    var11.setFixedRangeAxisSpace(var14, true);
    java.awt.Stroke var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setDomainGridlineStroke(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    boolean var11 = var10.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var14 = var13.getAlpha();
    org.jfree.chart.util.Layer var15 = null;
    boolean var16 = var10.removeRangeMarker((org.jfree.chart.plot.Marker)var13, var15);
    org.jfree.chart.axis.AxisLocation var17 = var10.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-1), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     var0.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var7 = var6.getLabelURL();
//     java.util.EventListener var8 = null;
//     boolean var9 = var6.hasListener(var8);
//     var6.setInverted(true);
//     java.awt.Paint var12 = var6.getAxisLinePaint();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
//     var6.centerRange(0.0d);
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var18 = var17.getCategoryMargin();
//     var17.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var24 = var23.getAngleTickUnit();
//     var23.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     var23.setAxis((org.jfree.chart.axis.ValueAxis)var27);
//     var23.setNoDataMessage("hi!");
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.block.BlockFrame var38 = var36.getFrame();
//     org.jfree.chart.event.TitleChangeListener var39 = null;
//     var36.removeChangeListener(var39);
//     java.awt.geom.Rectangle2D var41 = var36.getBounds();
//     java.awt.geom.Point2D var42 = null;
//     org.jfree.chart.plot.PlotState var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     var23.draw(var31, var41, var42, var43, var44);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     var46.setWeight(100);
//     org.jfree.data.category.CategoryDataset var50 = var46.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var51 = var46.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var52 = var46.getRangeAxisEdge();
//     double var53 = var17.getCategoryStart(15, 10, var41, var52);
//     var6.setUpArrow((java.awt.Shape)var41);
//     
//     // Checks the contract:  equals-hashcode on var0 and var46
//     assertTrue("Contract failed: equals-hashcode on var0 and var46", var0.equals(var46) ? var0.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var0
//     assertTrue("Contract failed: equals-hashcode on var46 and var0", var46.equals(var0) ? var46.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     boolean var21 = var20.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var20.removeProgressListener(var22);
//     var20.setBackgroundImageAlpha(100.0f);
//     var20.removeLegend();
//     org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var20);
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var32 = var31.getStandardTickUnits();
//     java.awt.Font var33 = var31.getLabelFont();
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("", var33);
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("", var33);
//     var20.addSubtitle(0, (org.jfree.chart.title.Title)var35);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var2 = var1.getAngleTickUnit();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var4.setCategoryMargin((-1.0d));
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setWeight(100);
    org.jfree.data.category.CategoryDataset var11 = var7.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var12 = var7.getDomainAxis();
    java.awt.Paint var13 = var7.getRangeCrosshairPaint();
    var4.setTickLabelPaint(var13);
    var1.setAngleLabelPaint(var13);
    org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var20 = var19.getStandardTickUnits();
    java.awt.Font var21 = var19.getLabelFont();
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var24 = var23.getAlpha();
    java.awt.Paint var25 = var23.getPaint();
    org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine("", var21, var25);
    var17.setAggregatedItemsPaint(var25);
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var31 = var30.getCategoryMargin();
    org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
    var32.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var36 = var35.getLabelURL();
    java.util.EventListener var37 = null;
    boolean var38 = var35.hasListener(var37);
    var35.setInverted(true);
    java.awt.Paint var41 = var35.getAxisLinePaint();
    var32.setTickMarkPaint(var41);
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var28, var30, (org.jfree.chart.axis.ValueAxis)var32, var43);
    java.awt.Stroke var45 = var44.getRangeGridlineStroke();
    java.awt.Paint var46 = null;
    org.jfree.chart.plot.MultiplePiePlot var47 = new org.jfree.chart.plot.MultiplePiePlot();
    var47.setBackgroundAlpha(1.0f);
    java.awt.Stroke var50 = var47.getOutlineStroke();
    org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(102.0d, var25, var45, var46, var50, 0.0f);
    org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var56 = var55.getStandardTickUnits();
    java.awt.Font var57 = var55.getLabelFont();
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var60 = var59.getAlpha();
    java.awt.Paint var61 = var59.getPaint();
    org.jfree.chart.text.TextLine var62 = new org.jfree.chart.text.TextLine("", var57, var61);
    org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var65 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var66 = var65.getPaint();
    var64.setOutlinePaint(var66);
    org.jfree.chart.text.TextLine var68 = new org.jfree.chart.text.TextLine("hi!", var57, var66);
    java.awt.Stroke var69 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(0.08d, var13, var50, var66, var69, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     boolean var16 = var11.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var23 = var22.getLabelURL();
//     var22.setNegativeArrowVisible(false);
//     java.awt.Font var26 = var22.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var37 = var36.getPaint();
//     var35.setOutlinePaint(var37);
//     var28.setRangeGridlinePaint(var37);
//     org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
//     var11.setRangeAxisLocation(var40, false);
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var45 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var46 = var45.getPaint();
//     var44.setOutlinePaint(var46);
//     var11.addRangeMarker((org.jfree.chart.plot.Marker)var44);
//     
//     // Checks the contract:  equals-hashcode on var35 and var44
//     assertTrue("Contract failed: equals-hashcode on var35 and var44", var35.equals(var44) ? var35.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var35
//     assertTrue("Contract failed: equals-hashcode on var44 and var35", var44.equals(var35) ? var44.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var45
//     assertTrue("Contract failed: equals-hashcode on var36 and var45", var36.equals(var45) ? var36.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var36
//     assertTrue("Contract failed: equals-hashcode on var45 and var36", var45.equals(var36) ? var45.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.plot.PlotRenderingInfo var0 = null;
//     org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
//     int var2 = var1.getPassesRequired();
//     double var3 = var1.getPieWRadius();
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     boolean var5 = var4.getSectionOutlinesVisible();
//     var4.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.block.BlockFrame var14 = var12.getFrame();
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var12.removeChangeListener(var15);
//     java.awt.geom.Rectangle2D var17 = var12.getBounds();
//     var4.setLegendItemShape((java.awt.Shape)var17);
//     var1.setLinkArea(var17);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     var21.setFixedDimension((-1.0d));
//     java.lang.Object var24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var21);
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var26 = var25.getLabelURL();
//     var25.setNegativeArrowVisible(false);
//     java.awt.Font var29 = var25.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.axis.ValueAxis var33 = var31.getDomainAxis(100);
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var31.getDomainMarkers((-1), var35);
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var39 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var40 = var39.getPaint();
//     var38.setOutlinePaint(var40);
//     var31.setRangeGridlinePaint(var40);
//     org.jfree.chart.axis.AxisLocation var43 = var31.getDomainAxisLocation();
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var46 = var45.getAngleTickUnit();
//     var45.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D();
//     var45.setAxis((org.jfree.chart.axis.ValueAxis)var49);
//     var45.setNoDataMessage("hi!");
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var56 = var55.getStandardTickUnits();
//     java.awt.Font var57 = var55.getLabelFont();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("", var57);
//     java.lang.Object var59 = var58.clone();
//     org.jfree.chart.block.BlockFrame var60 = var58.getFrame();
//     org.jfree.chart.event.TitleChangeListener var61 = null;
//     var58.removeChangeListener(var61);
//     java.awt.geom.Rectangle2D var63 = var58.getBounds();
//     java.awt.geom.Point2D var64 = null;
//     org.jfree.chart.plot.PlotState var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     var45.draw(var53, var63, var64, var65, var66);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var69 = var68.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var72 = var71.getAlpha();
//     org.jfree.chart.util.Layer var73 = null;
//     boolean var74 = var68.removeRangeMarker((org.jfree.chart.plot.Marker)var71, var73);
//     org.jfree.chart.axis.AxisLocation var75 = var68.getRangeAxisLocation();
//     java.util.List var76 = var68.getAnnotations();
//     var31.drawDomainTickBands(var44, var63, var76);
//     var1.setPieArea(var63);
//     
//     // Checks the contract:  equals-hashcode on var10 and var56
//     assertTrue("Contract failed: equals-hashcode on var10 and var56", var10.equals(var56) ? var10.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var10
//     assertTrue("Contract failed: equals-hashcode on var56 and var10", var56.equals(var10) ? var56.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var1.setUpperBound(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     var4.setLabelFont(var7);
//     var0.setDomainAxis(var4);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.setWeight(100);
//     org.jfree.data.category.CategoryDataset var14 = var10.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var15 = var10.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var16 = var10.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setWeight(100);
//     org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var22 = var17.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var23 = var17.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var27 = var26.getStandardTickUnits();
//     java.awt.Font var28 = var26.getLabelFont();
//     var25.setLabelFont(var28);
//     java.util.List var30 = var17.getCategoriesForAxis(var25);
//     org.jfree.chart.axis.CategoryAxis[] var31 = new org.jfree.chart.axis.CategoryAxis[] { var25};
//     var10.setDomainAxes(var31);
//     var0.setDomainAxes(var31);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var27
//     assertTrue("Contract failed: equals-hashcode on var6 and var27", var6.equals(var27) ? var6.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var6
//     assertTrue("Contract failed: equals-hashcode on var27 and var6", var27.equals(var6) ? var27.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var11.setFixedRangeAxisSpace(var28);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.setWeight(100);
    org.jfree.data.category.CategoryDataset var35 = var31.getDataset(0);
    var31.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var38 = var37.getLabelURL();
    java.util.EventListener var39 = null;
    boolean var40 = var37.hasListener(var39);
    var37.setInverted(true);
    java.awt.Paint var43 = var37.getAxisLinePaint();
    org.jfree.data.Range var44 = var31.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis)var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var3 = var2.getPaint();
//     var1.setOutlinePaint(var3);
//     org.jfree.chart.JFreeChart var5 = null;
//     org.jfree.chart.event.ChartChangeEventType var6 = null;
//     org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var5, var6);
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var10 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var11 = var10.getPaint();
//     var9.setOutlinePaint(var11);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var11);
//     var1.setPaint(var11);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    java.lang.String var3 = var2.getNoDataMessage();
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var2.rendererChanged(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = var11.getRenderer((-1));
    org.jfree.chart.plot.SeriesRenderingOrder var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSeriesRenderingOrder(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var4 = var3.getLabel();
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     boolean var11 = var0.render(var7, var8, 1, var10);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     var0.setRangeAxis(0, var13, true);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var0.zoomDomainAxes(100.0d, var17, var18);
//     var0.zoom(0.0d);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     java.awt.Image var21 = null;
//     var19.setBackgroundImage(var21);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.setWeight(100);
//     org.jfree.data.category.CategoryDataset var27 = var23.getDataset(0);
//     var23.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var32 = var31.getStandardTickUnits();
//     java.awt.Font var33 = var31.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var36 = var35.getAlpha();
//     java.awt.Paint var37 = var35.getPaint();
//     org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("", var33, var37);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var41 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var42 = var41.getPaint();
//     var40.setOutlinePaint(var42);
//     org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine("hi!", var33, var42);
//     var23.setRangeGridlinePaint(var42);
//     boolean var46 = var19.equals((java.lang.Object)var23);
//     
//     // Checks the contract:  equals-hashcode on var5 and var32
//     assertTrue("Contract failed: equals-hashcode on var5 and var32", var5.equals(var32) ? var5.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var5
//     assertTrue("Contract failed: equals-hashcode on var32 and var5", var32.equals(var5) ? var32.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
//     var4.setText("hi!");
//     org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
//     java.awt.Font var16 = var14.getLabelFont();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var16);
//     java.awt.Paint var19 = null;
//     org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setWeight(100);
//     org.jfree.data.category.CategoryDataset var25 = var21.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var26 = var21.getDomainAxis();
//     java.awt.Paint var27 = var21.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("", var16, (org.jfree.chart.plot.Plot)var21, false);
//     boolean var30 = var29.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var31 = null;
//     var29.removeProgressListener(var31);
//     org.jfree.chart.event.ChartProgressEvent var35 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var9, var29, (-16777216), 15);
//     java.lang.Object var36 = var29.clone();
//     var4.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Polar Plot", var1, var2);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
    java.awt.Font var4 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var4);
    var6.setToolTipText("");
    var6.setURLText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(15);
    org.jfree.chart.plot.PieLabelRecord var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("VerticalAlignment.CENTER");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var0.setRenderer(var7);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var0.zoomDomainAxes(0.0d, 0.2d, var11, var12);
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var15 = var14.getAngleTickUnit();
//     var14.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var14.setAxis((org.jfree.chart.axis.ValueAxis)var18);
//     var14.setNoDataMessage("hi!");
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.setWeight(100);
//     org.jfree.data.category.CategoryDataset var26 = var22.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var27 = var22.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var28 = var22.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.setWeight(100);
//     org.jfree.data.category.CategoryDataset var33 = var29.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var34 = var29.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var35 = var29.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var39 = var38.getStandardTickUnits();
//     java.awt.Font var40 = var38.getLabelFont();
//     var37.setLabelFont(var40);
//     java.util.List var42 = var29.getCategoriesForAxis(var37);
//     org.jfree.chart.axis.CategoryAxis[] var43 = new org.jfree.chart.axis.CategoryAxis[] { var37};
//     var22.setDomainAxes(var43);
//     boolean var45 = var14.equals((java.lang.Object)var43);
//     boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var11, (java.lang.Object)var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var29
//     assertTrue("Contract failed: equals-hashcode on var0 and var29", var0.equals(var29) ? var0.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var0
//     assertTrue("Contract failed: equals-hashcode on var29 and var0", var29.equals(var0) ? var29.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var11.getDomainMarkers(10, var21);
    org.jfree.chart.plot.CategoryMarker var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addDomainMarker(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    var0.setNegativeArrowVisible(false);
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDefaultAutoRange(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     double var7 = var6.getBottom();
//     double var9 = var6.extendHeight(100.0d);
//     double var11 = var6.calculateTopOutset(12.0d);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
//     java.awt.Font var15 = var13.getLabelFont();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.block.BlockFrame var18 = var16.getFrame();
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var16.removeChangeListener(var19);
//     java.awt.geom.Rectangle2D var21 = var16.getBounds();
//     org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var21, "", "");
//     var6.trim(var21);
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     org.jfree.chart.plot.PiePlotState var4 = new org.jfree.chart.plot.PiePlotState(var3);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.chart.plot.PiePlotState var6 = new org.jfree.chart.plot.PiePlotState(var5);
//     java.awt.geom.Rectangle2D var7 = var6.getExplodedPieArea();
//     double var8 = var6.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var13.removeChangeListener(var16);
//     java.awt.geom.Rectangle2D var18 = var13.getBounds();
//     var6.setLinkArea(var18);
//     var4.setPieArea(var18);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.setWeight(100);
//     org.jfree.data.category.CategoryDataset var25 = var21.getDataset(0);
//     var21.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var28 = var27.getLabelURL();
//     java.util.EventListener var29 = null;
//     boolean var30 = var27.hasListener(var29);
//     var27.setInverted(true);
//     java.awt.Paint var33 = var27.getAxisLinePaint();
//     org.jfree.data.Range var34 = var21.getDataRange((org.jfree.chart.axis.ValueAxis)var27);
//     org.jfree.chart.util.RectangleEdge var35 = var21.getDomainAxisEdge();
//     double var36 = var1.dateToJava2D(var2, var18, var35);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.lang.String var6 = var4.getText();
//     org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
//     double var9 = var7.extendHeight(100.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.PiePlotState var11 = new org.jfree.chart.plot.PiePlotState(var10);
//     java.awt.geom.Rectangle2D var12 = var11.getExplodedPieArea();
//     double var13 = var11.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
//     java.awt.Font var17 = var15.getLabelFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var17);
//     java.lang.Object var19 = var18.clone();
//     org.jfree.chart.block.BlockFrame var20 = var18.getFrame();
//     org.jfree.chart.event.TitleChangeListener var21 = null;
//     var18.removeChangeListener(var21);
//     java.awt.geom.Rectangle2D var23 = var18.getBounds();
//     var11.setLinkArea(var23);
//     java.awt.geom.Rectangle2D var27 = var7.createInsetRectangle(var23, false, false);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.awt.Font var6 = var4.getFont();
    java.lang.String var7 = var4.getURLText();
    boolean var8 = var4.getNotify();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTextAlignment(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var3.setAxisLineStroke(var13);
    java.awt.Shape var15 = var3.getLeftArrow();
    boolean var16 = var0.equals((java.lang.Object)var15);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.entity.PieSectionEntity var23 = new org.jfree.chart.entity.PieSectionEntity(var15, var17, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
    var23.setPieIndex((-16777216));
    var23.setSectionKey((java.lang.Comparable)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.plot.SeriesRenderingOrder var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSeriesRenderingOrder(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    var0.setBackgroundAlpha(1.0f);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    int var4 = var0.getBackgroundImageAlignment();
    java.lang.Object var5 = null;
    boolean var6 = var0.equals(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     var9.setFixedDimension((-1.0d));
//     java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var14 = var13.getLabelURL();
//     var13.setNegativeArrowVisible(false);
//     java.awt.Font var17 = var13.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     org.jfree.chart.axis.ValueAxis var21 = var19.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = var19.getRenderer();
//     java.awt.Paint var23 = var19.getDomainZeroBaselinePaint();
//     boolean var24 = var19.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     var26.setFixedDimension((-1.0d));
//     java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var31 = var30.getLabelURL();
//     var30.setNegativeArrowVisible(false);
//     java.awt.Font var34 = var30.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.ValueAxis var38 = var36.getDomainAxis(100);
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var36.getDomainMarkers((-1), var40);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var44 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var45 = var44.getPaint();
//     var43.setOutlinePaint(var45);
//     var36.setRangeGridlinePaint(var45);
//     org.jfree.chart.axis.AxisLocation var48 = var36.getDomainAxisLocation();
//     var19.setRangeAxisLocation(var48, false);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.plot.PolarPlot var52 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var53 = var52.getAngleTickUnit();
//     var52.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D();
//     var52.setAxis((org.jfree.chart.axis.ValueAxis)var56);
//     var52.setNoDataMessage("hi!");
//     java.awt.Graphics2D var60 = null;
//     org.jfree.chart.axis.NumberAxis3D var62 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var63 = var62.getStandardTickUnits();
//     java.awt.Font var64 = var62.getLabelFont();
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle("", var64);
//     java.lang.Object var66 = var65.clone();
//     org.jfree.chart.block.BlockFrame var67 = var65.getFrame();
//     org.jfree.chart.event.TitleChangeListener var68 = null;
//     var65.removeChangeListener(var68);
//     java.awt.geom.Rectangle2D var70 = var65.getBounds();
//     java.awt.geom.Point2D var71 = null;
//     org.jfree.chart.plot.PlotState var72 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     var52.draw(var60, var70, var71, var72, var73);
//     java.util.List var75 = null;
//     var19.drawRangeTickBands(var51, var70, var75);
//     java.lang.Object var77 = null;
//     java.lang.Object var78 = var4.draw(var7, var70, var77);
//     
//     // Checks the contract:  equals-hashcode on var2 and var63
//     assertTrue("Contract failed: equals-hashcode on var2 and var63", var2.equals(var63) ? var2.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var2
//     assertTrue("Contract failed: equals-hashcode on var63 and var2", var63.equals(var2) ? var63.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
    org.jfree.chart.event.TitleChangeListener var7 = null;
    var4.removeChangeListener(var7);
    java.awt.geom.Rectangle2D var9 = var4.getBounds();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTextAlignment(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var4 = var3.getLabel();
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     boolean var11 = var0.render(var7, var8, 1, var10);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     var0.setRangeAxis(0, var13, true);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var20 = var19.getLabel();
//     org.jfree.chart.util.Layer var21 = null;
//     var16.addRangeMarker(1, (org.jfree.chart.plot.Marker)var19, var21);
//     boolean var23 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var19);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("XY Plot", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 0, var6);
    var0.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var0.zoomDomainAxes(0.08d, 0.025d, var13, var14);
    org.jfree.chart.plot.PlotOrientation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", var1, 1.0E-5d, 1.0f, 100.0f);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
    double var7 = var6.getBottom();
    double var9 = var6.extendHeight(90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 92.0d);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     java.util.Date var3 = var1.calculateHighestVisibleTickValue(var2);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var29 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var30 = var29.getPaint();
    var28.setOutlinePaint(var30);
    org.jfree.chart.event.MarkerChangeEvent var32 = null;
    var28.notifyListeners(var32);
    org.jfree.chart.util.Layer var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addDomainMarker((-16777216), (org.jfree.chart.plot.Marker)var28, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    java.text.DateFormat var4 = null;
    var1.setDateFormatOverride(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    java.awt.Paint var3 = null;
    var0.setLabelBackgroundPaint(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
//     java.awt.Font var25 = var23.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var28 = var27.getAlpha();
//     java.awt.Paint var29 = var27.getPaint();
//     org.jfree.chart.text.TextLine var30 = new org.jfree.chart.text.TextLine("", var25, var29);
//     var21.setAggregatedItemsPaint(var29);
//     org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", var7, var29);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setWeight(100);
//     org.jfree.data.category.CategoryDataset var11 = var7.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var12 = var7.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var7.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     var15.setLabelFont(var18);
//     java.util.List var20 = var7.getCategoriesForAxis(var15);
//     org.jfree.chart.axis.CategoryAxis[] var21 = new org.jfree.chart.axis.CategoryAxis[] { var15};
//     var0.setDomainAxes(var21);
//     java.lang.String var23 = var0.getPlotType();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.setWeight(100);
//     org.jfree.data.category.CategoryDataset var28 = var24.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var29 = var24.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var30 = var24.getDatasetRenderingOrder();
//     var0.setDatasetRenderingOrder(var30);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    var0.setPositiveArrowVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
    java.awt.Paint var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setWeight(100);
    org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
    java.awt.Paint var18 = var12.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
    boolean var21 = var20.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var22 = null;
    var20.removeProgressListener(var22);
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
    int var27 = var26.getPercent();
    org.jfree.chart.JFreeChart var28 = var26.getChart();
    int var29 = var26.getPercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.chart.axis.ValueAxis var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var0.getRangeAxisIndex(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     var0.clearRangeMarkers();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     var7.setFixedDimension((-1.0d));
//     java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var12 = var11.getLabelURL();
//     var11.setNegativeArrowVisible(false);
//     java.awt.Font var15 = var11.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var16);
//     org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var23 = var22.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     var24.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var28 = var27.getLabelURL();
//     java.util.EventListener var29 = null;
//     boolean var30 = var27.hasListener(var29);
//     var27.setInverted(true);
//     java.awt.Paint var33 = var27.getAxisLinePaint();
//     var24.setTickMarkPaint(var33);
//     var22.setPaint(var33);
//     org.jfree.chart.util.Layer var36 = null;
//     var17.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var22, var36);
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var39 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var22, var38);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     var0.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     java.awt.Font var10 = var8.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var13 = var12.getAlpha();
//     java.awt.Paint var14 = var12.getPaint();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var10, var14);
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var19 = var18.getPaint();
//     var17.setOutlinePaint(var19);
//     org.jfree.chart.text.TextLine var21 = new org.jfree.chart.text.TextLine("hi!", var10, var19);
//     var0.setRangeGridlinePaint(var19);
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var25 = var24.getAlpha();
//     java.awt.Paint var26 = var24.getPaint();
//     var0.setBackgroundPaint(var26);
//     
//     // Checks the contract:  equals-hashcode on var12 and var24
//     assertTrue("Contract failed: equals-hashcode on var12 and var24", var12.equals(var24) ? var12.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var12
//     assertTrue("Contract failed: equals-hashcode on var24 and var12", var24.equals(var12) ? var24.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.removeCategoryLabelToolTip((java.lang.Comparable)' ');
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var13.removeChangeListener(var16);
//     java.awt.geom.Rectangle2D var18 = var13.getBounds();
//     org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var18, "", "");
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var7.valueToJava2D(1.0E-8d, var18, var22);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.setWeight(100);
//     org.jfree.data.category.CategoryDataset var28 = var24.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var29 = var24.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var30 = var24.getRangeAxisEdge();
//     double var31 = var1.getCategoryStart(1, (-16777216), var18, var30);
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
//     var1.setLabelInsets(var38);
//     
//     // Checks the contract:  equals-hashcode on var11 and var34
//     assertTrue("Contract failed: equals-hashcode on var11 and var34", var11.equals(var34) ? var11.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var11
//     assertTrue("Contract failed: equals-hashcode on var34 and var11", var34.equals(var11) ? var34.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test239() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("XY Plot", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(byte)1);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    var1.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot();
    var6.setBackgroundAlpha(1.0f);
    java.awt.Stroke var9 = var6.getOutlineStroke();
    var1.setPlot((org.jfree.chart.plot.Plot)var6);
    java.awt.Image var11 = var6.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var13 = null;
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var12, var13);
    org.jfree.chart.util.RectangleInsets var15 = var14.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleAnchor var16 = var14.getLegendItemGraphicAnchor();
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var19 = var18.getLabelURL();
    java.util.EventListener var20 = null;
    boolean var21 = var18.hasListener(var20);
    var18.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot();
    var25.setBackgroundAlpha(1.0f);
    java.awt.Stroke var28 = var25.getOutlineStroke();
    var18.setAxisLineStroke(var28);
    boolean var30 = var18.getAutoRangeStickyZero();
    var18.setAutoTickUnitSelection(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var14, (java.lang.Object)var18);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    var0.setPositiveArrowVisible(false);
    org.jfree.data.RangeType var4 = var0.getRangeType();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.setWeight(100);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset(0);
    org.jfree.chart.axis.CategoryAnchor var10 = var5.getDomainGridlinePosition();
    org.jfree.chart.axis.ValueAxis var12 = var5.getRangeAxisForDataset(1);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var14, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("XY Plot", var1, var2);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var5 = var4.getAngleTickUnit();
    var4.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    var4.setAxis((org.jfree.chart.axis.ValueAxis)var8);
    var4.setNoDataMessage("hi!");
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setWeight(100);
    org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var18 = var12.getDatasetRenderingOrder();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.setWeight(100);
    org.jfree.data.category.CategoryDataset var23 = var19.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var24 = var19.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var25 = var19.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var29 = var28.getStandardTickUnits();
    java.awt.Font var30 = var28.getLabelFont();
    var27.setLabelFont(var30);
    java.util.List var32 = var19.getCategoriesForAxis(var27);
    org.jfree.chart.axis.CategoryAxis[] var33 = new org.jfree.chart.axis.CategoryAxis[] { var27};
    var12.setDomainAxes(var33);
    boolean var35 = var4.equals((java.lang.Object)var33);
    java.awt.Paint var36 = var4.getAngleLabelPaint();
    org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(102.0d, 0.08d, 1.0d, 0.0d, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     double var7 = var6.getBottom();
//     double var9 = var6.extendHeight(100.0d);
//     double var11 = var6.calculateTopOutset(12.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.plot.PiePlotState var13 = new org.jfree.chart.plot.PiePlotState(var12);
//     int var14 = var13.getPassesRequired();
//     double var15 = var13.getPieWRadius();
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
//     boolean var17 = var16.getSectionOutlinesVisible();
//     var16.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var22 = var21.getStandardTickUnits();
//     java.awt.Font var23 = var21.getLabelFont();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var23);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.block.BlockFrame var26 = var24.getFrame();
//     org.jfree.chart.event.TitleChangeListener var27 = null;
//     var24.removeChangeListener(var27);
//     java.awt.geom.Rectangle2D var29 = var24.getBounds();
//     var16.setLegendItemShape((java.awt.Shape)var29);
//     var13.setLinkArea(var29);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var34 = var33.getAlpha();
//     java.awt.Paint var35 = var33.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var36 = var33.getLabelOffsetType();
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var39 = var38.getAlpha();
//     java.awt.Paint var40 = var38.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var41 = var38.getLabelOffsetType();
//     java.awt.geom.Rectangle2D var42 = var6.createAdjustedRectangle(var29, var36, var41);
//     
//     // Checks the contract:  equals-hashcode on var2 and var22
//     assertTrue("Contract failed: equals-hashcode on var2 and var22", var2.equals(var22) ? var2.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var2
//     assertTrue("Contract failed: equals-hashcode on var22 and var2", var22.equals(var2) ? var22.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var38
//     assertTrue("Contract failed: equals-hashcode on var33 and var38", var33.equals(var38) ? var33.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var33
//     assertTrue("Contract failed: equals-hashcode on var38 and var33", var38.equals(var33) ? var38.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var6 = var5.getAlpha();
//     java.awt.Paint var7 = var5.getPaint();
//     org.jfree.chart.text.TextLine var8 = new org.jfree.chart.text.TextLine("", var3, var7);
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var8.equals(var10);
//     org.jfree.chart.text.TextFragment var12 = var8.getFirstTextFragment();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.text.TextAnchor var14 = null;
//     float var15 = var12.calculateBaselineOffset(var13, var14);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var2 = var1.getCategoryMargin();
    var1.setCategoryLabelPositionOffset(0);
    org.jfree.chart.axis.CategoryLabelPositions var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     java.awt.Stroke var5 = var0.getAxisLineStroke();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
//     java.awt.Font var9 = var7.getLabelFont();
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var9);
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     boolean var14 = var10.equals((java.lang.Object)var13);
//     java.lang.String var15 = var13.getLabelFormat();
//     java.text.NumberFormat var16 = var13.getPercentFormat();
//     var0.setNumberFormatOverride(var16);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickMarkPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkPosition(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.setWeight(100);
//     org.jfree.data.category.CategoryDataset var14 = var10.getDataset(0);
//     var10.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
//     java.awt.Font var20 = var18.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var23 = var22.getAlpha();
//     java.awt.Paint var24 = var22.getPaint();
//     org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("", var20, var24);
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var28 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var29 = var28.getPaint();
//     var27.setOutlinePaint(var29);
//     org.jfree.chart.text.TextLine var31 = new org.jfree.chart.text.TextLine("hi!", var20, var29);
//     var10.setRangeGridlinePaint(var29);
//     var5.setBackgroundPaint(var29);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.title.LegendTitle var26 = var19.getLegend(100);
    java.lang.Object var27 = var19.clone();
    org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var29 = var28.getAngleTickUnit();
    boolean var30 = var28.isDomainZoomable();
    org.jfree.data.xy.XYDataset var31 = null;
    var28.setDataset(var31);
    java.awt.Stroke var33 = var28.getRadiusGridlineStroke();
    var19.setBorderStroke(var33);
    var19.setBackgroundImageAlignment(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var5.setCopyright("PieSection: -16777216, 100(XY Plot)");

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
    var7.setBackgroundAlpha(1.0f);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    var0.setAxisLineStroke(var10);
    boolean var12 = var0.isAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     java.awt.Font var4 = var2.getLabelFont();
//     var1.setLabelFont(var4);
//     var1.setUpperMargin(2.2d);
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = var11.getRendererForDataset(var16);
//     java.awt.Stroke var18 = var11.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var20 = var11.getRangeAxisEdge(100);
//     double var21 = var1.getCategoryEnd(255, 100, var10, var20);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var17 = var16.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     java.util.EventListener var23 = null;
//     boolean var24 = var21.hasListener(var23);
//     var21.setInverted(true);
//     java.awt.Paint var27 = var21.getAxisLinePaint();
//     var18.setTickMarkPaint(var27);
//     var16.setPaint(var27);
//     org.jfree.chart.util.Layer var30 = null;
//     var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
//     double var40 = var38.extendHeight(10.0d);
//     double var41 = var38.getTop();
//     boolean var42 = var11.equals((java.lang.Object)var38);
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var44 = var43.getLabelURL();
//     java.util.EventListener var45 = null;
//     boolean var46 = var43.hasListener(var45);
//     var43.setInverted(true);
//     var43.setTickMarkOutsideLength((-1.0f));
//     org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
//     java.lang.Object var52 = var43.clone();
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D();
//     var54.setFixedDimension((-1.0d));
//     java.lang.Object var57 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var54);
//     org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var59 = var58.getLabelURL();
//     var58.setNegativeArrowVisible(false);
//     java.awt.Font var62 = var58.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var53, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.axis.ValueAxis)var58, var63);
//     org.jfree.data.Range var65 = var58.getDefaultAutoRange();
//     var43.setRangeWithMargins(var65);
//     
//     // Checks the contract:  equals-hashcode on var11 and var64
//     assertTrue("Contract failed: equals-hashcode on var11 and var64", var11.equals(var64) ? var11.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var11
//     assertTrue("Contract failed: equals-hashcode on var64 and var11", var64.equals(var11) ? var64.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setWeight(100);
//     org.jfree.data.category.CategoryDataset var11 = var7.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var12 = var7.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var7.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     var15.setLabelFont(var18);
//     java.util.List var20 = var7.getCategoriesForAxis(var15);
//     org.jfree.chart.axis.CategoryAxis[] var21 = new org.jfree.chart.axis.CategoryAxis[] { var15};
//     var0.setDomainAxes(var21);
//     java.lang.String var23 = var0.getPlotType();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     var24.setFixedDimension((-1.0d));
//     java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var24);
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
//     java.awt.Font var34 = var32.getLabelFont();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("", var34);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var34);
//     java.awt.Paint var37 = null;
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, var37);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.setWeight(100);
//     org.jfree.data.category.CategoryDataset var43 = var39.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var44 = var39.getDomainAxis();
//     java.awt.Paint var45 = var39.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var39, false);
//     boolean var48 = var47.getAntiAlias();
//     org.jfree.chart.event.ChartChangeEventType var49 = null;
//     org.jfree.chart.event.ChartChangeEvent var50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var24, var47, var49);
//     int var51 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var24);
//     
//     // Checks the contract:  equals-hashcode on var7 and var39
//     assertTrue("Contract failed: equals-hashcode on var7 and var39", var7.equals(var39) ? var7.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var7
//     assertTrue("Contract failed: equals-hashcode on var39 and var7", var39.equals(var7) ? var39.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var33
//     assertTrue("Contract failed: equals-hashcode on var17 and var33", var17.equals(var33) ? var17.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var17
//     assertTrue("Contract failed: equals-hashcode on var33 and var17", var33.equals(var17) ? var33.hashCode() == var17.hashCode() : true);
// 
//   }

//  public void test258() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("XY Plot", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setUpperMargin(0.2d);
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.2d);
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.setInverted(true);
    java.awt.Paint var6 = var0.getAxisLinePaint();
    var0.setVerticalTickLabels(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    java.util.EventListener var8 = null;
    boolean var9 = var6.hasListener(var8);
    var6.setInverted(true);
    java.awt.Paint var12 = var6.getAxisLinePaint();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setWeight(100);
    org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var22 = var17.getDomainAxis();
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var24 = var17.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    boolean var26 = var25.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var29 = var28.getAlpha();
    org.jfree.chart.util.Layer var30 = null;
    boolean var31 = var25.removeRangeMarker((org.jfree.chart.plot.Marker)var28, var30);
    org.jfree.chart.axis.AxisLocation var32 = var25.getRangeAxisLocation();
    var17.setRangeAxisLocation(var32, false);
    org.jfree.data.category.CategoryDataset var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var17.getRendererForDataset(var35);
    org.jfree.chart.LegendItemCollection var37 = var17.getLegendItems();
    var0.setFixedLegendItems(var37);
    java.lang.String var39 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "Category Plot"+ "'", var39.equals("Category Plot"));

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var1 = var0.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
//     java.awt.Font var5 = var3.getLabelFont();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var5);
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.block.BlockFrame var8 = var6.getFrame();
//     org.jfree.chart.event.TitleChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     java.awt.geom.Rectangle2D var11 = var6.getBounds();
//     var0.setUpArrow((java.awt.Shape)var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.setWeight(100);
//     org.jfree.data.category.CategoryDataset var17 = var13.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var18 = var13.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var13.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var23 = var22.getStandardTickUnits();
//     java.awt.Font var24 = var22.getLabelFont();
//     var21.setLabelFont(var24);
//     java.util.List var26 = var13.getCategoriesForAxis(var21);
//     var0.setPlot((org.jfree.chart.plot.Plot)var13);
//     
//     // Checks the contract:  equals-hashcode on var4 and var23
//     assertTrue("Contract failed: equals-hashcode on var4 and var23", var4.equals(var23) ? var4.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var4
//     assertTrue("Contract failed: equals-hashcode on var23 and var4", var23.equals(var4) ? var23.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.chart.annotations.XYAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
    org.jfree.chart.event.TitleChangeListener var7 = null;
    var4.removeChangeListener(var7);
    java.awt.geom.Rectangle2D var9 = var4.getBounds();
    org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var9, "", "");
    java.lang.String var13 = var12.getURLText();
    java.lang.String var14 = var12.getURLText();
    java.awt.Shape var15 = var12.getArea();
    java.lang.String var16 = var12.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + ""+ "'", var13.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + ""+ "'", var14.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "0,0,1,1"+ "'", var16.equals("0,0,1,1"));

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var17 = var16.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     java.util.EventListener var23 = null;
//     boolean var24 = var21.hasListener(var23);
//     var21.setInverted(true);
//     java.awt.Paint var27 = var21.getAxisLinePaint();
//     var18.setTickMarkPaint(var27);
//     var16.setPaint(var27);
//     org.jfree.chart.util.Layer var30 = null;
//     var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
//     double var40 = var38.extendHeight(10.0d);
//     double var41 = var38.getTop();
//     boolean var42 = var11.equals((java.lang.Object)var38);
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var44 = var43.getLabelURL();
//     java.util.EventListener var45 = null;
//     boolean var46 = var43.hasListener(var45);
//     var43.setInverted(true);
//     var43.setTickMarkOutsideLength((-1.0f));
//     org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
//     org.jfree.data.xy.XYDataset var52 = null;
//     int var53 = var11.indexOf(var52);
//     org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var56 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var57 = var56.getPaint();
//     var55.setOutlinePaint(var57);
//     double var59 = var55.getValue();
//     org.jfree.chart.util.Layer var60 = null;
//     boolean var61 = var11.removeRangeMarker((org.jfree.chart.plot.Marker)var55, var60);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = null;
    var0.setLogo(var1);
    var0.setLicenceText("0,0,1,1");

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var1 = null;
    var0.setLegendLabelURLGenerator(var1);
    java.lang.Object var3 = var0.clone();
    java.awt.Paint var5 = var0.getSectionOutlinePaint((java.lang.Comparable)0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var2 = var1.getCategoryMargin();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.setWeight(100);
//     org.jfree.data.category.CategoryDataset var7 = var3.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var8 = var3.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var9 = var3.getDatasetRenderingOrder();
//     boolean var10 = var3.isRangeCrosshairVisible();
//     boolean var11 = var3.isRangeCrosshairLockedOnData();
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var3);
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
//     boolean var16 = var15.getSectionOutlinesVisible();
//     double var17 = var15.getMaximumExplodePercent();
//     var15.setSectionOutlinesVisible(false);
//     double var20 = var15.getLabelLinkMargin();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     var22.setFixedDimension((-1.0d));
//     java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var22);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var27 = var26.getLabelURL();
//     var26.setNegativeArrowVisible(false);
//     java.awt.Font var30 = var26.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var26, var31);
//     org.jfree.chart.axis.ValueAxis var34 = var32.getDomainAxis(100);
//     var32.clearRangeMarkers(15);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     org.jfree.chart.plot.PiePlotState var39 = new org.jfree.chart.plot.PiePlotState(var38);
//     int var40 = var39.getPassesRequired();
//     double var41 = var39.getPieWRadius();
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot();
//     boolean var43 = var42.getSectionOutlinesVisible();
//     var42.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var47 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var48 = var47.getStandardTickUnits();
//     java.awt.Font var49 = var47.getLabelFont();
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("", var49);
//     java.lang.Object var51 = var50.clone();
//     org.jfree.chart.block.BlockFrame var52 = var50.getFrame();
//     org.jfree.chart.event.TitleChangeListener var53 = null;
//     var50.removeChangeListener(var53);
//     java.awt.geom.Rectangle2D var55 = var50.getBounds();
//     var42.setLegendItemShape((java.awt.Shape)var55);
//     var39.setLinkArea(var55);
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     org.jfree.chart.plot.CrosshairState var60 = null;
//     boolean var61 = var32.render(var37, var55, 0, var59, var60);
//     var15.setLegendItemShape((java.awt.Shape)var55);
//     org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var67 = var66.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var69 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var70 = var69.getStandardTickUnits();
//     java.awt.Font var71 = var69.getLabelFont();
//     org.jfree.chart.title.TextTitle var72 = new org.jfree.chart.title.TextTitle("", var71);
//     java.lang.Object var73 = var72.clone();
//     org.jfree.chart.block.BlockFrame var74 = var72.getFrame();
//     org.jfree.chart.event.TitleChangeListener var75 = null;
//     var72.removeChangeListener(var75);
//     java.awt.geom.Rectangle2D var77 = var72.getBounds();
//     var66.setUpArrow((java.awt.Shape)var77);
//     org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot();
//     var79.setWeight(100);
//     org.jfree.data.category.CategoryDataset var83 = var79.getDataset(0);
//     org.jfree.data.category.CategoryDataset var84 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var85 = var79.getRendererForDataset(var84);
//     java.awt.Stroke var86 = var79.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var88 = var79.getRangeAxisEdge(100);
//     double var89 = var64.java2DToValue(0.2d, var77, var88);
//     double var90 = var1.getCategoryStart((-1), (-16777216), var55, var88);
//     
//     // Checks the contract:  equals-hashcode on var3 and var79
//     assertTrue("Contract failed: equals-hashcode on var3 and var79", var3.equals(var79) ? var3.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var3
//     assertTrue("Contract failed: equals-hashcode on var79 and var3", var79.equals(var3) ? var79.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var70
//     assertTrue("Contract failed: equals-hashcode on var48 and var70", var48.equals(var70) ? var48.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var48
//     assertTrue("Contract failed: equals-hashcode on var70 and var48", var70.equals(var48) ? var70.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var4 = var3.getAlpha();
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var3, var5);
//     org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     var8.setPositiveArrowVisible(false);
//     org.jfree.data.RangeType var12 = var8.getRangeType();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var8);
//     boolean var14 = var8.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var18 = var17.getStandardTickUnits();
//     java.awt.Font var19 = var17.getLabelFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     java.lang.Object var21 = var20.clone();
//     org.jfree.chart.block.BlockFrame var22 = var20.getFrame();
//     org.jfree.chart.event.TitleChangeListener var23 = null;
//     var20.removeChangeListener(var23);
//     java.awt.geom.Rectangle2D var25 = var20.getBounds();
//     org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var25, "", "");
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.setWeight(100);
//     org.jfree.data.category.CategoryDataset var33 = var29.getDataset(0);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var29.getRendererForDataset(var34);
//     java.awt.Stroke var36 = var29.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var38 = var29.getRangeAxisEdge(100);
//     double var39 = var8.lengthToJava2D(1.0E-5d, var25, var38);
//     
//     // Checks the contract:  equals-hashcode on var9 and var18
//     assertTrue("Contract failed: equals-hashcode on var9 and var18", var9.equals(var18) ? var9.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var9
//     assertTrue("Contract failed: equals-hashcode on var18 and var9", var18.equals(var9) ? var18.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"Polar Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "WMAP_Plot");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 1);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = null;
    var0.setLogo(var1);
    org.jfree.chart.ui.BasicProjectInfo var8 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var8.setInfo("");
    org.jfree.chart.ui.Library[] var11 = var8.getOptionalLibraries();
    java.lang.String var12 = var8.getName();
    var8.setLicenceName("hi!");
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var8);
    org.jfree.chart.ui.Library[] var16 = var8.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    boolean var2 = var1.getDarkerSides();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setInteriorGap((-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     java.awt.Image var21 = null;
//     var19.setBackgroundImage(var21);
//     java.awt.Paint var23 = var19.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
//     java.awt.Font var26 = var24.getLabelFont();
//     var24.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var29 = new org.jfree.chart.plot.MultiplePiePlot();
//     var29.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var32 = var29.getOutlineStroke();
//     var24.setPlot((org.jfree.chart.plot.Plot)var29);
//     java.awt.Image var34 = var29.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var36 = null;
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29, (org.jfree.chart.block.Arrangement)var35, var36);
//     org.jfree.chart.util.RectangleInsets var38 = var37.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var39 = var37.getLegendItemGraphicAnchor();
//     org.jfree.chart.block.BlockContainer var40 = var37.getItemContainer();
//     var19.addLegend(var37);
//     
//     // Checks the contract:  equals-hashcode on var5 and var25
//     assertTrue("Contract failed: equals-hashcode on var5 and var25", var5.equals(var25) ? var5.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var5
//     assertTrue("Contract failed: equals-hashcode on var25 and var5", var25.equals(var5) ? var25.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    boolean var2 = var0.containsKey((java.lang.Comparable)(short)(-1));
    java.lang.Object var3 = null;
    boolean var4 = var0.equals(var3);
    boolean var6 = var0.containsKey((java.lang.Comparable)' ');
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, (-1.0f), 100.0f, var4);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     double var8 = var6.extendHeight(10.0d);
//     double var9 = var6.getTop();
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     var11.setFixedDimension((-1.0d));
//     java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var16 = var15.getLabelURL();
//     var15.setNegativeArrowVisible(false);
//     java.awt.Font var19 = var15.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var10, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.axis.ValueAxis)var15, var20);
//     org.jfree.chart.axis.ValueAxis var23 = var21.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = var21.getRenderer();
//     java.awt.Paint var25 = var21.getDomainZeroBaselinePaint();
//     boolean var26 = var21.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     var28.setFixedDimension((-1.0d));
//     java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var28);
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var33 = var32.getLabelURL();
//     var32.setNegativeArrowVisible(false);
//     java.awt.Font var36 = var32.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var32, var37);
//     org.jfree.chart.axis.ValueAxis var40 = var38.getDomainAxis(100);
//     org.jfree.chart.util.Layer var42 = null;
//     java.util.Collection var43 = var38.getDomainMarkers((-1), var42);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var46 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var47 = var46.getPaint();
//     var45.setOutlinePaint(var47);
//     var38.setRangeGridlinePaint(var47);
//     org.jfree.chart.axis.AxisLocation var50 = var38.getDomainAxisLocation();
//     var21.setRangeAxisLocation(var50, false);
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var55 = var54.getAngleTickUnit();
//     var54.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D();
//     var54.setAxis((org.jfree.chart.axis.ValueAxis)var58);
//     var54.setNoDataMessage("hi!");
//     java.awt.Graphics2D var62 = null;
//     org.jfree.chart.axis.NumberAxis3D var64 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var65 = var64.getStandardTickUnits();
//     java.awt.Font var66 = var64.getLabelFont();
//     org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle("", var66);
//     java.lang.Object var68 = var67.clone();
//     org.jfree.chart.block.BlockFrame var69 = var67.getFrame();
//     org.jfree.chart.event.TitleChangeListener var70 = null;
//     var67.removeChangeListener(var70);
//     java.awt.geom.Rectangle2D var72 = var67.getBounds();
//     java.awt.geom.Point2D var73 = null;
//     org.jfree.chart.plot.PlotState var74 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     var54.draw(var62, var72, var73, var74, var75);
//     java.util.List var77 = null;
//     var21.drawRangeTickBands(var53, var72, var77);
//     var6.trim(var72);
//     
//     // Checks the contract:  equals-hashcode on var2 and var65
//     assertTrue("Contract failed: equals-hashcode on var2 and var65", var2.equals(var65) ? var2.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var2
//     assertTrue("Contract failed: equals-hashcode on var65 and var2", var65.equals(var2) ? var65.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    var0.setNoDataMessage("hi!");
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
    java.awt.Font var12 = var10.getLabelFont();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
    org.jfree.chart.event.TitleChangeListener var16 = null;
    var13.removeChangeListener(var16);
    java.awt.geom.Rectangle2D var18 = var13.getBounds();
    java.awt.geom.Point2D var19 = null;
    org.jfree.chart.plot.PlotState var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    var0.draw(var8, var18, var19, var20, var21);
    int var23 = var0.getBackgroundImageAlignment();
    boolean var24 = var0.isAngleLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 0.20000000000000018d, 0.08d);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.block.RectangleConstraint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var9 = var4.arrange(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setUpperMargin(0.2d);
    org.jfree.chart.block.LineBorder var4 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
    java.awt.Font var11 = var9.getLabelFont();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var11);
    java.awt.Paint var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setWeight(100);
    org.jfree.data.category.CategoryDataset var20 = var16.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var21 = var16.getDomainAxis();
    java.awt.Paint var22 = var16.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("", var11, (org.jfree.chart.plot.Plot)var16, false);
    boolean var25 = var24.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var26 = null;
    var24.removeProgressListener(var26);
    org.jfree.chart.event.ChartProgressEvent var30 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var24, (-16777216), 15);
    org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var24);
    org.jfree.chart.plot.Plot var32 = var1.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     var0.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
//     var0.setNoDataMessage("hi!");
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var13.removeChangeListener(var16);
//     java.awt.geom.Rectangle2D var18 = var13.getBounds();
//     java.awt.geom.Point2D var19 = null;
//     org.jfree.chart.plot.PlotState var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var0.draw(var8, var18, var19, var20, var21);
//     java.awt.Paint var23 = null;
//     var0.setRadiusGridlinePaint(var23);
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var29 = var28.getStandardTickUnits();
//     java.awt.Font var30 = var28.getLabelFont();
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var30);
//     java.lang.Object var32 = var31.clone();
//     org.jfree.chart.block.BlockFrame var33 = var31.getFrame();
//     org.jfree.chart.event.TitleChangeListener var34 = null;
//     var31.removeChangeListener(var34);
//     java.awt.geom.Rectangle2D var36 = var31.getBounds();
//     java.awt.Point var37 = var0.translateValueThetaRadiusToJava2D(0.05d, 0.025d, var36);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.event.ChartChangeListener var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addChangeListener(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     var5.setBackgroundImageAlpha(1.0f);
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var18);
//     java.awt.Paint var21 = null;
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, var21);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.setWeight(100);
//     org.jfree.data.category.CategoryDataset var27 = var23.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var28 = var23.getDomainAxis();
//     java.awt.Paint var29 = var23.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("", var18, (org.jfree.chart.plot.Plot)var23, false);
//     boolean var32 = var31.isNotify();
//     org.jfree.chart.event.ChartProgressEvent var35 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var31, 1, 10);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     boolean var21 = var20.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var20.removeProgressListener(var22);
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
//     java.lang.Object var27 = var20.clone();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var30 = var29.getAngleTickUnit();
//     var29.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     var29.setAxis((org.jfree.chart.axis.ValueAxis)var33);
//     var29.setNoDataMessage("hi!");
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var40 = var39.getStandardTickUnits();
//     java.awt.Font var41 = var39.getLabelFont();
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("", var41);
//     java.lang.Object var43 = var42.clone();
//     org.jfree.chart.block.BlockFrame var44 = var42.getFrame();
//     org.jfree.chart.event.TitleChangeListener var45 = null;
//     var42.removeChangeListener(var45);
//     java.awt.geom.Rectangle2D var47 = var42.getBounds();
//     java.awt.geom.Point2D var48 = null;
//     org.jfree.chart.plot.PlotState var49 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     var29.draw(var37, var47, var48, var49, var50);
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     var20.draw(var28, var47, var52);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var4 = var3.getLabel();
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var11 = var10.getLabel();
//     org.jfree.chart.util.Layer var12 = null;
//     var7.addRangeMarker(1, (org.jfree.chart.plot.Marker)var10, var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     boolean var18 = var7.render(var14, var15, 1, var17);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     var7.setRangeAxis(0, var20, true);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var25.setCategoryMargin((-1.0d));
//     float var28 = var25.getMaximumCategoryLabelWidthRatio();
//     var25.setMaximumCategoryLabelWidthRatio(1.0f);
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var32 = var31.getLabelURL();
//     java.util.EventListener var33 = null;
//     boolean var34 = var31.hasListener(var33);
//     var31.setLabel("");
//     org.jfree.chart.axis.MarkerAxisBand var37 = null;
//     var31.setMarkerBand(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var23, var25, (org.jfree.chart.axis.ValueAxis)var31, var39);
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D();
//     var42.setFixedDimension((-1.0d));
//     java.lang.Object var45 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var42);
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var47 = var46.getLabelURL();
//     var46.setNegativeArrowVisible(false);
//     java.awt.Font var50 = var46.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var41, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.axis.ValueAxis)var46, var51);
//     org.jfree.chart.axis.ValueAxis var54 = var52.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = var52.getRenderer();
//     java.awt.Paint var56 = var52.getDomainZeroBaselinePaint();
//     boolean var57 = var52.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D();
//     var59.setFixedDimension((-1.0d));
//     java.lang.Object var62 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var59);
//     org.jfree.chart.axis.NumberAxis3D var63 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var64 = var63.getLabelURL();
//     var63.setNegativeArrowVisible(false);
//     java.awt.Font var67 = var63.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var59, (org.jfree.chart.axis.ValueAxis)var63, var68);
//     org.jfree.chart.axis.ValueAxis var71 = var69.getDomainAxis(100);
//     org.jfree.chart.util.Layer var73 = null;
//     java.util.Collection var74 = var69.getDomainMarkers((-1), var73);
//     org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var77 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var78 = var77.getPaint();
//     var76.setOutlinePaint(var78);
//     var69.setRangeGridlinePaint(var78);
//     org.jfree.chart.axis.AxisLocation var81 = var69.getDomainAxisLocation();
//     var52.setRangeAxisLocation(var81, false);
//     var40.setRangeAxisLocation(var81, true);
//     var7.setDomainAxisLocation(var81);
//     var0.setDomainAxisLocation(var81, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var10
//     assertTrue("Contract failed: equals-hashcode on var3 and var10", var3.equals(var10) ? var3.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var3
//     assertTrue("Contract failed: equals-hashcode on var10 and var3", var10.equals(var3) ? var10.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
    java.awt.Paint var28 = var11.getRangeGridlinePaint();
    java.awt.Stroke var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeZeroBaselineStroke(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", (-16777216));
    int var3 = var2.getAlpha();
    float[] var5 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var2.getComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var4 = var3.getAlpha();
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var3, var5);
//     org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     var8.setPositiveArrowVisible(false);
//     org.jfree.data.RangeType var12 = var8.getRangeType();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     var15.setFixedDimension((-1.0d));
//     java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var15);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var20 = var19.getLabelURL();
//     var19.setNegativeArrowVisible(false);
//     java.awt.Font var23 = var19.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var31 = var30.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     var32.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var36 = var35.getLabelURL();
//     java.util.EventListener var37 = null;
//     boolean var38 = var35.hasListener(var37);
//     var35.setInverted(true);
//     java.awt.Paint var41 = var35.getAxisLinePaint();
//     var32.setTickMarkPaint(var41);
//     var30.setPaint(var41);
//     org.jfree.chart.util.Layer var44 = null;
//     var25.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var30, var44);
//     org.jfree.chart.util.Layer var46 = null;
//     boolean var47 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var30, var46);
//     
//     // Checks the contract:  equals-hashcode on var3 and var30
//     assertTrue("Contract failed: equals-hashcode on var3 and var30", var3.equals(var30) ? var3.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var3
//     assertTrue("Contract failed: equals-hashcode on var30 and var3", var30.equals(var3) ? var30.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var3 = var2.getLabelURL();
//     java.util.EventListener var4 = null;
//     boolean var5 = var2.hasListener(var4);
//     var2.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
//     var9.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var12 = var9.getOutlineStroke();
//     var2.setAxisLineStroke(var12);
//     java.awt.Shape var14 = var2.getLeftArrow();
//     var1.setRightArrow(var14);
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var17 = var16.getLabelURL();
//     java.util.EventListener var18 = null;
//     boolean var19 = var16.hasListener(var18);
//     var16.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var23 = new org.jfree.chart.plot.MultiplePiePlot();
//     var23.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var26 = var23.getOutlineStroke();
//     var16.setAxisLineStroke(var26);
//     java.awt.Shape var28 = var16.getLeftArrow();
//     var1.setDownArrow(var28);
//     
//     // Checks the contract:  equals-hashcode on var9 and var23
//     assertTrue("Contract failed: equals-hashcode on var9 and var23", var9.equals(var23) ? var9.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var9
//     assertTrue("Contract failed: equals-hashcode on var23 and var9", var23.equals(var9) ? var23.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     var0.zoomDomainAxes(102.0d, var6, var7, false);
//     var0.clearRangeMarkers(1);
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var14.setLabel("");
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var0.removeRangeMarker((-16777216), (org.jfree.chart.plot.Marker)var14, var17);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var3.setCategoryMargin((-1.0d));
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setWeight(100);
//     org.jfree.data.category.CategoryDataset var10 = var6.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var11 = var6.getDomainAxis();
//     java.awt.Paint var12 = var6.getRangeCrosshairPaint();
//     var3.setTickLabelPaint(var12);
//     var0.setAngleLabelPaint(var12);
//     var0.zoom(1.0E-5d);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = var0.getRenderer(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     boolean var16 = var11.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var23 = var22.getLabelURL();
//     var22.setNegativeArrowVisible(false);
//     java.awt.Font var26 = var22.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var37 = var36.getPaint();
//     var35.setOutlinePaint(var37);
//     var28.setRangeGridlinePaint(var37);
//     org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
//     var11.setRangeAxisLocation(var40, false);
//     org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var45 = var44.getLabelURL();
//     java.util.EventListener var46 = null;
//     boolean var47 = var44.hasListener(var46);
//     var44.setLabel("");
//     boolean var50 = var44.isVerticalTickLabels();
//     org.jfree.chart.axis.MarkerAxisBand var51 = null;
//     var44.setMarkerBand(var51);
//     var11.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var44);
//     org.jfree.chart.util.RectangleInsets var54 = var11.getAxisOffset();
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var57 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var58 = var57.getPaint();
//     var56.setOutlinePaint(var58);
//     org.jfree.chart.block.BlockBorder var60 = new org.jfree.chart.block.BlockBorder(var58);
//     var11.setRangeZeroBaselinePaint(var58);
//     
//     // Checks the contract:  equals-hashcode on var35 and var56
//     assertTrue("Contract failed: equals-hashcode on var35 and var56", var35.equals(var56) ? var35.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var35
//     assertTrue("Contract failed: equals-hashcode on var56 and var35", var56.equals(var35) ? var56.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var57
//     assertTrue("Contract failed: equals-hashcode on var36 and var57", var36.equals(var57) ? var36.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var36
//     assertTrue("Contract failed: equals-hashcode on var57 and var36", var57.equals(var36) ? var57.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("WMAP_Plot", "");

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     boolean var5 = var0.isAxisLineVisible();
//     java.awt.Paint var6 = var0.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.setWeight(100);
//     org.jfree.data.category.CategoryDataset var11 = var7.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var12 = var7.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var13 = var7.getDatasetRenderingOrder();
//     boolean var14 = var7.isRangeCrosshairVisible();
//     boolean var15 = var7.isRangeCrosshairLockedOnData();
//     var0.setPlot((org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.LegendItemCollection var17 = var7.getLegendItems();
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.LegendItemCollection var19 = var18.getLegendItems();
//     int var20 = var19.getItemCount();
//     var17.addAll(var19);
//     
//     // Checks the contract:  equals-hashcode on var17 and var19
//     assertTrue("Contract failed: equals-hashcode on var17 and var19", var17.equals(var19) ? var17.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var17
//     assertTrue("Contract failed: equals-hashcode on var19 and var17", var19.equals(var17) ? var19.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    float[] var5 = new float[] { (-1.0f), 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(1, 1, (-16777216), var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    java.text.NumberFormat var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
    java.awt.Font var5 = var3.getLabelFont();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var5);
    java.lang.Object var7 = var6.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var10 = var6.equals((java.lang.Object)var9);
    java.lang.Object var11 = var9.clone();
    java.text.NumberFormat var12 = var9.getNumberFormat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("0,0,1,1", var1, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var2.setCategoryMargin((-1.0d));
//     float var5 = var2.getMaximumCategoryLabelWidthRatio();
//     var2.setMaximumCategoryLabelWidthRatio(1.0f);
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var9 = var8.getLabelURL();
//     java.util.EventListener var10 = null;
//     boolean var11 = var8.hasListener(var10);
//     var8.setLabel("");
//     org.jfree.chart.axis.MarkerAxisBand var14 = null;
//     var8.setMarkerBand(var14);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var8, var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     var19.setFixedDimension((-1.0d));
//     java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var24 = var23.getLabelURL();
//     var23.setNegativeArrowVisible(false);
//     java.awt.Font var27 = var23.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     org.jfree.chart.axis.ValueAxis var31 = var29.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = var29.getRenderer();
//     java.awt.Paint var33 = var29.getDomainZeroBaselinePaint();
//     boolean var34 = var29.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     var36.setFixedDimension((-1.0d));
//     java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var36);
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var41 = var40.getLabelURL();
//     var40.setNegativeArrowVisible(false);
//     java.awt.Font var44 = var40.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var45);
//     org.jfree.chart.axis.ValueAxis var48 = var46.getDomainAxis(100);
//     org.jfree.chart.util.Layer var50 = null;
//     java.util.Collection var51 = var46.getDomainMarkers((-1), var50);
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var55 = var54.getPaint();
//     var53.setOutlinePaint(var55);
//     var46.setRangeGridlinePaint(var55);
//     org.jfree.chart.axis.AxisLocation var58 = var46.getDomainAxisLocation();
//     var29.setRangeAxisLocation(var58, false);
//     var17.setRangeAxisLocation(var58, true);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.NumberAxis3D var64 = new org.jfree.chart.axis.NumberAxis3D();
//     var64.setFixedDimension((-1.0d));
//     java.lang.Object var67 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var64);
//     org.jfree.chart.axis.NumberAxis3D var68 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var69 = var68.getLabelURL();
//     var68.setNegativeArrowVisible(false);
//     java.awt.Font var72 = var68.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot(var63, (org.jfree.chart.axis.ValueAxis)var64, (org.jfree.chart.axis.ValueAxis)var68, var73);
//     org.jfree.chart.axis.ValueAxis var76 = var74.getDomainAxis(100);
//     org.jfree.chart.axis.ValueAxis var78 = var74.getRangeAxis(0);
//     int var79 = var74.getWeight();
//     org.jfree.chart.plot.PlotOrientation var80 = var74.getOrientation();
//     org.jfree.chart.util.RectangleEdge var81 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var58, var80);
//     
//     // Checks the contract:  equals-hashcode on var29 and var74
//     assertTrue("Contract failed: equals-hashcode on var29 and var74", var29.equals(var74) ? var29.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var29
//     assertTrue("Contract failed: equals-hashcode on var74 and var29", var74.equals(var29) ? var74.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var2 = var1.getLabelURL();
    java.util.EventListener var3 = null;
    boolean var4 = var1.hasListener(var3);
    var1.setLabel("");
    boolean var7 = var1.isVerticalTickLabels();
    var1.setAutoRange(true);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
    java.awt.Font var13 = var11.getLabelFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var13);
    var1.setTickLabelFont(var13);
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("Polar Plot", var13, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.lang.String var6 = var4.getText();
    org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
    double var8 = var4.getContentYOffset();
    double var9 = var4.getContentYOffset();
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var4.removeChangeListener(var10);
    boolean var12 = var4.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
    java.awt.Paint var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setWeight(100);
    org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
    java.awt.Paint var18 = var12.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
    boolean var21 = var20.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var22 = null;
    var20.removeProgressListener(var22);
    var20.setBackgroundImageAlpha(100.0f);
    var20.removeLegend();
    org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var20);
    org.jfree.chart.plot.Plot var28 = var20.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var30 = var20.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     var8.setLabelFont(var11);
//     java.util.List var13 = var0.getCategoriesForAxis(var8);
//     var8.setCategoryMargin((-1.0d));
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.Plot var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var19 = var18.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var22 = var21.getStandardTickUnits();
//     java.awt.Font var23 = var21.getLabelFont();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var23);
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.block.BlockFrame var26 = var24.getFrame();
//     org.jfree.chart.event.TitleChangeListener var27 = null;
//     var24.removeChangeListener(var27);
//     java.awt.geom.Rectangle2D var29 = var24.getBounds();
//     var18.setUpArrow((java.awt.Shape)var29);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.setWeight(100);
//     org.jfree.data.category.CategoryDataset var35 = var31.getDataset(0);
//     var31.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var38 = var37.getLabelURL();
//     java.util.EventListener var39 = null;
//     boolean var40 = var37.hasListener(var39);
//     var37.setInverted(true);
//     java.awt.Paint var43 = var37.getAxisLinePaint();
//     org.jfree.data.Range var44 = var31.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
//     org.jfree.chart.util.RectangleEdge var45 = var31.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var46 = null;
//     org.jfree.chart.axis.AxisSpace var47 = var8.reserveSpace(var16, var17, var29, var45, var46);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.title.LegendTitle var26 = var19.getLegend(100);
    org.jfree.chart.ChartRenderingInfo var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var32 = var19.createBufferedImage(0, (-16777216), 9.223372036854776E18d, 1.0d, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
    java.lang.String var2 = var1.getText();
    float var3 = var1.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "hi!"+ "'", var2.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var4 = var3.getLabel();
    org.jfree.chart.util.Layer var5 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    boolean var11 = var0.render(var7, var8, 1, var10);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var0.setRangeAxis(0, var13, true);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var18.setCategoryMargin((-1.0d));
    float var21 = var18.getMaximumCategoryLabelWidthRatio();
    var18.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var25 = var24.getLabelURL();
    java.util.EventListener var26 = null;
    boolean var27 = var24.hasListener(var26);
    var24.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var30 = null;
    var24.setMarkerBand(var30);
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var16, var18, (org.jfree.chart.axis.ValueAxis)var24, var32);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
    var35.setFixedDimension((-1.0d));
    java.lang.Object var38 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var35);
    org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var40 = var39.getLabelURL();
    var39.setNegativeArrowVisible(false);
    java.awt.Font var43 = var39.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var44);
    org.jfree.chart.axis.ValueAxis var47 = var45.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = var45.getRenderer();
    java.awt.Paint var49 = var45.getDomainZeroBaselinePaint();
    boolean var50 = var45.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var51 = null;
    org.jfree.chart.axis.NumberAxis3D var52 = new org.jfree.chart.axis.NumberAxis3D();
    var52.setFixedDimension((-1.0d));
    java.lang.Object var55 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var52);
    org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var57 = var56.getLabelURL();
    var56.setNegativeArrowVisible(false);
    java.awt.Font var60 = var56.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
    org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var51, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.axis.ValueAxis)var56, var61);
    org.jfree.chart.axis.ValueAxis var64 = var62.getDomainAxis(100);
    org.jfree.chart.util.Layer var66 = null;
    java.util.Collection var67 = var62.getDomainMarkers((-1), var66);
    org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var70 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var71 = var70.getPaint();
    var69.setOutlinePaint(var71);
    var62.setRangeGridlinePaint(var71);
    org.jfree.chart.axis.AxisLocation var74 = var62.getDomainAxisLocation();
    var45.setRangeAxisLocation(var74, false);
    var33.setRangeAxisLocation(var74, true);
    var0.setDomainAxisLocation(var74);
    org.jfree.chart.axis.ValueAxis var81 = var0.getRangeAxisForDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    var0.clearCornerTextItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    boolean var2 = var0.isDomainZoomable();
    org.jfree.data.xy.XYDataset var3 = null;
    var0.setDataset(var3);
    java.awt.Stroke var5 = var0.getRadiusGridlineStroke();
    boolean var6 = var0.isRangeZoomable();
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
    java.awt.Font var9 = var7.getLabelFont();
    var7.setLabel("");
    java.lang.String var12 = var7.getLabel();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var7);
    var0.removeCornerTextItem("XY Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var17 = var11.getQuadrantPaint((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var3 = var2.getPaint();
//     var1.setOutlinePaint(var3);
//     org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var3);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.setWeight(100);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
//     java.awt.Font var13 = var11.getLabelFont();
//     var10.setLabelFont(var13);
//     var6.setDomainAxis(var10);
//     boolean var16 = var5.equals((java.lang.Object)var10);
//     var10.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var20 = var19.getLabelURL();
//     java.util.EventListener var21 = null;
//     boolean var22 = var19.hasListener(var21);
//     var19.setLabel("");
//     boolean var25 = var19.isVerticalTickLabels();
//     var19.setAutoRange(true);
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var30 = var29.getStandardTickUnits();
//     java.awt.Font var31 = var29.getLabelFont();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("", var31);
//     var19.setTickLabelFont(var31);
//     var10.setTickLabelFont(var31);
//     
//     // Checks the contract:  equals-hashcode on var12 and var30
//     assertTrue("Contract failed: equals-hashcode on var12 and var30", var12.equals(var30) ? var12.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var12
//     assertTrue("Contract failed: equals-hashcode on var30 and var12", var30.equals(var12) ? var30.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 10.0d);
    org.jfree.data.Range var5 = var4.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var6 = var4.getHeightConstraintType();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(10.0d, 10.0d);
    org.jfree.data.Range var14 = var13.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var15 = var13.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(0.05d, var1, var6, 0.2d, var10, var15);
    org.jfree.data.Range var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var18 = var16.toRangeHeight(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     boolean var21 = var20.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var20.removeProgressListener(var22);
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
//     int var27 = var26.getPercent();
//     org.jfree.chart.JFreeChart var28 = var26.getChart();
//     org.jfree.chart.event.TitleChangeEvent var29 = null;
//     var28.titleChanged(var29);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    double var12 = var1.getUpperMargin();
    var1.setLabelToolTip("PieSection: -16777216, 100(XY Plot)");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var19 = var18.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var22 = var21.getAlpha();
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
//     java.util.List var26 = var18.getAnnotations();
//     var11.drawRangeTickBands(var16, var17, var26);
//     int var28 = var11.getRangeAxisCount();
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     var30.setFixedDimension((-1.0d));
//     java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var35 = var34.getLabelURL();
//     var34.setNegativeArrowVisible(false);
//     java.awt.Font var38 = var34.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var29, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var34, var39);
//     org.jfree.chart.axis.ValueAxis var42 = var40.getDomainAxis(100);
//     org.jfree.chart.util.Layer var44 = null;
//     java.util.Collection var45 = var40.getDomainMarkers((-1), var44);
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var48 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var49 = var48.getPaint();
//     var47.setOutlinePaint(var49);
//     var40.setRangeGridlinePaint(var49);
//     org.jfree.chart.axis.AxisLocation var52 = var40.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var54 = var40.getRangeAxisForDataset(0);
//     java.awt.Paint var55 = var40.getDomainCrosshairPaint();
//     java.awt.Stroke var56 = var40.getDomainCrosshairStroke();
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var58.setLabel("");
//     org.jfree.chart.event.MarkerChangeEvent var61 = null;
//     var58.notifyListeners(var61);
//     var40.addDomainMarker((org.jfree.chart.plot.Marker)var58);
//     org.jfree.chart.util.Layer var64 = null;
//     boolean var65 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var58, var64);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     boolean var7 = var0.isRangeCrosshairVisible();
//     boolean var8 = var0.isSubplot();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
//     java.awt.Font var15 = var13.getLabelFont();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var15);
//     java.awt.Paint var18 = null;
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, var18);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.setWeight(100);
//     org.jfree.data.category.CategoryDataset var24 = var20.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var25 = var20.getDomainAxis();
//     java.awt.Paint var26 = var20.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("", var15, (org.jfree.chart.plot.Plot)var20, false);
//     boolean var29 = var28.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var30 = null;
//     var28.removeProgressListener(var30);
//     var28.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.LegendTitle var35 = var28.getLegend(100);
//     java.lang.Object var36 = var28.clone();
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var38 = var37.getAngleTickUnit();
//     boolean var39 = var37.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var40 = null;
//     var37.setDataset(var40);
//     java.awt.Stroke var42 = var37.getRadiusGridlineStroke();
//     var28.setBorderStroke(var42);
//     var0.setDomainGridlineStroke(var42);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("UnitType.ABSOLUTE", var1, var2);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.setInverted(true);
    var0.setTickMarkOutsideLength((-1.0f));
    var0.setRangeAboutValue(10.0d, 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = var0.getRendererForDataset(var5);
    java.awt.Stroke var7 = var0.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var9 = var0.getRangeAxisEdge(100);
    boolean var10 = var0.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLegendItemGraphicPadding();
    java.awt.Font var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setItemFont(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    boolean var9 = var8.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var12 = var11.getAlpha();
    org.jfree.chart.util.Layer var13 = null;
    boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
    org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
    var0.setRangeAxisLocation(var15, false);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var0.getRendererForDataset(var18);
    org.jfree.chart.LegendItemCollection var20 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var22 = var20.get(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     var3.setFixedDimension((-1.0d));
//     java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var8 = var7.getLabelURL();
//     var7.setNegativeArrowVisible(false);
//     java.awt.Font var11 = var7.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var7, var12);
//     org.jfree.data.Range var14 = var7.getDefaultAutoRange();
//     org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 90.0d);
//     var1.setRange(var14, true, true);
//     org.jfree.chart.axis.DateTickUnit var20 = null;
//     java.util.Date var21 = var1.calculateLowestVisibleTickValue(var20);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.data.Range var12 = var5.getDefaultAutoRange();
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 90.0d);
    double var15 = var12.getLength();
    double var16 = var12.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var19 = var18.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var22 = var21.getAlpha();
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
//     java.util.List var26 = var18.getAnnotations();
//     var11.drawRangeTickBands(var16, var17, var26);
//     int var28 = var11.getRangeAxisCount();
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var31 = var30.getLabelURL();
//     java.util.EventListener var32 = null;
//     boolean var33 = var30.hasListener(var32);
//     var30.setInverted(true);
//     java.awt.Paint var36 = var30.getAxisLinePaint();
//     var11.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var30);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     var11.handleClick(0, 4, var40);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     java.awt.Paint var6 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var8.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var12 = var11.getAlpha();
//     org.jfree.chart.util.Layer var13 = null;
//     boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
//     var0.setRangeAxisLocation(var15, false);
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var21 = var20.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     var22.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var26 = var25.getLabelURL();
//     java.util.EventListener var27 = null;
//     boolean var28 = var25.hasListener(var27);
//     var25.setInverted(true);
//     java.awt.Paint var31 = var25.getAxisLinePaint();
//     var22.setTickMarkPaint(var31);
//     var20.setPaint(var31);
//     org.jfree.chart.util.Layer var34 = null;
//     var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var20, var34);
//     
//     // Checks the contract:  equals-hashcode on var11 and var20
//     assertTrue("Contract failed: equals-hashcode on var11 and var20", var11.equals(var20) ? var11.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var11
//     assertTrue("Contract failed: equals-hashcode on var20 and var11", var20.equals(var11) ? var20.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.awt.Font var6 = var4.getFont();
//     java.lang.String var7 = var4.getURLText();
//     java.awt.Paint var8 = var4.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     var9.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     var14.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var17 = var14.getOutlineStroke();
//     var9.setPlot((org.jfree.chart.plot.Plot)var14);
//     java.awt.Image var19 = var14.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var21 = null;
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14, (org.jfree.chart.block.Arrangement)var20, var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLegendItemGraphicPadding();
//     org.jfree.chart.util.HorizontalAlignment var24 = var22.getHorizontalAlignment();
//     var4.setTextAlignment(var24);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     java.awt.Font var4 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
//     java.lang.Object var6 = var5.clone();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     boolean var9 = var5.equals((java.lang.Object)var8);
//     java.lang.String var10 = var8.getLabelFormat();
//     java.text.NumberFormat var11 = var8.getPercentFormat();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
//     java.awt.Font var15 = var13.getLabelFont();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     boolean var20 = var16.equals((java.lang.Object)var19);
//     java.lang.String var21 = var19.getLabelFormat();
//     java.text.NumberFormat var22 = var19.getPercentFormat();
//     java.text.NumberFormat var23 = var19.getNumberFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var11, var23);
//     
//     // Checks the contract:  equals-hashcode on var3 and var14
//     assertTrue("Contract failed: equals-hashcode on var3 and var14", var3.equals(var14) ? var3.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var3
//     assertTrue("Contract failed: equals-hashcode on var14 and var3", var14.equals(var3) ? var14.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var19
//     assertTrue("Contract failed: equals-hashcode on var8 and var19", var8.equals(var19) ? var8.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var8
//     assertTrue("Contract failed: equals-hashcode on var19 and var8", var19.equals(var8) ? var19.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var4 = var3.getLabelURL();
//     java.util.EventListener var5 = null;
//     boolean var6 = var3.hasListener(var5);
//     var3.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
//     var10.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var13 = var10.getOutlineStroke();
//     var3.setAxisLineStroke(var13);
//     java.awt.Shape var15 = var3.getLeftArrow();
//     boolean var16 = var0.equals((java.lang.Object)var15);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var0.zoomRangeAxes(102.0d, var18, var19);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     var0.handleClick(15, 4, var23);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    var19.removeLegend();
    var19.setTextAntiAlias(true);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    var29.setFixedDimension((-1.0d));
    java.lang.Object var32 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var29);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var34 = var33.getLabelURL();
    var33.setNegativeArrowVisible(false);
    java.awt.Font var37 = var33.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var33, var38);
    org.jfree.chart.axis.ValueAxis var41 = var39.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = var39.getRenderer();
    java.awt.Paint var43 = var39.getDomainZeroBaselinePaint();
    var39.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var46 = null;
    var39.setFixedRangeAxisSpace(var46, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setTextAntiAlias((java.lang.Object)var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var4 = var3.getMaximumDate();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var7 = var6.getMaximumDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var4, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2);
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var6 = var5.getMaximumDate();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var11 = var10.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
//     java.awt.Font var15 = var13.getLabelFont();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.block.BlockFrame var18 = var16.getFrame();
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var16.removeChangeListener(var19);
//     java.awt.geom.Rectangle2D var21 = var16.getBounds();
//     var10.setUpArrow((java.awt.Shape)var21);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.setWeight(100);
//     org.jfree.data.category.CategoryDataset var27 = var23.getDataset(0);
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = var23.getRendererForDataset(var28);
//     java.awt.Stroke var30 = var23.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var32 = var23.getRangeAxisEdge(100);
//     double var33 = var8.java2DToValue(0.2d, var21, var32);
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var35.removeCategoryLabelToolTip((java.lang.Comparable)' ');
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var45 = var44.getStandardTickUnits();
//     java.awt.Font var46 = var44.getLabelFont();
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("", var46);
//     java.lang.Object var48 = var47.clone();
//     org.jfree.chart.block.BlockFrame var49 = var47.getFrame();
//     org.jfree.chart.event.TitleChangeListener var50 = null;
//     var47.removeChangeListener(var50);
//     java.awt.geom.Rectangle2D var52 = var47.getBounds();
//     org.jfree.chart.entity.ChartEntity var55 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var52, "", "");
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var41.valueToJava2D(1.0E-8d, var52, var56);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     var58.setWeight(100);
//     org.jfree.data.category.CategoryDataset var62 = var58.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var63 = var58.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var64 = var58.getRangeAxisEdge();
//     double var65 = var35.getCategoryStart(1, (-16777216), var52, var64);
//     double var66 = var1.dateToJava2D(var6, var21, var64);
//     
//     // Checks the contract:  equals-hashcode on var14 and var45
//     assertTrue("Contract failed: equals-hashcode on var14 and var45", var14.equals(var45) ? var14.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var14
//     assertTrue("Contract failed: equals-hashcode on var45 and var14", var45.equals(var14) ? var45.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var58
//     assertTrue("Contract failed: equals-hashcode on var23 and var58", var23.equals(var58) ? var23.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var23
//     assertTrue("Contract failed: equals-hashcode on var58 and var23", var58.equals(var23) ? var58.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var21 = null;
//     var19.removeProgressListener(var21);
//     var19.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.LegendTitle var26 = var19.getLegend(100);
//     org.jfree.chart.title.LegendTitle var27 = var19.getLegend();
//     org.jfree.chart.event.PlotChangeEvent var28 = null;
//     var19.plotChanged(var28);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var3 = var2.getPaint();
//     var1.setOutlinePaint(var3);
//     org.jfree.chart.JFreeChart var5 = null;
//     org.jfree.chart.event.ChartChangeEventType var6 = null;
//     org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var5, var6);
//     org.jfree.chart.util.RectangleInsets var8 = var1.getLabelOffset();
//     java.lang.Object var9 = null;
//     boolean var10 = var1.equals(var9);
//     java.lang.Class var11 = null;
//     java.util.EventListener[] var12 = var1.getListeners(var11);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("0,0,1,1");
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var4 = var3.getMaximumDate();
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
//     boolean var6 = var5.getSectionOutlinesVisible();
//     var5.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var13.removeChangeListener(var16);
//     java.awt.geom.Rectangle2D var18 = var13.getBounds();
//     var5.setLegendItemShape((java.awt.Shape)var18);
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var24 = var23.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var27 = var26.getStandardTickUnits();
//     java.awt.Font var28 = var26.getLabelFont();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("", var28);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.block.BlockFrame var31 = var29.getFrame();
//     org.jfree.chart.event.TitleChangeListener var32 = null;
//     var29.removeChangeListener(var32);
//     java.awt.geom.Rectangle2D var34 = var29.getBounds();
//     var23.setUpArrow((java.awt.Shape)var34);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.setWeight(100);
//     org.jfree.data.category.CategoryDataset var40 = var36.getDataset(0);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = var36.getRendererForDataset(var41);
//     java.awt.Stroke var43 = var36.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var45 = var36.getRangeAxisEdge(100);
//     double var46 = var21.java2DToValue(0.2d, var34, var45);
//     double var47 = var1.dateToJava2D(var4, var18, var45);
//     
//     // Checks the contract:  equals-hashcode on var11 and var27
//     assertTrue("Contract failed: equals-hashcode on var11 and var27", var11.equals(var27) ? var11.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var11
//     assertTrue("Contract failed: equals-hashcode on var27 and var11", var27.equals(var11) ? var27.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     java.awt.Font var4 = var2.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var7 = var6.getAlpha();
//     java.awt.Paint var8 = var6.getPaint();
//     org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("", var4, var8);
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     java.lang.Object var11 = var10.clone();
//     boolean var12 = var9.equals(var11);
//     org.jfree.chart.text.TextFragment var13 = var9.getFirstTextFragment();
//     org.jfree.chart.text.TextFragment var14 = var9.getLastTextFragment();
//     java.awt.Font var15 = var14.getFont();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     var17.setFixedDimension((-1.0d));
//     java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var17);
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     var21.setNegativeArrowVisible(false);
//     java.awt.Font var25 = var21.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var21, var26);
//     org.jfree.chart.axis.ValueAxis var29 = var27.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = var27.getRenderer();
//     java.awt.Paint var31 = var27.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var35 = var34.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var38 = var37.getAlpha();
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var34.removeRangeMarker((org.jfree.chart.plot.Marker)var37, var39);
//     org.jfree.chart.axis.AxisLocation var41 = var34.getRangeAxisLocation();
//     java.util.List var42 = var34.getAnnotations();
//     var27.drawRangeTickBands(var32, var33, var42);
//     java.awt.Paint var44 = var27.getDomainZeroBaselinePaint();
//     boolean var45 = var27.isDomainCrosshairLockedOnData();
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("Category Plot", var15, (org.jfree.chart.plot.Plot)var27, false);
//     
//     // Checks the contract:  equals-hashcode on var6 and var37
//     assertTrue("Contract failed: equals-hashcode on var6 and var37", var6.equals(var37) ? var6.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var6
//     assertTrue("Contract failed: equals-hashcode on var37 and var6", var37.equals(var6) ? var37.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("0,0,1,1");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     java.awt.Stroke var6 = var0.getDomainGridlineStroke();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     boolean var9 = var8.getSectionOutlinesVisible();
//     double var10 = var8.getMaximumExplodePercent();
//     var8.setSectionOutlinesVisible(false);
//     double var13 = var8.getLabelLinkMargin();
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     var15.setFixedDimension((-1.0d));
//     java.lang.Object var18 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var15);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var20 = var19.getLabelURL();
//     var19.setNegativeArrowVisible(false);
//     java.awt.Font var23 = var19.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.axis.ValueAxis var27 = var25.getDomainAxis(100);
//     var25.clearRangeMarkers(15);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.plot.PiePlotState var32 = new org.jfree.chart.plot.PiePlotState(var31);
//     int var33 = var32.getPassesRequired();
//     double var34 = var32.getPieWRadius();
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot();
//     boolean var36 = var35.getSectionOutlinesVisible();
//     var35.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var41 = var40.getStandardTickUnits();
//     java.awt.Font var42 = var40.getLabelFont();
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("", var42);
//     java.lang.Object var44 = var43.clone();
//     org.jfree.chart.block.BlockFrame var45 = var43.getFrame();
//     org.jfree.chart.event.TitleChangeListener var46 = null;
//     var43.removeChangeListener(var46);
//     java.awt.geom.Rectangle2D var48 = var43.getBounds();
//     var35.setLegendItemShape((java.awt.Shape)var48);
//     var32.setLinkArea(var48);
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     org.jfree.chart.plot.CrosshairState var53 = null;
//     boolean var54 = var25.render(var30, var48, 0, var52, var53);
//     var8.setLegendItemShape((java.awt.Shape)var48);
//     var0.drawBackground(var7, var48);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var17 = var16.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     java.util.EventListener var23 = null;
//     boolean var24 = var21.hasListener(var23);
//     var21.setInverted(true);
//     java.awt.Paint var27 = var21.getAxisLinePaint();
//     var18.setTickMarkPaint(var27);
//     var16.setPaint(var27);
//     org.jfree.chart.util.Layer var30 = null;
//     var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
//     java.lang.Object var32 = var11.clone();
//     java.awt.Graphics2D var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     var11.drawBackground(var33, var34);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    var11.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var18 = null;
    var11.setFixedRangeAxisSpace(var18, true);
    var11.clearDomainMarkers((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var24 = var11.getRangeAxisForDataset((-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.FIXED", var1, 0.8f, 1.0f, var4, 1.0d, var6);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     var0.clear();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
//     java.awt.Font var5 = var3.getLabelFont();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var5);
//     java.lang.Object var7 = var6.clone();
//     java.lang.String var8 = var6.getText();
//     org.jfree.chart.util.RectangleInsets var9 = var6.getPadding();
//     double var11 = var9.extendHeight(100.0d);
//     var0.setPadding(var9);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
//     java.awt.Font var15 = var13.getLabelFont();
//     var13.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var18 = new org.jfree.chart.plot.MultiplePiePlot();
//     var18.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var21 = var18.getOutlineStroke();
//     var13.setPlot((org.jfree.chart.plot.Plot)var18);
//     java.awt.Image var23 = var18.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var25 = null;
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var24, var25);
//     org.jfree.chart.LegendItemSource[] var27 = var26.getSources();
//     var0.add((org.jfree.chart.block.Block)var26);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    var0.setLabelLinkMargin(10.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var7 = var0.getLabelDistributor();
    org.jfree.chart.util.RectangleInsets var8 = var0.getLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var20 = var19.getPaint();
//     var18.setOutlinePaint(var20);
//     var11.setRangeGridlinePaint(var20);
//     org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
//     java.awt.Paint var26 = var11.getDomainCrosshairPaint();
//     java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
//     java.awt.Paint var28 = var11.getRangeGridlinePaint();
//     org.jfree.chart.plot.Marker var29 = null;
//     boolean var30 = var11.removeDomainMarker(var29);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    java.awt.Image var21 = null;
    var19.setBackgroundImage(var21);
    org.jfree.chart.plot.Plot var23 = var19.getPlot();
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var25 = var24.getLabelURL();
    var24.setNegativeArrowVisible(false);
    java.awt.Font var28 = var24.getTickLabelFont();
    org.jfree.chart.axis.MarkerAxisBand var29 = null;
    var24.setMarkerBand(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setTextAntiAlias((java.lang.Object)var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    var0.setNegativeArrowVisible(false);
    var0.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(0.0d);
    double var5 = var4.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     int var3 = var0.getWeight();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     var4.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
//     var9.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var12 = var9.getOutlineStroke();
//     var4.setPlot((org.jfree.chart.plot.Plot)var9);
//     var4.setAutoTickUnitSelection(false);
//     org.jfree.chart.axis.ValueAxis[] var16 = new org.jfree.chart.axis.ValueAxis[] { var4};
//     var0.setRangeAxes(var16);
//     org.jfree.chart.axis.CategoryAxis var19 = var0.getDomainAxis((-16777216));
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
//     java.awt.Font var22 = var20.getLabelFont();
//     var20.setLabel("");
//     boolean var25 = var20.isAxisLineVisible();
//     java.awt.Paint var26 = var20.getTickLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.setWeight(100);
//     org.jfree.data.category.CategoryDataset var31 = var27.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var32 = var27.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var33 = var27.getDatasetRenderingOrder();
//     boolean var34 = var27.isRangeCrosshairVisible();
//     boolean var35 = var27.isRangeCrosshairLockedOnData();
//     var20.setPlot((org.jfree.chart.plot.Plot)var27);
//     org.jfree.chart.LegendItemCollection var37 = var27.getLegendItems();
//     var0.setFixedLegendItems(var37);
//     
//     // Checks the contract:  equals-hashcode on var5 and var21
//     assertTrue("Contract failed: equals-hashcode on var5 and var21", var5.equals(var21) ? var5.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var5
//     assertTrue("Contract failed: equals-hashcode on var21 and var5", var21.equals(var5) ? var21.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PieSection: -16777216, 100(XY Plot)", "WMAP_Plot", var3);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var21 = null;
//     var19.removeProgressListener(var21);
//     var19.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.event.PlotChangeEvent var25 = null;
//     var19.plotChanged(var25);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = var0.getRendererForDataset(var5);
    org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var9 = var8.getAlpha();
    java.awt.Paint var10 = var8.getPaint();
    org.jfree.chart.util.LengthAdjustmentType var11 = var8.getLabelOffsetType();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
    java.awt.Font var16 = var14.getLabelFont();
    var13.setLabelFont(var16);
    var8.setLabelFont(var16);
    org.jfree.chart.util.Layer var19 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var8, var19);
    var0.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var3 = var2.getPaint();
    var1.setOutlinePaint(var3);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var3);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setWeight(100);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
    java.awt.Font var13 = var11.getLabelFont();
    var10.setLabelFont(var13);
    var6.setDomainAxis(var10);
    boolean var16 = var5.equals((java.lang.Object)var10);
    java.awt.Paint var17 = var5.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.lang.String var6 = var4.getText();
//     org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
//     java.lang.Object var8 = var4.clone();
//     org.jfree.chart.util.HorizontalAlignment var9 = var4.getTextAlignment();
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
//     java.awt.Font var13 = var11.getLabelFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var13);
//     java.lang.Object var15 = var14.clone();
//     org.jfree.chart.util.VerticalAlignment var16 = var14.getVerticalAlignment();
//     java.lang.String var17 = var16.toString();
//     org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var9, var16, 2.2d, 0.20000000000000018d);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var11.zoomRangeAxes(0.0d, var29, var30, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Polar Plot");

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     var1.setLabel("");
//     boolean var6 = var1.isAxisLineVisible();
//     java.awt.Font var7 = var1.getTickLabelFont();
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var9 = var8.getAngleTickUnit();
//     java.awt.Paint var10 = var8.getRadiusGridlinePaint();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("LengthConstraintType.FIXED", var7, (org.jfree.chart.plot.Plot)var8, false);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.setWeight(100);
//     org.jfree.data.category.CategoryDataset var17 = var13.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var18 = var13.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var13.getDatasetRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var23 = var22.getStandardTickUnits();
//     java.awt.Font var24 = var22.getLabelFont();
//     var21.setLabelFont(var24);
//     java.util.List var26 = var13.getCategoriesForAxis(var21);
//     java.util.Collection var27 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var26);
//     var12.setSubtitles(var26);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     var0.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var7 = var6.getLabelURL();
//     java.util.EventListener var8 = null;
//     boolean var9 = var6.hasListener(var8);
//     var6.setInverted(true);
//     java.awt.Paint var12 = var6.getAxisLinePaint();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
//     var0.setBackgroundAlpha(0.0f);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setWeight(100);
//     org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var22 = var17.getDomainAxis();
//     java.awt.Paint var23 = var17.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var24 = var17.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var26 = var25.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var29 = var28.getAlpha();
//     org.jfree.chart.util.Layer var30 = null;
//     boolean var31 = var25.removeRangeMarker((org.jfree.chart.plot.Marker)var28, var30);
//     org.jfree.chart.axis.AxisLocation var32 = var25.getRangeAxisLocation();
//     var17.setRangeAxisLocation(var32, false);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var17.getRendererForDataset(var35);
//     org.jfree.chart.LegendItemCollection var37 = var17.getLegendItems();
//     var0.setFixedLegendItems(var37);
//     int var39 = var37.getItemCount();
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.LegendItemCollection var41 = var40.getLegendItems();
//     int var42 = var41.getItemCount();
//     java.util.Iterator var43 = var41.iterator();
//     var37.addAll(var41);
//     
//     // Checks the contract:  equals-hashcode on var37 and var41
//     assertTrue("Contract failed: equals-hashcode on var37 and var41", var37.equals(var41) ? var37.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var37
//     assertTrue("Contract failed: equals-hashcode on var41 and var37", var41.equals(var37) ? var41.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.util.HorizontalAlignment var15 = var13.getHorizontalAlignment();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     var16.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
//     var21.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var24 = var21.getOutlineStroke();
//     var16.setPlot((org.jfree.chart.plot.Plot)var21);
//     java.awt.Image var26 = var21.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var28 = null;
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = var29.getSources();
//     var13.setSources(var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var21
//     assertTrue("Contract failed: equals-hashcode on var5 and var21", var5.equals(var21) ? var5.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var5
//     assertTrue("Contract failed: equals-hashcode on var21 and var5", var21.equals(var5) ? var21.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var27
//     assertTrue("Contract failed: equals-hashcode on var11 and var27", var11.equals(var27) ? var11.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var11
//     assertTrue("Contract failed: equals-hashcode on var27 and var11", var27.equals(var11) ? var27.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var4 = var3.getLabel();
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var10 = var9.getPaint();
//     var8.setOutlinePaint(var10);
//     org.jfree.chart.util.RectangleAnchor var12 = var8.getLabelAnchor();
//     var3.setLabelAnchor(var12);
//     java.lang.Class var14 = null;
//     java.util.EventListener[] var15 = var3.getListeners(var14);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.ChartRenderingInfo var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var30 = var19.createBufferedImage((-16777216), 0, 100.0d, 0.20000000000000018d, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", (-16777216));
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     var5.setFixedDimension((-1.0d));
//     java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var10 = var9.getLabelURL();
//     var9.setNegativeArrowVisible(false);
//     java.awt.Font var13 = var9.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = var15.getRenderer();
//     java.awt.Paint var19 = var15.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var23 = var22.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var26 = var25.getAlpha();
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var22.removeRangeMarker((org.jfree.chart.plot.Marker)var25, var27);
//     org.jfree.chart.axis.AxisLocation var29 = var22.getRangeAxisLocation();
//     java.util.List var30 = var22.getAnnotations();
//     var15.drawRangeTickBands(var20, var21, var30);
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = var15.getRenderer((-1));
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var35 = var34.getStandardTickUnits();
//     java.awt.Font var36 = var34.getLabelFont();
//     var34.setLabel("");
//     boolean var39 = var34.isAxisLineVisible();
//     java.awt.Paint var40 = var34.getTickLabelPaint();
//     var15.setDomainZeroBaselinePaint(var40);
//     java.awt.Paint[] var42 = new java.awt.Paint[] { var40};
//     org.jfree.chart.axis.NumberAxis3D var47 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var48 = var47.getStandardTickUnits();
//     java.awt.Font var49 = var47.getLabelFont();
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("", var49);
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle("", var49);
//     java.awt.Paint var52 = null;
//     org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("", var49, var52);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.setWeight(100);
//     org.jfree.data.category.CategoryDataset var58 = var54.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var59 = var54.getDomainAxis();
//     java.awt.Paint var60 = var54.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("", var49, (org.jfree.chart.plot.Plot)var54, false);
//     boolean var63 = var62.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var64 = null;
//     var62.removeProgressListener(var64);
//     var62.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.LegendTitle var69 = var62.getLegend(100);
//     java.lang.Object var70 = var62.clone();
//     org.jfree.chart.plot.PolarPlot var71 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var72 = var71.getAngleTickUnit();
//     boolean var73 = var71.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var74 = null;
//     var71.setDataset(var74);
//     java.awt.Stroke var76 = var71.getRadiusGridlineStroke();
//     var62.setBorderStroke(var76);
//     java.awt.Stroke[] var78 = new java.awt.Stroke[] { var76};
//     org.jfree.chart.StrokeMap var79 = new org.jfree.chart.StrokeMap();
//     boolean var81 = var79.containsKey((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.plot.PolarPlot var83 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var84 = var83.getAngleTickUnit();
//     boolean var85 = var83.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var86 = null;
//     var83.setDataset(var86);
//     java.awt.Stroke var88 = var83.getRadiusGridlineStroke();
//     var79.put((java.lang.Comparable)(-16777216), var88);
//     java.awt.Stroke[] var90 = new java.awt.Stroke[] { var88};
//     java.awt.Shape[] var91 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var92 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var42, var78, var90, var91);
//     
//     // Checks the contract:  equals-hashcode on var35 and var48
//     assertTrue("Contract failed: equals-hashcode on var35 and var48", var35.equals(var48) ? var35.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var35
//     assertTrue("Contract failed: equals-hashcode on var48 and var35", var48.equals(var35) ? var48.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var83
//     assertTrue("Contract failed: equals-hashcode on var71 and var83", var71.equals(var83) ? var71.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var71
//     assertTrue("Contract failed: equals-hashcode on var83 and var71", var83.equals(var71) ? var83.hashCode() == var71.hashCode() : true);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
//     boolean var2 = var0.containsKey((java.lang.Comparable)(short)(-1));
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var5 = var4.getAngleTickUnit();
//     boolean var6 = var4.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var7 = null;
//     var4.setDataset(var7);
//     java.awt.Stroke var9 = var4.getRadiusGridlineStroke();
//     var0.put((java.lang.Comparable)(-16777216), var9);
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
//     java.awt.Font var13 = var11.getLabelFont();
//     var11.setLabel("");
//     boolean var16 = var11.isAxisLineVisible();
//     java.awt.Paint var17 = var11.getTickLabelPaint();
//     org.jfree.chart.axis.NumberTickUnit var18 = var11.getTickUnit();
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
//     boolean var20 = var19.getSectionOutlinesVisible();
//     java.awt.Paint var22 = null;
//     var19.setSectionPaint((java.lang.Comparable)10, var22);
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
//     java.awt.Font var26 = var24.getLabelFont();
//     var24.setLabel("");
//     java.lang.String var29 = var24.getLabel();
//     java.awt.Stroke var30 = var24.getAxisLineStroke();
//     var19.setLabelOutlineStroke(var30);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.setWeight(100);
//     org.jfree.data.category.CategoryDataset var36 = var32.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var37 = var32.getDomainAxis();
//     java.awt.Paint var38 = var32.getRangeCrosshairPaint();
//     var19.setLabelPaint(var38);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var42 = var41.getAlpha();
//     java.awt.Paint var43 = var41.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var44 = var41.getLabelOffsetType();
//     org.jfree.chart.event.MarkerChangeEvent var45 = null;
//     var41.notifyListeners(var45);
//     org.jfree.chart.axis.NumberAxis3D var47 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var48 = var47.getLabelURL();
//     java.util.EventListener var49 = null;
//     boolean var50 = var47.hasListener(var49);
//     var47.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var54 = new org.jfree.chart.plot.MultiplePiePlot();
//     var54.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var57 = var54.getOutlineStroke();
//     var47.setAxisLineStroke(var57);
//     var41.setStroke(var57);
//     var19.setBaseSectionOutlineStroke(var57);
//     var0.put((java.lang.Comparable)var18, var57);
//     
//     // Checks the contract:  equals-hashcode on var12 and var25
//     assertTrue("Contract failed: equals-hashcode on var12 and var25", var12.equals(var25) ? var12.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var12
//     assertTrue("Contract failed: equals-hashcode on var25 and var12", var25.equals(var12) ? var25.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = var0.getRendererForDataset(var5);
    java.awt.Stroke var7 = var0.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var9 = var0.getRangeAxisEdge(100);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    int var11 = var0.getIndexOf(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var11.handleClick(100, 255, var18);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
//     org.jfree.data.Range var6 = var5.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var8 = var5.toFixedWidth(0.0d);
//     double var9 = var5.getWidth();
//     org.jfree.chart.util.Size2D var10 = var1.arrange(var2, var5);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var1.draw(var11, var12);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
//     java.awt.Paint var6 = var0.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var9 = var8.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var12 = var11.getAlpha();
//     org.jfree.chart.util.Layer var13 = null;
//     boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
//     var0.setRangeAxisLocation(var15, false);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var0.getRendererForDataset(var18);
//     org.jfree.chart.LegendItemCollection var20 = var0.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var0.zoomRangeAxes(0.2d, var22, var23);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.setWeight(100);
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var31 = var26.getDomainAxis();
//     java.awt.Paint var32 = var26.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var33 = var26.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var35 = var34.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var38 = var37.getAlpha();
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var34.removeRangeMarker((org.jfree.chart.plot.Marker)var37, var39);
//     org.jfree.chart.axis.AxisLocation var41 = var34.getRangeAxisLocation();
//     var26.setRangeAxisLocation(var41, false);
//     var0.setDomainAxisLocation(10, var41);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var8
//     assertTrue("Contract failed: equals-hashcode on var34 and var8", var34.equals(var8) ? var34.hashCode() == var8.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var0.", var26.equals(var0) == var0.equals(var26));
//     
//     // Checks the contract:  equals-hashcode on var11 and var37
//     assertTrue("Contract failed: equals-hashcode on var11 and var37", var11.equals(var37) ? var11.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var11
//     assertTrue("Contract failed: equals-hashcode on var37 and var11", var37.equals(var11) ? var37.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    boolean var5 = var0.isAxisLineVisible();
    java.awt.Paint var6 = var0.getTickLabelPaint();
    org.jfree.chart.axis.NumberTickUnit var7 = var0.getTickUnit();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(12.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    boolean var2 = var0.isDomainZoomable();
    org.jfree.data.xy.XYDataset var3 = null;
    var0.setDataset(var3);
    java.awt.Stroke var5 = var0.getRadiusGridlineStroke();
    boolean var6 = var0.isRangeZoomable();
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
    java.awt.Font var9 = var7.getLabelFont();
    var7.setLabel("");
    java.lang.String var12 = var7.getLabel();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var7);
    var0.clearCornerTextItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var1 = var0.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var4 = var3.getAlpha();
//     org.jfree.chart.util.Layer var5 = null;
//     boolean var6 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var3, var5);
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var8.setLabel("");
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var13 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var14 = var13.getPaint();
//     var12.setOutlinePaint(var14);
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var18 = var17.getAlpha();
//     java.awt.Paint var19 = var17.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var20 = var17.getLabelOffsetType();
//     var12.setLabelOffsetType(var20);
//     var8.setLabelOffsetType(var20);
//     var3.setLabelOffsetType(var20);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     boolean var21 = var20.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var20.removeProgressListener(var22);
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
//     java.lang.Object var27 = var20.clone();
//     boolean var28 = var20.isNotify();
//     boolean var29 = var20.isNotify();
//     org.jfree.chart.plot.MultiplePiePlot var31 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var38 = var37.getAlpha();
//     java.awt.Paint var39 = var37.getPaint();
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("", var35, var39);
//     var31.setAggregatedItemsPaint(var39);
//     org.jfree.data.category.CategoryDataset var42 = null;
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var45 = var44.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D();
//     var46.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var50 = var49.getLabelURL();
//     java.util.EventListener var51 = null;
//     boolean var52 = var49.hasListener(var51);
//     var49.setInverted(true);
//     java.awt.Paint var55 = var49.getAxisLinePaint();
//     var46.setTickMarkPaint(var55);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var42, var44, (org.jfree.chart.axis.ValueAxis)var46, var57);
//     java.awt.Stroke var59 = var58.getRangeGridlineStroke();
//     java.awt.Paint var60 = null;
//     org.jfree.chart.plot.MultiplePiePlot var61 = new org.jfree.chart.plot.MultiplePiePlot();
//     var61.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var64 = var61.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(102.0d, var39, var59, var60, var64, 0.0f);
//     var20.setBorderStroke(var59);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     java.lang.String var5 = var0.getLabel();
//     java.awt.Stroke var6 = var0.getAxisLineStroke();
//     java.lang.String var7 = var0.getLabelToolTip();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.axis.AxisState var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var11 = var10.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
//     java.awt.Font var15 = var13.getLabelFont();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.chart.block.BlockFrame var18 = var16.getFrame();
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var16.removeChangeListener(var19);
//     java.awt.geom.Rectangle2D var21 = var16.getBounds();
//     var10.setUpArrow((java.awt.Shape)var21);
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
//     java.awt.Font var25 = var23.getLabelFont();
//     var23.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var28 = new org.jfree.chart.plot.MultiplePiePlot();
//     var28.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var31 = var28.getOutlineStroke();
//     var23.setPlot((org.jfree.chart.plot.Plot)var28);
//     java.awt.Image var33 = var28.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var35 = null;
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28, (org.jfree.chart.block.Arrangement)var34, var35);
//     org.jfree.chart.util.RectangleInsets var37 = var36.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var38 = var36.getLegendItemGraphicAnchor();
//     org.jfree.chart.LegendItemSource[] var39 = var36.getSources();
//     org.jfree.chart.util.RectangleEdge var40 = var36.getLegendItemGraphicEdge();
//     java.util.List var41 = var0.refreshTicks(var8, var9, var21, var40);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     boolean var5 = var0.isAxisLineVisible();
//     java.awt.Paint var6 = var0.getTickLabelPaint();
//     org.jfree.chart.axis.NumberTickUnit var7 = var0.getTickUnit();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
//     java.lang.Object var13 = var12.clone();
//     java.awt.Font var14 = var12.getFont();
//     var0.setTickLabelFont(var14);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
//     org.jfree.chart.util.HorizontalAlignment var7 = var4.getTextAlignment();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.util.VerticalAlignment var14 = var12.getVerticalAlignment();
//     var4.setVerticalAlignment(var14);
//     
//     // Checks the contract:  equals-hashcode on var2 and var10
//     assertTrue("Contract failed: equals-hashcode on var2 and var10", var2.equals(var10) ? var2.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var2
//     assertTrue("Contract failed: equals-hashcode on var10 and var2", var10.equals(var2) ? var10.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
    java.awt.Font var5 = var3.getLabelFont();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var5);
    java.lang.Object var7 = var6.clone();
    java.lang.String var8 = var6.getText();
    org.jfree.chart.util.RectangleInsets var9 = var6.getPadding();
    var0.setLabelPadding(var9);
    var0.setLabelLinkMargin(0.025d);
    double var13 = var0.getStartAngle();
    org.jfree.chart.labels.PieToolTipGenerator var14 = null;
    var0.setToolTipGenerator(var14);
    boolean var16 = var0.getSimpleLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var2 = var1.getAlpha();
//     java.awt.Paint var3 = var1.getPaint();
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     boolean var5 = var4.getSectionOutlinesVisible();
//     double var6 = var4.getMaximumExplodePercent();
//     var4.setSectionOutlinesVisible(false);
//     var4.setLabelLinkMargin(10.0d);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     int var12 = var4.getPieIndex();
//     var4.setIgnoreZeroValues(true);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     var16.setFixedDimension((-1.0d));
//     java.lang.Object var19 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var16);
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var21 = var20.getLabelURL();
//     var20.setNegativeArrowVisible(false);
//     java.awt.Font var24 = var20.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var20, var25);
//     org.jfree.chart.axis.ValueAxis var28 = var26.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = var26.getRenderer();
//     java.awt.Paint var30 = var26.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var34 = var33.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var37 = var36.getAlpha();
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var39 = var33.removeRangeMarker((org.jfree.chart.plot.Marker)var36, var38);
//     org.jfree.chart.axis.AxisLocation var40 = var33.getRangeAxisLocation();
//     java.util.List var41 = var33.getAnnotations();
//     var26.drawRangeTickBands(var31, var32, var41);
//     var26.clearRangeAxes();
//     java.awt.Paint var44 = var26.getRangeZeroBaselinePaint();
//     var4.setBaseSectionOutlinePaint(var44);
//     
//     // Checks the contract:  equals-hashcode on var1 and var36
//     assertTrue("Contract failed: equals-hashcode on var1 and var36", var1.equals(var36) ? var1.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var1
//     assertTrue("Contract failed: equals-hashcode on var36 and var1", var36.equals(var1) ? var36.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.title.LegendTitle var26 = var19.getLegend(100);
    boolean var27 = var19.getAntiAlias();
    org.jfree.chart.ChartRenderingInfo var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var33 = var19.createBufferedImage(100, 0, 9.223372036854776E18d, 12.0d, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin((-1.0d));
    float var5 = var2.getMaximumCategoryLabelWidthRatio();
    var2.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var9 = var8.getLabelURL();
    java.util.EventListener var10 = null;
    boolean var11 = var8.hasListener(var10);
    var8.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var14 = null;
    var8.setMarkerBand(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var8, var16);
    var2.setLowerMargin(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     boolean var21 = var20.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var20.removeProgressListener(var22);
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
//     int var27 = var26.getPercent();
//     int var28 = var26.getType();
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     var29.setFixedDimension((-1.0d));
//     java.lang.Object var32 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var29);
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var38 = var37.getStandardTickUnits();
//     java.awt.Font var39 = var37.getLabelFont();
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("", var39);
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("", var39);
//     java.awt.Paint var42 = null;
//     org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("", var39, var42);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.setWeight(100);
//     org.jfree.data.category.CategoryDataset var48 = var44.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var49 = var44.getDomainAxis();
//     java.awt.Paint var50 = var44.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var52 = new org.jfree.chart.JFreeChart("", var39, (org.jfree.chart.plot.Plot)var44, false);
//     boolean var53 = var52.getAntiAlias();
//     org.jfree.chart.event.ChartChangeEventType var54 = null;
//     org.jfree.chart.event.ChartChangeEvent var55 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var29, var52, var54);
//     var26.setChart(var52);
//     
//     // Checks the contract:  equals-hashcode on var6 and var38
//     assertTrue("Contract failed: equals-hashcode on var6 and var38", var6.equals(var38) ? var6.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var6
//     assertTrue("Contract failed: equals-hashcode on var38 and var6", var38.equals(var6) ? var38.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var44
//     assertTrue("Contract failed: equals-hashcode on var12 and var44", var12.equals(var44) ? var12.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var12
//     assertTrue("Contract failed: equals-hashcode on var44 and var12", var44.equals(var12) ? var44.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var52
//     assertTrue("Contract failed: equals-hashcode on var20 and var52", var20.equals(var52) ? var20.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var20
//     assertTrue("Contract failed: equals-hashcode on var52 and var20", var52.equals(var20) ? var52.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Multiple Pie Plot");

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    java.text.DateFormat var4 = null;
    var1.setDateFormatOverride(var4);
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLeftArrow(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setAnchorValue(10.0d, false);
//     java.lang.Object var4 = var0.clone();
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var9 = var8.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     var10.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var14 = var13.getLabelURL();
//     java.util.EventListener var15 = null;
//     boolean var16 = var13.hasListener(var15);
//     var13.setInverted(true);
//     java.awt.Paint var19 = var13.getAxisLinePaint();
//     var10.setTickMarkPaint(var19);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var10, var21);
//     var0.setDomainAxis(255, var8, true);
//     var0.zoom(100.0d);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var17 = var16.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     java.util.EventListener var23 = null;
//     boolean var24 = var21.hasListener(var23);
//     var21.setInverted(true);
//     java.awt.Paint var27 = var21.getAxisLinePaint();
//     var18.setTickMarkPaint(var27);
//     var16.setPaint(var27);
//     org.jfree.chart.util.Layer var30 = null;
//     var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
//     double var40 = var38.extendHeight(10.0d);
//     double var41 = var38.getTop();
//     boolean var42 = var11.equals((java.lang.Object)var38);
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var44 = var43.getLabelURL();
//     java.util.EventListener var45 = null;
//     boolean var46 = var43.hasListener(var45);
//     var43.setInverted(true);
//     var43.setTickMarkOutsideLength((-1.0f));
//     org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
//     org.jfree.data.xy.XYDataset var52 = null;
//     int var53 = var11.indexOf(var52);
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     var11.setRenderer(100, var55, true);
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var60 = var59.getAlpha();
//     java.awt.Paint var61 = var59.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var62 = var59.getLabelOffsetType();
//     org.jfree.chart.event.MarkerChangeEvent var63 = null;
//     var59.notifyListeners(var63);
//     org.jfree.chart.axis.NumberAxis3D var65 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var66 = var65.getLabelURL();
//     java.util.EventListener var67 = null;
//     boolean var68 = var65.hasListener(var67);
//     var65.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var72 = new org.jfree.chart.plot.MultiplePiePlot();
//     var72.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var75 = var72.getOutlineStroke();
//     var65.setAxisLineStroke(var75);
//     var59.setStroke(var75);
//     boolean var78 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var59);
// 
//   }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     java.awt.Image var21 = null;
//     var19.setBackgroundImage(var21);
//     org.jfree.chart.plot.Plot var23 = var19.getPlot();
//     float var24 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     var25.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var30 = new org.jfree.chart.plot.MultiplePiePlot();
//     var30.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var33 = var30.getOutlineStroke();
//     var25.setPlot((org.jfree.chart.plot.Plot)var30);
//     java.awt.Image var35 = var30.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30, (org.jfree.chart.block.Arrangement)var36, var37);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var40 = var38.getLegendItemGraphicAnchor();
//     var19.removeSubtitle((org.jfree.chart.title.Title)var38);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var3.setAxisLineStroke(var13);
    java.awt.Shape var15 = var3.getLeftArrow();
    boolean var16 = var0.equals((java.lang.Object)var15);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var0.zoomRangeAxes(102.0d, var18, var19);
    java.awt.Stroke var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlineStroke(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var4 = var3.getLabel();
//     org.jfree.chart.util.Layer var5 = null;
//     var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
//     org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
//     var0.setOutlineVisible(false);
//     org.jfree.chart.util.RectangleEdge var10 = var0.getDomainAxisEdge();
//     org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot();
//     var11.setBackgroundAlpha(1.0f);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var15 = var14.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var18 = var17.getAlpha();
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var20 = var14.removeRangeMarker((org.jfree.chart.plot.Marker)var17, var19);
//     org.jfree.chart.axis.AxisLocation var21 = var14.getRangeAxisLocation();
//     java.util.List var22 = var14.getAnnotations();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
//     java.awt.Font var26 = var24.getLabelFont();
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("", var26);
//     java.lang.Object var28 = var27.clone();
//     org.jfree.chart.block.BlockFrame var29 = var27.getFrame();
//     org.jfree.chart.util.RectangleInsets var30 = var27.getMargin();
//     var14.setAxisOffset(var30);
//     boolean var32 = var11.equals((java.lang.Object)var30);
//     boolean var33 = var10.equals((java.lang.Object)var30);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicAnchor();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     var17.setFixedDimension((-1.0d));
//     java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var17);
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     var21.setNegativeArrowVisible(false);
//     java.awt.Font var25 = var21.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var21, var26);
//     org.jfree.chart.axis.ValueAxis var29 = var27.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = var27.getRenderer();
//     java.awt.Paint var31 = var27.getDomainZeroBaselinePaint();
//     boolean var32 = var27.isDomainCrosshairLockedOnData();
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var35 = var34.getStandardTickUnits();
//     java.awt.Font var36 = var34.getLabelFont();
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("", var36);
//     java.lang.Object var38 = var37.clone();
//     org.jfree.chart.util.RectangleInsets var39 = var37.getPadding();
//     double var40 = var39.getBottom();
//     org.jfree.chart.util.UnitType var41 = var39.getUnitType();
//     var27.setAxisOffset(var39);
//     var13.setLegendItemGraphicPadding(var39);
//     
//     // Checks the contract:  equals-hashcode on var1 and var35
//     assertTrue("Contract failed: equals-hashcode on var1 and var35", var1.equals(var35) ? var1.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var1
//     assertTrue("Contract failed: equals-hashcode on var35 and var1", var35.equals(var1) ? var35.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX((-1.0d));
    var0.setTranslateY(100.0d);
    var0.setGenerateEntities(true);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2);
//     java.text.DateFormat var4 = null;
//     var1.setDateFormatOverride(var4);
//     java.util.TimeZone var6 = var1.getTimeZone();
//     org.jfree.chart.axis.DateTickUnit var7 = null;
//     java.util.Date var8 = var1.calculateLowestVisibleTickValue(var7);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var28 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var27};
    var11.setRenderers(var28);
    var11.clearRangeAxes();
    org.jfree.chart.annotations.XYAnnotation var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
    boolean var28 = var11.isDomainZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var21 = null;
//     var19.removeProgressListener(var21);
//     org.jfree.chart.plot.Plot var23 = var19.getPlot();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     var24.setFixedDimension((-1.0d));
//     java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var24);
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
//     java.awt.Font var34 = var32.getLabelFont();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("", var34);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var34);
//     java.awt.Paint var37 = null;
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, var37);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.setWeight(100);
//     org.jfree.data.category.CategoryDataset var43 = var39.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var44 = var39.getDomainAxis();
//     java.awt.Paint var45 = var39.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var39, false);
//     boolean var48 = var47.getAntiAlias();
//     org.jfree.chart.event.ChartChangeEventType var49 = null;
//     org.jfree.chart.event.ChartChangeEvent var50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var24, var47, var49);
//     java.awt.Image var51 = null;
//     var47.setBackgroundImage(var51);
//     var47.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var19, var47, 255, 15);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var39
//     assertTrue("Contract failed: equals-hashcode on var11 and var39", var11.equals(var39) ? var11.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var11
//     assertTrue("Contract failed: equals-hashcode on var39 and var11", var39.equals(var11) ? var39.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var47
//     assertTrue("Contract failed: equals-hashcode on var19 and var47", var19.equals(var47) ? var19.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var19
//     assertTrue("Contract failed: equals-hashcode on var47 and var19", var47.equals(var19) ? var47.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    var5.setBackgroundImageAlpha(1.0f);
    var5.setBackgroundAlpha(0.8f);
    java.lang.Object var14 = null;
    boolean var15 = var5.equals(var14);
    org.jfree.chart.JFreeChart var16 = var5.getPieChart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var17 = var16.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSimpleLabels(false);
    var0.setLabelGap(0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    java.util.EventListener var8 = null;
    boolean var9 = var6.hasListener(var8);
    var6.setInverted(true);
    java.awt.Paint var12 = var6.getAxisLinePaint();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setWeight(100);
    org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var22 = var17.getDomainAxis();
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var24 = var17.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    boolean var26 = var25.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var29 = var28.getAlpha();
    org.jfree.chart.util.Layer var30 = null;
    boolean var31 = var25.removeRangeMarker((org.jfree.chart.plot.Marker)var28, var30);
    org.jfree.chart.axis.AxisLocation var32 = var25.getRangeAxisLocation();
    var17.setRangeAxisLocation(var32, false);
    org.jfree.data.category.CategoryDataset var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var17.getRendererForDataset(var35);
    org.jfree.chart.LegendItemCollection var37 = var17.getLegendItems();
    var0.setFixedLegendItems(var37);
    int var39 = var37.getItemCount();
    org.jfree.chart.LegendItem var40 = null;
    var37.add(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     boolean var21 = var20.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var20.removeProgressListener(var22);
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
//     int var27 = var26.getPercent();
//     org.jfree.chart.JFreeChart var28 = var26.getChart();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
//     java.awt.Font var34 = var32.getLabelFont();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("", var34);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var34);
//     var36.setToolTipText("");
//     var36.setExpandToFitSpace(false);
//     java.lang.String var41 = var36.getID();
//     org.jfree.chart.block.LineBorder var42 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var43 = var42.getPaint();
//     var36.setFrame((org.jfree.chart.block.BlockFrame)var42);
//     java.awt.geom.Rectangle2D var45 = var36.getBounds();
//     java.awt.geom.Point2D var46 = null;
//     org.jfree.chart.ChartRenderingInfo var47 = null;
//     var28.draw(var29, var45, var46, var47);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var20 = var19.getPaint();
//     var18.setOutlinePaint(var20);
//     var11.setRangeGridlinePaint(var20);
//     org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
//     java.util.List var24 = var11.getAnnotations();
//     org.jfree.chart.axis.ValueAxis[] var25 = null;
//     var11.setRangeAxes(var25);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     java.awt.geom.Point2D var17 = null;
//     var11.zoomDomainAxes(0.08d, var16, var17, true);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var26 = var25.getAngleTickUnit();
    var25.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    var25.setAxis((org.jfree.chart.axis.ValueAxis)var29);
    var25.setNoDataMessage("hi!");
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var36 = var35.getStandardTickUnits();
    java.awt.Font var37 = var35.getLabelFont();
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("", var37);
    java.lang.Object var39 = var38.clone();
    org.jfree.chart.block.BlockFrame var40 = var38.getFrame();
    org.jfree.chart.event.TitleChangeListener var41 = null;
    var38.removeChangeListener(var41);
    java.awt.geom.Rectangle2D var43 = var38.getBounds();
    java.awt.geom.Point2D var44 = null;
    org.jfree.chart.plot.PlotState var45 = null;
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    var25.draw(var33, var43, var44, var45, var46);
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    boolean var49 = var48.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var52 = var51.getAlpha();
    org.jfree.chart.util.Layer var53 = null;
    boolean var54 = var48.removeRangeMarker((org.jfree.chart.plot.Marker)var51, var53);
    org.jfree.chart.axis.AxisLocation var55 = var48.getRangeAxisLocation();
    java.util.List var56 = var48.getAnnotations();
    var11.drawDomainTickBands(var24, var43, var56);
    org.jfree.chart.event.MarkerChangeEvent var58 = null;
    var11.markerChanged(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
    java.awt.Paint var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setWeight(100);
    org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
    java.awt.Paint var18 = var12.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
    boolean var21 = var20.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var22 = null;
    var20.removeProgressListener(var22);
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
    org.jfree.chart.plot.CategoryPlot var27 = var20.getCategoryPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var29 = var20.getSubtitle((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.awt.Font var6 = var4.getFont();
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
//     java.awt.Font var13 = var11.getLabelFont();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var13);
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("", var13);
//     java.awt.Paint var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, var16);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setWeight(100);
//     org.jfree.data.category.CategoryDataset var22 = var18.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var23 = var18.getDomainAxis();
//     java.awt.Paint var24 = var18.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("", var13, (org.jfree.chart.plot.Plot)var18, false);
//     boolean var27 = var26.getAntiAlias();
//     java.awt.Image var28 = null;
//     var26.setBackgroundImage(var28);
//     java.awt.Paint var30 = var26.getBackgroundPaint();
//     java.awt.Image var31 = null;
//     var26.setBackgroundImage(var31);
//     var4.addChangeListener((org.jfree.chart.event.TitleChangeListener)var26);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var19 = var18.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var22 = var21.getAlpha();
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
//     java.util.List var26 = var18.getAnnotations();
//     var11.drawRangeTickBands(var16, var17, var26);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.setWeight(100);
//     org.jfree.data.category.CategoryDataset var33 = var29.getDataset(0);
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     java.awt.geom.Point2D var36 = null;
//     var29.zoomDomainAxes(102.0d, var35, var36, false);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     var41.setFixedDimension((-1.0d));
//     java.lang.Object var44 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var41);
//     org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var46 = var45.getLabelURL();
//     var45.setNegativeArrowVisible(false);
//     java.awt.Font var49 = var45.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var40, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.axis.ValueAxis)var45, var50);
//     org.jfree.chart.axis.ValueAxis var53 = var51.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var54 = var51.getRenderer();
//     java.awt.Paint var55 = var51.getDomainZeroBaselinePaint();
//     boolean var56 = var51.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D();
//     var58.setFixedDimension((-1.0d));
//     java.lang.Object var61 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var58);
//     org.jfree.chart.axis.NumberAxis3D var62 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var63 = var62.getLabelURL();
//     var62.setNegativeArrowVisible(false);
//     java.awt.Font var66 = var62.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var67 = null;
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot(var57, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var62, var67);
//     org.jfree.chart.axis.ValueAxis var70 = var68.getDomainAxis(100);
//     org.jfree.chart.util.Layer var72 = null;
//     java.util.Collection var73 = var68.getDomainMarkers((-1), var72);
//     org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var76 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var77 = var76.getPaint();
//     var75.setOutlinePaint(var77);
//     var68.setRangeGridlinePaint(var77);
//     org.jfree.chart.axis.AxisLocation var80 = var68.getDomainAxisLocation();
//     var51.setRangeAxisLocation(var80, false);
//     var29.setDomainAxisLocation(0, var80, true);
//     var11.setDomainAxisLocation(255, var80, false);
//     
//     // Checks the contract:  equals-hashcode on var51 and var11
//     assertTrue("Contract failed: equals-hashcode on var51 and var11", var51.equals(var11) ? var51.hashCode() == var11.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var51 and var11.", var51.equals(var11) == var11.equals(var51));
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer();
//     var14.clear();
//     var13.setWrapper(var14);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var23 = var22.getLabelURL();
//     var22.setNegativeArrowVisible(false);
//     java.awt.Font var26 = var22.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var34 = var33.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
//     var35.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var39 = var38.getLabelURL();
//     java.util.EventListener var40 = null;
//     boolean var41 = var38.hasListener(var40);
//     var38.setInverted(true);
//     java.awt.Paint var44 = var38.getAxisLinePaint();
//     var35.setTickMarkPaint(var44);
//     var33.setPaint(var44);
//     org.jfree.chart.util.Layer var47 = null;
//     var28.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var33, var47);
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var51 = var50.getStandardTickUnits();
//     java.awt.Font var52 = var50.getLabelFont();
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle("", var52);
//     java.lang.Object var54 = var53.clone();
//     org.jfree.chart.util.RectangleInsets var55 = var53.getPadding();
//     double var57 = var55.extendHeight(10.0d);
//     double var58 = var55.getTop();
//     boolean var59 = var28.equals((java.lang.Object)var55);
//     var13.setLegendItemGraphicPadding(var55);
//     
//     // Checks the contract:  equals-hashcode on var1 and var51
//     assertTrue("Contract failed: equals-hashcode on var1 and var51", var1.equals(var51) ? var1.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var1
//     assertTrue("Contract failed: equals-hashcode on var51 and var1", var51.equals(var1) ? var51.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var5.setInfo("");
    org.jfree.chart.ui.Library[] var8 = var5.getOptionalLibraries();
    java.lang.String var9 = var5.getName();
    var5.setName("ChartEntity: tooltip = ");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var3 = var2.getLabelURL();
    java.util.EventListener var4 = null;
    boolean var5 = var2.hasListener(var4);
    var2.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
    var9.setBackgroundAlpha(1.0f);
    java.awt.Stroke var12 = var9.getOutlineStroke();
    var2.setAxisLineStroke(var12);
    java.awt.Shape var14 = var2.getLeftArrow();
    var1.setRightArrow(var14);
    org.jfree.chart.axis.DateTickMarkPosition var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkPosition(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     java.awt.Font var4 = var2.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var7 = var6.getAlpha();
//     java.awt.Paint var8 = var6.getPaint();
//     org.jfree.chart.text.TextLine var9 = new org.jfree.chart.text.TextLine("", var4, var8);
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var12 = var11.getLabel();
//     java.lang.Object var13 = var11.clone();
//     java.awt.Paint var14 = var11.getPaint();
//     org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("XY Plot", var4, var14, 10.0f);
//     
//     // Checks the contract:  equals-hashcode on var6 and var11
//     assertTrue("Contract failed: equals-hashcode on var6 and var11", var6.equals(var11) ? var6.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var6
//     assertTrue("Contract failed: equals-hashcode on var11 and var6", var11.equals(var6) ? var11.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
//     var4.setText("hi!");
//     org.jfree.chart.util.RectangleEdge var9 = var4.getPosition();
//     org.jfree.chart.block.BlockFrame var10 = var4.getFrame();
//     java.lang.String var11 = var4.getURLText();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     var12.setFixedDimension((-1.0d));
//     java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var12);
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
//     java.awt.Font var22 = var20.getLabelFont();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var22);
//     java.awt.Paint var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var25);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.setWeight(100);
//     org.jfree.data.category.CategoryDataset var31 = var27.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var32 = var27.getDomainAxis();
//     java.awt.Paint var33 = var27.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("", var22, (org.jfree.chart.plot.Plot)var27, false);
//     boolean var36 = var35.getAntiAlias();
//     org.jfree.chart.event.ChartChangeEventType var37 = null;
//     org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var12, var35, var37);
//     var35.setBackgroundImageAlpha(0.8f);
//     var35.clearSubtitles();
//     var4.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var35);
//     
//     // Checks the contract:  equals-hashcode on var2 and var21
//     assertTrue("Contract failed: equals-hashcode on var2 and var21", var2.equals(var21) ? var2.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var2
//     assertTrue("Contract failed: equals-hashcode on var21 and var2", var21.equals(var2) ? var21.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
//     java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var19 = var18.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var22 = var21.getAlpha();
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
//     java.util.List var26 = var18.getAnnotations();
//     var11.drawRangeTickBands(var16, var17, var26);
//     org.jfree.chart.axis.AxisSpace var28 = null;
//     var11.setFixedRangeAxisSpace(var28);
//     int var30 = var11.getDomainAxisCount();
//     org.jfree.chart.axis.ValueAxis var32 = var11.getRangeAxis((-1));
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Point2D var35 = null;
//     var11.zoomRangeAxes(0.14d, var34, var35, true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("PieSection: -16777216, 100(XY Plot)", "Multiple Pie Plot", "WMAP_Plot", "Multiple Pie Plot");

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("WMAP_Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     java.awt.Font var10 = var8.getLabelFont();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
//     java.lang.Object var12 = var11.clone();
//     org.jfree.chart.block.BlockFrame var13 = var11.getFrame();
//     org.jfree.chart.event.TitleChangeListener var14 = null;
//     var11.removeChangeListener(var14);
//     java.awt.geom.Rectangle2D var16 = var11.getBounds();
//     org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var16, "", "");
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var5.valueToJava2D(1.0E-8d, var16, var20);
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var24 = var23.getStandardTickUnits();
//     java.awt.Font var25 = var23.getLabelFont();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var25);
//     java.lang.Object var27 = var26.clone();
//     org.jfree.chart.block.BlockFrame var28 = var26.getFrame();
//     org.jfree.chart.event.TitleChangeListener var29 = null;
//     var26.removeChangeListener(var29);
//     java.awt.geom.Rectangle2D var31 = var26.getBounds();
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     org.jfree.chart.axis.AxisState var34 = var1.draw(var2, 1.0E-5d, var16, var31, var32, var33);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    java.lang.String var17 = var11.getPlotType();
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var23 = var22.getStandardTickUnits();
    java.awt.Font var24 = var22.getLabelFont();
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var24);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var24);
    java.awt.Paint var27 = null;
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, var27);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    var29.setWeight(100);
    org.jfree.data.category.CategoryDataset var33 = var29.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var34 = var29.getDomainAxis();
    java.awt.Paint var35 = var29.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart("", var24, (org.jfree.chart.plot.Plot)var29, false);
    boolean var38 = var37.getAntiAlias();
    java.awt.Image var39 = null;
    var37.setBackgroundImage(var39);
    java.awt.Paint var41 = var37.getBackgroundPaint();
    var11.setRangeZeroBaselinePaint(var41);
    org.jfree.chart.axis.AxisSpace var43 = null;
    var11.setFixedDomainAxisSpace(var43, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "XY Plot"+ "'", var17.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("0,0,1,1");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.AxisState var3 = null;
//     org.jfree.chart.util.Size2D var4 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
//     java.awt.Font var9 = var7.getLabelFont();
//     var7.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot();
//     var12.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var15 = var12.getOutlineStroke();
//     var7.setPlot((org.jfree.chart.plot.Plot)var12);
//     java.awt.Image var17 = var12.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12, (org.jfree.chart.block.Arrangement)var18, var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var22 = var20.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var23 = org.jfree.chart.util.RectangleAnchor.createRectangle(var4, 92.0d, 92.0d, var22);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var26 = var25.getCategoryMargin();
//     var25.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var32 = var31.getAngleTickUnit();
//     var31.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
//     var31.setAxis((org.jfree.chart.axis.ValueAxis)var35);
//     var31.setNoDataMessage("hi!");
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var42 = var41.getStandardTickUnits();
//     java.awt.Font var43 = var41.getLabelFont();
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("", var43);
//     java.lang.Object var45 = var44.clone();
//     org.jfree.chart.block.BlockFrame var46 = var44.getFrame();
//     org.jfree.chart.event.TitleChangeListener var47 = null;
//     var44.removeChangeListener(var47);
//     java.awt.geom.Rectangle2D var49 = var44.getBounds();
//     java.awt.geom.Point2D var50 = null;
//     org.jfree.chart.plot.PlotState var51 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     var31.draw(var39, var49, var50, var51, var52);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.setWeight(100);
//     org.jfree.data.category.CategoryDataset var58 = var54.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var59 = var54.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var60 = var54.getRangeAxisEdge();
//     double var61 = var25.getCategoryStart(15, 10, var49, var60);
//     java.util.List var62 = var1.refreshTicks(var2, var3, var23, var60);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    var0.setLabelGap(0.0d);
    double var5 = var0.getExplodePercent((java.lang.Comparable)15);
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessageFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
//     java.awt.Font var7 = var5.getLabelFont();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setWeight(100);
//     org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
//     java.awt.Paint var18 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
//     boolean var21 = var20.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var22 = null;
//     var20.removeProgressListener(var22);
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
//     java.lang.Object var27 = var20.clone();
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var29 = var28.getStandardTickUnits();
//     java.awt.Font var30 = var28.getLabelFont();
//     var28.setLabel("");
//     java.lang.String var33 = var28.getLabel();
//     java.awt.Stroke var34 = var28.getAxisLineStroke();
//     var20.setBorderStroke(var34);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX((-1.0d));
    var0.setTranslateY(100.0d);
    boolean var5 = var0.getGenerateEntities();
    var0.setGenerateEntities(false);
    double var8 = var0.getTranslateX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var3.setAxisLineStroke(var13);
    java.awt.Shape var15 = var3.getLeftArrow();
    boolean var16 = var0.equals((java.lang.Object)var15);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.entity.PieSectionEntity var23 = new org.jfree.chart.entity.PieSectionEntity(var15, var17, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
    var23.setToolTipText("0,0,1,1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    var1.setAlpha(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var6 = var5.getAlpha();
//     java.awt.Paint var7 = var5.getPaint();
//     org.jfree.chart.text.TextLine var8 = new org.jfree.chart.text.TextLine("", var3, var7);
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     java.lang.Object var10 = var9.clone();
//     boolean var11 = var8.equals(var10);
//     org.jfree.chart.text.TextFragment var12 = var8.getFirstTextFragment();
//     org.jfree.chart.text.TextFragment var13 = var8.getLastTextFragment();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.util.Size2D var15 = var13.calculateDimensions(var14);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Category Plot", var1, var2);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(4);
    org.jfree.chart.plot.PieLabelRecord var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var29.setLabel("");
    org.jfree.chart.event.MarkerChangeEvent var32 = null;
    var29.notifyListeners(var32);
    var11.addDomainMarker((org.jfree.chart.plot.Marker)var29);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(2.2d);
    org.jfree.chart.util.Layer var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addDomainMarker((org.jfree.chart.plot.Marker)var36, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
//     var4.setText("hi!");
//     org.jfree.chart.util.RectangleEdge var9 = var4.getPosition();
//     org.jfree.chart.util.RectangleEdge var10 = var4.getPosition();
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
//     java.awt.Font var13 = var11.getLabelFont();
//     var11.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var16 = new org.jfree.chart.plot.MultiplePiePlot();
//     var16.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var19 = var16.getOutlineStroke();
//     var11.setPlot((org.jfree.chart.plot.Plot)var16);
//     java.awt.Image var21 = var16.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var23 = null;
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var22, var23);
//     org.jfree.chart.util.RectangleInsets var25 = var24.getLegendItemGraphicPadding();
//     org.jfree.chart.util.HorizontalAlignment var26 = var24.getHorizontalAlignment();
//     var4.setHorizontalAlignment(var26);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("VerticalAlignment.CENTER");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     java.util.Date var3 = var1.calculateLowestVisibleTickValue(var2);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var1.setLabel("");
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var6 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var7 = var6.getPaint();
//     var5.setOutlinePaint(var7);
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var11 = var10.getAlpha();
//     java.awt.Paint var12 = var10.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var13 = var10.getLabelOffsetType();
//     var5.setLabelOffsetType(var13);
//     var1.setLabelOffsetType(var13);
//     java.lang.Class var16 = null;
//     java.util.EventListener[] var17 = var1.getListeners(var16);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.text.TextLine var1 = null;
//     var0.addLine(var1);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     java.lang.Object var8 = var7.clone();
//     java.lang.String var9 = var7.getText();
//     org.jfree.chart.util.RectangleInsets var10 = var7.getPadding();
//     double var11 = var7.getContentYOffset();
//     double var12 = var7.getContentYOffset();
//     boolean var13 = var0.equals((java.lang.Object)var12);
//     org.jfree.chart.util.HorizontalAlignment var14 = var0.getLineAlignment();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
//     java.lang.Object var20 = var19.clone();
//     org.jfree.chart.util.VerticalAlignment var21 = var19.getVerticalAlignment();
//     java.lang.String var22 = var21.toString();
//     java.lang.String var23 = var21.toString();
//     org.jfree.chart.block.FlowArrangement var26 = new org.jfree.chart.block.FlowArrangement(var14, var21, (-0.18d), 92.0d);
//     
//     // Checks the contract:  equals-hashcode on var5 and var17
//     assertTrue("Contract failed: equals-hashcode on var5 and var17", var5.equals(var17) ? var5.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var5
//     assertTrue("Contract failed: equals-hashcode on var17 and var5", var17.equals(var5) ? var17.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    boolean var9 = var8.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var12 = var11.getAlpha();
    org.jfree.chart.util.Layer var13 = null;
    boolean var14 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var11, var13);
    org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
    var0.setRangeAxisLocation(var15, false);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var0.getRendererForDataset(var18);
    org.jfree.chart.LegendItemCollection var20 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var22 = var20.get((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.chart.plot.PiePlotState var3 = new org.jfree.chart.plot.PiePlotState(var2);
    java.awt.geom.Rectangle2D var4 = var3.getExplodedPieArea();
    double var5 = var3.getTotal();
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
    java.awt.Font var9 = var7.getLabelFont();
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var9);
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.block.BlockFrame var12 = var10.getFrame();
    org.jfree.chart.event.TitleChangeListener var13 = null;
    var10.removeChangeListener(var13);
    java.awt.geom.Rectangle2D var15 = var10.getBounds();
    var3.setLinkArea(var15);
    var1.setPieArea(var15);
    org.jfree.chart.plot.PlotRenderingInfo var18 = var1.getInfo();
    var1.setPieCenterY((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var8 = var4.equals((java.lang.Object)var7);
    java.lang.String var9 = var7.getLabelFormat();
    java.text.AttributedString var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setAttributedLabel((-16777216), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "hi!"+ "'", var9.equals("hi!"));

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     var5.setDataset(var11);
//     java.awt.Paint var13 = var5.getAggregatedItemsPaint();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var16 = var15.getAngleTickUnit();
//     var15.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     var15.setAxis((org.jfree.chart.axis.ValueAxis)var19);
//     var15.setNoDataMessage("hi!");
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var27);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.block.BlockFrame var30 = var28.getFrame();
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var28.removeChangeListener(var31);
//     java.awt.geom.Rectangle2D var33 = var28.getBounds();
//     java.awt.geom.Point2D var34 = null;
//     org.jfree.chart.plot.PlotState var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var15.draw(var23, var33, var34, var35, var36);
//     java.awt.geom.Point2D var38 = null;
//     org.jfree.chart.plot.PlotState var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     var5.draw(var14, var33, var38, var39, var40);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
//     java.awt.Font var17 = var15.getLabelFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var17);
//     java.lang.Object var19 = var18.clone();
//     java.lang.String var20 = var18.getText();
//     org.jfree.chart.util.RectangleInsets var21 = var18.getPadding();
//     double var22 = var18.getContentYOffset();
//     var18.setHeight(1.0E-5d);
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot();
//     boolean var26 = var25.getSectionOutlinesVisible();
//     var25.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var31 = var30.getStandardTickUnits();
//     java.awt.Font var32 = var30.getLabelFont();
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("", var32);
//     java.lang.Object var34 = var33.clone();
//     org.jfree.chart.block.BlockFrame var35 = var33.getFrame();
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var33.removeChangeListener(var36);
//     java.awt.geom.Rectangle2D var38 = var33.getBounds();
//     var25.setLegendItemShape((java.awt.Shape)var38);
//     boolean var40 = var25.getIgnoreZeroValues();
//     java.awt.Paint var41 = var25.getLabelPaint();
//     var11.add((org.jfree.chart.block.Block)var18, (java.lang.Object)var25);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var31
//     assertTrue("Contract failed: equals-hashcode on var1 and var31", var1.equals(var31) ? var1.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var31
//     assertTrue("Contract failed: equals-hashcode on var16 and var31", var16.equals(var31) ? var16.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var1
//     assertTrue("Contract failed: equals-hashcode on var31 and var1", var31.equals(var1) ? var31.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var16
//     assertTrue("Contract failed: equals-hashcode on var31 and var16", var31.equals(var16) ? var31.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("Category Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    var0.setNoDataMessage("hi!");
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setWeight(100);
    org.jfree.data.category.CategoryDataset var12 = var8.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var13 = var8.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var14 = var8.getDatasetRenderingOrder();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.setWeight(100);
    org.jfree.data.category.CategoryDataset var19 = var15.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var21 = var15.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
    java.awt.Font var26 = var24.getLabelFont();
    var23.setLabelFont(var26);
    java.util.List var28 = var15.getCategoriesForAxis(var23);
    org.jfree.chart.axis.CategoryAxis[] var29 = new org.jfree.chart.axis.CategoryAxis[] { var23};
    var8.setDomainAxes(var29);
    boolean var31 = var0.equals((java.lang.Object)var29);
    boolean var32 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedWidth(10.0d);
    org.jfree.data.Range var6 = var5.getWidthRange();
    double var7 = var5.getHeight();
    org.jfree.data.Range var8 = var5.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(short)1, 102.0d, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    var0.setLabelGap(0.0d);
    double var5 = var0.getExplodePercent((java.lang.Comparable)15);
    org.jfree.chart.labels.PieToolTipGenerator var6 = var0.getToolTipGenerator();
    org.jfree.chart.util.RectangleInsets var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelPadding(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
//     java.awt.Font var6 = var4.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setWeight(100);
//     org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
//     boolean var20 = var19.getAntiAlias();
//     java.awt.Image var21 = null;
//     var19.setBackgroundImage(var21);
//     org.jfree.chart.plot.Plot var23 = var19.getPlot();
//     org.jfree.chart.plot.CategoryPlot var24 = var19.getCategoryPlot();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     var25.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var30 = new org.jfree.chart.plot.MultiplePiePlot();
//     var30.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var33 = var30.getOutlineStroke();
//     var25.setPlot((org.jfree.chart.plot.Plot)var30);
//     java.awt.Image var35 = var30.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30, (org.jfree.chart.block.Arrangement)var36, var37);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var40 = var38.getLegendItemGraphicAnchor();
//     var19.addLegend(var38);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("PieSection: -16777216, 100(XY Plot)", var1, (-1.0d), 2.0f, 2.0f);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     boolean var5 = var0.isAxisLineVisible();
//     java.awt.Paint var6 = var0.getTickLabelPaint();
//     org.jfree.chart.axis.NumberTickUnit var7 = var0.getTickUnit();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
//     java.awt.Font var12 = var10.getLabelFont();
//     var9.setLabelFont(var12);
//     var0.setTickLabelFont(var12);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = null;
    var0.setLogo(var1);
    org.jfree.chart.ui.Library[] var3 = var0.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("WMAP_Plot");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.setWeight(100);
//     org.jfree.data.category.CategoryDataset var6 = var2.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var7 = var2.getDomainGridlinePosition();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.plot.PiePlotState var11 = new org.jfree.chart.plot.PiePlotState(var10);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.plot.PiePlotState var13 = new org.jfree.chart.plot.PiePlotState(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getExplodedPieArea();
//     double var15 = var13.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var18 = var17.getStandardTickUnits();
//     java.awt.Font var19 = var17.getLabelFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     java.lang.Object var21 = var20.clone();
//     org.jfree.chart.block.BlockFrame var22 = var20.getFrame();
//     org.jfree.chart.event.TitleChangeListener var23 = null;
//     var20.removeChangeListener(var23);
//     java.awt.geom.Rectangle2D var25 = var20.getBounds();
//     var13.setLinkArea(var25);
//     var11.setPieArea(var25);
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var29 = var28.getLabelURL();
//     java.util.EventListener var30 = null;
//     boolean var31 = var28.hasListener(var30);
//     var28.setInverted(true);
//     var28.setTickMarkOutsideLength((-1.0f));
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var38 = var37.getAngleTickUnit();
//     var37.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     var37.setAxis((org.jfree.chart.axis.ValueAxis)var41);
//     var37.setNoDataMessage("hi!");
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.axis.NumberAxis3D var47 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var48 = var47.getStandardTickUnits();
//     java.awt.Font var49 = var47.getLabelFont();
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("", var49);
//     java.lang.Object var51 = var50.clone();
//     org.jfree.chart.block.BlockFrame var52 = var50.getFrame();
//     org.jfree.chart.event.TitleChangeListener var53 = null;
//     var50.removeChangeListener(var53);
//     java.awt.geom.Rectangle2D var55 = var50.getBounds();
//     java.awt.geom.Point2D var56 = null;
//     org.jfree.chart.plot.PlotState var57 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var58 = null;
//     var37.draw(var45, var55, var56, var57, var58);
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     var60.setWeight(100);
//     org.jfree.data.category.CategoryDataset var64 = var60.getDataset(0);
//     var60.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var67 = var66.getLabelURL();
//     java.util.EventListener var68 = null;
//     boolean var69 = var66.hasListener(var68);
//     var66.setInverted(true);
//     java.awt.Paint var72 = var66.getAxisLinePaint();
//     org.jfree.data.Range var73 = var60.getDataRange((org.jfree.chart.axis.ValueAxis)var66);
//     org.jfree.chart.util.RectangleEdge var74 = var60.getDomainAxisEdge();
//     double var75 = var28.valueToJava2D(0.20000000000000018d, var55, var74);
//     double var76 = var1.getCategoryJava2DCoordinate(var7, 15, (-16777216), var25, var74);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var23 = var22.getLabelURL();
    var22.setNegativeArrowVisible(false);
    java.awt.Font var26 = var22.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
    org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var37 = var36.getPaint();
    var35.setOutlinePaint(var37);
    var28.setRangeGridlinePaint(var37);
    org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
    var11.setRangeAxisLocation(var40, false);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var45 = var44.getLabelURL();
    java.util.EventListener var46 = null;
    boolean var47 = var44.hasListener(var46);
    var44.setLabel("");
    boolean var50 = var44.isVerticalTickLabels();
    org.jfree.chart.axis.MarkerAxisBand var51 = null;
    var44.setMarkerBand(var51);
    var11.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var44);
    boolean var54 = var44.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setFixedDimension((-1.0d));
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
    java.awt.Font var10 = var8.getLabelFont();
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var10);
    java.awt.Paint var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.setWeight(100);
    org.jfree.data.category.CategoryDataset var19 = var15.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxis();
    java.awt.Paint var21 = var15.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", var10, (org.jfree.chart.plot.Plot)var15, false);
    boolean var24 = var23.getAntiAlias();
    org.jfree.chart.event.ChartChangeEventType var25 = null;
    org.jfree.chart.event.ChartChangeEvent var26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var23, var25);
    java.awt.Image var27 = var23.getBackgroundImage();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var29 = var23.getSubtitle(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var17 = var16.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     java.util.EventListener var23 = null;
//     boolean var24 = var21.hasListener(var23);
//     var21.setInverted(true);
//     java.awt.Paint var27 = var21.getAxisLinePaint();
//     var18.setTickMarkPaint(var27);
//     var16.setPaint(var27);
//     org.jfree.chart.util.Layer var30 = null;
//     var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
//     double var40 = var38.extendHeight(10.0d);
//     double var41 = var38.getTop();
//     boolean var42 = var11.equals((java.lang.Object)var38);
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var44 = var43.getLabelURL();
//     java.util.EventListener var45 = null;
//     boolean var46 = var43.hasListener(var45);
//     var43.setInverted(true);
//     var43.setTickMarkOutsideLength((-1.0f));
//     org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.setWeight(100);
//     org.jfree.data.category.CategoryDataset var56 = var52.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var57 = var52.getDomainAxis();
//     java.awt.Paint var58 = var52.getRangeCrosshairPaint();
//     org.jfree.chart.LegendItemCollection var59 = var52.getFixedLegendItems();
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var61 = var60.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var64 = var63.getAlpha();
//     org.jfree.chart.util.Layer var65 = null;
//     boolean var66 = var60.removeRangeMarker((org.jfree.chart.plot.Marker)var63, var65);
//     org.jfree.chart.axis.AxisLocation var67 = var60.getRangeAxisLocation();
//     var52.setRangeAxisLocation(var67, false);
//     org.jfree.data.category.CategoryDataset var70 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var71 = var52.getRendererForDataset(var70);
//     org.jfree.chart.LegendItemCollection var72 = var52.getLegendItems();
//     java.util.Iterator var73 = var72.iterator();
//     var11.setFixedLegendItems(var72);
//     
//     // Checks the contract:  equals-hashcode on var16 and var63
//     assertTrue("Contract failed: equals-hashcode on var16 and var63", var16.equals(var63) ? var16.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var16
//     assertTrue("Contract failed: equals-hashcode on var63 and var16", var63.equals(var16) ? var63.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    boolean var2 = var1.getSectionOutlinesVisible();
    java.awt.Paint var4 = null;
    var1.setSectionPaint((java.lang.Comparable)10, var4);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    var6.setLabel("");
    java.lang.String var11 = var6.getLabel();
    java.awt.Stroke var12 = var6.getAxisLineStroke();
    var1.setLabelOutlineStroke(var12);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setWeight(100);
    org.jfree.data.category.CategoryDataset var18 = var14.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var19 = var14.getDomainAxis();
    java.awt.Paint var20 = var14.getRangeCrosshairPaint();
    var1.setLabelPaint(var20);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var24 = var23.getAlpha();
    java.awt.Paint var25 = var23.getPaint();
    org.jfree.chart.util.LengthAdjustmentType var26 = var23.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var27 = null;
    var23.notifyListeners(var27);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var30 = var29.getLabelURL();
    java.util.EventListener var31 = null;
    boolean var32 = var29.hasListener(var31);
    var29.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var36 = new org.jfree.chart.plot.MultiplePiePlot();
    var36.setBackgroundAlpha(1.0f);
    java.awt.Stroke var39 = var36.getOutlineStroke();
    var29.setAxisLineStroke(var39);
    var23.setStroke(var39);
    var1.setBaseSectionOutlineStroke(var39);
    var0.setSeparatorStroke(var39);
    double var44 = var0.getSectionDepth();
    org.jfree.chart.urls.PieURLGenerator var45 = var0.getURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setCategoryMargin((-1.0d));
//     float var4 = var1.getMaximumCategoryLabelWidthRatio();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     var7.setFixedDimension((-1.0d));
//     java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var12 = var11.getLabelURL();
//     var11.setNegativeArrowVisible(false);
//     java.awt.Font var15 = var11.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var16);
//     org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis(100);
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var17.getDomainMarkers((-1), var21);
//     var17.setRangeZeroBaselineVisible(false);
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var17.setFixedDomainAxisSpace(var25);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     var28.setFixedDimension((-1.0d));
//     java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var28);
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var33 = var32.getLabelURL();
//     var32.setNegativeArrowVisible(false);
//     java.awt.Font var36 = var32.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var32, var37);
//     org.jfree.chart.axis.ValueAxis var40 = var38.getDomainAxis(100);
//     var38.clearRangeMarkers(15);
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     org.jfree.chart.plot.PiePlotState var45 = new org.jfree.chart.plot.PiePlotState(var44);
//     int var46 = var45.getPassesRequired();
//     double var47 = var45.getPieWRadius();
//     org.jfree.chart.plot.PiePlot var48 = new org.jfree.chart.plot.PiePlot();
//     boolean var49 = var48.getSectionOutlinesVisible();
//     var48.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var53 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var54 = var53.getStandardTickUnits();
//     java.awt.Font var55 = var53.getLabelFont();
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("", var55);
//     java.lang.Object var57 = var56.clone();
//     org.jfree.chart.block.BlockFrame var58 = var56.getFrame();
//     org.jfree.chart.event.TitleChangeListener var59 = null;
//     var56.removeChangeListener(var59);
//     java.awt.geom.Rectangle2D var61 = var56.getBounds();
//     var48.setLegendItemShape((java.awt.Shape)var61);
//     var45.setLinkArea(var61);
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     org.jfree.chart.plot.CrosshairState var66 = null;
//     boolean var67 = var38.render(var43, var61, 0, var65, var66);
//     org.jfree.chart.axis.NumberAxis3D var69 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var70 = var69.getStandardTickUnits();
//     java.awt.Font var71 = var69.getLabelFont();
//     org.jfree.chart.title.TextTitle var72 = new org.jfree.chart.title.TextTitle("", var71);
//     java.lang.Object var73 = var72.clone();
//     org.jfree.chart.block.BlockFrame var74 = var72.getFrame();
//     var72.setText("hi!");
//     org.jfree.chart.util.RectangleEdge var77 = var72.getPosition();
//     org.jfree.chart.axis.AxisSpace var78 = null;
//     org.jfree.chart.axis.AxisSpace var79 = var1.reserveSpace(var5, (org.jfree.chart.plot.Plot)var17, var61, var77, var78);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]", var1);
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("WMAP_Plot");
//     java.awt.Graphics2D var2 = null;
//     java.awt.Color var6 = java.awt.Color.getColor("hi!", (-16777216));
//     java.awt.image.ColorModel var7 = null;
//     java.awt.Rectangle var8 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var13 = var12.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
//     java.awt.Font var17 = var15.getLabelFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var17);
//     java.lang.Object var19 = var18.clone();
//     org.jfree.chart.block.BlockFrame var20 = var18.getFrame();
//     org.jfree.chart.event.TitleChangeListener var21 = null;
//     var18.removeChangeListener(var21);
//     java.awt.geom.Rectangle2D var23 = var18.getBounds();
//     var12.setUpArrow((java.awt.Shape)var23);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.setWeight(100);
//     org.jfree.data.category.CategoryDataset var29 = var25.getDataset(0);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = var25.getRendererForDataset(var30);
//     java.awt.Stroke var32 = var25.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var34 = var25.getRangeAxisEdge(100);
//     double var35 = var10.java2DToValue(0.2d, var23, var34);
//     java.awt.geom.AffineTransform var36 = null;
//     java.awt.RenderingHints var37 = null;
//     java.awt.PaintContext var38 = var6.createContext(var7, var8, var23, var36, var37);
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var44 = var43.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var47 = var46.getStandardTickUnits();
//     java.awt.Font var48 = var46.getLabelFont();
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle("", var48);
//     java.lang.Object var50 = var49.clone();
//     org.jfree.chart.block.BlockFrame var51 = var49.getFrame();
//     org.jfree.chart.event.TitleChangeListener var52 = null;
//     var49.removeChangeListener(var52);
//     java.awt.geom.Rectangle2D var54 = var49.getBounds();
//     var43.setUpArrow((java.awt.Shape)var54);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     var56.setWeight(100);
//     org.jfree.data.category.CategoryDataset var60 = var56.getDataset(0);
//     org.jfree.data.category.CategoryDataset var61 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = var56.getRendererForDataset(var61);
//     java.awt.Stroke var63 = var56.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var65 = var56.getRangeAxisEdge(100);
//     double var66 = var41.java2DToValue(0.2d, var54, var65);
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     org.jfree.chart.axis.AxisState var68 = var1.draw(var2, 1.0E-5d, (java.awt.geom.Rectangle2D)var8, var39, var65, var67);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var11.setFixedRangeAxisSpace(var28);
    int var30 = var11.getDomainAxisCount();
    org.jfree.chart.axis.ValueAxis var32 = var11.getRangeAxis((-1));
    org.jfree.chart.annotations.XYAnnotation var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     var1.setTickUnit(var2);
//     var1.configure();
//     java.text.DateFormat var5 = null;
//     var1.setDateFormatOverride(var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var10 = var9.getAngleTickUnit();
//     var9.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     var9.setAxis((org.jfree.chart.axis.ValueAxis)var13);
//     var9.setNoDataMessage("hi!");
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var20 = var19.getStandardTickUnits();
//     java.awt.Font var21 = var19.getLabelFont();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("", var21);
//     java.lang.Object var23 = var22.clone();
//     org.jfree.chart.block.BlockFrame var24 = var22.getFrame();
//     org.jfree.chart.event.TitleChangeListener var25 = null;
//     var22.removeChangeListener(var25);
//     java.awt.geom.Rectangle2D var27 = var22.getBounds();
//     java.awt.geom.Point2D var28 = null;
//     org.jfree.chart.plot.PlotState var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var9.draw(var17, var27, var28, var29, var30);
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.setWeight(100);
//     org.jfree.data.category.CategoryDataset var37 = var33.getDataset(0);
//     var33.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var40 = var39.getLabelURL();
//     java.util.EventListener var41 = null;
//     boolean var42 = var39.hasListener(var41);
//     var39.setInverted(true);
//     java.awt.Paint var45 = var39.getAxisLinePaint();
//     org.jfree.data.Range var46 = var33.getDataRange((org.jfree.chart.axis.ValueAxis)var39);
//     org.jfree.chart.util.RectangleEdge var47 = var33.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var48 = org.jfree.chart.util.RectangleEdge.opposite(var47);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     org.jfree.chart.axis.AxisState var50 = var1.draw(var7, 9.223372036854776E18d, var27, var32, var47, var49);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     java.util.List var2 = var1.getBlocks();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     var5.setFixedDimension((-1.0d));
//     java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var10 = var9.getLabelURL();
//     var9.setNegativeArrowVisible(false);
//     java.awt.Font var13 = var9.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis(100);
//     org.jfree.chart.util.Layer var19 = null;
//     java.util.Collection var20 = var15.getDomainMarkers((-1), var19);
//     org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var23 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var24 = var23.getPaint();
//     var22.setOutlinePaint(var24);
//     var15.setRangeGridlinePaint(var24);
//     org.jfree.chart.axis.AxisLocation var27 = var15.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var29 = var15.getRangeAxisForDataset(0);
//     java.awt.Paint var30 = var15.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var32 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var31};
//     var15.setRenderers(var32);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.chart.plot.PiePlotState var36 = new org.jfree.chart.plot.PiePlotState(var35);
//     java.awt.geom.Rectangle2D var37 = var36.getExplodedPieArea();
//     double var38 = var36.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var41 = var40.getStandardTickUnits();
//     java.awt.Font var42 = var40.getLabelFont();
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("", var42);
//     java.lang.Object var44 = var43.clone();
//     org.jfree.chart.block.BlockFrame var45 = var43.getFrame();
//     org.jfree.chart.event.TitleChangeListener var46 = null;
//     var43.removeChangeListener(var46);
//     java.awt.geom.Rectangle2D var48 = var43.getBounds();
//     var36.setLinkArea(var48);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     var15.drawAnnotations(var34, var48, var50);
//     var1.draw(var3, var48);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    var0.setLabelLinkMargin(10.0d);
    java.awt.Paint var7 = var0.getShadowPaint();
    java.awt.Paint var8 = var0.getBaseSectionPaint();
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var10 = var9.getAngleTickUnit();
    var0.setExplodePercent((java.lang.Comparable)var10, 102.0d);
    java.awt.Paint var13 = var0.getLabelOutlinePaint();
    java.lang.Comparable var14 = null;
    org.jfree.chart.util.Size2D var15 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var17 = var16.getLabelURL();
    java.util.EventListener var18 = null;
    boolean var19 = var16.hasListener(var18);
    var16.setInverted(true);
    java.awt.Paint var22 = var16.getAxisLinePaint();
    boolean var23 = var15.equals((java.lang.Object)var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSectionOutlinePaint(var14, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Stroke var2 = var0.getSectionOutlineStroke((java.lang.Comparable)(-1.0f));
    double var3 = var0.getMinimumArcAngleToDraw();
    boolean var4 = var0.getIgnoreZeroValues();
    java.awt.Stroke var5 = var0.getLabelLinkStroke();
    var0.setLabelLinkMargin(0.20000000000000018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    java.awt.Color var1 = java.awt.Color.getColor("0,0,1,1");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    double var6 = var4.getMaximumExplodePercent();
    var4.setSectionOutlinesVisible(false);
    var4.setLabelLinkMargin(10.0d);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    int var12 = var4.getPieIndex();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
    java.awt.Font var16 = var14.getLabelFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var21 = var17.equals((java.lang.Object)var20);
    var4.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
    java.lang.String var23 = var20.getLabelFormat();
    org.jfree.chart.ui.BasicProjectInfo var29 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var29.setInfo("");
    org.jfree.chart.ui.Library[] var32 = var29.getOptionalLibraries();
    boolean var33 = var20.equals((java.lang.Object)var29);
    java.lang.String var34 = var29.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "hi!"+ "'", var23.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + "hi!"+ "'", var34.equals("hi!"));

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("WMAP_Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     boolean var5 = var4.getSectionOutlinesVisible();
//     var4.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.block.BlockFrame var14 = var12.getFrame();
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var12.removeChangeListener(var15);
//     java.awt.geom.Rectangle2D var17 = var12.getBounds();
//     var4.setLegendItemShape((java.awt.Shape)var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     var20.setFixedDimension((-1.0d));
//     java.lang.Object var23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var25 = var24.getLabelURL();
//     var24.setNegativeArrowVisible(false);
//     java.awt.Font var28 = var24.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     org.jfree.chart.axis.ValueAxis var32 = var30.getDomainAxis(100);
//     org.jfree.chart.util.Layer var34 = null;
//     java.util.Collection var35 = var30.getDomainMarkers((-1), var34);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var38 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var39 = var38.getPaint();
//     var37.setOutlinePaint(var39);
//     var30.setRangeGridlinePaint(var39);
//     org.jfree.chart.axis.AxisLocation var42 = var30.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var44 = var30.getRangeAxisForDataset(0);
//     java.awt.Paint var45 = var30.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var47 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var46};
//     var30.setRenderers(var47);
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     org.jfree.chart.plot.PiePlotState var51 = new org.jfree.chart.plot.PiePlotState(var50);
//     java.awt.geom.Rectangle2D var52 = var51.getExplodedPieArea();
//     double var53 = var51.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var56 = var55.getStandardTickUnits();
//     java.awt.Font var57 = var55.getLabelFont();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle("", var57);
//     java.lang.Object var59 = var58.clone();
//     org.jfree.chart.block.BlockFrame var60 = var58.getFrame();
//     org.jfree.chart.event.TitleChangeListener var61 = null;
//     var58.removeChangeListener(var61);
//     java.awt.geom.Rectangle2D var63 = var58.getBounds();
//     var51.setLinkArea(var63);
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var30.drawAnnotations(var49, var63, var65);
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot();
//     var67.setWeight(100);
//     org.jfree.data.category.CategoryDataset var71 = var67.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var72 = var67.getDomainAxis();
//     org.jfree.chart.plot.DatasetRenderingOrder var73 = var67.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var74 = null;
//     var67.setRenderer(var74);
//     var67.setBackgroundAlpha(1.0f);
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     java.awt.geom.Point2D var80 = null;
//     var67.zoomRangeAxes(0.2d, var79, var80, true);
//     org.jfree.chart.util.RectangleEdge var84 = var67.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     org.jfree.chart.axis.AxisState var86 = var1.draw(var2, 0.0d, var17, var63, var84, var85);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = null;
    var0.setLogo(var1);
    java.awt.Image var3 = var0.getLogo();
    var0.setVersion("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setFixedDimension((-1.0d));
//     java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
//     java.awt.Font var10 = var8.getLabelFont();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var10);
//     java.awt.Paint var13 = null;
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.setWeight(100);
//     org.jfree.data.category.CategoryDataset var19 = var15.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxis();
//     java.awt.Paint var21 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", var10, (org.jfree.chart.plot.Plot)var15, false);
//     boolean var24 = var23.getAntiAlias();
//     org.jfree.chart.event.ChartChangeEventType var25 = null;
//     org.jfree.chart.event.ChartChangeEvent var26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var23, var25);
//     java.awt.Image var27 = var23.getBackgroundImage();
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
//     java.awt.Font var34 = var32.getLabelFont();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("", var34);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var34);
//     java.awt.Paint var37 = null;
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var34, var37);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.setWeight(100);
//     org.jfree.data.category.CategoryDataset var43 = var39.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var44 = var39.getDomainAxis();
//     java.awt.Paint var45 = var39.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("", var34, (org.jfree.chart.plot.Plot)var39, false);
//     boolean var48 = var47.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var49 = null;
//     var47.removeProgressListener(var49);
//     var47.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.LegendTitle var54 = var47.getLegend(100);
//     boolean var55 = var47.getAntiAlias();
//     java.awt.image.BufferedImage var58 = var47.createBufferedImage(15, 4);
//     var23.setBackgroundImage((java.awt.Image)var58);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var39
//     assertTrue("Contract failed: equals-hashcode on var15 and var39", var15.equals(var39) ? var15.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var15
//     assertTrue("Contract failed: equals-hashcode on var39 and var15", var39.equals(var15) ? var39.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var3 = var2.getPaint();
//     var1.setOutlinePaint(var3);
//     org.jfree.chart.JFreeChart var5 = null;
//     org.jfree.chart.event.ChartChangeEventType var6 = null;
//     org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var5, var6);
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var13 = var12.getStandardTickUnits();
//     java.awt.Font var14 = var12.getLabelFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("", var14);
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var14);
//     java.awt.Paint var17 = null;
//     org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var17);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.setWeight(100);
//     org.jfree.data.category.CategoryDataset var23 = var19.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var24 = var19.getDomainAxis();
//     java.awt.Paint var25 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var19, false);
//     boolean var28 = var27.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var29 = null;
//     var27.removeProgressListener(var29);
//     var27.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.LegendTitle var34 = var27.getLegend(100);
//     java.lang.Object var35 = var27.clone();
//     var7.setChart(var27);
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var39 = var38.getStandardTickUnits();
//     java.awt.Font var40 = var38.getLabelFont();
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("", var40);
//     java.lang.Object var42 = var41.clone();
//     org.jfree.chart.block.BlockFrame var43 = var41.getFrame();
//     var41.setText("hi!");
//     var27.addSubtitle((org.jfree.chart.title.Title)var41);
//     
//     // Checks the contract:  equals-hashcode on var13 and var39
//     assertTrue("Contract failed: equals-hashcode on var13 and var39", var13.equals(var39) ? var13.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var13
//     assertTrue("Contract failed: equals-hashcode on var39 and var13", var39.equals(var13) ? var39.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var28 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var27};
    var11.setRenderers(var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.PiePlotState var32 = new org.jfree.chart.plot.PiePlotState(var31);
    java.awt.geom.Rectangle2D var33 = var32.getExplodedPieArea();
    double var34 = var32.getTotal();
    org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var37 = var36.getStandardTickUnits();
    java.awt.Font var38 = var36.getLabelFont();
    org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("", var38);
    java.lang.Object var40 = var39.clone();
    org.jfree.chart.block.BlockFrame var41 = var39.getFrame();
    org.jfree.chart.event.TitleChangeListener var42 = null;
    var39.removeChangeListener(var42);
    java.awt.geom.Rectangle2D var44 = var39.getBounds();
    var32.setLinkArea(var44);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    var11.drawAnnotations(var30, var44, var46);
    org.jfree.chart.annotations.XYAnnotation var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    int var16 = var11.getWeight();
    int var17 = var11.getDatasetCount();
    var11.mapDatasetToDomainAxis((-16777216), (-1));
    java.awt.Paint var21 = var11.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.lang.String var6 = var4.getText();
//     org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
//     double var8 = var4.getContentYOffset();
//     double var9 = var4.getContentYOffset();
//     org.jfree.chart.event.TitleChangeListener var10 = null;
//     var4.removeChangeListener(var10);
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot();
//     boolean var13 = var12.getSectionOutlinesVisible();
//     var12.setPieIndex(0);
//     org.jfree.chart.plot.AbstractPieLabelDistributor var16 = var12.getLabelDistributor();
//     boolean var17 = var12.getLabelLinksVisible();
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var20 = var19.getAlpha();
//     java.awt.Paint var21 = var19.getPaint();
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot();
//     boolean var23 = var22.getSectionOutlinesVisible();
//     double var24 = var22.getMaximumExplodePercent();
//     var22.setSectionOutlinesVisible(false);
//     var22.setLabelLinkMargin(10.0d);
//     var19.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var22);
//     int var30 = var22.getPieIndex();
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
//     java.awt.Font var34 = var32.getLabelFont();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("", var34);
//     java.lang.Object var36 = var35.clone();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     boolean var39 = var35.equals((java.lang.Object)var38);
//     var22.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     java.lang.String var41 = var38.getLabelFormat();
//     var12.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var43 = var4.equals((java.lang.Object)var12);
//     
//     // Checks the contract:  equals-hashcode on var2 and var33
//     assertTrue("Contract failed: equals-hashcode on var2 and var33", var2.equals(var33) ? var2.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var2
//     assertTrue("Contract failed: equals-hashcode on var33 and var2", var33.equals(var2) ? var33.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.labels.PieSectionLabelGenerator var1 = var0.getLegendLabelToolTipGenerator();
    org.jfree.chart.labels.PieToolTipGenerator var2 = null;
    var0.setToolTipGenerator(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    var0.setBackgroundAlpha(1.0f);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    boolean var4 = var3.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var7 = var6.getAlpha();
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var3.removeRangeMarker((org.jfree.chart.plot.Marker)var6, var8);
    org.jfree.chart.axis.AxisLocation var10 = var3.getRangeAxisLocation();
    java.util.List var11 = var3.getAnnotations();
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
    java.awt.Font var15 = var13.getLabelFont();
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
    java.lang.Object var17 = var16.clone();
    org.jfree.chart.block.BlockFrame var18 = var16.getFrame();
    org.jfree.chart.util.RectangleInsets var19 = var16.getMargin();
    var3.setAxisOffset(var19);
    boolean var21 = var0.equals((java.lang.Object)var19);
    org.jfree.chart.util.RectangleInsets var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var22, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    boolean var2 = var0.isAutoRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAboutValue(104.0d, (-5.975d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Stroke var2 = var0.getSectionOutlineStroke((java.lang.Comparable)(-1.0f));
    double var3 = var0.getMinimumArcAngleToDraw();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var5 = var4.getLabelURL();
    var4.setNegativeArrowVisible(false);
    java.awt.Font var8 = var4.getTickLabelFont();
    var0.setLabelFont(var8);
    var0.setSimpleLabels(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     var0.setBackgroundAlpha(10.0f);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isNotify();
//     java.awt.RenderingHints var6 = null;
//     var4.setRenderingHints(var6);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(2.2d);
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.LegendItemSource[] var14 = var13.getSources();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var17 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var18 = var17.getPaint();
//     var16.setOutlinePaint(var18);
//     double var20 = var16.getValue();
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var22 = var21.getStandardTickUnits();
//     java.awt.Font var23 = var21.getLabelFont();
//     var21.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var26 = new org.jfree.chart.plot.MultiplePiePlot();
//     var26.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var29 = var26.getOutlineStroke();
//     var21.setPlot((org.jfree.chart.plot.Plot)var26);
//     java.awt.Image var31 = var26.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26, (org.jfree.chart.block.Arrangement)var32, var33);
//     org.jfree.chart.util.RectangleInsets var35 = var34.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var36 = var34.getLegendItemGraphicAnchor();
//     var16.setLabelAnchor(var36);
//     var13.setLegendItemGraphicLocation(var36);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var32
//     assertTrue("Contract failed: equals-hashcode on var11 and var32", var11.equals(var32) ? var11.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var11
//     assertTrue("Contract failed: equals-hashcode on var32 and var11", var32.equals(var11) ? var32.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var1 = var0.getLabelURL();
//     java.util.EventListener var2 = null;
//     boolean var3 = var0.hasListener(var2);
//     var0.setLabel("");
//     boolean var6 = var0.isVerticalTickLabels();
//     var0.setAutoRange(true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var13 = var12.getCategoryMargin();
//     var12.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var19 = var18.getAngleTickUnit();
//     var18.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setAxis((org.jfree.chart.axis.ValueAxis)var22);
//     var18.setNoDataMessage("hi!");
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var29 = var28.getStandardTickUnits();
//     java.awt.Font var30 = var28.getLabelFont();
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var30);
//     java.lang.Object var32 = var31.clone();
//     org.jfree.chart.block.BlockFrame var33 = var31.getFrame();
//     org.jfree.chart.event.TitleChangeListener var34 = null;
//     var31.removeChangeListener(var34);
//     java.awt.geom.Rectangle2D var36 = var31.getBounds();
//     java.awt.geom.Point2D var37 = null;
//     org.jfree.chart.plot.PlotState var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     var18.draw(var26, var36, var37, var38, var39);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.setWeight(100);
//     org.jfree.data.category.CategoryDataset var45 = var41.getDataset(0);
//     org.jfree.chart.axis.CategoryAnchor var46 = var41.getDomainGridlinePosition();
//     org.jfree.chart.util.RectangleEdge var47 = var41.getRangeAxisEdge();
//     double var48 = var12.getCategoryStart(15, 10, var36, var47);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var53 = var52.getLabel();
//     org.jfree.chart.util.Layer var54 = null;
//     var49.addRangeMarker(1, (org.jfree.chart.plot.Marker)var52, var54);
//     org.jfree.chart.LegendItemCollection var56 = var49.getLegendItems();
//     var49.setOutlineVisible(false);
//     org.jfree.chart.util.RectangleEdge var59 = var49.getDomainAxisEdge();
//     java.util.List var60 = var0.refreshTicks(var9, var10, var36, var59);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    var0.setIgnoreZeroValues(true);
    java.awt.Paint var4 = var0.getSectionPaint((java.lang.Comparable)' ');
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     var0.setBackgroundAlpha(10.0f);
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var0.zoomRangeAxes(100.0d, var7, var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", (-16777216));
//     java.awt.image.ColorModel var14 = null;
//     java.awt.Rectangle var15 = null;
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var20 = var19.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var23 = var22.getStandardTickUnits();
//     java.awt.Font var24 = var22.getLabelFont();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var24);
//     java.lang.Object var26 = var25.clone();
//     org.jfree.chart.block.BlockFrame var27 = var25.getFrame();
//     org.jfree.chart.event.TitleChangeListener var28 = null;
//     var25.removeChangeListener(var28);
//     java.awt.geom.Rectangle2D var30 = var25.getBounds();
//     var19.setUpArrow((java.awt.Shape)var30);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.setWeight(100);
//     org.jfree.data.category.CategoryDataset var36 = var32.getDataset(0);
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = var32.getRendererForDataset(var37);
//     java.awt.Stroke var39 = var32.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var41 = var32.getRangeAxisEdge(100);
//     double var42 = var17.java2DToValue(0.2d, var30, var41);
//     java.awt.geom.AffineTransform var43 = null;
//     java.awt.RenderingHints var44 = null;
//     java.awt.PaintContext var45 = var13.createContext(var14, var15, var30, var43, var44);
//     java.awt.geom.Point2D var46 = null;
//     org.jfree.chart.plot.PlotState var47 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     var0.draw(var10, (java.awt.geom.Rectangle2D)var15, var46, var47, var48);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
    java.awt.Font var35 = var33.getLabelFont();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
    double var40 = var38.extendHeight(10.0d);
    double var41 = var38.getTop();
    boolean var42 = var11.equals((java.lang.Object)var38);
    org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var44 = var43.getLabelURL();
    java.util.EventListener var45 = null;
    boolean var46 = var43.hasListener(var45);
    var43.setInverted(true);
    var43.setTickMarkOutsideLength((-1.0f));
    org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
    var43.setRangeAboutValue(0.2d, 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    var0.setMinimumArcAngleToDraw((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
    java.lang.Object var9 = var8.clone();
    org.jfree.chart.block.BlockFrame var10 = var8.getFrame();
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var8.removeChangeListener(var11);
    java.awt.geom.Rectangle2D var13 = var8.getBounds();
    var0.setLegendItemShape((java.awt.Shape)var13);
    java.awt.Shape var15 = var0.getLegendItemShape();
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseSectionPaint(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Polar Plot", var1, 10.0f, 0.0f, var4);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var3 = var2.getPaint();
    var1.setOutlinePaint(var3);
    org.jfree.chart.util.RectangleAnchor var5 = var1.getLabelAnchor();
    java.lang.String var6 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleAnchor.TOP_LEFT"+ "'", var6.equals("RectangleAnchor.TOP_LEFT"));

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     var0.clear();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
//     java.awt.Font var5 = var3.getLabelFont();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var5);
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.block.BlockFrame var8 = var6.getFrame();
//     org.jfree.chart.event.TitleChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var0.add((org.jfree.chart.block.Block)var6);
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var13 = var12.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
//     java.awt.Font var17 = var15.getLabelFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var17);
//     java.lang.Object var19 = var18.clone();
//     org.jfree.chart.block.BlockFrame var20 = var18.getFrame();
//     org.jfree.chart.event.TitleChangeListener var21 = null;
//     var18.removeChangeListener(var21);
//     java.awt.geom.Rectangle2D var23 = var18.getBounds();
//     var12.setUpArrow((java.awt.Shape)var23);
//     var6.setBounds(var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)12.0d, 1.05d, 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    int var2 = var1.getPassesRequired();
    double var3 = var1.getLatestAngle();
    var1.setPieCenterX(2.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     var3.setFixedDimension((-1.0d));
//     java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var8 = var7.getLabelURL();
//     var7.setNegativeArrowVisible(false);
//     java.awt.Font var11 = var7.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var7, var12);
//     org.jfree.data.Range var14 = var7.getDefaultAutoRange();
//     org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 90.0d);
//     var1.setRange(var14, true, true);
//     double var20 = var14.getLowerBound();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     var22.setFixedDimension((-1.0d));
//     java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var22);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var27 = var26.getLabelURL();
//     var26.setNegativeArrowVisible(false);
//     java.awt.Font var30 = var26.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var26, var31);
//     org.jfree.data.Range var33 = var26.getDefaultAutoRange();
//     org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, 90.0d);
//     double var36 = var33.getLength();
//     org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(var14, var33);
//     
//     // Checks the contract:  equals-hashcode on var13 and var32
//     assertTrue("Contract failed: equals-hashcode on var13 and var32", var13.equals(var32) ? var13.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var13
//     assertTrue("Contract failed: equals-hashcode on var32 and var13", var32.equals(var13) ? var32.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var16 = var15.getLabelURL();
//     java.util.EventListener var17 = null;
//     boolean var18 = var15.hasListener(var17);
//     var15.setLabel("");
//     boolean var21 = var15.isVerticalTickLabels();
//     var15.setAutoRange(true);
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var27);
//     var15.setTickLabelFont(var27);
//     var13.setItemFont(var27);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Polar Plot", var1);
// 
//   }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
//     org.jfree.chart.event.TitleChangeListener var7 = null;
//     var4.removeChangeListener(var7);
//     java.awt.geom.Rectangle2D var9 = var4.getBounds();
//     org.jfree.chart.entity.ChartEntity var12 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var9, "", "");
//     java.lang.String var13 = var12.getURLText();
//     java.lang.String var14 = var12.toString();
//     var12.setToolTipText("0,0,1,1");
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var18 = var17.getLabelURL();
//     var17.setNegativeArrowVisible(false);
//     java.awt.Font var21 = var17.getTickLabelFont();
//     java.lang.Object var22 = var17.clone();
//     var17.setRange(100.0d, 102.0d);
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var31 = var30.getStandardTickUnits();
//     java.awt.Font var32 = var30.getLabelFont();
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("", var32);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("", var32);
//     java.awt.Paint var35 = null;
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("", var32, var35);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     var37.setWeight(100);
//     org.jfree.data.category.CategoryDataset var41 = var37.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var42 = var37.getDomainAxis();
//     java.awt.Paint var43 = var37.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("", var32, (org.jfree.chart.plot.Plot)var37, false);
//     boolean var46 = var45.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var47 = null;
//     var45.removeProgressListener(var47);
//     var45.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.LegendTitle var52 = var45.getLegend(100);
//     java.lang.Object var53 = var45.clone();
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var55 = var54.getAngleTickUnit();
//     boolean var56 = var54.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var57 = null;
//     var54.setDataset(var57);
//     java.awt.Stroke var59 = var54.getRadiusGridlineStroke();
//     var45.setBorderStroke(var59);
//     org.jfree.chart.event.ChartProgressEvent var63 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100.0d, var45, 0, 1);
//     boolean var64 = var12.equals((java.lang.Object)var45);
//     
//     // Checks the contract:  equals-hashcode on var2 and var31
//     assertTrue("Contract failed: equals-hashcode on var2 and var31", var2.equals(var31) ? var2.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var2
//     assertTrue("Contract failed: equals-hashcode on var31 and var2", var31.equals(var2) ? var31.hashCode() == var2.hashCode() : true);
// 
//   }

}
