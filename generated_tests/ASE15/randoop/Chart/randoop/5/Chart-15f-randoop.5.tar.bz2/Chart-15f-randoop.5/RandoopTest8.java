
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    int var3 = var0.getWeight();
    org.jfree.chart.util.SortOrder var4 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var7.setValue((-1.0d));
    org.jfree.chart.util.RectangleInsets var10 = var7.getLabelOffset();
    org.jfree.chart.util.RectangleAnchor var11 = var7.getLabelAnchor();
    org.jfree.chart.util.LengthAdjustmentType var12 = var7.getLabelOffsetType();
    org.jfree.chart.util.RectangleInsets var13 = var7.getLabelOffset();
    org.jfree.chart.util.Layer var14 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var7, var14);
    var7.setAlpha(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var3.setAxisLineStroke(var13);
    java.awt.Shape var15 = var3.getLeftArrow();
    boolean var16 = var0.equals((java.lang.Object)var15);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.entity.PieSectionEntity var23 = new org.jfree.chart.entity.PieSectionEntity(var15, var17, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
    var23.setSectionKey((java.lang.Comparable)0.025d);
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var27 = var26.getLabelURL();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var30 = var29.getStandardTickUnits();
    java.awt.Font var31 = var29.getLabelFont();
    org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("", var31);
    java.lang.Object var33 = var32.clone();
    org.jfree.chart.block.BlockFrame var34 = var32.getFrame();
    org.jfree.chart.event.TitleChangeListener var35 = null;
    var32.removeChangeListener(var35);
    java.awt.geom.Rectangle2D var37 = var32.getBounds();
    var26.setUpArrow((java.awt.Shape)var37);
    var23.setArea((java.awt.Shape)var37);
    org.jfree.data.general.PieDataset var40 = null;
    org.jfree.chart.entity.PieSectionEntity var46 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var37, var40, 1, 4, (java.lang.Comparable)2.2d, "Range[0.0,1.0]", "java.awt.Color[r=0,g=0,b=0]");
    var46.setURLText("Multiple Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    java.awt.Paint var3 = null;
    var0.setSectionPaint((java.lang.Comparable)10, var3);
    java.awt.Paint var5 = var0.getBaseSectionOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    boolean var2 = var1.isEmpty();
    org.jfree.chart.block.BlockFrame var3 = var1.getFrame();
    var1.setMargin(1.0E-8d, 4.2953125d, 0.08305664062499996d, 0.0d);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
    java.awt.Font var13 = var11.getLabelFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var13);
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("", var13);
    var15.setToolTipText("");
    var15.setExpandToFitSpace(false);
    java.awt.Paint var20 = var15.getBackgroundPaint();
    var1.add((org.jfree.chart.block.Block)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.util.LengthAdjustmentType var4 = var1.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var5 = null;
    var1.notifyListeners(var5);
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var8 = var7.getLabelURL();
    java.util.EventListener var9 = null;
    boolean var10 = var7.hasListener(var9);
    var7.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    var14.setBackgroundAlpha(1.0f);
    java.awt.Stroke var17 = var14.getOutlineStroke();
    var7.setAxisLineStroke(var17);
    var1.setStroke(var17);
    org.jfree.chart.text.TextAnchor var20 = var1.getLabelTextAnchor();
    org.jfree.chart.util.LengthAdjustmentType var21 = var1.getLabelOffsetType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 6.00001d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    var5.setBackgroundImageAlpha(1.0f);
    var5.setBackgroundAlpha(0.8f);
    java.lang.Object var14 = null;
    boolean var15 = var5.equals(var14);
    org.jfree.chart.JFreeChart var16 = var5.getPieChart();
    java.lang.Comparable var17 = var5.getAggregatedItemsKey();
    java.awt.Stroke var18 = var5.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Other"+ "'", var17.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
    java.awt.Font var9 = var7.getLabelFont();
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("", var9);
    java.lang.Object var11 = var10.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var14 = var10.equals((java.lang.Object)var13);
    java.lang.String var15 = var13.getLabelFormat();
    java.text.NumberFormat var16 = var13.getPercentFormat();
    var4.setNumberFormatOverride(var16);
    var4.setAutoTickUnitSelection(false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "hi!"+ "'", var15.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.lang.String var1 = var0.getLabelURL();
    java.lang.String var2 = var0.getLabelURL();
    boolean var3 = var0.isInverted();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    var4.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
    var9.setBackgroundAlpha(1.0f);
    java.awt.Stroke var12 = var9.getOutlineStroke();
    var4.setPlot((org.jfree.chart.plot.Plot)var9);
    java.awt.Image var14 = var9.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9, (org.jfree.chart.block.Arrangement)var15, var16);
    org.jfree.chart.util.RectangleInsets var18 = var17.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleAnchor var19 = var17.getLegendItemGraphicAnchor();
    java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var17);
    java.awt.Paint var21 = var17.getBackgroundPaint();
    org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var23 = var22.getPaint();
    org.jfree.chart.util.RectangleInsets var24 = var22.getInsets();
    double var26 = var24.calculateLeftInset(0.2d);
    double var27 = var24.getLeft();
    var17.setItemLabelPadding(var24);
    org.jfree.chart.util.UnitType var29 = var24.getUnitType();
    double var31 = var24.calculateTopInset(0.2953124999999999d);
    var0.setTickLabelInsets(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(100.0d, var7, var8);
    var0.setNoDataMessage("PieSection: -16777216, 100(XY Plot)");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
    java.awt.Paint var28 = var11.getRangeGridlinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    var11.setRenderer(100, var30);
    org.jfree.chart.util.Layer var33 = null;
    java.util.Collection var34 = var11.getRangeMarkers(15, var33);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var38 = var37.getAngleTickUnit();
    boolean var39 = var37.isDomainZoomable();
    org.jfree.data.xy.XYDataset var40 = null;
    var37.setDataset(var40);
    boolean var42 = var37.isRangeZoomable();
    org.jfree.data.xy.XYDataset var43 = var37.getDataset();
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var47 = var46.getAngleTickUnit();
    var46.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D();
    var46.setAxis((org.jfree.chart.axis.ValueAxis)var50);
    var46.setNoDataMessage("hi!");
    org.jfree.data.xy.XYDataset var54 = var46.getDataset();
    org.jfree.chart.plot.PlotRenderingInfo var57 = null;
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D();
    var59.setFixedDimension((-1.0d));
    java.lang.Object var62 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var59);
    org.jfree.chart.axis.NumberAxis3D var63 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var64 = var63.getLabelURL();
    var63.setNegativeArrowVisible(false);
    java.awt.Font var67 = var63.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
    org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var58, (org.jfree.chart.axis.ValueAxis)var59, (org.jfree.chart.axis.ValueAxis)var63, var68);
    org.jfree.chart.axis.ValueAxis var71 = var69.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var72 = var69.getRenderer();
    java.awt.Paint var73 = var69.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var74 = null;
    java.awt.geom.Rectangle2D var75 = null;
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
    boolean var77 = var76.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var80 = var79.getAlpha();
    org.jfree.chart.util.Layer var81 = null;
    boolean var82 = var76.removeRangeMarker((org.jfree.chart.plot.Marker)var79, var81);
    org.jfree.chart.axis.AxisLocation var83 = var76.getRangeAxisLocation();
    java.util.List var84 = var76.getAnnotations();
    var69.drawRangeTickBands(var74, var75, var84);
    java.awt.Paint var86 = var69.getDomainZeroBaselinePaint();
    java.awt.geom.Point2D var87 = var69.getQuadrantOrigin();
    var46.zoomRangeAxes(0.05d, 90.0d, var57, var87);
    var37.zoomDomainAxes(92.0d, var45, var87);
    var11.zoomRangeAxes(0.0d, var36, var87);
    var11.clearDomainAxes();
    boolean var92 = var11.isRangeCrosshairVisible();
    var11.setRangeZeroBaselineVisible(true);
    org.jfree.chart.util.Layer var96 = null;
    java.util.Collection var97 = var11.getDomainMarkers((-104858), var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var97);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    var11.clearRangeMarkers(15);
    java.awt.Paint var16 = var11.getDomainCrosshairPaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = var11.getRenderer(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var11.setFixedRangeAxisSpace(var28);
    org.jfree.chart.axis.AxisSpace var30 = null;
    var11.setFixedRangeAxisSpace(var30);
    var11.setDomainZeroBaselineVisible(false);
    float var34 = var11.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0f);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.block.BlockFrame var16 = var13.getFrame();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setWeight(100);
    org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
    var17.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var24 = var23.getLabelURL();
    java.util.EventListener var25 = null;
    boolean var26 = var23.hasListener(var25);
    var23.setInverted(true);
    java.awt.Paint var29 = var23.getAxisLinePaint();
    org.jfree.data.Range var30 = var17.getDataRange((org.jfree.chart.axis.ValueAxis)var23);
    org.jfree.chart.util.RectangleEdge var31 = var17.getDomainAxisEdge();
    var17.setBackgroundAlpha(0.0f);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setWeight(100);
    org.jfree.data.category.CategoryDataset var38 = var34.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var39 = var34.getDomainAxis();
    java.awt.Paint var40 = var34.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var41 = var34.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    boolean var43 = var42.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var46 = var45.getAlpha();
    org.jfree.chart.util.Layer var47 = null;
    boolean var48 = var42.removeRangeMarker((org.jfree.chart.plot.Marker)var45, var47);
    org.jfree.chart.axis.AxisLocation var49 = var42.getRangeAxisLocation();
    var34.setRangeAxisLocation(var49, false);
    org.jfree.data.category.CategoryDataset var52 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = var34.getRendererForDataset(var52);
    org.jfree.chart.LegendItemCollection var54 = var34.getLegendItems();
    var17.setFixedLegendItems(var54);
    org.jfree.chart.util.RectangleEdge var57 = var17.getRangeAxisEdge(0);
    org.jfree.chart.LegendItemSource[] var58 = new org.jfree.chart.LegendItemSource[] { var17};
    var13.setSources(var58);
    org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var61 = var60.getNextFillPaint();
    boolean var62 = var13.equals((java.lang.Object)var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    var1.setInnerSeparatorExtension(1.0E-5d);
    boolean var4 = var1.getSeparatorsVisible();
    var1.setSectionDepth(2.0d);
    boolean var7 = var1.getSeparatorsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.lang.String var6 = var4.getText();
    org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
    double var8 = var4.getContentYOffset();
    double var9 = var4.getContentYOffset();
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var4.removeChangeListener(var10);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    var13.setFixedDimension((-1.0d));
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var18 = var17.getLabelURL();
    var17.setNegativeArrowVisible(false);
    java.awt.Font var21 = var17.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var17, var22);
    org.jfree.chart.axis.ValueAxis var25 = var23.getDomainAxis(100);
    org.jfree.chart.util.Layer var27 = null;
    java.util.Collection var28 = var23.getDomainMarkers((-1), var27);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var32 = var31.getPaint();
    var30.setOutlinePaint(var32);
    var23.setRangeGridlinePaint(var32);
    org.jfree.chart.axis.AxisLocation var35 = var23.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var37 = var23.getRangeAxisForDataset(0);
    java.awt.Paint var38 = var23.getDomainCrosshairPaint();
    java.awt.Stroke var39 = var23.getDomainCrosshairStroke();
    java.awt.Paint var40 = var23.getRangeGridlinePaint();
    var4.setBackgroundPaint(var40);
    java.lang.Object var42 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Set var2 = var0.keySet();
    boolean var4 = var0.containsKey("Category Plot");
    java.lang.Object[][] var5 = var0.getContents();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    double var16 = var14.calculateRightOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.0d);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    boolean var2 = var0.isDomainZoomable();
    org.jfree.data.xy.XYDataset var3 = null;
    var0.setDataset(var3);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    var5.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var5.setPlot((org.jfree.chart.plot.Plot)var10);
    java.awt.Image var15 = var10.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var17 = null;
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10, (org.jfree.chart.block.Arrangement)var16, var17);
    org.jfree.chart.util.RectangleInsets var19 = var18.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleAnchor var20 = var18.getLegendItemGraphicAnchor();
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    java.awt.Font var22 = var18.getItemFont();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    var24.setFixedDimension((-1.0d));
    java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var24);
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var29 = var28.getLabelURL();
    var28.setNegativeArrowVisible(false);
    java.awt.Font var32 = var28.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var28, var33);
    org.jfree.chart.axis.ValueAxis var36 = var34.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var38 = var34.getRangeAxis(0);
    int var39 = var34.getWeight();
    org.jfree.chart.plot.PlotOrientation var40 = var34.getOrientation();
    org.jfree.chart.axis.ValueAxis var41 = var34.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var43 = var34.getRangeAxisLocation((-16777216));
    org.jfree.chart.LegendItemSource[] var44 = new org.jfree.chart.LegendItemSource[] { var34};
    var18.setSources(var44);
    org.jfree.chart.util.RectangleInsets var46 = var18.getLegendItemGraphicPadding();
    var0.setInsets(var46);
    var0.setRadiusGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    java.util.EventListener var8 = null;
    boolean var9 = var6.hasListener(var8);
    var6.setInverted(true);
    java.awt.Paint var12 = var6.getAxisLinePaint();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
    boolean var15 = var0.isRangeZoomable();
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
    var17.setFixedDimension((-1.0d));
    java.lang.Object var20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var17);
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    var21.setNegativeArrowVisible(false);
    java.awt.Font var25 = var21.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var21, var26);
    org.jfree.chart.axis.ValueAxis var29 = var27.getDomainAxis(100);
    org.jfree.chart.util.Layer var31 = null;
    java.util.Collection var32 = var27.getDomainMarkers((-1), var31);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var35 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var36 = var35.getPaint();
    var34.setOutlinePaint(var36);
    var27.setRangeGridlinePaint(var36);
    org.jfree.chart.axis.AxisLocation var39 = var27.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var41 = var27.getRangeAxisForDataset(0);
    java.awt.Paint var42 = var27.getDomainCrosshairPaint();
    java.awt.Stroke var43 = var27.getDomainCrosshairStroke();
    java.awt.Paint var44 = var27.getRangeGridlinePaint();
    var0.setRangeGridlinePaint(var44);
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var47 = var46.getAngleTickUnit();
    boolean var48 = var46.isDomainZoomable();
    boolean var49 = var46.isRangeZoomable();
    org.jfree.data.general.DatasetChangeEvent var50 = null;
    var46.datasetChanged(var50);
    org.jfree.chart.axis.ValueAxis var52 = null;
    var46.setAxis(var52);
    org.jfree.chart.plot.PlotOrientation var54 = var46.getOrientation();
    var0.setOrientation(var54);
    org.jfree.chart.ui.Licences var56 = new org.jfree.chart.ui.Licences();
    boolean var57 = var54.equals((java.lang.Object)var56);
    java.lang.String var58 = var56.getLGPL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.block.BlockContainer var15 = var13.getItemContainer();
//     double var16 = var13.getWidth();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.util.Size2D var19 = var17.calculateDimensions(var18);
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var25 = var24.getPaint();
//     var23.setOutlinePaint(var25);
//     org.jfree.chart.util.RectangleAnchor var27 = var23.getLabelAnchor();
//     java.awt.geom.Rectangle2D var28 = org.jfree.chart.util.RectangleAnchor.createRectangle(var19, 0.05d, 0.0d, var27);
//     var13.setBounds(var28);
//     org.jfree.chart.util.RectangleInsets var30 = var13.getMargin();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var35 = var34.getLabelURL();
//     java.util.EventListener var36 = null;
//     boolean var37 = var34.hasListener(var36);
//     var34.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var41 = new org.jfree.chart.plot.MultiplePiePlot();
//     var41.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var44 = var41.getOutlineStroke();
//     var34.setAxisLineStroke(var44);
//     java.awt.Shape var46 = var34.getLeftArrow();
//     boolean var47 = var31.equals((java.lang.Object)var46);
//     boolean var48 = var31.isRangeGridlinesVisible();
//     var31.setRangeCrosshairVisible(false);
//     org.jfree.chart.util.RectangleEdge var51 = var31.getRangeAxisEdge();
//     java.lang.String var52 = var51.toString();
//     java.lang.String var53 = var51.toString();
//     var13.setLegendItemGraphicEdge(var51);
//     
//     // Checks the contract:  equals-hashcode on var5 and var41
//     assertTrue("Contract failed: equals-hashcode on var5 and var41", var5.equals(var41) ? var5.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var5
//     assertTrue("Contract failed: equals-hashcode on var41 and var5", var41.equals(var5) ? var41.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.zoomDomainAxes(102.0d, var6, var7, false);
    boolean var10 = var0.getDrawSharedDomainAxis();
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var0.zoomDomainAxes(90.0d, 1.0E-8d, var13, var14);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var21 = var20.getLabel();
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    var23.setFixedDimension((-1.0d));
    java.lang.Object var26 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var28 = var27.getLabelURL();
    var27.setNegativeArrowVisible(false);
    java.awt.Font var31 = var27.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var32);
    org.jfree.chart.axis.ValueAxis var35 = var33.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = var33.getRenderer();
    java.awt.Paint var37 = var33.getDomainZeroBaselinePaint();
    boolean var38 = var33.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
    var40.setFixedDimension((-1.0d));
    java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var40);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var45 = var44.getLabelURL();
    var44.setNegativeArrowVisible(false);
    java.awt.Font var48 = var44.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.axis.ValueAxis)var44, var49);
    org.jfree.chart.axis.ValueAxis var52 = var50.getDomainAxis(100);
    org.jfree.chart.util.Layer var54 = null;
    java.util.Collection var55 = var50.getDomainMarkers((-1), var54);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var58 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var59 = var58.getPaint();
    var57.setOutlinePaint(var59);
    var50.setRangeGridlinePaint(var59);
    org.jfree.chart.axis.AxisLocation var62 = var50.getDomainAxisLocation();
    var33.setRangeAxisLocation(var62, false);
    org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var67 = var66.getLabelURL();
    java.util.EventListener var68 = null;
    boolean var69 = var66.hasListener(var68);
    var66.setLabel("");
    boolean var72 = var66.isVerticalTickLabels();
    org.jfree.chart.axis.MarkerAxisBand var73 = null;
    var66.setMarkerBand(var73);
    var33.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var66);
    org.jfree.chart.util.RectangleInsets var76 = var33.getAxisOffset();
    var20.setLabelOffset(var76);
    org.jfree.chart.util.RectangleInsets var78 = var20.getLabelOffset();
    org.jfree.chart.util.Layer var79 = null;
    boolean var80 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var20, var79);
    org.jfree.data.general.DatasetChangeEvent var81 = null;
    var0.datasetChanged(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    boolean var7 = var0.render(var3, var4, 0, var6);
    var0.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var13.setCategoryMargin((-1.0d));
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setWeight(100);
    org.jfree.data.category.CategoryDataset var20 = var16.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var21 = var16.getDomainAxis();
    java.awt.Paint var22 = var16.getRangeCrosshairPaint();
    var13.setTickLabelPaint(var22);
    var0.setDomainAxis(0, var13);
    org.jfree.data.general.DatasetChangeEvent var25 = null;
    var0.datasetChanged(var25);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    var28.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var33 = var32.getCategoryMargin();
    var28.setDomainAxis(var32);
    var0.setDomainAxis(0, var32, true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var38 = var0.getRenderer((-8323073));
    var0.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    boolean var1 = var0.getSeparatorsVisible();
    double var2 = var0.getSectionDepth();
    double var3 = var0.getSectionDepth();
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var0.setLegendLabelURLGenerator(var4);
    java.awt.Stroke var6 = var0.getSeparatorStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    var0.setLabelLinkMargin(10.0d);
    java.awt.Paint var7 = var0.getShadowPaint();
    var0.setLabelLinksVisible(true);
    boolean var10 = var0.getLabelLinksVisible();
    boolean var11 = var0.getLabelLinksVisible();
    var0.setSectionOutlinesVisible(false);
    org.jfree.chart.LegendItemCollection var14 = var0.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var8 = var7.getLabelURL();
    java.util.EventListener var9 = null;
    boolean var10 = var7.hasListener(var9);
    var7.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
    var14.setBackgroundAlpha(1.0f);
    java.awt.Stroke var17 = var14.getOutlineStroke();
    var7.setAxisLineStroke(var17);
    java.awt.Shape var19 = var7.getLeftArrow();
    var6.setRightArrow(var19);
    java.lang.Object var21 = var6.clone();
    var6.configure();
    java.awt.Font var23 = var6.getTickLabelFont();
    org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
    boolean var25 = var24.getSectionOutlinesVisible();
    java.awt.Paint var27 = null;
    var24.setSectionPaint((java.lang.Comparable)10, var27);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var30 = var29.getStandardTickUnits();
    java.awt.Font var31 = var29.getLabelFont();
    var29.setLabel("");
    java.lang.String var34 = var29.getLabel();
    java.awt.Stroke var35 = var29.getAxisLineStroke();
    var24.setLabelOutlineStroke(var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.setWeight(100);
    org.jfree.data.category.CategoryDataset var41 = var37.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var42 = var37.getDomainAxis();
    java.awt.Paint var43 = var37.getRangeCrosshairPaint();
    var24.setLabelPaint(var43);
    org.jfree.chart.plot.AbstractPieLabelDistributor var45 = var24.getLabelDistributor();
    java.awt.Paint var46 = var24.getBaseSectionOutlinePaint();
    double var47 = var24.getMaximumLabelWidth();
    org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var50 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var51 = var50.getPaint();
    var49.setOutlinePaint(var51);
    var24.setLabelOutlinePaint(var51);
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", var23, (org.jfree.chart.plot.Plot)var24, true);
    java.awt.Paint var56 = var24.getLabelLinkPaint();
    org.jfree.chart.block.BlockBorder var57 = new org.jfree.chart.block.BlockBorder(0.0d, 0.08d, 0.08d, 2.2d, var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + ""+ "'", var34.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var9 = var8.getCategoryMargin();
    var0.setDomainAxis(var8);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = var0.getRenderer(100);
    org.jfree.chart.util.RectangleInsets var13 = var0.getAxisOffset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var0.setRenderer(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-16579837), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin((-1.0d));
    float var5 = var2.getMaximumCategoryLabelWidthRatio();
    var2.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var9 = var8.getLabelURL();
    java.util.EventListener var10 = null;
    boolean var11 = var8.hasListener(var10);
    var8.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var14 = null;
    var8.setMarkerBand(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var8, var16);
    var2.removeCategoryLabelToolTip((java.lang.Comparable)1.0f);
    java.awt.Stroke var20 = var2.getTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ChartChangeEventType.GENERAL", var1);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    var0.setPieIndex(0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var4 = var0.getLabelDistributor();
    boolean var5 = var0.getLabelLinksVisible();
    var0.zoom(0.0d);
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.setIgnoreZeroValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    var1.configure();
    java.util.Date var5 = var1.getMinimumDate();
    var1.zoomRange(0.05d, 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    double var6 = var4.getMaximumExplodePercent();
    var4.setSectionOutlinesVisible(false);
    var4.setLabelLinkMargin(10.0d);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    int var12 = var4.getPieIndex();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
    java.awt.Font var16 = var14.getLabelFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var21 = var17.equals((java.lang.Object)var20);
    var4.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
    java.awt.Paint var23 = var4.getShadowPaint();
    java.lang.String var24 = var4.getPlotType();
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot();
    boolean var26 = var25.getSectionOutlinesVisible();
    var25.setPieIndex(0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var29 = var25.getLabelDistributor();
    boolean var30 = var25.getLabelLinksVisible();
    var25.zoom(0.0d);
    double var33 = var25.getMaximumExplodePercent();
    org.jfree.chart.plot.AbstractPieLabelDistributor var34 = var25.getLabelDistributor();
    var34.clear();
    var4.setLabelDistributor(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Pie Plot"+ "'", var24.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    java.util.EventListener var2 = null;
    boolean var3 = var0.hasListener(var2);
    var0.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
    var7.setBackgroundAlpha(1.0f);
    java.awt.Stroke var10 = var7.getOutlineStroke();
    var0.setAxisLineStroke(var10);
    java.awt.Shape var12 = var0.getLeftArrow();
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    var14.setFixedDimension((-1.0d));
    java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var19 = var18.getLabelURL();
    var18.setNegativeArrowVisible(false);
    java.awt.Font var22 = var18.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var18, var23);
    org.jfree.data.Range var25 = var18.getDefaultAutoRange();
    org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 90.0d);
    var0.setRangeWithMargins(var25);
    boolean var29 = var0.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
    java.awt.Font var35 = var33.getLabelFont();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
    double var40 = var38.extendHeight(10.0d);
    double var41 = var38.getTop();
    boolean var42 = var11.equals((java.lang.Object)var38);
    org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var44 = var43.getLabelURL();
    java.util.EventListener var45 = null;
    boolean var46 = var43.hasListener(var45);
    var43.setInverted(true);
    var43.setTickMarkOutsideLength((-1.0f));
    org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
    org.jfree.data.xy.XYDataset var52 = null;
    int var53 = var11.indexOf(var52);
    org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
    var11.setRenderer(100, var55, true);
    org.jfree.data.xy.XYDataset var59 = var11.getDataset(255);
    org.jfree.chart.util.Layer var60 = null;
    java.util.Collection var61 = var11.getDomainMarkers(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var1.setValue((-1.0d));
    org.jfree.chart.util.RectangleInsets var4 = var1.getLabelOffset();
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    var6.setFixedDimension((-1.0d));
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var11 = var10.getLabelURL();
    var10.setNegativeArrowVisible(false);
    java.awt.Font var14 = var10.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var15);
    org.jfree.chart.axis.ValueAxis var18 = var16.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = var16.getRenderer();
    java.awt.Paint var20 = var16.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    boolean var24 = var23.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var27 = var26.getAlpha();
    org.jfree.chart.util.Layer var28 = null;
    boolean var29 = var23.removeRangeMarker((org.jfree.chart.plot.Marker)var26, var28);
    org.jfree.chart.axis.AxisLocation var30 = var23.getRangeAxisLocation();
    java.util.List var31 = var23.getAnnotations();
    var16.drawRangeTickBands(var21, var22, var31);
    int var33 = var16.getRangeAxisCount();
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var16);
    var16.clearRangeAxes();
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    org.jfree.chart.plot.PiePlotState var38 = new org.jfree.chart.plot.PiePlotState(var37);
    java.awt.geom.Rectangle2D var39 = var38.getExplodedPieArea();
    double var40 = var38.getTotal();
    org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var43 = var42.getStandardTickUnits();
    java.awt.Font var44 = var42.getLabelFont();
    org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("", var44);
    java.lang.Object var46 = var45.clone();
    org.jfree.chart.block.BlockFrame var47 = var45.getFrame();
    org.jfree.chart.event.TitleChangeListener var48 = null;
    var45.removeChangeListener(var48);
    java.awt.geom.Rectangle2D var50 = var45.getBounds();
    var38.setLinkArea(var50);
    org.jfree.chart.plot.PlotRenderingInfo var52 = null;
    var16.drawAnnotations(var36, var50, var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    java.awt.Paint var14 = var13.getBackgroundPaint();
    org.jfree.chart.block.BlockContainer var15 = var13.getItemContainer();
    var13.setMargin(2.0d, 0.14d, 100.0d, (-5.975d));
    org.jfree.chart.util.RectangleEdge var21 = var13.getLegendItemGraphicEdge();
    java.awt.Font var22 = var13.getItemFont();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.setWeight(100);
    org.jfree.data.category.CategoryDataset var27 = var23.getDataset(0);
    var23.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var30 = var29.getLabelURL();
    java.util.EventListener var31 = null;
    boolean var32 = var29.hasListener(var31);
    var29.setInverted(true);
    java.awt.Paint var35 = var29.getAxisLinePaint();
    org.jfree.data.Range var36 = var23.getDataRange((org.jfree.chart.axis.ValueAxis)var29);
    org.jfree.chart.util.RectangleEdge var37 = var23.getDomainAxisEdge();
    var13.setLegendItemGraphicEdge(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var4 = var3.getLabelURL();
//     java.util.EventListener var5 = null;
//     boolean var6 = var3.hasListener(var5);
//     var3.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
//     var10.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var13 = var10.getOutlineStroke();
//     var3.setAxisLineStroke(var13);
//     java.awt.Shape var15 = var3.getLeftArrow();
//     boolean var16 = var0.equals((java.lang.Object)var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.entity.PieSectionEntity var23 = new org.jfree.chart.entity.PieSectionEntity(var15, var17, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
//     var23.setSectionKey((java.lang.Comparable)0.025d);
//     var23.setSectionIndex(3);
//     org.jfree.chart.plot.PolarPlot var28 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var29 = var28.getAngleTickUnit();
//     boolean var30 = var28.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var31 = null;
//     var28.setDataset(var31);
//     boolean var33 = var23.equals((java.lang.Object)var28);
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var34 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var35 = null;
//     java.lang.String var36 = var23.getImageMapAreaTag(var34, var35);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.block.BlockContainer var15 = var13.getItemContainer();
    org.jfree.chart.util.RectangleInsets var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setLegendItemGraphicPadding(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
    java.awt.Font var35 = var33.getLabelFont();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
    double var40 = var38.extendHeight(10.0d);
    double var41 = var38.getTop();
    boolean var42 = var11.equals((java.lang.Object)var38);
    org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var44 = var43.getLabelURL();
    java.util.EventListener var45 = null;
    boolean var46 = var43.hasListener(var45);
    var43.setInverted(true);
    var43.setTickMarkOutsideLength((-1.0f));
    org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
    org.jfree.data.xy.XYDataset var52 = null;
    int var53 = var11.indexOf(var52);
    org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
    var11.setRenderer(100, var55, true);
    int var58 = var11.getSeriesCount();
    org.jfree.chart.axis.AxisSpace var59 = null;
    var11.setFixedDomainAxisSpace(var59);
    java.awt.Graphics2D var61 = null;
    java.awt.geom.Rectangle2D var62 = null;
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    org.jfree.chart.plot.CrosshairState var65 = null;
    boolean var66 = var11.render(var61, var62, 4, var64, var65);
    var11.clearDomainMarkers();
    var11.clearRangeMarkers();
    var11.setDomainCrosshairValue(0.2953124999999999d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    var2.setFixedDimension((-1.0d));
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    var6.setNegativeArrowVisible(false);
    java.awt.Font var10 = var6.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var11);
    org.jfree.chart.axis.ValueAxis var14 = var12.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = var12.getRenderer();
    java.awt.Paint var16 = var12.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    boolean var20 = var19.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var23 = var22.getAlpha();
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var19.removeRangeMarker((org.jfree.chart.plot.Marker)var22, var24);
    org.jfree.chart.axis.AxisLocation var26 = var19.getRangeAxisLocation();
    java.util.List var27 = var19.getAnnotations();
    var12.drawRangeTickBands(var17, var18, var27);
    java.awt.Paint var29 = var12.getDomainZeroBaselinePaint();
    boolean var30 = var12.isDomainCrosshairLockedOnData();
    java.awt.Color var33 = java.awt.Color.getColor("hi!", (-16777216));
    int var34 = var33.getAlpha();
    var12.setOutlinePaint((java.awt.Paint)var33);
    java.awt.Color var36 = java.awt.Color.getColor("Rotation.CLOCKWISE", var33);
    java.awt.Color var39 = java.awt.Color.getColor("hi!", (-16777216));
    java.awt.Color var40 = var39.brighter();
    int var41 = var40.getGreen();
    java.awt.color.ColorSpace var42 = var40.getColorSpace();
    org.jfree.data.xy.XYDataset var43 = null;
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    var44.setFixedDimension((-1.0d));
    java.lang.Object var47 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var44);
    org.jfree.chart.axis.NumberAxis3D var48 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var49 = var48.getLabelURL();
    var48.setNegativeArrowVisible(false);
    java.awt.Font var52 = var48.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
    org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var43, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.axis.ValueAxis)var48, var53);
    org.jfree.chart.axis.ValueAxis var56 = var54.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var57 = var54.getRenderer();
    java.awt.Paint var58 = var54.getDomainZeroBaselinePaint();
    boolean var59 = var40.equals((java.lang.Object)var54);
    java.awt.Color var62 = java.awt.Color.getColor("VerticalAlignment.CENTER", 0);
    int var63 = var62.getTransparency();
    float[] var64 = null;
    float[] var65 = var62.getRGBComponents(var64);
    org.jfree.chart.ChartColor var72 = new org.jfree.chart.ChartColor(15, 255, 10);
    java.awt.Color var75 = java.awt.Color.getColor("VerticalAlignment.CENTER", 0);
    int var76 = var75.getTransparency();
    float[] var77 = null;
    float[] var78 = var75.getRGBComponents(var77);
    float[] var79 = var72.getRGBColorComponents(var78);
    float[] var80 = java.awt.Color.RGBtoHSB(4, 0, 15, var78);
    float[] var81 = var62.getRGBComponents(var80);
    float[] var82 = var40.getRGBComponents(var81);
    float[] var83 = var36.getRGBComponents(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = var0.getRendererForDataset(var5);
    java.awt.Stroke var7 = var0.getDomainGridlineStroke();
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var0.datasetChanged(var8);
    org.jfree.chart.axis.ValueAxis var11 = var0.getRangeAxis(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     var0.setBackgroundAlpha(1.0f);
//     var0.setBackgroundImageAlignment(1);
//     java.lang.String var5 = var0.getPlotType();
//     org.jfree.chart.util.TableOrder var6 = var0.getDataExtractOrder();
//     org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
//     var7.setBackgroundAlpha(1.0f);
//     var7.setBackgroundImageAlignment(1);
//     org.jfree.chart.util.TableOrder var12 = var7.getDataExtractOrder();
//     var0.setDataExtractOrder(var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     boolean var1 = var0.getSectionOutlinesVisible();
//     double var2 = var0.getMaximumExplodePercent();
//     org.jfree.chart.util.RectangleInsets var3 = var0.getSimpleLabelOffset();
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var8 = var7.getStandardTickUnits();
//     java.awt.Font var9 = var7.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var12 = var11.getAlpha();
//     java.awt.Paint var13 = var11.getPaint();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("", var9, var13);
//     var5.setAggregatedItemsPaint(var13);
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var19 = var18.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     var20.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var24 = var23.getLabelURL();
//     java.util.EventListener var25 = null;
//     boolean var26 = var23.hasListener(var25);
//     var23.setInverted(true);
//     java.awt.Paint var29 = var23.getAxisLinePaint();
//     var20.setTickMarkPaint(var29);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var16, var18, (org.jfree.chart.axis.ValueAxis)var20, var31);
//     java.awt.Stroke var33 = var32.getRangeGridlineStroke();
//     java.awt.Paint var34 = null;
//     org.jfree.chart.plot.MultiplePiePlot var35 = new org.jfree.chart.plot.MultiplePiePlot();
//     var35.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var38 = var35.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(102.0d, var13, var33, var34, var38, 0.0f);
//     var0.setLabelOutlinePaint(var13);
//     double var42 = var0.getShadowXOffset();
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var44 = var43.getLabelURL();
//     var43.setNegativeArrowVisible(false);
//     java.awt.Font var47 = var43.getTickLabelFont();
//     java.lang.Object var48 = var43.clone();
//     var43.setRange(100.0d, 102.0d);
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var57 = var56.getStandardTickUnits();
//     java.awt.Font var58 = var56.getLabelFont();
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("", var58);
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("", var58);
//     java.awt.Paint var61 = null;
//     org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, var61);
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
//     var63.setWeight(100);
//     org.jfree.data.category.CategoryDataset var67 = var63.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var68 = var63.getDomainAxis();
//     java.awt.Paint var69 = var63.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var71 = new org.jfree.chart.JFreeChart("", var58, (org.jfree.chart.plot.Plot)var63, false);
//     boolean var72 = var71.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var73 = null;
//     var71.removeProgressListener(var73);
//     var71.setBackgroundImageAlpha(100.0f);
//     org.jfree.chart.title.LegendTitle var78 = var71.getLegend(100);
//     java.lang.Object var79 = var71.clone();
//     org.jfree.chart.plot.PolarPlot var80 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var81 = var80.getAngleTickUnit();
//     boolean var82 = var80.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var83 = null;
//     var80.setDataset(var83);
//     java.awt.Stroke var85 = var80.getRadiusGridlineStroke();
//     var71.setBorderStroke(var85);
//     org.jfree.chart.event.ChartProgressEvent var89 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100.0d, var71, 0, 1);
//     var71.setTextAntiAlias(false);
//     java.awt.Paint var92 = var71.getBorderPaint();
//     var0.setLabelBackgroundPaint(var92);
//     
//     // Checks the contract:  equals-hashcode on var8 and var57
//     assertTrue("Contract failed: equals-hashcode on var8 and var57", var8.equals(var57) ? var8.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var8
//     assertTrue("Contract failed: equals-hashcode on var57 and var8", var57.equals(var8) ? var57.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     var0.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var7 = var6.getLabelURL();
//     java.util.EventListener var8 = null;
//     boolean var9 = var6.hasListener(var8);
//     var6.setInverted(true);
//     java.awt.Paint var12 = var6.getAxisLinePaint();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
//     var6.centerRange(0.0d);
//     var6.setVerticalTickLabels(false);
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
//     java.awt.Font var20 = var18.getLabelFont();
//     var18.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var23 = new org.jfree.chart.plot.MultiplePiePlot();
//     var23.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var26 = var23.getOutlineStroke();
//     var18.setPlot((org.jfree.chart.plot.Plot)var23);
//     double var28 = var23.getLimit();
//     var6.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     java.lang.String var30 = var23.getNoDataMessage();
//     java.lang.String var31 = var23.getPlotType();
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
//     java.awt.Font var34 = var32.getLabelFont();
//     var32.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var37 = new org.jfree.chart.plot.MultiplePiePlot();
//     var37.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var40 = var37.getOutlineStroke();
//     var32.setPlot((org.jfree.chart.plot.Plot)var37);
//     java.awt.Image var42 = var37.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var43 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var44 = null;
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37, (org.jfree.chart.block.Arrangement)var43, var44);
//     var37.setAggregatedItemsKey((java.lang.Comparable)(short)100);
//     org.jfree.chart.util.TableOrder var48 = var37.getDataExtractOrder();
//     var23.setDataExtractOrder(var48);
//     
//     // Checks the contract:  equals-hashcode on var19 and var33
//     assertTrue("Contract failed: equals-hashcode on var19 and var33", var19.equals(var33) ? var19.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var19
//     assertTrue("Contract failed: equals-hashcode on var33 and var19", var33.equals(var19) ? var33.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicAnchor();
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
    org.jfree.chart.util.RectangleInsets var17 = var13.getMargin();
    var13.setID("RectangleConstraintType.RANGE");
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var24 = var23.getLabel();
    org.jfree.chart.util.Layer var25 = null;
    var20.addRangeMarker(1, (org.jfree.chart.plot.Marker)var23, var25);
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var29 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var30 = var29.getPaint();
    var28.setOutlinePaint(var30);
    org.jfree.chart.util.RectangleAnchor var32 = var28.getLabelAnchor();
    var23.setLabelAnchor(var32);
    var13.setLegendItemGraphicAnchor(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var5.setInfo("");
    var5.setName("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("0,0,1,1");
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getCategoryMargin();
//     var3.setCategoryLabelPositionOffset(0);
//     boolean var7 = var1.equals((java.lang.Object)var3);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     boolean var10 = var9.isNegativeArrowVisible();
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var14 = var13.getLabelURL();
//     java.util.EventListener var15 = null;
//     boolean var16 = var13.hasListener(var15);
//     var13.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var20 = new org.jfree.chart.plot.MultiplePiePlot();
//     var20.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var23 = var20.getOutlineStroke();
//     var13.setAxisLineStroke(var23);
//     java.awt.Shape var25 = var13.getLeftArrow();
//     var12.setRightArrow(var25);
//     java.lang.Object var27 = var12.clone();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.DateTickUnit var30 = null;
//     var29.setTickUnit(var30);
//     var29.configure();
//     java.util.Date var33 = var29.getMinimumDate();
//     var12.setMaximumDate(var33);
//     var9.setMinimumDate(var33);
//     var1.setMaximumDate(var33);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     var38.setFixedDimension((-1.0d));
//     java.lang.Object var41 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var38);
//     org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var43 = var42.getLabelURL();
//     var42.setNegativeArrowVisible(false);
//     java.awt.Font var46 = var42.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var42, var47);
//     org.jfree.data.Range var49 = var42.getDefaultAutoRange();
//     org.jfree.data.Range var50 = var42.getRange();
//     double var51 = var50.getLength();
//     double var52 = var50.getLowerBound();
//     org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(10.0d, 10.0d);
//     org.jfree.chart.block.RectangleConstraint var57 = var55.toFixedHeight(12.0d);
//     org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D("Category Plot");
//     org.jfree.data.Range var60 = var59.getRange();
//     org.jfree.chart.block.RectangleConstraint var61 = var57.toRangeHeight(var60);
//     org.jfree.chart.block.RectangleConstraint var62 = new org.jfree.chart.block.RectangleConstraint(var50, var60);
//     var1.setRange(var50, false, true);
//     org.jfree.chart.plot.PiePlot var66 = new org.jfree.chart.plot.PiePlot();
//     boolean var67 = var66.getSectionOutlinesVisible();
//     var66.setPieIndex(0);
//     org.jfree.chart.plot.AbstractPieLabelDistributor var70 = var66.getLabelDistributor();
//     boolean var71 = var66.getLabelLinksVisible();
//     var66.zoom(0.0d);
//     double var74 = var66.getMaximumExplodePercent();
//     boolean var75 = var50.equals((java.lang.Object)var66);
//     org.jfree.data.xy.XYDataset var76 = null;
//     org.jfree.chart.axis.NumberAxis3D var77 = new org.jfree.chart.axis.NumberAxis3D();
//     var77.setFixedDimension((-1.0d));
//     java.lang.Object var80 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var77);
//     org.jfree.chart.axis.NumberAxis3D var81 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var82 = var81.getLabelURL();
//     var81.setNegativeArrowVisible(false);
//     java.awt.Font var85 = var81.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var86 = null;
//     org.jfree.chart.plot.XYPlot var87 = new org.jfree.chart.plot.XYPlot(var76, (org.jfree.chart.axis.ValueAxis)var77, (org.jfree.chart.axis.ValueAxis)var81, var86);
//     org.jfree.data.Range var88 = var81.getDefaultAutoRange();
//     org.jfree.data.Range var89 = var81.getRange();
//     double var90 = var89.getLength();
//     boolean var92 = var89.contains(0.2d);
//     org.jfree.data.Range var93 = org.jfree.data.Range.combine(var50, var89);
//     
//     // Checks the contract:  equals-hashcode on var48 and var87
//     assertTrue("Contract failed: equals-hashcode on var48 and var87", var48.equals(var87) ? var48.hashCode() == var87.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var87 and var48
//     assertTrue("Contract failed: equals-hashcode on var87 and var48", var87.equals(var48) ? var87.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxisForDataset(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var1 = null;
//     java.awt.Paint[] var2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.StrokeMap var3 = new org.jfree.chart.StrokeMap();
//     boolean var5 = var3.containsKey((java.lang.Comparable)(short)(-1));
//     var3.clear();
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var9 = var8.getAngleTickUnit();
//     boolean var10 = var8.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var11 = null;
//     var8.setDataset(var11);
//     boolean var13 = var8.isRangeZoomable();
//     org.jfree.data.xy.XYDataset var14 = var8.getDataset();
//     java.awt.Stroke var15 = var8.getRadiusGridlineStroke();
//     var3.put((java.lang.Comparable)0.0f, var15);
//     java.awt.Stroke[] var17 = new java.awt.Stroke[] { var15};
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.setWeight(100);
//     org.jfree.data.category.CategoryDataset var22 = var18.getDataset(0);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = var18.getRendererForDataset(var23);
//     org.jfree.chart.util.RectangleEdge var25 = var18.getRangeAxisEdge();
//     var18.setBackgroundImageAlpha(0.5f);
//     var18.setRangeCrosshairValue((-1.0d));
//     org.jfree.chart.plot.MultiplePiePlot var31 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
//     java.awt.Font var35 = var33.getLabelFont();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var38 = var37.getAlpha();
//     java.awt.Paint var39 = var37.getPaint();
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("", var35, var39);
//     var31.setAggregatedItemsPaint(var39);
//     org.jfree.data.category.CategoryDataset var42 = null;
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var45 = var44.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D();
//     var46.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var50 = var49.getLabelURL();
//     java.util.EventListener var51 = null;
//     boolean var52 = var49.hasListener(var51);
//     var49.setInverted(true);
//     java.awt.Paint var55 = var49.getAxisLinePaint();
//     var46.setTickMarkPaint(var55);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var42, var44, (org.jfree.chart.axis.ValueAxis)var46, var57);
//     java.awt.Stroke var59 = var58.getRangeGridlineStroke();
//     java.awt.Paint var60 = null;
//     org.jfree.chart.plot.MultiplePiePlot var61 = new org.jfree.chart.plot.MultiplePiePlot();
//     var61.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var64 = var61.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(102.0d, var39, var59, var60, var64, 0.0f);
//     var18.setOutlineStroke(var64);
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var64};
//     java.awt.Shape[] var69 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var70 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var2, var17, var68, var69);
//     java.lang.Object var71 = var70.clone();
//     java.awt.Paint var72 = var70.getNextOutlinePaint();
//     java.awt.Stroke var73 = var70.getNextStroke();
//     java.awt.Paint var74 = var70.getNextPaint();
//     java.awt.Shape var75 = var70.getNextShape();
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    var4.setLabelFont(var7);
    var0.setDomainAxis(var4);
    var0.setDrawSharedDomainAxis(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)192.025d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
//     java.lang.String var7 = var4.getURLText();
//     java.lang.Object var8 = var4.clone();
//     var4.setWidth(10.0d);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var13 = var12.getMaximumDate();
//     java.text.DateFormat var14 = var12.getDateFormatOverride();
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var16.setLabel("");
//     org.jfree.chart.event.MarkerChangeEvent var19 = null;
//     var16.notifyListeners(var19);
//     java.awt.Stroke var21 = var16.getStroke();
//     var12.setAxisLineStroke(var21);
//     var12.setAxisLineVisible(true);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     var26.setFixedDimension((-1.0d));
//     java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var31 = var30.getLabelURL();
//     var30.setNegativeArrowVisible(false);
//     java.awt.Font var34 = var30.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.ValueAxis var38 = var36.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = var36.getRenderer();
//     java.awt.Paint var40 = var36.getDomainZeroBaselinePaint();
//     boolean var41 = var36.isDomainCrosshairLockedOnData();
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var44 = var43.getStandardTickUnits();
//     java.awt.Font var45 = var43.getLabelFont();
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("", var45);
//     java.lang.Object var47 = var46.clone();
//     org.jfree.chart.util.RectangleInsets var48 = var46.getPadding();
//     double var49 = var48.getBottom();
//     org.jfree.chart.util.UnitType var50 = var48.getUnitType();
//     var36.setAxisOffset(var48);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var55 = var54.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D();
//     var56.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var60 = var59.getLabelURL();
//     java.util.EventListener var61 = null;
//     boolean var62 = var59.hasListener(var61);
//     var59.setInverted(true);
//     java.awt.Paint var65 = var59.getAxisLinePaint();
//     var56.setTickMarkPaint(var65);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var67 = null;
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot(var52, var54, (org.jfree.chart.axis.ValueAxis)var56, var67);
//     java.awt.Stroke var69 = var68.getRangeGridlineStroke();
//     org.jfree.chart.axis.AxisLocation var71 = var68.getRangeAxisLocation(100);
//     var36.setDomainAxisLocation(var71);
//     org.jfree.chart.plot.SeriesRenderingOrder var73 = var36.getSeriesRenderingOrder();
//     java.awt.Paint var74 = var36.getBackgroundPaint();
//     var12.setTickLabelPaint(var74);
//     var4.setPaint(var74);
//     
//     // Checks the contract:  equals-hashcode on var2 and var44
//     assertTrue("Contract failed: equals-hashcode on var2 and var44", var2.equals(var44) ? var2.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var2
//     assertTrue("Contract failed: equals-hashcode on var44 and var2", var44.equals(var2) ? var44.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.lang.String var6 = var4.getText();
    org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
    java.lang.Object var8 = var4.clone();
    var4.setExpandToFitSpace(true);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var12 = var11.getLabelURL();
    var11.setNegativeArrowVisible(false);
    java.awt.Font var15 = var11.getTickLabelFont();
    java.lang.Object var16 = var11.clone();
    var11.setRange(100.0d, 102.0d);
    var11.setLowerMargin(0.20000000000000018d);
    java.awt.Font var22 = var11.getTickLabelFont();
    var4.setFont(var22);
    var4.setExpandToFitSpace(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    int var2 = var1.getPassesRequired();
    double var3 = var1.getLatestAngle();
    org.jfree.chart.plot.PlotRenderingInfo var4 = var1.getInfo();
    org.jfree.chart.block.LineBorder var5 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
    java.awt.Font var12 = var10.getLabelFont();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var12);
    java.awt.Paint var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setWeight(100);
    org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var22 = var17.getDomainAxis();
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("", var12, (org.jfree.chart.plot.Plot)var17, false);
    boolean var26 = var25.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var27 = null;
    var25.removeProgressListener(var27);
    org.jfree.chart.event.ChartProgressEvent var31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var25, (-16777216), 15);
    org.jfree.chart.plot.CategoryPlot var32 = var25.getCategoryPlot();
    java.awt.Image var33 = var25.getBackgroundImage();
    java.awt.Color var37 = java.awt.Color.getHSBColor(10.0f, 0.8f, 2.0f);
    var25.setBorderPaint((java.awt.Paint)var37);
    int var39 = var37.getRGB();
    java.awt.image.ColorModel var40 = null;
    java.awt.Rectangle var41 = null;
    org.jfree.chart.block.BlockContainer var42 = new org.jfree.chart.block.BlockContainer();
    var42.clear();
    double var44 = var42.getContentXOffset();
    java.awt.geom.Rectangle2D var45 = var42.getBounds();
    java.awt.geom.AffineTransform var46 = null;
    java.awt.RenderingHints var47 = null;
    java.awt.PaintContext var48 = var37.createContext(var40, var41, var45, var46, var47);
    var1.setPieArea((java.awt.geom.Rectangle2D)var41);
    double var50 = var1.getLatestAngle();
    int var51 = var1.getPassesRequired();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-104858));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, 100.0d);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
    java.awt.Font var5 = var3.getLabelFont();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    var7.setFixedDimension((-1.0d));
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var12 = var11.getLabelURL();
    var11.setNegativeArrowVisible(false);
    java.awt.Font var15 = var11.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var16);
    org.jfree.data.Range var18 = var11.getDefaultAutoRange();
    org.jfree.data.Range var20 = org.jfree.data.Range.expandToInclude(var18, 90.0d);
    double var21 = var18.getLength();
    var3.setRangeWithMargins(var18);
    org.jfree.chart.block.RectangleConstraint var23 = var2.toRangeWidth(var18);
    org.jfree.chart.block.LengthConstraintType var24 = var23.getWidthConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("Polar Plot");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.setWeight(100);
    org.jfree.data.category.CategoryDataset var6 = var2.getDataset(0);
    org.jfree.chart.axis.CategoryAnchor var7 = var2.getDomainGridlinePosition();
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var2.zoomRangeAxes(0.08d, 1.0E-5d, var10, var11);
    org.jfree.chart.axis.AxisSpace var13 = null;
    var2.setFixedDomainAxisSpace(var13);
    java.util.List var15 = var2.getAnnotations();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var2);
    var1.setPositiveArrowVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    float var23 = var19.getBackgroundImageAlpha();
    var19.setAntiAlias(false);
    var19.setTextAntiAlias(true);
    org.jfree.chart.plot.Plot var28 = var19.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(15);
    var1.clear();
    org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var5 = var4.getAngleTickUnit();
    boolean var6 = var4.isDomainZoomable();
    org.jfree.data.xy.XYDataset var7 = null;
    var4.setDataset(var7);
    java.awt.Stroke var9 = var4.getRadiusGridlineStroke();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    var13.setFixedDimension((-1.0d));
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var18 = var17.getLabelURL();
    var17.setNegativeArrowVisible(false);
    java.awt.Font var21 = var17.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var17, var22);
    org.jfree.chart.axis.ValueAxis var25 = var23.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = var23.getRenderer();
    java.awt.Paint var27 = var23.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    boolean var31 = var30.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var34 = var33.getAlpha();
    org.jfree.chart.util.Layer var35 = null;
    boolean var36 = var30.removeRangeMarker((org.jfree.chart.plot.Marker)var33, var35);
    org.jfree.chart.axis.AxisLocation var37 = var30.getRangeAxisLocation();
    java.util.List var38 = var30.getAnnotations();
    var23.drawRangeTickBands(var28, var29, var38);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var23.setFixedRangeAxisSpace(var40);
    org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var44 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var45 = var44.getPaint();
    var43.setOutlinePaint(var45);
    org.jfree.chart.JFreeChart var47 = null;
    org.jfree.chart.event.ChartChangeEventType var48 = null;
    org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var43, var47, var48);
    java.lang.String var50 = var49.toString();
    org.jfree.chart.event.ChartChangeEventType var51 = null;
    var49.setType(var51);
    org.jfree.chart.axis.NumberAxis3D var53 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var54 = var53.getStandardTickUnits();
    java.awt.Font var55 = var53.getLabelFont();
    var53.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var58 = new org.jfree.chart.plot.MultiplePiePlot();
    var58.setBackgroundAlpha(1.0f);
    java.awt.Stroke var61 = var58.getOutlineStroke();
    var53.setPlot((org.jfree.chart.plot.Plot)var58);
    var58.setBackgroundImageAlpha(1.0f);
    var58.setBackgroundAlpha(0.8f);
    java.lang.Object var67 = null;
    boolean var68 = var58.equals(var67);
    org.jfree.chart.JFreeChart var69 = var58.getPieChart();
    var49.setChart(var69);
    org.jfree.chart.event.ChartProgressEvent var73 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var23, var69, 15, 1);
    java.awt.geom.Point2D var74 = var23.getQuadrantOrigin();
    var4.zoomDomainAxes(0.025d, var11, var74, true);
    var1.set(4, (java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    var0.setAnchorValue(0.0d, false);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    boolean var10 = var9.getSectionOutlinesVisible();
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    var12.setFixedDimension((-1.0d));
    java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var12);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var17 = var16.getLabelURL();
    var16.setNegativeArrowVisible(false);
    java.awt.Font var20 = var16.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var16, var21);
    org.jfree.chart.axis.ValueAxis var24 = var22.getDomainAxis(100);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var22.getDomainMarkers((-1), var26);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var30 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var31 = var30.getPaint();
    var29.setOutlinePaint(var31);
    var22.setRangeGridlinePaint(var31);
    var9.setLabelLinkPaint(var31);
    var8.setTickMarkPaint(var31);
    var0.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.SortOrder var37 = var0.getRowRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(28.687499999999993d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var2 = var1.getMaximumDate();
    var1.zoomRange(0.025d, 2.2d);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    var6.setAutoRange(false);
    org.jfree.chart.axis.DateTickUnit var9 = var6.getTickUnit();
    var1.setTickUnit(var9);
    var1.resizeRange(10.0d, 0.0d);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var17 = null;
    var16.setTickUnit(var17);
    java.text.DateFormat var19 = null;
    var16.setDateFormatOverride(var19);
    java.util.TimeZone var21 = var16.getTimeZone();
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("LengthConstraintType.FIXED", var21);
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var25 = null;
    var24.setTickUnit(var25);
    var24.configure();
    java.util.Date var28 = var24.getMinimumDate();
    java.util.TimeZone var29 = var24.getTimeZone();
    var22.setTimeZone(var29);
    org.jfree.chart.axis.TickUnitSource var31 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var29);
    var1.setTimeZone(var29);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    var33.setWeight(100);
    org.jfree.data.category.CategoryDataset var37 = var33.getDataset(0);
    var33.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var40 = var39.getLabelURL();
    java.util.EventListener var41 = null;
    boolean var42 = var39.hasListener(var41);
    var39.setInverted(true);
    java.awt.Paint var45 = var39.getAxisLinePaint();
    org.jfree.data.Range var46 = var33.getDataRange((org.jfree.chart.axis.ValueAxis)var39);
    org.jfree.chart.util.RectangleEdge var47 = var33.getDomainAxisEdge();
    boolean var48 = var33.isRangeZoomable();
    org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var51 = null;
    var50.setTickUnit(var51);
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var56 = var55.getLabelURL();
    java.util.EventListener var57 = null;
    boolean var58 = var55.hasListener(var57);
    var55.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var62 = new org.jfree.chart.plot.MultiplePiePlot();
    var62.setBackgroundAlpha(1.0f);
    java.awt.Stroke var65 = var62.getOutlineStroke();
    var55.setAxisLineStroke(var65);
    java.awt.Shape var67 = var55.getLeftArrow();
    var54.setRightArrow(var67);
    java.lang.Object var69 = var54.clone();
    org.jfree.chart.axis.DateAxis var71 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var72 = null;
    var71.setTickUnit(var72);
    var71.configure();
    java.util.Date var75 = var71.getMinimumDate();
    var54.setMaximumDate(var75);
    var50.setMaximumDate(var75);
    boolean var78 = var33.equals((java.lang.Object)var50);
    org.jfree.chart.axis.DateTickMarkPosition var79 = var50.getTickMarkPosition();
    var1.setTickMarkPosition(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSimpleLabels(false);
    java.awt.Paint var6 = var0.getSectionOutlinePaint((java.lang.Comparable)90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = var0.getRendererForDataset(var5);
//     org.jfree.chart.util.RectangleEdge var7 = var0.getRangeAxisEdge();
//     org.jfree.chart.util.RectangleInsets var8 = var0.getAxisOffset();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.setAnchorValue(10.0d, false);
//     java.lang.Object var13 = var9.clone();
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var18 = var17.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     var19.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var23 = var22.getLabelURL();
//     java.util.EventListener var24 = null;
//     boolean var25 = var22.hasListener(var24);
//     var22.setInverted(true);
//     java.awt.Paint var28 = var22.getAxisLinePaint();
//     var19.setTickMarkPaint(var28);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var15, var17, (org.jfree.chart.axis.ValueAxis)var19, var30);
//     var9.setDomainAxis(255, var17, true);
//     org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder();
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var40 = var39.getStandardTickUnits();
//     java.awt.Font var41 = var39.getLabelFont();
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("", var41);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("", var41);
//     java.awt.Paint var44 = null;
//     org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var41, var44);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     var46.setWeight(100);
//     org.jfree.data.category.CategoryDataset var50 = var46.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var51 = var46.getDomainAxis();
//     java.awt.Paint var52 = var46.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("", var41, (org.jfree.chart.plot.Plot)var46, false);
//     boolean var55 = var54.getAntiAlias();
//     org.jfree.chart.event.ChartProgressListener var56 = null;
//     var54.removeProgressListener(var56);
//     var54.setBackgroundImageAlpha(100.0f);
//     var54.removeLegend();
//     org.jfree.chart.event.ChartChangeEvent var61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var34, var54);
//     java.awt.Stroke var62 = var34.getStroke();
//     var9.setRangeGridlineStroke(var62);
//     org.jfree.data.category.CategoryDataset var64 = null;
//     org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var66.setCategoryMargin((-1.0d));
//     float var69 = var66.getMaximumCategoryLabelWidthRatio();
//     var66.setMaximumCategoryLabelWidthRatio(1.0f);
//     org.jfree.chart.axis.NumberAxis3D var72 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var73 = var72.getLabelURL();
//     java.util.EventListener var74 = null;
//     boolean var75 = var72.hasListener(var74);
//     var72.setLabel("");
//     org.jfree.chart.axis.MarkerAxisBand var78 = null;
//     var72.setMarkerBand(var78);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var80 = null;
//     org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot(var64, var66, (org.jfree.chart.axis.ValueAxis)var72, var80);
//     java.awt.Font var82 = var66.getTickLabelFont();
//     boolean var83 = var66.isAxisLineVisible();
//     int var84 = var66.getCategoryLabelPositionOffset();
//     var9.setDomainAxis(var66);
//     int var86 = var0.getDomainAxisIndex(var66);
//     
//     // Checks the contract:  equals-hashcode on var0 and var46
//     assertTrue("Contract failed: equals-hashcode on var0 and var46", var0.equals(var46) ? var0.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var0
//     assertTrue("Contract failed: equals-hashcode on var46 and var0", var46.equals(var0) ? var46.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    java.awt.Font var32 = var16.getLabelFont();
    java.awt.Font var33 = var16.getLabelFont();
    java.lang.String var34 = var16.getLabel();
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var36 = var35.getAngleTickUnit();
    org.jfree.chart.renderer.PolarItemRenderer var37 = var35.getRenderer();
    java.awt.Paint var38 = var35.getAngleGridlinePaint();
    java.awt.Paint var39 = var35.getRadiusGridlinePaint();
    java.awt.Paint var40 = var35.getRadiusGridlinePaint();
    var16.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var35);
    var35.setRadiusGridlinesVisible(false);
    var35.removeCornerTextItem("{0}");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.block.BlockFrame var11 = var9.getFrame();
    org.jfree.chart.event.TitleChangeListener var12 = null;
    var9.removeChangeListener(var12);
    java.awt.geom.Rectangle2D var14 = var9.getBounds();
    var3.setUpArrow((java.awt.Shape)var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setWeight(100);
    org.jfree.data.category.CategoryDataset var20 = var16.getDataset(0);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = var16.getRendererForDataset(var21);
    java.awt.Stroke var23 = var16.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var25 = var16.getRangeAxisEdge(100);
    double var26 = var1.java2DToValue(0.2d, var14, var25);
    org.jfree.chart.axis.Timeline var27 = null;
    var1.setTimeline(var27);
    java.util.TimeZone var29 = var1.getTimeZone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 9.223372036854776E18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ChartEntity: tooltip = ", var1, 2.0f, 0.5f, 0.0d, 2.0f, 1.0f);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.block.BlockFrame var11 = var9.getFrame();
    org.jfree.chart.event.TitleChangeListener var12 = null;
    var9.removeChangeListener(var12);
    java.awt.geom.Rectangle2D var14 = var9.getBounds();
    var3.setUpArrow((java.awt.Shape)var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setWeight(100);
    org.jfree.data.category.CategoryDataset var20 = var16.getDataset(0);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = var16.getRendererForDataset(var21);
    java.awt.Stroke var23 = var16.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var25 = var16.getRangeAxisEdge(100);
    double var26 = var1.java2DToValue(0.2d, var14, var25);
    org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var14, "TextAnchor.CENTER", "0,0,2,-2,2,2,2,2");
    java.lang.String var30 = var29.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 9.223372036854776E18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "rect"+ "'", var30.equals("rect"));

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var3 = var2.getPaint();
    var1.setOutlinePaint(var3);
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var5, var6);
    java.lang.String var8 = var7.toString();
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var7.setType(var9);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var12 = var11.getStandardTickUnits();
    java.awt.Font var13 = var11.getLabelFont();
    var11.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var16 = new org.jfree.chart.plot.MultiplePiePlot();
    var16.setBackgroundAlpha(1.0f);
    java.awt.Stroke var19 = var16.getOutlineStroke();
    var11.setPlot((org.jfree.chart.plot.Plot)var16);
    var16.setBackgroundImageAlpha(1.0f);
    var16.setBackgroundAlpha(0.8f);
    java.lang.Object var25 = null;
    boolean var26 = var16.equals(var25);
    org.jfree.chart.JFreeChart var27 = var16.getPieChart();
    var7.setChart(var27);
    org.jfree.chart.JFreeChart var29 = var7.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    java.lang.String var5 = var0.getLabel();
    boolean var6 = var0.isVerticalTickLabels();
    java.lang.Object var7 = var0.clone();
    java.awt.Font var8 = var0.getTickLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicAnchor();
//     java.awt.Paint var16 = var13.getBackgroundPaint();
//     java.awt.Paint var17 = var13.getItemPaint();
//     java.awt.Paint var18 = var13.getItemPaint();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.VerticalAlignment var21 = var20.getVerticalAlignment();
//     org.jfree.chart.util.HorizontalAlignment var22 = var20.getTextAlignment();
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var26 = var25.getStandardTickUnits();
//     java.awt.Font var27 = var25.getLabelFont();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("", var27);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.util.VerticalAlignment var30 = var28.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var23, var30, (-1.0d), 1.0d);
//     var20.setVerticalAlignment(var30);
//     var13.setVerticalAlignment(var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
    java.awt.Paint var28 = var11.getRangeGridlinePaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    int var30 = var11.getIndexOf(var29);
    org.jfree.chart.util.RectangleEdge var32 = var11.getDomainAxisEdge(255);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
    var37.setFixedDimension((-1.0d));
    java.lang.Object var40 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var37);
    org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var42 = var41.getLabelURL();
    var41.setNegativeArrowVisible(false);
    java.awt.Font var45 = var41.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var36, (org.jfree.chart.axis.ValueAxis)var37, (org.jfree.chart.axis.ValueAxis)var41, var46);
    org.jfree.chart.axis.ValueAxis var49 = var47.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = var47.getRenderer();
    java.awt.Paint var51 = var47.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var52 = null;
    java.awt.geom.Rectangle2D var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    boolean var55 = var54.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var58 = var57.getAlpha();
    org.jfree.chart.util.Layer var59 = null;
    boolean var60 = var54.removeRangeMarker((org.jfree.chart.plot.Marker)var57, var59);
    org.jfree.chart.axis.AxisLocation var61 = var54.getRangeAxisLocation();
    java.util.List var62 = var54.getAnnotations();
    var47.drawRangeTickBands(var52, var53, var62);
    int var64 = var47.getRangeAxisCount();
    java.awt.Graphics2D var65 = null;
    org.jfree.chart.axis.NumberAxis3D var67 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var68 = var67.getStandardTickUnits();
    java.awt.Font var69 = var67.getLabelFont();
    org.jfree.chart.title.TextTitle var70 = new org.jfree.chart.title.TextTitle("", var69);
    java.lang.Object var71 = var70.clone();
    org.jfree.chart.block.BlockFrame var72 = var70.getFrame();
    org.jfree.chart.event.TitleChangeListener var73 = null;
    var70.removeChangeListener(var73);
    java.awt.geom.Rectangle2D var75 = var70.getBounds();
    org.jfree.chart.entity.ChartEntity var78 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var75, "", "");
    org.jfree.chart.plot.PlotRenderingInfo var79 = null;
    var47.drawAnnotations(var65, var75, var79);
    org.jfree.chart.axis.AxisSpace var81 = null;
    var47.setFixedDomainAxisSpace(var81);
    org.jfree.chart.plot.PlotRenderingInfo var84 = null;
    java.awt.geom.Point2D var85 = null;
    var47.zoomDomainAxes(102.0d, var84, var85);
    java.awt.geom.Point2D var87 = var47.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.zoomDomainAxes(9.223372036854776E18d, 0.08d, var35, var87);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
    java.awt.Font var20 = var18.getLabelFont();
    org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("", var20);
    java.lang.Object var22 = var21.clone();
    org.jfree.chart.util.RectangleInsets var23 = var21.getPadding();
    double var24 = var23.getBottom();
    org.jfree.chart.util.UnitType var25 = var23.getUnitType();
    var11.setAxisOffset(var23);
    java.awt.Stroke var27 = var11.getRangeCrosshairStroke();
    org.jfree.chart.axis.ValueAxis var28 = var11.getDomainAxis();
    java.awt.Paint var29 = var11.getDomainCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var31 = var11.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataset var33 = null;
    var11.setDataset(4, var33);
    boolean var35 = var11.isDomainCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(100.0d, var7, var8);
    boolean var10 = var0.isAngleLabelsVisible();
    var0.addCornerTextItem("Pie Plot");
    int var13 = var0.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    int var16 = var11.getWeight();
    org.jfree.chart.plot.PlotOrientation var17 = var11.getOrientation();
    boolean var18 = var11.isRangeZoomable();
    org.jfree.chart.util.RectangleEdge var20 = var11.getRangeAxisEdge((-1));
    java.awt.Stroke var21 = var11.getRangeCrosshairStroke();
    var11.setDomainZeroBaselineVisible(false);
    var11.clearAnnotations();
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var27 = var26.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
    var28.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var32 = var31.getLabelURL();
    java.util.EventListener var33 = null;
    boolean var34 = var31.hasListener(var33);
    var31.setInverted(true);
    java.awt.Paint var37 = var31.getAxisLinePaint();
    var28.setTickMarkPaint(var37);
    var26.setPaint(var37);
    var26.setValue(3.125d);
    java.awt.Color var44 = java.awt.Color.getColor("hi!", (-16777216));
    int var45 = var44.getAlpha();
    java.awt.Color var46 = var44.darker();
    int var47 = var44.getRed();
    var26.setPaint((java.awt.Paint)var44);
    var11.setRangeTickBandPaint((java.awt.Paint)var44);
    org.jfree.chart.annotations.XYAnnotation var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var51 = var11.removeAnnotation(var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    int var16 = var11.getWeight();
    org.jfree.chart.axis.AxisSpace var17 = null;
    var11.setFixedRangeAxisSpace(var17, false);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
    java.awt.Font var22 = var20.getLabelFont();
    var20.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot();
    var25.setBackgroundAlpha(1.0f);
    java.awt.Stroke var28 = var25.getOutlineStroke();
    var20.setPlot((org.jfree.chart.plot.Plot)var25);
    int var30 = var11.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var20);
    java.util.List var31 = var11.getAnnotations();
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var34 = var33.getLabelURL();
    var33.setNegativeArrowVisible(false);
    java.awt.Font var37 = var33.getTickLabelFont();
    java.lang.Object var38 = var33.clone();
    var33.setRange(100.0d, 102.0d);
    org.jfree.chart.axis.NumberTickUnit var42 = var33.getTickUnit();
    org.jfree.data.RangeType var43 = var33.getRangeType();
    var11.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var33, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    java.util.EventListener var8 = null;
    boolean var9 = var6.hasListener(var8);
    var6.setInverted(true);
    java.awt.Paint var12 = var6.getAxisLinePaint();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var16 = var0.getDomainAxisEdge(15);
    org.jfree.chart.util.RectangleEdge var17 = var0.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.AxisSpace var14 = null;
    var11.setFixedRangeAxisSpace(var14, true);
    double var17 = var11.getRangeCrosshairValue();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    var11.setRenderer(var18);
    var11.clearAnnotations();
    org.jfree.data.general.DatasetChangeEvent var21 = null;
    var11.datasetChanged(var21);
    org.jfree.chart.util.Layer var24 = null;
    java.util.Collection var25 = var11.getDomainMarkers((-57), var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var17 = var16.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     var18.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var22 = var21.getLabelURL();
//     java.util.EventListener var23 = null;
//     boolean var24 = var21.hasListener(var23);
//     var21.setInverted(true);
//     java.awt.Paint var27 = var21.getAxisLinePaint();
//     var18.setTickMarkPaint(var27);
//     var16.setPaint(var27);
//     org.jfree.chart.util.Layer var30 = null;
//     var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
//     java.lang.Object var32 = var11.clone();
//     double var33 = var11.getDomainCrosshairValue();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.setWeight(100);
//     org.jfree.data.category.CategoryDataset var38 = var34.getDataset(0);
//     var34.clearDomainMarkers();
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var41 = var40.getLabelURL();
//     java.util.EventListener var42 = null;
//     boolean var43 = var40.hasListener(var42);
//     var40.setInverted(true);
//     java.awt.Paint var46 = var40.getAxisLinePaint();
//     org.jfree.data.Range var47 = var34.getDataRange((org.jfree.chart.axis.ValueAxis)var40);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var49 = var48.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var52 = var51.getAlpha();
//     org.jfree.chart.util.Layer var53 = null;
//     boolean var54 = var48.removeRangeMarker((org.jfree.chart.plot.Marker)var51, var53);
//     var34.addRangeMarker((org.jfree.chart.plot.Marker)var51);
//     var34.setRangeCrosshairVisible(false);
//     org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var59 = var58.getLabelURL();
//     java.util.EventListener var60 = null;
//     boolean var61 = var58.hasListener(var60);
//     var58.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var65 = new org.jfree.chart.plot.MultiplePiePlot();
//     var65.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var68 = var65.getOutlineStroke();
//     var58.setAxisLineStroke(var68);
//     var34.setRangeCrosshairStroke(var68);
//     var11.setRangeZeroBaselineStroke(var68);
//     
//     // Checks the contract:  equals-hashcode on var16 and var51
//     assertTrue("Contract failed: equals-hashcode on var16 and var51", var16.equals(var51) ? var16.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var16
//     assertTrue("Contract failed: equals-hashcode on var51 and var16", var51.equals(var16) ? var51.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("0,0,1,1");
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var4 = var3.getCategoryMargin();
//     var3.setCategoryLabelPositionOffset(0);
//     boolean var7 = var1.equals((java.lang.Object)var3);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     boolean var10 = var9.isNegativeArrowVisible();
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var14 = var13.getLabelURL();
//     java.util.EventListener var15 = null;
//     boolean var16 = var13.hasListener(var15);
//     var13.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var20 = new org.jfree.chart.plot.MultiplePiePlot();
//     var20.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var23 = var20.getOutlineStroke();
//     var13.setAxisLineStroke(var23);
//     java.awt.Shape var25 = var13.getLeftArrow();
//     var12.setRightArrow(var25);
//     java.lang.Object var27 = var12.clone();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("XY Plot");
//     org.jfree.chart.axis.DateTickUnit var30 = null;
//     var29.setTickUnit(var30);
//     var29.configure();
//     java.util.Date var33 = var29.getMinimumDate();
//     var12.setMaximumDate(var33);
//     var9.setMinimumDate(var33);
//     var1.setMaximumDate(var33);
//     org.jfree.chart.axis.Timeline var37 = var1.getTimeline();
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var39 = var38.getLabelURL();
//     java.util.EventListener var40 = null;
//     boolean var41 = var38.hasListener(var40);
//     var38.zoomRange((-1.0d), 1.0d);
//     org.jfree.chart.plot.MultiplePiePlot var45 = new org.jfree.chart.plot.MultiplePiePlot();
//     var45.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var48 = var45.getOutlineStroke();
//     var38.setAxisLineStroke(var48);
//     boolean var50 = var38.getAutoRangeStickyZero();
//     org.jfree.chart.axis.TickUnitSource var51 = var38.getStandardTickUnits();
//     var1.setStandardTickUnits(var51);
//     
//     // Checks the contract:  equals-hashcode on var20 and var45
//     assertTrue("Contract failed: equals-hashcode on var20 and var45", var20.equals(var45) ? var20.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var20
//     assertTrue("Contract failed: equals-hashcode on var45 and var20", var45.equals(var20) ? var45.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     boolean var2 = var0.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var3 = null;
//     var0.setDataset(var3);
//     java.awt.Stroke var5 = var0.getRadiusGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     var0.zoomDomainAxes(102.0d, 0.05d, var8, var9);
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     var11.setFixedDimension((-1.0d));
//     java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var20 = var19.getStandardTickUnits();
//     java.awt.Font var21 = var19.getLabelFont();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("", var21);
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var21);
//     java.awt.Paint var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.setWeight(100);
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset(0);
//     org.jfree.chart.axis.CategoryAxis var31 = var26.getDomainAxis();
//     java.awt.Paint var32 = var26.getRangeCrosshairPaint();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("", var21, (org.jfree.chart.plot.Plot)var26, false);
//     boolean var35 = var34.getAntiAlias();
//     org.jfree.chart.event.ChartChangeEventType var36 = null;
//     org.jfree.chart.event.ChartChangeEvent var37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var11, var34, var36);
//     java.awt.Image var38 = null;
//     var34.setBackgroundImage(var38);
//     java.awt.Paint var40 = null;
//     var34.setBackgroundPaint(var40);
//     java.awt.image.BufferedImage var44 = var34.createBufferedImage(255, 100);
//     var0.setBackgroundImage((java.awt.Image)var44);
//     java.awt.Paint var46 = null;
//     var0.setAngleGridlinePaint(var46);
//     var0.clearCornerTextItems();
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D();
//     var50.setFixedDimension((-1.0d));
//     java.lang.Object var53 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var50);
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var55 = var54.getLabelURL();
//     var54.setNegativeArrowVisible(false);
//     java.awt.Font var58 = var54.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var49, (org.jfree.chart.axis.ValueAxis)var50, (org.jfree.chart.axis.ValueAxis)var54, var59);
//     org.jfree.chart.axis.ValueAxis var62 = var60.getDomainAxis(100);
//     org.jfree.chart.axis.ValueAxis var64 = var60.getRangeAxis(0);
//     int var65 = var60.getWeight();
//     int var66 = var60.getDatasetCount();
//     var60.mapDatasetToDomainAxis((-16777216), (-1));
//     org.jfree.chart.plot.ValueMarker var72 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var72.setValue((-1.0d));
//     org.jfree.chart.util.Layer var75 = null;
//     var60.addRangeMarker(0, (org.jfree.chart.plot.Marker)var72, var75);
//     org.jfree.chart.text.TextAnchor var77 = var72.getLabelTextAnchor();
//     org.jfree.chart.block.BlockBorder var82 = new org.jfree.chart.block.BlockBorder(10.0d, 1.0d, 0.0d, (-1.0d));
//     org.jfree.chart.util.RectangleInsets var83 = var82.getInsets();
//     java.awt.Paint var84 = var82.getPaint();
//     org.jfree.chart.axis.NumberAxis3D var88 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var89 = var88.getStandardTickUnits();
//     java.awt.Font var90 = var88.getLabelFont();
//     org.jfree.chart.title.TextTitle var91 = new org.jfree.chart.title.TextTitle("", var90);
//     org.jfree.chart.title.TextTitle var92 = new org.jfree.chart.title.TextTitle("", var90);
//     java.awt.Paint var93 = null;
//     org.jfree.chart.text.TextBlock var94 = org.jfree.chart.text.TextUtilities.createTextBlock("", var90, var93);
//     boolean var95 = var82.equals((java.lang.Object)var90);
//     var72.setLabelFont(var90);
//     var0.setAngleLabelFont(var90);
//     
//     // Checks the contract:  equals-hashcode on var20 and var89
//     assertTrue("Contract failed: equals-hashcode on var20 and var89", var20.equals(var89) ? var20.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var20
//     assertTrue("Contract failed: equals-hashcode on var89 and var20", var89.equals(var20) ? var89.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("PieSection: 1, 15(2.2)");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     java.awt.Font var4 = var2.getLabelFont();
//     var1.setLabelFont(var4);
//     var1.setUpperMargin(2.2d);
//     var1.setUpperMargin(0.5d);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
//     boolean var12 = var11.getDarkerSides();
//     boolean var13 = var11.getDarkerSides();
//     boolean var14 = var11.getDarkerSides();
//     var1.setPlot((org.jfree.chart.plot.Plot)var11);
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=10.0]");
//     boolean var18 = var11.equals((java.lang.Object)var17);
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     org.jfree.chart.plot.PiePlotState var20 = new org.jfree.chart.plot.PiePlotState(var19);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.chart.plot.PiePlotState var22 = new org.jfree.chart.plot.PiePlotState(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getExplodedPieArea();
//     double var24 = var22.getTotal();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var27 = var26.getStandardTickUnits();
//     java.awt.Font var28 = var26.getLabelFont();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("", var28);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.block.BlockFrame var31 = var29.getFrame();
//     org.jfree.chart.event.TitleChangeListener var32 = null;
//     var29.removeChangeListener(var32);
//     java.awt.geom.Rectangle2D var34 = var29.getBounds();
//     var22.setLinkArea(var34);
//     var20.setPieArea(var34);
//     org.jfree.chart.plot.PlotRenderingInfo var37 = var20.getInfo();
//     java.awt.geom.Rectangle2D var38 = var20.getPieArea();
//     var17.setLeftArrow((java.awt.Shape)var38);
//     
//     // Checks the contract:  equals-hashcode on var3 and var27
//     assertTrue("Contract failed: equals-hashcode on var3 and var27", var3.equals(var27) ? var3.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var3
//     assertTrue("Contract failed: equals-hashcode on var27 and var3", var27.equals(var3) ? var27.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var4 = var3.getLabel();
    org.jfree.chart.util.Layer var5 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    boolean var11 = var0.render(var7, var8, 1, var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    int var13 = var0.getIndexOf(var12);
    org.jfree.data.category.CategoryDataset var15 = var0.getDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var26 = var25.getAngleTickUnit();
    var25.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    var25.setAxis((org.jfree.chart.axis.ValueAxis)var29);
    var25.setNoDataMessage("hi!");
    java.awt.Graphics2D var33 = null;
    org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var36 = var35.getStandardTickUnits();
    java.awt.Font var37 = var35.getLabelFont();
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("", var37);
    java.lang.Object var39 = var38.clone();
    org.jfree.chart.block.BlockFrame var40 = var38.getFrame();
    org.jfree.chart.event.TitleChangeListener var41 = null;
    var38.removeChangeListener(var41);
    java.awt.geom.Rectangle2D var43 = var38.getBounds();
    java.awt.geom.Point2D var44 = null;
    org.jfree.chart.plot.PlotState var45 = null;
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    var25.draw(var33, var43, var44, var45, var46);
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    boolean var49 = var48.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var52 = var51.getAlpha();
    org.jfree.chart.util.Layer var53 = null;
    boolean var54 = var48.removeRangeMarker((org.jfree.chart.plot.Marker)var51, var53);
    org.jfree.chart.axis.AxisLocation var55 = var48.getRangeAxisLocation();
    java.util.List var56 = var48.getAnnotations();
    var11.drawDomainTickBands(var24, var43, var56);
    boolean var58 = var11.isRangeCrosshairVisible();
    java.awt.Paint var59 = var11.getDomainTickBandPaint();
    var11.mapDatasetToDomainAxis(1, 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var23 = var22.getLabelURL();
    var22.setNegativeArrowVisible(false);
    java.awt.Font var26 = var22.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
    org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var37 = var36.getPaint();
    var35.setOutlinePaint(var37);
    var28.setRangeGridlinePaint(var37);
    org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
    var11.setRangeAxisLocation(var40, false);
    java.awt.Paint var43 = null;
    var11.setDomainTickBandPaint(var43);
    org.jfree.chart.axis.AxisSpace var45 = var11.getFixedRangeAxisSpace();
    org.jfree.chart.annotations.XYAnnotation var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(10.0d, false);
    int var4 = var0.getDomainAxisCount();
    double var5 = var0.getRangeCrosshairValue();
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    var7.setMaximumCategoryLabelWidthRatio(0.8f);
    int var10 = var0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var20 = var19.getPaint();
//     var18.setOutlinePaint(var20);
//     var11.setRangeGridlinePaint(var20);
//     org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
//     java.awt.Paint var26 = var11.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var28 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var27};
//     var11.setRenderers(var28);
//     var11.clearRangeAxes();
//     var11.configureRangeAxes();
//     var11.configureRangeAxes();
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     var34.setFixedDimension((-1.0d));
//     java.lang.Object var37 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var34);
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var39 = var38.getLabelURL();
//     var38.setNegativeArrowVisible(false);
//     java.awt.Font var42 = var38.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.chart.axis.ValueAxis)var38, var43);
//     org.jfree.chart.axis.ValueAxis var46 = var44.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var50 = var49.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var51 = new org.jfree.chart.axis.NumberAxis3D();
//     var51.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var54 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var55 = var54.getLabelURL();
//     java.util.EventListener var56 = null;
//     boolean var57 = var54.hasListener(var56);
//     var54.setInverted(true);
//     java.awt.Paint var60 = var54.getAxisLinePaint();
//     var51.setTickMarkPaint(var60);
//     var49.setPaint(var60);
//     org.jfree.chart.util.Layer var63 = null;
//     var44.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var49, var63);
//     org.jfree.chart.util.Layer var65 = null;
//     boolean var66 = var11.removeRangeMarker((org.jfree.chart.plot.Marker)var49, var65);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var5 = var4.getCategoryMargin();
//     var0.setDomainAxis(var4);
//     boolean var7 = var0.isSubplot();
//     org.jfree.chart.event.AxisChangeEvent var8 = null;
//     var0.axisChanged(var8);
//     var0.zoom(0.0d);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.util.RectangleEdge var25 = var11.getRangeAxisEdge(4);
    org.jfree.chart.axis.AxisLocation var26 = var11.getRangeAxisLocation();
    java.awt.Stroke var27 = var11.getRangeGridlineStroke();
    var11.setWeight((-16579837));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    var4.centerRange((-0.18d));
    java.util.Date var7 = var4.getMaximumDate();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var10 = null;
    var9.setTickUnit(var10);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var15 = var14.getLabelURL();
    java.util.EventListener var16 = null;
    boolean var17 = var14.hasListener(var16);
    var14.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
    var21.setBackgroundAlpha(1.0f);
    java.awt.Stroke var24 = var21.getOutlineStroke();
    var14.setAxisLineStroke(var24);
    java.awt.Shape var26 = var14.getLeftArrow();
    var13.setRightArrow(var26);
    java.lang.Object var28 = var13.clone();
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var31 = null;
    var30.setTickUnit(var31);
    var30.configure();
    java.util.Date var34 = var30.getMinimumDate();
    var13.setMaximumDate(var34);
    var9.setMaximumDate(var34);
    var4.setMinimumDate(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var38 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-2.1799999999999997d), 3.125d, (-254), (java.lang.Comparable)var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1);
    var0.zoomRange((-1.0d), 104.0d);
    java.awt.Paint var6 = var0.getTickMarkPaint();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.PiePlotState var9 = new org.jfree.chart.plot.PiePlotState(var8);
    var9.setLatestAngle(0.0d);
    var9.setPieCenterX(0.2d);
    double var14 = var9.getTotal();
    double var15 = var9.getPieHRadius();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
    java.awt.Font var20 = var18.getLabelFont();
    org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("", var20);
    java.awt.Paint var22 = null;
    org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var20, var22);
    java.util.List var24 = var23.getLines();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.util.Size2D var26 = var23.calculateDimensions(var25);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var30.setLabel("");
    org.jfree.chart.event.MarkerChangeEvent var33 = null;
    var30.notifyListeners(var33);
    java.awt.Stroke var35 = var30.getStroke();
    org.jfree.chart.util.RectangleAnchor var36 = var30.getLabelAnchor();
    java.awt.geom.Rectangle2D var37 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, 92.0d, (-0.18d), var36);
    var9.setExplodedPieArea(var37);
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
    var40.setFixedDimension((-1.0d));
    java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var40);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var45 = var44.getLabelURL();
    var44.setNegativeArrowVisible(false);
    java.awt.Font var48 = var44.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.axis.ValueAxis)var44, var49);
    org.jfree.chart.axis.ValueAxis var52 = var50.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var53 = var50.getRenderer();
    java.awt.Paint var54 = var50.getDomainZeroBaselinePaint();
    var50.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var57 = null;
    var50.setFixedRangeAxisSpace(var57, true);
    var50.clearDomainMarkers((-1));
    org.jfree.chart.util.RectangleEdge var62 = var50.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var63 = null;
    var50.setDataset(var63);
    org.jfree.chart.util.RectangleEdge var66 = var50.getRangeAxisEdge(10);
    double var67 = var0.java2DToValue(106.0d, var37, var66);
    org.jfree.chart.axis.DateTickUnit var68 = null;
    var0.setTickUnit(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 9.223372036854776E18d);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var28 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var27};
    var11.setRenderers(var28);
    java.awt.Paint var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeCrosshairPaint(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    int var28 = var11.getRangeAxisCount();
    org.jfree.chart.util.Layer var29 = null;
    java.util.Collection var30 = var11.getDomainMarkers(var29);
    org.jfree.chart.util.Layer var31 = null;
    java.util.Collection var32 = var11.getRangeMarkers(var31);
    java.awt.geom.Point2D var33 = var11.getQuadrantOrigin();
    var11.mapDatasetToRangeAxis((-16579837), 15);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.setWeight(100);
    org.jfree.data.category.CategoryDataset var41 = var37.getDataset(0);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Point2D var44 = null;
    var37.zoomDomainAxes(102.0d, var43, var44, false);
    org.jfree.data.xy.XYDataset var48 = null;
    org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D();
    var49.setFixedDimension((-1.0d));
    java.lang.Object var52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var49);
    org.jfree.chart.axis.NumberAxis3D var53 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var54 = var53.getLabelURL();
    var53.setNegativeArrowVisible(false);
    java.awt.Font var57 = var53.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
    org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var48, (org.jfree.chart.axis.ValueAxis)var49, (org.jfree.chart.axis.ValueAxis)var53, var58);
    org.jfree.chart.axis.ValueAxis var61 = var59.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var62 = var59.getRenderer();
    java.awt.Paint var63 = var59.getDomainZeroBaselinePaint();
    boolean var64 = var59.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var65 = null;
    org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D();
    var66.setFixedDimension((-1.0d));
    java.lang.Object var69 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var66);
    org.jfree.chart.axis.NumberAxis3D var70 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var71 = var70.getLabelURL();
    var70.setNegativeArrowVisible(false);
    java.awt.Font var74 = var70.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
    org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot(var65, (org.jfree.chart.axis.ValueAxis)var66, (org.jfree.chart.axis.ValueAxis)var70, var75);
    org.jfree.chart.axis.ValueAxis var78 = var76.getDomainAxis(100);
    org.jfree.chart.util.Layer var80 = null;
    java.util.Collection var81 = var76.getDomainMarkers((-1), var80);
    org.jfree.chart.plot.ValueMarker var83 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var84 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var85 = var84.getPaint();
    var83.setOutlinePaint(var85);
    var76.setRangeGridlinePaint(var85);
    org.jfree.chart.axis.AxisLocation var88 = var76.getDomainAxisLocation();
    var59.setRangeAxisLocation(var88, false);
    var37.setDomainAxisLocation(0, var88, true);
    var11.setRangeAxisLocation(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }


    org.jfree.chart.block.RectangleConstraint var3 = new org.jfree.chart.block.RectangleConstraint(10.0d, 10.0d);
    org.jfree.chart.block.RectangleConstraint var5 = var3.toFixedHeight(12.0d);
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("Category Plot");
    org.jfree.data.Range var8 = var7.getRange();
    org.jfree.chart.block.RectangleConstraint var9 = var5.toRangeHeight(var8);
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, 10.0d);
    org.jfree.data.Range var13 = var12.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var14 = var12.getHeightConstraintType();
    java.lang.String var15 = var14.toString();
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    var20.setFixedDimension((-1.0d));
    java.lang.Object var23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var20);
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var25 = var24.getLabelURL();
    var24.setNegativeArrowVisible(false);
    java.awt.Font var28 = var24.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
    org.jfree.data.Range var31 = var24.getDefaultAutoRange();
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 90.0d);
    var18.setRange(var31, true, true);
    double var37 = var31.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(10.0d, 10.0d);
    org.jfree.data.Range var41 = var40.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var42 = var40.getHeightConstraintType();
    java.lang.String var43 = var42.toString();
    org.jfree.chart.block.RectangleConstraint var44 = new org.jfree.chart.block.RectangleConstraint((-5.975d), var8, var14, 0.20000000000000018d, var31, var42);
    org.jfree.chart.block.LengthConstraintType var45 = var44.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var47 = var44.toFixedWidth(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "LengthConstraintType.FIXED"+ "'", var15.equals("LengthConstraintType.FIXED"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "LengthConstraintType.FIXED"+ "'", var43.equals("LengthConstraintType.FIXED"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    var0.setLabelGap(0.0d);
    double var5 = var0.getExplodePercent((java.lang.Comparable)15);
    org.jfree.chart.labels.PieToolTipGenerator var6 = var0.getToolTipGenerator();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("XY Plot");
    boolean var9 = var8.isNegativeArrowVisible();
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var13 = var12.getLabelURL();
    java.util.EventListener var14 = null;
    boolean var15 = var12.hasListener(var14);
    var12.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot();
    var19.setBackgroundAlpha(1.0f);
    java.awt.Stroke var22 = var19.getOutlineStroke();
    var12.setAxisLineStroke(var22);
    java.awt.Shape var24 = var12.getLeftArrow();
    var11.setRightArrow(var24);
    java.lang.Object var26 = var11.clone();
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var29 = null;
    var28.setTickUnit(var29);
    var28.configure();
    java.util.Date var32 = var28.getMinimumDate();
    var11.setMaximumDate(var32);
    var8.setMinimumDate(var32);
    double var35 = var0.getExplodePercent((java.lang.Comparable)var32);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var0.markerChanged(var36);
    org.jfree.chart.block.LineBorder var38 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var44 = var43.getStandardTickUnits();
    java.awt.Font var45 = var43.getLabelFont();
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("", var45);
    org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("", var45);
    java.awt.Paint var48 = null;
    org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("", var45, var48);
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    var50.setWeight(100);
    org.jfree.data.category.CategoryDataset var54 = var50.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var55 = var50.getDomainAxis();
    java.awt.Paint var56 = var50.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var58 = new org.jfree.chart.JFreeChart("", var45, (org.jfree.chart.plot.Plot)var50, false);
    boolean var59 = var58.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var60 = null;
    var58.removeProgressListener(var60);
    org.jfree.chart.event.ChartProgressEvent var64 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var38, var58, (-16777216), 15);
    java.awt.Paint var65 = var38.getPaint();
    java.awt.Paint var66 = var38.getPaint();
    var0.setLabelBackgroundPaint(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("poly", var1);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var4 = var3.getLabel();
    org.jfree.chart.util.Layer var5 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    boolean var11 = var0.render(var7, var8, 1, var10);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var0.setRangeAxis(0, var13, true);
    org.jfree.chart.axis.ValueAxis var17 = var0.getRangeAxis(4);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.setWeight(100);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    boolean var25 = var18.render(var21, var22, 0, var24);
    var18.mapDatasetToRangeAxis(0, 0);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var31.setCategoryMargin((-1.0d));
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.setWeight(100);
    org.jfree.data.category.CategoryDataset var38 = var34.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var39 = var34.getDomainAxis();
    java.awt.Paint var40 = var34.getRangeCrosshairPaint();
    var31.setTickLabelPaint(var40);
    var18.setDomainAxis(0, var31);
    int var43 = var0.getDomainAxisIndex(var31);
    var0.clearRangeMarkers();
    org.jfree.chart.plot.CategoryMarker var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1));

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var4 = var3.getAlpha();
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var3, var5);
    org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation();
    java.util.List var8 = var0.getAnnotations();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
    java.awt.Font var12 = var10.getLabelFont();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.block.BlockFrame var15 = var13.getFrame();
    org.jfree.chart.util.RectangleInsets var16 = var13.getMargin();
    var0.setAxisOffset(var16);
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker((-0.05d));
    org.jfree.chart.util.Layer var21 = null;
    var0.addRangeMarker((-16579837), (org.jfree.chart.plot.Marker)var20, var21);
    org.jfree.chart.plot.Plot var23 = var0.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
    double var7 = var6.getBottom();
    org.jfree.chart.util.UnitType var8 = var6.getUnitType();
    java.lang.String var9 = var8.toString();
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets(var8, (-0.18d), 90.0d, (-0.18d), 102.0d);
    org.jfree.chart.util.RectangleInsets var19 = new org.jfree.chart.util.RectangleInsets(var8, 1.0E-8d, 2.2d, 0.20000000000000018d, 104.0d);
    java.lang.String var20 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "UnitType.ABSOLUTE"+ "'", var9.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "UnitType.ABSOLUTE"+ "'", var20.equals("UnitType.ABSOLUTE"));

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    var11.clearRangeAxes();
    java.awt.Paint var29 = var11.getRangeZeroBaselinePaint();
    int var30 = var11.getSeriesCount();
    java.awt.Stroke var31 = var11.getRangeCrosshairStroke();
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    var33.setFixedDimension((-1.0d));
    var33.setAutoRange(true);
    var11.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var33, false);
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = var11.getRendererForDataset(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var23 = var22.getLabelURL();
    var22.setNegativeArrowVisible(false);
    java.awt.Font var26 = var22.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
    org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var37 = var36.getPaint();
    var35.setOutlinePaint(var37);
    var28.setRangeGridlinePaint(var37);
    org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
    var11.setRangeAxisLocation(var40, false);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var45 = var44.getLabelURL();
    java.util.EventListener var46 = null;
    boolean var47 = var44.hasListener(var46);
    var44.setLabel("");
    boolean var50 = var44.isVerticalTickLabels();
    org.jfree.chart.axis.MarkerAxisBand var51 = null;
    var44.setMarkerBand(var51);
    var11.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var44);
    java.awt.Paint var54 = var11.getDomainZeroBaselinePaint();
    var11.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     var5.setBackgroundImageAlpha(1.0f);
//     var5.setBackgroundAlpha(0.8f);
//     java.lang.Object var14 = null;
//     boolean var15 = var5.equals(var14);
//     org.jfree.chart.JFreeChart var16 = var5.getPieChart();
//     java.lang.String var17 = var5.getPlotType();
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
//     boolean var19 = var18.getSectionOutlinesVisible();
//     var18.setPieIndex(0);
//     org.jfree.chart.plot.AbstractPieLabelDistributor var22 = var18.getLabelDistributor();
//     boolean var23 = var18.getLabelLinksVisible();
//     org.jfree.chart.util.Rotation var24 = var18.getDirection();
//     var18.setShadowYOffset(0.025d);
//     double var27 = var18.getShadowXOffset();
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot();
//     boolean var29 = var28.getSectionOutlinesVisible();
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var32 = var31.getStandardTickUnits();
//     java.awt.Font var33 = var31.getLabelFont();
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle("", var33);
//     java.lang.Object var35 = var34.clone();
//     java.lang.String var36 = var34.getText();
//     org.jfree.chart.util.RectangleInsets var37 = var34.getPadding();
//     var28.setLabelPadding(var37);
//     var28.setLabelLinkMargin(0.025d);
//     boolean var41 = var28.getLabelLinksVisible();
//     var28.setCircular(true);
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var47 = var46.getLabelURL();
//     var46.setNegativeArrowVisible(false);
//     java.awt.Font var50 = var46.getTickLabelFont();
//     java.lang.Object var51 = var46.clone();
//     var46.setRange(100.0d, 102.0d);
//     org.jfree.chart.axis.NumberTickUnit var55 = var46.getTickUnit();
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D();
//     var57.setFixedDimension((-1.0d));
//     java.lang.Object var60 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var57);
//     org.jfree.chart.axis.NumberAxis3D var61 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var62 = var61.getLabelURL();
//     var61.setNegativeArrowVisible(false);
//     java.awt.Font var65 = var61.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var57, (org.jfree.chart.axis.ValueAxis)var61, var66);
//     org.jfree.chart.axis.ValueAxis var69 = var67.getDomainAxis(100);
//     org.jfree.chart.plot.ValueMarker var72 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var73 = var72.getAlpha();
//     org.jfree.chart.axis.NumberAxis3D var74 = new org.jfree.chart.axis.NumberAxis3D();
//     var74.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var77 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var78 = var77.getLabelURL();
//     java.util.EventListener var79 = null;
//     boolean var80 = var77.hasListener(var79);
//     var77.setInverted(true);
//     java.awt.Paint var83 = var77.getAxisLinePaint();
//     var74.setTickMarkPaint(var83);
//     var72.setPaint(var83);
//     org.jfree.chart.util.Layer var86 = null;
//     var67.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var72, var86);
//     java.awt.Font var88 = var72.getLabelFont();
//     var45.setTickLabelFont((java.lang.Comparable)var55, var88);
//     java.awt.Paint var90 = var28.getSectionOutlinePaint((java.lang.Comparable)var55);
//     var18.setExplodePercent((java.lang.Comparable)var55, 1.0E-5d);
//     var5.setAggregatedItemsKey((java.lang.Comparable)1.0E-5d);
//     
//     // Checks the contract:  equals-hashcode on var1 and var32
//     assertTrue("Contract failed: equals-hashcode on var1 and var32", var1.equals(var32) ? var1.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var1
//     assertTrue("Contract failed: equals-hashcode on var32 and var1", var32.equals(var1) ? var32.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var0.setRenderer(var7);
    var0.setBackgroundAlpha(1.0f);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomRangeAxes(0.2d, var12, var13, true);
    org.jfree.chart.axis.ValueAxis var17 = var0.getRangeAxis((-1));
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.setWeight(100);
    org.jfree.data.category.CategoryDataset var22 = var18.getDataset(0);
    var18.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var25 = var24.getLabelURL();
    java.util.EventListener var26 = null;
    boolean var27 = var24.hasListener(var26);
    var24.setInverted(true);
    java.awt.Paint var30 = var24.getAxisLinePaint();
    org.jfree.data.Range var31 = var18.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.util.RectangleEdge var32 = var18.getDomainAxisEdge();
    boolean var33 = var18.isRangeZoomable();
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
    var35.setFixedDimension((-1.0d));
    java.lang.Object var38 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var35);
    org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var40 = var39.getLabelURL();
    var39.setNegativeArrowVisible(false);
    java.awt.Font var43 = var39.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var44);
    org.jfree.chart.axis.ValueAxis var47 = var45.getDomainAxis(100);
    org.jfree.chart.util.Layer var49 = null;
    java.util.Collection var50 = var45.getDomainMarkers((-1), var49);
    org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var53 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var54 = var53.getPaint();
    var52.setOutlinePaint(var54);
    var45.setRangeGridlinePaint(var54);
    org.jfree.chart.axis.AxisLocation var57 = var45.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var59 = var45.getRangeAxisForDataset(0);
    java.awt.Paint var60 = var45.getDomainCrosshairPaint();
    java.awt.Stroke var61 = var45.getDomainCrosshairStroke();
    java.awt.Paint var62 = var45.getRangeGridlinePaint();
    var18.setRangeGridlinePaint(var62);
    org.jfree.chart.plot.PolarPlot var64 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var65 = var64.getAngleTickUnit();
    boolean var66 = var64.isDomainZoomable();
    boolean var67 = var64.isRangeZoomable();
    org.jfree.data.general.DatasetChangeEvent var68 = null;
    var64.datasetChanged(var68);
    org.jfree.chart.axis.ValueAxis var70 = null;
    var64.setAxis(var70);
    org.jfree.chart.plot.PlotOrientation var72 = var64.getOrientation();
    var18.setOrientation(var72);
    var0.setOrientation(var72);
    var0.configureDomainAxes();
    org.jfree.chart.util.RectangleInsets var76 = var0.getAxisOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    java.util.EventListener var8 = null;
    boolean var9 = var6.hasListener(var8);
    var6.setInverted(true);
    java.awt.Paint var12 = var6.getAxisLinePaint();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
    var0.setBackgroundAlpha(0.0f);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setWeight(100);
    org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var22 = var17.getDomainAxis();
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var24 = var17.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    boolean var26 = var25.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var29 = var28.getAlpha();
    org.jfree.chart.util.Layer var30 = null;
    boolean var31 = var25.removeRangeMarker((org.jfree.chart.plot.Marker)var28, var30);
    org.jfree.chart.axis.AxisLocation var32 = var25.getRangeAxisLocation();
    var17.setRangeAxisLocation(var32, false);
    org.jfree.data.category.CategoryDataset var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var17.getRendererForDataset(var35);
    org.jfree.chart.LegendItemCollection var37 = var17.getLegendItems();
    var0.setFixedLegendItems(var37);
    org.jfree.chart.util.RectangleEdge var40 = var0.getRangeAxisEdge(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    var0.setRenderer(var41);
    org.jfree.chart.util.RectangleEdge var44 = var0.getRangeAxisEdge((-104858));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(15);
    int var2 = var1.getItemCount();
    var1.distributeLabels((-1.0d), 1.0d);
    var1.sort();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    java.awt.Stroke var6 = var0.getAngleGridlineStroke();
    var0.addCornerTextItem("LengthConstraintType.FIXED");
    java.awt.Font var9 = var0.getAngleLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    boolean var2 = var0.isDomainZoomable();
    org.jfree.data.xy.XYDataset var3 = null;
    var0.setDataset(var3);
    java.awt.Stroke var5 = var0.getRadiusGridlineStroke();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(102.0d, 0.05d, var8, var9);
    java.awt.Stroke var11 = null;
    var0.setRadiusGridlineStroke(var11);
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var15 = var14.getLabelURL();
    var14.setNegativeArrowVisible(false);
    java.awt.Font var18 = var14.getTickLabelFont();
    java.lang.Object var19 = var14.clone();
    var14.setRange(100.0d, 102.0d);
    var14.setLowerMargin(0.20000000000000018d);
    java.awt.Font var25 = var14.getTickLabelFont();
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var27 = var26.getStandardTickUnits();
    java.awt.Font var28 = var26.getLabelFont();
    var26.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var31 = new org.jfree.chart.plot.MultiplePiePlot();
    var31.setBackgroundAlpha(1.0f);
    java.awt.Stroke var34 = var31.getOutlineStroke();
    var26.setPlot((org.jfree.chart.plot.Plot)var31);
    java.awt.Image var36 = var31.getBackgroundImage();
    org.jfree.data.category.CategoryDataset var37 = null;
    var31.setDataset(var37);
    java.awt.Paint var39 = var31.getAggregatedItemsPaint();
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", var25, var39);
    var0.setNoDataMessagePaint(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var3 = var2.getCategoryMargin();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var4.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var8 = var7.getLabelURL();
    java.util.EventListener var9 = null;
    boolean var10 = var7.hasListener(var9);
    var7.setInverted(true);
    java.awt.Paint var13 = var7.getAxisLinePaint();
    var4.setTickMarkPaint(var13);
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, var15);
    java.awt.Stroke var17 = var16.getRangeGridlineStroke();
    double var18 = var16.getRangeCrosshairValue();
    org.jfree.chart.axis.ValueAxis var20 = null;
    var16.setRangeAxis(15, var20);
    var16.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("poly", var1);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    var1.setLabel("");
    java.awt.Stroke var6 = var1.getAxisLineStroke();
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var8 = var7.getLabelURL();
    java.util.EventListener var9 = null;
    boolean var10 = var7.hasListener(var9);
    org.jfree.chart.axis.NumberTickUnit var11 = var7.getTickUnit();
    var1.setTickUnit(var11, false, false);
    boolean var15 = var0.equals((java.lang.Object)var1);
    java.lang.String var16 = var0.getVersion();
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo();
    var17.setLicenceText("hi!");
    java.lang.String var20 = var17.getLicenceText();
    java.awt.Image var21 = var17.getLogo();
    java.lang.String var22 = var17.getVersion();
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var17);
    var0.addOptionalLibrary("RectangleAnchor.TOP_LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "hi!"+ "'", var20.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var2.setTickUnit(var3);
    java.text.DateFormat var5 = null;
    var2.setDateFormatOverride(var5);
    java.util.TimeZone var7 = var2.getTimeZone();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("LengthConstraintType.FIXED", var7);
    var8.setInverted(true);
    double var11 = var8.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0d);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    double var5 = var0.getLabelLinkMargin();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    var7.setFixedDimension((-1.0d));
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
    org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var12 = var11.getLabelURL();
    var11.setNegativeArrowVisible(false);
    java.awt.Font var15 = var11.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var11, var16);
    org.jfree.chart.axis.ValueAxis var19 = var17.getDomainAxis(100);
    var17.clearRangeMarkers(15);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = new org.jfree.chart.plot.PiePlotState(var23);
    int var25 = var24.getPassesRequired();
    double var26 = var24.getPieWRadius();
    org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot();
    boolean var28 = var27.getSectionOutlinesVisible();
    var27.setMinimumArcAngleToDraw((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var33 = var32.getStandardTickUnits();
    java.awt.Font var34 = var32.getLabelFont();
    org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("", var34);
    java.lang.Object var36 = var35.clone();
    org.jfree.chart.block.BlockFrame var37 = var35.getFrame();
    org.jfree.chart.event.TitleChangeListener var38 = null;
    var35.removeChangeListener(var38);
    java.awt.geom.Rectangle2D var40 = var35.getBounds();
    var27.setLegendItemShape((java.awt.Shape)var40);
    var24.setLinkArea(var40);
    org.jfree.chart.plot.PlotRenderingInfo var44 = null;
    org.jfree.chart.plot.CrosshairState var45 = null;
    boolean var46 = var17.render(var22, var40, 0, var44, var45);
    var0.setLegendItemShape((java.awt.Shape)var40);
    java.awt.Shape var48 = var0.getLegendItemShape();
    org.jfree.chart.util.RectangleInsets var49 = var0.getLabelPadding();
    double var51 = var49.calculateTopOutset(0.08d);
    double var53 = var49.calculateRightOutset(0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 2.0d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var5 = var4.getCategoryMargin();
    var0.setDomainAxis(var4);
    var4.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var3 = var2.getPaint();
    var1.setOutlinePaint(var3);
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var5, var6);
    java.lang.String var8 = var7.toString();
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var7.setType(var9);
    org.jfree.chart.JFreeChart var11 = null;
    var7.setChart(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     java.lang.String var6 = var4.getText();
//     org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
//     java.lang.Object var8 = var4.clone();
//     java.lang.Object var9 = var4.clone();
//     var4.setText("LengthConstraintType.FIXED");
//     var4.setExpandToFitSpace(true);
//     double var14 = var4.getHeight();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.ValueAxis var20 = var16.getRangeAxisForDataset(0);
//     var16.clearRangeMarkers();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     var16.setRenderer(0, var23, true);
//     var16.setBackgroundImageAlignment(100);
//     var16.clearRangeAxes();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var34 = var33.getLabelURL();
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var37 = var36.getStandardTickUnits();
//     java.awt.Font var38 = var36.getLabelFont();
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("", var38);
//     java.lang.Object var40 = var39.clone();
//     org.jfree.chart.block.BlockFrame var41 = var39.getFrame();
//     org.jfree.chart.event.TitleChangeListener var42 = null;
//     var39.removeChangeListener(var42);
//     java.awt.geom.Rectangle2D var44 = var39.getBounds();
//     var33.setUpArrow((java.awt.Shape)var44);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     var46.setWeight(100);
//     org.jfree.data.category.CategoryDataset var50 = var46.getDataset(0);
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = var46.getRendererForDataset(var51);
//     java.awt.Stroke var53 = var46.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleEdge var55 = var46.getRangeAxisEdge(100);
//     double var56 = var31.java2DToValue(0.2d, var44, var55);
//     org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var44, "TextAnchor.CENTER", "0,0,2,-2,2,2,2,2");
//     var16.drawBackgroundImage(var29, var44);
//     var4.draw(var15, var44);
//     
//     // Checks the contract:  equals-hashcode on var2 and var37
//     assertTrue("Contract failed: equals-hashcode on var2 and var37", var2.equals(var37) ? var2.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var2
//     assertTrue("Contract failed: equals-hashcode on var37 and var2", var37.equals(var2) ? var37.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    var0.setLabelLinkMargin(10.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var7 = var0.getLabelDistributor();
    org.jfree.chart.labels.PieSectionLabelGenerator var8 = var0.getLegendLabelToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    var0.setAnchorValue(9.223372036854776E18d, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var0.setRenderer(var8);
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var13 = var12.getAngleTickUnit();
    var12.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    var12.setAxis((org.jfree.chart.axis.ValueAxis)var16);
    var12.setNoDataMessage("hi!");
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var23 = var22.getStandardTickUnits();
    java.awt.Font var24 = var22.getLabelFont();
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var24);
    java.lang.Object var26 = var25.clone();
    org.jfree.chart.block.BlockFrame var27 = var25.getFrame();
    org.jfree.chart.event.TitleChangeListener var28 = null;
    var25.removeChangeListener(var28);
    java.awt.geom.Rectangle2D var30 = var25.getBounds();
    java.awt.geom.Point2D var31 = null;
    org.jfree.chart.plot.PlotState var32 = null;
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    var12.draw(var20, var30, var31, var32, var33);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    var35.setWeight(100);
    org.jfree.data.category.CategoryDataset var39 = var35.getDataset(0);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = var35.getRendererForDataset(var40);
    java.awt.Stroke var42 = var35.getDomainGridlineStroke();
    var12.setRadiusGridlineStroke(var42);
    var0.setRangeGridlineStroke(var42);
    org.jfree.data.general.DatasetChangeEvent var45 = null;
    var0.datasetChanged(var45);
    float var47 = var0.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0f);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    int var3 = var0.getWeight();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    var4.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
    var9.setBackgroundAlpha(1.0f);
    java.awt.Stroke var12 = var9.getOutlineStroke();
    var4.setPlot((org.jfree.chart.plot.Plot)var9);
    var4.setAutoTickUnitSelection(false);
    org.jfree.chart.axis.ValueAxis[] var16 = new org.jfree.chart.axis.ValueAxis[] { var4};
    var0.setRangeAxes(var16);
    org.jfree.chart.axis.CategoryAxis var19 = var0.getDomainAxis((-16777216));
    boolean var20 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
    var25.setFixedDimension((-1.0d));
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var25);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var30 = var29.getLabelURL();
    var29.setNegativeArrowVisible(false);
    java.awt.Font var33 = var29.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var34);
    org.jfree.chart.axis.ValueAxis var37 = var35.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = var35.getRenderer();
    java.awt.Paint var39 = var35.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var40 = null;
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    boolean var43 = var42.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var46 = var45.getAlpha();
    org.jfree.chart.util.Layer var47 = null;
    boolean var48 = var42.removeRangeMarker((org.jfree.chart.plot.Marker)var45, var47);
    org.jfree.chart.axis.AxisLocation var49 = var42.getRangeAxisLocation();
    java.util.List var50 = var42.getAnnotations();
    var35.drawRangeTickBands(var40, var41, var50);
    var35.clearRangeAxes();
    java.awt.Paint var53 = var35.getRangeZeroBaselinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var56 = null;
    org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var58 = var57.getStandardTickUnits();
    java.awt.Font var59 = var57.getLabelFont();
    var57.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var62 = new org.jfree.chart.plot.MultiplePiePlot();
    var62.setBackgroundAlpha(1.0f);
    java.awt.Stroke var65 = var62.getOutlineStroke();
    var57.setPlot((org.jfree.chart.plot.Plot)var62);
    java.awt.Image var67 = var62.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var68 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var69 = null;
    org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var62, (org.jfree.chart.block.Arrangement)var68, var69);
    org.jfree.chart.util.RectangleInsets var71 = var70.getLegendItemGraphicPadding();
    org.jfree.chart.block.BlockContainer var72 = var70.getItemContainer();
    double var73 = var70.getWidth();
    org.jfree.chart.text.TextLine var74 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var75 = null;
    org.jfree.chart.util.Size2D var76 = var74.calculateDimensions(var75);
    org.jfree.chart.plot.ValueMarker var80 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var81 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var82 = var81.getPaint();
    var80.setOutlinePaint(var82);
    org.jfree.chart.util.RectangleAnchor var84 = var80.getLabelAnchor();
    java.awt.geom.Rectangle2D var85 = org.jfree.chart.util.RectangleAnchor.createRectangle(var76, 0.05d, 0.0d, var84);
    var70.setBounds(var85);
    org.jfree.chart.plot.ValueMarker var88 = new org.jfree.chart.plot.ValueMarker(2.2d);
    org.jfree.chart.util.RectangleAnchor var89 = var88.getLabelAnchor();
    java.awt.geom.Point2D var90 = org.jfree.chart.util.RectangleAnchor.coordinates(var85, var89);
    var35.zoomDomainAxes(1.05d, 3.0d, var56, var90);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(6.00001d, (-0.05d), var23, var90);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    boolean var7 = var0.isRangeCrosshairVisible();
    boolean var8 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.ValueAxis var13 = var9.getRangeAxisForDataset(0);
    var9.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var15 = var9.getDataset();
    java.awt.Paint var16 = var9.getRangeGridlinePaint();
    var0.setRangeGridlinePaint(var16);
    java.awt.Paint[] var18 = new java.awt.Paint[] { var16};
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.VerticalAlignment var21 = var20.getVerticalAlignment();
    java.awt.Paint var22 = var20.getPaint();
    java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var25 = var24.getAngleTickUnit();
    var24.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
    var24.setAxis((org.jfree.chart.axis.ValueAxis)var28);
    var24.setNoDataMessage("hi!");
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var35 = var34.getStandardTickUnits();
    java.awt.Font var36 = var34.getLabelFont();
    org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle("", var36);
    java.lang.Object var38 = var37.clone();
    org.jfree.chart.block.BlockFrame var39 = var37.getFrame();
    org.jfree.chart.event.TitleChangeListener var40 = null;
    var37.removeChangeListener(var40);
    java.awt.geom.Rectangle2D var42 = var37.getBounds();
    java.awt.geom.Point2D var43 = null;
    org.jfree.chart.plot.PlotState var44 = null;
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    var24.draw(var32, var42, var43, var44, var45);
    java.awt.Paint var47 = null;
    var24.setRadiusGridlinePaint(var47);
    java.awt.Stroke var49 = var24.getRadiusGridlineStroke();
    java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
    org.jfree.chart.axis.NumberAxis3D var51 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var52 = var51.getLabelURL();
    java.util.EventListener var53 = null;
    boolean var54 = var51.hasListener(var53);
    org.jfree.chart.axis.NumberTickUnit var55 = var51.getTickUnit();
    java.awt.Stroke var56 = var51.getTickMarkStroke();
    java.awt.Stroke[] var57 = new java.awt.Stroke[] { var56};
    java.awt.Shape[] var58 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    org.jfree.chart.plot.DefaultDrawingSupplier var59 = new org.jfree.chart.plot.DefaultDrawingSupplier(var18, var23, var50, var57, var58);
    java.awt.Stroke var60 = var59.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    java.awt.Stroke var27 = var11.getDomainCrosshairStroke();
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var29.setLabel("");
    org.jfree.chart.event.MarkerChangeEvent var32 = null;
    var29.notifyListeners(var32);
    var11.addDomainMarker((org.jfree.chart.plot.Marker)var29);
    var11.setRangeCrosshairValue(0.3125000000000002d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1);
    var0.zoomRange((-1.0d), 104.0d);
    java.util.Date var6 = var0.getMinimumDate();
    var0.setInverted(false);
    java.text.DateFormat var9 = var0.getDateFormatOverride();
    java.util.Date var10 = var0.getMaximumDate();
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("XY Plot");
    boolean var13 = var12.isNegativeArrowVisible();
    org.jfree.chart.axis.DateTickMarkPosition var14 = var12.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var18 = null;
    var17.setTickUnit(var18);
    java.text.DateFormat var20 = null;
    var17.setDateFormatOverride(var20);
    java.util.TimeZone var22 = var17.getTimeZone();
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("LengthConstraintType.FIXED", var22);
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var26 = null;
    var25.setTickUnit(var26);
    var25.configure();
    java.util.Date var29 = var25.getMinimumDate();
    java.util.TimeZone var30 = var25.getTimeZone();
    var23.setTimeZone(var30);
    var12.setTimeZone(var30);
    org.jfree.chart.axis.TickUnitSource var33 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var30);
    var0.setStandardTickUnits(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    int var2 = var1.getPassesRequired();
    double var3 = var1.getPieWRadius();
    var1.setLatestAngle((-1.7999999999999998d));
    double var6 = var1.getPieHRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var4 = var3.getLabel();
    org.jfree.chart.util.Layer var5 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    boolean var11 = var0.render(var7, var8, 1, var10);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var0.setRangeAxis(0, var13, true);
    org.jfree.chart.axis.ValueAxis var17 = var0.getRangeAxis(4);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var0.getDomainMarkers(15, var19);
    var0.setRangeCrosshairValue(0.0d, false);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.setAnchorValue(10.0d, false);
    java.lang.Object var28 = var24.clone();
    org.jfree.chart.util.SortOrder var29 = var24.getColumnRenderingOrder();
    var0.setRowRenderingOrder(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX((-1.0d));
    var0.setTranslateY(100.0d);
    boolean var5 = var0.getGenerateEntities();
    var0.setTranslateX(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    var19.removeLegend();
    int var26 = var19.getSubtitleCount();
    boolean var27 = var19.isBorderVisible();
    java.awt.Image var28 = var19.getBackgroundImage();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var31 = var19.createBufferedImage((-1), 5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.AxisSpace var14 = null;
    var11.setFixedRangeAxisSpace(var14, true);
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
    boolean var18 = var17.getSectionOutlinesVisible();
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
    java.awt.Font var22 = var20.getLabelFont();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
    java.lang.Object var24 = var23.clone();
    java.lang.String var25 = var23.getText();
    org.jfree.chart.util.RectangleInsets var26 = var23.getPadding();
    var17.setLabelPadding(var26);
    var17.setLabelLinkMargin(0.025d);
    boolean var30 = var11.equals((java.lang.Object)var17);
    java.awt.Stroke var31 = var11.getDomainCrosshairStroke();
    java.awt.Stroke var32 = var11.getDomainGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    java.lang.Object var32 = var11.clone();
    java.awt.Paint var33 = var11.getRangeTickBandPaint();
    boolean var34 = var11.isRangeCrosshairLockedOnData();
    boolean var35 = var11.isDomainZeroBaselineVisible();
    boolean var36 = var11.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var23 = var22.getLabelURL();
    var22.setNegativeArrowVisible(false);
    java.awt.Font var26 = var22.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
    org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var37 = var36.getPaint();
    var35.setOutlinePaint(var37);
    var28.setRangeGridlinePaint(var37);
    org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
    var11.setRangeAxisLocation(var40, false);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var45 = var44.getLabelURL();
    java.util.EventListener var46 = null;
    boolean var47 = var44.hasListener(var46);
    var44.setLabel("");
    boolean var50 = var44.isVerticalTickLabels();
    org.jfree.chart.axis.MarkerAxisBand var51 = null;
    var44.setMarkerBand(var51);
    var11.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var44);
    var44.setTickLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    int var2 = var1.getPassesRequired();
    double var3 = var1.getPieWRadius();
    double var4 = var1.getPieCenterX();
    var1.setLatestAngle(102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleEdge.RIGHT");
    java.text.NumberFormat var2 = var1.getNumberFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test136"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var2 = var1.getAlpha();
//     java.awt.Paint var3 = var1.getPaint();
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     boolean var5 = var4.getSectionOutlinesVisible();
//     double var6 = var4.getMaximumExplodePercent();
//     var4.setSectionOutlinesVisible(false);
//     var4.setLabelLinkMargin(10.0d);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
//     int var12 = var4.getPieIndex();
//     java.awt.Shape var13 = var4.getLegendItemShape();
//     org.jfree.chart.entity.ChartEntity var15 = new org.jfree.chart.entity.ChartEntity(var13, "ChartEntity: tooltip = ");
//     var15.setToolTipText("LengthConstraintType.FIXED");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var18 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var19 = null;
//     java.lang.String var20 = var15.getImageMapAreaTag(var18, var19);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test137"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    java.awt.Image var21 = null;
    var19.setBackgroundImage(var21);
    java.awt.Paint var23 = var19.getBackgroundPaint();
    java.awt.Image var24 = null;
    var19.setBackgroundImage(var24);
    java.awt.Image var26 = var19.getBackgroundImage();
    org.jfree.chart.plot.Plot var27 = var19.getPlot();
    int var28 = var19.getSubtitleCount();
    boolean var29 = var19.getAntiAlias();
    org.jfree.chart.plot.CategoryPlot var30 = var19.getCategoryPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test138"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    java.lang.Object var3 = var0.handleGetObject("");
    java.lang.Object var5 = var0.handleGetObject("VerticalAlignment.CENTER");
    java.util.Locale var6 = var0.getLocale();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test139"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.lang.String var6 = var4.getText();
    org.jfree.chart.util.RectangleInsets var7 = var4.getPadding();
    java.lang.String var8 = var4.getURLText();
    var4.setToolTipText("");
    double var11 = var4.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test140"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var2 = var1.getMaximumDate();
    java.text.DateFormat var3 = var1.getDateFormatOverride();
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var5.setLabel("");
    org.jfree.chart.event.MarkerChangeEvent var8 = null;
    var5.notifyListeners(var8);
    java.awt.Stroke var10 = var5.getStroke();
    var1.setAxisLineStroke(var10);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
    java.awt.Font var18 = var16.getLabelFont();
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
    java.lang.Object var20 = var19.clone();
    org.jfree.chart.block.BlockFrame var21 = var19.getFrame();
    org.jfree.chart.event.TitleChangeListener var22 = null;
    var19.removeChangeListener(var22);
    java.awt.geom.Rectangle2D var24 = var19.getBounds();
    org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var24, "", "");
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var13.valueToJava2D(1.0E-8d, var24, var28);
    org.jfree.chart.axis.DateTickMarkPosition var30 = var13.getTickMarkPosition();
    var1.setTickMarkPosition(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test141"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    int var16 = var11.getWeight();
    java.awt.Paint var17 = var11.getRangeGridlinePaint();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var20 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var21 = var20.getPaint();
    var19.setOutlinePaint(var21);
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartChangeEventType var24 = null;
    org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var19, var23, var24);
    org.jfree.chart.util.RectangleInsets var26 = var19.getLabelOffset();
    double var28 = var26.extendWidth(0.0d);
    var11.setInsets(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var31 = var11.getRangeAxisForDataset(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 6.0d);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test142"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    int var16 = var11.getWeight();
    org.jfree.chart.plot.PlotOrientation var17 = var11.getOrientation();
    boolean var18 = var11.isRangeZoomable();
    org.jfree.chart.util.RectangleEdge var20 = var11.getRangeAxisEdge((-1));
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.setWeight(100);
    org.jfree.data.category.CategoryDataset var25 = var21.getDataset(0);
    var21.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var28 = var27.getLabelURL();
    java.util.EventListener var29 = null;
    boolean var30 = var27.hasListener(var29);
    var27.setInverted(true);
    java.awt.Paint var33 = var27.getAxisLinePaint();
    org.jfree.data.Range var34 = var21.getDataRange((org.jfree.chart.axis.ValueAxis)var27);
    org.jfree.chart.util.RectangleEdge var35 = var21.getDomainAxisEdge();
    boolean var36 = var21.isRangeZoomable();
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
    var38.setFixedDimension((-1.0d));
    java.lang.Object var41 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var38);
    org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var43 = var42.getLabelURL();
    var42.setNegativeArrowVisible(false);
    java.awt.Font var46 = var42.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var42, var47);
    org.jfree.chart.axis.ValueAxis var50 = var48.getDomainAxis(100);
    org.jfree.chart.util.Layer var52 = null;
    java.util.Collection var53 = var48.getDomainMarkers((-1), var52);
    org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var56 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var57 = var56.getPaint();
    var55.setOutlinePaint(var57);
    var48.setRangeGridlinePaint(var57);
    org.jfree.chart.axis.AxisLocation var60 = var48.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var62 = var48.getRangeAxisForDataset(0);
    java.awt.Paint var63 = var48.getDomainCrosshairPaint();
    java.awt.Stroke var64 = var48.getDomainCrosshairStroke();
    java.awt.Paint var65 = var48.getRangeGridlinePaint();
    var21.setRangeGridlinePaint(var65);
    org.jfree.chart.plot.PolarPlot var67 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var68 = var67.getAngleTickUnit();
    boolean var69 = var67.isDomainZoomable();
    boolean var70 = var67.isRangeZoomable();
    org.jfree.data.general.DatasetChangeEvent var71 = null;
    var67.datasetChanged(var71);
    org.jfree.chart.axis.ValueAxis var73 = null;
    var67.setAxis(var73);
    org.jfree.chart.plot.PlotOrientation var75 = var67.getOrientation();
    var21.setOrientation(var75);
    var11.setOrientation(var75);
    org.jfree.chart.plot.PieLabelDistributor var79 = new org.jfree.chart.plot.PieLabelDistributor(15);
    boolean var80 = var75.equals((java.lang.Object)var79);
    var79.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test143"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    int var28 = var11.getRangeAxisCount();
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var31 = var30.getLabelURL();
    java.util.EventListener var32 = null;
    boolean var33 = var30.hasListener(var32);
    var30.setInverted(true);
    java.awt.Paint var36 = var30.getAxisLinePaint();
    var11.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var30);
    var11.configureDomainAxes();
    java.awt.Paint var39 = var11.getBackgroundPaint();
    var11.setDomainCrosshairValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test144"); }


    org.jfree.chart.util.ObjectList var2 = new org.jfree.chart.util.ObjectList(15);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.plot.PolarPlot var5 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var6 = var5.getAngleTickUnit();
    var5.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
    var5.setAxis((org.jfree.chart.axis.ValueAxis)var9);
    var5.setNoDataMessage("hi!");
    var2.set(100, (java.lang.Object)var5);
    var5.removeCornerTextItem("PieSection: -16777216, 100(XY Plot)");
    boolean var16 = var5.isAngleLabelsVisible();
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var18 = var17.getLabelURL();
    var17.setNegativeArrowVisible(false);
    java.awt.Font var21 = var17.getTickLabelFont();
    java.lang.Object var22 = var17.clone();
    var17.setRange(100.0d, 102.0d);
    org.jfree.chart.axis.NumberTickUnit var26 = var17.getTickUnit();
    var5.setAngleTickUnit((org.jfree.chart.axis.TickUnit)var26);
    java.awt.Paint var28 = var5.getAngleGridlinePaint();
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.setWeight(100);
    org.jfree.data.category.CategoryDataset var35 = var31.getDataset(0);
    var31.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var38 = var37.getLabelURL();
    java.util.EventListener var39 = null;
    boolean var40 = var37.hasListener(var39);
    var37.setInverted(true);
    java.awt.Paint var43 = var37.getAxisLinePaint();
    org.jfree.data.Range var44 = var31.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
    org.jfree.chart.util.RectangleEdge var45 = var31.getDomainAxisEdge();
    boolean var46 = var31.isRangeZoomable();
    var30.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var31);
    java.awt.Stroke var48 = var30.getOutlineStroke();
    org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(4.0d, var28, var48);
    org.jfree.chart.util.RectangleInsets var50 = var49.getLabelOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test145"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setCategoryMargin((-1.0d));
    float var4 = var1.getMaximumCategoryLabelWidthRatio();
    var1.setMaximumCategoryLabelWidthRatio(1.0f);
    var1.setCategoryLabelPositionOffset(0);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    var10.setFixedDimension((-1.0d));
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var15 = var14.getLabelURL();
    var14.setNegativeArrowVisible(false);
    java.awt.Font var18 = var14.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var19);
    org.jfree.chart.axis.ValueAxis var22 = var20.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var26 = var25.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    var27.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var31 = var30.getLabelURL();
    java.util.EventListener var32 = null;
    boolean var33 = var30.hasListener(var32);
    var30.setInverted(true);
    java.awt.Paint var36 = var30.getAxisLinePaint();
    var27.setTickMarkPaint(var36);
    var25.setPaint(var36);
    org.jfree.chart.util.Layer var39 = null;
    var20.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var25, var39);
    org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot();
    boolean var42 = var41.getSectionOutlinesVisible();
    var41.setLabelGap(0.0d);
    double var46 = var41.getExplodePercent((java.lang.Comparable)15);
    java.awt.Paint var47 = var41.getLabelLinkPaint();
    org.jfree.data.general.PieDataset var48 = null;
    var41.setDataset(var48);
    java.awt.Color var52 = java.awt.Color.getColor("hi!", (-16777216));
    int var53 = var52.getAlpha();
    java.awt.Color var54 = var52.darker();
    float[] var55 = null;
    float[] var56 = var52.getRGBComponents(var55);
    java.awt.Color var57 = var52.brighter();
    var41.setLabelLinkPaint((java.awt.Paint)var57);
    var20.setRangeZeroBaselinePaint((java.awt.Paint)var57);
    var1.setLabelPaint((java.awt.Paint)var57);
    int var61 = var57.getTransparency();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test146"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var3.setCategoryMargin((-1.0d));
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setWeight(100);
    org.jfree.data.category.CategoryDataset var10 = var6.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var11 = var6.getDomainAxis();
    java.awt.Paint var12 = var6.getRangeCrosshairPaint();
    var3.setTickLabelPaint(var12);
    var0.setAngleLabelPaint(var12);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
    java.awt.Font var18 = var16.getLabelFont();
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("", var18);
    boolean var20 = var0.equals((java.lang.Object)var19);
    java.awt.Font var21 = var19.getFont();
    var19.setExpandToFitSpace(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test147"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    java.awt.Paint var3 = null;
    var0.setSectionPaint((java.lang.Comparable)10, var3);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("0,0,1,1");
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var9 = var8.getCategoryMargin();
    var8.setCategoryLabelPositionOffset(0);
    boolean var12 = var6.equals((java.lang.Object)var8);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("XY Plot");
    boolean var15 = var14.isNegativeArrowVisible();
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var19 = var18.getLabelURL();
    java.util.EventListener var20 = null;
    boolean var21 = var18.hasListener(var20);
    var18.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot();
    var25.setBackgroundAlpha(1.0f);
    java.awt.Stroke var28 = var25.getOutlineStroke();
    var18.setAxisLineStroke(var28);
    java.awt.Shape var30 = var18.getLeftArrow();
    var17.setRightArrow(var30);
    java.lang.Object var32 = var17.clone();
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var35 = null;
    var34.setTickUnit(var35);
    var34.configure();
    java.util.Date var38 = var34.getMinimumDate();
    var17.setMaximumDate(var38);
    var14.setMinimumDate(var38);
    var6.setMaximumDate(var38);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.setWeight(100);
    org.jfree.data.category.CategoryDataset var46 = var42.getDataset(0);
    var42.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var48 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var49 = var48.getLabelURL();
    java.util.EventListener var50 = null;
    boolean var51 = var48.hasListener(var50);
    var48.setInverted(true);
    java.awt.Paint var54 = var48.getAxisLinePaint();
    org.jfree.data.Range var55 = var42.getDataRange((org.jfree.chart.axis.ValueAxis)var48);
    org.jfree.data.xy.XYDataset var56 = null;
    org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D();
    var57.setFixedDimension((-1.0d));
    java.lang.Object var60 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var57);
    org.jfree.chart.axis.NumberAxis3D var61 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var62 = var61.getLabelURL();
    var61.setNegativeArrowVisible(false);
    java.awt.Font var65 = var61.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
    org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var56, (org.jfree.chart.axis.ValueAxis)var57, (org.jfree.chart.axis.ValueAxis)var61, var66);
    org.jfree.data.Range var68 = var61.getDefaultAutoRange();
    org.jfree.data.Range var70 = org.jfree.data.Range.expandToInclude(var68, 90.0d);
    org.jfree.data.Range var72 = org.jfree.data.Range.expandToInclude(var70, 0.05d);
    var48.setRangeWithMargins(var72);
    org.jfree.chart.plot.PiePlot var74 = new org.jfree.chart.plot.PiePlot();
    java.awt.Stroke var76 = var74.getSectionOutlineStroke((java.lang.Comparable)(-1.0f));
    org.jfree.chart.plot.PiePlot var77 = new org.jfree.chart.plot.PiePlot();
    boolean var78 = var77.getSectionOutlinesVisible();
    java.awt.Paint var80 = null;
    var77.setSectionPaint((java.lang.Comparable)10, var80);
    org.jfree.chart.axis.NumberAxis3D var82 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var83 = var82.getStandardTickUnits();
    java.awt.Font var84 = var82.getLabelFont();
    var82.setLabel("");
    java.lang.String var87 = var82.getLabel();
    java.awt.Stroke var88 = var82.getAxisLineStroke();
    var77.setLabelOutlineStroke(var88);
    var74.setBaseSectionOutlineStroke(var88);
    java.awt.Paint var91 = var74.getBaseSectionOutlinePaint();
    var48.addChangeListener((org.jfree.chart.event.AxisChangeListener)var74);
    var74.setPieIndex((-1));
    var74.setPieIndex((-16777216));
    java.awt.Paint var97 = var74.getLabelLinkPaint();
    var0.setSectionPaint((java.lang.Comparable)var38, var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var87 + "' != '" + ""+ "'", var87.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test148"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var3.setAxisLineStroke(var13);
    java.awt.Shape var15 = var3.getLeftArrow();
    boolean var16 = var0.equals((java.lang.Object)var15);
    boolean var17 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.event.RendererChangeEvent var21 = null;
    var0.rendererChanged(var21);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var25.setCategoryMargin((-1.0d));
    float var28 = var25.getMaximumCategoryLabelWidthRatio();
    var25.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var32 = var31.getLabelURL();
    java.util.EventListener var33 = null;
    boolean var34 = var31.hasListener(var33);
    var31.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var37 = null;
    var31.setMarkerBand(var37);
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var23, var25, (org.jfree.chart.axis.ValueAxis)var31, var39);
    java.awt.Font var41 = var25.getTickLabelFont();
    var0.setDomainAxis(var25);
    org.jfree.chart.util.RectangleEdge var44 = var0.getDomainAxisEdge(0);
    double var45 = var0.getAnchorValue();
    org.jfree.chart.axis.ValueAxis var47 = var0.getRangeAxis(0);
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    var48.setAnchorValue(10.0d, false);
    java.lang.Object var52 = var48.clone();
    org.jfree.data.category.CategoryDataset var54 = null;
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var57 = var56.getCategoryMargin();
    org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D();
    var58.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var61 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var62 = var61.getLabelURL();
    java.util.EventListener var63 = null;
    boolean var64 = var61.hasListener(var63);
    var61.setInverted(true);
    java.awt.Paint var67 = var61.getAxisLinePaint();
    var58.setTickMarkPaint(var67);
    org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var54, var56, (org.jfree.chart.axis.ValueAxis)var58, var69);
    var48.setDomainAxis(255, var56, true);
    var56.removeCategoryLabelToolTip((java.lang.Comparable)10.0f);
    java.util.List var75 = var0.getCategoriesForAxis(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test149"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    java.awt.Font var6 = var4.getFont();
    java.lang.String var7 = var4.getURLText();
    boolean var8 = var4.getNotify();
    java.awt.Paint var9 = var4.getPaint();
    java.lang.Object var10 = var4.clone();
    var4.setText("PieSection: -16777216, 100(XY Plot)");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test150"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    int var2 = var1.getPassesRequired();
    double var3 = var1.getPieWRadius();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    var4.setMinimumArcAngleToDraw((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
    java.awt.Font var11 = var9.getLabelFont();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.block.BlockFrame var14 = var12.getFrame();
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var12.removeChangeListener(var15);
    java.awt.geom.Rectangle2D var17 = var12.getBounds();
    var4.setLegendItemShape((java.awt.Shape)var17);
    var1.setLinkArea(var17);
    int var20 = var1.getPassesRequired();
    java.awt.geom.Rectangle2D var21 = var1.getExplodedPieArea();
    var1.setPieCenterY(1.0d);
    org.jfree.chart.plot.PlotRenderingInfo var24 = var1.getInfo();
    double var25 = var1.getPieHRadius();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test151"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     var5.setDataset(var11);
//     java.awt.Paint var13 = var5.getAggregatedItemsPaint();
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
//     java.awt.Font var16 = var14.getLabelFont();
//     var14.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot();
//     var19.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var22 = var19.getOutlineStroke();
//     var14.setPlot((org.jfree.chart.plot.Plot)var19);
//     java.awt.Image var24 = var19.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var26 = null;
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19, (org.jfree.chart.block.Arrangement)var25, var26);
//     org.jfree.chart.LegendItemSource[] var28 = var27.getSources();
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets();
//     double var30 = var29.getRight();
//     double var32 = var29.calculateLeftOutset(90.0d);
//     var27.setLegendItemGraphicPadding(var29);
//     var5.setInsets(var29);
//     
//     // Checks the contract:  equals-hashcode on var1 and var15
//     assertTrue("Contract failed: equals-hashcode on var1 and var15", var1.equals(var15) ? var1.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var1
//     assertTrue("Contract failed: equals-hashcode on var15 and var1", var15.equals(var1) ? var15.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test152"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    boolean var5 = var0.isAxisLineVisible();
    org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var7 = var6.getAngleTickUnit();
    org.jfree.chart.renderer.PolarItemRenderer var8 = var6.getRenderer();
    java.awt.Paint var9 = var6.getAngleGridlinePaint();
    java.awt.Paint var10 = var6.getRadiusGridlinePaint();
    var0.setPlot((org.jfree.chart.plot.Plot)var6);
    boolean var12 = var0.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test153"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    org.jfree.chart.plot.PolarPlot var2 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var3 = var2.getAngleTickUnit();
    boolean var4 = var2.isDomainZoomable();
    org.jfree.data.xy.XYDataset var5 = null;
    var2.setDataset(var5);
    boolean var7 = var2.isRangeZoomable();
    org.jfree.data.xy.XYDataset var8 = var2.getDataset();
    java.awt.Stroke var9 = var2.getRadiusGridlineStroke();
    var0.setBaseSectionOutlineStroke(var9);
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test154"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getRangeMarkers(255, var7);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var0.setRenderer(11, var10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test155"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
    java.awt.Font var5 = var3.getLabelFont();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var5);
    java.lang.Object var7 = var6.clone();
    java.lang.String var8 = var6.getText();
    org.jfree.chart.util.RectangleInsets var9 = var6.getPadding();
    double var11 = var9.extendHeight(100.0d);
    var0.setPadding(var9);
    boolean var13 = var0.isEmpty();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(10.0d, 10.0d);
    org.jfree.chart.block.RectangleConstraint var19 = var17.toFixedHeight(12.0d);
    org.jfree.chart.util.Size2D var20 = var0.arrange(var14, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test156"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    var0.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var6 = var0.getDataset();
    java.awt.Paint var7 = var0.getRangeGridlinePaint();
    org.jfree.data.category.CategoryDataset var8 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test157"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    var0.setForegroundAlpha(10.0f);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(0);
    boolean var9 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test158"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
    java.awt.Font var35 = var33.getLabelFont();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
    double var40 = var38.extendHeight(10.0d);
    double var41 = var38.getTop();
    boolean var42 = var11.equals((java.lang.Object)var38);
    var11.setRangeZeroBaselineVisible(true);
    var11.setDomainCrosshairLockedOnData(false);
    org.jfree.chart.util.RectangleEdge var47 = var11.getDomainAxisEdge();
    java.awt.geom.Point2D var48 = var11.getQuadrantOrigin();
    org.jfree.data.xy.XYDataset var49 = null;
    var11.setDataset(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test159"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();
    double var2 = var0.getContentXOffset();
    java.lang.String var3 = var0.getID();
    java.util.List var4 = var0.getBlocks();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test160"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.labels.PieSectionLabelGenerator var1 = var0.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var2 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test161"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    java.util.List var2 = var1.getBlocks();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.setWeight(100);
    org.jfree.data.category.CategoryDataset var7 = var3.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var8 = var3.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var9 = var3.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var3.setRenderer(var10);
    var3.setBackgroundAlpha(1.0f);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var3.zoomRangeAxes(0.2d, var15, var16, true);
    org.jfree.chart.util.RectangleEdge var20 = var3.getRangeAxisEdge(1);
    boolean var21 = var1.equals((java.lang.Object)var20);
    double var22 = var1.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test162"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "", var3, "", "", "");
    var7.setLicenceText("");
    java.lang.String var10 = var7.toString();
    var7.setLicenceText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + " version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var10.equals(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test163"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleAnchor var16 = var13.getLegendItemGraphicLocation();
    org.jfree.chart.block.BlockContainer var17 = var13.getItemContainer();
    org.jfree.chart.util.RectangleAnchor var18 = var13.getLegendItemGraphicLocation();
    org.jfree.chart.util.RectangleEdge var19 = var13.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleEdge var20 = org.jfree.chart.util.RectangleEdge.opposite(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test164"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
//     boolean var2 = var0.isDomainZoomable();
//     boolean var3 = var0.isRangeZoomable();
//     java.awt.Font var4 = var0.getAngleLabelFont();
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     var0.setAxis(var5);
//     org.jfree.chart.renderer.PolarItemRenderer var7 = var0.getRenderer();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     var0.zoomRangeAxes(102.0d, var9, var12, false);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test165"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
//     var1.addFragment(var3);
//     org.jfree.chart.text.TextFragment var5 = var1.getLastTextFragment();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var11 = var10.getAlpha();
//     java.awt.Paint var12 = var10.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var13 = var10.getLabelOffsetType();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var17 = var16.getStandardTickUnits();
//     java.awt.Font var18 = var16.getLabelFont();
//     var15.setLabelFont(var18);
//     var10.setLabelFont(var18);
//     org.jfree.chart.text.TextAnchor var21 = var10.getLabelTextAnchor();
//     java.lang.String var22 = var21.toString();
//     java.lang.String var23 = var21.toString();
//     var5.draw(var6, 0.0f, 1.0f, var21, 10.0f, (-1.0f), 10.0d);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test166"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setWeight(100);
//     org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = var0.getRendererForDataset(var5);
//     org.jfree.chart.axis.ValueAxis var8 = var0.getRangeAxisForDataset(4);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     var10.setFixedDimension((-1.0d));
//     java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var15 = var14.getLabelURL();
//     var14.setNegativeArrowVisible(false);
//     java.awt.Font var18 = var14.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var19);
//     org.jfree.chart.axis.ValueAxis var22 = var20.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = var20.getRenderer();
//     java.awt.Paint var24 = var20.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var28 = var27.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var31 = var30.getAlpha();
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var33 = var27.removeRangeMarker((org.jfree.chart.plot.Marker)var30, var32);
//     org.jfree.chart.axis.AxisLocation var34 = var27.getRangeAxisLocation();
//     java.util.List var35 = var27.getAnnotations();
//     var20.drawRangeTickBands(var25, var26, var35);
//     var20.clearRangeAxes();
//     java.awt.Paint var38 = var20.getRangeZeroBaselinePaint();
//     int var39 = var20.getSeriesCount();
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     org.jfree.chart.util.RectangleInsets var41 = var40.getItemLabelPadding();
//     var0.setInsets(var41, false);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var45.setLabel("");
//     org.jfree.chart.event.MarkerChangeEvent var48 = null;
//     var45.notifyListeners(var48);
//     java.awt.Stroke var50 = var45.getStroke();
//     org.jfree.chart.util.RectangleAnchor var51 = var45.getLabelAnchor();
//     java.lang.String var52 = var45.getLabel();
//     org.jfree.chart.util.Layer var53 = null;
//     boolean var54 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var45, var53);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test167"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     double var3 = var2.getCategoryMargin();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     var4.setFixedDimension((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var8 = var7.getLabelURL();
//     java.util.EventListener var9 = null;
//     boolean var10 = var7.hasListener(var9);
//     var7.setInverted(true);
//     java.awt.Paint var13 = var7.getAxisLinePaint();
//     var4.setTickMarkPaint(var13);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, var15);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     var19.setFixedDimension((-1.0d));
//     java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var24 = var23.getLabelURL();
//     var23.setNegativeArrowVisible(false);
//     java.awt.Font var27 = var23.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     org.jfree.chart.axis.ValueAxis var31 = var29.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = var29.getRenderer();
//     java.awt.Paint var33 = var29.getDomainZeroBaselinePaint();
//     boolean var34 = var29.isDomainCrosshairLockedOnData();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     var36.setFixedDimension((-1.0d));
//     java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var36);
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var41 = var40.getLabelURL();
//     var40.setNegativeArrowVisible(false);
//     java.awt.Font var44 = var40.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var45);
//     org.jfree.chart.axis.ValueAxis var48 = var46.getDomainAxis(100);
//     org.jfree.chart.util.Layer var50 = null;
//     java.util.Collection var51 = var46.getDomainMarkers((-1), var50);
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var55 = var54.getPaint();
//     var53.setOutlinePaint(var55);
//     var46.setRangeGridlinePaint(var55);
//     org.jfree.chart.axis.AxisLocation var58 = var46.getDomainAxisLocation();
//     var29.setRangeAxisLocation(var58, false);
//     var16.setDomainAxisLocation(0, var58, false);
//     org.jfree.chart.axis.CategoryAxis var64 = var16.getDomainAxis((-16777216));
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     java.lang.String var67 = var66.getLabel();
//     java.lang.Object var68 = var66.clone();
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var71 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var72 = var71.getPaint();
//     var70.setOutlinePaint(var72);
//     double var74 = var70.getValue();
//     org.jfree.chart.axis.NumberAxis3D var75 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var76 = var75.getStandardTickUnits();
//     java.awt.Font var77 = var75.getLabelFont();
//     var75.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var80 = new org.jfree.chart.plot.MultiplePiePlot();
//     var80.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var83 = var80.getOutlineStroke();
//     var75.setPlot((org.jfree.chart.plot.Plot)var80);
//     java.awt.Image var85 = var80.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var86 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var87 = null;
//     org.jfree.chart.title.LegendTitle var88 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var80, (org.jfree.chart.block.Arrangement)var86, var87);
//     org.jfree.chart.util.RectangleInsets var89 = var88.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var90 = var88.getLegendItemGraphicAnchor();
//     var70.setLabelAnchor(var90);
//     var66.setLabelAnchor(var90);
//     org.jfree.chart.util.Layer var93 = null;
//     boolean var94 = var16.removeDomainMarker((org.jfree.chart.plot.Marker)var66, var93);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test168"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    double var1 = var0.getOuterSeparatorExtension();
    double var2 = var0.getLabelGap();
    var0.setBackgroundAlpha(2.0f);
    boolean var5 = var0.getSeparatorsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test169"); }


    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
    java.awt.Font var5 = var3.getLabelFont();
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var8 = var7.getAlpha();
    java.awt.Paint var9 = var7.getPaint();
    org.jfree.chart.text.TextLine var10 = new org.jfree.chart.text.TextLine("", var5, var9);
    var1.setAggregatedItemsPaint(var9);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var15 = var14.getCategoryMargin();
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    var16.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var20 = var19.getLabelURL();
    java.util.EventListener var21 = null;
    boolean var22 = var19.hasListener(var21);
    var19.setInverted(true);
    java.awt.Paint var25 = var19.getAxisLinePaint();
    var16.setTickMarkPaint(var25);
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var12, var14, (org.jfree.chart.axis.ValueAxis)var16, var27);
    java.awt.Stroke var29 = var28.getRangeGridlineStroke();
    java.awt.Paint var30 = null;
    org.jfree.chart.plot.MultiplePiePlot var31 = new org.jfree.chart.plot.MultiplePiePlot();
    var31.setBackgroundAlpha(1.0f);
    java.awt.Stroke var34 = var31.getOutlineStroke();
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(102.0d, var9, var29, var30, var34, 0.0f);
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(10.0d);
    var38.setValue((-1.0d));
    org.jfree.chart.text.TextAnchor var41 = var38.getLabelTextAnchor();
    var36.setLabelTextAnchor(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test170"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin((-1.0d));
    float var5 = var2.getMaximumCategoryLabelWidthRatio();
    var2.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var9 = var8.getLabelURL();
    java.util.EventListener var10 = null;
    boolean var11 = var8.hasListener(var10);
    var8.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var14 = null;
    var8.setMarkerBand(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var8, var16);
    var2.removeCategoryLabelToolTip((java.lang.Comparable)1.0f);
    double var20 = var2.getLowerMargin();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var25 = var24.getLabelURL();
    java.util.EventListener var26 = null;
    boolean var27 = var24.hasListener(var26);
    var24.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var31 = new org.jfree.chart.plot.MultiplePiePlot();
    var31.setBackgroundAlpha(1.0f);
    java.awt.Stroke var34 = var31.getOutlineStroke();
    var24.setAxisLineStroke(var34);
    java.awt.Shape var36 = var24.getLeftArrow();
    boolean var37 = var21.equals((java.lang.Object)var36);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.entity.PieSectionEntity var44 = new org.jfree.chart.entity.PieSectionEntity(var36, var38, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
    var44.setPieIndex((-16777216));
    java.lang.String var47 = var44.toString();
    java.awt.Shape var48 = var44.getArea();
    java.lang.String var49 = var44.toString();
    org.jfree.data.general.PieDataset var50 = null;
    var44.setDataset(var50);
    boolean var52 = var2.equals((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "PieSection: -16777216, 100(XY Plot)"+ "'", var47.equals("PieSection: -16777216, 100(XY Plot)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "PieSection: -16777216, 100(XY Plot)"+ "'", var49.equals("PieSection: -16777216, 100(XY Plot)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test171"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.title.LegendTitle var26 = var19.getLegend(100);
    java.lang.Object var27 = var19.clone();
    java.awt.Image var28 = var19.getBackgroundImage();
    org.jfree.chart.title.LegendTitle var30 = var19.getLegend(1);
    boolean var31 = var19.getAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test172"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var3 = var2.getPaint();
    var1.setOutlinePaint(var3);
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(var3);
    java.awt.Paint var6 = var5.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test173"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    var0.setBackgroundAlpha(1.0f);
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    double var5 = var0.getLimit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test174"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.block.BlockContainer var15 = var13.getItemContainer();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setWeight(100);
    org.jfree.data.category.CategoryDataset var20 = var16.getDataset(0);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = var16.getRendererForDataset(var21);
    org.jfree.chart.axis.ValueAxis var24 = var16.getRangeAxisForDataset(4);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
    var26.setFixedDimension((-1.0d));
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var26);
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var31 = var30.getLabelURL();
    var30.setNegativeArrowVisible(false);
    java.awt.Font var34 = var30.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var30, var35);
    org.jfree.chart.axis.ValueAxis var38 = var36.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = var36.getRenderer();
    java.awt.Paint var40 = var36.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var41 = null;
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
    boolean var44 = var43.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var47 = var46.getAlpha();
    org.jfree.chart.util.Layer var48 = null;
    boolean var49 = var43.removeRangeMarker((org.jfree.chart.plot.Marker)var46, var48);
    org.jfree.chart.axis.AxisLocation var50 = var43.getRangeAxisLocation();
    java.util.List var51 = var43.getAnnotations();
    var36.drawRangeTickBands(var41, var42, var51);
    var36.clearRangeAxes();
    java.awt.Paint var54 = var36.getRangeZeroBaselinePaint();
    int var55 = var36.getSeriesCount();
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36);
    org.jfree.chart.util.RectangleInsets var57 = var56.getItemLabelPadding();
    var16.setInsets(var57, false);
    double var61 = var57.calculateBottomInset((-2.1799999999999997d));
    var13.setPadding(var57);
    org.jfree.chart.util.UnitType var63 = var57.getUnitType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test175"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", (-16777216));
    int var3 = var2.getAlpha();
    java.awt.Color var4 = var2.darker();
    int var5 = var4.getTransparency();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test176"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setUpperMargin(0.2d);
    var1.setUpperMargin(0.0d);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.ValueAxis var10 = var6.getRangeAxisForDataset(0);
    var6.setAnchorValue(9.223372036854776E18d, false);
    boolean var14 = var6.isRangeCrosshairLockedOnData();
    var1.setPlot((org.jfree.chart.plot.Plot)var6);
    var1.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test177"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    boolean var1 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var4 = var3.getAlpha();
    org.jfree.chart.util.Layer var5 = null;
    boolean var6 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var3, var5);
    org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation();
    boolean var8 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis var9 = var0.getDomainAxis();
    boolean var10 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test178"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var5 = var4.getLabelURL();
    java.util.EventListener var6 = null;
    boolean var7 = var4.hasListener(var6);
    var4.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot();
    var11.setBackgroundAlpha(1.0f);
    java.awt.Stroke var14 = var11.getOutlineStroke();
    var4.setAxisLineStroke(var14);
    java.awt.Shape var16 = var4.getLeftArrow();
    boolean var17 = var1.equals((java.lang.Object)var16);
    java.util.List var18 = var1.getAnnotations();
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    var1.setRenderer(var19);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("Multiple Pie Plot", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.LegendTitle var22 = var21.getLegend();
    java.awt.Paint var23 = var22.getItemPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test179"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var11.setFixedRangeAxisSpace(var28);
    org.jfree.chart.axis.AxisSpace var30 = null;
    var11.setFixedRangeAxisSpace(var30);
    var11.setDomainZeroBaselineVisible(false);
    java.awt.Paint var34 = var11.getRangeTickBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test180"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = var0.getRendererForDataset(var5);
    org.jfree.chart.util.RectangleEdge var7 = var0.getRangeAxisEdge();
    org.jfree.data.category.CategoryDataset var9 = var0.getDataset(1);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    org.jfree.chart.event.MarkerChangeEvent var13 = null;
    var10.markerChanged(var13);
    org.jfree.chart.LegendItemCollection var15 = var10.getLegendItems();
    var0.setFixedLegendItems(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test181"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(15);
    var1.clear();
    java.lang.Object var4 = var1.get(10);
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
    java.awt.Font var11 = var9.getLabelFont();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle("", var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var11);
    java.awt.Paint var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setWeight(100);
    org.jfree.data.category.CategoryDataset var20 = var16.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var21 = var16.getDomainAxis();
    java.awt.Paint var22 = var16.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("", var11, (org.jfree.chart.plot.Plot)var16, false);
    boolean var25 = var24.getAntiAlias();
    java.awt.Image var26 = null;
    var24.setBackgroundImage(var26);
    java.awt.Paint var28 = var24.getBackgroundPaint();
    java.awt.Image var29 = null;
    var24.setBackgroundImage(var29);
    java.awt.Image var31 = var24.getBackgroundImage();
    org.jfree.chart.plot.Plot var32 = var24.getPlot();
    int var33 = var24.getSubtitleCount();
    org.jfree.chart.plot.CategoryPlot var34 = var24.getCategoryPlot();
    int var35 = var1.indexOf((java.lang.Object)var24);
    java.lang.Object var37 = null;
    var1.set(0, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test182"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    var2.setFixedDimension((-1.0d));
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    var6.setNegativeArrowVisible(false);
    java.awt.Font var10 = var6.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var11);
    org.jfree.data.Range var13 = var6.getDefaultAutoRange();
    org.jfree.data.Range var14 = var6.getRange();
    double var15 = var14.getLength();
    double var16 = var14.getLowerBound();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test183"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
    java.awt.Font var35 = var33.getLabelFont();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
    double var40 = var38.extendHeight(10.0d);
    double var41 = var38.getTop();
    boolean var42 = var11.equals((java.lang.Object)var38);
    double var44 = var38.trimWidth(2.2d);
    double var46 = var38.calculateRightInset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.20000000000000018d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.0d);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test184"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
//     java.awt.Paint var16 = var11.getBackgroundPaint();
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     var18.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var21 = var18.getLabelOffset();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     var23.setFixedDimension((-1.0d));
//     java.lang.Object var26 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var28 = var27.getLabelURL();
//     var27.setNegativeArrowVisible(false);
//     java.awt.Font var31 = var27.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var32);
//     org.jfree.chart.axis.ValueAxis var35 = var33.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = var33.getRenderer();
//     java.awt.Paint var37 = var33.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var41 = var40.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var44 = var43.getAlpha();
//     org.jfree.chart.util.Layer var45 = null;
//     boolean var46 = var40.removeRangeMarker((org.jfree.chart.plot.Marker)var43, var45);
//     org.jfree.chart.axis.AxisLocation var47 = var40.getRangeAxisLocation();
//     java.util.List var48 = var40.getAnnotations();
//     var33.drawRangeTickBands(var38, var39, var48);
//     int var50 = var33.getRangeAxisCount();
//     var18.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var33);
//     boolean var52 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var18);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test185"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    boolean var16 = var11.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var23 = var22.getLabelURL();
    var22.setNegativeArrowVisible(false);
    java.awt.Font var26 = var22.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
    org.jfree.chart.axis.ValueAxis var30 = var28.getDomainAxis(100);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var28.getDomainMarkers((-1), var32);
    org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var37 = var36.getPaint();
    var35.setOutlinePaint(var37);
    var28.setRangeGridlinePaint(var37);
    org.jfree.chart.axis.AxisLocation var40 = var28.getDomainAxisLocation();
    var11.setRangeAxisLocation(var40, false);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var45 = var44.getLabelURL();
    java.util.EventListener var46 = null;
    boolean var47 = var44.hasListener(var46);
    var44.setLabel("");
    boolean var50 = var44.isVerticalTickLabels();
    org.jfree.chart.axis.MarkerAxisBand var51 = null;
    var44.setMarkerBand(var51);
    var11.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var44);
    java.awt.Stroke var54 = var44.getAxisLineStroke();
    org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var56 = var55.getLabelURL();
    var55.setNegativeArrowVisible(false);
    java.awt.Font var59 = var55.getTickLabelFont();
    java.lang.Object var60 = var55.clone();
    var55.setRange(100.0d, 102.0d);
    var55.setLowerMargin(0.20000000000000018d);
    java.awt.Shape var66 = var55.getDownArrow();
    var44.setLeftArrow(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test186"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(10.0d, 1.0d, 0.0d, (-1.0d));
    org.jfree.chart.util.RectangleInsets var6 = var5.getInsets();
    var0.setFrame((org.jfree.chart.block.BlockFrame)var5);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.VerticalAlignment var10 = var9.getVerticalAlignment();
    org.jfree.chart.util.HorizontalAlignment var11 = var9.getTextAlignment();
    var0.setHorizontalAlignment(var11);
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var16 = var15.getStandardTickUnits();
    java.awt.Font var17 = var15.getLabelFont();
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("", var17);
    java.lang.Object var19 = var18.clone();
    org.jfree.chart.util.VerticalAlignment var20 = var18.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var13, var20, (-1.0d), 1.0d);
    org.jfree.chart.block.FlowArrangement var26 = new org.jfree.chart.block.FlowArrangement(var11, var20, 92.0d, (-0.05d));
    java.lang.String var27 = var11.toString();
    org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.VerticalAlignment var30 = var29.getVerticalAlignment();
    java.lang.String var31 = var30.toString();
    org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var11, var30, (-0.18d), 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var27.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "VerticalAlignment.CENTER"+ "'", var31.equals("VerticalAlignment.CENTER"));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test187"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getHeightConstraintType();
    java.lang.Object var4 = null;
    boolean var5 = var3.equals(var4);
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "LengthConstraintType.FIXED"+ "'", var6.equals("LengthConstraintType.FIXED"));

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test188"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.block.BlockFrame var6 = var4.getFrame();
    var4.setText("hi!");
    org.jfree.chart.util.RectangleEdge var9 = var4.getPosition();
    org.jfree.chart.block.BlockFrame var10 = var4.getFrame();
    java.awt.Paint var11 = var4.getPaint();
    org.jfree.chart.block.BlockFrame var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setFrame(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test189"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.LEFT", "UnitType.ABSOLUTE", "0,0,1,1", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test190"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setCategoryMargin((-1.0d));
    float var5 = var2.getMaximumCategoryLabelWidthRatio();
    var2.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var9 = var8.getLabelURL();
    java.util.EventListener var10 = null;
    boolean var11 = var8.hasListener(var10);
    var8.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var14 = null;
    var8.setMarkerBand(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var8, var16);
    java.awt.Font var18 = var2.getTickLabelFont();
    boolean var19 = var2.isAxisLineVisible();
    int var20 = var2.getCategoryLabelPositionOffset();
    int var21 = var2.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test191"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var5.setInfo("");
    org.jfree.chart.ui.Library[] var8 = var5.getOptionalLibraries();
    org.jfree.chart.ui.ProjectInfo var9 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var10 = var9.getVersion();
    java.util.List var11 = null;
    var9.setContributors(var11);
    java.lang.String var13 = var9.toString();
    java.util.List var14 = var9.getContributors();
    var5.addLibrary((org.jfree.chart.ui.Library)var9);
    var9.setName("Range[0.0,1.05]");
    var9.setName("{0}");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var13.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test192"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var4 = var3.getLabel();
    org.jfree.chart.util.Layer var5 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    boolean var11 = var0.render(var7, var8, 1, var10);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var0.setRangeAxis(0, var13, true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var16};
    var0.setRenderers(var17);
    org.jfree.chart.plot.Plot var19 = var0.getRootPlot();
    java.awt.Paint var20 = var0.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var21 = var0.getLegendItems();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var24 = var23.getCategoryMargin();
    org.jfree.chart.ChartColor var28 = new org.jfree.chart.ChartColor(0, 255, 4);
    var23.setTickLabelPaint((java.awt.Paint)var28);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    org.jfree.chart.plot.PiePlotState var31 = new org.jfree.chart.plot.PiePlotState(var30);
    int var32 = var31.getPassesRequired();
    org.jfree.chart.plot.PlotRenderingInfo var33 = var31.getInfo();
    double var34 = var31.getPieWRadius();
    boolean var35 = var23.equals((java.lang.Object)var34);
    java.util.List var36 = var0.getCategoriesForAxis(var23);
    org.jfree.chart.util.RectangleEdge var37 = var0.getRangeAxisEdge();
    org.jfree.chart.event.RendererChangeEvent var38 = null;
    var0.rendererChanged(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test193"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    boolean var2 = var1.getSectionOutlinesVisible();
    java.awt.Paint var4 = null;
    var1.setSectionPaint((java.lang.Comparable)10, var4);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    var6.setLabel("");
    java.lang.String var11 = var6.getLabel();
    java.awt.Stroke var12 = var6.getAxisLineStroke();
    var1.setLabelOutlineStroke(var12);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setWeight(100);
    org.jfree.data.category.CategoryDataset var18 = var14.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var19 = var14.getDomainAxis();
    java.awt.Paint var20 = var14.getRangeCrosshairPaint();
    var1.setLabelPaint(var20);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var24 = var23.getAlpha();
    java.awt.Paint var25 = var23.getPaint();
    org.jfree.chart.util.LengthAdjustmentType var26 = var23.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var27 = null;
    var23.notifyListeners(var27);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var30 = var29.getLabelURL();
    java.util.EventListener var31 = null;
    boolean var32 = var29.hasListener(var31);
    var29.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var36 = new org.jfree.chart.plot.MultiplePiePlot();
    var36.setBackgroundAlpha(1.0f);
    java.awt.Stroke var39 = var36.getOutlineStroke();
    var29.setAxisLineStroke(var39);
    var23.setStroke(var39);
    var1.setBaseSectionOutlineStroke(var39);
    var0.setSeparatorStroke(var39);
    double var44 = var0.getSectionDepth();
    var0.setSeparatorsVisible(false);
    java.awt.Paint var47 = var0.getSeparatorPaint();
    var0.setSeparatorsVisible(true);
    boolean var50 = var0.getSeparatorsVisible();
    java.awt.Stroke var51 = var0.getSeparatorStroke();
    org.jfree.chart.labels.PieSectionLabelGenerator var52 = var0.getLegendLabelToolTipGenerator();
    var0.setBackgroundImageAlpha(1.0f);
    java.awt.Paint var56 = var0.getSectionOutlinePaint((java.lang.Comparable)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test194"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDrawSharedDomainAxis(false);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.axis.CategoryAxis var6 = var0.getDomainAxis((-8323073));
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var0.handleClick(15, 5, var9);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test195"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setFixedDimension((-1.0d));
//     java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var6 = var5.getLabelURL();
//     var5.setNegativeArrowVisible(false);
//     java.awt.Font var9 = var5.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
//     org.jfree.chart.util.Layer var15 = null;
//     java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var20 = var19.getPaint();
//     var18.setOutlinePaint(var20);
//     var11.setRangeGridlinePaint(var20);
//     org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
//     org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
//     java.awt.Paint var26 = var11.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var28 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var27};
//     var11.setRenderers(var28);
//     var11.clearRangeAxes();
//     var11.configureRangeAxes();
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var35 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var36 = var35.getPaint();
//     var34.setOutlinePaint(var36);
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var40 = var39.getAlpha();
//     java.awt.Paint var41 = var39.getPaint();
//     org.jfree.chart.util.LengthAdjustmentType var42 = var39.getLabelOffsetType();
//     var34.setLabelOffsetType(var42);
//     org.jfree.chart.util.Layer var44 = null;
//     boolean var45 = var11.removeDomainMarker((-104858), (org.jfree.chart.plot.Marker)var34, var44);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test196"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
//     boolean var8 = var4.equals((java.lang.Object)var7);
//     java.lang.String var9 = var7.getLabelFormat();
//     java.text.AttributedString var11 = null;
//     var7.setAttributedLabel(100, var11);
//     java.lang.String var13 = var7.getLabelFormat();
//     java.lang.Object var14 = var7.clone();
//     java.text.NumberFormat var15 = var7.getNumberFormat();
//     java.lang.Object var16 = var7.clone();
//     
//     // Checks the contract:  equals-hashcode on var14 and var16
//     assertTrue("Contract failed: equals-hashcode on var14 and var16", var14.equals(var16) ? var14.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var14
//     assertTrue("Contract failed: equals-hashcode on var16 and var14", var16.equals(var14) ? var16.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test197"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicAnchor();
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
    java.awt.Font var17 = var13.getItemFont();
    org.jfree.chart.util.RectangleAnchor var18 = var13.getLegendItemGraphicLocation();
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var21 = var20.getLabel();
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    var23.setFixedDimension((-1.0d));
    java.lang.Object var26 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var28 = var27.getLabelURL();
    var27.setNegativeArrowVisible(false);
    java.awt.Font var31 = var27.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var32);
    org.jfree.chart.axis.ValueAxis var35 = var33.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = var33.getRenderer();
    java.awt.Paint var37 = var33.getDomainZeroBaselinePaint();
    boolean var38 = var33.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
    var40.setFixedDimension((-1.0d));
    java.lang.Object var43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var40);
    org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var45 = var44.getLabelURL();
    var44.setNegativeArrowVisible(false);
    java.awt.Font var48 = var44.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var39, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.axis.ValueAxis)var44, var49);
    org.jfree.chart.axis.ValueAxis var52 = var50.getDomainAxis(100);
    org.jfree.chart.util.Layer var54 = null;
    java.util.Collection var55 = var50.getDomainMarkers((-1), var54);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var58 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var59 = var58.getPaint();
    var57.setOutlinePaint(var59);
    var50.setRangeGridlinePaint(var59);
    org.jfree.chart.axis.AxisLocation var62 = var50.getDomainAxisLocation();
    var33.setRangeAxisLocation(var62, false);
    org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var67 = var66.getLabelURL();
    java.util.EventListener var68 = null;
    boolean var69 = var66.hasListener(var68);
    var66.setLabel("");
    boolean var72 = var66.isVerticalTickLabels();
    org.jfree.chart.axis.MarkerAxisBand var73 = null;
    var66.setMarkerBand(var73);
    var33.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var66);
    org.jfree.chart.util.RectangleInsets var76 = var33.getAxisOffset();
    var20.setLabelOffset(var76);
    org.jfree.chart.util.RectangleInsets var78 = var20.getLabelOffset();
    var13.setLegendItemGraphicPadding(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test198"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    var0.setNoDataMessage("hi!");
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setWeight(100);
    org.jfree.data.category.CategoryDataset var12 = var8.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var13 = var8.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var14 = var8.getDatasetRenderingOrder();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.setWeight(100);
    org.jfree.data.category.CategoryDataset var19 = var15.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var21 = var15.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
    java.awt.Font var26 = var24.getLabelFont();
    var23.setLabelFont(var26);
    java.util.List var28 = var15.getCategoriesForAxis(var23);
    org.jfree.chart.axis.CategoryAxis[] var29 = new org.jfree.chart.axis.CategoryAxis[] { var23};
    var8.setDomainAxes(var29);
    boolean var31 = var0.equals((java.lang.Object)var29);
    java.lang.String var32 = var0.getPlotType();
    org.jfree.chart.plot.PlotRenderingInfo var34 = null;
    java.awt.geom.Point2D var35 = null;
    var0.zoomDomainAxes(0.2d, var34, var35);
    java.awt.Paint var37 = null;
    var0.setOutlinePaint(var37);
    org.jfree.chart.plot.Plot var39 = var0.getRootPlot();
    org.jfree.chart.LegendItemCollection var40 = var0.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "Polar Plot"+ "'", var32.equals("Polar Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test199"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("VerticalAlignment.CENTER");
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    boolean var4 = var3.getSectionOutlinesVisible();
    var3.setMinimumArcAngleToDraw((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var9 = var8.getStandardTickUnits();
    java.awt.Font var10 = var8.getLabelFont();
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle("", var10);
    java.lang.Object var12 = var11.clone();
    org.jfree.chart.block.BlockFrame var13 = var11.getFrame();
    org.jfree.chart.event.TitleChangeListener var14 = null;
    var11.removeChangeListener(var14);
    java.awt.geom.Rectangle2D var16 = var11.getBounds();
    var3.setLegendItemShape((java.awt.Shape)var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    var19.setFixedDimension((-1.0d));
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var24 = var23.getLabelURL();
    var23.setNegativeArrowVisible(false);
    java.awt.Font var27 = var23.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
    org.jfree.chart.axis.ValueAxis var31 = var29.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = var29.getRenderer();
    java.awt.Paint var33 = var29.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    boolean var37 = var36.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var40 = var39.getAlpha();
    org.jfree.chart.util.Layer var41 = null;
    boolean var42 = var36.removeRangeMarker((org.jfree.chart.plot.Marker)var39, var41);
    org.jfree.chart.axis.AxisLocation var43 = var36.getRangeAxisLocation();
    java.util.List var44 = var36.getAnnotations();
    var29.drawRangeTickBands(var34, var35, var44);
    var29.clearRangeAxes();
    java.awt.Paint var47 = var29.getRangeZeroBaselinePaint();
    int var48 = var29.getSeriesCount();
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
    org.jfree.chart.util.RectangleEdge var51 = var29.getRangeAxisEdge((-16777216));
    double var52 = var1.java2DToValue(104.0d, var16, var51);
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("0,0,1,1");
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var57 = var56.getCategoryMargin();
    var56.setCategoryLabelPositionOffset(0);
    boolean var60 = var54.equals((java.lang.Object)var56);
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis("XY Plot");
    boolean var63 = var62.isNegativeArrowVisible();
    org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var67 = var66.getLabelURL();
    java.util.EventListener var68 = null;
    boolean var69 = var66.hasListener(var68);
    var66.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var73 = new org.jfree.chart.plot.MultiplePiePlot();
    var73.setBackgroundAlpha(1.0f);
    java.awt.Stroke var76 = var73.getOutlineStroke();
    var66.setAxisLineStroke(var76);
    java.awt.Shape var78 = var66.getLeftArrow();
    var65.setRightArrow(var78);
    java.lang.Object var80 = var65.clone();
    org.jfree.chart.axis.DateAxis var82 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var83 = null;
    var82.setTickUnit(var83);
    var82.configure();
    java.util.Date var86 = var82.getMinimumDate();
    var65.setMaximumDate(var86);
    var62.setMinimumDate(var86);
    var54.setMaximumDate(var86);
    org.jfree.chart.axis.Timeline var90 = var54.getTimeline();
    var1.setTimeline(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 9.223372036854776E18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test200"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1);
    var0.zoomRange((-1.0d), 104.0d);
    boolean var6 = var0.isTickMarksVisible();
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    boolean var8 = var7.getSectionOutlinesVisible();
    double var9 = var7.getMaximumExplodePercent();
    var7.setSectionOutlinesVisible(false);
    var7.setLabelLinkMargin(10.0d);
    org.jfree.chart.plot.PieLabelDistributor var15 = new org.jfree.chart.plot.PieLabelDistributor(15);
    java.lang.String var16 = var15.toString();
    var15.clear();
    var7.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor)var15);
    var15.clear();
    boolean var20 = var0.equals((java.lang.Object)var15);
    var15.sort();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test201"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var7);
    java.awt.Paint var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setWeight(100);
    org.jfree.data.category.CategoryDataset var16 = var12.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var17 = var12.getDomainAxis();
    java.awt.Paint var18 = var12.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", var7, (org.jfree.chart.plot.Plot)var12, false);
    boolean var21 = var20.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var22 = null;
    var20.removeProgressListener(var22);
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var20, (-16777216), 15);
    org.jfree.chart.plot.CategoryPlot var27 = var20.getCategoryPlot();
    java.awt.Image var28 = var20.getBackgroundImage();
    float var29 = var20.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.5f);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test202"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var4 = null;
    var3.setTickUnit(var4);
    java.text.DateFormat var6 = null;
    var3.setDateFormatOverride(var6);
    java.util.TimeZone var8 = var3.getTimeZone();
    var1.setTimeZone(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test203"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var4 = var3.getLabel();
    org.jfree.chart.util.Layer var5 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    boolean var11 = var0.render(var7, var8, 1, var10);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var0.setRangeAxis(0, var13, true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var16};
    var0.setRenderers(var17);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var21 = var20.getLabelURL();
    java.util.EventListener var22 = null;
    boolean var23 = var20.hasListener(var22);
    var20.setLabel("");
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var20, false);
    org.jfree.data.RangeType var28 = var20.getRangeType();
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
    var30.setFixedDimension((-1.0d));
    java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
    org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var35 = var34.getLabelURL();
    var34.setNegativeArrowVisible(false);
    java.awt.Font var38 = var34.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
    org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var29, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var34, var39);
    org.jfree.data.Range var41 = var34.getDefaultAutoRange();
    org.jfree.data.Range var43 = org.jfree.data.Range.expandToInclude(var41, 90.0d);
    var20.setRangeWithMargins(var41);
    boolean var45 = var20.isNegativeArrowVisible();
    double var46 = var20.getLowerBound();
    var20.zoomRange(1.0d, 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-0.05d));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test204"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    var0.setLabelLinkMargin(10.0d);
    java.awt.Paint var7 = var0.getShadowPaint();
    java.awt.Paint var8 = var0.getBaseSectionPaint();
    java.awt.Paint var9 = var0.getLabelPaint();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    var10.setFixedDimension((-1.0d));
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var10);
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var19 = var18.getStandardTickUnits();
    java.awt.Font var20 = var18.getLabelFont();
    org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("", var20);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("", var20);
    java.awt.Paint var23 = null;
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var20, var23);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    var25.setWeight(100);
    org.jfree.data.category.CategoryDataset var29 = var25.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var30 = var25.getDomainAxis();
    java.awt.Paint var31 = var25.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("", var20, (org.jfree.chart.plot.Plot)var25, false);
    boolean var34 = var33.getAntiAlias();
    org.jfree.chart.event.ChartChangeEventType var35 = null;
    org.jfree.chart.event.ChartChangeEvent var36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var33, var35);
    double var37 = var10.getAutoRangeMinimumSize();
    org.jfree.data.Range var38 = var10.getRange();
    var10.setRange(0.2d, 2.2d);
    java.awt.Paint var42 = var10.getTickLabelPaint();
    var0.setNoDataMessagePaint(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test205"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var5 = var0.getDomainAxis();
    java.awt.Paint var6 = var0.getRangeCrosshairPaint();
    org.jfree.chart.plot.DatasetRenderingOrder var7 = var0.getDatasetRenderingOrder();
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test206"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    java.awt.Paint var16 = var11.getRangeZeroBaselinePaint();
    java.awt.Paint var18 = var11.getQuadrantPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test207"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var4 = var3.getLabel();
    org.jfree.chart.util.Layer var5 = null;
    var0.addRangeMarker(1, (org.jfree.chart.plot.Marker)var3, var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    boolean var11 = var0.render(var7, var8, 1, var10);
    org.jfree.chart.axis.CategoryAxis var12 = var0.getDomainAxis();
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    var0.zoomDomainAxes(2.2d, var14, var15);
    var0.mapDatasetToRangeAxis(15, 15);
    org.jfree.chart.axis.ValueAxis var20 = var0.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test208"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.setWeight(100);
    org.jfree.data.category.CategoryDataset var5 = var1.getDataset(0);
    org.jfree.chart.axis.CategoryAnchor var6 = var1.getDomainGridlinePosition();
    boolean var7 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.axis.CategoryAxis var9 = var1.getDomainAxisForDataset((-57));
    org.jfree.chart.axis.AxisSpace var10 = var1.getFixedDomainAxisSpace();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var13 = var12.getCategoryMargin();
    var12.setCategoryLabelPositionOffset(0);
    int var16 = var1.getDomainAxisIndex(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test209"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    var1.setPieCenterY(10.0d);
    var1.setLatestAngle(0.0d);
    double var6 = var1.getTotal();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test210"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    var0.setBackgroundAlpha(1.0f);
    java.awt.Stroke var3 = var0.getOutlineStroke();
    int var4 = var0.getBackgroundImageAlignment();
    org.jfree.data.category.CategoryDataset var5 = null;
    var0.setDataset(var5);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setWeight(100);
    org.jfree.data.category.CategoryDataset var11 = var7.getDataset(0);
    org.jfree.chart.axis.CategoryAnchor var12 = var7.getDomainGridlinePosition();
    boolean var13 = var0.equals((java.lang.Object)var12);
    java.awt.Paint var14 = var0.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test211"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    double var6 = var4.getMaximumExplodePercent();
    var4.setSectionOutlinesVisible(false);
    var4.setLabelLinkMargin(10.0d);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    int var12 = var4.getPieIndex();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
    java.awt.Font var16 = var14.getLabelFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var21 = var17.equals((java.lang.Object)var20);
    var4.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
    double var23 = var4.getInteriorGap();
    var4.setIgnoreNullValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test212"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.lang.String var1 = var0.getVersion();
    java.lang.String var2 = var0.toString();
    var0.setCopyright("Range[0.0,1.0]");
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.setWeight(100);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var10 = var5.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var11 = var5.getDatasetRenderingOrder();
    boolean var12 = var5.isRangeCrosshairVisible();
    boolean var13 = var5.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    var5.setRenderer(15, var15);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    var19.setFixedDimension((-1.0d));
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var24 = var23.getLabelURL();
    var23.setNegativeArrowVisible(false);
    java.awt.Font var27 = var23.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
    org.jfree.chart.axis.ValueAxis var31 = var29.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = var29.getRenderer();
    java.awt.Paint var33 = var29.getDomainZeroBaselinePaint();
    boolean var34 = var29.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var37 = var36.getStandardTickUnits();
    java.awt.Font var38 = var36.getLabelFont();
    org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle("", var38);
    java.lang.Object var40 = var39.clone();
    org.jfree.chart.util.RectangleInsets var41 = var39.getPadding();
    double var42 = var41.getBottom();
    org.jfree.chart.util.UnitType var43 = var41.getUnitType();
    var29.setAxisOffset(var41);
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var48 = var47.getCategoryMargin();
    org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D();
    var49.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var52 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var53 = var52.getLabelURL();
    java.util.EventListener var54 = null;
    boolean var55 = var52.hasListener(var54);
    var52.setInverted(true);
    java.awt.Paint var58 = var52.getAxisLinePaint();
    var49.setTickMarkPaint(var58);
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var45, var47, (org.jfree.chart.axis.ValueAxis)var49, var60);
    java.awt.Stroke var62 = var61.getRangeGridlineStroke();
    org.jfree.chart.axis.AxisLocation var64 = var61.getRangeAxisLocation(100);
    var29.setDomainAxisLocation(var64);
    var5.setDomainAxisLocation(0, var64);
    boolean var67 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"+ "'", var2.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test213"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    var0.setLabelGap(0.0d);
    double var5 = var0.getExplodePercent((java.lang.Comparable)15);
    java.awt.Paint var6 = var0.getLabelLinkPaint();
    org.jfree.data.general.PieDataset var7 = null;
    var0.setDataset(var7);
    var0.setOutlineVisible(false);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var11);
    double var13 = var0.getInteriorGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.08d);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test214"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    double var6 = var4.getMaximumExplodePercent();
    var4.setSectionOutlinesVisible(false);
    var4.setLabelLinkMargin(10.0d);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot();
    boolean var13 = var12.getSectionOutlinesVisible();
    double var14 = var12.getMaximumExplodePercent();
    org.jfree.chart.util.RectangleInsets var15 = var12.getSimpleLabelOffset();
    var4.setInsets(var15);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var28 = new org.jfree.chart.plot.MultiplePiePlot();
    var28.setBackgroundAlpha(1.0f);
    java.awt.Stroke var31 = var28.getOutlineStroke();
    var21.setAxisLineStroke(var31);
    java.awt.Shape var33 = var21.getLeftArrow();
    boolean var34 = var18.equals((java.lang.Object)var33);
    org.jfree.data.general.PieDataset var35 = null;
    org.jfree.chart.entity.PieSectionEntity var41 = new org.jfree.chart.entity.PieSectionEntity(var33, var35, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
    var41.setPieIndex((-16777216));
    org.jfree.data.general.PieDataset var44 = var41.getDataset();
    boolean var45 = var17.equals((java.lang.Object)var41);
    var4.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var17);
    java.text.NumberFormat var47 = var17.getNumberFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test215"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", (-16777216));
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    int var4 = var2.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test216"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var2.setTickUnit(var3);
    var2.configure();
    java.util.Date var6 = var2.getMinimumDate();
    java.util.TimeZone var7 = var2.getTimeZone();
    org.jfree.chart.axis.DateTickUnit var8 = var2.getTickUnit();
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var9);
    var10.removeCornerTextItem("ChartEntity: tooltip = ");
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    var10.setAxis((org.jfree.chart.axis.ValueAxis)var13);
    org.jfree.chart.LegendItemCollection var15 = var10.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test217"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setAnchorValue(10.0d, false);
    java.lang.Object var4 = var0.clone();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    double var9 = var8.getCategoryMargin();
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    var10.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var14 = var13.getLabelURL();
    java.util.EventListener var15 = null;
    boolean var16 = var13.hasListener(var15);
    var13.setInverted(true);
    java.awt.Paint var19 = var13.getAxisLinePaint();
    var10.setTickMarkPaint(var19);
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var10, var21);
    var0.setDomainAxis(255, var8, true);
    int var25 = var8.getMaximumCategoryLabelLines();
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var29 = var28.getStandardTickUnits();
    java.awt.Font var30 = var28.getLabelFont();
    var27.setLabelFont(var30);
    var27.setUpperMargin(2.2d);
    var27.setUpperMargin(0.5d);
    org.jfree.chart.axis.CategoryLabelPositions var36 = var27.getCategoryLabelPositions();
    var8.setCategoryLabelPositions(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test218"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     boolean var2 = var1.isEmpty();
//     boolean var3 = var1.isEmpty();
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     var5.setFixedDimension((-1.0d));
//     java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var10 = var9.getLabelURL();
//     var9.setNegativeArrowVisible(false);
//     java.awt.Font var13 = var9.getTickLabelFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.ValueAxis var17 = var15.getDomainAxis(100);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = var15.getRenderer();
//     java.awt.Paint var19 = var15.getDomainZeroBaselinePaint();
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     boolean var23 = var22.isRangeGridlinesVisible();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var26 = var25.getAlpha();
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var22.removeRangeMarker((org.jfree.chart.plot.Marker)var25, var27);
//     org.jfree.chart.axis.AxisLocation var29 = var22.getRangeAxisLocation();
//     java.util.List var30 = var22.getAnnotations();
//     var15.drawRangeTickBands(var20, var21, var30);
//     java.awt.Paint var32 = var15.getDomainZeroBaselinePaint();
//     java.awt.geom.Point2D var33 = var15.getQuadrantOrigin();
//     org.jfree.chart.axis.AxisSpace var34 = null;
//     var15.setFixedDomainAxisSpace(var34, true);
//     boolean var37 = var1.equals((java.lang.Object)true);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
//     org.jfree.data.Range var42 = var41.getHeightRange();
//     org.jfree.chart.block.LengthConstraintType var43 = var41.getHeightConstraintType();
//     org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine();
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.util.Size2D var46 = var44.calculateDimensions(var45);
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var52 = var51.getPaint();
//     var50.setOutlinePaint(var52);
//     org.jfree.chart.util.RectangleAnchor var54 = var50.getLabelAnchor();
//     java.awt.geom.Rectangle2D var55 = org.jfree.chart.util.RectangleAnchor.createRectangle(var46, 0.05d, 0.0d, var54);
//     org.jfree.chart.util.Size2D var56 = var41.calculateConstrainedSize(var46);
//     org.jfree.chart.util.Size2D var57 = var1.arrange(var38, var41);
//     
//     // Checks the contract:  equals-hashcode on var46 and var57
//     assertTrue("Contract failed: equals-hashcode on var46 and var57", var46.equals(var57) ? var46.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var46
//     assertTrue("Contract failed: equals-hashcode on var57 and var46", var57.equals(var46) ? var57.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test219"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    double var6 = var4.getMaximumExplodePercent();
    var4.setSectionOutlinesVisible(false);
    var4.setLabelLinkMargin(10.0d);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    var4.setSimpleLabels(true);
    var4.setLabelLinksVisible(true);
    double var16 = var4.getMaximumLabelWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.14d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test220"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setLicenceText("hi!");
    java.lang.String var3 = var0.getLicenceText();
    java.awt.Image var4 = var0.getLogo();
    java.lang.String var5 = var0.getVersion();
    var0.setLicenceText("PieSection: -16777216, 100(XY Plot)");
    java.lang.String var8 = var0.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "hi!"+ "'", var3.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test221"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    var3.setFixedDimension((-1.0d));
    java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var8 = var7.getLabelURL();
    var7.setNegativeArrowVisible(false);
    java.awt.Font var11 = var7.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var7, var12);
    org.jfree.data.Range var14 = var7.getDefaultAutoRange();
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 90.0d);
    var1.setRange(var14, true, true);
    double var20 = var14.getLowerBound();
    org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var14, 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test222"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var5.setInfo("");
    org.jfree.chart.ui.Library[] var8 = var5.getOptionalLibraries();
    java.lang.String var9 = var5.getName();
    var5.addOptionalLibrary("PieSection: -16777216, 100(XY Plot)");
    var5.setVersion(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    var5.setCopyright("");
    java.lang.String var16 = var5.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + " version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var16.equals(" version .\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test223"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var5.setInfo("");
    org.jfree.chart.ui.Library[] var8 = var5.getOptionalLibraries();
    java.lang.String var9 = var5.getName();
    var5.addOptionalLibrary("PieSection: -16777216, 100(XY Plot)");
    java.lang.String var12 = var5.getName();
    var5.setVersion("Size2D[width=-5.975, height=0.0]");
    java.lang.String var15 = var5.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Size2D[width=-5.975, height=0.0]"+ "'", var15.equals("Size2D[width=-5.975, height=0.0]"));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test224"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    var0.setAnchorValue(0.0d, false);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    boolean var10 = var9.getSectionOutlinesVisible();
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    var12.setFixedDimension((-1.0d));
    java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var12);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var17 = var16.getLabelURL();
    var16.setNegativeArrowVisible(false);
    java.awt.Font var20 = var16.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var16, var21);
    org.jfree.chart.axis.ValueAxis var24 = var22.getDomainAxis(100);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var22.getDomainMarkers((-1), var26);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var30 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var31 = var30.getPaint();
    var29.setOutlinePaint(var31);
    var22.setRangeGridlinePaint(var31);
    var9.setLabelLinkPaint(var31);
    var8.setTickMarkPaint(var31);
    var0.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis)var8);
    java.awt.Paint var37 = var8.getAxisLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test225"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    int var2 = var1.getPassesRequired();
    double var3 = var1.getPieWRadius();
    java.awt.geom.Rectangle2D var4 = var1.getLinkArea();
    java.awt.geom.Rectangle2D var5 = var1.getLinkArea();
    int var6 = var1.getPassesRequired();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test226"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    boolean var2 = var1.getSectionOutlinesVisible();
    java.awt.Paint var4 = null;
    var1.setSectionPaint((java.lang.Comparable)10, var4);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    var6.setLabel("");
    java.lang.String var11 = var6.getLabel();
    java.awt.Stroke var12 = var6.getAxisLineStroke();
    var1.setLabelOutlineStroke(var12);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setWeight(100);
    org.jfree.data.category.CategoryDataset var18 = var14.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var19 = var14.getDomainAxis();
    java.awt.Paint var20 = var14.getRangeCrosshairPaint();
    var1.setLabelPaint(var20);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var24 = var23.getAlpha();
    java.awt.Paint var25 = var23.getPaint();
    org.jfree.chart.util.LengthAdjustmentType var26 = var23.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var27 = null;
    var23.notifyListeners(var27);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var30 = var29.getLabelURL();
    java.util.EventListener var31 = null;
    boolean var32 = var29.hasListener(var31);
    var29.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var36 = new org.jfree.chart.plot.MultiplePiePlot();
    var36.setBackgroundAlpha(1.0f);
    java.awt.Stroke var39 = var36.getOutlineStroke();
    var29.setAxisLineStroke(var39);
    var23.setStroke(var39);
    var1.setBaseSectionOutlineStroke(var39);
    var0.setSeparatorStroke(var39);
    double var44 = var0.getSectionDepth();
    var0.setSeparatorsVisible(false);
    java.awt.Paint var47 = var0.getSeparatorPaint();
    var0.setSeparatorsVisible(true);
    org.jfree.data.general.PieDataset var50 = null;
    var0.setDataset(var50);
    java.awt.Stroke var52 = var0.getLabelOutlineStroke();
    org.jfree.chart.util.Rotation var53 = var0.getDirection();
    java.awt.Paint var54 = var0.getSeparatorPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test227"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    var11.setRangeZeroBaselineVisible(false);
    org.jfree.chart.axis.AxisSpace var19 = null;
    var11.setFixedDomainAxisSpace(var19);
    org.jfree.chart.axis.ValueAxis var22 = var11.getRangeAxis(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test228"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var15 = var11.getRangeAxis(0);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var11.getRangeMarkers(var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var11.getDrawingSupplier();
    var11.setRangeGridlinesVisible(true);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.setWeight(100);
    org.jfree.data.category.CategoryDataset var25 = var21.getDataset(0);
    var21.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var28 = var27.getLabelURL();
    java.util.EventListener var29 = null;
    boolean var30 = var27.hasListener(var29);
    var27.setInverted(true);
    java.awt.Paint var33 = var27.getAxisLinePaint();
    org.jfree.data.Range var34 = var21.getDataRange((org.jfree.chart.axis.ValueAxis)var27);
    org.jfree.chart.util.RectangleEdge var35 = var21.getDomainAxisEdge();
    boolean var36 = var21.isRangeZoomable();
    var21.clearRangeMarkers(255);
    java.awt.Paint var39 = var21.getRangeCrosshairPaint();
    boolean var40 = var21.getDrawSharedDomainAxis();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.setWeight(100);
    org.jfree.data.category.CategoryDataset var46 = var42.getDataset(0);
    org.jfree.chart.axis.CategoryAnchor var47 = var42.getDomainGridlinePosition();
    org.jfree.chart.plot.PlotRenderingInfo var50 = null;
    java.awt.geom.Point2D var51 = null;
    var42.zoomRangeAxes(0.08d, 1.0E-5d, var50, var51);
    org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("Multiple Pie Plot", (org.jfree.chart.plot.Plot)var42);
    org.jfree.chart.ChartRenderingInfo var58 = null;
    java.awt.image.BufferedImage var59 = var53.createBufferedImage(255, 4, 102.0d, (-1.0d), var58);
    var21.setBackgroundImage((java.awt.Image)var59);
    var11.setBackgroundImage((java.awt.Image)var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test229"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.axis.AxisSpace var32 = null;
    var11.setFixedRangeAxisSpace(var32, true);
    var11.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.ValueAxis var38 = var11.getDomainAxis(0);
    org.jfree.data.xy.XYDataset var39 = null;
    var11.setDataset(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test230"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    boolean var2 = var1.getSectionOutlinesVisible();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    java.lang.Object var8 = var7.clone();
    java.lang.String var9 = var7.getText();
    org.jfree.chart.util.RectangleInsets var10 = var7.getPadding();
    var1.setLabelPadding(var10);
    java.awt.Font var12 = var1.getLabelFont();
    org.jfree.chart.text.TextLine var13 = new org.jfree.chart.text.TextLine("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", var12);
    org.jfree.chart.text.TextFragment var14 = null;
    var13.addFragment(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test231"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    var1.configure();
    java.util.TimeZone var5 = var1.getTimeZone();
    java.awt.Stroke var6 = var1.getAxisLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test232"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
//     java.awt.Font var2 = var0.getLabelFont();
//     var0.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
//     var5.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var8 = var5.getOutlineStroke();
//     var0.setPlot((org.jfree.chart.plot.Plot)var5);
//     java.awt.Image var10 = var5.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var12 = null;
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicAnchor();
//     org.jfree.chart.LegendItemSource[] var16 = var13.getSources();
//     org.jfree.chart.util.RectangleEdge var17 = var13.getLegendItemGraphicEdge();
//     java.awt.Paint var18 = var13.getItemPaint();
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var20 = var19.getStandardTickUnits();
//     java.awt.Font var21 = var19.getLabelFont();
//     var19.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var24 = new org.jfree.chart.plot.MultiplePiePlot();
//     var24.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var27 = var24.getOutlineStroke();
//     var19.setPlot((org.jfree.chart.plot.Plot)var24);
//     java.awt.Image var29 = var24.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var31 = null;
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24, (org.jfree.chart.block.Arrangement)var30, var31);
//     org.jfree.chart.util.RectangleInsets var33 = var32.getLegendItemGraphicPadding();
//     org.jfree.chart.util.RectangleAnchor var34 = var32.getLegendItemGraphicAnchor();
//     java.lang.Object var35 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var32);
//     org.jfree.chart.util.RectangleInsets var36 = var32.getMargin();
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
//     java.lang.String var38 = var37.getLabelURL();
//     java.util.EventListener var39 = null;
//     boolean var40 = var37.hasListener(var39);
//     var37.setInverted(true);
//     java.awt.Paint var43 = var37.getAxisLinePaint();
//     boolean var44 = var32.equals((java.lang.Object)var43);
//     var32.setMargin(4.2953125d, 0.0d, 0.0d, (-5.975d));
//     org.jfree.chart.util.RectangleAnchor var50 = var32.getLegendItemGraphicLocation();
//     var13.setLegendItemGraphicLocation(var50);
//     
//     // Checks the contract:  equals-hashcode on var1 and var20
//     assertTrue("Contract failed: equals-hashcode on var1 and var20", var1.equals(var20) ? var1.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var1
//     assertTrue("Contract failed: equals-hashcode on var20 and var1", var20.equals(var1) ? var20.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var24
//     assertTrue("Contract failed: equals-hashcode on var5 and var24", var5.equals(var24) ? var5.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var5
//     assertTrue("Contract failed: equals-hashcode on var24 and var5", var24.equals(var5) ? var24.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var30
//     assertTrue("Contract failed: equals-hashcode on var11 and var30", var11.equals(var30) ? var11.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var11
//     assertTrue("Contract failed: equals-hashcode on var30 and var11", var30.equals(var11) ? var30.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test233"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    boolean var2 = var1.getSectionOutlinesVisible();
    java.awt.Paint var4 = null;
    var1.setSectionPaint((java.lang.Comparable)10, var4);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    var6.setLabel("");
    java.lang.String var11 = var6.getLabel();
    java.awt.Stroke var12 = var6.getAxisLineStroke();
    var1.setLabelOutlineStroke(var12);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setWeight(100);
    org.jfree.data.category.CategoryDataset var18 = var14.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var19 = var14.getDomainAxis();
    java.awt.Paint var20 = var14.getRangeCrosshairPaint();
    var1.setLabelPaint(var20);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var24 = var23.getAlpha();
    java.awt.Paint var25 = var23.getPaint();
    org.jfree.chart.util.LengthAdjustmentType var26 = var23.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var27 = null;
    var23.notifyListeners(var27);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var30 = var29.getLabelURL();
    java.util.EventListener var31 = null;
    boolean var32 = var29.hasListener(var31);
    var29.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var36 = new org.jfree.chart.plot.MultiplePiePlot();
    var36.setBackgroundAlpha(1.0f);
    java.awt.Stroke var39 = var36.getOutlineStroke();
    var29.setAxisLineStroke(var39);
    var23.setStroke(var39);
    var1.setBaseSectionOutlineStroke(var39);
    var0.setSeparatorStroke(var39);
    double var44 = var0.getSectionDepth();
    var0.setSeparatorsVisible(false);
    var0.setSimpleLabels(true);
    int var49 = var0.getBackgroundImageAlignment();
    var0.setOuterSeparatorExtension(2.2d);
    java.awt.Stroke var52 = var0.getSeparatorStroke();
    java.awt.Paint var53 = var0.getSeparatorPaint();
    org.jfree.chart.util.RectangleInsets var54 = var0.getLabelPadding();
    int var55 = var0.getPieIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test234"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    var0.setAnchorValue(9.223372036854776E18d, false);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge();
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    java.awt.Graphics2D var10 = null;
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    var12.setFixedDimension((-1.0d));
    java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var12);
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var17 = var16.getLabelURL();
    var16.setNegativeArrowVisible(false);
    java.awt.Font var20 = var16.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var16, var21);
    org.jfree.chart.axis.ValueAxis var24 = var22.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = var22.getRenderer();
    java.awt.Paint var26 = var22.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    boolean var30 = var29.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var33 = var32.getAlpha();
    org.jfree.chart.util.Layer var34 = null;
    boolean var35 = var29.removeRangeMarker((org.jfree.chart.plot.Marker)var32, var34);
    org.jfree.chart.axis.AxisLocation var36 = var29.getRangeAxisLocation();
    java.util.List var37 = var29.getAnnotations();
    var22.drawRangeTickBands(var27, var28, var37);
    int var39 = var22.getRangeAxisCount();
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var43 = var42.getStandardTickUnits();
    java.awt.Font var44 = var42.getLabelFont();
    org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("", var44);
    java.lang.Object var46 = var45.clone();
    org.jfree.chart.block.BlockFrame var47 = var45.getFrame();
    org.jfree.chart.event.TitleChangeListener var48 = null;
    var45.removeChangeListener(var48);
    java.awt.geom.Rectangle2D var50 = var45.getBounds();
    org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var50, "", "");
    org.jfree.chart.plot.PlotRenderingInfo var54 = null;
    var22.drawAnnotations(var40, var50, var54);
    org.jfree.chart.plot.PlotRenderingInfo var57 = null;
    boolean var58 = var0.render(var10, var50, 255, var57);
    org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
    var0.setRenderer(var59);
    org.jfree.chart.plot.PlotOrientation var61 = var0.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test235"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    java.awt.Paint var28 = var11.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.AxisSpace var29 = null;
    var11.setFixedRangeAxisSpace(var29);
    org.jfree.chart.axis.AxisLocation var31 = var11.getDomainAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test236"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer();
    var14.clear();
    var13.setWrapper(var14);
    org.jfree.chart.util.RectangleEdge var17 = var13.getLegendItemGraphicEdge();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    var19.setFixedDimension((-1.0d));
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var24 = var23.getLabelURL();
    var23.setNegativeArrowVisible(false);
    java.awt.Font var27 = var23.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
    org.jfree.chart.axis.ValueAxis var31 = var29.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = var29.getRenderer();
    java.awt.Paint var33 = var29.getDomainZeroBaselinePaint();
    boolean var34 = var29.isDomainCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
    var36.setFixedDimension((-1.0d));
    java.lang.Object var39 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var36);
    org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var41 = var40.getLabelURL();
    var40.setNegativeArrowVisible(false);
    java.awt.Font var44 = var40.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var35, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var40, var45);
    org.jfree.chart.axis.ValueAxis var48 = var46.getDomainAxis(100);
    org.jfree.chart.util.Layer var50 = null;
    java.util.Collection var51 = var46.getDomainMarkers((-1), var50);
    org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var55 = var54.getPaint();
    var53.setOutlinePaint(var55);
    var46.setRangeGridlinePaint(var55);
    org.jfree.chart.axis.AxisLocation var58 = var46.getDomainAxisLocation();
    var29.setRangeAxisLocation(var58, false);
    org.jfree.chart.axis.NumberAxis3D var62 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var63 = var62.getLabelURL();
    java.util.EventListener var64 = null;
    boolean var65 = var62.hasListener(var64);
    var62.setLabel("");
    boolean var68 = var62.isVerticalTickLabels();
    org.jfree.chart.axis.MarkerAxisBand var69 = null;
    var62.setMarkerBand(var69);
    var29.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var62);
    org.jfree.chart.util.RectangleInsets var72 = var29.getAxisOffset();
    org.jfree.chart.plot.PlotOrientation var73 = var29.getOrientation();
    org.jfree.chart.util.Layer var75 = null;
    java.util.Collection var76 = var29.getRangeMarkers(0, var75);
    org.jfree.chart.util.RectangleEdge var78 = var29.getRangeAxisEdge((-1));
    var13.setLegendItemGraphicEdge(var78);
    org.jfree.chart.util.HorizontalAlignment var80 = var13.getHorizontalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test237"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var3.setAxisLineStroke(var13);
    java.awt.Shape var15 = var3.getLeftArrow();
    boolean var16 = var0.equals((java.lang.Object)var15);
    boolean var17 = var0.isRangeGridlinesVisible();
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.event.RendererChangeEvent var21 = null;
    var0.rendererChanged(var21);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var25.setCategoryMargin((-1.0d));
    float var28 = var25.getMaximumCategoryLabelWidthRatio();
    var25.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var32 = var31.getLabelURL();
    java.util.EventListener var33 = null;
    boolean var34 = var31.hasListener(var33);
    var31.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var37 = null;
    var31.setMarkerBand(var37);
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var23, var25, (org.jfree.chart.axis.ValueAxis)var31, var39);
    java.awt.Font var41 = var25.getTickLabelFont();
    var0.setDomainAxis(var25);
    org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var45 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var46 = var45.getPaint();
    var44.setOutlinePaint(var46);
    var25.setAxisLinePaint(var46);
    double var49 = var25.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.05d);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test238"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedWidth(0.0d);
    org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(100.0d, 0.0d);
    org.jfree.data.Range var12 = var11.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var14 = var11.toFixedWidth(0.0d);
    double var15 = var11.getWidth();
    org.jfree.chart.util.Size2D var16 = var7.arrange(var8, var11);
    org.jfree.chart.util.Size2D var17 = var2.calculateConstrainedSize(var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
    var19.setFixedDimension((-1.0d));
    java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var24 = var23.getLabelURL();
    var23.setNegativeArrowVisible(false);
    java.awt.Font var27 = var23.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
    org.jfree.data.Range var30 = var23.getDefaultAutoRange();
    org.jfree.data.Range var31 = var23.getRange();
    org.jfree.chart.block.RectangleConstraint var32 = var2.toRangeHeight(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test239"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setWeight(100);
    org.jfree.data.category.CategoryDataset var4 = var0.getDataset(0);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    java.util.EventListener var8 = null;
    boolean var9 = var6.hasListener(var8);
    var6.setInverted(true);
    java.awt.Paint var12 = var6.getAxisLinePaint();
    org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.chart.util.RectangleEdge var14 = var0.getDomainAxisEdge();
    boolean var15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test240"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    double var5 = var0.getLabelLinkMargin();
    java.awt.Stroke var6 = var0.getOutlineStroke();
    org.jfree.chart.plot.AbstractPieLabelDistributor var7 = var0.getLabelDistributor();
    org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var10 = var9.getAlpha();
    java.awt.Paint var11 = var9.getPaint();
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot();
    boolean var13 = var12.getSectionOutlinesVisible();
    double var14 = var12.getMaximumExplodePercent();
    var12.setSectionOutlinesVisible(false);
    var12.setLabelLinkMargin(10.0d);
    var9.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var12);
    int var20 = var12.getPieIndex();
    org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var23 = var22.getStandardTickUnits();
    java.awt.Font var24 = var22.getLabelFont();
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("", var24);
    java.lang.Object var26 = var25.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var29 = var25.equals((java.lang.Object)var28);
    var12.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var28);
    java.lang.String var31 = var28.getLabelFormat();
    org.jfree.chart.ui.BasicProjectInfo var37 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "", "hi!");
    var37.setInfo("");
    org.jfree.chart.ui.Library[] var40 = var37.getOptionalLibraries();
    boolean var41 = var28.equals((java.lang.Object)var37);
    var0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var28);
    org.jfree.chart.labels.PieSectionLabelGenerator var43 = var0.getLabelGenerator();
    org.jfree.chart.util.RectangleInsets var44 = var0.getSimpleLabelOffset();
    org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot();
    boolean var46 = var45.getSectionOutlinesVisible();
    var45.setPieIndex(0);
    org.jfree.chart.plot.AbstractPieLabelDistributor var49 = var45.getLabelDistributor();
    boolean var50 = var45.getLabelLinksVisible();
    var45.zoom(0.0d);
    org.jfree.chart.event.PlotChangeEvent var53 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var45);
    org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(10.0d);
    java.lang.String var56 = var55.getLabel();
    java.lang.Object var57 = var55.clone();
    java.awt.Paint var58 = var55.getPaint();
    java.awt.Paint var59 = var55.getLabelPaint();
    var55.setValue(0.05d);
    java.awt.Paint var62 = var55.getLabelPaint();
    var45.setLabelLinkPaint(var62);
    var0.setShadowPaint(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "hi!"+ "'", var31.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test241"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    java.awt.Image var21 = null;
    var19.setBackgroundImage(var21);
    java.awt.Paint var23 = var19.getBackgroundPaint();
    java.awt.Image var24 = null;
    var19.setBackgroundImage(var24);
    java.awt.Image var26 = var19.getBackgroundImage();
    org.jfree.chart.plot.Plot var27 = var19.getPlot();
    int var28 = var19.getSubtitleCount();
    org.jfree.chart.plot.CategoryPlot var29 = var19.getCategoryPlot();
    var29.setWeight(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test242"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    var0.setAnchorValue(9.223372036854776E18d, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var0.setRenderer(var8);
    boolean var10 = var0.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test243"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    var2.setFixedDimension((-1.0d));
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var7 = var6.getLabelURL();
    var6.setNegativeArrowVisible(false);
    java.awt.Font var10 = var6.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var6, var11);
    org.jfree.chart.axis.ValueAxis var14 = var12.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxis(0);
    int var17 = var12.getWeight();
    org.jfree.chart.plot.PlotOrientation var18 = var12.getOrientation();
    org.jfree.chart.axis.ValueAxis var19 = var12.getDomainAxis();
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var22 = var21.getStandardTickUnits();
    java.awt.Font var23 = var21.getLabelFont();
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var23);
    java.lang.Object var25 = var24.clone();
    org.jfree.chart.util.RectangleInsets var26 = var24.getPadding();
    double var28 = var26.extendHeight(10.0d);
    double var29 = var26.getTop();
    var12.setAxisOffset(var26);
    org.jfree.chart.util.RectangleEdge var31 = var12.getDomainAxisEdge();
    boolean var32 = var12.isRangeCrosshairLockedOnData();
    boolean var33 = var12.isDomainZoomable();
    java.awt.Paint var34 = var12.getNoDataMessagePaint();
    org.jfree.chart.plot.PlotOrientation var35 = var12.getOrientation();
    org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var37 = var36.getAngleTickUnit();
    boolean var38 = var36.isDomainZoomable();
    boolean var39 = var36.isRangeZoomable();
    java.awt.Paint var40 = var36.getAngleGridlinePaint();
    boolean var41 = var35.equals((java.lang.Object)var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var42 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test244"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("", var8);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.block.BlockFrame var11 = var9.getFrame();
    org.jfree.chart.event.TitleChangeListener var12 = null;
    var9.removeChangeListener(var12);
    java.awt.geom.Rectangle2D var14 = var9.getBounds();
    var3.setUpArrow((java.awt.Shape)var14);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setWeight(100);
    org.jfree.data.category.CategoryDataset var20 = var16.getDataset(0);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = var16.getRendererForDataset(var21);
    java.awt.Stroke var23 = var16.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleEdge var25 = var16.getRangeAxisEdge(100);
    double var26 = var1.java2DToValue(0.2d, var14, var25);
    boolean var27 = var1.isAxisLineVisible();
    java.lang.Object var28 = var1.clone();
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var31 = var30.getMaximumDate();
    var30.zoomRange(0.025d, 2.2d);
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
    var35.setAutoRange(false);
    org.jfree.chart.axis.DateTickUnit var38 = var35.getTickUnit();
    var30.setTickUnit(var38);
    var1.setTickUnit(var38, true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 9.223372036854776E18d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test245"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", (-16777216));
    java.awt.Color var3 = var2.brighter();
    int var4 = var3.getGreen();
    java.awt.Color var5 = var3.darker();
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-16777216));
    int var9 = var8.getAlpha();
    java.awt.Color var10 = var8.darker();
    java.awt.Color var13 = java.awt.Color.getColor("hi!", (-16777216));
    int var14 = var13.getAlpha();
    java.awt.Color var15 = var13.darker();
    int var16 = var13.getRed();
    float[] var23 = new float[] { 10.0f, 100.0f, 0.0f};
    float[] var24 = java.awt.Color.RGBtoHSB((-1), 1, 4, var23);
    float[] var25 = var13.getRGBColorComponents(var23);
    float[] var26 = var8.getColorComponents(var23);
    float[] var27 = var5.getRGBColorComponents(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test246"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    double var6 = var4.getMaximumExplodePercent();
    var4.setSectionOutlinesVisible(false);
    var4.setLabelLinkMargin(10.0d);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    int var12 = var4.getPieIndex();
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var15 = var14.getStandardTickUnits();
    java.awt.Font var16 = var14.getLabelFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("", var16);
    java.lang.Object var18 = var17.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var21 = var17.equals((java.lang.Object)var20);
    var4.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
    java.awt.Paint var23 = var4.getShadowPaint();
    java.lang.String var24 = var4.getPlotType();
    org.jfree.chart.event.AxisChangeEvent var25 = null;
    var4.axisChanged(var25);
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var29 = var28.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
    var30.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var34 = var33.getLabelURL();
    java.util.EventListener var35 = null;
    boolean var36 = var33.hasListener(var35);
    var33.setInverted(true);
    java.awt.Paint var39 = var33.getAxisLinePaint();
    var30.setTickMarkPaint(var39);
    var28.setPaint(var39);
    var28.setAlpha(1.0f);
    org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot();
    boolean var45 = var44.getSectionOutlinesVisible();
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var47 = var46.getAngleTickUnit();
    boolean var48 = var46.isDomainZoomable();
    org.jfree.data.xy.XYDataset var49 = null;
    var46.setDataset(var49);
    boolean var51 = var46.isRangeZoomable();
    org.jfree.data.xy.XYDataset var52 = var46.getDataset();
    java.awt.Stroke var53 = var46.getRadiusGridlineStroke();
    var44.setBaseSectionOutlineStroke(var53);
    var28.setOutlineStroke(var53);
    var4.setLabelLinkStroke(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Pie Plot"+ "'", var24.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test247"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    var19.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.title.LegendTitle var26 = var19.getLegend(100);
    java.lang.Object var27 = var19.clone();
    java.awt.Image var28 = var19.getBackgroundImage();
    var19.setTitle("XY Plot");
    boolean var31 = var19.isBorderVisible();
    org.jfree.chart.plot.CategoryPlot var32 = var19.getCategoryPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test248"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var2 = var1.getAlpha();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    boolean var5 = var4.getSectionOutlinesVisible();
    double var6 = var4.getMaximumExplodePercent();
    var4.setSectionOutlinesVisible(false);
    var4.setLabelLinkMargin(10.0d);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var4);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    var12.setFixedDimension((-1.0d));
    java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var12);
    org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var21 = var20.getStandardTickUnits();
    java.awt.Font var22 = var20.getLabelFont();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("", var22);
    java.awt.Paint var25 = null;
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var25);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.setWeight(100);
    org.jfree.data.category.CategoryDataset var31 = var27.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var32 = var27.getDomainAxis();
    java.awt.Paint var33 = var27.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("", var22, (org.jfree.chart.plot.Plot)var27, false);
    boolean var36 = var35.getAntiAlias();
    org.jfree.chart.event.ChartChangeEventType var37 = null;
    org.jfree.chart.event.ChartChangeEvent var38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var12, var35, var37);
    java.awt.Image var39 = null;
    var35.setBackgroundImage(var39);
    java.awt.Paint var41 = null;
    var35.setBackgroundPaint(var41);
    java.awt.Paint var43 = var35.getBorderPaint();
    var4.setLabelShadowPaint(var43);
    boolean var45 = var4.getLabelLinksVisible();
    java.awt.Paint var47 = null;
    var4.setSectionOutlinePaint((java.lang.Comparable)"PieSection: 15, 100(0.025)", var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test249"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var17 = var16.getAlpha();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    var18.setFixedDimension((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var22 = var21.getLabelURL();
    java.util.EventListener var23 = null;
    boolean var24 = var21.hasListener(var23);
    var21.setInverted(true);
    java.awt.Paint var27 = var21.getAxisLinePaint();
    var18.setTickMarkPaint(var27);
    var16.setPaint(var27);
    org.jfree.chart.util.Layer var30 = null;
    var11.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var16, var30);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var34 = var33.getStandardTickUnits();
    java.awt.Font var35 = var33.getLabelFont();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("", var35);
    java.lang.Object var37 = var36.clone();
    org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
    double var40 = var38.extendHeight(10.0d);
    double var41 = var38.getTop();
    boolean var42 = var11.equals((java.lang.Object)var38);
    org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var44 = var43.getLabelURL();
    java.util.EventListener var45 = null;
    boolean var46 = var43.hasListener(var45);
    var43.setInverted(true);
    var43.setTickMarkOutsideLength((-1.0f));
    org.jfree.data.Range var51 = var11.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
    double var52 = var43.getFixedDimension();
    java.awt.Shape var53 = var43.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test250"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    boolean var1 = var0.getSectionOutlinesVisible();
    double var2 = var0.getMaximumExplodePercent();
    var0.setSectionOutlinesVisible(false);
    var0.setLabelLinkMargin(10.0d);
    java.awt.Paint var7 = var0.getShadowPaint();
    var0.setLabelLinksVisible(true);
    boolean var10 = var0.getLabelLinksVisible();
    boolean var11 = var0.getLabelLinksVisible();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var14 = var13.getAlpha();
    java.awt.Paint var15 = var13.getPaint();
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
    boolean var17 = var16.getSectionOutlinesVisible();
    double var18 = var16.getMaximumExplodePercent();
    var16.setSectionOutlinesVisible(false);
    var16.setLabelLinkMargin(10.0d);
    var13.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var16);
    org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
    boolean var25 = var24.getSectionOutlinesVisible();
    double var26 = var24.getMaximumExplodePercent();
    org.jfree.chart.util.RectangleInsets var27 = var24.getSimpleLabelOffset();
    var16.setInsets(var27);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var29 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    var30.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var34 = var33.getLabelURL();
    java.util.EventListener var35 = null;
    boolean var36 = var33.hasListener(var35);
    var33.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot();
    var40.setBackgroundAlpha(1.0f);
    java.awt.Stroke var43 = var40.getOutlineStroke();
    var33.setAxisLineStroke(var43);
    java.awt.Shape var45 = var33.getLeftArrow();
    boolean var46 = var30.equals((java.lang.Object)var45);
    org.jfree.data.general.PieDataset var47 = null;
    org.jfree.chart.entity.PieSectionEntity var53 = new org.jfree.chart.entity.PieSectionEntity(var45, var47, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
    var53.setPieIndex((-16777216));
    org.jfree.data.general.PieDataset var56 = var53.getDataset();
    boolean var57 = var29.equals((java.lang.Object)var53);
    var16.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var29);
    var0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var29);
    java.text.NumberFormat var60 = var29.getPercentFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test251"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
    java.awt.Font var4 = var2.getLabelFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var4);
    var6.setToolTipText("");
    var6.setExpandToFitSpace(false);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.util.Size2D var14 = var12.calculateDimensions(var13);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    org.jfree.chart.util.RectangleAnchor var22 = var18.getLabelAnchor();
    java.awt.geom.Rectangle2D var23 = org.jfree.chart.util.RectangleAnchor.createRectangle(var14, 0.05d, 0.0d, var22);
    var6.draw(var11, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test252"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    java.util.List var24 = var11.getAnnotations();
    java.lang.Object var25 = null;
    boolean var26 = var11.equals(var25);
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var28 = var27.getLabelURL();
    java.util.EventListener var29 = null;
    boolean var30 = var27.hasListener(var29);
    var27.setLabel("");
    org.jfree.chart.axis.MarkerAxisBand var33 = null;
    var27.setMarkerBand(var33);
    var27.setAutoTickUnitSelection(true);
    java.lang.String var37 = var27.getLabelToolTip();
    java.awt.Paint var38 = var27.getAxisLinePaint();
    var27.setAutoRangeMinimumSize(0.20000000000000018d);
    int var41 = var11.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var27);
    var27.setAutoRangeIncludesZero(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test253"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("XY Plot");
    boolean var4 = var3.isNegativeArrowVisible();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    org.jfree.chart.plot.PiePlotState var6 = new org.jfree.chart.plot.PiePlotState(var5);
    var6.setPieCenterY(10.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var14 = var13.getStandardTickUnits();
    java.awt.Font var15 = var13.getLabelFont();
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var15);
    java.lang.Object var17 = var16.clone();
    org.jfree.chart.block.BlockFrame var18 = var16.getFrame();
    org.jfree.chart.event.TitleChangeListener var19 = null;
    var16.removeChangeListener(var19);
    java.awt.geom.Rectangle2D var21 = var16.getBounds();
    org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var21, "", "");
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var10.valueToJava2D(1.0E-8d, var21, var25);
    var6.setExplodedPieArea(var21);
    var3.setUpArrow((java.awt.Shape)var21);
    var0.draw(var1, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test254"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    var11.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisSpace var18 = null;
    var11.setFixedRangeAxisSpace(var18, true);
    var11.clearDomainMarkers((-1));
    org.jfree.chart.util.RectangleEdge var23 = var11.getRangeAxisEdge();
    org.jfree.data.xy.XYDataset var24 = null;
    var11.setDataset(var24);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    var27.setFixedDimension((-1.0d));
    java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var27);
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var32 = var31.getLabelURL();
    var31.setNegativeArrowVisible(false);
    java.awt.Font var35 = var31.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var31, var36);
    org.jfree.chart.axis.ValueAxis var39 = var37.getDomainAxis(100);
    org.jfree.chart.axis.ValueAxis var41 = var37.getRangeAxis(0);
    java.awt.Paint var42 = var37.getBackgroundPaint();
    org.jfree.chart.axis.ValueAxis var43 = var37.getRangeAxis();
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
    var44.setWeight(100);
    org.jfree.data.category.CategoryDataset var48 = var44.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var49 = var44.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var50 = var44.getDatasetRenderingOrder();
    var37.setDatasetRenderingOrder(var50);
    var11.setDatasetRenderingOrder(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test255"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var3 = var2.getPaint();
    var1.setOutlinePaint(var3);
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var5, var6);
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var13 = var12.getStandardTickUnits();
    java.awt.Font var14 = var12.getLabelFont();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("", var14);
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var14);
    java.awt.Paint var17 = null;
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var17);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.setWeight(100);
    org.jfree.data.category.CategoryDataset var23 = var19.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var24 = var19.getDomainAxis();
    java.awt.Paint var25 = var19.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var19, false);
    boolean var28 = var27.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var29 = null;
    var27.removeProgressListener(var29);
    var27.setBackgroundImageAlpha(100.0f);
    org.jfree.chart.title.LegendTitle var34 = var27.getLegend(100);
    java.lang.Object var35 = var27.clone();
    var7.setChart(var27);
    org.jfree.chart.event.ChartChangeEventType var37 = null;
    var7.setType(var37);
    org.jfree.chart.JFreeChart var39 = var7.getChart();
    org.jfree.chart.title.LegendTitle var40 = var39.getLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test256"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    var0.setNoDataMessage("hi!");
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setWeight(100);
    org.jfree.data.category.CategoryDataset var12 = var8.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var13 = var8.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var14 = var8.getDatasetRenderingOrder();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.setWeight(100);
    org.jfree.data.category.CategoryDataset var19 = var15.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var20 = var15.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var21 = var15.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var25 = var24.getStandardTickUnits();
    java.awt.Font var26 = var24.getLabelFont();
    var23.setLabelFont(var26);
    java.util.List var28 = var15.getCategoriesForAxis(var23);
    org.jfree.chart.axis.CategoryAxis[] var29 = new org.jfree.chart.axis.CategoryAxis[] { var23};
    var8.setDomainAxes(var29);
    boolean var31 = var0.equals((java.lang.Object)var29);
    java.lang.String var32 = var0.getPlotType();
    org.jfree.data.general.DatasetChangeEvent var33 = null;
    var0.datasetChanged(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "Polar Plot"+ "'", var32.equals("Polar Plot"));

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test257"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    boolean var2 = var0.isDomainZoomable();
    org.jfree.data.xy.XYDataset var3 = null;
    var0.setDataset(var3);
    java.awt.Stroke var5 = var0.getRadiusGridlineStroke();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(102.0d, 0.05d, var8, var9);
    java.awt.Stroke var11 = null;
    var0.setRadiusGridlineStroke(var11);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var15 = var14.getMaximumDate();
    var14.zoomRange(0.025d, 2.2d);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    var19.setAutoRange(false);
    org.jfree.chart.axis.DateTickUnit var22 = var19.getTickUnit();
    var14.setTickUnit(var22);
    var0.setAngleTickUnit((org.jfree.chart.axis.TickUnit)var22);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var28 = var27.getAngleTickUnit();
    var27.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
    var27.setAxis((org.jfree.chart.axis.ValueAxis)var31);
    java.awt.Stroke var33 = var27.getAngleGridlineStroke();
    var27.addCornerTextItem("LengthConstraintType.FIXED");
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var39 = var38.getAngleTickUnit();
    boolean var40 = var38.isDomainZoomable();
    org.jfree.data.xy.XYDataset var41 = null;
    var38.setDataset(var41);
    boolean var43 = var38.isRangeZoomable();
    org.jfree.data.xy.XYDataset var44 = var38.getDataset();
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var48 = var47.getAngleTickUnit();
    var47.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var51 = new org.jfree.chart.axis.NumberAxis3D();
    var47.setAxis((org.jfree.chart.axis.ValueAxis)var51);
    var47.setNoDataMessage("hi!");
    org.jfree.data.xy.XYDataset var55 = var47.getDataset();
    org.jfree.chart.plot.PlotRenderingInfo var58 = null;
    org.jfree.data.xy.XYDataset var59 = null;
    org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D();
    var60.setFixedDimension((-1.0d));
    java.lang.Object var63 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var60);
    org.jfree.chart.axis.NumberAxis3D var64 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var65 = var64.getLabelURL();
    var64.setNegativeArrowVisible(false);
    java.awt.Font var68 = var64.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
    org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var59, (org.jfree.chart.axis.ValueAxis)var60, (org.jfree.chart.axis.ValueAxis)var64, var69);
    org.jfree.chart.axis.ValueAxis var72 = var70.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var73 = var70.getRenderer();
    java.awt.Paint var74 = var70.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var75 = null;
    java.awt.geom.Rectangle2D var76 = null;
    org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot();
    boolean var78 = var77.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var80 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var81 = var80.getAlpha();
    org.jfree.chart.util.Layer var82 = null;
    boolean var83 = var77.removeRangeMarker((org.jfree.chart.plot.Marker)var80, var82);
    org.jfree.chart.axis.AxisLocation var84 = var77.getRangeAxisLocation();
    java.util.List var85 = var77.getAnnotations();
    var70.drawRangeTickBands(var75, var76, var85);
    java.awt.Paint var87 = var70.getDomainZeroBaselinePaint();
    java.awt.geom.Point2D var88 = var70.getQuadrantOrigin();
    var47.zoomRangeAxes(0.05d, 90.0d, var58, var88);
    var38.zoomDomainAxes(92.0d, var46, var88);
    var27.zoomRangeAxes(0.025d, var37, var88);
    var0.zoomDomainAxes(1.0E-8d, var26, var88, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test258"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    boolean var2 = var1.getSectionOutlinesVisible();
    java.awt.Paint var4 = null;
    var1.setSectionPaint((java.lang.Comparable)10, var4);
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var7 = var6.getStandardTickUnits();
    java.awt.Font var8 = var6.getLabelFont();
    var6.setLabel("");
    java.lang.String var11 = var6.getLabel();
    java.awt.Stroke var12 = var6.getAxisLineStroke();
    var1.setLabelOutlineStroke(var12);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.setWeight(100);
    org.jfree.data.category.CategoryDataset var18 = var14.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var19 = var14.getDomainAxis();
    java.awt.Paint var20 = var14.getRangeCrosshairPaint();
    var1.setLabelPaint(var20);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var24 = var23.getAlpha();
    java.awt.Paint var25 = var23.getPaint();
    org.jfree.chart.util.LengthAdjustmentType var26 = var23.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeEvent var27 = null;
    var23.notifyListeners(var27);
    org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var30 = var29.getLabelURL();
    java.util.EventListener var31 = null;
    boolean var32 = var29.hasListener(var31);
    var29.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var36 = new org.jfree.chart.plot.MultiplePiePlot();
    var36.setBackgroundAlpha(1.0f);
    java.awt.Stroke var39 = var36.getOutlineStroke();
    var29.setAxisLineStroke(var39);
    var23.setStroke(var39);
    var1.setBaseSectionOutlineStroke(var39);
    var0.setSeparatorStroke(var39);
    double var44 = var0.getSectionDepth();
    var0.setSeparatorsVisible(false);
    org.jfree.chart.plot.Plot var47 = null;
    var0.setParent(var47);
    var0.setOuterSeparatorExtension(0.14d);
    var0.setInnerSeparatorExtension((-5.975d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test259"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    int var2 = var1.getPassesRequired();
    var1.setPassesRequired(4);
    org.jfree.chart.entity.EntityCollection var5 = var1.getEntityCollection();
    var1.setPieHRadius((-0.18d));
    double var8 = var1.getLatestAngle();
    java.awt.geom.Rectangle2D var9 = var1.getPieArea();
    java.awt.geom.Rectangle2D var10 = null;
    var1.setPieArea(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test260"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = var11.getRenderer();
    java.awt.Paint var15 = var11.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    boolean var19 = var18.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var22 = var21.getAlpha();
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
    java.util.List var26 = var18.getAnnotations();
    var11.drawRangeTickBands(var16, var17, var26);
    org.jfree.chart.axis.AxisSpace var28 = null;
    var11.setFixedRangeAxisSpace(var28, true);
    org.jfree.chart.util.RectangleInsets var31 = var11.getAxisOffset();
    java.awt.Paint var32 = var11.getRangeTickBandPaint();
    java.awt.Paint var33 = var11.getOutlinePaint();
    boolean var34 = var11.isRangeZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test261"); }


    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var5 = var4.getStandardTickUnits();
    java.awt.Font var6 = var4.getLabelFont();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var6);
    java.awt.Paint var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setWeight(100);
    org.jfree.data.category.CategoryDataset var15 = var11.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxis();
    java.awt.Paint var17 = var11.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", var6, (org.jfree.chart.plot.Plot)var11, false);
    boolean var20 = var19.getAntiAlias();
    org.jfree.chart.event.ChartProgressListener var21 = null;
    var19.removeProgressListener(var21);
    org.jfree.chart.plot.Plot var23 = var19.getPlot();
    java.awt.Stroke var24 = var19.getBorderStroke();
    org.jfree.chart.title.LegendTitle var26 = var19.getLegend(0);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
    var28.setFixedDimension((-1.0d));
    java.lang.Object var31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var28);
    org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var33 = var32.getLabelURL();
    var32.setNegativeArrowVisible(false);
    java.awt.Font var36 = var32.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var32, var37);
    org.jfree.chart.axis.ValueAxis var40 = var38.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = var38.getRenderer();
    java.awt.Paint var42 = var38.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
    boolean var46 = var45.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var49 = var48.getAlpha();
    org.jfree.chart.util.Layer var50 = null;
    boolean var51 = var45.removeRangeMarker((org.jfree.chart.plot.Marker)var48, var50);
    org.jfree.chart.axis.AxisLocation var52 = var45.getRangeAxisLocation();
    java.util.List var53 = var45.getAnnotations();
    var38.drawRangeTickBands(var43, var44, var53);
    var38.clearRangeAxes();
    java.awt.Paint var56 = var38.getRangeZeroBaselinePaint();
    int var57 = var38.getSeriesCount();
    org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
    org.jfree.chart.util.RectangleInsets var59 = var58.getItemLabelPadding();
    var19.removeSubtitle((org.jfree.chart.title.Title)var58);
    org.jfree.chart.title.LegendTitle var61 = var19.getLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test262"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.util.RectangleInsets var1 = var0.getLabelPadding();
    double var2 = var0.getMaximumExplodePercent();
    java.awt.Stroke var3 = var0.getLabelLinkStroke();
    double var4 = var0.getMaximumLabelWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.14d);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test263"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("Multiple Pie Plot", (-8323073), 0);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test264"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("", var3);
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    boolean var8 = var4.equals((java.lang.Object)var7);
    java.lang.String var9 = var7.getLabelFormat();
    java.text.AttributedString var11 = null;
    var7.setAttributedLabel(100, var11);
    java.lang.String var13 = var7.getLabelFormat();
    java.lang.String var14 = var7.getLabelFormat();
    java.text.AttributedString var16 = null;
    var7.setAttributedLabel(15, var16);
    java.lang.Object var18 = var7.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "hi!"+ "'", var9.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "hi!"+ "'", var13.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test265"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(91.0d, 0.2d);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.util.Size2D var6 = new org.jfree.chart.util.Size2D((-5.975d), 0.0d);
    java.lang.String var7 = var6.toString();
    org.jfree.chart.util.Size2D var8 = var2.calculateConstrainedSize(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Size2D[width=-5.975, height=0.0]"+ "'", var7.equals("Size2D[width=-5.975, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test266"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    boolean var2 = var0.containsKey((java.lang.Comparable)'#');
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("");
    java.util.Date var5 = var4.getMaximumDate();
    var4.zoomRange(0.025d, 2.2d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    var9.setAutoRange(false);
    org.jfree.chart.axis.DateTickUnit var12 = var9.getTickUnit();
    var4.setTickUnit(var12);
    java.awt.Stroke var14 = var0.getStroke((java.lang.Comparable)var12);
    java.awt.Stroke var16 = var0.getStroke((java.lang.Comparable)"RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test267"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    var0.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomRangeAxes(100.0d, var7, var8);
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var11 = var10.getAngleTickUnit();
    var10.setBackgroundAlpha(10.0f);
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
    var10.setAxis((org.jfree.chart.axis.ValueAxis)var14);
    var10.setNoDataMessage("hi!");
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.setWeight(100);
    org.jfree.data.category.CategoryDataset var22 = var18.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var23 = var18.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var24 = var18.getDatasetRenderingOrder();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    var25.setWeight(100);
    org.jfree.data.category.CategoryDataset var29 = var25.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var30 = var25.getDomainAxis();
    org.jfree.chart.plot.DatasetRenderingOrder var31 = var25.getDatasetRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var35 = var34.getStandardTickUnits();
    java.awt.Font var36 = var34.getLabelFont();
    var33.setLabelFont(var36);
    java.util.List var38 = var25.getCategoriesForAxis(var33);
    org.jfree.chart.axis.CategoryAxis[] var39 = new org.jfree.chart.axis.CategoryAxis[] { var33};
    var18.setDomainAxes(var39);
    boolean var41 = var10.equals((java.lang.Object)var39);
    java.awt.Paint var42 = var10.getAngleLabelPaint();
    var0.setAngleGridlinePaint(var42);
    var0.clearCornerTextItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test268"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var1 = var0.getAngleTickUnit();
    org.jfree.chart.renderer.PolarItemRenderer var2 = var0.getRenderer();
    java.awt.Paint var3 = var0.getAngleGridlinePaint();
    var0.removeCornerTextItem("hi!");
    var0.removeCornerTextItem("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=0.0]");
    java.awt.Paint var8 = var0.getRadiusGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test269"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDrawSharedDomainAxis(false);
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var4 = var3.getLabelURL();
    java.util.EventListener var5 = null;
    boolean var6 = var3.hasListener(var5);
    var3.zoomRange((-1.0d), 1.0d);
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    var10.setBackgroundAlpha(1.0f);
    java.awt.Stroke var13 = var10.getOutlineStroke();
    var3.setAxisLineStroke(var13);
    java.awt.Shape var15 = var3.getLeftArrow();
    boolean var16 = var0.equals((java.lang.Object)var15);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.entity.PieSectionEntity var23 = new org.jfree.chart.entity.PieSectionEntity(var15, var17, 15, 100, (java.lang.Comparable)"XY Plot", "WMAP_Plot", "XY Plot");
    var23.setPieIndex((-16777216));
    java.lang.String var26 = var23.toString();
    java.awt.Shape var27 = var23.getArea();
    java.lang.String var28 = var23.toString();
    org.jfree.data.general.PieDataset var29 = null;
    var23.setDataset(var29);
    java.lang.Comparable var31 = var23.getSectionKey();
    int var32 = var23.getPieIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "PieSection: -16777216, 100(XY Plot)"+ "'", var26.equals("PieSection: -16777216, 100(XY Plot)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "PieSection: -16777216, 100(XY Plot)"+ "'", var28.equals("PieSection: -16777216, 100(XY Plot)"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "XY Plot"+ "'", var31.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-16777216));

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test270"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     var0.clear();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var4 = var3.getStandardTickUnits();
//     java.awt.Font var5 = var3.getLabelFont();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("", var5);
//     java.lang.Object var7 = var6.clone();
//     java.lang.String var8 = var6.getText();
//     org.jfree.chart.util.RectangleInsets var9 = var6.getPadding();
//     double var11 = var9.extendHeight(100.0d);
//     var0.setPadding(var9);
//     org.jfree.chart.block.Arrangement var13 = var0.getArrangement();
//     boolean var14 = var0.isEmpty();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(10.0d);
//     float var18 = var17.getAlpha();
//     java.awt.Paint var19 = var17.getPaint();
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
//     boolean var21 = var20.getSectionOutlinesVisible();
//     double var22 = var20.getMaximumExplodePercent();
//     var20.setSectionOutlinesVisible(false);
//     var20.setLabelLinkMargin(10.0d);
//     var17.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var20);
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot();
//     boolean var29 = var28.getSectionOutlinesVisible();
//     double var30 = var28.getMaximumExplodePercent();
//     org.jfree.chart.util.RectangleInsets var31 = var28.getSimpleLabelOffset();
//     var20.setInsets(var31);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     org.jfree.chart.plot.PiePlotState var34 = new org.jfree.chart.plot.PiePlotState(var33);
//     int var35 = var34.getPassesRequired();
//     double var36 = var34.getPieWRadius();
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot();
//     boolean var38 = var37.getSectionOutlinesVisible();
//     var37.setMinimumArcAngleToDraw((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var42 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var43 = var42.getStandardTickUnits();
//     java.awt.Font var44 = var42.getLabelFont();
//     org.jfree.chart.title.TextTitle var45 = new org.jfree.chart.title.TextTitle("", var44);
//     java.lang.Object var46 = var45.clone();
//     org.jfree.chart.block.BlockFrame var47 = var45.getFrame();
//     org.jfree.chart.event.TitleChangeListener var48 = null;
//     var45.removeChangeListener(var48);
//     java.awt.geom.Rectangle2D var50 = var45.getBounds();
//     var37.setLegendItemShape((java.awt.Shape)var50);
//     var34.setLinkArea(var50);
//     var31.trim(var50);
//     var0.draw(var15, var50);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test271"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    var0.setNegativeArrowVisible(false);
    org.jfree.chart.axis.MarkerAxisBand var4 = null;
    var0.setMarkerBand(var4);
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var11 = var10.getStandardTickUnits();
    java.awt.Font var12 = var10.getLabelFont();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("", var12);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var12);
    java.awt.Paint var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setWeight(100);
    org.jfree.data.category.CategoryDataset var21 = var17.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var22 = var17.getDomainAxis();
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("", var12, (org.jfree.chart.plot.Plot)var17, false);
    boolean var26 = var25.getAntiAlias();
    java.awt.Image var27 = null;
    var25.setBackgroundImage(var27);
    org.jfree.chart.plot.Plot var29 = var25.getPlot();
    org.jfree.chart.plot.CategoryPlot var30 = var25.getCategoryPlot();
    var25.setBackgroundImageAlpha((-1.0f));
    boolean var33 = var0.equals((java.lang.Object)var25);
    org.jfree.chart.plot.CategoryPlot var34 = var25.getCategoryPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test272"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    java.awt.Paint var12 = var11.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test273"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("XY Plot");
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var2.setTickUnit(var3);
    var2.configure();
    java.util.Date var6 = var2.getMinimumDate();
    java.util.TimeZone var7 = var2.getTimeZone();
    org.jfree.chart.axis.DateTickUnit var8 = var2.getTickUnit();
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var9);
    var10.removeCornerTextItem("ChartEntity: tooltip = ");
    java.awt.Stroke var13 = var10.getAngleGridlineStroke();
    boolean var14 = var10.isRadiusGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test274"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var1 = var0.getLabelURL();
    var0.setNegativeArrowVisible(false);
    boolean var4 = var0.getAutoRangeIncludesZero();
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    var6.setFixedDimension((-1.0d));
    java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var11 = var10.getLabelURL();
    var10.setNegativeArrowVisible(false);
    java.awt.Font var14 = var10.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var15);
    org.jfree.chart.axis.ValueAxis var18 = var16.getDomainAxis(100);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = var16.getRenderer();
    java.awt.Paint var20 = var16.getDomainZeroBaselinePaint();
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    boolean var24 = var23.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var27 = var26.getAlpha();
    org.jfree.chart.util.Layer var28 = null;
    boolean var29 = var23.removeRangeMarker((org.jfree.chart.plot.Marker)var26, var28);
    org.jfree.chart.axis.AxisLocation var30 = var23.getRangeAxisLocation();
    java.util.List var31 = var23.getAnnotations();
    var16.drawRangeTickBands(var21, var22, var31);
    int var33 = var16.getRangeAxisCount();
    org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var36 = var35.getLabelURL();
    java.util.EventListener var37 = null;
    boolean var38 = var35.hasListener(var37);
    var35.setInverted(true);
    java.awt.Paint var41 = var35.getAxisLinePaint();
    var16.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis)var35);
    var16.configureDomainAxes();
    boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)var16);
    org.jfree.chart.axis.MarkerAxisBand var45 = null;
    var0.setMarkerBand(var45);
    org.jfree.data.Range var47 = null;
    org.jfree.data.Range var49 = org.jfree.data.Range.expandToInclude(var47, 0.0d);
    double var50 = var49.getUpperBound();
    var0.setRange(var49, false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test275"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var3 = var2.getStandardTickUnits();
//     java.awt.Font var4 = var2.getLabelFont();
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("", var4);
//     java.awt.Paint var6 = null;
//     org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, var6);
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getLineAlignment();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.TickUnitSource var10 = var9.getStandardTickUnits();
//     java.awt.Font var11 = var9.getLabelFont();
//     var9.setLabel("");
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot();
//     var14.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var17 = var14.getOutlineStroke();
//     var9.setPlot((org.jfree.chart.plot.Plot)var14);
//     java.awt.Image var19 = var14.getBackgroundImage();
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Arrangement var21 = null;
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14, (org.jfree.chart.block.Arrangement)var20, var21);
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLegendItemGraphicPadding();
//     org.jfree.chart.util.HorizontalAlignment var24 = var22.getHorizontalAlignment();
//     var7.setLineAlignment(var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var10
//     assertTrue("Contract failed: equals-hashcode on var3 and var10", var3.equals(var10) ? var3.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var3
//     assertTrue("Contract failed: equals-hashcode on var10 and var3", var10.equals(var3) ? var10.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test276"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
    var2.clear();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var6 = var5.getStandardTickUnits();
    java.awt.Font var7 = var5.getLabelFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("", var7);
    java.lang.Object var9 = var8.clone();
    java.lang.String var10 = var8.getText();
    org.jfree.chart.util.RectangleInsets var11 = var8.getPadding();
    double var13 = var11.extendHeight(100.0d);
    var2.setPadding(var11);
    var1.add((org.jfree.chart.block.Block)var2);
    boolean var16 = var1.isEmpty();
    java.lang.Object var17 = var1.clone();
    java.util.List var18 = var1.getBlocks();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test277"); }


    org.jfree.chart.block.BlockResult var0 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var1 = var0.getEntityCollection();
    org.jfree.chart.entity.EntityCollection var2 = var0.getEntityCollection();
    org.jfree.chart.entity.EntityCollection var3 = var0.getEntityCollection();
    org.jfree.chart.entity.EntityCollection var4 = null;
    var0.setEntityCollection(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test278"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.chart.axis.TickUnitSource var1 = var0.getStandardTickUnits();
    java.awt.Font var2 = var0.getLabelFont();
    var0.setLabel("");
    org.jfree.chart.plot.MultiplePiePlot var5 = new org.jfree.chart.plot.MultiplePiePlot();
    var5.setBackgroundAlpha(1.0f);
    java.awt.Stroke var8 = var5.getOutlineStroke();
    var0.setPlot((org.jfree.chart.plot.Plot)var5);
    java.awt.Image var10 = var5.getBackgroundImage();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Arrangement var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var11, var12);
    org.jfree.chart.util.RectangleInsets var14 = var13.getLegendItemGraphicPadding();
    org.jfree.chart.util.RectangleAnchor var15 = var13.getLegendItemGraphicAnchor();
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
    java.awt.Font var17 = var13.getItemFont();
    org.jfree.chart.util.RectangleAnchor var18 = var13.getLegendItemGraphicLocation();
    org.jfree.chart.util.VerticalAlignment var19 = var13.getVerticalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test279"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.setWeight(100);
    org.jfree.data.category.CategoryDataset var31 = var27.getDataset(0);
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = var27.getRendererForDataset(var32);
    java.awt.Stroke var34 = var27.getDomainGridlineStroke();
    var11.setDomainCrosshairStroke(var34);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    java.awt.geom.Point2D var38 = null;
    var11.zoomDomainAxes(10.0d, var37, var38);
    org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("Polar Plot");
    java.awt.Shape var43 = var42.getDownArrow();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeAxis((-57), (org.jfree.chart.axis.ValueAxis)var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test280"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    var1.setFixedDimension((-1.0d));
    java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var6 = var5.getLabelURL();
    var5.setNegativeArrowVisible(false);
    java.awt.Font var9 = var5.getTickLabelFont();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.axis.ValueAxis var13 = var11.getDomainAxis(100);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var11.getDomainMarkers((-1), var15);
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(10.0d);
    org.jfree.chart.block.LineBorder var19 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var20 = var19.getPaint();
    var18.setOutlinePaint(var20);
    var11.setRangeGridlinePaint(var20);
    org.jfree.chart.axis.AxisLocation var23 = var11.getDomainAxisLocation();
    org.jfree.chart.axis.ValueAxis var25 = var11.getRangeAxisForDataset(0);
    java.awt.Paint var26 = var11.getDomainCrosshairPaint();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    java.lang.String var28 = var27.getLabelURL();
    java.util.EventListener var29 = null;
    boolean var30 = var27.hasListener(var29);
    var27.setInverted(true);
    java.awt.Paint var33 = var27.getAxisLinePaint();
    org.jfree.data.Range var34 = var27.getRange();
    java.awt.Paint var35 = var27.getTickLabelPaint();
    var11.setBackgroundPaint(var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.setWeight(100);
    org.jfree.data.category.CategoryDataset var41 = var37.getDataset(0);
    org.jfree.chart.axis.CategoryAxis var42 = var37.getDomainAxis();
    java.awt.Paint var43 = var37.getRangeCrosshairPaint();
    org.jfree.chart.LegendItemCollection var44 = var37.getFixedLegendItems();
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
    boolean var46 = var45.isRangeGridlinesVisible();
    org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(10.0d);
    float var49 = var48.getAlpha();
    org.jfree.chart.util.Layer var50 = null;
    boolean var51 = var45.removeRangeMarker((org.jfree.chart.plot.Marker)var48, var50);
    org.jfree.chart.axis.AxisLocation var52 = var45.getRangeAxisLocation();
    var37.setRangeAxisLocation(var52, false);
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.TickUnit var56 = var55.getAngleTickUnit();
    boolean var57 = var55.isDomainZoomable();
    boolean var58 = var55.isRangeZoomable();
    org.jfree.data.general.DatasetChangeEvent var59 = null;
    var55.datasetChanged(var59);
    org.jfree.chart.axis.ValueAxis var61 = null;
    var55.setAxis(var61);
    org.jfree.chart.plot.PlotOrientation var63 = var55.getOrientation();
    org.jfree.chart.axis.TickUnitSource var64 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    boolean var65 = var63.equals((java.lang.Object)var64);
    org.jfree.chart.util.RectangleEdge var66 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var52, var63);
    var11.setDomainAxisLocation(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

}
