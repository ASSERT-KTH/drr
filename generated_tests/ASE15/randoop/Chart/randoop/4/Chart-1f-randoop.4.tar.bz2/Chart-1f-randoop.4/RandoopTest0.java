
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     java.awt.Paint var4 = var1.getSeriesLabelPaint(1);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Stroke var3 = null;
//     var1.setSeriesOutlineStroke((-1), var3);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var2 = var1.getDefaultLabelFont();
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesStroke((-1), var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     java.awt.Paint var4 = null;
//     var1.setSeriesLabelPaint(100, var4);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.plot.Marker var3 = null;
//     org.jfree.chart.util.Layer var4 = null;
//     var0.addRangeMarker(1, var3, var4);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     var1.setSeriesLabelVisible(100, (java.lang.Boolean)false);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.annotations.CategoryAnnotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var0.removeAnnotation(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(1, var2, true);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.configureDomainAxes();
//     java.awt.Paint var7 = var5.getDomainGridlinePaint();
//     var0.setRangeMinorGridlinePaint(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.Color var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator(100, var1, 10.0f, (-1), 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Stroke var3 = var0.getItemOutlineStroke(10, 10);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var5.setDomainAxis(100, var8, false);
    org.jfree.chart.util.SortOrder var11 = var5.getColumnRenderingOrder();
    java.awt.Paint var12 = var5.getRangeMinorGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem(var0, "", "hi!", "hi!", var4, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
//     java.awt.Stroke var5 = var2.getRangeCrosshairStroke();
//     var0.setDomainGridlineStroke(var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedDomainAxisSpace(var3, false);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    var6.setDomainAxis(0, var10);
    var0.setParent((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.plot.CategoryMarker var14 = null;
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(1, var14, var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.lang.Boolean var5 = var1.isLabelVisible(100, 1);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.data.category.CategoryDataset var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var1.generateLabel(var2, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    org.jfree.chart.util.RectangleInsets var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisOffset(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(1, var2, true);
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var0.setFixedRangeAxisSpace(var5, false);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis(0);
//     java.awt.Stroke var11 = var8.getRangeCrosshairStroke();
//     var0.setRangeGridlineStroke(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var3 = var1.equals((java.lang.Object)var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var7 = var5.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var8 = null;
//     var5.setFixedDomainAxisSpace(var8, false);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     org.jfree.chart.axis.AxisSpace var13 = null;
//     org.jfree.chart.axis.AxisSpace var14 = var2.reserveSpace(var4, (org.jfree.chart.plot.Plot)var5, var11, var12, var13);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var5.setDomainAxis(100, var8, false);
    org.jfree.chart.util.SortOrder var11 = var5.getColumnRenderingOrder();
    java.awt.Paint var12 = var5.getRangeMinorGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis(0);
    java.awt.Stroke var16 = var13.getRangeCrosshairStroke();
    java.awt.Stroke var17 = var13.getRangeZeroBaselineStroke();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    var18.setTickLabelsVisible(false);
    var18.setAxisLineVisible(true);
    java.awt.Paint var23 = var18.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem(var0, "", "", "hi!", var4, var12, var17, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis(0);
//     java.awt.Stroke var16 = var13.getRangeCrosshairStroke();
//     java.awt.Stroke var17 = var13.getRangeZeroBaselineStroke();
//     var6.setDomainCrosshairStroke(var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDefaultLabelFont(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var1.setRenderer(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var6 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var1, "hi!", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(10.0d, var4, var5, false);
    org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
    org.jfree.chart.plot.Marker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var11 = var0.removeRangeMarker(var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     var0.setDomainCrosshairVisible(false);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawBackground(var9, var10);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = var0.getBoolean(0);
    var0.setBoolean(1, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     boolean var3 = var1.getAllowNull();
//     java.awt.Paint var5 = var1.getSeriesLabelPaint(1);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.plot.CategoryMarker var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    var0.setDomainCrosshairVisible(true);
    var0.setBackgroundImageAlpha(0.0f);
    boolean var8 = var0.isRangeZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    boolean var15 = var14.isShapeFilled();
    var14.setLineVisible(false);
    java.awt.Shape var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setLine(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedDomainAxisSpace(var3, false);
    boolean var6 = var0.canSelectByPoint();
    org.jfree.chart.axis.AxisLocation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.LegendItemCollection var1 = new org.jfree.chart.LegendItemCollection();
//     var0.addAll(var1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var7 = var5.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var5.setDomainAxis(0, var9);
    boolean var11 = var5.isDomainZoomable();
    org.jfree.chart.plot.Plot var12 = var5.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var5);
    java.util.List var14 = var5.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes(10, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     boolean var15 = var14.isShapeFilled();
//     org.jfree.chart.renderer.RenderAttributes var17 = new org.jfree.chart.renderer.RenderAttributes(false);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.configureDomainAxes();
//     java.awt.Paint var20 = var18.getDomainGridlinePaint();
//     var17.setDefaultOutlinePaint(var20);
//     var14.setOutlinePaint(var20);
//     
//     // Checks the contract:  equals-hashcode on var10 and var18
//     assertTrue("Contract failed: equals-hashcode on var10 and var18", var10.equals(var18) ? var10.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var10
//     assertTrue("Contract failed: equals-hashcode on var18 and var10", var18.equals(var10) ? var18.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var3 = var1.equals((java.lang.Object)var2);
//     java.lang.String var4 = var2.getLabelURL();
//     org.jfree.chart.renderer.RenderAttributes var6 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var7 = var6.getDefaultLabelFont();
//     java.awt.Paint var8 = var6.getDefaultPaint();
//     var2.setLabelPaint(var8);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var2.getCategorySeriesMiddle((java.lang.Comparable)(byte)1, (java.lang.Comparable)10.0d, var12, 8.0d, var14, var15);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(100, var9, false);
//     java.util.List var12 = var6.getCategories();
//     boolean var13 = var6.isDomainGridlinesVisible();
//     boolean var14 = var3.equals((java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, (-1.0d), (-1.0d), 10.0d, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    var8.setDomainAxis(100, var11, false);
    org.jfree.chart.util.SortOrder var14 = var8.getColumnRenderingOrder();
    var0.setColumnRenderingOrder(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    var0.setBackgroundAlpha((-1.0f));
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawBackgroundImage(var9, var10);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    var13.setTickLabelsVisible(false);
    var13.setMaximumCategoryLabelLines((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-1), var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    boolean var8 = var0.isRangeCrosshairVisible();
    org.jfree.chart.LegendItemCollection var9 = var0.getLegendItems();
    java.awt.Image var10 = null;
    var0.setBackgroundImage(var10);
    int var12 = var0.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    var14.setDescription("");
    java.awt.Shape var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setShape(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(100, var4, false);
    org.jfree.chart.util.SortOrder var7 = var1.getColumnRenderingOrder();
    var1.clearRangeAxes();
    var1.setRangeMinorGridlinesVisible(false);
    org.jfree.chart.plot.PlotOrientation var11 = var1.getOrientation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDomainCrosshairVisible(true);
    var0.setRangeCrosshairValue(10.0d, false);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var0.zoomDomainAxes(1.0d, var7, var8, false);
    org.jfree.chart.util.Layer var12 = null;
    java.util.Collection var13 = var0.getRangeMarkers(4, var12);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    var15.setDomainAxis(0, var19);
    boolean var21 = var15.isDomainZoomable();
    org.jfree.chart.plot.Plot var22 = var15.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
    java.util.List var24 = var15.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxes(15, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     java.awt.Paint var2 = var0.getDomainGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomRangeAxes(10.0d, var4, var5, false);
//     org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
//     org.jfree.chart.event.MarkerChangeEvent var9 = null;
//     var0.markerChanged(var9);
//     org.jfree.chart.axis.AxisLocation var12 = null;
//     var0.setDomainAxisLocation(10, var12);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
//     java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
//     var0.setRangeGridlineStroke(var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setTickLabelsVisible(false);
//     java.awt.Font var8 = var5.getLabelFont();
//     var5.setLabelToolTip("hi!");
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var13 = var11.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     var11.setDomainAxis(0, var15);
//     boolean var17 = var11.isDomainZoomable();
//     var11.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.configureDomainAxes();
//     java.awt.Paint var22 = var20.getDomainGridlinePaint();
//     var11.setRangeZeroBaselinePaint(var22);
//     var5.setLabelPaint(var22);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis();
//     var25.setDomainAxis(100, var28, false);
//     org.jfree.chart.util.SortOrder var31 = var25.getColumnRenderingOrder();
//     java.awt.Paint var32 = var25.getRangeMinorGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var35 = var33.getDomainAxis(0);
//     java.awt.Stroke var36 = var33.getRangeCrosshairStroke();
//     java.awt.Stroke var37 = var33.getRangeZeroBaselineStroke();
//     var25.setRangeMinorGridlineStroke(var37);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var42 = var40.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
//     var40.setDomainAxis(0, var44);
//     boolean var46 = var40.isDomainZoomable();
//     var40.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.configureDomainAxes();
//     java.awt.Paint var51 = var49.getDomainGridlinePaint();
//     var40.setRangeZeroBaselinePaint(var51);
//     org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("", var51);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var22, var37, var51);
//     
//     // Checks the contract:  equals-hashcode on var11 and var40
//     assertTrue("Contract failed: equals-hashcode on var11 and var40", var11.equals(var40) ? var11.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var33
//     assertTrue("Contract failed: equals-hashcode on var20 and var33", var20.equals(var33) ? var20.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var49
//     assertTrue("Contract failed: equals-hashcode on var20 and var49", var20.equals(var49) ? var20.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var20
//     assertTrue("Contract failed: equals-hashcode on var33 and var20", var33.equals(var20) ? var33.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var49
//     assertTrue("Contract failed: equals-hashcode on var33 and var49", var33.equals(var49) ? var33.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var11
//     assertTrue("Contract failed: equals-hashcode on var40 and var11", var40.equals(var11) ? var40.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var20
//     assertTrue("Contract failed: equals-hashcode on var49 and var20", var49.equals(var20) ? var49.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var33
//     assertTrue("Contract failed: equals-hashcode on var49 and var33", var49.equals(var33) ? var49.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    org.jfree.chart.annotations.CategoryAnnotation var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject((java.lang.Comparable)'#', (java.lang.Comparable)(short)(-1));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     org.jfree.chart.plot.PlotState var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.draw(var7, var8, var9, var10, var11);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
//     var6.setInsets(var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var18 = null;
//     var15.setFixedDomainAxisSpace(var18, false);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setDomainAxis(0, var25);
//     var15.setParent((org.jfree.chart.plot.Plot)var21);
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     java.awt.geom.Point2D var30 = null;
//     var15.zoomDomainAxes(0.0d, var29, var30);
//     boolean var32 = var13.equals((java.lang.Object)var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(10.0d, var4, var5, false);
    org.jfree.chart.plot.Marker var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var0.removeRangeMarker(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
//     int var8 = var0.getRendererCount();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(100, var12, false);
//     org.jfree.chart.util.SortOrder var15 = var9.getColumnRenderingOrder();
//     java.awt.Paint var16 = var9.getRangeMinorGridlinePaint();
//     int var17 = var9.getRendererCount();
//     org.jfree.chart.axis.CategoryAnchor var18 = var9.getDomainGridlinePosition();
//     var0.setDomainGridlinePosition(var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     var6.setRangePannable(false);
//     org.jfree.chart.plot.Marker var16 = null;
//     org.jfree.chart.util.Layer var17 = null;
//     var6.addRangeMarker(100, var16, var17);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    var0.configureDomainAxes();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 1);
    float[] var6 = new float[] { (-1.0f), 10.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var2.getComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    java.awt.Stroke var3 = var0.getOutlineStroke();
    float var4 = var0.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5f);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     var14.setDescription("");
//     var14.setSeriesIndex(0);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var19.setDomainAxis(100, var22, false);
//     org.jfree.chart.util.SortOrder var25 = var19.getColumnRenderingOrder();
//     java.awt.Paint var26 = var19.getRangeMinorGridlinePaint();
//     var14.setLinePaint(var26);
//     
//     // Checks the contract:  equals-hashcode on var10 and var19
//     assertTrue("Contract failed: equals-hashcode on var10 and var19", var10.equals(var19) ? var10.hashCode() == var19.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var19.", var10.equals(var19) == var19.equals(var10));
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var4 = var3.getTop();
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var3.createOutsetRectangle(var5, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var4 = var3.getTop();
    double var6 = var3.calculateBottomInset(4.0d);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var3.createInsetRectangle(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4.0d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.axis.CategoryLabelPositions var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setCategoryLabelPositions(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedDomainAxisSpace(var9, false);
    var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
    var6.setDomainCrosshairColumnKey((java.lang.Comparable)0L, true);
    org.jfree.chart.axis.AxisLocation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setDomainAxisLocation(var16, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "CategoryAnchor.MIDDLE");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    java.awt.Stroke var5 = var0.getSeriesStroke(15);
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(10.0d, var4, var5, false);
    org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
    org.jfree.chart.plot.CategoryMarker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(15, var10, var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
//     java.awt.Stroke var4 = var0.getRangeZeroBaselineStroke();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.configureDomainAxes();
//     java.awt.Paint var7 = var5.getDomainGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     var5.zoomRangeAxes(10.0d, var9, var10, false);
//     org.jfree.chart.plot.DrawingSupplier var13 = var5.getDrawingSupplier();
//     var0.setDrawingSupplier(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.plot.Marker var8 = null;
//     org.jfree.chart.util.Layer var9 = null;
//     boolean var11 = var0.removeDomainMarker(10, var8, var9, false);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var0.getRendererForDataset(var12);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     var14.setFixedDomainAxisSpace(var17, false);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var22 = var20.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     var20.setDomainAxis(0, var24);
//     var14.setParent((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.util.RectangleInsets var27 = new org.jfree.chart.util.RectangleInsets();
//     var20.setInsets(var27);
//     var0.setInsets(var27);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    java.lang.Comparable var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setValue((-1.0d), var18, (java.lang.Comparable)1L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.urls.CategoryURLGenerator var8 = null;
    var0.setSeriesURLGenerator(15, var8);
    org.jfree.chart.renderer.RenderAttributes var12 = new org.jfree.chart.renderer.RenderAttributes(false);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.configureDomainAxes();
    java.awt.Paint var15 = var13.getDomainGridlinePaint();
    var12.setDefaultOutlinePaint(var15);
    java.awt.Paint var19 = var12.getItemOutlinePaint(10, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlinePaint((-1), var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    var0.setSeriesLinesVisible(100, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedDomainAxisSpace(var3, false);
    boolean var6 = var0.canSelectByPoint();
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var1 = var0.getDefaultPaint();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.configureDomainAxes();
    java.awt.Paint var4 = var2.getDomainGridlinePaint();
    var0.setDefaultPaint(var4);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setTickLabelsVisible(false);
    var7.setAxisLineVisible(true);
    java.awt.Paint var12 = var7.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", 1);
//     java.awt.Color var3 = var2.brighter();
//     java.awt.color.ColorSpace var4 = null;
//     float[] var6 = new float[] { 100.0f};
//     float[] var7 = var3.getComponents(var4, var6);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    boolean var5 = var3.equals((java.lang.Object)var4);
    boolean var6 = var4.isAxisLineVisible();
    var0.setObject((java.lang.Object)var4, (java.lang.Comparable)10.0f, (java.lang.Comparable)4);
    java.lang.Object var12 = var0.getObject(0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)'a', (java.lang.Comparable)(-1L));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     var0.zoom(0.0d);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var3.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var3.getBasePositiveItemLabelPosition();
//     var0.setSeriesNegativeItemLabelPosition(100, var8, true);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var14 = var12.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var15 = null;
//     var12.setFixedDomainAxisSpace(var15, false);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setDomainAxis(0, var22);
//     var12.setParent((org.jfree.chart.plot.Plot)var18);
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.configureDomainAxes();
//     java.awt.Paint var29 = var27.getDomainGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var32 = var30.getDomainAxis(0);
//     java.awt.Stroke var33 = var30.getRangeCrosshairStroke();
//     java.awt.Stroke var34 = var30.getRangeZeroBaselineStroke();
//     var0.drawDomainLine(var11, var12, var25, 100.0d, var29, var34);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     var6.clearRangeAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var6.handleClick(100, 1, var16);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    boolean var4 = var2.equals((java.lang.Object)var3);
    boolean var5 = var3.isAxisLineVisible();
    var0.setObject((java.lang.Object)var5, (java.lang.Comparable)(byte)10, (java.lang.Comparable)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var10 = var0.getColumnKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var0.setBaseToolTipGenerator(var10, false);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var14.setDomainAxis(100, var17, false);
    org.jfree.chart.util.SortOrder var20 = var14.getColumnRenderingOrder();
    java.awt.Paint var21 = var14.getRangeMinorGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var24 = var22.getDomainAxis(0);
    java.awt.Stroke var25 = var22.getRangeCrosshairStroke();
    java.awt.Stroke var26 = var22.getRangeZeroBaselineStroke();
    var14.setRangeMinorGridlineStroke(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesStroke((-1), var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", 1);
//     java.awt.Color var3 = var2.brighter();
//     java.awt.color.ColorSpace var4 = null;
//     float[] var5 = new float[] { };
//     float[] var6 = var2.getComponents(var4, var5);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    boolean var15 = var14.isShapeFilled();
    var14.setLineVisible(false);
    var14.setURLText("hi!");
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var21 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    boolean var23 = var21.equals((java.lang.Object)var22);
    java.lang.String var24 = var22.getLabelURL();
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var28 = var26.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.Paint var29 = var26.getAxisLinePaint();
    var22.setTickLabelPaint((java.lang.Comparable)(short)100, var29);
    var14.setFillPaint(var29);
    java.awt.Shape var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setLine(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var4 = var3.getTop();
    double var6 = var3.trimWidth(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-14.0d));

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var13 = var11.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    var11.setDomainAxis(0, var15);
    boolean var17 = var11.isDomainZoomable();
    var11.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.configureDomainAxes();
    java.awt.Paint var22 = var20.getDomainGridlinePaint();
    var11.setRangeZeroBaselinePaint(var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.CategoryMarker var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    java.awt.Stroke var5 = var0.getSeriesStroke(15);
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.configureDomainAxes();
    java.awt.Stroke var10 = var8.getRangeGridlineStroke();
    var0.setBaseOutlineStroke(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var2 = var1.getBaseSeriesVisibleInLegend();
    java.awt.Paint var4 = var1.lookupLegendTextPaint(15);
    boolean var5 = var1.getBaseSeriesVisibleInLegend();
    var1.setBaseShapesVisible(false);
    boolean var8 = var1.getBaseShapesFilled();
    org.jfree.chart.labels.ItemLabelPosition var12 = var1.getPositiveItemLabelPosition((-1), 1, true);
    org.jfree.chart.text.TextAnchor var13 = var12.getTextAnchor();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var15 = var14.getBaseSeriesVisibleInLegend();
    java.awt.Paint var17 = var14.lookupLegendTextPaint(15);
    boolean var18 = var14.getBaseSeriesVisibleInLegend();
    var14.setBaseShapesVisible(false);
    boolean var21 = var14.getBaseShapesFilled();
    org.jfree.chart.labels.ItemLabelPosition var25 = var14.getPositiveItemLabelPosition((-1), 1, true);
    org.jfree.chart.text.TextAnchor var26 = var25.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var28 = new org.jfree.chart.labels.ItemLabelPosition(var0, var13, var26, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", var1);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 1);
    float[] var4 = new float[] { 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = var2.getRGBColorComponents(var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("", 1);
//     java.awt.Color var4 = var3.brighter();
//     java.awt.Color var5 = java.awt.Color.getColor("", var4);
//     java.awt.color.ColorSpace var6 = null;
//     float[] var8 = new float[] { 100.0f};
//     float[] var9 = var4.getComponents(var6, var8);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("", 1);
//     java.awt.Color var4 = var3.brighter();
//     java.awt.Color var5 = java.awt.Color.getColor("", var4);
//     java.awt.Color var6 = var5.darker();
//     java.awt.color.ColorSpace var7 = null;
//     float[] var11 = new float[] { 100.0f, 100.0f, 10.0f};
//     float[] var12 = var5.getComponents(var7, var11);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    var0.setBackgroundAlpha((-1.0f));
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     java.util.List var6 = var0.getCategories();
//     boolean var7 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setTickLabelsVisible(false);
//     var8.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var8.getCategoryStart(10, (-1), var15, var16);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var20 = var18.getColumnRenderingOrder();
//     var8.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var18);
//     java.awt.Paint var22 = var18.getRangeCrosshairPaint();
//     var0.setDomainCrosshairPaint(var22);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var0.", var18.equals(var0) == var0.equals(var18));
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeColumn(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setTickLabelsVisible(false);
//     var1.setAxisLineVisible(true);
//     java.awt.Paint var6 = var1.getAxisLinePaint();
//     var0.setRangeCrosshairPaint(var6);
//     float var8 = var0.getBackgroundAlpha();
//     var0.setDomainCrosshairVisible(true);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     org.jfree.chart.plot.PlotState var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var0.draw(var11, var12, var13, var14, var15);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
//     int var8 = var0.getRendererCount();
//     org.jfree.chart.axis.CategoryAnchor var9 = var0.getDomainGridlinePosition();
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var0.drawBackground(var10, var11);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     int var2 = var0.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var4 = var3.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
//     boolean var7 = var3.getBaseSeriesVisibleInLegend();
//     var3.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
//     var3.setBaseToolTipGenerator(var10, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var14 = var13.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var16 = var13.lookupLegendTextPaint(15);
//     boolean var17 = var13.getBaseSeriesVisibleInLegend();
//     var13.setBaseShapesVisible(false);
//     boolean var20 = var13.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var13.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var25 = var24.getTextAnchor();
//     var3.setBaseNegativeItemLabelPosition(var24);
//     var0.setBaseNegativeItemLabelPosition(var24);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     var29.setRangeAxis(1, var31, true);
//     org.jfree.chart.axis.AxisSpace var34 = null;
//     var29.setFixedRangeAxisSpace(var34, false);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     java.awt.Paint var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
//     var41.setDomainAxis(100, var44, false);
//     org.jfree.chart.util.SortOrder var47 = var41.getColumnRenderingOrder();
//     java.awt.Paint var48 = var41.getRangeMinorGridlinePaint();
//     boolean var49 = var41.isRangeCrosshairVisible();
//     java.awt.Stroke var50 = var41.getDomainGridlineStroke();
//     var0.drawRangeLine(var28, var29, var37, var38, (-1.0d), var40, var50);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.configureDomainAxes();
//     java.awt.Paint var10 = var8.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleInsets var11 = var8.getInsets();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var14 = var12.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setDomainAxis(0, var16);
//     boolean var18 = var12.isDomainZoomable();
//     var12.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var21 = null;
//     var12.markerChanged(var21);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     java.awt.geom.Point2D var25 = null;
//     var12.zoomDomainAxes(0.0d, var24, var25);
//     org.jfree.data.category.DefaultCategoryDataset var27 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = var12.getRendererForDataset((org.jfree.data.category.CategoryDataset)var27);
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
//     var29.setTickLabelsVisible(false);
//     java.awt.Font var32 = var29.getLabelFont();
//     var29.setLabelToolTip("hi!");
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var37 = var36.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var39 = var36.lookupLegendTextPaint(15);
//     boolean var40 = var36.getBaseSeriesVisibleInLegend();
//     var36.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
//     var36.setBaseToolTipGenerator(var43, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var46 = null;
//     var36.setBaseToolTipGenerator(var46, false);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, var29, var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var51 = var0.initialise(var6, var7, var8, (org.jfree.data.category.CategoryDataset)var27, var50);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var36 and var0.", var36.equals(var0) == var0.equals(var36));
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     boolean var12 = var6.isDomainZoomable();
//     org.jfree.chart.plot.Plot var13 = var6.getRootPlot();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.configureDomainAxes();
//     java.awt.Paint var16 = var14.getDomainGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var14.zoomRangeAxes(10.0d, var18, var19, false);
//     org.jfree.chart.plot.DrawingSupplier var22 = var14.getDrawingSupplier();
//     var13.setDrawingSupplier(var22, true);
//     var0.setDrawingSupplier(var22);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.lang.Boolean var10 = var0.getSeriesShapesVisible(10);
    var0.setUseFillPaint(true);
    boolean var13 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var5 = var4.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var7 = var4.lookupLegendTextPaint(15);
//     boolean var8 = var4.getBaseSeriesVisibleInLegend();
//     var4.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
//     var4.setBaseToolTipGenerator(var11, false);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var17 = var15.getTickLabelPaint((java.lang.Comparable)0);
//     var4.setSeriesOutlinePaint(4, var17, true);
//     var1.setSeriesLabelPaint(10, var17);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var8.setTickLabelsVisible(false);
    var8.setAxisLineVisible(true);
    java.awt.Paint var13 = var8.getAxisLinePaint();
    var7.setRangeCrosshairPaint(var13);
    float var15 = var7.getBackgroundAlpha();
    java.awt.Paint var16 = var7.getOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    var17.setMaximumCategoryLabelLines((-1));
    var17.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.configureDomainAxes();
    java.awt.Paint var26 = var24.getDomainGridlinePaint();
    java.lang.Object var27 = var24.clone();
    var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
    java.awt.Graphics2D var29 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    org.jfree.chart.axis.AxisState var33 = null;
    var17.drawTickMarks(var29, 4.0d, var31, var32, var33);
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var38 = var36.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
    var36.setDomainAxis(0, var40);
    boolean var42 = var36.isDomainZoomable();
    var36.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var45 = null;
    var36.markerChanged(var45);
    org.jfree.chart.plot.PlotRenderingInfo var48 = null;
    java.awt.geom.Point2D var49 = null;
    var36.zoomDomainAxes(0.0d, var48, var49);
    org.jfree.data.category.DefaultCategoryDataset var51 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = var36.getRendererForDataset((org.jfree.data.category.CategoryDataset)var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var4, var5, var6, var7, var17, var35, (org.jfree.data.category.CategoryDataset)var51, (-1), 100, false, 4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    var0.configureDomainAxes();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var8.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var14 = var8.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    boolean var16 = var8.removeAnnotation(var15);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    var18.setDomainAxis(0, var22);
    boolean var24 = var18.isDomainZoomable();
    org.jfree.chart.plot.Marker var26 = null;
    org.jfree.chart.util.Layer var27 = null;
    boolean var29 = var18.removeDomainMarker(10, var26, var27, false);
    org.jfree.data.category.CategoryDataset var30 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = var18.getRendererForDataset(var30);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.plot.Marker var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    var8.drawRangeMarker(var17, var18, var32, var33, var34);
    java.lang.Boolean var37 = null;
    var8.setSeriesVisible(10, var37, true);
    boolean var40 = var8.getBaseSeriesVisibleInLegend();
    boolean var43 = var8.getItemShapeFilled(1, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-2), (org.jfree.chart.renderer.category.CategoryItemRenderer)var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    java.awt.Font var20 = var17.getLabelFont();
    var17.setLabelToolTip("hi!");
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var25 = var24.getBaseSeriesVisibleInLegend();
    java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
    boolean var28 = var24.getBaseSeriesVisibleInLegend();
    var24.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var24.setBaseToolTipGenerator(var31, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var24.setBaseToolTipGenerator(var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var17, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var40 = var24.getLegendItem(4, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var2 = var0.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var0.getCategoryEnd((-1), (-1), var5, var6);
    float var8 = var0.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    var10.setTickLabelsVisible(false);
    var10.setAxisLineVisible(true);
    java.awt.Paint var15 = var10.getAxisLinePaint();
    var9.setRangeCrosshairPaint(var15);
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartChangeEventType var18 = null;
    org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var17, var18);
    var0.setAxisLinePaint(var15);
    java.awt.Font var21 = var0.getLabelFont();
    org.jfree.chart.util.RectangleInsets var22 = var0.getLabelInsets();
    org.jfree.data.KeyedObjects2D var24 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var26 = var25.getBaseSeriesVisibleInLegend();
    java.awt.Paint var28 = var25.lookupLegendTextPaint(15);
    boolean var29 = var25.getBaseSeriesVisibleInLegend();
    var25.setBaseShapesVisible(false);
    var24.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var35 = var24.getColumnKeys();
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var38 = var0.getCategoryMiddle((java.lang.Comparable)1.0d, var35, var36, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.lang.String var4 = var2.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var6 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var7 = var6.getDefaultLabelFont();
    java.awt.Paint var8 = var6.getDefaultPaint();
    var2.setLabelPaint(var8);
    org.jfree.chart.util.RectangleInsets var10 = var2.getTickLabelInsets();
    double var12 = var10.calculateBottomInset((-1.0d));
    double var14 = var10.calculateTopOutset(100.0d);
    java.awt.geom.Rectangle2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var16 = var10.createOutsetRectangle(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-1), var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = null;
//     var1.setSeriesShape(0, var4);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setTickLabelsVisible(false);
//     var6.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var6.getCategoryStart(10, (-1), var13, var14);
//     java.awt.Font var17 = var6.getTickLabelFont((java.lang.Comparable)'4');
//     var1.setDefaultLabelFont(var17);
//     java.awt.Paint var21 = var1.getItemOutlinePaint(1, 15);
//     var1.setSeriesLabelVisible(4, (java.lang.Boolean)false);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisLinePaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var6 = var5.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var8 = var7.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var10 = var7.lookupLegendTextPaint(15);
//     boolean var11 = var7.getBaseSeriesVisibleInLegend();
//     var7.setBaseShapesVisible(false);
//     boolean var14 = var7.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var7.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var19 = var18.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var20 = new org.jfree.chart.labels.ItemLabelPosition(var6, var19);
//     
//     // Checks the contract:  equals-hashcode on var5 and var18
//     assertTrue("Contract failed: equals-hashcode on var5 and var18", var5.equals(var18) ? var5.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var20
//     assertTrue("Contract failed: equals-hashcode on var5 and var20", var5.equals(var20) ? var5.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var5
//     assertTrue("Contract failed: equals-hashcode on var18 and var5", var18.equals(var5) ? var18.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var20
//     assertTrue("Contract failed: equals-hashcode on var18 and var20", var18.equals(var20) ? var18.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var5
//     assertTrue("Contract failed: equals-hashcode on var20 and var5", var20.equals(var5) ? var20.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var18
//     assertTrue("Contract failed: equals-hashcode on var20 and var18", var20.equals(var18) ? var20.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setTickLabelsVisible(false);
//     var1.setAxisLineVisible(true);
//     java.awt.Paint var6 = var1.getAxisLinePaint();
//     var0.setRangeCrosshairPaint(var6);
//     float var8 = var0.getBackgroundAlpha();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(0, var13);
//     boolean var15 = var9.isDomainZoomable();
//     org.jfree.chart.plot.Plot var16 = var9.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var9);
//     var0.notifyListeners(var17);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var0.handleClick(2, 15, var21);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var5 = var4.getBaseSeriesVisibleInLegend();
    java.awt.Paint var7 = var4.lookupLegendTextPaint(15);
    boolean var8 = var4.getBaseSeriesVisibleInLegend();
    var4.setBaseShapesVisible(false);
    java.awt.Shape var12 = var4.lookupLegendShape(100);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
    var13.setDomainAxis(100, var16, false);
    java.util.List var19 = var13.getCategories();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var22 = var20.getDomainAxis(0);
    java.awt.Stroke var23 = var20.getRangeCrosshairStroke();
    java.awt.Stroke var24 = var20.getRangeZeroBaselineStroke();
    var13.setOutlineStroke(var24);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var27 = var26.getBaseSeriesVisibleInLegend();
    java.awt.Paint var29 = var26.lookupLegendTextPaint(15);
    boolean var30 = var26.getBaseSeriesVisibleInLegend();
    var26.setBaseShapesVisible(false);
    var26.setBaseCreateEntities(true);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var38 = var36.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
    var36.setDomainAxis(0, var40);
    boolean var42 = var36.isDomainZoomable();
    var36.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
    var45.configureDomainAxes();
    java.awt.Paint var47 = var45.getDomainGridlinePaint();
    var36.setRangeZeroBaselinePaint(var47);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", var47);
    boolean var50 = var49.isShapeFilled();
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
    var52.setTickLabelsVisible(false);
    var52.setAxisLineVisible(true);
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var51.setRangeCrosshairPaint(var57);
    float var59 = var51.getBackgroundAlpha();
    java.awt.Paint var60 = var51.getOutlinePaint();
    var49.setLabelPaint(var60);
    var49.setSeriesIndex(0);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var65 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis();
    boolean var67 = var65.equals((java.lang.Object)var66);
    java.lang.String var68 = var66.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var70 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var71 = var70.getDefaultLabelFont();
    java.awt.Paint var72 = var70.getDefaultPaint();
    var66.setLabelPaint(var72);
    var49.setLinePaint(var72);
    var26.setBasePaint(var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var76 = new org.jfree.chart.LegendItem(var0, "hi!", "", "Category Plot", var12, var24, var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDomainCrosshairVisible(true);
    org.jfree.chart.event.AnnotationChangeEvent var3 = null;
    var0.annotationChanged(var3);
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var6 = org.jfree.chart.axis.AxisLocation.getOpposite(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(1, var2, true);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedRangeAxisSpace(var5, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var8.getLegendItemURLGenerator();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var19 = var17.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var17.setDomainAxis(0, var21);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var25 = var23.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var26 = null;
    var23.setFixedDomainAxisSpace(var26, false);
    var21.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var8.drawRangeMarker(var16, var23, var30, var31, var32);
    org.jfree.chart.event.RendererChangeEvent var34 = null;
    var23.rendererChanged(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     boolean var3 = var1.getAllowNull();
//     var1.setDefaultCreateEntity((java.lang.Boolean)false);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var10 = var8.equals((java.lang.Object)var9);
//     java.lang.String var11 = var9.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.Paint var16 = var13.getAxisLinePaint();
//     var9.setTickLabelPaint((java.lang.Comparable)(short)100, var16);
//     var1.setSeriesFillPaint(0, var16);
//     java.awt.Paint var21 = var1.getItemLabelPaint((-1), 15);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(10.0d, var4, var5, false);
    org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.axis.AxisLocation var12 = null;
    var0.setDomainAxisLocation(10, var12);
    org.jfree.chart.plot.Marker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var17 = var0.removeRangeMarker(1, var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var15.getValue(10, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var3 = var1.equals((java.lang.Object)var2);
//     java.lang.String var4 = var2.getLabelURL();
//     float var5 = var2.getMinorTickMarkInsideLength();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var9.setFixedDomainAxisSpace(var12, false);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setDomainAxis(0, var19);
//     var9.setParent((org.jfree.chart.plot.Plot)var15);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     java.awt.geom.Point2D var24 = null;
//     var9.zoomDomainAxes(0.0d, var23, var24);
//     java.util.List var26 = var9.getAnnotations();
//     org.jfree.chart.util.RectangleEdge var28 = var9.getDomainAxisEdge(100);
//     double var29 = var2.getCategoryStart((-2), (-1), var8, var28);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var6 = var5.getBaseSeriesVisibleInLegend();
    java.awt.Paint var8 = var5.lookupLegendTextPaint(15);
    boolean var9 = var5.getBaseSeriesVisibleInLegend();
    var5.setBaseShapesVisible(false);
    java.awt.Shape var13 = var5.lookupLegendShape(100);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    var16.setDomainAxis(100, var19, false);
    java.util.List var22 = var16.getCategories();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var25 = var23.getDomainAxis(0);
    java.awt.Stroke var26 = var23.getRangeCrosshairStroke();
    java.awt.Stroke var27 = var23.getRangeZeroBaselineStroke();
    var16.setOutlineStroke(var27);
    var15.setDomainGridlineStroke(var27);
    java.awt.Paint var30 = var15.getDomainGridlinePaint();
    java.awt.Color var35 = java.awt.Color.getColor("", 1);
    java.awt.Color var36 = var35.brighter();
    java.awt.Color var37 = java.awt.Color.getColor("", var36);
    java.awt.color.ColorSpace var38 = var36.getColorSpace();
    java.awt.Stroke var39 = null;
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var44 = var42.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis();
    var42.setDomainAxis(0, var46);
    boolean var48 = var42.isDomainZoomable();
    var42.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    var51.configureDomainAxes();
    java.awt.Paint var53 = var51.getDomainGridlinePaint();
    var42.setRangeZeroBaselinePaint(var53);
    org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("", var53);
    var55.setDescription("");
    var55.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
    java.awt.Shape var60 = var55.getLine();
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
    var61.configureDomainAxes();
    java.awt.Stroke var63 = var61.getRangeGridlineStroke();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var65 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis();
    boolean var67 = var65.equals((java.lang.Object)var66);
    java.lang.String var69 = var66.getCategoryLabelToolTip((java.lang.Comparable)10L);
    org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var73 = var71.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var75 = new org.jfree.chart.axis.CategoryAxis();
    var71.setDomainAxis(0, var75);
    boolean var77 = var71.isDomainZoomable();
    var71.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot();
    var80.configureDomainAxes();
    java.awt.Paint var82 = var80.getDomainGridlinePaint();
    var71.setRangeZeroBaselinePaint(var82);
    org.jfree.chart.LegendItem var84 = new org.jfree.chart.LegendItem("", var82);
    var66.setAxisLinePaint(var82);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var86 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", "DatasetRenderingOrder.REVERSE", "hi!", "DatasetRenderingOrder.REVERSE", true, var13, false, var30, true, (java.awt.Paint)var36, var39, false, var60, var63, var82);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var5 = var3.calculateLeftOutset(4.0d);
    double var6 = var3.getLeft();
    double var7 = var3.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Paint var1 = var0.getBaseItemLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.data.event.DatasetChangeListener var17 = null;
    var15.removeChangeListener(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeColumn((java.lang.Comparable)100L);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var2.getCategorySeriesMiddle((-1), 10, 0, 1, 10.0d, var9, var10);
    boolean var12 = var2.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     boolean var3 = var1.getAllowNull();
//     var1.setSeriesCreateEntity(4, (java.lang.Boolean)true);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     var14.setDescription("");
//     var14.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
//     java.awt.Shape var19 = var14.getLine();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
//     var20.setDomainAxis(100, var23, false);
//     org.jfree.chart.util.SortOrder var26 = var20.getColumnRenderingOrder();
//     java.awt.Paint var27 = var20.getRangeMinorGridlinePaint();
//     boolean var28 = var20.isRangeCrosshairVisible();
//     org.jfree.chart.axis.AxisLocation var30 = null;
//     var20.setDomainAxisLocation(1, var30);
//     org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var19, (org.jfree.chart.plot.Plot)var20, "hi!");
//     
//     // Checks the contract:  equals-hashcode on var10 and var20
//     assertTrue("Contract failed: equals-hashcode on var10 and var20", var10.equals(var20) ? var10.hashCode() == var20.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var20.", var10.equals(var20) == var20.equals(var10));
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    int var3 = java.awt.Color.HSBtoRGB(2.0f, 0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-100));

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var7 = null;
//     boolean var8 = var0.removeAnnotation(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.Marker var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var0.drawRangeMarker(var9, var10, var24, var25, var26);
//     java.lang.Boolean var29 = null;
//     var0.setSeriesVisible(10, var29, true);
//     boolean var32 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.urls.CategoryURLGenerator var34 = null;
//     var0.setSeriesURLGenerator(15, var34, false);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var39 = var37.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     var37.setDomainAxis(0, var41);
//     boolean var43 = var37.isDomainZoomable();
//     var37.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var46 = null;
//     var37.markerChanged(var46);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var37.zoomDomainAxes(0.0d, var49, var50);
//     org.jfree.data.category.DefaultCategoryDataset var52 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = var37.getRendererForDataset((org.jfree.data.category.CategoryDataset)var52);
//     org.jfree.data.event.DatasetChangeListener var54 = null;
//     var52.removeChangeListener(var54);
//     org.jfree.data.Range var56 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var52);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    int var2 = var0.getColumnCount();
    var0.setSeriesItemLabelsVisible(4, false);
    int var6 = var0.getPassCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-100), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.data.event.DatasetChangeListener var17 = null;
    var15.removeChangeListener(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeValue((java.lang.Comparable)(-14.0d), (java.lang.Comparable)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = null;
//     var1.setSeriesShape(0, var4);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setTickLabelsVisible(false);
//     var6.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var6.getCategoryStart(10, (-1), var13, var14);
//     java.awt.Font var17 = var6.getTickLabelFont((java.lang.Comparable)'4');
//     var1.setDefaultLabelFont(var17);
//     java.awt.Shape var20 = null;
//     var1.setSeriesShape(0, var20);
//     java.lang.Boolean var22 = var1.getDefaultCreateEntity();
//     java.lang.Boolean var24 = var1.getSeriesCreateEntity(1);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    var0.setDomainCrosshairVisible(true);
    var0.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.plot.CategoryMarker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(100, var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     var14.setDescription("");
//     var14.setSeriesIndex(0);
//     var14.setToolTipText("");
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     var21.setRangeAxis(1, var23, true);
//     org.jfree.chart.axis.AxisSpace var26 = null;
//     var21.setFixedRangeAxisSpace(var26, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var30 = var29.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var32 = var29.lookupLegendTextPaint(15);
//     boolean var33 = var29.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var34 = var29.getLegendItemURLGenerator();
//     var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var29, false);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var40 = var38.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis();
//     var38.setDomainAxis(0, var42);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var46 = var44.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var47 = null;
//     var44.setFixedDomainAxisSpace(var47, false);
//     var42.addChangeListener((org.jfree.chart.event.AxisChangeListener)var44);
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.plot.Marker var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     var29.drawRangeMarker(var37, var44, var51, var52, var53);
//     java.awt.Font var58 = var29.getItemLabelFont(0, 4, false);
//     var14.setLabelFont(var58);
//     
//     // Checks the contract:  equals-hashcode on var10 and var44
//     assertTrue("Contract failed: equals-hashcode on var10 and var44", var10.equals(var44) ? var10.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var10
//     assertTrue("Contract failed: equals-hashcode on var44 and var10", var44.equals(var10) ? var44.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     java.awt.Font var4 = var1.getSeriesLabelFont(15);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var7 = var5.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var5.setDomainAxis(0, var9);
    boolean var11 = var5.isDomainZoomable();
    var5.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.configureDomainAxes();
    java.awt.Paint var16 = var14.getDomainGridlinePaint();
    var5.setRangeZeroBaselinePaint(var16);
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("", var16);
    boolean var19 = var18.isShapeFilled();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var21.setTickLabelsVisible(false);
    var21.setAxisLineVisible(true);
    java.awt.Paint var26 = var21.getAxisLinePaint();
    var20.setRangeCrosshairPaint(var26);
    float var28 = var20.getBackgroundAlpha();
    java.awt.Paint var29 = var20.getOutlinePaint();
    var18.setLabelPaint(var29);
    var18.setSeriesIndex(0);
    var18.setDescription("CategoryAnchor.MIDDLE");
    var18.setLineVisible(false);
    java.awt.Shape var37 = var18.getShape();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var39 = var38.getBaseSeriesVisibleInLegend();
    java.awt.Paint var41 = var38.lookupLegendTextPaint(15);
    java.awt.Paint var43 = var38.getSeriesOutlinePaint(0);
    var38.setBaseItemLabelsVisible(false, true);
    var38.setDrawOutlines(false);
    java.awt.Paint var52 = var38.getItemLabelPaint(10, (-1), false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem(var0, "hi!", "", "CategoryAnchor.MIDDLE", var37, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     var0.clearRangeAxes();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setDomainAxis(0, var12);
//     boolean var14 = var8.isDomainZoomable();
//     var8.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.configureDomainAxes();
//     java.awt.Paint var19 = var17.getDomainGridlinePaint();
//     var8.setRangeZeroBaselinePaint(var19);
//     var0.setDomainGridlinePaint(var19);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var0.", var17.equals(var0) == var0.equals(var17));
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     var0.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var9 = null;
//     var0.markerChanged(var9);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     java.awt.geom.Point2D var13 = null;
//     var0.zoomDomainAxes(0.0d, var12, var13);
//     org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setTickLabelsVisible(false);
//     java.awt.Font var20 = var17.getLabelFont();
//     var17.setLabelToolTip("hi!");
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var25 = var24.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
//     boolean var28 = var24.getBaseSeriesVisibleInLegend();
//     var24.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var24.setBaseToolTipGenerator(var31, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
//     var24.setBaseToolTipGenerator(var34, false);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var17, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
//     org.jfree.data.general.DatasetGroup var38 = var15.getGroup();
//     java.lang.Object var39 = var38.clone();
//     java.lang.Object var40 = var38.clone();
//     
//     // Checks the contract:  equals-hashcode on var39 and var40
//     assertTrue("Contract failed: equals-hashcode on var39 and var40", var39.equals(var40) ? var39.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var39
//     assertTrue("Contract failed: equals-hashcode on var40 and var39", var40.equals(var39) ? var40.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.ItemLabelAnchor var6 = var5.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var8 = var7.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var10 = var9.getBaseSeriesVisibleInLegend();
//     int var11 = var9.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var13 = var12.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var15 = var12.lookupLegendTextPaint(15);
//     boolean var16 = var12.getBaseSeriesVisibleInLegend();
//     var12.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var19 = null;
//     var12.setBaseToolTipGenerator(var19, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var23 = var22.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var25 = var22.lookupLegendTextPaint(15);
//     boolean var26 = var22.getBaseSeriesVisibleInLegend();
//     var22.setBaseShapesVisible(false);
//     boolean var29 = var22.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var33 = var22.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var34 = var33.getTextAnchor();
//     var12.setBaseNegativeItemLabelPosition(var33);
//     var9.setBaseNegativeItemLabelPosition(var33);
//     var7.setBasePositiveItemLabelPosition(var33);
//     org.jfree.chart.text.TextAnchor var38 = var33.getTextAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var40 = var39.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var42 = var41.getBaseSeriesVisibleInLegend();
//     int var43 = var41.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var45 = var44.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var47 = var44.lookupLegendTextPaint(15);
//     boolean var48 = var44.getBaseSeriesVisibleInLegend();
//     var44.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
//     var44.setBaseToolTipGenerator(var51, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var55 = var54.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var57 = var54.lookupLegendTextPaint(15);
//     boolean var58 = var54.getBaseSeriesVisibleInLegend();
//     var54.setBaseShapesVisible(false);
//     boolean var61 = var54.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var65 = var54.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var66 = var65.getTextAnchor();
//     var44.setBaseNegativeItemLabelPosition(var65);
//     var41.setBaseNegativeItemLabelPosition(var65);
//     var39.setBasePositiveItemLabelPosition(var65);
//     org.jfree.chart.text.TextAnchor var70 = var65.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var72 = new org.jfree.chart.labels.ItemLabelPosition(var6, var38, var70, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var0
//     assertTrue("Contract failed: equals-hashcode on var39 and var0", var39.equals(var0) ? var39.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var0.", var7.equals(var0) == var0.equals(var7));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var39 and var0.", var39.equals(var0) == var0.equals(var39));
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var65
//     assertTrue("Contract failed: equals-hashcode on var5 and var65", var5.equals(var65) ? var5.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var65
//     assertTrue("Contract failed: equals-hashcode on var33 and var65", var33.equals(var65) ? var33.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var5
//     assertTrue("Contract failed: equals-hashcode on var65 and var5", var65.equals(var5) ? var65.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var33
//     assertTrue("Contract failed: equals-hashcode on var65 and var33", var65.equals(var33) ? var65.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setTickLabelsVisible(false);
    var0.setAxisLineVisible(true);
    java.awt.Paint var5 = var0.getAxisLinePaint();
    var0.configure();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    boolean var10 = var8.equals((java.lang.Object)var9);
    java.lang.String var11 = var9.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var13 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var14 = var13.getDefaultLabelFont();
    java.awt.Paint var15 = var13.getDefaultPaint();
    var9.setLabelPaint(var15);
    org.jfree.chart.util.RectangleInsets var17 = var9.getTickLabelInsets();
    double var19 = var17.calculateBottomInset((-1.0d));
    var0.setTickLabelInsets(var17);
    java.awt.geom.Rectangle2D var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var22 = var17.createOutsetRectangle(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0d);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    int var3 = var0.getColumnIndex((java.lang.Comparable)(-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getRowKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     boolean var3 = var1.getAllowNull();
//     var1.setDefaultCreateEntity((java.lang.Boolean)false);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var10 = var8.equals((java.lang.Object)var9);
//     java.lang.String var11 = var9.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.Paint var16 = var13.getAxisLinePaint();
//     var9.setTickLabelPaint((java.lang.Comparable)(short)100, var16);
//     var1.setSeriesFillPaint(0, var16);
//     java.lang.Boolean var21 = var1.getCreateEntity((-2), 1);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    int var2 = var0.getColumnCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = null;
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    var8.setDomainAxis(0, var12);
    boolean var14 = var8.isDomainZoomable();
    var8.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var17 = null;
    var8.markerChanged(var17);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var8.zoomDomainAxes(0.0d, var20, var21);
    org.jfree.data.category.DefaultCategoryDataset var23 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = var8.getRendererForDataset((org.jfree.data.category.CategoryDataset)var23);
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
    var25.setTickLabelsVisible(false);
    java.awt.Font var28 = var25.getLabelFont();
    var25.setLabelToolTip("hi!");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var33 = var32.getBaseSeriesVisibleInLegend();
    java.awt.Paint var35 = var32.lookupLegendTextPaint(15);
    boolean var36 = var32.getBaseSeriesVisibleInLegend();
    var32.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var39 = null;
    var32.setBaseToolTipGenerator(var39, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var32.setBaseToolTipGenerator(var42, false);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, var25, var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
    org.jfree.chart.renderer.category.CategoryItemRendererState var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var50 = var0.createHotSpotShape(var3, var4, var5, var6, var7, (org.jfree.data.category.CategoryDataset)var23, 15, (-100), false, var49);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    java.util.List var6 = var0.getCategories();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis(0);
    java.awt.Stroke var10 = var7.getRangeCrosshairStroke();
    java.awt.Stroke var11 = var7.getRangeZeroBaselineStroke();
    var0.setOutlineStroke(var11);
    org.jfree.chart.event.ChartChangeEvent var13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    org.jfree.chart.event.ChartChangeEventType var14 = null;
    var13.setType(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    var0.setDomainCrosshairVisible(true);
    int var6 = var0.getDatasetCount();
    java.lang.String var7 = var0.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    java.lang.Boolean var8 = var0.getSeriesShapesFilled(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     java.awt.Paint var3 = var1.getDefaultPaint();
//     java.awt.Font var6 = var1.getItemLabelFont(2, 0);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var2 = var0.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var0.getCategoryEnd((-1), (-1), var5, var6);
    float var8 = var0.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    var10.setTickLabelsVisible(false);
    var10.setAxisLineVisible(true);
    java.awt.Paint var15 = var10.getAxisLinePaint();
    var9.setRangeCrosshairPaint(var15);
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartChangeEventType var18 = null;
    org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var17, var18);
    var0.setAxisLinePaint(var15);
    java.awt.Font var21 = var0.getLabelFont();
    org.jfree.chart.util.RectangleInsets var22 = var0.getLabelInsets();
    java.awt.geom.Rectangle2D var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var24 = var22.createInsetRectangle(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     boolean var3 = var1.getAllowNull();
//     var1.setDefaultCreateEntity((java.lang.Boolean)false);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var10 = var8.equals((java.lang.Object)var9);
//     java.lang.String var11 = var9.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var15 = var13.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.Paint var16 = var13.getAxisLinePaint();
//     var9.setTickLabelPaint((java.lang.Comparable)(short)100, var16);
//     var1.setSeriesFillPaint(0, var16);
//     org.jfree.chart.renderer.RenderAttributes var21 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var22 = var21.getDefaultCreateEntity();
//     java.awt.Shape var24 = null;
//     var21.setSeriesShape(0, var24);
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     var26.setTickLabelsVisible(false);
//     var26.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var26.getCategoryStart(10, (-1), var33, var34);
//     java.awt.Font var37 = var26.getTickLabelFont((java.lang.Comparable)'4');
//     var21.setDefaultLabelFont(var37);
//     var1.setSeriesLabelFont(4, var37);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(10.0d, var4, var5, false);
    org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.axis.AxisLocation var12 = null;
    var0.setDomainAxisLocation(10, var12);
    org.jfree.chart.annotations.CategoryAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(0, var6);
    boolean var8 = var2.isDomainZoomable();
    var2.setDomainCrosshairVisible(false);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
    java.lang.Object var12 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var3 = var2.getBaseSeriesVisibleInLegend();
//     int var4 = var2.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var6 = var5.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var8 = var5.lookupLegendTextPaint(15);
//     boolean var9 = var5.getBaseSeriesVisibleInLegend();
//     var5.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
//     var5.setBaseToolTipGenerator(var12, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var16 = var15.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var15.lookupLegendTextPaint(15);
//     boolean var19 = var15.getBaseSeriesVisibleInLegend();
//     var15.setBaseShapesVisible(false);
//     boolean var22 = var15.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var15.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var27 = var26.getTextAnchor();
//     var5.setBaseNegativeItemLabelPosition(var26);
//     var2.setBaseNegativeItemLabelPosition(var26);
//     var0.setBasePositiveItemLabelPosition(var26);
//     org.jfree.chart.text.TextAnchor var31 = var26.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var32 = var26.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var34 = var33.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var36 = var33.lookupLegendTextPaint(15);
//     boolean var37 = var33.getBaseSeriesVisibleInLegend();
//     var33.setBaseShapesVisible(false);
//     boolean var40 = var33.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var44 = var33.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var45 = var44.getTextAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var47 = var46.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var49 = var46.lookupLegendTextPaint(15);
//     boolean var50 = var46.getBaseSeriesVisibleInLegend();
//     var46.setBaseShapesVisible(false);
//     boolean var53 = var46.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var57 = var46.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var58 = var57.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var60 = new org.jfree.chart.labels.ItemLabelPosition(var32, var45, var58, 0.05d);
//     
//     // Checks the contract:  equals-hashcode on var26 and var44
//     assertTrue("Contract failed: equals-hashcode on var26 and var44", var26.equals(var44) ? var26.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var57
//     assertTrue("Contract failed: equals-hashcode on var26 and var57", var26.equals(var57) ? var26.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var26
//     assertTrue("Contract failed: equals-hashcode on var44 and var26", var44.equals(var26) ? var44.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var57
//     assertTrue("Contract failed: equals-hashcode on var44 and var57", var44.equals(var57) ? var44.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var26
//     assertTrue("Contract failed: equals-hashcode on var57 and var26", var57.equals(var26) ? var57.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var44
//     assertTrue("Contract failed: equals-hashcode on var57 and var44", var57.equals(var44) ? var57.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var1 = var0.getDefaultPaint();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     java.awt.Paint var4 = var2.getDomainGridlinePaint();
//     var0.setDefaultPaint(var4);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setTickLabelsVisible(false);
//     var6.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var6.getCategoryStart(10, (-1), var13, var14);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var18 = var16.getColumnRenderingOrder();
//     var6.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
//     java.awt.Paint var20 = var16.getRangeCrosshairPaint();
//     var0.setDefaultLabelPaint(var20);
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.Plot var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var3 = new org.jfree.chart.entity.PlotEntity(var0, var1, "DatasetRenderingOrder.REVERSE");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.data.KeyedObjects2D var3 = new org.jfree.data.KeyedObjects2D();
    java.util.List var4 = var3.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxes(10, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedDomainAxisSpace(var9, false);
    var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
    var6.setDomainCrosshairColumnKey((java.lang.Comparable)0L, true);
    var6.setOutlineVisible(false);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.configureDomainAxes();
    java.awt.Paint var20 = var18.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var21 = var18.getInsets();
    double var23 = var21.calculateLeftOutset(4.0d);
    double var25 = var21.calculateRightInset((-1.0d));
    var6.setInsets(var21, true);
    java.awt.geom.Rectangle2D var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var31 = var21.createOutsetRectangle(var28, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 8.0d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
//     java.awt.Stroke var4 = var0.getRangeZeroBaselineStroke();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.configureDomainAxes();
//     boolean var7 = var5.isOutlineVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var9 = var8.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
//     boolean var12 = var8.getBaseSeriesVisibleInLegend();
//     var8.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
//     var8.setBaseToolTipGenerator(var15, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var18 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var8};
//     var5.setRenderers(var18);
//     var0.setRenderers(var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(1, var2, true);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedRangeAxisSpace(var5, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var8.getLegendItemURLGenerator();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var19 = var17.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var17.setDomainAxis(0, var21);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var25 = var23.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var26 = null;
    var23.setFixedDomainAxisSpace(var26, false);
    var21.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.plot.Marker var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var8.drawRangeMarker(var16, var23, var30, var31, var32);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var36 = var35.getBaseSeriesVisibleInLegend();
    java.awt.Paint var38 = var35.lookupLegendTextPaint(15);
    boolean var39 = var35.getBaseSeriesVisibleInLegend();
    var35.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var35.setBaseToolTipGenerator(var42, false);
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var48 = var46.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var51 = null;
    org.jfree.chart.util.RectangleEdge var52 = null;
    double var53 = var46.getCategoryEnd((-1), (-1), var51, var52);
    float var54 = var46.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis();
    var56.setTickLabelsVisible(false);
    var56.setAxisLineVisible(true);
    java.awt.Paint var61 = var56.getAxisLinePaint();
    var55.setRangeCrosshairPaint(var61);
    org.jfree.chart.JFreeChart var63 = null;
    org.jfree.chart.event.ChartChangeEventType var64 = null;
    org.jfree.chart.event.ChartChangeEvent var65 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var61, var63, var64);
    var46.setAxisLinePaint(var61);
    java.awt.Font var67 = var46.getLabelFont();
    var35.setSeriesItemLabelFont(0, var67);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setSeriesItemLabelFont((-100), var67);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    boolean var8 = var0.isRangeCrosshairVisible();
    org.jfree.chart.LegendItemCollection var9 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var11 = var9.get(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    boolean var8 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var9 = var0.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleInsets var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     java.awt.Paint var3 = var1.getDefaultPaint();
//     java.awt.Paint var6 = var1.getItemPaint(10, (-1));
//     java.awt.Font var8 = var1.getSeriesLabelFont(1);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var2 = var0.getDatasetRenderingOrder();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    java.awt.Font var20 = var17.getLabelFont();
    var17.setLabelToolTip("hi!");
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var25 = var24.getBaseSeriesVisibleInLegend();
    java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
    boolean var28 = var24.getBaseSeriesVisibleInLegend();
    var24.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var24.setBaseToolTipGenerator(var31, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var24.setBaseToolTipGenerator(var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var17, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
//     org.jfree.chart.LegendItemCollection var8 = new org.jfree.chart.LegendItemCollection();
//     var7.addAll(var8);
//     
//     // Checks the contract:  equals-hashcode on var7 and var8
//     assertTrue("Contract failed: equals-hashcode on var7 and var8", var7.equals(var8) ? var7.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var7
//     assertTrue("Contract failed: equals-hashcode on var8 and var7", var8.equals(var7) ? var8.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 15, (-100));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     java.awt.Stroke var4 = var1.getRangeCrosshairStroke();
//     var1.setDomainCrosshairVisible(true);
//     org.jfree.chart.axis.CategoryAnchor var7 = var1.getDomainGridlinePosition();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setDomainAxis(0, var12);
//     boolean var14 = var8.isDomainZoomable();
//     org.jfree.chart.plot.Plot var15 = var8.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.axis.ValueAxis var18 = var8.getRangeAxis(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     int var20 = var8.getIndexOf(var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.configureDomainAxes();
//     java.awt.Paint var23 = var21.getDomainGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var21.zoomRangeAxes(10.0d, var25, var26, false);
//     org.jfree.chart.plot.DrawingSupplier var29 = var21.getDrawingSupplier();
//     var8.setDrawingSupplier(var29);
//     org.jfree.chart.util.ShadowGenerator var31 = var8.getShadowGenerator();
//     boolean var32 = var7.equals((java.lang.Object)var8);
//     var0.setDomainGridlinePosition(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var21
//     assertTrue("Contract failed: equals-hashcode on var0 and var21", var0.equals(var21) ? var0.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var0
//     assertTrue("Contract failed: equals-hashcode on var21 and var0", var21.equals(var0) ? var21.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var2 = var1.getBaseSeriesVisibleInLegend();
    java.awt.Paint var4 = var1.lookupLegendTextPaint(15);
    boolean var5 = var1.getBaseSeriesVisibleInLegend();
    var1.setBaseShapesVisible(false);
    var0.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var11 = var0.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var14 = var12.getDomainAxis(0);
    java.awt.Stroke var15 = var12.getRangeCrosshairStroke();
    var12.setDomainCrosshairVisible(true);
    var12.setBackgroundImageAlpha(0.0f);
    boolean var20 = var0.equals((java.lang.Object)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var22 = var12.getRangeAxisForDataset((-2));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(0, var6);
    boolean var8 = var2.isDomainZoomable();
    var2.setDomainCrosshairVisible(false);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
    var2.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.ValueAxis var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var2.getRangeAxisIndex(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.clearCategoryLabelToolTips();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setDomainAxis(0, var6);
//     boolean var8 = var2.isDomainZoomable();
//     var2.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var11 = null;
//     var2.markerChanged(var11);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var2);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.AxisState var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.configureDomainAxes();
//     boolean var19 = var17.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setDomainAxis(0, var25);
//     boolean var27 = var21.isDomainZoomable();
//     org.jfree.chart.axis.AxisLocation var28 = var21.getRangeAxisLocation();
//     var17.setRangeAxisLocation(2, var28);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     var30.setDomainAxis(100, var33, false);
//     org.jfree.chart.util.SortOrder var36 = var30.getColumnRenderingOrder();
//     var30.setRangeMinorGridlinesVisible(false);
//     var30.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotOrientation var41 = var30.getOrientation();
//     org.jfree.chart.util.RectangleEdge var42 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var28, var41);
//     java.util.List var43 = var0.refreshTicks(var14, var15, var16, var42);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(0, var6);
    boolean var8 = var2.isDomainZoomable();
    var2.setDomainCrosshairVisible(false);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)false);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    boolean var11 = var0.removeDomainMarker(10, var8, var9, false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    boolean var15 = var13.equals((java.lang.Object)var14);
    java.lang.String var16 = var14.getLabelURL();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var20 = var18.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.Paint var21 = var18.getAxisLinePaint();
    var14.setTickLabelPaint((java.lang.Comparable)(short)100, var21);
    var0.setNoDataMessagePaint(var21);
    var0.setCrosshairDatasetIndex(15);
    org.jfree.chart.event.AnnotationChangeEvent var26 = null;
    var0.annotationChanged(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     java.awt.Paint[] var1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var4 = var3.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
//     boolean var7 = var3.getBaseSeriesVisibleInLegend();
//     var3.setBaseLinesVisible(true);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     java.awt.Stroke var13 = var10.getRangeCrosshairStroke();
//     var3.setBaseOutlineStroke(var13);
//     java.awt.Stroke[] var15 = new java.awt.Stroke[] { var13};
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var17 = var16.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var19 = var16.lookupLegendTextPaint(15);
//     java.awt.Paint var21 = var16.getSeriesOutlinePaint(0);
//     java.awt.Stroke var22 = var16.getBaseStroke();
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var25 = var24.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
//     boolean var28 = var24.getBaseSeriesVisibleInLegend();
//     var24.setBaseShapesVisible(false);
//     java.awt.Shape var32 = var24.lookupLegendShape(100);
//     org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity(var32);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var37 = var35.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var35.setDomainAxis(0, var39);
//     boolean var41 = var35.isDomainZoomable();
//     var35.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.configureDomainAxes();
//     java.awt.Paint var46 = var44.getDomainGridlinePaint();
//     var35.setRangeZeroBaselinePaint(var46);
//     org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("", var46);
//     boolean var49 = var48.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
//     var51.setTickLabelsVisible(false);
//     var51.setAxisLineVisible(true);
//     java.awt.Paint var56 = var51.getAxisLinePaint();
//     var50.setRangeCrosshairPaint(var56);
//     float var58 = var50.getBackgroundAlpha();
//     java.awt.Paint var59 = var50.getOutlinePaint();
//     var48.setLabelPaint(var59);
//     var48.setSeriesIndex(0);
//     var48.setDescription("CategoryAnchor.MIDDLE");
//     var48.setLineVisible(false);
//     java.awt.Shape var67 = var48.getShape();
//     var33.setArea(var67);
//     java.awt.Shape[] var69 = new java.awt.Shape[] { var67};
//     org.jfree.chart.plot.DefaultDrawingSupplier var70 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var2, var15, var23, var69);
//     
//     // Checks the contract:  equals-hashcode on var10 and var44
//     assertTrue("Contract failed: equals-hashcode on var10 and var44", var10.equals(var44) ? var10.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var10
//     assertTrue("Contract failed: equals-hashcode on var44 and var10", var44.equals(var10) ? var44.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis(0);
//     java.awt.Stroke var7 = var4.getRangeCrosshairStroke();
//     var0.setRangeGridlineStroke(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    boolean var5 = var3.equals((java.lang.Object)var4);
    boolean var6 = var4.isAxisLineVisible();
    var0.setObject((java.lang.Object)var4, (java.lang.Comparable)10.0f, (java.lang.Comparable)4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    java.awt.Color var1 = java.awt.Color.getColor("ChartEntity: tooltip = null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setTickLabelsVisible(false);
//     var0.setMaximumCategoryLabelLines((-1));
//     var0.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.configureDomainAxes();
//     java.awt.Paint var9 = var7.getDomainGridlinePaint();
//     java.lang.Object var10 = var7.clone();
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     var0.setLabel("CategoryAnchor.MIDDLE");
//     float var14 = var0.getMinorTickMarkOutsideLength();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     var16.setDomainAxis(0, var20);
//     boolean var22 = var16.isDomainZoomable();
//     var16.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.configureDomainAxes();
//     java.awt.Paint var27 = var25.getDomainGridlinePaint();
//     var16.setRangeZeroBaselinePaint(var27);
//     org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", var27);
//     boolean var30 = var29.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setTickLabelsVisible(false);
//     var32.setAxisLineVisible(true);
//     java.awt.Paint var37 = var32.getAxisLinePaint();
//     var31.setRangeCrosshairPaint(var37);
//     float var39 = var31.getBackgroundAlpha();
//     java.awt.Paint var40 = var31.getOutlinePaint();
//     var29.setLabelPaint(var40);
//     var29.setSeriesIndex(0);
//     var29.setDescription("CategoryAnchor.MIDDLE");
//     java.awt.Paint var46 = var29.getOutlinePaint();
//     var0.setTickMarkPaint(var46);
//     
//     // Checks the contract:  equals-hashcode on var7 and var25
//     assertTrue("Contract failed: equals-hashcode on var7 and var25", var7.equals(var25) ? var7.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var7
//     assertTrue("Contract failed: equals-hashcode on var25 and var7", var25.equals(var7) ? var25.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 8.0d, 100.0d, 8.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    var0.setSeriesShapesFilled(15, (java.lang.Boolean)false);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var0.setBaseURLGenerator(var10);
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = var0.getSeriesToolTipGenerator(2);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    double var16 = var15.getLabelAngle();
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var15.getCategorySeriesMiddle(10, 1, 0, 10, 0.0d, var22, var23);
    var15.setLabelAngle(100.0d);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var30 = var28.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
    var28.setDomainAxis(0, var32);
    boolean var34 = var28.isDomainZoomable();
    var28.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.configureDomainAxes();
    java.awt.Paint var39 = var37.getDomainGridlinePaint();
    var28.setRangeZeroBaselinePaint(var39);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", var39);
    boolean var42 = var41.isShapeFilled();
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
    var44.setTickLabelsVisible(false);
    var44.setAxisLineVisible(true);
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var43.setRangeCrosshairPaint(var49);
    float var51 = var43.getBackgroundAlpha();
    java.awt.Paint var52 = var43.getOutlinePaint();
    var41.setLabelPaint(var52);
    var15.setAxisLinePaint(var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendTextPaint((-100), var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var13 = var11.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var11.getCategoryEnd((-1), (-1), var16, var17);
    float var19 = var11.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var21.setTickLabelsVisible(false);
    var21.setAxisLineVisible(true);
    java.awt.Paint var26 = var21.getAxisLinePaint();
    var20.setRangeCrosshairPaint(var26);
    org.jfree.chart.JFreeChart var28 = null;
    org.jfree.chart.event.ChartChangeEventType var29 = null;
    org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var28, var29);
    var11.setAxisLinePaint(var26);
    java.awt.Font var32 = var11.getLabelFont();
    var0.setSeriesItemLabelFont(0, var32);
    boolean var37 = var0.isItemLabelVisible(4, 1, false);
    org.jfree.chart.annotations.CategoryAnnotation var38 = null;
    boolean var39 = var0.removeAnnotation(var38);
    org.jfree.chart.annotations.CategoryAnnotation var40 = null;
    org.jfree.chart.util.Layer var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var40, var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.RenderAttributes var6 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.lang.Boolean var7 = var6.getDefaultCreateEntity();
    java.awt.Shape var9 = null;
    var6.setSeriesShape(0, var9);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    var11.setTickLabelsVisible(false);
    var11.setMaximumCategoryLabelLines((-1));
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var11.getCategoryStart(10, (-1), var18, var19);
    java.awt.Font var22 = var11.getTickLabelFont((java.lang.Comparable)'4');
    var6.setDefaultLabelFont(var22);
    java.awt.Shape var25 = null;
    var6.setSeriesShape(0, var25);
    java.awt.Paint var27 = var6.getDefaultOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "Category Plot", var4, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var1 = var0.getRowKeys();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var5 = var3.equals((java.lang.Object)var4);
//     boolean var6 = var4.isAxisLineVisible();
//     var0.setObject((java.lang.Object)var4, (java.lang.Comparable)10.0f, (java.lang.Comparable)4);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var13.setDomainAxis(100, var16, false);
//     java.util.List var19 = var13.getCategories();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var22 = var20.getDomainAxis(0);
//     java.awt.Stroke var23 = var20.getRangeCrosshairStroke();
//     java.awt.Stroke var24 = var20.getRangeZeroBaselineStroke();
//     var13.setOutlineStroke(var24);
//     org.jfree.chart.util.RectangleEdge var26 = var13.getRangeAxisEdge();
//     double var27 = var4.getCategoryStart(0, 0, var12, var26);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.configureDomainAxes();
    java.awt.Paint var6 = var4.getDomainGridlinePaint();
    java.lang.Object var7 = var4.clone();
    org.jfree.chart.plot.DatasetRenderingOrder var8 = var4.getDatasetRenderingOrder();
    boolean var9 = var3.equals((java.lang.Object)var4);
    var4.setRangeCrosshairValue(100.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("CategoryAnchor.MIDDLE");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-33));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.data.Range var8 = var0.findRangeBounds(var7);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getSeriesToolTipGenerator(0);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-33), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    var0.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseShapesVisible(false);
    var2.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var13 = var2.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
    var14.setDomainCrosshairVisible(true);
    var14.setBackgroundImageAlpha(0.0f);
    boolean var22 = var2.equals((java.lang.Object)var14);
    boolean var23 = var0.equals((java.lang.Object)var2);
    boolean var25 = var2.equals((java.lang.Object)100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.removeRow((java.lang.Comparable)100.0f);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
//     var0.setBaseToolTipGenerator(var7, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var11 = var10.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var13 = var10.lookupLegendTextPaint(15);
//     boolean var14 = var10.getBaseSeriesVisibleInLegend();
//     var10.setBaseShapesVisible(false);
//     boolean var17 = var10.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var21 = var10.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var22 = var21.getTextAnchor();
//     var0.setBaseNegativeItemLabelPosition(var21);
//     boolean var24 = var0.getBaseShapesFilled();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var25.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     org.jfree.chart.labels.ItemLabelPosition var30 = var25.getBasePositiveItemLabelPosition();
//     var0.setBaseNegativeItemLabelPosition(var30, true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var30
//     assertTrue("Contract failed: equals-hashcode on var21 and var30", var21.equals(var30) ? var21.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var21
//     assertTrue("Contract failed: equals-hashcode on var30 and var21", var30.equals(var21) ? var30.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.RenderingSource var14 = null;
    var0.select(8.0d, 10.0d, var13, var14);
    java.awt.Stroke var16 = var0.getRangeGridlineStroke();
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var19 = var0.removeAnnotation(var17, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    boolean var8 = var7.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var2 = var0.getSeriesPaint(0);
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var3.setTickLabelsVisible(false);
//     java.awt.Font var6 = var3.getLabelFont();
//     var3.setLabelToolTip("hi!");
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(0, var13);
//     boolean var15 = var9.isDomainZoomable();
//     var9.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.configureDomainAxes();
//     java.awt.Paint var20 = var18.getDomainGridlinePaint();
//     var9.setRangeZeroBaselinePaint(var20);
//     var3.setLabelPaint(var20);
//     var0.setDefaultLabelPaint(var20);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var25 = var24.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
//     java.awt.Stroke var29 = var24.getSeriesStroke(15);
//     var24.setBaseSeriesVisible(false);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.configureDomainAxes();
//     java.awt.Stroke var34 = var32.getRangeGridlineStroke();
//     var24.setBaseOutlineStroke(var34);
//     var0.setDefaultOutlineStroke(var34);
//     
//     // Checks the contract:  equals-hashcode on var18 and var32
//     assertTrue("Contract failed: equals-hashcode on var18 and var32", var18.equals(var32) ? var18.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var18
//     assertTrue("Contract failed: equals-hashcode on var32 and var18", var32.equals(var18) ? var32.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = null;
    var0.setBaseItemLabelGenerator(var2, true);
    java.awt.Paint var5 = var0.getBaseLegendTextPaint();
    java.awt.Paint var9 = var0.getItemPaint((-1), 1, true);
    java.awt.Font var10 = null;
    var0.setBaseItemLabelFont(var10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    java.lang.Object var8 = var0.clone();
    org.jfree.chart.util.RectangleInsets var9 = var0.getAxisOffset();
    java.awt.geom.Rectangle2D var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var11 = var9.createOutsetRectangle(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Paint var3 = var1.getDefaultFillPaint();
//     java.awt.Paint var4 = var1.getDefaultOutlinePaint();
//     java.awt.Paint var5 = var1.getDefaultOutlinePaint();
//     java.awt.Stroke var7 = var1.getSeriesOutlineStroke((-33));
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     boolean var12 = var6.isDomainZoomable();
//     var6.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.configureDomainAxes();
//     java.awt.Paint var17 = var15.getDomainGridlinePaint();
//     var6.setRangeZeroBaselinePaint(var17);
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("", var17);
//     var19.setDescription("");
//     var19.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
//     java.awt.Shape var24 = var19.getLine();
//     java.awt.Color var29 = java.awt.Color.getColor("", 1);
//     java.awt.Color var30 = var29.brighter();
//     java.awt.Color var31 = java.awt.Color.getColor("", var30);
//     int var32 = var31.getTransparency();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var35 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var37 = var35.equals((java.lang.Object)var36);
//     java.lang.String var38 = var36.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var42 = var40.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.Paint var43 = var40.getAxisLinePaint();
//     var36.setTickLabelPaint((java.lang.Comparable)(short)100, var43);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
//     var45.setDomainAxis(100, var48, false);
//     org.jfree.chart.util.SortOrder var51 = var45.getColumnRenderingOrder();
//     var45.setRangeMinorGridlinesVisible(false);
//     var45.setRangeCrosshairLockedOnData(false);
//     java.awt.Stroke var56 = var45.getDomainGridlineStroke();
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var61 = var59.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis();
//     var59.setDomainAxis(0, var63);
//     boolean var65 = var59.isDomainZoomable();
//     var59.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     var68.configureDomainAxes();
//     java.awt.Paint var70 = var68.getDomainGridlinePaint();
//     var59.setRangeZeroBaselinePaint(var70);
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("", var70);
//     var72.setDescription("");
//     var72.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
//     java.awt.Shape var77 = var72.getLine();
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
//     var78.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var81 = new org.jfree.chart.axis.CategoryAxis();
//     var78.setDomainAxis(100, var81, false);
//     java.util.List var84 = var78.getCategories();
//     org.jfree.chart.plot.CategoryPlot var85 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var87 = var85.getDomainAxis(0);
//     java.awt.Stroke var88 = var85.getRangeCrosshairStroke();
//     java.awt.Stroke var89 = var85.getRangeZeroBaselineStroke();
//     var78.setOutlineStroke(var89);
//     java.awt.Color var94 = java.awt.Color.getHSBColor((-1.0f), 0.5f, 10.0f);
//     org.jfree.chart.LegendItem var95 = new org.jfree.chart.LegendItem("DatasetRenderingOrder.REVERSE", "DatasetRenderingOrder.REVERSE", "ChartEntity: tooltip = null", "ChartEntity: tooltip = null", true, var24, false, (java.awt.Paint)var31, false, var43, var56, false, var77, var89, (java.awt.Paint)var94);
//     
//     // Checks the contract:  equals-hashcode on var6 and var59
//     assertTrue("Contract failed: equals-hashcode on var6 and var59", var6.equals(var59) ? var6.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var68
//     assertTrue("Contract failed: equals-hashcode on var15 and var68", var15.equals(var68) ? var15.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var85
//     assertTrue("Contract failed: equals-hashcode on var15 and var85", var15.equals(var85) ? var15.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var6
//     assertTrue("Contract failed: equals-hashcode on var59 and var6", var59.equals(var6) ? var59.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var15
//     assertTrue("Contract failed: equals-hashcode on var68 and var15", var68.equals(var15) ? var68.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var85
//     assertTrue("Contract failed: equals-hashcode on var68 and var85", var68.equals(var85) ? var68.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var15
//     assertTrue("Contract failed: equals-hashcode on var85 and var15", var85.equals(var15) ? var85.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var68
//     assertTrue("Contract failed: equals-hashcode on var85 and var68", var85.equals(var68) ? var85.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var72
//     assertTrue("Contract failed: equals-hashcode on var19 and var72", var19.equals(var72) ? var19.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var19
//     assertTrue("Contract failed: equals-hashcode on var72 and var19", var72.equals(var19) ? var72.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("DatasetRenderingOrder.REVERSE");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    var0.setSeriesItemLabelsVisible(15, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getNegativeItemLabelPosition(0, 0, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-2), (java.lang.Boolean)false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.data.event.DatasetChangeEvent var6 = null;
//     var0.datasetChanged(var6);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setDomainAxis(100, var11, false);
//     java.util.List var14 = var8.getCategories();
//     boolean var15 = var8.isDomainGridlinesVisible();
//     org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setDomainAxis(0, var22);
//     boolean var24 = var18.isDomainZoomable();
//     var18.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var27 = null;
//     var18.markerChanged(var27);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Point2D var31 = null;
//     var18.zoomDomainAxes(0.0d, var30, var31);
//     org.jfree.data.category.DefaultCategoryDataset var33 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = var18.getRendererForDataset((org.jfree.data.category.CategoryDataset)var33);
//     org.jfree.data.event.DatasetChangeListener var35 = null;
//     var33.removeChangeListener(var35);
//     int var38 = var33.getRowIndex((java.lang.Comparable)(byte)0);
//     var33.clearSelection();
//     var8.setDataset(1, (org.jfree.data.category.CategoryDataset)var33);
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var33);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    boolean var11 = var0.isDomainCrosshairVisible();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setDomainCrosshairVisible(true);
    org.jfree.chart.event.AnnotationChangeEvent var15 = null;
    var12.annotationChanged(var15);
    org.jfree.chart.util.SortOrder var17 = var12.getColumnRenderingOrder();
    var0.setColumnRenderingOrder(var17);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var0.zoomRangeAxes(10.0d, var20, var21, true);
    org.jfree.chart.annotations.CategoryAnnotation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var25 = var0.removeAnnotation(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue((java.lang.Number)4);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var3.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.ItemLabelPosition var8 = var3.getBasePositiveItemLabelPosition();
    var0.setSeriesNegativeItemLabelPosition(100, var8, true);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 100);
    int var3 = var2.getRGB();
    java.awt.Color var4 = var2.darker();
    int var5 = var4.getAlpha();
    int var6 = var4.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777116));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("DatasetRenderingOrder.REVERSE", var1, var2);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var3 = var2.getBaseSeriesVisibleInLegend();
//     int var4 = var2.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var6 = var5.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var8 = var5.lookupLegendTextPaint(15);
//     boolean var9 = var5.getBaseSeriesVisibleInLegend();
//     var5.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
//     var5.setBaseToolTipGenerator(var12, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var16 = var15.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var15.lookupLegendTextPaint(15);
//     boolean var19 = var15.getBaseSeriesVisibleInLegend();
//     var15.setBaseShapesVisible(false);
//     boolean var22 = var15.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var15.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var27 = var26.getTextAnchor();
//     var5.setBaseNegativeItemLabelPosition(var26);
//     var2.setBaseNegativeItemLabelPosition(var26);
//     var0.setBasePositiveItemLabelPosition(var26);
//     org.jfree.chart.text.TextAnchor var31 = var26.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var32 = var26.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var34 = var33.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var36 = var33.lookupLegendTextPaint(15);
//     boolean var37 = var33.getBaseSeriesVisibleInLegend();
//     var33.setBaseShapesVisible(false);
//     boolean var40 = var33.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var44 = var33.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var45 = var44.getTextAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var47 = var46.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var49 = var48.getBaseSeriesVisibleInLegend();
//     int var50 = var48.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var52 = var51.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var54 = var51.lookupLegendTextPaint(15);
//     boolean var55 = var51.getBaseSeriesVisibleInLegend();
//     var51.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var58 = null;
//     var51.setBaseToolTipGenerator(var58, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var62 = var61.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var64 = var61.lookupLegendTextPaint(15);
//     boolean var65 = var61.getBaseSeriesVisibleInLegend();
//     var61.setBaseShapesVisible(false);
//     boolean var68 = var61.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var72 = var61.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var73 = var72.getTextAnchor();
//     var51.setBaseNegativeItemLabelPosition(var72);
//     var48.setBaseNegativeItemLabelPosition(var72);
//     var46.setBasePositiveItemLabelPosition(var72);
//     org.jfree.chart.text.TextAnchor var77 = var72.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var79 = new org.jfree.chart.labels.ItemLabelPosition(var32, var45, var77, (-7.8d));
//     
//     // Checks the contract:  equals-hashcode on var26 and var44
//     assertTrue("Contract failed: equals-hashcode on var26 and var44", var26.equals(var44) ? var26.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var72
//     assertTrue("Contract failed: equals-hashcode on var26 and var72", var26.equals(var72) ? var26.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var26
//     assertTrue("Contract failed: equals-hashcode on var44 and var26", var44.equals(var26) ? var44.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var72
//     assertTrue("Contract failed: equals-hashcode on var44 and var72", var44.equals(var72) ? var44.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var26
//     assertTrue("Contract failed: equals-hashcode on var72 and var26", var72.equals(var26) ? var72.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var44
//     assertTrue("Contract failed: equals-hashcode on var72 and var44", var72.equals(var44) ? var72.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    var0.setSeriesURLGenerator(15, var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = var0.getPlot();
    boolean var38 = var0.getUseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesFilled((-100), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    java.awt.Font var20 = var17.getLabelFont();
    var17.setLabelToolTip("hi!");
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var25 = var24.getBaseSeriesVisibleInLegend();
    java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
    boolean var28 = var24.getBaseSeriesVisibleInLegend();
    var24.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var24.setBaseToolTipGenerator(var31, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var24.setBaseToolTipGenerator(var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var17, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeColumn((-100));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var5 = var3.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var3.setDomainAxis(0, var7);
//     boolean var9 = var3.isDomainZoomable();
//     var3.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.configureDomainAxes();
//     java.awt.Paint var14 = var12.getDomainGridlinePaint();
//     var3.setRangeZeroBaselinePaint(var14);
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", var14);
//     var16.setDescription("");
//     var16.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
//     java.awt.Shape var21 = var16.getLine();
//     java.awt.GradientPaint var22 = var0.transform(var1, var21);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     var0.clearRangeAxes();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.configureDomainAxes();
//     boolean var10 = var8.isOutlineVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var12 = var11.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var14 = var11.lookupLegendTextPaint(15);
//     boolean var15 = var11.getBaseSeriesVisibleInLegend();
//     var11.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var18 = null;
//     var11.setBaseToolTipGenerator(var18, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var11};
//     var8.setRenderers(var21);
//     var0.setRenderers(var21);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
//     org.jfree.chart.JFreeChart var8 = null;
//     org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var8);
//     org.jfree.chart.plot.Marker var11 = null;
//     org.jfree.chart.util.Layer var12 = null;
//     var0.addRangeMarker(0, var11, var12);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    java.lang.Object var6 = var0.clone();
    java.lang.Boolean var8 = var0.getSeriesItemLabelsVisible(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setTickLabelsVisible(false);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var0.getCategoryStart((-1), 0, var5, var6);
//     float var8 = var0.getTickMarkInsideLength();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.configureDomainAxes();
//     boolean var16 = var14.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setDomainAxis(0, var22);
//     boolean var24 = var18.isDomainZoomable();
//     org.jfree.chart.axis.AxisLocation var25 = var18.getRangeAxisLocation();
//     var14.setRangeAxisLocation(2, var25);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     var27.setDomainAxis(100, var30, false);
//     org.jfree.chart.util.SortOrder var33 = var27.getColumnRenderingOrder();
//     var27.setRangeMinorGridlinesVisible(false);
//     var27.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotOrientation var38 = var27.getOrientation();
//     org.jfree.chart.util.RectangleEdge var39 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var25, var38);
//     org.jfree.chart.axis.AxisSpace var40 = null;
//     org.jfree.chart.axis.AxisSpace var41 = var0.reserveSpace(var9, (org.jfree.chart.plot.Plot)var10, var13, var39, var40);
//     
//     // Checks the contract:  equals-hashcode on var10 and var14
//     assertTrue("Contract failed: equals-hashcode on var10 and var14", var10.equals(var14) ? var10.hashCode() == var14.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var14.", var10.equals(var14) == var14.equals(var10));
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var11 = var10.getBaseSeriesVisibleInLegend();
    java.awt.Paint var13 = var10.lookupLegendTextPaint(15);
    boolean var14 = var10.getBaseSeriesVisibleInLegend();
    var10.setBaseShapesVisible(false);
    boolean var17 = var10.getBaseShapesFilled();
    org.jfree.chart.labels.ItemLabelPosition var21 = var10.getPositiveItemLabelPosition((-1), 1, true);
    org.jfree.chart.text.TextAnchor var22 = var21.getTextAnchor();
    var0.setBaseNegativeItemLabelPosition(var21);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.annotations.CategoryAnnotation var26 = null;
    org.jfree.chart.util.Layer var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var26, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var9.setFixedDomainAxisSpace(var12, false);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    var15.setDomainAxis(0, var19);
    var9.setParent((org.jfree.chart.plot.Plot)var15);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    java.awt.geom.Point2D var24 = null;
    var9.zoomDomainAxes(0.0d, var23, var24);
    java.util.List var26 = var9.getAnnotations();
    org.jfree.chart.util.RectangleEdge var28 = var9.getDomainAxisEdge(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var29 = var3.getCategoryMiddle((-33), (-33), var8, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     boolean var15 = var14.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setTickLabelsVisible(false);
//     var17.setAxisLineVisible(true);
//     java.awt.Paint var22 = var17.getAxisLinePaint();
//     var16.setRangeCrosshairPaint(var22);
//     float var24 = var16.getBackgroundAlpha();
//     java.awt.Paint var25 = var16.getOutlinePaint();
//     var14.setLabelPaint(var25);
//     var14.setSeriesIndex(0);
//     var14.setDescription("CategoryAnchor.MIDDLE");
//     java.awt.Paint var31 = var14.getOutlinePaint();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var33 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var35 = var33.equals((java.lang.Object)var34);
//     java.lang.String var36 = var34.getLabelURL();
//     org.jfree.chart.renderer.RenderAttributes var38 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var39 = var38.getDefaultLabelFont();
//     java.awt.Paint var40 = var38.getDefaultPaint();
//     var34.setLabelPaint(var40);
//     var14.setFillPaint(var40);
//     org.jfree.chart.renderer.RenderAttributes var44 = new org.jfree.chart.renderer.RenderAttributes(false);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.configureDomainAxes();
//     java.awt.Paint var47 = var45.getDomainGridlinePaint();
//     var44.setDefaultOutlinePaint(var47);
//     java.awt.Paint var51 = var44.getItemOutlinePaint(10, 0);
//     var14.setLabelPaint(var51);
//     
//     // Checks the contract:  equals-hashcode on var10 and var45
//     assertTrue("Contract failed: equals-hashcode on var10 and var45", var10.equals(var45) ? var10.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var10
//     assertTrue("Contract failed: equals-hashcode on var45 and var10", var45.equals(var10) ? var45.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setDomainCrosshairVisible(true);
//     var0.setRangeCrosshairValue(10.0d, false);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var0.zoomDomainAxes(1.0d, var7, var8, false);
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var0.getDomainMarkers(var11);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     org.jfree.chart.plot.PlotState var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     var0.draw(var13, var14, var15, var16, var17);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var5 = var4.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var7 = var4.lookupLegendTextPaint(15);
//     boolean var8 = var4.getBaseSeriesVisibleInLegend();
//     var4.setBaseShapesVisible(false);
//     java.awt.Shape var12 = var4.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var13.setDomainAxis(100, var16, false);
//     org.jfree.chart.util.SortOrder var19 = var13.getColumnRenderingOrder();
//     var13.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var13.drawBackgroundImage(var22, var23);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var27 = var25.getDomainAxis(0);
//     java.awt.Stroke var28 = var25.getRangeCrosshairStroke();
//     var13.setDomainCrosshairStroke(var28);
//     var13.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var33 = new org.jfree.chart.entity.PlotEntity(var12, (org.jfree.chart.plot.Plot)var13, "DatasetRenderingOrder.REVERSE");
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
//     var35.setDomainAxis(100, var38, false);
//     java.util.List var41 = var35.getCategories();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var44 = var42.getDomainAxis(0);
//     java.awt.Stroke var45 = var42.getRangeCrosshairStroke();
//     java.awt.Stroke var46 = var42.getRangeZeroBaselineStroke();
//     var35.setOutlineStroke(var46);
//     var34.setDomainGridlineStroke(var46);
//     org.jfree.chart.renderer.RenderAttributes var49 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var51 = var49.getSeriesPaint(0);
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
//     var52.setTickLabelsVisible(false);
//     java.awt.Font var55 = var52.getLabelFont();
//     var52.setLabelToolTip("hi!");
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var60 = var58.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis();
//     var58.setDomainAxis(0, var62);
//     boolean var64 = var58.isDomainZoomable();
//     var58.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot();
//     var67.configureDomainAxes();
//     java.awt.Paint var69 = var67.getDomainGridlinePaint();
//     var58.setRangeZeroBaselinePaint(var69);
//     var52.setLabelPaint(var69);
//     var49.setDefaultLabelPaint(var69);
//     org.jfree.chart.LegendItem var73 = new org.jfree.chart.LegendItem("", "PlotOrientation.VERTICAL", "ChartEntity: tooltip = null", "", var12, var46, var69);
//     
//     // Checks the contract:  equals-hashcode on var25 and var42
//     assertTrue("Contract failed: equals-hashcode on var25 and var42", var25.equals(var42) ? var25.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var67
//     assertTrue("Contract failed: equals-hashcode on var25 and var67", var25.equals(var67) ? var25.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var25
//     assertTrue("Contract failed: equals-hashcode on var42 and var25", var42.equals(var25) ? var42.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var67
//     assertTrue("Contract failed: equals-hashcode on var42 and var67", var42.equals(var67) ? var42.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var25
//     assertTrue("Contract failed: equals-hashcode on var67 and var25", var67.equals(var25) ? var67.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var42
//     assertTrue("Contract failed: equals-hashcode on var67 and var42", var67.equals(var42) ? var67.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     java.awt.Paint var2 = var0.getDomainGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomRangeAxes(10.0d, var4, var5, false);
//     org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
//     org.jfree.chart.event.MarkerChangeEvent var9 = null;
//     var0.markerChanged(var9);
//     java.lang.Object var11 = null;
//     boolean var12 = var0.equals(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var14.setDomainAxis(100, var17, false);
//     java.util.List var20 = var14.getCategories();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis(0);
//     java.awt.Stroke var24 = var21.getRangeCrosshairStroke();
//     java.awt.Stroke var25 = var21.getRangeZeroBaselineStroke();
//     var14.setOutlineStroke(var25);
//     var13.setDomainGridlineStroke(var25);
//     var0.setDomainGridlineStroke(var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var3 = null;
    var0.setFixedDomainAxisSpace(var3, false);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    var6.setDomainAxis(0, var10);
    var0.setParent((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var6.zoomRangeAxes(8.0d, 0.0d, var15, var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = null;
    var0.setBaseItemLabelGenerator(var2, true);
    java.awt.Paint var5 = var0.getBaseLegendTextPaint();
    java.awt.Paint var9 = var0.getItemPaint((-1), 1, true);
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseShapesVisible(false);
//     var0.setBaseCreateEntities(true);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     var10.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.configureDomainAxes();
//     java.awt.Paint var21 = var19.getDomainGridlinePaint();
//     var10.setRangeZeroBaselinePaint(var21);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var21);
//     boolean var24 = var23.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     var26.setTickLabelsVisible(false);
//     var26.setAxisLineVisible(true);
//     java.awt.Paint var31 = var26.getAxisLinePaint();
//     var25.setRangeCrosshairPaint(var31);
//     float var33 = var25.getBackgroundAlpha();
//     java.awt.Paint var34 = var25.getOutlinePaint();
//     var23.setLabelPaint(var34);
//     var23.setSeriesIndex(0);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var39 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var41 = var39.equals((java.lang.Object)var40);
//     java.lang.String var42 = var40.getLabelURL();
//     org.jfree.chart.renderer.RenderAttributes var44 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var45 = var44.getDefaultLabelFont();
//     java.awt.Paint var46 = var44.getDefaultPaint();
//     var40.setLabelPaint(var46);
//     var23.setLinePaint(var46);
//     var0.setBasePaint(var46);
//     org.jfree.chart.util.ShapeList var50 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var52 = null;
//     var50.setShape(4, var52);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var58 = var56.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis();
//     var56.setDomainAxis(0, var60);
//     boolean var62 = var56.isDomainZoomable();
//     var56.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     var65.configureDomainAxes();
//     java.awt.Paint var67 = var65.getDomainGridlinePaint();
//     var56.setRangeZeroBaselinePaint(var67);
//     org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem("", var67);
//     boolean var70 = var69.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var72 = new org.jfree.chart.axis.CategoryAxis();
//     var72.setTickLabelsVisible(false);
//     var72.setAxisLineVisible(true);
//     java.awt.Paint var77 = var72.getAxisLinePaint();
//     var71.setRangeCrosshairPaint(var77);
//     float var79 = var71.getBackgroundAlpha();
//     java.awt.Paint var80 = var71.getOutlinePaint();
//     var69.setLabelPaint(var80);
//     var69.setSeriesIndex(0);
//     var69.setDescription("CategoryAnchor.MIDDLE");
//     var69.setLineVisible(false);
//     java.awt.Shape var88 = var69.getShape();
//     var50.setShape(15, var88);
//     var0.setBaseShape(var88, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var56
//     assertTrue("Contract failed: equals-hashcode on var10 and var56", var10.equals(var56) ? var10.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var65
//     assertTrue("Contract failed: equals-hashcode on var19 and var65", var19.equals(var65) ? var19.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var71
//     assertTrue("Contract failed: equals-hashcode on var25 and var71", var25.equals(var71) ? var25.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var10
//     assertTrue("Contract failed: equals-hashcode on var56 and var10", var56.equals(var10) ? var56.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var19
//     assertTrue("Contract failed: equals-hashcode on var65 and var19", var65.equals(var19) ? var65.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var25
//     assertTrue("Contract failed: equals-hashcode on var71 and var25", var71.equals(var25) ? var71.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    boolean var15 = var14.isShapeFilled();
    var14.setLineVisible(false);
    var14.setURLText("hi!");
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var21 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    boolean var23 = var21.equals((java.lang.Object)var22);
    java.lang.String var24 = var22.getLabelURL();
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var28 = var26.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.Paint var29 = var26.getAxisLinePaint();
    var22.setTickLabelPaint((java.lang.Comparable)(short)100, var29);
    var14.setFillPaint(var29);
    java.lang.Object var32 = var14.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.lang.Boolean var3 = var0.getSeriesLinesVisible(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    var14.setDescription("");
    var14.setSeriesIndex(0);
    var14.setToolTipText("");
    java.text.AttributedString var21 = var14.getAttributedLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    java.awt.Paint var5 = var0.getSeriesOutlinePaint(0);
    var0.setBaseItemLabelsVisible(false, true);
    var0.setDrawOutlines(false);
    java.awt.Paint var14 = var0.getItemLabelPaint(10, (-1), false);
    java.awt.Shape var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-33), var16, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(0, var6);
    boolean var8 = var2.isDomainZoomable();
    var2.setDomainCrosshairVisible(false);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
    int var12 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected((-100), 0, true, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.data.category.DefaultCategoryDataset var2 = new org.jfree.data.category.DefaultCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var2, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    boolean var2 = var0.isOutlineVisible();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var3.setBaseToolTipGenerator(var10, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var3};
    var0.setRenderers(var13);
    org.jfree.chart.axis.ValueAxis var16 = var0.getRangeAxis((-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var3.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.ItemLabelPosition var8 = var3.getBasePositiveItemLabelPosition();
    var0.setSeriesNegativeItemLabelPosition(100, var8, true);
    org.jfree.chart.urls.CategoryURLGenerator var11 = var0.getBaseURLGenerator();
    var0.setBaseLinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var3 = var2.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var5 = var2.lookupLegendTextPaint(15);
//     boolean var6 = var2.getBaseSeriesVisibleInLegend();
//     var2.setBaseShapesVisible(false);
//     java.awt.Shape var10 = var2.lookupLegendShape(100);
//     org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var10);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setTickLabelsVisible(false);
//     var12.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var12.getCategoryStart(10, (-1), var19, var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var24 = var22.getColumnRenderingOrder();
//     var12.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     java.awt.Paint var26 = var22.getRangeCrosshairPaint();
//     org.jfree.chart.entity.PlotEntity var28 = new org.jfree.chart.entity.PlotEntity(var10, (org.jfree.chart.plot.Plot)var22, "CategoryAnchor.MIDDLE");
//     java.awt.GradientPaint var29 = var0.transform(var1, var10);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    boolean var8 = var0.isRangeCrosshairVisible();
    org.jfree.chart.LegendItemCollection var9 = var0.getLegendItems();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var0.zoomRangeAxes(0.0d, var11, var12);
    org.jfree.chart.event.MarkerChangeEvent var14 = null;
    var0.markerChanged(var14);
    org.jfree.chart.plot.Plot var16 = var0.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    var0.setDomainGridlinesVisible(false);
    boolean var10 = var0.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    var0.configureDomainAxes();
    java.util.List var7 = var0.getCategories();
    org.jfree.chart.axis.ValueAxis var9 = null;
    var0.setRangeAxis(4, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     java.util.List var6 = var0.getCategories();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis(0);
//     java.awt.Stroke var10 = var7.getRangeCrosshairStroke();
//     java.awt.Stroke var11 = var7.getRangeZeroBaselineStroke();
//     var0.setOutlineStroke(var11);
//     java.awt.Paint var13 = var0.getRangeGridlinePaint();
//     var0.setAnchorValue(0.0d, true);
//     var0.zoom(4.0d);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     var0.setRangeMinorGridlinesVisible(false);
//     var0.setRangeCrosshairLockedOnData(false);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.drawBackground(var11, var12);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.renderer.category.BarPainter var1 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var0.setBarPainter(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(100, var9, false);
//     java.util.List var12 = var6.getCategories();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis(0);
//     java.awt.Stroke var16 = var13.getRangeCrosshairStroke();
//     java.awt.Stroke var17 = var13.getRangeZeroBaselineStroke();
//     var6.setOutlineStroke(var17);
//     var5.setDomainGridlineStroke(var17);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var22 = var20.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var20.getCategoryEnd((-1), (-1), var25, var26);
//     float var28 = var20.getTickMarkInsideLength();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     var30.setTickLabelsVisible(false);
//     var30.setAxisLineVisible(true);
//     java.awt.Paint var35 = var30.getAxisLinePaint();
//     var29.setRangeCrosshairPaint(var35);
//     org.jfree.chart.JFreeChart var37 = null;
//     org.jfree.chart.event.ChartChangeEventType var38 = null;
//     org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var35, var37, var38);
//     var20.setAxisLinePaint(var35);
//     java.awt.Font var41 = var20.getLabelFont();
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var47 = null;
//     java.awt.geom.Rectangle2D var48 = null;
//     java.awt.geom.Rectangle2D var49 = var0.createHotSpotBounds(var3, var4, var5, var20, var42, var43, 15, 100, true, var47, var48);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = var1.getSeriesShape(4);
//     java.lang.Boolean var7 = var1.getCreateEntity(1, 1);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var1 = var0.getDefaultPaint();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     java.awt.Paint var4 = var2.getDomainGridlinePaint();
//     var0.setDefaultPaint(var4);
//     java.lang.Boolean var7 = var0.getSeriesCreateEntity((-16777116));
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE");
    boolean var2 = var1.isLineVisible();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var3.setDomainAxis(100, var6, false);
    java.util.List var9 = var3.getCategories();
    boolean var10 = var3.isDomainGridlinesVisible();
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var13.setDomainAxis(0, var17);
    boolean var19 = var13.isDomainZoomable();
    var13.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var22 = null;
    var13.markerChanged(var22);
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var13.zoomDomainAxes(0.0d, var25, var26);
    org.jfree.data.category.DefaultCategoryDataset var28 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = var13.getRendererForDataset((org.jfree.data.category.CategoryDataset)var28);
    org.jfree.data.event.DatasetChangeListener var30 = null;
    var28.removeChangeListener(var30);
    int var33 = var28.getRowIndex((java.lang.Comparable)(byte)0);
    var28.clearSelection();
    var3.setDataset(1, (org.jfree.data.category.CategoryDataset)var28);
    var1.setDataset((org.jfree.data.general.Dataset)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var28.removeValue((java.lang.Comparable)0.2d, (java.lang.Comparable)(-16777116));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-1));

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var7 = null;
//     boolean var8 = var0.removeAnnotation(var7);
//     java.lang.Boolean var10 = var0.getSeriesShapesVisible(10);
//     var0.setUseFillPaint(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var13.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var19 = var13.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var20 = null;
//     boolean var21 = var13.removeAnnotation(var20);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var25 = var23.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     var23.setDomainAxis(0, var27);
//     boolean var29 = var23.isDomainZoomable();
//     org.jfree.chart.plot.Marker var31 = null;
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var34 = var23.removeDomainMarker(10, var31, var32, false);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var23.getRendererForDataset(var35);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.plot.Marker var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     var13.drawRangeMarker(var22, var23, var37, var38, var39);
//     java.lang.Boolean var42 = null;
//     var13.setSeriesVisible(10, var42, true);
//     boolean var45 = var13.getBaseSeriesVisibleInLegend();
//     boolean var48 = var13.getItemShapeFilled(1, 100);
//     boolean var49 = var13.getBaseLinesVisible();
//     java.awt.Stroke var53 = var13.getItemStroke(4, 4, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var55 = var54.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var57 = var54.lookupLegendTextPaint(15);
//     boolean var58 = var54.getBaseSeriesVisibleInLegend();
//     var54.setBaseShapesVisible(false);
//     java.awt.Shape var62 = var54.lookupLegendShape(100);
//     org.jfree.chart.entity.ChartEntity var63 = new org.jfree.chart.entity.ChartEntity(var62);
//     var13.setBaseShape(var62);
//     var0.setBaseShape(var62);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setTickLabelsVisible(false);
//     var0.setAxisLineVisible(true);
//     java.awt.Paint var5 = var0.getAxisLinePaint();
//     var0.configure();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var10 = var8.equals((java.lang.Object)var9);
//     java.lang.String var11 = var9.getLabelURL();
//     org.jfree.chart.renderer.RenderAttributes var13 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var14 = var13.getDefaultLabelFont();
//     java.awt.Paint var15 = var13.getDefaultPaint();
//     var9.setLabelPaint(var15);
//     org.jfree.chart.util.RectangleInsets var17 = var9.getTickLabelInsets();
//     double var19 = var17.calculateBottomInset((-1.0d));
//     var0.setTickLabelInsets(var17);
//     double var22 = var17.calculateTopInset(8.0d);
//     java.awt.geom.Rectangle2D var23 = null;
//     var17.trim(var23);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.lang.String var5 = var2.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.lang.Comparable var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var2.getCategoryLabelToolTip(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     boolean var15 = var14.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setTickLabelsVisible(false);
//     var17.setAxisLineVisible(true);
//     java.awt.Paint var22 = var17.getAxisLinePaint();
//     var16.setRangeCrosshairPaint(var22);
//     float var24 = var16.getBackgroundAlpha();
//     java.awt.Paint var25 = var16.getOutlinePaint();
//     var14.setLabelPaint(var25);
//     var14.setSeriesIndex(0);
//     var14.setDescription("CategoryAnchor.MIDDLE");
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var34 = var32.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setDomainAxis(0, var36);
//     boolean var38 = var32.isDomainZoomable();
//     var32.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.configureDomainAxes();
//     java.awt.Paint var43 = var41.getDomainGridlinePaint();
//     var32.setRangeZeroBaselinePaint(var43);
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", var43);
//     boolean var46 = var45.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
//     var48.setTickLabelsVisible(false);
//     var48.setAxisLineVisible(true);
//     java.awt.Paint var53 = var48.getAxisLinePaint();
//     var47.setRangeCrosshairPaint(var53);
//     float var55 = var47.getBackgroundAlpha();
//     java.awt.Paint var56 = var47.getOutlinePaint();
//     var45.setLabelPaint(var56);
//     var45.setSeriesIndex(0);
//     var45.setDescription("CategoryAnchor.MIDDLE");
//     var45.setLineVisible(false);
//     java.awt.Shape var64 = var45.getShape();
//     var14.setShape(var64);
//     
//     // Checks the contract:  equals-hashcode on var1 and var32
//     assertTrue("Contract failed: equals-hashcode on var1 and var32", var1.equals(var32) ? var1.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var41
//     assertTrue("Contract failed: equals-hashcode on var10 and var41", var10.equals(var41) ? var10.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var47
//     assertTrue("Contract failed: equals-hashcode on var16 and var47", var16.equals(var47) ? var16.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var1
//     assertTrue("Contract failed: equals-hashcode on var32 and var1", var32.equals(var1) ? var32.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var10
//     assertTrue("Contract failed: equals-hashcode on var41 and var10", var41.equals(var10) ? var41.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var16
//     assertTrue("Contract failed: equals-hashcode on var47 and var16", var47.equals(var16) ? var47.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var45
//     assertTrue("Contract failed: equals-hashcode on var14 and var45", var14.equals(var45) ? var14.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var14
//     assertTrue("Contract failed: equals-hashcode on var45 and var14", var45.equals(var14) ? var45.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.data.event.DatasetChangeListener var17 = null;
    var15.removeChangeListener(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var20 = var15.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = null;
//     var1.setSeriesShape(0, var4);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setTickLabelsVisible(false);
//     var6.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var6.getCategoryStart(10, (-1), var13, var14);
//     java.awt.Font var17 = var6.getTickLabelFont((java.lang.Comparable)'4');
//     var1.setDefaultLabelFont(var17);
//     java.awt.Shape var20 = null;
//     var1.setSeriesShape(0, var20);
//     java.awt.Stroke var24 = var1.getItemOutlineStroke(0, 0);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    var0.setSeriesURLGenerator(15, var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = var0.getPlot();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var40 = var39.getBaseSeriesVisibleInLegend();
    int var41 = var39.getColumnCount();
    var39.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var46 = var44.getTickLabelPaint((java.lang.Comparable)0);
    var39.setBaseItemLabelPaint(var46, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendTextPaint((-2), var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseShapesVisible(false);
//     java.awt.Shape var8 = var0.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(100, var12, false);
//     org.jfree.chart.util.SortOrder var15 = var9.getColumnRenderingOrder();
//     var9.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var9.drawBackgroundImage(var18, var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis(0);
//     java.awt.Stroke var24 = var21.getRangeCrosshairStroke();
//     var9.setDomainCrosshairStroke(var24);
//     var9.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var29 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var9, "DatasetRenderingOrder.REVERSE");
//     org.jfree.chart.plot.Plot var30 = var29.getPlot();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var31 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var32 = null;
//     java.lang.String var33 = var29.getImageMapAreaTag(var31, var32);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ChartEntity: tooltip = null");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(1, var2, true);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedRangeAxisSpace(var5, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var8.getLegendItemURLGenerator();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var0.zoomRangeAxes(0.2d, 100.0d, var18, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.configureDomainAxes();
//     boolean var8 = var6.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.axis.AxisLocation var17 = var10.getRangeAxisLocation();
//     var6.setRangeAxisLocation(2, var17);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var19.setDomainAxis(100, var22, false);
//     org.jfree.chart.util.SortOrder var25 = var19.getColumnRenderingOrder();
//     var19.setRangeMinorGridlinesVisible(false);
//     var19.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotOrientation var30 = var19.getOrientation();
//     org.jfree.chart.util.RectangleEdge var31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var17, var30);
//     var0.setRangeAxisLocation(var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var6.", var0.equals(var6) == var6.equals(var0));
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var5 = var3.calculateLeftOutset(4.0d);
    double var7 = var3.calculateRightInset((-1.0d));
    double var8 = var3.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.0d);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var13 = var12.getBaseSeriesVisibleInLegend();
    java.awt.Paint var15 = var12.lookupLegendTextPaint(15);
    boolean var16 = var12.getBaseSeriesVisibleInLegend();
    var12.setBaseLinesVisible(true);
    org.jfree.chart.urls.CategoryURLGenerator var20 = null;
    var12.setSeriesURLGenerator(15, var20);
    java.awt.Paint var23 = null;
    var12.setLegendTextPaint(100, var23);
    var0.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.axis.ValueAxis var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var27 = var0.getRangeAxisIndex(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE");
    boolean var2 = var1.isLineVisible();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var3.setDomainAxis(100, var6, false);
    java.util.List var9 = var3.getCategories();
    boolean var10 = var3.isDomainGridlinesVisible();
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var13.setDomainAxis(0, var17);
    boolean var19 = var13.isDomainZoomable();
    var13.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var22 = null;
    var13.markerChanged(var22);
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var13.zoomDomainAxes(0.0d, var25, var26);
    org.jfree.data.category.DefaultCategoryDataset var28 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = var13.getRendererForDataset((org.jfree.data.category.CategoryDataset)var28);
    org.jfree.data.event.DatasetChangeListener var30 = null;
    var28.removeChangeListener(var30);
    int var33 = var28.getRowIndex((java.lang.Comparable)(byte)0);
    var28.clearSelection();
    var3.setDataset(1, (org.jfree.data.category.CategoryDataset)var28);
    var1.setDataset((org.jfree.data.general.Dataset)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var28.removeColumn((java.lang.Comparable)(-7.8d));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-1));

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     java.awt.Paint var4 = var2.getDomainGridlinePaint();
//     var1.setDefaultOutlinePaint(var4);
//     java.awt.Paint var6 = var1.getDefaultLabelPaint();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setDomainAxis(100, var10, false);
//     org.jfree.chart.util.SortOrder var13 = var7.getColumnRenderingOrder();
//     java.awt.Paint var14 = var7.getRangeMinorGridlinePaint();
//     boolean var15 = var7.isRangeCrosshairVisible();
//     java.awt.Stroke var16 = var7.getDomainGridlineStroke();
//     var1.setDefaultStroke(var16);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var7.", var2.equals(var7) == var7.equals(var2));
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseShapesVisible(false);
//     java.awt.Shape var8 = var0.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(100, var12, false);
//     org.jfree.chart.util.SortOrder var15 = var9.getColumnRenderingOrder();
//     var9.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var9.drawBackgroundImage(var18, var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis(0);
//     java.awt.Stroke var24 = var21.getRangeCrosshairStroke();
//     var9.setDomainCrosshairStroke(var24);
//     var9.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var29 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var9, "DatasetRenderingOrder.REVERSE");
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var32 = var30.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     double var37 = var30.getCategoryEnd((-1), (-1), var35, var36);
//     java.lang.Object var38 = var30.clone();
//     boolean var39 = var9.equals((java.lang.Object)var30);
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     var9.drawOutline(var40, var41);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var13 = var11.getTickLabelPaint((java.lang.Comparable)0);
    var0.setSeriesOutlinePaint(4, var13, true);
    java.awt.Shape var17 = null;
    var0.setSeriesShape(255, var17, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    var1.setTickLabelsVisible(false);
    var1.setAxisLineVisible(true);
    java.awt.Paint var6 = var1.getAxisLinePaint();
    var0.setRangeCrosshairPaint(var6);
    float var8 = var0.getBackgroundAlpha();
    java.awt.Paint var9 = var0.getOutlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var0.zoomRangeAxes(0.0d, var11, var12, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var2 = var0.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var0.getCategoryEnd((-1), (-1), var5, var6);
    float var8 = var0.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    var10.setTickLabelsVisible(false);
    var10.setAxisLineVisible(true);
    java.awt.Paint var15 = var10.getAxisLinePaint();
    var9.setRangeCrosshairPaint(var15);
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartChangeEventType var18 = null;
    org.jfree.chart.event.ChartChangeEvent var19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var17, var18);
    var0.setAxisLinePaint(var15);
    java.awt.Font var21 = var0.getLabelFont();
    org.jfree.chart.util.RectangleInsets var22 = var0.getLabelInsets();
    java.awt.geom.Rectangle2D var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var24 = var22.createOutsetRectangle(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Comparable var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    java.awt.Stroke var5 = var2.getRangeCrosshairStroke();
    var2.setDomainCrosshairVisible(true);
    var2.setBackgroundImageAlpha(0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addObject(var1, (java.lang.Object)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    java.awt.Shape var8 = var0.lookupLegendShape(100);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-16777116), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
//     boolean var8 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.LegendItemCollection var9 = var0.getLegendItems();
//     java.awt.Image var10 = null;
//     var0.setBackgroundImage(var10);
//     var0.setDomainCrosshairRowKey((java.lang.Comparable)(-1.0f), false);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.configureDomainAxes();
//     java.awt.Paint var17 = var15.getDomainGridlinePaint();
//     java.awt.Stroke var18 = var15.getOutlineStroke();
//     var0.setParent((org.jfree.chart.plot.Plot)var15);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setDomainAxis(100, var24, false);
//     org.jfree.chart.util.SortOrder var27 = var21.getColumnRenderingOrder();
//     java.awt.Paint var28 = var21.getRangeMinorGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var31 = var29.getDomainAxis(0);
//     java.awt.Stroke var32 = var29.getRangeCrosshairStroke();
//     java.awt.Stroke var33 = var29.getRangeZeroBaselineStroke();
//     var21.setRangeMinorGridlineStroke(var33);
//     org.jfree.chart.axis.AxisLocation var36 = var21.getDomainAxisLocation(15);
//     org.jfree.chart.axis.AxisLocation var37 = var36.getOpposite();
//     var0.setDomainAxisLocation(0, var36);
//     
//     // Checks the contract:  equals-hashcode on var15 and var29
//     assertTrue("Contract failed: equals-hashcode on var15 and var29", var15.equals(var29) ? var15.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var15
//     assertTrue("Contract failed: equals-hashcode on var29 and var15", var29.equals(var15) ? var29.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = null;
//     var1.setSeriesShape(0, var4);
//     java.awt.Stroke var8 = var1.getItemOutlineStroke(15, 100);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setDrawBarOutline(false);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = null;
    org.jfree.data.category.DefaultCategoryDataset var6 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var8 = var0.initialise(var3, var4, var5, (org.jfree.data.category.CategoryDataset)var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    int var3 = var0.getColumnIndex((java.lang.Comparable)(-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((java.lang.Comparable)1L);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
//     boolean var8 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.LegendItemCollection var9 = var0.getLegendItems();
//     java.awt.Image var10 = null;
//     var0.setBackgroundImage(var10);
//     var0.setDomainCrosshairRowKey((java.lang.Comparable)(-1.0f), false);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.configureDomainAxes();
//     java.awt.Paint var17 = var15.getDomainGridlinePaint();
//     java.awt.Stroke var18 = var15.getOutlineStroke();
//     var0.setParent((org.jfree.chart.plot.Plot)var15);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     java.awt.geom.Point2D var22 = null;
//     org.jfree.chart.plot.PlotState var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     var0.draw(var20, var21, var22, var23, var24);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    var0.setDomainCrosshairVisible(true);
    int var6 = var0.getDatasetCount();
    org.jfree.chart.plot.CategoryMarker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    int var2 = var0.getColumnCount();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var5 = var3.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var3.setDomainAxis(0, var7);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var9.setFixedDomainAxisSpace(var12, false);
    var7.addChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
    var9.setDomainCrosshairColumnKey((java.lang.Comparable)0L, true);
    boolean var19 = var0.hasListener((java.util.EventListener)var9);
    java.awt.Color var23 = java.awt.Color.getColor("hi!", 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-100), (java.awt.Paint)var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var2 = var1.getBaseSeriesVisibleInLegend();
    java.awt.Paint var4 = var1.lookupLegendTextPaint(15);
    boolean var5 = var1.getBaseSeriesVisibleInLegend();
    var1.setBaseShapesVisible(false);
    var0.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)8.05d, (java.lang.Comparable)(-33));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     boolean var6 = var3.isMinorTickMarksVisible();
//     float var7 = var3.getMaximumCategoryLabelWidthRatio();
//     var3.configure();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setDomainCrosshairVisible(true);
//     org.jfree.chart.event.AnnotationChangeEvent var15 = null;
//     var12.annotationChanged(var15);
//     org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setTickLabelsVisible(false);
//     var18.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var18.getCategoryStart(10, (-1), var25, var26);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var30 = var28.getColumnRenderingOrder();
//     var18.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var28);
//     java.awt.Paint var32 = var28.getRangeCrosshairPaint();
//     org.jfree.chart.plot.PlotOrientation var33 = var28.getOrientation();
//     org.jfree.chart.util.RectangleEdge var34 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var17, var33);
//     org.jfree.chart.axis.AxisState var35 = null;
//     var3.drawTickMarks(var9, 0.0d, var11, var34, var35);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(1, var2, true);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedRangeAxisSpace(var5, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var8.getLegendItemURLGenerator();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    org.jfree.chart.plot.CategoryPlot var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setPlot(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var1 = var0.calculateOffsetX();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setDomainAxis(0, var6);
//     boolean var8 = var2.isDomainZoomable();
//     org.jfree.chart.plot.Marker var10 = null;
//     org.jfree.chart.util.Layer var11 = null;
//     boolean var13 = var2.removeDomainMarker(10, var10, var11, false);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = var2.getRendererForDataset(var14);
//     int var16 = var2.getDomainAxisCount();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.configureDomainAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var19 = var17.getDatasetRenderingOrder();
//     java.lang.String var20 = var19.toString();
//     var2.setDatasetRenderingOrder(var19);
//     boolean var22 = var0.equals((java.lang.Object)var19);
//     java.awt.image.BufferedImage var23 = null;
//     java.awt.image.BufferedImage var24 = var0.createDropShadow(var23);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     var0.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var9 = null;
//     var0.markerChanged(var9);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var13 = var12.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var15 = var12.lookupLegendTextPaint(15);
//     boolean var16 = var12.getBaseSeriesVisibleInLegend();
//     var12.setBaseLinesVisible(true);
//     org.jfree.chart.urls.CategoryURLGenerator var20 = null;
//     var12.setSeriesURLGenerator(15, var20);
//     java.awt.Paint var23 = null;
//     var12.setLegendTextPaint(100, var23);
//     var0.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     var0.clearRangeMarkers(255);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var28.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var34 = var28.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var35 = null;
//     boolean var36 = var28.removeAnnotation(var35);
//     boolean var37 = var28.getUseFillPaint();
//     boolean var38 = var0.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var12 and var28
//     assertTrue("Contract failed: equals-hashcode on var12 and var28", var12.equals(var28) ? var12.hashCode() == var28.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var28.", var12.equals(var28) == var28.equals(var12));
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue((java.lang.Number)2.0d);
    var1.setSelected(false);
    var1.setSelected(true);
    boolean var6 = var1.isSelected();
    boolean var7 = var1.isSelected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    boolean var7 = var0.getBaseShapesFilled();
    var0.setDrawOutlines(true);
    var0.setAutoPopulateSeriesStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     java.awt.Image var13 = var6.getBackgroundImage();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setDomainAxis(0, var19);
//     boolean var21 = var15.isDomainZoomable();
//     var15.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.configureDomainAxes();
//     java.awt.Paint var26 = var24.getDomainGridlinePaint();
//     var15.setRangeZeroBaselinePaint(var26);
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("", var26);
//     boolean var29 = var28.isShapeFilled();
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var31 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var33 = var31.equals((java.lang.Object)var32);
//     java.lang.String var34 = var32.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var38 = var36.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.Paint var39 = var36.getAxisLinePaint();
//     var32.setTickLabelPaint((java.lang.Comparable)(short)100, var39);
//     var28.setFillPaint(var39);
//     var6.setNoDataMessagePaint(var39);
//     
//     // Checks the contract:  equals-hashcode on var0 and var24
//     assertTrue("Contract failed: equals-hashcode on var0 and var24", var0.equals(var24) ? var0.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    boolean var11 = var0.removeDomainMarker(10, var8, var9, false);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var0.getRendererForDataset(var12);
    java.awt.Stroke var14 = var0.getRangeMinorGridlineStroke();
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var0.zoomDomainAxes(6.05d, var16, var17, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var7 = null;
//     boolean var8 = var0.removeAnnotation(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.Marker var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var0.drawRangeMarker(var9, var10, var24, var25, var26);
//     java.lang.Boolean var29 = null;
//     var0.setSeriesVisible(10, var29, true);
//     boolean var32 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.urls.CategoryURLGenerator var34 = null;
//     var0.setSeriesURLGenerator(15, var34, false);
//     org.jfree.chart.plot.CategoryPlot var37 = var0.getPlot();
//     boolean var38 = var0.getUseFillPaint();
//     java.lang.Boolean var40 = var0.getSeriesLinesVisible(100);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var43 = var42.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var45 = var42.lookupLegendTextPaint(15);
//     boolean var46 = var42.getBaseSeriesVisibleInLegend();
//     var42.setBaseLinesVisible(true);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.data.Range var50 = var42.findRangeBounds(var49);
//     org.jfree.chart.labels.CategoryToolTipGenerator var52 = var42.getSeriesToolTipGenerator(0);
//     var42.setAutoPopulateSeriesOutlineStroke(true);
//     java.awt.Paint var56 = var42.lookupSeriesPaint((-33));
//     var0.setSeriesOutlinePaint(0, var56, false);
//     
//     // Checks the contract:  equals-hashcode on var42 and var0
//     assertTrue("Contract failed: equals-hashcode on var42 and var0", var42.equals(var0) ? var42.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var42 and var0.", var42.equals(var0) == var0.equals(var42));
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    var0.setSeriesURLGenerator(15, var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = var0.getPlot();
    boolean var38 = var0.getUseFillPaint();
    double var39 = var0.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    java.awt.Stroke var4 = var0.getRangeZeroBaselineStroke();
    var0.clearRangeMarkers();
    java.awt.Stroke var6 = var0.getRangeZeroBaselineStroke();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(1.0d, var8, var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes((-7.8d), var12, var13, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    var1.setTickLabelsVisible(false);
    var1.setAxisLineVisible(true);
    java.awt.Paint var6 = var1.getAxisLinePaint();
    var0.setRangeCrosshairPaint(var6);
    float var8 = var0.getBackgroundAlpha();
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.plot.CategoryCrosshairState var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var14 = var0.render(var9, var10, (-100), var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var9 = null;
//     var6.setFixedDomainAxisSpace(var9, false);
//     var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
//     var6.setDomainCrosshairColumnKey((java.lang.Comparable)0L, true);
//     var6.setOutlineVisible(false);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.configureDomainAxes();
//     java.awt.Paint var20 = var18.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleInsets var21 = var18.getInsets();
//     double var23 = var21.calculateLeftOutset(4.0d);
//     double var25 = var21.calculateRightInset((-1.0d));
//     var6.setInsets(var21, true);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
//     var28.setDomainAxis(100, var31, false);
//     org.jfree.chart.util.SortOrder var34 = var28.getColumnRenderingOrder();
//     java.awt.Paint var35 = var28.getRangeMinorGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var38 = var36.getDomainAxis(0);
//     java.awt.Stroke var39 = var36.getRangeCrosshairStroke();
//     java.awt.Stroke var40 = var36.getRangeZeroBaselineStroke();
//     var28.setRangeMinorGridlineStroke(var40);
//     org.jfree.chart.axis.AxisLocation var43 = var28.getDomainAxisLocation(15);
//     org.jfree.chart.axis.AxisLocation var44 = var43.getOpposite();
//     org.jfree.chart.axis.AxisLocation var45 = org.jfree.chart.axis.AxisLocation.getOpposite(var44);
//     var6.setDomainAxisLocation(var44, true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var36
//     assertTrue("Contract failed: equals-hashcode on var18 and var36", var18.equals(var36) ? var18.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var18
//     assertTrue("Contract failed: equals-hashcode on var36 and var18", var36.equals(var18) ? var36.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    java.lang.Object var2 = var1.clone();
    java.lang.String var3 = var1.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "hi!"+ "'", var3.equals("hi!"));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    var14.setDescription("");
    var14.setSeriesIndex(0);
    var14.setLineVisible(false);
    var14.setURLText("hi!");
    java.awt.Font var23 = var14.getLabelFont();
    java.awt.Paint var24 = var14.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    java.awt.Color var3 = java.awt.Color.getColor("", 1);
    java.awt.Color var4 = var3.brighter();
    java.awt.Color var5 = java.awt.Color.getColor("", var4);
    int var6 = var5.getTransparency();
    java.awt.Color var10 = java.awt.Color.getColor("", 1);
    java.awt.Color var11 = var10.brighter();
    java.awt.Color var12 = java.awt.Color.getColor("", var11);
    java.awt.color.ColorSpace var13 = var11.getColorSpace();
    float[] var16 = new float[] { (-1.0f), 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var17 = var5.getComponents(var13, var16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    org.jfree.chart.util.SortOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByObjects(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    boolean var4 = var2.equals((java.lang.Object)var3);
    boolean var5 = var3.isAxisLineVisible();
    var0.setObject((java.lang.Object)var5, (java.lang.Comparable)(byte)10, (java.lang.Comparable)(byte)10);
    int var10 = var0.getColumnIndex((java.lang.Comparable)0);
    org.jfree.data.SelectableValue var12 = new org.jfree.data.SelectableValue((java.lang.Number)2.0d);
    var12.setSelected(false);
    boolean var15 = var12.isSelected();
    boolean var16 = var0.equals((java.lang.Object)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)2.0d, (java.lang.Comparable)(short)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setDrawBarOutline(false);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getPositiveItemLabelPositionFallback();
    double var4 = var0.getShadowYOffset();
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    boolean var6 = var0.removeAnnotation(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisOffset(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setDrawBarOutline(false);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getPositiveItemLabelPositionFallback();
    boolean var4 = var0.getBaseSeriesVisible();
    org.jfree.chart.renderer.RenderAttributes var7 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var8 = var7.getDefaultLabelFont();
    java.awt.Paint var9 = var7.getDefaultPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-16777116), var9, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setDrawBarOutline(false);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getPositiveItemLabelPositionFallback();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(0, var13);
//     boolean var15 = var9.isDomainZoomable();
//     org.jfree.chart.plot.Plot var16 = var9.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.axis.ValueAxis var19 = var9.getRangeAxis(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     int var21 = var9.getIndexOf(var20);
//     org.jfree.chart.LegendItemCollection var22 = var9.getLegendItems();
//     boolean var23 = var9.isDomainZoomable();
//     var9.mapDatasetToRangeAxis(0, (-33));
//     org.jfree.chart.axis.CategoryAxis var28 = var9.getDomainAxisForDataset(0);
//     java.awt.Color var32 = java.awt.Color.getColor("", 1);
//     java.awt.Color var33 = var32.brighter();
//     java.awt.Color var34 = java.awt.Color.getColor("", var33);
//     int var35 = var34.getTransparency();
//     var28.setTickLabelPaint((java.awt.Paint)var34);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.data.category.DefaultCategoryDataset var38 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Object var39 = var38.clone();
//     org.jfree.data.KeyedObjects2D var40 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var42 = var41.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var44 = var41.lookupLegendTextPaint(15);
//     boolean var45 = var41.getBaseSeriesVisibleInLegend();
//     var41.setBaseShapesVisible(false);
//     var40.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
//     java.util.List var51 = var40.getColumnKeys();
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var54 = var52.getDomainAxis(0);
//     java.awt.Stroke var55 = var52.getRangeCrosshairStroke();
//     var52.setDomainCrosshairVisible(true);
//     var52.setBackgroundImageAlpha(0.0f);
//     boolean var60 = var40.equals((java.lang.Object)var52);
//     boolean var61 = var38.equals((java.lang.Object)var40);
//     var38.validateObject();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var66 = null;
//     boolean var67 = var0.hitTest(8.0d, 0.05d, var6, var7, var8, var28, var37, (org.jfree.data.category.CategoryDataset)var38, 255, 2, false, var66);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject(0, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.lang.String var4 = var2.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var6 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var7 = var6.getDefaultLabelFont();
    java.awt.Paint var8 = var6.getDefaultPaint();
    var2.setLabelPaint(var8);
    org.jfree.chart.util.RectangleInsets var10 = var2.getTickLabelInsets();
    double var12 = var10.calculateBottomInset((-1.0d));
    java.awt.geom.Rectangle2D var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var10.createInsetRectangle(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2.0d);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setTickLabelsVisible(false);
//     var0.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var0.getCategoryStart(10, (-1), var7, var8);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var12 = var10.getColumnRenderingOrder();
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var14.setDomainAxis(100, var17, false);
//     org.jfree.chart.util.SortOrder var20 = var14.getColumnRenderingOrder();
//     var14.clearRangeAxes();
//     var14.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var25 = var24.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
//     boolean var28 = var24.getBaseSeriesVisibleInLegend();
//     var24.setBaseShapesVisible(false);
//     boolean var31 = var24.getBaseShapesFilled();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var35 = var33.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
//     var33.setDomainAxis(0, var37);
//     boolean var39 = var33.isDomainZoomable();
//     var33.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     var42.configureDomainAxes();
//     java.awt.Paint var44 = var42.getDomainGridlinePaint();
//     var33.setRangeZeroBaselinePaint(var44);
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("", var44);
//     boolean var47 = var46.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis();
//     var49.setTickLabelsVisible(false);
//     var49.setAxisLineVisible(true);
//     java.awt.Paint var54 = var49.getAxisLinePaint();
//     var48.setRangeCrosshairPaint(var54);
//     float var56 = var48.getBackgroundAlpha();
//     java.awt.Paint var57 = var48.getOutlinePaint();
//     var46.setLabelPaint(var57);
//     var24.setBaseLegendTextPaint(var57);
//     var14.setRangeGridlinePaint(var57);
//     org.jfree.chart.renderer.RenderAttributes var62 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var63 = var62.getDefaultCreateEntity();
//     java.awt.Paint var64 = var62.getDefaultFillPaint();
//     var14.setOutlinePaint(var64);
//     java.awt.Stroke var66 = var14.getDomainGridlineStroke();
//     var10.setDomainGridlineStroke(var66);
//     
//     // Checks the contract:  equals-hashcode on var10 and var42
//     assertTrue("Contract failed: equals-hashcode on var10 and var42", var10.equals(var42) ? var10.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var10
//     assertTrue("Contract failed: equals-hashcode on var42 and var10", var42.equals(var10) ? var42.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    java.awt.Stroke var4 = var0.getRangeZeroBaselineStroke();
    var0.clearRangeMarkers();
    boolean var6 = var0.isNotify();
    var0.setCrosshairDatasetIndex(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 1.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-131072));

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var13 = var12.getBaseSeriesVisibleInLegend();
    java.awt.Paint var15 = var12.lookupLegendTextPaint(15);
    boolean var16 = var12.getBaseSeriesVisibleInLegend();
    var12.setBaseLinesVisible(true);
    org.jfree.chart.urls.CategoryURLGenerator var20 = null;
    var12.setSeriesURLGenerator(15, var20);
    java.awt.Paint var23 = null;
    var12.setLegendTextPaint(100, var23);
    var0.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.annotations.CategoryAnnotation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var26, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    var0.clearRangeAxes();
    var0.setRangeMinorGridlinesVisible(false);
    org.jfree.chart.axis.ValueAxis var11 = null;
    var0.setRangeAxis(1, var11);
    org.jfree.data.KeyedObjects2D var14 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var16 = var15.getBaseSeriesVisibleInLegend();
    java.awt.Paint var18 = var15.lookupLegendTextPaint(15);
    boolean var19 = var15.getBaseSeriesVisibleInLegend();
    var15.setBaseShapesVisible(false);
    var14.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var25 = var14.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes(0, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    org.jfree.chart.renderer.RenderAttributes var5 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.lang.Boolean var6 = var5.getDefaultCreateEntity();
    java.awt.Paint var7 = var5.getDefaultFillPaint();
    java.awt.Paint var8 = var5.getDefaultOutlinePaint();
    java.awt.Paint var9 = var5.getDefaultOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue((-16777116), (java.lang.Comparable)"AxisLocation.BOTTOM_OR_RIGHT", (java.lang.Object)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     java.util.List var6 = var0.getCategories();
//     boolean var7 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     var10.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var19 = null;
//     var10.markerChanged(var19);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var10.zoomDomainAxes(0.0d, var22, var23);
//     org.jfree.data.category.DefaultCategoryDataset var25 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = var10.getRendererForDataset((org.jfree.data.category.CategoryDataset)var25);
//     org.jfree.data.event.DatasetChangeListener var27 = null;
//     var25.removeChangeListener(var27);
//     int var30 = var25.getRowIndex((java.lang.Comparable)(byte)0);
//     var25.clearSelection();
//     var0.setDataset(1, (org.jfree.data.category.CategoryDataset)var25);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var35 = var33.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
//     var33.setDomainAxis(0, var37);
//     boolean var39 = var33.isDomainZoomable();
//     var33.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var42 = null;
//     var33.markerChanged(var42);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var33.zoomDomainAxes(0.0d, var45, var46);
//     org.jfree.data.category.DefaultCategoryDataset var48 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = var33.getRendererForDataset((org.jfree.data.category.CategoryDataset)var48);
//     var48.addValue((java.lang.Number)(-1.0d), (java.lang.Comparable)4.0d, (java.lang.Comparable)'a');
//     var25.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var48);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = null;
//     var1.setSeriesShape(0, var4);
//     java.awt.Paint var7 = var1.getSeriesLabelPaint((-1));
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("PlotOrientation.VERTICAL", var1, var2);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var13 = var11.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    var11.setDomainAxis(0, var15);
    boolean var17 = var11.isDomainZoomable();
    org.jfree.chart.plot.Plot var18 = var11.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var11);
    java.util.List var20 = var11.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxes((-16777116), var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setTickLabelsVisible(false);
    var0.setAxisLineVisible(true);
    java.awt.Paint var5 = var0.getAxisLinePaint();
    var0.configure();
    java.awt.Stroke var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAxisLineStroke(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var2 = var0.getDatasetRenderingOrder();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var3);
    org.jfree.data.category.DefaultCategoryDataset var5 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var6 = var5.clone();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    var7.setDomainAxis(0, var11);
    boolean var13 = var7.isDomainZoomable();
    var7.setDomainCrosshairVisible(false);
    var5.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var7);
    java.lang.Object var17 = var5.clone();
    java.lang.Object var18 = var5.clone();
    var0.setDataset((org.jfree.data.category.CategoryDataset)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBackgroundImageAlpha(2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(1, var2, true);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedRangeAxisSpace(var5, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var8.getLegendItemURLGenerator();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setDomainCrosshairVisible(true);
    org.jfree.chart.event.AnnotationChangeEvent var19 = null;
    var16.annotationChanged(var19);
    org.jfree.chart.util.SortOrder var21 = var16.getColumnRenderingOrder();
    var0.setRowRenderingOrder(var21);
    double var23 = var0.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    var0.setUseSeriesOffset(true);
    var0.clearSeriesPaints(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-1), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    java.util.List var6 = var0.getCategories();
    boolean var7 = var0.isDomainGridlinesVisible();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.util.RectangleInsets var9 = var0.getAxisOffset();
    double var11 = var9.calculateLeftInset(100.0d);
    java.awt.geom.Rectangle2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var13 = var9.createOutsetRectangle(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 4.0d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var3.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var9 = var3.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    boolean var11 = var3.removeAnnotation(var10);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var15 = var13.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var13.setDomainAxis(0, var17);
    boolean var19 = var13.isDomainZoomable();
    org.jfree.chart.plot.Marker var21 = null;
    org.jfree.chart.util.Layer var22 = null;
    boolean var24 = var13.removeDomainMarker(10, var21, var22, false);
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = var13.getRendererForDataset(var25);
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.plot.Marker var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var3.drawRangeMarker(var12, var13, var27, var28, var29);
    java.lang.Boolean var32 = null;
    var3.setSeriesVisible(10, var32, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var36 = null;
    var3.setSeriesToolTipGenerator(100, var36, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = var3.getToolTipGenerator(15, 1, false);
    java.awt.Paint var43 = var3.getBaseOutlinePaint();
    var0.setSeriesPaint(0, var43, false);
    java.awt.Graphics2D var48 = null;
    java.awt.geom.Rectangle2D var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    var50.configureDomainAxes();
    java.awt.Paint var52 = var50.getDomainGridlinePaint();
    java.lang.Object var53 = var50.clone();
    java.awt.Paint var54 = var50.getRangeZeroBaselinePaint();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var56 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis();
    boolean var58 = var56.equals((java.lang.Object)var57);
    java.awt.geom.Rectangle2D var64 = null;
    org.jfree.chart.util.RectangleEdge var65 = null;
    double var66 = var57.getCategorySeriesMiddle((-1), 10, 0, 1, 10.0d, var64, var65);
    var57.setLabelToolTip("Category Plot");
    org.jfree.chart.axis.ValueAxis var69 = null;
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var72 = var70.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var74 = new org.jfree.chart.axis.CategoryAxis();
    var70.setDomainAxis(0, var74);
    boolean var76 = var70.isDomainZoomable();
    var70.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var79 = null;
    var70.markerChanged(var79);
    org.jfree.chart.plot.PlotRenderingInfo var82 = null;
    java.awt.geom.Point2D var83 = null;
    var70.zoomDomainAxes(0.0d, var82, var83);
    org.jfree.data.category.DefaultCategoryDataset var85 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var86 = var70.getRendererForDataset((org.jfree.data.category.CategoryDataset)var85);
    org.jfree.data.event.DatasetChangeListener var87 = null;
    var85.removeChangeListener(var87);
    int var90 = var85.getRowIndex((java.lang.Comparable)(byte)0);
    var85.clearSelection();
    int var92 = var85.getColumnCount();
    org.jfree.chart.renderer.category.CategoryItemRendererState var96 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var97 = var0.hitTest(8.0d, 100.0d, var48, var49, var50, var57, var69, (org.jfree.data.category.CategoryDataset)var85, 5, (-16777116), false, var96);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
//     boolean var11 = var0.isSubplot();
//     java.awt.Paint var12 = var0.getBackgroundPaint();
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var0.drawOutline(var13, var14);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    int var2 = var0.getColumnCount();
    var0.setSeriesItemLabelsVisible(4, false);
    int var6 = var0.getPassCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-100), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDomainCrosshairVisible(true);
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)"hi!", true);
    org.jfree.chart.plot.CategoryMarker var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    var0.setBaseCreateEntities(true);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    var10.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.configureDomainAxes();
    java.awt.Paint var21 = var19.getDomainGridlinePaint();
    var10.setRangeZeroBaselinePaint(var21);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var21);
    boolean var24 = var23.isShapeFilled();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
    var26.setTickLabelsVisible(false);
    var26.setAxisLineVisible(true);
    java.awt.Paint var31 = var26.getAxisLinePaint();
    var25.setRangeCrosshairPaint(var31);
    float var33 = var25.getBackgroundAlpha();
    java.awt.Paint var34 = var25.getOutlinePaint();
    var23.setLabelPaint(var34);
    var23.setSeriesIndex(0);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var39 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
    boolean var41 = var39.equals((java.lang.Object)var40);
    java.lang.String var42 = var40.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var44 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var45 = var44.getDefaultLabelFont();
    java.awt.Paint var46 = var44.getDefaultPaint();
    var40.setLabelPaint(var46);
    var23.setLinePaint(var46);
    var0.setBasePaint(var46);
    boolean var50 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var52 = var51.getBaseSeriesVisibleInLegend();
    java.awt.Paint var54 = var51.lookupLegendTextPaint(15);
    java.awt.Stroke var56 = var51.getSeriesStroke(15);
    var51.setAutoPopulateSeriesOutlineStroke(true);
    boolean var59 = var0.equals((java.lang.Object)true);
    org.jfree.chart.plot.CategoryPlot var60 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPlot(var60);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.category.DefaultCategoryDataset var2 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var3 = var2.clone();
    var0.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var2);
    org.jfree.data.category.CategoryDatasetSelectionState var5 = null;
    var2.setSelectionState(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.incrementValue(4.0d, (java.lang.Comparable)100, (java.lang.Comparable)(-1.0d));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    boolean var8 = var0.isRangeCrosshairVisible();
    org.jfree.chart.LegendItemCollection var9 = var0.getLegendItems();
    java.awt.Image var10 = null;
    var0.setBackgroundImage(var10);
    var0.setDomainCrosshairRowKey((java.lang.Comparable)(-1.0f), false);
    org.jfree.chart.plot.Plot var15 = var0.getRootPlot();
    double var16 = var0.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.data.event.DatasetChangeListener var17 = null;
    var15.removeChangeListener(var17);
    int var20 = var15.getRowIndex((java.lang.Comparable)(byte)0);
    var15.clearSelection();
    java.lang.Comparable var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeValue(var22, (java.lang.Comparable)15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    java.awt.Font var20 = var17.getLabelFont();
    var17.setLabelToolTip("hi!");
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var25 = var24.getBaseSeriesVisibleInLegend();
    java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
    boolean var28 = var24.getBaseSeriesVisibleInLegend();
    var24.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var24.setBaseToolTipGenerator(var31, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var24.setBaseToolTipGenerator(var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var17, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    org.jfree.data.general.DatasetGroup var38 = var15.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setSelected(0, (-131072), true, false);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue((java.lang.Number)(-2));

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
//     boolean var11 = var0.isDomainCrosshairVisible();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var14 = var12.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setDomainAxis(0, var16);
//     boolean var18 = var12.isDomainZoomable();
//     var12.setDomainCrosshairVisible(false);
//     org.jfree.chart.event.MarkerChangeEvent var21 = null;
//     var12.markerChanged(var21);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     java.awt.geom.Point2D var25 = null;
//     var12.zoomDomainAxes(0.0d, var24, var25);
//     org.jfree.data.category.DefaultCategoryDataset var27 = new org.jfree.data.category.DefaultCategoryDataset();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = var12.getRendererForDataset((org.jfree.data.category.CategoryDataset)var27);
//     org.jfree.data.event.DatasetChangeListener var29 = null;
//     var27.removeChangeListener(var29);
//     int var32 = var27.getRowIndex((java.lang.Comparable)(byte)0);
//     var27.clearSelection();
//     int var34 = var27.getColumnCount();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var27);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue((-14.0d), (java.lang.Comparable)0, (java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var13 = var11.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var11.getCategoryEnd((-1), (-1), var16, var17);
    float var19 = var11.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var21.setTickLabelsVisible(false);
    var21.setAxisLineVisible(true);
    java.awt.Paint var26 = var21.getAxisLinePaint();
    var20.setRangeCrosshairPaint(var26);
    org.jfree.chart.JFreeChart var28 = null;
    org.jfree.chart.event.ChartChangeEventType var29 = null;
    org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var28, var29);
    var11.setAxisLinePaint(var26);
    java.awt.Font var32 = var11.getLabelFont();
    var0.setSeriesItemLabelFont(0, var32);
    boolean var37 = var0.isItemLabelVisible(4, 1, false);
    org.jfree.chart.urls.CategoryURLGenerator var38 = null;
    var0.setBaseURLGenerator(var38, false);
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    java.awt.Graphics2D var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    var48.setRangeCrosshairVisible(false);
    java.lang.String var51 = var48.getPlotType();
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
    var52.setTickLabelsVisible(false);
    var52.setMaximumCategoryLabelLines((-1));
    org.jfree.chart.axis.CategoryLabelPositions var57 = var52.getCategoryLabelPositions();
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.data.category.DefaultCategoryDataset var59 = new org.jfree.data.category.DefaultCategoryDataset();
    var59.addValue((-14.0d), (java.lang.Comparable)0, (java.lang.Comparable)0L);
    org.jfree.chart.renderer.category.CategoryItemRendererState var67 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var68 = var0.hitTest(0.0d, 0.2d, var46, var47, var48, var52, var58, (org.jfree.data.category.CategoryDataset)var59, 0, 10, false, var67);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "Category Plot"+ "'", var51.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var5 = var3.calculateLeftOutset(4.0d);
    double var7 = var3.extendHeight(0.05d);
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var11 = var3.createOutsetRectangle(var8, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.05d);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var2 = var1.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var4 = var1.lookupLegendTextPaint(15);
//     boolean var5 = var1.getBaseSeriesVisibleInLegend();
//     var1.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var1.setBaseToolTipGenerator(var8, false);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var14 = var12.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var12.getCategoryEnd((-1), (-1), var17, var18);
//     float var20 = var12.getTickMarkInsideLength();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var22.setTickLabelsVisible(false);
//     var22.setAxisLineVisible(true);
//     java.awt.Paint var27 = var22.getAxisLinePaint();
//     var21.setRangeCrosshairPaint(var27);
//     org.jfree.chart.JFreeChart var29 = null;
//     org.jfree.chart.event.ChartChangeEventType var30 = null;
//     org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var27, var29, var30);
//     var12.setAxisLinePaint(var27);
//     java.awt.Font var33 = var12.getLabelFont();
//     var1.setSeriesItemLabelFont(0, var33);
//     boolean var35 = var1.getUseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     var37.configureDomainAxes();
//     java.awt.Stroke var39 = var37.getRangeGridlineStroke();
//     var1.setSeriesOutlineStroke(0, var39, true);
//     boolean var42 = var0.equals((java.lang.Object)true);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var46 = var44.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
//     var44.setDomainAxis(0, var48);
//     boolean var50 = var44.isDomainZoomable();
//     var44.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     var53.configureDomainAxes();
//     java.awt.Paint var55 = var53.getDomainGridlinePaint();
//     var44.setRangeZeroBaselinePaint(var55);
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("", var55);
//     var57.setDescription("");
//     var57.setSeriesIndex(0);
//     var57.setToolTipText("");
//     org.jfree.chart.util.GradientPaintTransformer var64 = var57.getFillPaintTransformer();
//     var0.setGradientPaintTransformer(var64);
//     
//     // Checks the contract:  equals-hashcode on var37 and var53
//     assertTrue("Contract failed: equals-hashcode on var37 and var53", var37.equals(var53) ? var37.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var37
//     assertTrue("Contract failed: equals-hashcode on var53 and var37", var53.equals(var37) ? var53.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseShapesVisible(false);
    var2.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var13 = var2.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
    var14.setDomainCrosshairVisible(true);
    var14.setBackgroundImageAlpha(0.0f);
    boolean var22 = var2.equals((java.lang.Object)var14);
    boolean var23 = var0.equals((java.lang.Object)var2);
    var0.validateObject();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var27 = var0.getValue((java.lang.Comparable)4.0d, (java.lang.Comparable)15);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    boolean var15 = var14.isShapeFilled();
    java.text.AttributedString var16 = var14.getAttributedLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.data.Range var8 = var0.findRangeBounds(var7);
    var0.setBaseSeriesVisibleInLegend(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setTickLabelsVisible(false);
    var0.setMaximumCategoryLabelLines((-1));
    var0.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setTickLabelsVisible(false);
    var7.setAxisLineVisible(true);
    java.awt.Paint var12 = var7.getAxisLinePaint();
    var7.configure();
    boolean var14 = var0.equals((java.lang.Object)var7);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var17 = var15.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    var15.setDomainAxis(0, var19);
    boolean var21 = var15.isDomainZoomable();
    var15.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var24 = null;
    var15.markerChanged(var24);
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    java.awt.geom.Point2D var28 = null;
    var15.zoomDomainAxes(0.0d, var27, var28);
    org.jfree.data.category.DefaultCategoryDataset var30 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = var15.getRendererForDataset((org.jfree.data.category.CategoryDataset)var30);
    org.jfree.data.event.DatasetChangeListener var32 = null;
    var30.removeChangeListener(var32);
    int var35 = var30.getRowIndex((java.lang.Comparable)(byte)0);
    var30.clearSelection();
    int var37 = var30.getColumnCount();
    var30.setValue(0.0d, (java.lang.Comparable)8.0d, (java.lang.Comparable)(byte)0);
    org.jfree.chart.event.DatasetChangeInfo var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.event.DatasetChangeEvent var43 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var14, (org.jfree.data.general.Dataset)var30, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseShapesVisible(false);
//     java.awt.Shape var8 = var0.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(100, var12, false);
//     org.jfree.chart.util.SortOrder var15 = var9.getColumnRenderingOrder();
//     var9.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var9.drawBackgroundImage(var18, var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis(0);
//     java.awt.Stroke var24 = var21.getRangeCrosshairStroke();
//     var9.setDomainCrosshairStroke(var24);
//     var9.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var29 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var9, "DatasetRenderingOrder.REVERSE");
//     org.jfree.chart.plot.Plot var30 = var29.getPlot();
//     boolean var32 = var29.equals((java.lang.Object)' ');
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var34 = var33.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var36 = var33.lookupLegendTextPaint(15);
//     boolean var37 = var33.getBaseSeriesVisibleInLegend();
//     var33.setBaseShapesVisible(false);
//     java.awt.Shape var41 = var33.lookupLegendShape(100);
//     org.jfree.chart.entity.ChartEntity var42 = new org.jfree.chart.entity.ChartEntity(var41);
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis();
//     var43.setTickLabelsVisible(false);
//     var43.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     double var52 = var43.getCategoryStart(10, (-1), var50, var51);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     var53.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var55 = var53.getColumnRenderingOrder();
//     var43.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var53);
//     java.awt.Paint var57 = var53.getRangeCrosshairPaint();
//     org.jfree.chart.entity.PlotEntity var59 = new org.jfree.chart.entity.PlotEntity(var41, (org.jfree.chart.plot.Plot)var53, "CategoryAnchor.MIDDLE");
//     var29.setArea(var41);
//     
//     // Checks the contract:  equals-hashcode on var21 and var53
//     assertTrue("Contract failed: equals-hashcode on var21 and var53", var21.equals(var53) ? var21.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var21
//     assertTrue("Contract failed: equals-hashcode on var53 and var21", var53.equals(var21) ? var53.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setDomainCrosshairVisible(true);
    var0.setRangeCrosshairValue(10.0d, false);
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.RenderingSource var9 = null;
    var0.select(0.0d, 10.0d, var8, var9);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    var11.setTickLabelsVisible(false);
    java.awt.Font var14 = var11.getLabelFont();
    var11.setLabelToolTip("hi!");
    java.awt.Font var18 = var11.getTickLabelFont((java.lang.Comparable)(byte)(-1));
    var0.setNoDataMessageFont(var18);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var21.setTickLabelsVisible(false);
    var21.setAxisLineVisible(true);
    java.awt.Paint var26 = var21.getAxisLinePaint();
    var20.setRangeCrosshairPaint(var26);
    org.jfree.chart.plot.DrawingSupplier var28 = var20.getDrawingSupplier();
    var0.setDrawingSupplier(var28, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    boolean var5 = var3.equals((java.lang.Object)var4);
    boolean var6 = var4.isAxisLineVisible();
    var0.setObject((java.lang.Object)var4, (java.lang.Comparable)10.0f, (java.lang.Comparable)4);
    var4.setTickMarkInsideLength((-1.0f));
    float var12 = var4.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0f);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    int var2 = var0.getColumnCount();
    var0.setAutoPopulateSeriesStroke(false);
    int var5 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-131072), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
    org.jfree.chart.axis.AxisLocation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setDomainAxis(100, var5, false);
//     org.jfree.chart.util.SortOrder var8 = var2.getColumnRenderingOrder();
//     var2.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var2.drawBackgroundImage(var11, var12);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis[] var15 = new org.jfree.chart.axis.ValueAxis[] { var14};
//     var2.setRangeAxes(var15);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setDomainAxis(0, var22);
//     boolean var24 = var18.isDomainZoomable();
//     var18.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.configureDomainAxes();
//     java.awt.Paint var29 = var27.getDomainGridlinePaint();
//     var18.setRangeZeroBaselinePaint(var29);
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", var29);
//     boolean var32 = var31.isShapeFilled();
//     var31.setLineVisible(false);
//     var31.setURLText("hi!");
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var40 = var38.equals((java.lang.Object)var39);
//     java.lang.String var41 = var39.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var45 = var43.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.Paint var46 = var43.getAxisLinePaint();
//     var39.setTickLabelPaint((java.lang.Comparable)(short)100, var46);
//     var31.setLabelPaint(var46);
//     var2.setRangeGridlinePaint(var46);
//     java.awt.geom.Rectangle2D var50 = null;
//     var0.drawOutline(var1, var2, var50);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setTickLabelsVisible(false);
//     var0.setMaximumCategoryLabelLines((-1));
//     var0.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.configureDomainAxes();
//     java.awt.Paint var9 = var7.getDomainGridlinePaint();
//     java.lang.Object var10 = var7.clone();
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var0.getCategoryStart(0, (-1), var14, var15);
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.configureDomainAxes();
//     boolean var25 = var23.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var29 = var27.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
//     var27.setDomainAxis(0, var31);
//     boolean var33 = var27.isDomainZoomable();
//     org.jfree.chart.axis.AxisLocation var34 = var27.getRangeAxisLocation();
//     var23.setRangeAxisLocation(2, var34);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var36.setDomainAxis(100, var39, false);
//     org.jfree.chart.util.SortOrder var42 = var36.getColumnRenderingOrder();
//     var36.setRangeMinorGridlinesVisible(false);
//     var36.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotOrientation var47 = var36.getOrientation();
//     org.jfree.chart.util.RectangleEdge var48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var34, var47);
//     double var49 = var0.getCategorySeriesMiddle(0, 2, 5, 1, 8.0d, var22, var48);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseShapesVisible(false);
    var2.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var13 = var2.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
    var14.setDomainCrosshairVisible(true);
    var14.setBackgroundImageAlpha(0.0f);
    boolean var22 = var2.equals((java.lang.Object)var14);
    boolean var23 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
    var24.setDomainAxis(100, var27, false);
    org.jfree.chart.util.SortOrder var30 = var24.getColumnRenderingOrder();
    var24.clearRangeAxes();
    var24.setRangeMinorGridlinesVisible(false);
    org.jfree.chart.plot.PlotOrientation var34 = var24.getOrientation();
    java.lang.String var35 = var34.toString();
    java.lang.Comparable var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setObject((java.lang.Object)var34, (java.lang.Comparable)0.5f, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var35.equals("PlotOrientation.VERTICAL"));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var6.setTickLabelsVisible(false);
    var6.setAxisLineVisible(true);
    java.awt.Paint var11 = var6.getAxisLinePaint();
    var5.setRangeCrosshairPaint(var11);
    float var13 = var5.getBackgroundAlpha();
    java.awt.Paint var14 = var5.getOutlinePaint();
    org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", var4, var14);
    org.jfree.chart.JFreeChart var16 = null;
    org.jfree.chart.event.ChartChangeEventType var17 = null;
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var16, var17);
    org.jfree.chart.JFreeChart var19 = null;
    var18.setChart(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var0.panDomainAxes(8.0d, var11, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    var0.setSeriesShapesFilled(15, (java.lang.Boolean)false);
    java.lang.Boolean var11 = var0.getSeriesCreateEntities(15);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    var13.setTickLabelsVisible(false);
    var13.setAxisLineVisible(true);
    java.awt.Paint var18 = var13.getAxisLinePaint();
    var13.configure();
    java.awt.Stroke var20 = var13.getTickMarkStroke();
    java.awt.Paint var21 = var13.getTickLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-131072), var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var3 = var2.getBaseSeriesVisibleInLegend();
//     int var4 = var2.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var6 = var5.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var8 = var5.lookupLegendTextPaint(15);
//     boolean var9 = var5.getBaseSeriesVisibleInLegend();
//     var5.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
//     var5.setBaseToolTipGenerator(var12, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var16 = var15.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var15.lookupLegendTextPaint(15);
//     boolean var19 = var15.getBaseSeriesVisibleInLegend();
//     var15.setBaseShapesVisible(false);
//     boolean var22 = var15.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var15.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var27 = var26.getTextAnchor();
//     var5.setBaseNegativeItemLabelPosition(var26);
//     var2.setBaseNegativeItemLabelPosition(var26);
//     var0.setBasePositiveItemLabelPosition(var26);
//     org.jfree.chart.text.TextAnchor var31 = var26.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var32 = var26.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var34 = var33.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var36 = var35.getBaseSeriesVisibleInLegend();
//     int var37 = var35.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var39 = var38.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var41 = var38.lookupLegendTextPaint(15);
//     boolean var42 = var38.getBaseSeriesVisibleInLegend();
//     var38.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var45 = null;
//     var38.setBaseToolTipGenerator(var45, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var49 = var48.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var51 = var48.lookupLegendTextPaint(15);
//     boolean var52 = var48.getBaseSeriesVisibleInLegend();
//     var48.setBaseShapesVisible(false);
//     boolean var55 = var48.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var59 = var48.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var60 = var59.getTextAnchor();
//     var38.setBaseNegativeItemLabelPosition(var59);
//     var35.setBaseNegativeItemLabelPosition(var59);
//     var33.setBasePositiveItemLabelPosition(var59);
//     org.jfree.chart.text.TextAnchor var64 = var59.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var65 = new org.jfree.chart.labels.ItemLabelPosition(var32, var64);
//     
//     // Checks the contract:  equals-hashcode on var26 and var59
//     assertTrue("Contract failed: equals-hashcode on var26 and var59", var26.equals(var59) ? var26.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var65
//     assertTrue("Contract failed: equals-hashcode on var26 and var65", var26.equals(var65) ? var26.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var26
//     assertTrue("Contract failed: equals-hashcode on var59 and var26", var59.equals(var26) ? var59.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var65
//     assertTrue("Contract failed: equals-hashcode on var59 and var65", var59.equals(var65) ? var59.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var26
//     assertTrue("Contract failed: equals-hashcode on var65 and var26", var65.equals(var26) ? var65.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var59
//     assertTrue("Contract failed: equals-hashcode on var65 and var59", var65.equals(var59) ? var65.hashCode() == var59.hashCode() : true);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
//     var0.setBaseToolTipGenerator(var7, false);
//     boolean var12 = var0.getItemVisible(4, 0);
//     boolean var13 = var0.getBaseCreateEntities();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.configureDomainAxes();
//     boolean var17 = var15.isOutlineVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var19 = var18.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var21 = var18.lookupLegendTextPaint(15);
//     boolean var22 = var18.getBaseSeriesVisibleInLegend();
//     var18.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var25 = null;
//     var18.setBaseToolTipGenerator(var25, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var28 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var18};
//     var15.setRenderers(var28);
//     java.awt.Stroke var30 = var15.getRangeZeroBaselineStroke();
//     var0.setSeriesStroke(1, var30, true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var0.", var18.equals(var0) == var0.equals(var18));
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setDrawBarOutline(false);
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var5.setDomainAxis(100, var8, false);
    org.jfree.chart.util.SortOrder var11 = var5.getColumnRenderingOrder();
    var5.setBackgroundAlpha((-1.0f));
    var5.setDomainCrosshairRowKey((java.lang.Comparable)"CategoryAnchor.MIDDLE", true);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var19 = var17.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var17.setDomainAxis(0, var21);
    boolean var23 = var17.isDomainZoomable();
    var17.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var26 = null;
    var17.markerChanged(var26);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var17.zoomDomainAxes(0.0d, var29, var30);
    org.jfree.data.category.DefaultCategoryDataset var32 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = var17.getRendererForDataset((org.jfree.data.category.CategoryDataset)var32);
    org.jfree.data.event.DatasetChangeListener var34 = null;
    var32.removeChangeListener(var34);
    int var37 = var32.getRowIndex((java.lang.Comparable)(byte)0);
    var32.clearSelection();
    int var39 = var32.getColumnCount();
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var41 = var0.initialise(var3, var4, var5, (org.jfree.data.category.CategoryDataset)var32, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var5 = var4.getBaseSeriesVisibleInLegend();
    java.awt.Paint var7 = var4.lookupLegendTextPaint(15);
    boolean var8 = var4.getBaseSeriesVisibleInLegend();
    var4.setBaseShapesVisible(false);
    java.awt.Shape var12 = var4.lookupLegendShape(100);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var14 = var13.getBaseSeriesVisibleInLegend();
    java.awt.Paint var16 = var13.lookupLegendTextPaint(15);
    boolean var17 = var13.getBaseSeriesVisibleInLegend();
    var13.setBaseLinesVisible(true);
    java.awt.Paint var23 = var13.getItemPaint(0, 101, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem(var0, "DatasetRenderingOrder.REVERSE", "CategoryAnchor.MIDDLE", "ChartEntity: tooltip = null", var12, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setDrawBarOutline(false);
//     org.jfree.chart.util.GradientPaintTransformer var3 = null;
//     var0.setGradientPaintTransformer(var3);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getNegativeItemLabelPositionFallback();
//     var0.setItemMargin((-1.0d));
//     boolean var9 = var0.isSeriesVisibleInLegend(10);
//     boolean var10 = var0.getShadowsVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Category Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    var0.setSeriesURLGenerator(15, var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = var0.getPlot();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(1, var2, true);
    var0.setForegroundAlpha(0.5f);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
//     boolean var11 = var0.isDomainCrosshairVisible();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.setDomainCrosshairVisible(true);
//     org.jfree.chart.event.AnnotationChangeEvent var15 = null;
//     var12.annotationChanged(var15);
//     org.jfree.chart.util.SortOrder var17 = var12.getColumnRenderingOrder();
//     var0.setColumnRenderingOrder(var17);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     var0.zoomRangeAxes(10.0d, var20, var21, true);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     org.jfree.chart.plot.PlotState var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     var0.draw(var24, var25, var26, var27, var28);
// 
//   }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = null;
//     var1.setSeriesShape(0, var4);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setTickLabelsVisible(false);
//     var6.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var6.getCategoryStart(10, (-1), var13, var14);
//     java.awt.Font var17 = var6.getTickLabelFont((java.lang.Comparable)'4');
//     var1.setDefaultLabelFont(var17);
//     java.awt.Shape var20 = null;
//     var1.setSeriesShape(0, var20);
//     java.awt.Paint var22 = var1.getDefaultOutlinePaint();
//     java.lang.Boolean var23 = var1.getDefaultCreateEntity();
//     java.awt.Stroke var25 = var1.getSeriesOutlineStroke(255);
// 
//   }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     var14.setDescription("");
//     var14.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
//     java.awt.Shape var19 = var14.getLine();
//     org.jfree.chart.util.GradientPaintTransformer var20 = var14.getFillPaintTransformer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var14.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var21);
//     java.awt.GradientPaint var23 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var25 = var24.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
//     boolean var28 = var24.getBaseSeriesVisibleInLegend();
//     var24.setBaseShapesVisible(false);
//     java.awt.Shape var32 = var24.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     var33.setDomainAxis(100, var36, false);
//     org.jfree.chart.util.SortOrder var39 = var33.getColumnRenderingOrder();
//     var33.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     var33.drawBackgroundImage(var42, var43);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var47 = var45.getDomainAxis(0);
//     java.awt.Stroke var48 = var45.getRangeCrosshairStroke();
//     var33.setDomainCrosshairStroke(var48);
//     var33.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var53 = new org.jfree.chart.entity.PlotEntity(var32, (org.jfree.chart.plot.Plot)var33, "DatasetRenderingOrder.REVERSE");
//     java.awt.GradientPaint var54 = var21.transform(var23, var32);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    var17.setDomainAxis(100, var20, false);
    java.util.List var23 = var17.getCategories();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var26 = var24.getDomainAxis(0);
    java.awt.Stroke var27 = var24.getRangeCrosshairStroke();
    java.awt.Stroke var28 = var24.getRangeZeroBaselineStroke();
    var17.setOutlineStroke(var28);
    org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var17);
    boolean var31 = var15.hasListener((java.util.EventListener)var17);
    java.lang.Comparable var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeValue(var32, (java.lang.Comparable)1L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var3 = var2.getBaseSeriesVisibleInLegend();
//     int var4 = var2.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var6 = var5.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var8 = var5.lookupLegendTextPaint(15);
//     boolean var9 = var5.getBaseSeriesVisibleInLegend();
//     var5.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
//     var5.setBaseToolTipGenerator(var12, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var16 = var15.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var15.lookupLegendTextPaint(15);
//     boolean var19 = var15.getBaseSeriesVisibleInLegend();
//     var15.setBaseShapesVisible(false);
//     boolean var22 = var15.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var15.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var27 = var26.getTextAnchor();
//     var5.setBaseNegativeItemLabelPosition(var26);
//     var2.setBaseNegativeItemLabelPosition(var26);
//     var0.setBasePositiveItemLabelPosition(var26);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var34 = var32.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var35 = null;
//     var32.setFixedDomainAxisSpace(var35, false);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var40 = var38.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis();
//     var38.setDomainAxis(0, var42);
//     var32.setParent((org.jfree.chart.plot.Plot)var38);
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
//     double var46 = var45.getLabelAngle();
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     double var54 = var45.getCategorySeriesMiddle(10, 1, 0, 10, 0.0d, var52, var53);
//     var45.setLabelAngle(100.0d);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var60 = var58.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis();
//     var58.setDomainAxis(0, var62);
//     boolean var64 = var58.isDomainZoomable();
//     var58.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot();
//     var67.configureDomainAxes();
//     java.awt.Paint var69 = var67.getDomainGridlinePaint();
//     var58.setRangeZeroBaselinePaint(var69);
//     org.jfree.chart.LegendItem var71 = new org.jfree.chart.LegendItem("", var69);
//     boolean var72 = var71.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var74 = new org.jfree.chart.axis.CategoryAxis();
//     var74.setTickLabelsVisible(false);
//     var74.setAxisLineVisible(true);
//     java.awt.Paint var79 = var74.getAxisLinePaint();
//     var73.setRangeCrosshairPaint(var79);
//     float var81 = var73.getBackgroundAlpha();
//     java.awt.Paint var82 = var73.getOutlinePaint();
//     var71.setLabelPaint(var82);
//     var45.setAxisLinePaint(var82);
//     var45.setCategoryLabelPositionOffset(0);
//     var45.setMinorTickMarksVisible(false);
//     org.jfree.chart.plot.CategoryMarker var89 = null;
//     java.awt.geom.Rectangle2D var90 = null;
//     var0.drawDomainMarker(var31, var32, var45, var89, var90);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    int var1 = var0.size();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var6 = var5.getBaseSeriesVisibleInLegend();
    int var7 = var5.getColumnCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    var8.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
    var8.setBaseToolTipGenerator(var15, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var19 = var18.getBaseSeriesVisibleInLegend();
    java.awt.Paint var21 = var18.lookupLegendTextPaint(15);
    boolean var22 = var18.getBaseSeriesVisibleInLegend();
    var18.setBaseShapesVisible(false);
    boolean var25 = var18.getBaseShapesFilled();
    org.jfree.chart.labels.ItemLabelPosition var29 = var18.getPositiveItemLabelPosition((-1), 1, true);
    org.jfree.chart.text.TextAnchor var30 = var29.getTextAnchor();
    var8.setBaseNegativeItemLabelPosition(var29);
    var5.setBaseNegativeItemLabelPosition(var29);
    var3.setBasePositiveItemLabelPosition(var29);
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
    var35.setTickLabelsVisible(false);
    var35.setMaximumCategoryLabelLines((-1));
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.util.RectangleEdge var43 = null;
    double var44 = var35.getCategoryStart(10, (-1), var42, var43);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
    var45.configureDomainAxes();
    org.jfree.chart.util.SortOrder var47 = var45.getColumnRenderingOrder();
    var35.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var45);
    java.awt.Paint var49 = var45.getRangeCrosshairPaint();
    var3.setSeriesOutlinePaint(10, var49);
    java.awt.Paint var52 = var3.lookupSeriesPaint(4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-1), var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    int var3 = var0.getColumnIndex((java.lang.Comparable)(-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject((java.lang.Comparable)(-0.7853981633974483d), (java.lang.Comparable)"DatasetRenderingOrder.REVERSE");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var3 = var1.equals((java.lang.Object)var2);
//     java.lang.String var4 = var2.getLabelURL();
//     org.jfree.chart.renderer.RenderAttributes var6 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var7 = var6.getDefaultLabelFont();
//     java.awt.Paint var8 = var6.getDefaultPaint();
//     var2.setLabelPaint(var8);
//     java.awt.Font var10 = var2.getLabelFont();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var14.setDomainAxis(100, var17, false);
//     java.util.List var20 = var14.getCategories();
//     org.jfree.chart.util.RectangleEdge var21 = var14.getDomainAxisEdge();
//     double var22 = var2.getCategoryMiddle(0, 5, var13, var21);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setTickLabelsVisible(false);
    java.awt.Font var3 = var0.getLabelFont();
    var0.setLabelToolTip("hi!");
    java.awt.Paint var7 = null;
    var0.setTickLabelPaint((java.lang.Comparable)8.0d, var7);
    org.jfree.chart.axis.CategoryLabelPositions var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCategoryLabelPositions(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    var0.setSeriesItemLabelsVisible(15, (java.lang.Boolean)false);
    var0.setItemLabelAnchorOffset(2.0d);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.CategoryItemLabelGenerator var16 = var0.getItemLabelGenerator(255, 0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    var0.setSeriesShapesFilled(15, (java.lang.Boolean)false);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var0.setBaseURLGenerator(var10);
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     int var12 = var0.getIndexOf(var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.configureDomainAxes();
//     java.awt.Paint var15 = var13.getDomainGridlinePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var13.zoomRangeAxes(10.0d, var17, var18, false);
//     org.jfree.chart.plot.DrawingSupplier var21 = var13.getDrawingSupplier();
//     var0.setDrawingSupplier(var21);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.configureDomainAxes();
//     java.awt.Paint var26 = var24.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleInsets var27 = var24.getInsets();
//     var24.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     var30.setDomainAxis(100, var33, false);
//     org.jfree.chart.util.SortOrder var36 = var30.getColumnRenderingOrder();
//     java.awt.Paint var37 = var30.getRangeMinorGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var40 = var38.getDomainAxis(0);
//     java.awt.Stroke var41 = var38.getRangeCrosshairStroke();
//     java.awt.Stroke var42 = var38.getRangeZeroBaselineStroke();
//     var30.setRangeMinorGridlineStroke(var42);
//     org.jfree.chart.axis.AxisLocation var45 = var30.getDomainAxisLocation(15);
//     org.jfree.chart.axis.AxisLocation var46 = var45.getOpposite();
//     org.jfree.chart.axis.AxisLocation var47 = org.jfree.chart.axis.AxisLocation.getOpposite(var46);
//     var24.setDomainAxisLocation(var47, false);
//     var0.setDomainAxisLocation(0, var47, false);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     var0.setRangeAxis(1, var2, true);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setTickLabelsVisible(false);
//     var5.setMaximumCategoryLabelLines((-1));
//     var5.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.configureDomainAxes();
//     java.awt.Paint var14 = var12.getDomainGridlinePaint();
//     java.lang.Object var15 = var12.clone();
//     var5.addChangeListener((org.jfree.chart.event.AxisChangeListener)var12);
//     var5.setLabel("CategoryAnchor.MIDDLE");
//     java.awt.Color var21 = java.awt.Color.getColor("hi!", 100);
//     int var22 = var21.getRGB();
//     java.awt.Color var23 = var21.darker();
//     var5.setAxisLinePaint((java.awt.Paint)var23);
//     boolean var25 = var0.equals((java.lang.Object)var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
//     var0.setBaseToolTipGenerator(var7, false);
//     java.awt.Paint var10 = var0.getBaseFillPaint();
//     org.jfree.chart.renderer.RenderAttributes var11 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var12 = var11.getDefaultPaint();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.configureDomainAxes();
//     java.awt.Paint var15 = var13.getDomainGridlinePaint();
//     var11.setDefaultPaint(var15);
//     var0.setBaseFillPaint(var15);
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
//     var19.setTickLabelsVisible(false);
//     var19.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var19.getCategoryStart(10, (-1), var26, var27);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var31 = var29.getColumnRenderingOrder();
//     var19.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var29);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     var33.setTickLabelsVisible(false);
//     java.awt.Font var36 = var33.getLabelFont();
//     var19.setLabelFont(var36);
//     var0.setSeriesItemLabelFont(0, var36);
//     
//     // Checks the contract:  equals-hashcode on var13 and var29
//     assertTrue("Contract failed: equals-hashcode on var13 and var29", var13.equals(var29) ? var13.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var13
//     assertTrue("Contract failed: equals-hashcode on var29 and var13", var29.equals(var13) ? var29.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var2.getCategorySeriesMiddle((-1), 10, 0, 1, 10.0d, var9, var10);
    boolean var12 = var2.isVisible();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
    var13.setDomainAxis(100, var16, false);
    org.jfree.chart.util.SortOrder var19 = var13.getColumnRenderingOrder();
    java.awt.Paint var20 = var13.getRangeMinorGridlinePaint();
    int var21 = var13.getRendererCount();
    org.jfree.chart.axis.CategoryAnchor var22 = var13.getDomainGridlinePosition();
    java.lang.String var23 = var22.toString();
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
    var27.setDomainAxis(100, var30, false);
    java.util.List var33 = var27.getCategories();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var36 = var34.getDomainAxis(0);
    java.awt.Stroke var37 = var34.getRangeCrosshairStroke();
    java.awt.Stroke var38 = var34.getRangeZeroBaselineStroke();
    var27.setOutlineStroke(var38);
    org.jfree.chart.util.RectangleEdge var40 = var27.getRangeAxisEdge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var41 = var2.getCategoryJava2DCoordinate(var22, (-33), 4, var26, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "CategoryAnchor.MIDDLE"+ "'", var23.equals("CategoryAnchor.MIDDLE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     java.awt.Paint var4 = var2.getDomainGridlinePaint();
//     var1.setDefaultOutlinePaint(var4);
//     java.awt.Paint var6 = var1.getDefaultLabelPaint();
//     var1.setDefaultCreateEntity((java.lang.Boolean)false);
//     java.awt.Paint var11 = var1.getItemLabelPaint((-16777116), (-100));
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var1 = var0.calculateOffsetX();
//     float var2 = var0.getShadowOpacity();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var4.setDomainAxis(0, var8);
//     boolean var10 = var4.isDomainZoomable();
//     var4.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.configureDomainAxes();
//     java.awt.Paint var15 = var13.getDomainGridlinePaint();
//     var4.setRangeZeroBaselinePaint(var15);
//     org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("", var15);
//     boolean var18 = var17.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     var20.setTickLabelsVisible(false);
//     var20.setAxisLineVisible(true);
//     java.awt.Paint var25 = var20.getAxisLinePaint();
//     var19.setRangeCrosshairPaint(var25);
//     float var27 = var19.getBackgroundAlpha();
//     java.awt.Paint var28 = var19.getOutlinePaint();
//     var17.setLabelPaint(var28);
//     var17.setToolTipText("hi!");
//     boolean var32 = var0.equals((java.lang.Object)var17);
//     java.awt.image.BufferedImage var33 = null;
//     java.awt.image.BufferedImage var34 = var0.createDropShadow(var33);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setTickLabelsVisible(false);
//     var1.setAxisLineVisible(true);
//     java.awt.Paint var6 = var1.getAxisLinePaint();
//     var0.setRangeCrosshairPaint(var6);
//     float var8 = var0.getBackgroundAlpha();
//     java.awt.Paint var9 = var0.getOutlinePaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var11 = var10.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var13 = var10.lookupLegendTextPaint(15);
//     boolean var14 = var10.getBaseSeriesVisibleInLegend();
//     var10.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
//     var10.setBaseToolTipGenerator(var17, false);
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var23 = var21.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var21.getCategoryEnd((-1), (-1), var26, var27);
//     float var29 = var21.getTickMarkInsideLength();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
//     var31.setTickLabelsVisible(false);
//     var31.setAxisLineVisible(true);
//     java.awt.Paint var36 = var31.getAxisLinePaint();
//     var30.setRangeCrosshairPaint(var36);
//     org.jfree.chart.JFreeChart var38 = null;
//     org.jfree.chart.event.ChartChangeEventType var39 = null;
//     org.jfree.chart.event.ChartChangeEvent var40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var36, var38, var39);
//     var21.setAxisLinePaint(var36);
//     java.awt.Font var42 = var21.getLabelFont();
//     var10.setSeriesItemLabelFont(0, var42);
//     boolean var47 = var10.isItemLabelVisible(4, 1, false);
//     int var48 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var30
//     assertTrue("Contract failed: equals-hashcode on var0 and var30", var0.equals(var30) ? var0.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var0
//     assertTrue("Contract failed: equals-hashcode on var30 and var0", var30.equals(var0) ? var30.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var1 = var0.getDefaultPaint();
//     java.awt.Paint var2 = var0.getDefaultLabelPaint();
//     java.awt.Font var4 = var0.getSeriesLabelFont(15);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     var0.setDefaultLabelVisible((java.lang.Boolean)true);
//     java.awt.Font var4 = var0.getSeriesLabelFont(100);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    var0.setRangeMinorGridlinesVisible(false);
    var0.setBackgroundImageAlignment(0);
    org.jfree.chart.plot.CategoryMarker var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(0, var6);
    boolean var8 = var2.isDomainZoomable();
    var2.setDomainCrosshairVisible(false);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected((-16777116), (-100), false, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.util.ShapeList var4 = new org.jfree.chart.util.ShapeList();
//     java.awt.Shape var6 = null;
//     var4.setShape(4, var6);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     var10.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.configureDomainAxes();
//     java.awt.Paint var21 = var19.getDomainGridlinePaint();
//     var10.setRangeZeroBaselinePaint(var21);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", var21);
//     boolean var24 = var23.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     var26.setTickLabelsVisible(false);
//     var26.setAxisLineVisible(true);
//     java.awt.Paint var31 = var26.getAxisLinePaint();
//     var25.setRangeCrosshairPaint(var31);
//     float var33 = var25.getBackgroundAlpha();
//     java.awt.Paint var34 = var25.getOutlinePaint();
//     var23.setLabelPaint(var34);
//     var23.setSeriesIndex(0);
//     var23.setDescription("CategoryAnchor.MIDDLE");
//     var23.setLineVisible(false);
//     java.awt.Shape var42 = var23.getShape();
//     var4.setShape(15, var42);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
//     var45.setTickLabelsVisible(false);
//     var45.setAxisLineVisible(true);
//     java.awt.Paint var50 = var45.getAxisLinePaint();
//     var44.setRangeCrosshairPaint(var50);
//     float var52 = var44.getBackgroundAlpha();
//     java.awt.Paint var53 = var44.getOutlinePaint();
//     java.awt.Font var54 = var44.getNoDataMessageFont();
//     java.awt.Paint var55 = var44.getDomainGridlinePaint();
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE", "AxisLocation.TOP_OR_LEFT", "TextAnchor.BOTTOM_CENTER", "DatasetRenderingOrder.REVERSE", var42, var55);
//     
//     // Checks the contract:  equals-hashcode on var25 and var44
//     assertTrue("Contract failed: equals-hashcode on var25 and var44", var25.equals(var44) ? var25.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var25
//     assertTrue("Contract failed: equals-hashcode on var44 and var25", var44.equals(var25) ? var44.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.configureDomainAxes();
    java.awt.Paint var10 = var8.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var8.zoomRangeAxes(10.0d, var12, var13, false);
    org.jfree.chart.plot.DrawingSupplier var16 = var8.getDrawingSupplier();
    var7.setDrawingSupplier(var16, true);
    org.jfree.chart.plot.DrawingSupplier var19 = var7.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var2 = var0.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.Paint var3 = var0.getAxisLinePaint();
    boolean var4 = var0.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    boolean var11 = var0.isSubplot();
    java.awt.Paint var12 = var0.getBackgroundPaint();
    org.jfree.chart.event.RendererChangeEvent var13 = null;
    var0.rendererChanged(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var1.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var7 = var1.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var8 = null;
    boolean var9 = var1.removeAnnotation(var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var13 = var11.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    var11.setDomainAxis(0, var15);
    boolean var17 = var11.isDomainZoomable();
    org.jfree.chart.plot.Marker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    boolean var22 = var11.removeDomainMarker(10, var19, var20, false);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = var11.getRendererForDataset(var23);
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.plot.Marker var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    var1.drawRangeMarker(var10, var11, var25, var26, var27);
    java.lang.Boolean var30 = null;
    var1.setSeriesVisible(10, var30, true);
    boolean var33 = var1.getBaseSeriesVisibleInLegend();
    boolean var36 = var1.getItemShapeFilled(1, 100);
    boolean var37 = var1.getBaseLinesVisible();
    org.jfree.chart.labels.CategoryItemLabelGenerator var38 = null;
    var1.setBaseItemLabelGenerator(var38);
    boolean var41 = var1.isSeriesItemLabelsVisible(0);
    boolean var42 = var0.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(10.0d, var4, var5, false);
    org.jfree.chart.plot.DrawingSupplier var8 = var0.getDrawingSupplier();
    var0.setRangeCrosshairVisible(false);
    var0.setRangeCrosshairVisible(false);
    boolean var13 = var0.isRangePannable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     boolean var15 = var14.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setTickLabelsVisible(false);
//     var17.setAxisLineVisible(true);
//     java.awt.Paint var22 = var17.getAxisLinePaint();
//     var16.setRangeCrosshairPaint(var22);
//     float var24 = var16.getBackgroundAlpha();
//     java.awt.Paint var25 = var16.getOutlinePaint();
//     var14.setLabelPaint(var25);
//     var14.setSeriesIndex(0);
//     var14.setDescription("CategoryAnchor.MIDDLE");
//     java.awt.Paint var31 = var14.getOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setDomainAxis(100, var35, false);
//     org.jfree.chart.util.SortOrder var38 = var32.getColumnRenderingOrder();
//     var32.clearRangeAxes();
//     var32.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var43 = var42.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var45 = var42.lookupLegendTextPaint(15);
//     boolean var46 = var42.getBaseSeriesVisibleInLegend();
//     var42.setBaseShapesVisible(false);
//     boolean var49 = var42.getBaseShapesFilled();
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var53 = var51.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis();
//     var51.setDomainAxis(0, var55);
//     boolean var57 = var51.isDomainZoomable();
//     var51.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     var60.configureDomainAxes();
//     java.awt.Paint var62 = var60.getDomainGridlinePaint();
//     var51.setRangeZeroBaselinePaint(var62);
//     org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("", var62);
//     boolean var65 = var64.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis();
//     var67.setTickLabelsVisible(false);
//     var67.setAxisLineVisible(true);
//     java.awt.Paint var72 = var67.getAxisLinePaint();
//     var66.setRangeCrosshairPaint(var72);
//     float var74 = var66.getBackgroundAlpha();
//     java.awt.Paint var75 = var66.getOutlinePaint();
//     var64.setLabelPaint(var75);
//     var42.setBaseLegendTextPaint(var75);
//     var32.setRangeGridlinePaint(var75);
//     var14.setOutlinePaint(var75);
//     
//     // Checks the contract:  equals-hashcode on var1 and var51
//     assertTrue("Contract failed: equals-hashcode on var1 and var51", var1.equals(var51) ? var1.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var60
//     assertTrue("Contract failed: equals-hashcode on var10 and var60", var10.equals(var60) ? var10.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var66
//     assertTrue("Contract failed: equals-hashcode on var16 and var66", var16.equals(var66) ? var16.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var1
//     assertTrue("Contract failed: equals-hashcode on var51 and var1", var51.equals(var1) ? var51.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var10
//     assertTrue("Contract failed: equals-hashcode on var60 and var10", var60.equals(var10) ? var60.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var16
//     assertTrue("Contract failed: equals-hashcode on var66 and var16", var66.equals(var16) ? var66.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    java.util.List var6 = var0.getCategories();
    boolean var7 = var0.isDomainGridlinesVisible();
    var0.setAnchorValue(0.0d);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = var0.getRenderer();
    var0.clearRangeMarkers();
    var0.setDomainCrosshairRowKey((java.lang.Comparable)(short)100, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    boolean var11 = var0.isSubplot();
    java.awt.Paint var12 = var0.getBackgroundPaint();
    java.awt.Font var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessageFont(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.configureDomainAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var3 = var1.getDatasetRenderingOrder();
//     var0.addObject((java.lang.Object)var1, (java.lang.Comparable)10L, (java.lang.Comparable)"Category Plot");
//     org.jfree.chart.axis.CategoryAnchor var7 = var1.getDomainGridlinePosition();
//     org.jfree.chart.plot.Marker var9 = null;
//     org.jfree.chart.util.Layer var10 = null;
//     var1.addRangeMarker(0, var9, var10);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    boolean var6 = var0.isSeriesVisibleInLegend(1);
    java.awt.Shape var10 = var0.getItemShape(10, (-100), false);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.configureDomainAxes();
    java.awt.Paint var13 = var11.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var14 = var11.getInsets();
    var11.setAnchorValue(0.0d);
    var11.setCrosshairDatasetIndex((-1));
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    var19.setTickLabelsVisible(false);
    var19.setMaximumCategoryLabelLines((-1));
    var19.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.configureDomainAxes();
    java.awt.Paint var28 = var26.getDomainGridlinePaint();
    java.lang.Object var29 = var26.clone();
    var19.addChangeListener((org.jfree.chart.event.AxisChangeListener)var26);
    var11.setParent((org.jfree.chart.plot.Plot)var26);
    org.jfree.chart.entity.PlotEntity var32 = new org.jfree.chart.entity.PlotEntity(var10, (org.jfree.chart.plot.Plot)var26);
    var32.setToolTipText("PlotOrientation.VERTICAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Shape var4 = var1.getSeriesShape(4);
//     var1.setSeriesCreateEntity(15, (java.lang.Boolean)false);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.data.event.DatasetChangeListener var17 = null;
    var15.removeChangeListener(var17);
    int var20 = var15.getRowIndex((java.lang.Comparable)(byte)0);
    var15.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.removeRow((java.lang.Comparable)(short)100);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    var0.setBackgroundAlpha((-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryAxis var10 = var0.getDomainAxisForDataset((-33));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     var0.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawBackgroundImage(var9, var10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var12.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var18 = var12.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var19 = null;
//     boolean var20 = var12.removeAnnotation(var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var24 = var22.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     var22.setDomainAxis(0, var26);
//     boolean var28 = var22.isDomainZoomable();
//     org.jfree.chart.plot.Marker var30 = null;
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var33 = var22.removeDomainMarker(10, var30, var31, false);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var22.getRendererForDataset(var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.plot.Marker var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     var12.drawRangeMarker(var21, var22, var36, var37, var38);
//     java.lang.Boolean var41 = null;
//     var12.setSeriesVisible(10, var41, true);
//     boolean var44 = var12.getBaseSeriesVisibleInLegend();
//     boolean var47 = var12.getItemShapeFilled(1, 100);
//     boolean var48 = var12.getBaseLinesVisible();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var49 = null;
//     var12.setBaseItemLabelGenerator(var49);
//     java.awt.Stroke var52 = var12.lookupSeriesOutlineStroke(10);
//     var0.setRangeZeroBaselineStroke(var52);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.configureDomainAxes();
//     java.awt.Stroke var56 = var54.getRangeGridlineStroke();
//     var0.setRangeCrosshairStroke(var56);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var60 = var58.getDomainAxis(0);
//     java.awt.Stroke var61 = var58.getRangeCrosshairStroke();
//     var0.setDomainGridlineStroke(var61);
//     
//     // Checks the contract:  equals-hashcode on var54 and var58
//     assertTrue("Contract failed: equals-hashcode on var54 and var58", var54.equals(var58) ? var54.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var54
//     assertTrue("Contract failed: equals-hashcode on var58 and var54", var58.equals(var54) ? var58.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.plot.DefaultDrawingSupplier var2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Shape var3 = var2.getNextShape();
    java.awt.Shape var4 = var2.getNextShape();
    var0.setShape(2, var4);
    var0.clear();
    java.awt.Shape var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-16777116), var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Stroke var2 = var0.getRangeGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-131072), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Stroke var1 = var0.getDefaultOutlineStroke();
//     java.lang.Boolean var2 = var0.getDefaultLabelVisible();
//     java.lang.Boolean var4 = var0.getSeriesLabelVisible((-2));
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    java.util.List var6 = var0.getCategories();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis(0);
    java.awt.Stroke var10 = var7.getRangeCrosshairStroke();
    java.awt.Stroke var11 = var7.getRangeZeroBaselineStroke();
    var0.setOutlineStroke(var11);
    java.awt.Paint var13 = var0.getRangeGridlinePaint();
    var0.setAnchorValue(0.0d, true);
    org.jfree.chart.axis.AxisSpace var17 = null;
    var0.setFixedDomainAxisSpace(var17, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    boolean var5 = var3.equals((java.lang.Object)var4);
    boolean var6 = var4.isAxisLineVisible();
    var0.setObject((java.lang.Object)var4, (java.lang.Comparable)10.0f, (java.lang.Comparable)4);
    java.lang.Object var12 = var0.getObject(0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var14 = var0.getRowKey((-33));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Stroke var1 = var0.getDefaultOutlineStroke();
//     java.awt.Font var2 = var0.getDefaultLabelFont();
//     java.awt.Font var4 = null;
//     var0.setSeriesLabelFont(2, var4);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var3.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var3.getBasePositiveItemLabelPosition();
//     var0.setSeriesNegativeItemLabelPosition(100, var8, true);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setTickLabelsVisible(false);
//     var12.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var12.getCategoryStart(10, (-1), var19, var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var24 = var22.getColumnRenderingOrder();
//     var12.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     java.awt.Paint var26 = var22.getRangeCrosshairPaint();
//     var11.setRangeGridlinePaint(var26);
//     boolean var28 = var0.hasListener((java.util.EventListener)var11);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var31 = var30.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var33 = var30.lookupLegendTextPaint(15);
//     boolean var34 = var30.getBaseSeriesVisibleInLegend();
//     var30.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
//     var30.setBaseToolTipGenerator(var37, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var41 = var40.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var43 = var40.lookupLegendTextPaint(15);
//     boolean var44 = var40.getBaseSeriesVisibleInLegend();
//     var40.setBaseShapesVisible(false);
//     boolean var47 = var40.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var51 = var40.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var52 = var51.getTextAnchor();
//     var30.setBaseNegativeItemLabelPosition(var51);
//     var0.setSeriesNegativeItemLabelPosition(0, var51, false);
//     
//     // Checks the contract:  equals-hashcode on var8 and var51
//     assertTrue("Contract failed: equals-hashcode on var8 and var51", var8.equals(var51) ? var8.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var8
//     assertTrue("Contract failed: equals-hashcode on var51 and var8", var51.equals(var8) ? var51.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var7 = null;
//     boolean var8 = var0.removeAnnotation(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.Marker var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var0.drawRangeMarker(var9, var10, var24, var25, var26);
//     java.lang.Boolean var29 = null;
//     var0.setSeriesVisible(10, var29, true);
//     boolean var32 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.urls.CategoryURLGenerator var34 = null;
//     var0.setSeriesURLGenerator(15, var34, false);
//     org.jfree.chart.plot.CategoryPlot var37 = var0.getPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var39 = var38.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var41 = var38.lookupLegendTextPaint(15);
//     boolean var42 = var38.getBaseSeriesVisibleInLegend();
//     var38.setBaseLinesVisible(true);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.data.Range var46 = var38.findRangeBounds(var45);
//     org.jfree.chart.labels.CategoryToolTipGenerator var48 = var38.getSeriesToolTipGenerator(0);
//     var38.setAutoPopulateSeriesOutlineStroke(true);
//     var38.setDefaultEntityRadius(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var55 = var54.getBaseSeriesVisibleInLegend();
//     int var56 = var54.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var58 = var57.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var60 = var57.lookupLegendTextPaint(15);
//     boolean var61 = var57.getBaseSeriesVisibleInLegend();
//     var57.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var64 = null;
//     var57.setBaseToolTipGenerator(var64, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var68 = var67.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var70 = var67.lookupLegendTextPaint(15);
//     boolean var71 = var67.getBaseSeriesVisibleInLegend();
//     var67.setBaseShapesVisible(false);
//     boolean var74 = var67.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var78 = var67.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var79 = var78.getTextAnchor();
//     var57.setBaseNegativeItemLabelPosition(var78);
//     var54.setBaseNegativeItemLabelPosition(var78);
//     var38.setSeriesPositiveItemLabelPosition(100, var78, false);
//     org.jfree.chart.text.TextAnchor var84 = var78.getTextAnchor();
//     var0.setBaseNegativeItemLabelPosition(var78);
//     
//     // Checks the contract:  equals-hashcode on var54 and var0
//     assertTrue("Contract failed: equals-hashcode on var54 and var0", var54.equals(var0) ? var54.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var0
//     assertTrue("Contract failed: equals-hashcode on var57 and var0", var57.equals(var0) ? var57.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var54 and var0.", var54.equals(var0) == var0.equals(var54));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var57 and var0.", var57.equals(var0) == var0.equals(var57));
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.data.Range var8 = var0.findRangeBounds(var7);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getSeriesToolTipGenerator(0);
    boolean var11 = var0.getAutoPopulateSeriesOutlinePaint();
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    var14.setDomainAxis(0, var18);
    boolean var20 = var14.isDomainZoomable();
    org.jfree.chart.plot.Plot var21 = var14.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var14);
    org.jfree.chart.axis.ValueAxis var24 = var14.getRangeAxis(0);
    boolean var25 = var14.isSubplot();
    java.awt.Paint var26 = var14.getBackgroundPaint();
    var14.setOutlineVisible(true);
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
    var29.setTickLabelsVisible(false);
    var29.setMaximumCategoryLabelLines((-1));
    var29.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    var36.configureDomainAxes();
    java.awt.Paint var38 = var36.getDomainGridlinePaint();
    java.lang.Object var39 = var36.clone();
    var29.addChangeListener((org.jfree.chart.event.AxisChangeListener)var36);
    var29.setLabel("CategoryAnchor.MIDDLE");
    java.lang.Object var43 = null;
    boolean var44 = var29.equals(var43);
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.data.category.DefaultCategoryDataset var46 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
    var47.configureDomainAxes();
    java.awt.Paint var49 = var47.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var50 = var47.getInsets();
    var46.addChangeListener((org.jfree.data.event.DatasetChangeListener)var47);
    org.jfree.chart.renderer.category.CategoryItemRendererState var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var56 = var0.createHotSpotShape(var12, var13, var14, var29, var45, (org.jfree.data.category.CategoryDataset)var46, 5, 4, false, var55);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
//     var6.setInsets(var13);
//     var6.setRangePannable(true);
//     org.jfree.chart.axis.CategoryAxis var18 = var6.getDomainAxisForDataset(0);
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
//     var19.setTickLabelsVisible(false);
//     var19.setMaximumCategoryLabelLines((-1));
//     var19.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.configureDomainAxes();
//     java.awt.Paint var28 = var26.getDomainGridlinePaint();
//     java.lang.Object var29 = var26.clone();
//     var19.addChangeListener((org.jfree.chart.event.AxisChangeListener)var26);
//     var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var26);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var7 = new org.jfree.chart.labels.ItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-1), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Stroke var2 = var0.getRangeGridlineStroke();
    org.jfree.chart.util.SortOrder var3 = var0.getColumnRenderingOrder();
    var0.setForegroundAlpha(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    boolean var35 = var0.getItemShapeFilled(1, 100);
    boolean var36 = var0.getBaseLinesVisible();
    java.awt.Stroke var40 = var0.getItemStroke(4, 4, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var42 = var41.getBaseSeriesVisibleInLegend();
    java.awt.Paint var44 = var41.lookupLegendTextPaint(15);
    boolean var45 = var41.getBaseSeriesVisibleInLegend();
    var41.setBaseShapesVisible(false);
    java.awt.Shape var49 = var41.lookupLegendShape(100);
    org.jfree.chart.entity.ChartEntity var50 = new org.jfree.chart.entity.ChartEntity(var49);
    var0.setBaseShape(var49);
    java.awt.Shape var53 = var0.getLegendShape((-1));
    var0.setUseSeriesOffset(true);
    var0.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    java.awt.Stroke var5 = var0.getSeriesStroke(15);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    java.lang.Boolean var9 = var0.getSeriesCreateEntities((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setTickLabelsVisible(false);
//     var0.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var0.getCategoryStart(10, (-1), var7, var8);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var12 = var10.getColumnRenderingOrder();
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var10);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.configureDomainAxes();
//     java.awt.Paint var16 = var14.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleInsets var17 = var14.getInsets();
//     var14.setRangeMinorGridlinesVisible(false);
//     boolean var20 = var0.hasListener((java.util.EventListener)var14);
//     
//     // Checks the contract:  equals-hashcode on var10 and var14
//     assertTrue("Contract failed: equals-hashcode on var10 and var14", var10.equals(var14) ? var10.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var10
//     assertTrue("Contract failed: equals-hashcode on var14 and var10", var14.equals(var10) ? var14.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     var14.setDescription("");
//     var14.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
//     java.awt.Shape var19 = var14.getLine();
//     org.jfree.chart.util.GradientPaintTransformer var20 = var14.getFillPaintTransformer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var14.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var21);
//     org.jfree.chart.util.GradientPaintTransformType var23 = var21.getType();
//     java.awt.Shape var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     var30.setTickLabelsVisible(false);
//     var30.setAxisLineVisible(true);
//     java.awt.Paint var35 = var30.getAxisLinePaint();
//     var29.setRangeCrosshairPaint(var35);
//     float var37 = var29.getBackgroundAlpha();
//     java.awt.Paint var38 = var29.getOutlinePaint();
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", var28, var38);
//     java.awt.Paint var40 = var39.getLinePaint();
//     boolean var41 = var23.equals((java.lang.Object)var40);
//     org.jfree.chart.util.StandardGradientPaintTransformer var42 = new org.jfree.chart.util.StandardGradientPaintTransformer(var23);
//     java.awt.GradientPaint var43 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var45 = var44.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var47 = var44.lookupLegendTextPaint(15);
//     boolean var48 = var44.getBaseSeriesVisibleInLegend();
//     var44.setBaseShapesVisible(false);
//     java.awt.Shape var52 = var44.lookupLegendShape(100);
//     org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity(var52);
//     java.awt.GradientPaint var54 = var42.transform(var43, var52);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseShapesVisible(false);
    var2.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var13 = var2.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
    var14.setDomainCrosshairVisible(true);
    var14.setBackgroundImageAlpha(0.0f);
    boolean var22 = var2.equals((java.lang.Object)var14);
    boolean var23 = var0.equals((java.lang.Object)var2);
    boolean var25 = var2.equals((java.lang.Object)100.0d);
    var2.clear();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.Color var32 = var31.brighter();
    java.awt.Color var33 = java.awt.Color.getColor("", var32);
    java.awt.Color var34 = var33.darker();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", (java.awt.Paint)var34);
    boolean var36 = var2.equals((java.lang.Object)var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var39 = var2.getObject((java.lang.Comparable)'#', (java.lang.Comparable)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var2 = var1.getBaseSeriesVisibleInLegend();
    java.awt.Paint var4 = var1.lookupLegendTextPaint(15);
    boolean var5 = var1.getBaseSeriesVisibleInLegend();
    var1.setBaseShapesVisible(false);
    var0.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var6.setFixedDomainAxisSpace(var9, false);
    var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
    var6.setDomainCrosshairColumnKey((java.lang.Comparable)0L, true);
    var6.setOutlineVisible(false);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.configureDomainAxes();
    java.awt.Paint var20 = var18.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var21 = var18.getInsets();
    double var23 = var21.calculateLeftOutset(4.0d);
    double var25 = var21.calculateRightInset((-1.0d));
    var6.setInsets(var21, true);
    double var29 = var21.trimHeight(0.2d);
    double var31 = var21.extendHeight(6.05d);
    java.awt.geom.Rectangle2D var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var33 = var21.createOutsetRectangle(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-7.8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 14.05d);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
//     int var8 = var0.getCrosshairDatasetIndex();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var11 = var9.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(0, var13);
//     boolean var15 = var9.isDomainZoomable();
//     org.jfree.chart.plot.Plot var16 = var9.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.axis.ValueAxis var19 = var9.getRangeAxis(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     int var21 = var9.getIndexOf(var20);
//     org.jfree.chart.LegendItemCollection var22 = var9.getLegendItems();
//     var0.setFixedLegendItems(var22);
//     
//     // Checks the contract:  equals-hashcode on var7 and var22
//     assertTrue("Contract failed: equals-hashcode on var7 and var22", var7.equals(var22) ? var7.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var7
//     assertTrue("Contract failed: equals-hashcode on var22 and var7", var22.equals(var7) ? var22.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var2 = var1.getBaseSeriesVisibleInLegend();
    java.awt.Paint var4 = var1.lookupLegendTextPaint(15);
    boolean var5 = var1.getBaseSeriesVisibleInLegend();
    var1.setBaseShapesVisible(false);
    var0.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var13 = var0.getObject((-1), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     java.awt.Paint var4 = var2.getDomainGridlinePaint();
//     var1.setDefaultOutlinePaint(var4);
//     java.awt.Paint var6 = var1.getDefaultLabelPaint();
//     java.awt.Font var8 = var1.getSeriesLabelFont((-16777116));
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var11 = var10.getBaseSeriesVisibleInLegend();
    java.awt.Paint var13 = var10.lookupLegendTextPaint(15);
    boolean var14 = var10.getBaseSeriesVisibleInLegend();
    var10.setBaseShapesVisible(false);
    boolean var17 = var10.getBaseShapesFilled();
    org.jfree.chart.labels.ItemLabelPosition var21 = var10.getPositiveItemLabelPosition((-1), 1, true);
    org.jfree.chart.text.TextAnchor var22 = var21.getTextAnchor();
    var0.setBaseNegativeItemLabelPosition(var21);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var27 = var0.getSeriesItemLabelGenerator((-16777116));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
//     java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis(0);
//     java.awt.Stroke var11 = var8.getRangeCrosshairStroke();
//     java.awt.Stroke var12 = var8.getRangeZeroBaselineStroke();
//     var0.setRangeMinorGridlineStroke(var12);
//     org.jfree.chart.axis.AxisLocation var15 = var0.getDomainAxisLocation(15);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     var16.setDomainAxis(0, var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var24 = var22.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var22.setFixedDomainAxisSpace(var25, false);
//     var20.addChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     var22.setDomainCrosshairColumnKey((java.lang.Comparable)0L, true);
//     var22.setOutlineVisible(false);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.configureDomainAxes();
//     java.awt.Paint var36 = var34.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleInsets var37 = var34.getInsets();
//     double var39 = var37.calculateLeftOutset(4.0d);
//     double var41 = var37.calculateRightInset((-1.0d));
//     var22.setInsets(var37, true);
//     boolean var44 = var15.equals((java.lang.Object)true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var34
//     assertTrue("Contract failed: equals-hashcode on var8 and var34", var8.equals(var34) ? var8.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var8
//     assertTrue("Contract failed: equals-hashcode on var34 and var8", var34.equals(var8) ? var34.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(0, var4);
//     boolean var6 = var0.isDomainZoomable();
//     org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
//     org.jfree.data.category.CategoryDataset var8 = null;
//     int var9 = var0.indexOf(var8);
//     org.jfree.chart.axis.CategoryAnchor var10 = var0.getDomainGridlinePosition();
//     var0.zoom(6.0d);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setDrawBarOutline(false);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getPositiveItemLabelPositionFallback();
    boolean var4 = var0.getBaseSeriesVisible();
    org.jfree.chart.renderer.category.BarPainter var5 = var0.getBarPainter();
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    var8.setDomainAxis(0, var12);
    boolean var14 = var8.isDomainZoomable();
    org.jfree.chart.LegendItemCollection var15 = var8.getLegendItems();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var18 = var16.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    var16.setDomainAxis(0, var20);
    boolean var22 = var16.isDomainZoomable();
    var16.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var25 = null;
    var16.markerChanged(var25);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var16.zoomDomainAxes(0.0d, var28, var29);
    org.jfree.data.category.DefaultCategoryDataset var31 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = var16.getRendererForDataset((org.jfree.data.category.CategoryDataset)var31);
    org.jfree.data.event.DatasetChangeListener var33 = null;
    var31.removeChangeListener(var33);
    int var36 = var31.getRowIndex((java.lang.Comparable)(byte)0);
    var31.clearSelection();
    int var38 = var31.getColumnCount();
    org.jfree.data.category.CategoryDatasetSelectionState var39 = var31.getSelectionState();
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var41 = var0.initialise(var6, var7, var8, (org.jfree.data.category.CategoryDataset)var31, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var2 = var1.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var4 = var3.getBaseSeriesVisibleInLegend();
//     int var5 = var3.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var7 = var6.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var9 = var6.lookupLegendTextPaint(15);
//     boolean var10 = var6.getBaseSeriesVisibleInLegend();
//     var6.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
//     var6.setBaseToolTipGenerator(var13, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var17 = var16.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var19 = var16.lookupLegendTextPaint(15);
//     boolean var20 = var16.getBaseSeriesVisibleInLegend();
//     var16.setBaseShapesVisible(false);
//     boolean var23 = var16.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var16.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var28 = var27.getTextAnchor();
//     var6.setBaseNegativeItemLabelPosition(var27);
//     var3.setBaseNegativeItemLabelPosition(var27);
//     var1.setBasePositiveItemLabelPosition(var27);
//     org.jfree.chart.text.TextAnchor var32 = var27.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var33 = var27.getItemLabelAnchor();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.setDomainCrosshairVisible(true);
//     var34.setRangeCrosshairValue(10.0d, false);
//     boolean var40 = var33.equals((java.lang.Object)var34);
//     boolean var41 = var0.equals((java.lang.Object)var33);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     var0.setDefaultLabelVisible((java.lang.Boolean)true);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var4.setDomainAxis(0, var8);
//     boolean var10 = var4.isDomainZoomable();
//     org.jfree.chart.plot.Plot var11 = var4.getRootPlot();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var13.setDomainAxis(100, var16, false);
//     java.util.List var19 = var13.getCategories();
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var22 = var20.getDomainAxis(0);
//     java.awt.Stroke var23 = var20.getRangeCrosshairStroke();
//     java.awt.Stroke var24 = var20.getRangeZeroBaselineStroke();
//     var13.setOutlineStroke(var24);
//     var12.setDomainGridlineStroke(var24);
//     var4.setDomainGridlineStroke(var24);
//     var0.setSeriesOutlineStroke(4, var24);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseShapesVisible(false);
    var2.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var13 = var2.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
    var14.setDomainCrosshairVisible(true);
    var14.setBackgroundImageAlpha(0.0f);
    boolean var22 = var2.equals((java.lang.Object)var14);
    boolean var23 = var0.equals((java.lang.Object)var2);
    boolean var25 = var2.equals((java.lang.Object)100.0d);
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var29 = var2.getObject((java.lang.Comparable)(-16.0d), (java.lang.Comparable)0.0f);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var3 = null;
//     var0.setFixedDomainAxisSpace(var3, false);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var8 = var6.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setDomainAxis(0, var10);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     java.awt.Image var13 = var6.getBackgroundImage();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Point2D var16 = null;
//     var6.zoomDomainAxes(1.0d, var15, var16, false);
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
//     double var20 = var19.getLabelAngle();
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var19.getCategorySeriesMiddle(10, 1, 0, 10, 0.0d, var26, var27);
//     var19.setLabelAngle(100.0d);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var34 = var32.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setDomainAxis(0, var36);
//     boolean var38 = var32.isDomainZoomable();
//     var32.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.configureDomainAxes();
//     java.awt.Paint var43 = var41.getDomainGridlinePaint();
//     var32.setRangeZeroBaselinePaint(var43);
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", var43);
//     boolean var46 = var45.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
//     var48.setTickLabelsVisible(false);
//     var48.setAxisLineVisible(true);
//     java.awt.Paint var53 = var48.getAxisLinePaint();
//     var47.setRangeCrosshairPaint(var53);
//     float var55 = var47.getBackgroundAlpha();
//     java.awt.Paint var56 = var47.getOutlinePaint();
//     var45.setLabelPaint(var56);
//     var19.setAxisLinePaint(var56);
//     var19.setCategoryLabelPositionOffset(0);
//     var19.setMinorTickMarksVisible(false);
//     float var63 = var19.getTickMarkOutsideLength();
//     var6.setDomainAxis(var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var41
//     assertTrue("Contract failed: equals-hashcode on var0 and var41", var0.equals(var41) ? var0.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var0
//     assertTrue("Contract failed: equals-hashcode on var41 and var0", var41.equals(var0) ? var41.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    boolean var3 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.zoomDomainAxes(10.0d, 10.0d, var6, var7);
    org.jfree.chart.axis.AxisLocation var10 = var0.getRangeAxisLocation(0);
    java.lang.String var11 = var10.toString();
    org.jfree.chart.axis.AxisLocation var12 = var10.getOpposite();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "AxisLocation.TOP_OR_LEFT"+ "'", var11.equals("AxisLocation.TOP_OR_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    java.awt.Shape var8 = var0.lookupLegendShape(100);
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var8);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    var10.setTickLabelsVisible(false);
    var10.setMaximumCategoryLabelLines((-1));
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var10.getCategoryStart(10, (-1), var17, var18);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.configureDomainAxes();
    org.jfree.chart.util.SortOrder var22 = var20.getColumnRenderingOrder();
    var10.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
    java.awt.Paint var24 = var20.getRangeCrosshairPaint();
    org.jfree.chart.entity.PlotEntity var26 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var20, "CategoryAnchor.MIDDLE");
    var26.setToolTipText("");
    java.awt.Shape var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.setArea(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.renderer.category.BarPainter var1 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var0.setBarPainter(var1);
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var0.setBaseToolTipGenerator(var10, false);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE");
    java.lang.String var15 = var14.getDescription();
    java.awt.Shape var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    var22.setTickLabelsVisible(false);
    var22.setAxisLineVisible(true);
    java.awt.Paint var27 = var22.getAxisLinePaint();
    var21.setRangeCrosshairPaint(var27);
    float var29 = var21.getBackgroundAlpha();
    java.awt.Paint var30 = var21.getOutlinePaint();
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", var20, var30);
    java.awt.Paint var32 = var31.getLinePaint();
    java.awt.Stroke var33 = var31.getLineStroke();
    var14.setOutlineStroke(var33);
    var0.setBaseStroke(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setDomainAxis(0, var6);
//     boolean var8 = var2.isDomainZoomable();
//     var2.setDomainCrosshairVisible(false);
//     var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
//     java.lang.Object var12 = var0.clone();
//     java.lang.Object var13 = var0.clone();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setTickLabelsVisible(false);
//     var15.setAxisLineVisible(true);
//     java.awt.Paint var20 = var15.getAxisLinePaint();
//     var14.setRangeCrosshairPaint(var20);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var14.drawBackgroundImage(var22, var23);
//     boolean var25 = var0.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.plot.PlotOrientation var26 = var14.getOrientation();
//     org.jfree.chart.axis.CategoryAnchor var27 = var14.getDomainGridlinePosition();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
//     var28.setDomainAxis(100, var31, false);
//     org.jfree.chart.util.SortOrder var34 = var28.getColumnRenderingOrder();
//     var28.clearRangeAxes();
//     var28.setRangeMinorGridlinesVisible(false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var39 = var38.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var41 = var38.lookupLegendTextPaint(15);
//     boolean var42 = var38.getBaseSeriesVisibleInLegend();
//     var38.setBaseShapesVisible(false);
//     boolean var45 = var38.getBaseShapesFilled();
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var49 = var47.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
//     var47.setDomainAxis(0, var51);
//     boolean var53 = var47.isDomainZoomable();
//     var47.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     var56.configureDomainAxes();
//     java.awt.Paint var58 = var56.getDomainGridlinePaint();
//     var47.setRangeZeroBaselinePaint(var58);
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", var58);
//     boolean var61 = var60.isShapeFilled();
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis();
//     var63.setTickLabelsVisible(false);
//     var63.setAxisLineVisible(true);
//     java.awt.Paint var68 = var63.getAxisLinePaint();
//     var62.setRangeCrosshairPaint(var68);
//     float var70 = var62.getBackgroundAlpha();
//     java.awt.Paint var71 = var62.getOutlinePaint();
//     var60.setLabelPaint(var71);
//     var38.setBaseLegendTextPaint(var71);
//     var28.setRangeGridlinePaint(var71);
//     org.jfree.chart.renderer.RenderAttributes var76 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var77 = var76.getDefaultCreateEntity();
//     java.awt.Paint var78 = var76.getDefaultFillPaint();
//     var28.setOutlinePaint(var78);
//     java.awt.Stroke var80 = var28.getDomainGridlineStroke();
//     var14.setRangeMinorGridlineStroke(var80);
//     
//     // Checks the contract:  equals-hashcode on var14 and var62
//     assertTrue("Contract failed: equals-hashcode on var14 and var62", var14.equals(var62) ? var14.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var14
//     assertTrue("Contract failed: equals-hashcode on var62 and var14", var62.equals(var14) ? var62.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.category.DefaultCategoryDataset var2 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var3 = var2.clone();
    var0.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected(100, 0, false);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    boolean var8 = var0.isRangeCrosshairVisible();
    java.awt.Stroke var9 = var0.getDomainGridlineStroke();
    org.jfree.chart.event.AnnotationChangeEvent var10 = null;
    var0.annotationChanged(var10);
    org.jfree.chart.plot.Marker var13 = null;
    org.jfree.chart.util.Layer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var15 = var0.removeRangeMarker(0, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var7 = null;
//     boolean var8 = var0.removeAnnotation(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.Marker var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var0.drawRangeMarker(var9, var10, var24, var25, var26);
//     java.lang.Boolean var29 = null;
//     var0.setSeriesVisible(10, var29, true);
//     boolean var32 = var0.getBaseSeriesVisibleInLegend();
//     boolean var35 = var0.getItemShapeFilled(1, 100);
//     java.awt.Paint var39 = var0.getItemLabelPaint((-16777116), (-1), false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var42 = var41.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var44 = var41.lookupLegendTextPaint(15);
//     boolean var45 = var41.getBaseSeriesVisibleInLegend();
//     var41.setBaseShapesVisible(false);
//     java.awt.Shape var49 = var41.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis();
//     var50.setDomainAxis(100, var53, false);
//     org.jfree.chart.util.SortOrder var56 = var50.getColumnRenderingOrder();
//     var50.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var59 = null;
//     java.awt.geom.Rectangle2D var60 = null;
//     var50.drawBackgroundImage(var59, var60);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var64 = var62.getDomainAxis(0);
//     java.awt.Stroke var65 = var62.getRangeCrosshairStroke();
//     var50.setDomainCrosshairStroke(var65);
//     var50.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var70 = new org.jfree.chart.entity.PlotEntity(var49, (org.jfree.chart.plot.Plot)var50, "DatasetRenderingOrder.REVERSE");
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var73 = var71.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var75 = new org.jfree.chart.axis.CategoryAxis();
//     var71.setDomainAxis(0, var75);
//     boolean var77 = var71.isDomainZoomable();
//     org.jfree.chart.plot.Plot var78 = var71.getRootPlot();
//     org.jfree.data.category.CategoryDataset var79 = null;
//     int var80 = var71.indexOf(var79);
//     org.jfree.chart.entity.PlotEntity var83 = new org.jfree.chart.entity.PlotEntity(var49, (org.jfree.chart.plot.Plot)var71, "TextAnchor.BOTTOM_CENTER", "CategoryAnchor.MIDDLE");
//     var0.setSeriesShape(2, var49, false);
//     
//     // Checks the contract:  equals-hashcode on var10 and var71
//     assertTrue("Contract failed: equals-hashcode on var10 and var71", var10.equals(var71) ? var10.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var10
//     assertTrue("Contract failed: equals-hashcode on var71 and var10", var71.equals(var10) ? var71.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setDomainAxis(0, var5);
//     boolean var7 = var1.isDomainZoomable();
//     var1.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     java.awt.Paint var12 = var10.getDomainGridlinePaint();
//     var1.setRangeZeroBaselinePaint(var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
//     var14.setDescription("");
//     var14.setSeriesKey((java.lang.Comparable)"CategoryAnchor.MIDDLE");
//     java.awt.Shape var19 = var14.getLine();
//     org.jfree.chart.util.GradientPaintTransformer var20 = var14.getFillPaintTransformer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var14.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var21);
//     java.lang.Object var23 = var21.clone();
//     java.awt.GradientPaint var24 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var26 = var25.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var28 = var25.lookupLegendTextPaint(15);
//     boolean var29 = var25.getBaseSeriesVisibleInLegend();
//     var25.setBaseShapesVisible(false);
//     java.awt.Shape var33 = var25.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
//     var34.setDomainAxis(100, var37, false);
//     org.jfree.chart.util.SortOrder var40 = var34.getColumnRenderingOrder();
//     var34.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     var34.drawBackgroundImage(var43, var44);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var48 = var46.getDomainAxis(0);
//     java.awt.Stroke var49 = var46.getRangeCrosshairStroke();
//     var34.setDomainCrosshairStroke(var49);
//     var34.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var54 = new org.jfree.chart.entity.PlotEntity(var33, (org.jfree.chart.plot.Plot)var34, "DatasetRenderingOrder.REVERSE");
//     java.awt.GradientPaint var55 = var21.transform(var24, var33);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("org.jfree.chart.event.ChartChangeEvent[source=false]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setDomainAxis(0, var6);
//     boolean var8 = var2.isDomainZoomable();
//     var2.setDomainCrosshairVisible(false);
//     var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
//     java.lang.Object var12 = var0.clone();
//     java.lang.Object var13 = var0.clone();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setTickLabelsVisible(false);
//     var15.setAxisLineVisible(true);
//     java.awt.Paint var20 = var15.getAxisLinePaint();
//     var14.setRangeCrosshairPaint(var20);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var14.drawBackgroundImage(var22, var23);
//     boolean var25 = var0.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.plot.PlotOrientation var26 = var14.getOrientation();
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("CategoryAnchor.MIDDLE");
//     java.lang.String var29 = var28.getDescription();
//     java.awt.Shape var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     var36.setTickLabelsVisible(false);
//     var36.setAxisLineVisible(true);
//     java.awt.Paint var41 = var36.getAxisLinePaint();
//     var35.setRangeCrosshairPaint(var41);
//     float var43 = var35.getBackgroundAlpha();
//     java.awt.Paint var44 = var35.getOutlinePaint();
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", var34, var44);
//     java.awt.Paint var46 = var45.getLinePaint();
//     java.awt.Stroke var47 = var45.getLineStroke();
//     var28.setOutlineStroke(var47);
//     boolean var49 = var26.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var14 and var35
//     assertTrue("Contract failed: equals-hashcode on var14 and var35", var14.equals(var35) ? var14.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var14
//     assertTrue("Contract failed: equals-hashcode on var35 and var14", var35.equals(var14) ? var35.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     java.awt.Paint var4 = var2.getDomainGridlinePaint();
//     var1.setDefaultOutlinePaint(var4);
//     java.awt.Paint var6 = var1.getDefaultLabelPaint();
//     var1.setDefaultCreateEntity((java.lang.Boolean)false);
//     java.awt.Font var11 = var1.getItemLabelFont(255, 5);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    boolean var5 = var3.equals((java.lang.Object)var4);
    java.lang.String var6 = var4.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var8 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var9 = var8.getDefaultLabelFont();
    java.awt.Paint var10 = var8.getDefaultPaint();
    var4.setLabelPaint(var10);
    org.jfree.chart.util.RectangleInsets var12 = var4.getTickLabelInsets();
    boolean var13 = var0.equals((java.lang.Object)var4);
    java.lang.Comparable var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var0.getIndex(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var2 = var0.getDatasetRenderingOrder();
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var3);
    org.jfree.data.category.DefaultCategoryDataset var5 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var6 = var5.clone();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var9 = var7.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    var7.setDomainAxis(0, var11);
    boolean var13 = var7.isDomainZoomable();
    var7.setDomainCrosshairVisible(false);
    var5.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var7);
    java.lang.Object var17 = var5.clone();
    java.lang.Object var18 = var5.clone();
    var0.setDataset((org.jfree.data.category.CategoryDataset)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var21 = var5.getColumnKey(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    var0.setSeriesShapesFilled(15, (java.lang.Boolean)false);
    java.lang.Boolean var11 = var0.getSeriesCreateEntities(15);
    org.jfree.chart.renderer.RenderAttributes var13 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.lang.Boolean var14 = var13.getDefaultCreateEntity();
    java.awt.Shape var16 = null;
    var13.setSeriesShape(0, var16);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    var18.setTickLabelsVisible(false);
    var18.setMaximumCategoryLabelLines((-1));
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var18.getCategoryStart(10, (-1), var25, var26);
    java.awt.Font var29 = var18.getTickLabelFont((java.lang.Comparable)'4');
    var13.setDefaultLabelFont(var29);
    java.awt.Paint var33 = var13.getItemOutlinePaint(1, 15);
    var0.setBaseItemLabelPaint(var33, false);
    double var36 = var0.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Stroke var1 = var0.getDefaultOutlineStroke();
//     java.awt.Paint var3 = var0.getSeriesLabelPaint((-1));
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setTickLabelsVisible(false);
//     var1.setAxisLineVisible(true);
//     java.awt.Paint var6 = var1.getAxisLinePaint();
//     var0.setRangeCrosshairPaint(var6);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var0.drawBackgroundImage(var8, var9);
//     org.jfree.chart.plot.Marker var12 = null;
//     org.jfree.chart.util.Layer var13 = null;
//     var0.addRangeMarker(4, var12, var13, false);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseShapesVisible(false);
    java.awt.Font var10 = var0.getItemLabelFont(0, (-100), true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
    var0.setSeriesItemLabelGenerator(3, var12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    java.awt.Font var20 = var17.getLabelFont();
    var17.setLabelToolTip("hi!");
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var25 = var24.getBaseSeriesVisibleInLegend();
    java.awt.Paint var27 = var24.lookupLegendTextPaint(15);
    boolean var28 = var24.getBaseSeriesVisibleInLegend();
    var24.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var24.setBaseToolTipGenerator(var31, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var24.setBaseToolTipGenerator(var34, false);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var17, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var40 = var38.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleEdge var44 = null;
    double var45 = var38.getCategoryEnd((-1), (-1), var43, var44);
    float var46 = var38.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
    var48.setTickLabelsVisible(false);
    var48.setAxisLineVisible(true);
    java.awt.Paint var53 = var48.getAxisLinePaint();
    var47.setRangeCrosshairPaint(var53);
    org.jfree.chart.JFreeChart var55 = null;
    org.jfree.chart.event.ChartChangeEventType var56 = null;
    org.jfree.chart.event.ChartChangeEvent var57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var53, var55, var56);
    var38.setAxisLinePaint(var53);
    java.awt.Font var59 = var38.getLabelFont();
    org.jfree.chart.util.RectangleInsets var60 = var38.getLabelInsets();
    var37.setInsets(var60, false);
    var37.setDomainCrosshairVisible(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var66 = var65.getBaseSeriesVisibleInLegend();
    java.awt.Paint var68 = var65.lookupLegendTextPaint(15);
    boolean var69 = var65.getBaseSeriesVisibleInLegend();
    var65.setBaseLinesVisible(true);
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var74 = var72.getDomainAxis(0);
    java.awt.Stroke var75 = var72.getRangeCrosshairStroke();
    var65.setBaseOutlineStroke(var75);
    boolean var77 = var65.getAutoPopulateSeriesPaint();
    java.awt.Paint var81 = var65.getItemLabelPaint((-1), 5, true);
    var37.setOutlinePaint(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     java.awt.Paint var2 = var0.getDomainGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var5 = var3.getColumnRenderingOrder();
//     var0.setRowRenderingOrder(var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.configureDomainAxes();
    java.awt.Paint var3 = var1.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var4 = var1.getInsets();
    var0.addChangeListener((org.jfree.data.event.DatasetChangeListener)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected(0, (-33), false, false);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var4 = var3.getTop();
    double var6 = var3.calculateBottomInset(4.0d);
    double var7 = var3.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(0, var6);
    boolean var8 = var2.isDomainZoomable();
    var2.setDomainCrosshairVisible(false);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
    java.lang.Object var12 = var0.clone();
    java.lang.Object var13 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    var15.setTickLabelsVisible(false);
    var15.setAxisLineVisible(true);
    java.awt.Paint var20 = var15.getAxisLinePaint();
    var14.setRangeCrosshairPaint(var20);
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    var14.drawBackgroundImage(var22, var23);
    boolean var25 = var0.hasListener((java.util.EventListener)var14);
    java.lang.Comparable var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.incrementValue((-0.7853981633974483d), (java.lang.Comparable)(-2), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 8.0d, 2.0d, 1.0d, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var9 = null;
    var0.markerChanged(var9);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomDomainAxes(0.0d, var12, var13);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    var17.setDomainAxis(100, var20, false);
    java.util.List var23 = var17.getCategories();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var26 = var24.getDomainAxis(0);
    java.awt.Stroke var27 = var24.getRangeCrosshairStroke();
    java.awt.Stroke var28 = var24.getRangeZeroBaselineStroke();
    var17.setOutlineStroke(var28);
    org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var17);
    boolean var31 = var15.hasListener((java.util.EventListener)var17);
    java.awt.Paint var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setRangeMinorGridlinePaint(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var2 = null;
    var0.setRangeAxis(1, var2, true);
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedRangeAxisSpace(var5, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    boolean var12 = var8.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var13 = var8.getLegendItemURLGenerator();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setItemMargin((-14.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    int var2 = var0.getItemCount();
    java.awt.Shape var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    var11.setTickLabelsVisible(false);
    var11.setAxisLineVisible(true);
    java.awt.Paint var16 = var11.getAxisLinePaint();
    var10.setRangeCrosshairPaint(var16);
    float var18 = var10.getBackgroundAlpha();
    java.awt.Paint var19 = var10.getOutlinePaint();
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "hi!", var9, var19);
    java.awt.Paint var21 = var20.getLinePaint();
    java.awt.Stroke var22 = var20.getLineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue(100, (java.lang.Comparable)(byte)100, (java.lang.Object)var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.data.Range var8 = var0.findRangeBounds(var7);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getSeriesToolTipGenerator(0);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var13 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    boolean var15 = var13.equals((java.lang.Object)var14);
    java.lang.String var16 = var14.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var18 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var19 = var18.getDefaultLabelFont();
    java.awt.Paint var20 = var18.getDefaultPaint();
    var14.setLabelPaint(var20);
    java.awt.Font var22 = var14.getLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendTextFont((-131072), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseLinesVisible(true);
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.data.Range var8 = var0.findRangeBounds(var7);
//     org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getSeriesToolTipGenerator(0);
//     var0.setAutoPopulateSeriesOutlineStroke(true);
//     var0.setDataBoundsIncludesVisibleSeriesOnly(false);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var19 = var17.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setDomainAxis(0, var21);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var25 = var23.getDomainAxis(0);
//     org.jfree.chart.axis.AxisSpace var26 = null;
//     var23.setFixedDomainAxisSpace(var26, false);
//     var21.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     var23.setDomainCrosshairColumnKey((java.lang.Comparable)0L, true);
//     var23.setOutlineVisible(false);
//     java.awt.Paint var35 = var23.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     var36.clearCategoryLabelToolTips();
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     java.awt.geom.Rectangle2D var45 = var0.createHotSpotBounds(var15, var16, var23, var36, var38, var39, (-131072), 0, true, var43, var44);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    java.awt.Stroke var5 = var0.getSeriesStroke(15);
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    var10.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var19 = null;
    var10.markerChanged(var19);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var10.zoomDomainAxes(0.0d, var22, var23);
    org.jfree.data.category.DefaultCategoryDataset var25 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = var10.getRendererForDataset((org.jfree.data.category.CategoryDataset)var25);
    org.jfree.data.event.DatasetChangeListener var27 = null;
    var25.removeChangeListener(var27);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    var30.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
    var30.setDomainAxis(100, var33, false);
    org.jfree.chart.util.SortOrder var36 = var30.getColumnRenderingOrder();
    java.awt.Paint var37 = var30.getRangeMinorGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var40 = var38.getDomainAxis(0);
    java.awt.Stroke var41 = var38.getRangeCrosshairStroke();
    java.awt.Stroke var42 = var38.getRangeZeroBaselineStroke();
    var30.setRangeMinorGridlineStroke(var42);
    java.awt.Paint var44 = var30.getDomainCrosshairPaint();
    org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("", var44);
    org.jfree.data.category.DefaultCategoryDataset var46 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var47 = var46.clone();
    org.jfree.data.category.DefaultCategoryDataset var48 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var49 = var48.clone();
    var46.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var48);
    var45.setDataset((org.jfree.data.general.Dataset)var48);
    var25.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var48);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var54 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis();
    boolean var56 = var54.equals((java.lang.Object)var55);
    java.awt.geom.Rectangle2D var62 = null;
    org.jfree.chart.util.RectangleEdge var63 = null;
    double var64 = var55.getCategorySeriesMiddle((-1), 10, 0, 1, 10.0d, var62, var63);
    java.awt.geom.Rectangle2D var67 = null;
    org.jfree.chart.util.RectangleEdge var68 = null;
    double var69 = var55.getCategoryEnd((-1), (-1), var67, var68);
    java.awt.geom.Rectangle2D var70 = null;
    org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
    var71.configureDomainAxes();
    boolean var73 = var71.isOutlineVisible();
    org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var77 = var75.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var79 = new org.jfree.chart.axis.CategoryAxis();
    var75.setDomainAxis(0, var79);
    boolean var81 = var75.isDomainZoomable();
    org.jfree.chart.axis.AxisLocation var82 = var75.getRangeAxisLocation();
    var71.setRangeAxisLocation(2, var82);
    org.jfree.chart.plot.CategoryPlot var84 = new org.jfree.chart.plot.CategoryPlot();
    var84.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var87 = new org.jfree.chart.axis.CategoryAxis();
    var84.setDomainAxis(100, var87, false);
    org.jfree.chart.util.SortOrder var90 = var84.getColumnRenderingOrder();
    var84.setRangeMinorGridlinesVisible(false);
    var84.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.PlotOrientation var95 = var84.getOrientation();
    org.jfree.chart.util.RectangleEdge var96 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var82, var95);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var97 = var0.getItemMiddle((java.lang.Comparable)(byte)1, (java.lang.Comparable)(-0.7853981633974483d), (org.jfree.data.category.CategoryDataset)var48, var55, var70, var96);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseShapesVisible(false);
    var2.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var13 = var2.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
    var14.setDomainCrosshairVisible(true);
    var14.setBackgroundImageAlpha(0.0f);
    boolean var22 = var2.equals((java.lang.Object)var14);
    boolean var23 = var0.equals((java.lang.Object)var2);
    boolean var25 = var2.equals((java.lang.Object)100.0d);
    var2.clear();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.Color var32 = var31.brighter();
    java.awt.Color var33 = java.awt.Color.getColor("", var32);
    java.awt.Color var34 = var33.darker();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", (java.awt.Paint)var34);
    boolean var36 = var2.equals((java.lang.Object)var35);
    java.lang.Comparable var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var38 = var2.getRowIndex(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var9 = var8.getBaseSeriesVisibleInLegend();
    java.awt.Paint var11 = var8.lookupLegendTextPaint(15);
    java.awt.Paint var13 = var8.getSeriesOutlinePaint(0);
    var8.setBaseItemLabelsVisible(false, true);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    java.awt.Font var20 = var17.getLabelFont();
    var17.setLabelToolTip("hi!");
    java.awt.Font var24 = var17.getTickLabelFont((java.lang.Comparable)(byte)(-1));
    var8.setBaseLegendTextFont(var24);
    var0.setSeriesItemLabelFont(10, var24, true);
    java.awt.Shape var29 = var0.lookupSeriesShape((-1));
    org.jfree.data.category.CategoryDataset var32 = null;
    java.lang.Comparable var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var35 = new org.jfree.chart.entity.CategoryItemEntity(var29, "", "CategoryAnchor.MIDDLE", var32, var33, (java.lang.Comparable)"DatasetRenderingOrder.REVERSE");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = var0.getBoolean(0);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var5 = var3.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var3.setDomainAxis(0, var7);
    boolean var9 = var3.isDomainZoomable();
    org.jfree.chart.plot.Plot var10 = var3.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.axis.ValueAxis var13 = var3.getRangeAxis(0);
    boolean var14 = var3.isDomainCrosshairVisible();
    boolean var15 = var0.equals((java.lang.Object)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.mapDatasetToRangeAxis((-100), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
    var0.setSeriesToolTipGenerator(100, var33, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var39 = var0.getToolTipGenerator(15, 1, false);
    java.awt.Paint var40 = var0.getBaseOutlinePaint();
    int var41 = var0.getPassCount();
    int var42 = var0.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    java.util.List var6 = var0.getCategories();
    boolean var7 = var0.isDomainGridlinesVisible();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.util.RectangleInsets var9 = var0.getAxisOffset();
    org.jfree.chart.util.SortOrder var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setColumnRenderingOrder(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    int var12 = var0.getIndexOf(var11);
    org.jfree.chart.LegendItemCollection var13 = var0.getLegendItems();
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var14.setTickLabelsVisible(false);
    var14.setAxisLineVisible(true);
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var14.configure();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var22 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
    boolean var24 = var22.equals((java.lang.Object)var23);
    java.lang.String var25 = var23.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var27 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var28 = var27.getDefaultLabelFont();
    java.awt.Paint var29 = var27.getDefaultPaint();
    var23.setLabelPaint(var29);
    org.jfree.chart.util.RectangleInsets var31 = var23.getTickLabelInsets();
    double var33 = var31.calculateBottomInset((-1.0d));
    var14.setTickLabelInsets(var31);
    org.jfree.chart.axis.CategoryAxis[] var35 = new org.jfree.chart.axis.CategoryAxis[] { var14};
    var0.setDomainAxes(var35);
    java.awt.geom.GeneralPath var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.RenderingSource var39 = null;
    var0.select(var37, var38, var39);
    org.jfree.chart.axis.AxisLocation var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var1.setDomainAxis(0, var5);
    boolean var7 = var1.isDomainZoomable();
    var1.setDomainCrosshairVisible(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    java.awt.Paint var12 = var10.getDomainGridlinePaint();
    var1.setRangeZeroBaselinePaint(var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", var12);
    boolean var15 = var14.isShapeFilled();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    var17.setTickLabelsVisible(false);
    var17.setAxisLineVisible(true);
    java.awt.Paint var22 = var17.getAxisLinePaint();
    var16.setRangeCrosshairPaint(var22);
    float var24 = var16.getBackgroundAlpha();
    java.awt.Paint var25 = var16.getOutlinePaint();
    var14.setLabelPaint(var25);
    var14.setSeriesIndex(0);
    var14.setDescription("CategoryAnchor.MIDDLE");
    java.awt.Paint var31 = var14.getOutlinePaint();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var33 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis();
    boolean var35 = var33.equals((java.lang.Object)var34);
    java.lang.String var36 = var34.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var38 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var39 = var38.getDefaultLabelFont();
    java.awt.Paint var40 = var38.getDefaultPaint();
    var34.setLabelPaint(var40);
    var14.setFillPaint(var40);
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var45 = var43.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
    var43.setDomainAxis(0, var47);
    boolean var49 = var43.isDomainZoomable();
    var43.setDomainCrosshairVisible(false);
    org.jfree.chart.event.MarkerChangeEvent var52 = null;
    var43.markerChanged(var52);
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    java.awt.geom.Point2D var56 = null;
    var43.zoomDomainAxes(0.0d, var55, var56);
    org.jfree.data.category.DefaultCategoryDataset var58 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var59 = var43.getRendererForDataset((org.jfree.data.category.CategoryDataset)var58);
    org.jfree.data.event.DatasetChangeListener var60 = null;
    var58.removeChangeListener(var60);
    int var63 = var58.getRowIndex((java.lang.Comparable)(byte)0);
    java.util.List var64 = var58.getColumnKeys();
    org.jfree.chart.event.DatasetChangeInfo var65 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.event.DatasetChangeEvent var66 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var40, (org.jfree.data.general.Dataset)var58, var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    java.awt.Stroke var5 = var0.getSeriesStroke(15);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    org.jfree.chart.renderer.RenderAttributes var9 = new org.jfree.chart.renderer.RenderAttributes(false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(100, var13, false);
    org.jfree.chart.util.SortOrder var16 = var10.getColumnRenderingOrder();
    java.awt.Paint var17 = var10.getRangeMinorGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var20 = var18.getDomainAxis(0);
    java.awt.Stroke var21 = var18.getRangeCrosshairStroke();
    java.awt.Stroke var22 = var18.getRangeZeroBaselineStroke();
    var10.setRangeMinorGridlineStroke(var22);
    var9.setDefaultStroke(var22);
    var0.setBaseStroke(var22, false);
    java.awt.Stroke var28 = var0.getSeriesOutlineStroke(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var1);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.configureDomainAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var5 = var3.getDatasetRenderingOrder();
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var3, var6);
    org.jfree.data.category.DefaultCategoryDataset var8 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var9 = var8.clone();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    var10.setDomainCrosshairVisible(false);
    var8.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var10);
    java.lang.Object var20 = var8.clone();
    java.lang.Object var21 = var8.clone();
    var3.setDataset((org.jfree.data.category.CategoryDataset)var8);
    var0.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var8);
    var8.setValue((java.lang.Number)0L, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)' ');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.incrementValue(3.0d, (java.lang.Comparable)1, (java.lang.Comparable)100.0d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    int var8 = var0.getRendererCount();
    var0.mapDatasetToRangeAxis(100, 2);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var14 = null;
    var12.setRangeAxis(1, var14, true);
    var12.clearDomainAxes();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    double var19 = var18.getLabelAngle();
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var18.getCategorySeriesMiddle(10, 1, 0, 10, 0.0d, var25, var26);
    java.awt.Stroke var28 = var18.getTickMarkStroke();
    var12.setDomainCrosshairStroke(var28);
    var0.setRangeGridlineStroke(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.getSeriesOutlinePaint(4);
    var0.clearSeriesStrokes(true);
    boolean var8 = var0.getItemShapeFilled((-1), (-2));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-33), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var2.getCategorySeriesMiddle((-1), 10, 0, 1, 10.0d, var9, var10);
    var2.setFixedDimension(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    boolean var3 = var1.equals((java.lang.Object)var2);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var2.getCategorySeriesMiddle((-1), 10, 0, 1, 10.0d, var9, var10);
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.util.RectangleEdge var15 = null;
    double var16 = var2.getCategoryEnd((-1), (-1), var14, var15);
    java.awt.Font var18 = var2.getTickLabelFont((java.lang.Comparable)(short)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var0.removeRangeMarker((-100), var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.data.Range var8 = var0.findRangeBounds(var7);
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = var0.getSeriesToolTipGenerator(0);
    var0.setAutoPopulateSeriesOutlineStroke(true);
    var0.setDataBoundsIncludesVisibleSeriesOnly(false);
    java.lang.Object var15 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.KeyedObjects2D var2 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var4 = var3.getBaseSeriesVisibleInLegend();
    java.awt.Paint var6 = var3.lookupLegendTextPaint(15);
    boolean var7 = var3.getBaseSeriesVisibleInLegend();
    var3.setBaseShapesVisible(false);
    var2.setObject((java.lang.Object)false, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(byte)100);
    java.util.List var13 = var2.getColumnKeys();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var16 = var14.getDomainAxis(0);
    java.awt.Stroke var17 = var14.getRangeCrosshairStroke();
    var14.setDomainCrosshairVisible(true);
    var14.setBackgroundImageAlpha(0.0f);
    boolean var22 = var2.equals((java.lang.Object)var14);
    boolean var23 = var0.equals((java.lang.Object)var2);
    boolean var25 = var2.equals((java.lang.Object)100.0d);
    var2.clear();
    java.awt.Color var31 = java.awt.Color.getColor("", 1);
    java.awt.Color var32 = var31.brighter();
    java.awt.Color var33 = java.awt.Color.getColor("", var32);
    java.awt.Color var34 = var33.darker();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", (java.awt.Paint)var34);
    boolean var36 = var2.equals((java.lang.Object)var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var39 = var2.getObject((java.lang.Comparable)2.0d, (java.lang.Comparable)10.0f);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var3 = var2.getBaseSeriesVisibleInLegend();
//     int var4 = var2.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var6 = var5.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var8 = var5.lookupLegendTextPaint(15);
//     boolean var9 = var5.getBaseSeriesVisibleInLegend();
//     var5.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
//     var5.setBaseToolTipGenerator(var12, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var16 = var15.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var18 = var15.lookupLegendTextPaint(15);
//     boolean var19 = var15.getBaseSeriesVisibleInLegend();
//     var15.setBaseShapesVisible(false);
//     boolean var22 = var15.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var15.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var27 = var26.getTextAnchor();
//     var5.setBaseNegativeItemLabelPosition(var26);
//     var2.setBaseNegativeItemLabelPosition(var26);
//     var0.setBasePositiveItemLabelPosition(var26);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setTickLabelsVisible(false);
//     var32.setMaximumCategoryLabelLines((-1));
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var32.getCategoryStart(10, (-1), var39, var40);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     var42.configureDomainAxes();
//     org.jfree.chart.util.SortOrder var44 = var42.getColumnRenderingOrder();
//     var32.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var42);
//     java.awt.Paint var46 = var42.getRangeCrosshairPaint();
//     var0.setSeriesOutlinePaint(10, var46);
//     java.awt.Paint var48 = var0.getBaseItemLabelPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var50 = var49.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var52 = var49.lookupLegendTextPaint(15);
//     boolean var53 = var49.getBaseSeriesVisibleInLegend();
//     var49.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var56 = null;
//     var49.setBaseToolTipGenerator(var56, false);
//     org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var62 = var60.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.geom.Rectangle2D var65 = null;
//     org.jfree.chart.util.RectangleEdge var66 = null;
//     double var67 = var60.getCategoryEnd((-1), (-1), var65, var66);
//     float var68 = var60.getTickMarkInsideLength();
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis();
//     var70.setTickLabelsVisible(false);
//     var70.setAxisLineVisible(true);
//     java.awt.Paint var75 = var70.getAxisLinePaint();
//     var69.setRangeCrosshairPaint(var75);
//     org.jfree.chart.JFreeChart var77 = null;
//     org.jfree.chart.event.ChartChangeEventType var78 = null;
//     org.jfree.chart.event.ChartChangeEvent var79 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var75, var77, var78);
//     var60.setAxisLinePaint(var75);
//     java.awt.Font var81 = var60.getLabelFont();
//     var49.setSeriesItemLabelFont(0, var81);
//     boolean var83 = var49.getUseOutlinePaint();
//     org.jfree.chart.plot.CategoryPlot var85 = new org.jfree.chart.plot.CategoryPlot();
//     var85.configureDomainAxes();
//     java.awt.Stroke var87 = var85.getRangeGridlineStroke();
//     var49.setSeriesOutlineStroke(0, var87, true);
//     var0.setBaseStroke(var87);
//     
//     // Checks the contract:  equals-hashcode on var42 and var85
//     assertTrue("Contract failed: equals-hashcode on var42 and var85", var42.equals(var85) ? var42.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var42
//     assertTrue("Contract failed: equals-hashcode on var85 and var42", var85.equals(var42) ? var85.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
    java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
    org.jfree.chart.annotations.CategoryAnnotation var7 = null;
    boolean var8 = var0.removeAnnotation(var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var10.setDomainAxis(0, var14);
    boolean var16 = var10.isDomainZoomable();
    org.jfree.chart.plot.Marker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var9, var10, var24, var25, var26);
    java.lang.Boolean var29 = null;
    var0.setSeriesVisible(10, var29, true);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    boolean var35 = var0.getItemShapeFilled(1, 100);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var38 = var36.getDomainAxis(0);
    org.jfree.chart.axis.AxisSpace var39 = null;
    var36.setFixedDomainAxisSpace(var39, false);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var44 = var42.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis();
    var42.setDomainAxis(0, var46);
    var36.setParent((org.jfree.chart.plot.Plot)var42);
    org.jfree.chart.util.RectangleInsets var49 = new org.jfree.chart.util.RectangleInsets();
    var42.setInsets(var49);
    boolean var51 = var0.hasListener((java.util.EventListener)var42);
    org.jfree.chart.axis.CategoryAnchor var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var42.setDomainGridlinePosition(var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = null;
    var0.setBaseItemLabelGenerator(var2, true);
    java.awt.Paint var5 = var0.getBaseLegendTextPaint();
    java.awt.Paint var9 = var0.getItemPaint((-1), 1, true);
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var11 = var10.clone();
    org.jfree.data.category.DefaultCategoryDataset var12 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var13 = var12.clone();
    var10.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var12);
    org.jfree.data.category.CategoryDatasetSelectionState var15 = null;
    var12.setSelectionState(var15);
    org.jfree.data.Range var17 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setSelected(0, (-16777116), false, true);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesPaint(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var4.setTickLabelsVisible(false);
    var4.setMaximumCategoryLabelLines((-1));
    var4.removeCategoryLabelToolTip((java.lang.Comparable)100.0d);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.configureDomainAxes();
    java.awt.Paint var13 = var11.getDomainGridlinePaint();
    java.lang.Object var14 = var11.clone();
    var4.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    var4.setLabel("CategoryAnchor.MIDDLE");
    java.awt.Color var20 = java.awt.Color.getColor("hi!", 100);
    int var21 = var20.getRGB();
    java.awt.Color var22 = var20.darker();
    var4.setAxisLinePaint((java.awt.Paint)var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-2), (java.awt.Paint)var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-16777116));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    boolean var11 = var0.isDomainCrosshairVisible();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.setDomainCrosshairVisible(true);
    org.jfree.chart.event.AnnotationChangeEvent var15 = null;
    var12.annotationChanged(var15);
    org.jfree.chart.util.SortOrder var17 = var12.getColumnRenderingOrder();
    var0.setColumnRenderingOrder(var17);
    org.jfree.chart.util.ObjectList var20 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    var22.configureDomainAxes();
    java.awt.Stroke var24 = var22.getRangeGridlineStroke();
    org.jfree.chart.util.SortOrder var25 = var22.getRowRenderingOrder();
    var20.set(101, (java.lang.Object)var22);
    org.jfree.chart.axis.AxisLocation var28 = var22.getRangeAxisLocation(4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-100), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var1 = var0.getDefaultPaint();
    java.awt.Paint var2 = var0.getDefaultOutlinePaint();
    java.awt.Paint var4 = var0.getSeriesPaint(15);
    var0.setDefaultLabelVisible((java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
    boolean var4 = var0.getBaseSeriesVisibleInLegend();
    var0.setBaseLinesVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, false);
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var13 = var11.getTickLabelPaint((java.lang.Comparable)0);
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var11.getCategoryEnd((-1), (-1), var16, var17);
    float var19 = var11.getTickMarkInsideLength();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    var21.setTickLabelsVisible(false);
    var21.setAxisLineVisible(true);
    java.awt.Paint var26 = var21.getAxisLinePaint();
    var20.setRangeCrosshairPaint(var26);
    org.jfree.chart.JFreeChart var28 = null;
    org.jfree.chart.event.ChartChangeEventType var29 = null;
    org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var28, var29);
    var11.setAxisLinePaint(var26);
    java.awt.Font var32 = var11.getLabelFont();
    var0.setSeriesItemLabelFont(0, var32);
    org.jfree.chart.annotations.CategoryAnnotation var34 = null;
    org.jfree.chart.util.Layer var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var34, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    java.awt.Color var3 = java.awt.Color.getColor("", 1);
    java.awt.Color var4 = var3.brighter();
    java.awt.Color var5 = java.awt.Color.getColor("", var4);
    java.awt.Color var9 = java.awt.Color.getColor("", 1);
    java.awt.Color var10 = var9.brighter();
    java.awt.Color var11 = java.awt.Color.getColor("", var10);
    java.awt.color.ColorSpace var12 = var10.getColorSpace();
    float[] var14 = new float[] { (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var15 = var5.getComponents(var12, var14);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.lang.Boolean var2 = var1.getDefaultCreateEntity();
//     java.awt.Paint var3 = var1.getDefaultFillPaint();
//     java.awt.Paint var4 = var1.getDefaultOutlinePaint();
//     java.lang.Boolean var7 = var1.isLabelVisible((-1), 5);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    java.awt.Stroke var3 = var0.getRangeCrosshairStroke();
    java.awt.Stroke var4 = var0.getRangeZeroBaselineStroke();
    var0.clearRangeMarkers();
    java.awt.Stroke var6 = var0.getRangeZeroBaselineStroke();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(1.0d, var8, var9);
    java.lang.Comparable var11 = null;
    var0.setDomainCrosshairRowKey(var11, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    java.lang.Object var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(100, var5, false);
    java.util.List var8 = var2.getCategories();
    boolean var9 = var2.isDomainGridlinesVisible();
    org.jfree.chart.event.PlotChangeEvent var10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.event.ChartChangeEventType var11 = var10.getType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent(var0, var1, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    var0.setDomainCrosshairVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    java.awt.Stroke var10 = var0.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getRowKeys();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    boolean var5 = var3.equals((java.lang.Object)var4);
    boolean var6 = var4.isAxisLineVisible();
    var0.setObject((java.lang.Object)var4, (java.lang.Comparable)10.0f, (java.lang.Comparable)4);
    var0.removeRow(0);
    java.util.List var12 = var0.getColumnKeys();
    int var14 = var0.getRowIndex((java.lang.Comparable)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(100, var3, false);
    org.jfree.chart.util.SortOrder var6 = var0.getColumnRenderingOrder();
    java.awt.Paint var7 = var0.getRangeMinorGridlinePaint();
    int var8 = var0.getRendererCount();
    org.jfree.chart.plot.Marker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    boolean var13 = var0.removeDomainMarker(4, var10, var11, false);
    org.jfree.chart.axis.AxisLocation var15 = var0.getRangeAxisLocation(255);
    var0.setForegroundAlpha(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     boolean var2 = var0.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var6 = var4.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var4.setDomainAxis(0, var8);
//     boolean var10 = var4.isDomainZoomable();
//     org.jfree.chart.axis.AxisLocation var11 = var4.getRangeAxisLocation();
//     var0.setRangeAxisLocation(2, var11);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.configureDomainAxes();
//     boolean var15 = var13.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var19 = var17.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setDomainAxis(0, var21);
//     boolean var23 = var17.isDomainZoomable();
//     org.jfree.chart.axis.AxisLocation var24 = var17.getRangeAxisLocation();
//     var13.setRangeAxisLocation(2, var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
//     var26.setDomainAxis(100, var29, false);
//     org.jfree.chart.util.SortOrder var32 = var26.getColumnRenderingOrder();
//     var26.setRangeMinorGridlinesVisible(false);
//     var26.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.plot.PlotOrientation var37 = var26.getOrientation();
//     org.jfree.chart.util.RectangleEdge var38 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var24, var37);
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var39.setTickLabelsVisible(false);
//     java.awt.Font var42 = var39.getLabelFont();
//     double var43 = var39.getFixedDimension();
//     var39.setMinorTickMarksVisible(false);
//     boolean var46 = var37.equals((java.lang.Object)false);
//     org.jfree.chart.util.RectangleEdge var47 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var11, var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var0.setDomainAxis(0, var4);
    boolean var6 = var0.isDomainZoomable();
    org.jfree.chart.plot.Plot var7 = var0.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    org.jfree.chart.axis.CategoryAxis var11 = var0.getDomainAxis();
    double var12 = var11.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(false);
//     java.awt.Font var2 = var1.getDefaultLabelFont();
//     java.awt.Paint var3 = var1.getDefaultPaint();
//     java.lang.Boolean var6 = var1.isLabelVisible((-100), (-100));
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    boolean var5 = var3.equals((java.lang.Object)var4);
    java.lang.String var6 = var4.getLabelURL();
    org.jfree.chart.renderer.RenderAttributes var8 = new org.jfree.chart.renderer.RenderAttributes(false);
    java.awt.Font var9 = var8.getDefaultLabelFont();
    java.awt.Paint var10 = var8.getDefaultPaint();
    var4.setLabelPaint(var10);
    org.jfree.chart.util.RectangleInsets var12 = var4.getTickLabelInsets();
    boolean var13 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var14.setTickLabelsVisible(false);
    var14.setMaximumCategoryLabelLines((-1));
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var14.getCategoryStart(10, (-1), var21, var22);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.configureDomainAxes();
    org.jfree.chart.util.SortOrder var26 = var24.getColumnRenderingOrder();
    var14.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
    java.awt.Paint var28 = var24.getRangeCrosshairPaint();
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var31 = var29.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
    var29.setDomainAxis(0, var33);
    boolean var35 = var29.isDomainZoomable();
    org.jfree.chart.plot.Plot var36 = var29.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var37 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var29);
    org.jfree.chart.axis.ValueAxis var39 = var29.getRangeAxis(0);
    boolean var40 = var29.isDomainCrosshairVisible();
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
    var41.setDomainCrosshairVisible(true);
    org.jfree.chart.event.AnnotationChangeEvent var44 = null;
    var41.annotationChanged(var44);
    org.jfree.chart.util.SortOrder var46 = var41.getColumnRenderingOrder();
    var29.setColumnRenderingOrder(var46);
    var24.setRowRenderingOrder(var46);
    var0.sortByObjects(var46);
    java.lang.Object var50 = var0.clone();
    java.lang.Comparable var51 = null;
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis();
    var53.setTickLabelsVisible(false);
    var53.setAxisLineVisible(true);
    java.awt.Paint var58 = var53.getAxisLinePaint();
    var52.setRangeCrosshairPaint(var58);
    float var60 = var52.getBackgroundAlpha();
    java.awt.Paint var61 = var52.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addObject(var51, (java.lang.Object)var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var3 = var1.getDomainAxis(0);
    java.awt.Stroke var4 = var1.getRangeCrosshairStroke();
    var1.setDomainCrosshairVisible(true);
    org.jfree.chart.axis.CategoryAnchor var7 = var1.getDomainGridlinePosition();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var10 = var8.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    var8.setDomainAxis(0, var12);
    boolean var14 = var8.isDomainZoomable();
    org.jfree.chart.plot.Plot var15 = var8.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.axis.ValueAxis var18 = var8.getRangeAxis(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    int var20 = var8.getIndexOf(var19);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.configureDomainAxes();
    java.awt.Paint var23 = var21.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var21.zoomRangeAxes(10.0d, var25, var26, false);
    org.jfree.chart.plot.DrawingSupplier var29 = var21.getDrawingSupplier();
    var8.setDrawingSupplier(var29);
    org.jfree.chart.util.ShadowGenerator var31 = var8.getShadowGenerator();
    boolean var32 = var7.equals((java.lang.Object)var8);
    int var33 = var8.getRangeAxisCount();
    org.jfree.data.KeyedObject var34 = new org.jfree.data.KeyedObject((java.lang.Comparable)14.05d, (java.lang.Object)var33);
    java.lang.Object var35 = var34.getObject();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + 1+ "'", var35.equals(1));

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var4 = var2.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var2.setDomainAxis(0, var6);
    boolean var8 = var2.isDomainZoomable();
    var2.setDomainCrosshairVisible(false);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var2);
    java.lang.Object var12 = var0.clone();
    java.lang.Object var13 = var0.clone();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    var15.setTickLabelsVisible(false);
    var15.setAxisLineVisible(true);
    java.awt.Paint var20 = var15.getAxisLinePaint();
    var14.setRangeCrosshairPaint(var20);
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    var14.drawBackgroundImage(var22, var23);
    boolean var25 = var0.hasListener((java.util.EventListener)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.awt.Paint var2 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(10.0d, var4, var5, false);
    org.jfree.chart.axis.AxisSpace var8 = null;
    var0.setFixedDomainAxisSpace(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue((-14.0d), (java.lang.Comparable)0, (java.lang.Comparable)0L);
    int var6 = var0.getRowIndex((java.lang.Comparable)"CategoryAnchor.MIDDLE");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = null;
    var0.setBaseItemLabelGenerator(var2, true);
    java.awt.Paint var5 = var0.getBaseLegendTextPaint();
    org.jfree.chart.labels.ItemLabelPosition var7 = null;
    var0.setSeriesNegativeItemLabelPosition(4, var7);
    var0.setSeriesVisible(2, (java.lang.Boolean)true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesFilled((-33), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setDomainAxis(100, var3, false);
//     java.util.List var6 = var0.getCategories();
//     boolean var7 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.event.ChartChangeEventType var9 = var8.getType();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.plot.Plot var17 = var10.getRootPlot();
//     org.jfree.chart.event.PlotChangeEvent var18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.axis.ValueAxis var20 = var10.getRangeAxis(0);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.RenderingSource var24 = null;
//     var10.select(8.0d, 10.0d, var23, var24);
//     java.awt.Stroke var26 = var10.getRangeGridlineStroke();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     var27.setDomainAxis(100, var30, false);
//     org.jfree.chart.util.SortOrder var33 = var27.getColumnRenderingOrder();
//     var27.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     var27.drawBackgroundImage(var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis[] var40 = new org.jfree.chart.axis.ValueAxis[] { var39};
//     var27.setRangeAxes(var40);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var45 = var43.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
//     var43.setDomainAxis(0, var47);
//     boolean var49 = var43.isDomainZoomable();
//     var43.setDomainCrosshairVisible(false);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.configureDomainAxes();
//     java.awt.Paint var54 = var52.getDomainGridlinePaint();
//     var43.setRangeZeroBaselinePaint(var54);
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", var54);
//     boolean var57 = var56.isShapeFilled();
//     var56.setLineVisible(false);
//     var56.setURLText("hi!");
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var63 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis();
//     boolean var65 = var63.equals((java.lang.Object)var64);
//     java.lang.String var66 = var64.getLabelURL();
//     org.jfree.chart.axis.CategoryAxis var68 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var70 = var68.getTickLabelPaint((java.lang.Comparable)0);
//     java.awt.Paint var71 = var68.getAxisLinePaint();
//     var64.setTickLabelPaint((java.lang.Comparable)(short)100, var71);
//     var56.setLabelPaint(var71);
//     var27.setRangeGridlinePaint(var71);
//     var10.setOutlinePaint(var71);
//     boolean var76 = var9.equals((java.lang.Object)var10);
//     
//     // Checks the contract:  equals-hashcode on var52 and var0
//     assertTrue("Contract failed: equals-hashcode on var52 and var0", var52.equals(var0) ? var52.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var52 and var0.", var52.equals(var0) == var0.equals(var52));
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("", 1);
//     java.awt.Color var4 = var3.brighter();
//     java.awt.Color var5 = java.awt.Color.getColor("", var4);
//     java.awt.Color var6 = var4.darker();
//     java.awt.Color var7 = var4.brighter();
//     java.awt.color.ColorSpace var8 = null;
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 100);
//     float[] var12 = null;
//     float[] var13 = var11.getComponents(var12);
//     float[] var14 = var7.getComponents(var8, var12);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesVisibleInLegend(0, (java.lang.Boolean)true, true);
//     java.lang.Boolean var6 = var0.getSeriesCreateEntities((-1));
//     org.jfree.chart.annotations.CategoryAnnotation var7 = null;
//     boolean var8 = var0.removeAnnotation(var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var12 = var10.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setDomainAxis(0, var14);
//     boolean var16 = var10.isDomainZoomable();
//     org.jfree.chart.plot.Marker var18 = null;
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var21 = var10.removeDomainMarker(10, var18, var19, false);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = var10.getRendererForDataset(var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.plot.Marker var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var0.drawRangeMarker(var9, var10, var24, var25, var26);
//     java.lang.Boolean var29 = null;
//     var0.setSeriesVisible(10, var29, true);
//     boolean var32 = var0.getBaseSeriesVisibleInLegend();
//     boolean var35 = var0.getItemShapeFilled(1, 100);
//     java.awt.Paint var39 = var0.getItemLabelPaint((-16777116), (-1), false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var41 = var40.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var43 = var40.lookupLegendTextPaint(15);
//     boolean var44 = var40.getBaseSeriesVisibleInLegend();
//     var40.setBaseLinesVisible(true);
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.data.Range var48 = var40.findRangeBounds(var47);
//     org.jfree.chart.labels.CategoryToolTipGenerator var50 = var40.getSeriesToolTipGenerator(0);
//     var40.setAutoPopulateSeriesOutlineStroke(true);
//     var40.setDefaultEntityRadius(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var57 = var56.getBaseSeriesVisibleInLegend();
//     int var58 = var56.getColumnCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var59 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var60 = var59.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var62 = var59.lookupLegendTextPaint(15);
//     boolean var63 = var59.getBaseSeriesVisibleInLegend();
//     var59.setBaseLinesVisible(true);
//     org.jfree.chart.labels.CategoryToolTipGenerator var66 = null;
//     var59.setBaseToolTipGenerator(var66, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var70 = var69.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var72 = var69.lookupLegendTextPaint(15);
//     boolean var73 = var69.getBaseSeriesVisibleInLegend();
//     var69.setBaseShapesVisible(false);
//     boolean var76 = var69.getBaseShapesFilled();
//     org.jfree.chart.labels.ItemLabelPosition var80 = var69.getPositiveItemLabelPosition((-1), 1, true);
//     org.jfree.chart.text.TextAnchor var81 = var80.getTextAnchor();
//     var59.setBaseNegativeItemLabelPosition(var80);
//     var56.setBaseNegativeItemLabelPosition(var80);
//     var40.setSeriesPositiveItemLabelPosition(100, var80, false);
//     org.jfree.chart.text.TextAnchor var86 = var80.getTextAnchor();
//     var0.setBaseNegativeItemLabelPosition(var80);
//     
//     // Checks the contract:  equals-hashcode on var56 and var0
//     assertTrue("Contract failed: equals-hashcode on var56 and var0", var56.equals(var0) ? var56.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var0
//     assertTrue("Contract failed: equals-hashcode on var59 and var0", var59.equals(var0) ? var59.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var56 and var0.", var56.equals(var0) == var0.equals(var56));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var59 and var0.", var59.equals(var0) == var0.equals(var59));
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setTickLabelsVisible(false);
    java.awt.Font var3 = var0.getLabelFont();
    var0.setVisible(false);
    boolean var6 = var0.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     java.awt.Paint var3 = var0.lookupLegendTextPaint(15);
//     boolean var4 = var0.getBaseSeriesVisibleInLegend();
//     var0.setBaseShapesVisible(false);
//     java.awt.Shape var8 = var0.lookupLegendShape(100);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.configureDomainAxes();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setDomainAxis(100, var12, false);
//     org.jfree.chart.util.SortOrder var15 = var9.getColumnRenderingOrder();
//     var9.setBackgroundAlpha((-1.0f));
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var9.drawBackgroundImage(var18, var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var23 = var21.getDomainAxis(0);
//     java.awt.Stroke var24 = var21.getRangeCrosshairStroke();
//     var9.setDomainCrosshairStroke(var24);
//     var9.clearDomainMarkers((-1));
//     org.jfree.chart.entity.PlotEntity var29 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var9, "DatasetRenderingOrder.REVERSE");
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.CategoryAxis var32 = var30.getDomainAxis(0);
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis();
//     var30.setDomainAxis(0, var34);
//     boolean var36 = var30.isDomainZoomable();
//     org.jfree.chart.plot.Plot var37 = var30.getRootPlot();
//     org.jfree.data.category.CategoryDataset var38 = null;
//     int var39 = var30.indexOf(var38);
//     org.jfree.chart.entity.PlotEntity var42 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var30, "TextAnchor.BOTTOM_CENTER", "CategoryAnchor.MIDDLE");
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     var43.configureDomainAxes();
//     java.awt.Paint var45 = var43.getDomainGridlinePaint();
//     java.awt.Stroke var46 = var43.getOutlineStroke();
//     org.jfree.chart.entity.PlotEntity var47 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var43);
//     
//     // Checks the contract:  equals-hashcode on var21 and var43
//     assertTrue("Contract failed: equals-hashcode on var21 and var43", var21.equals(var43) ? var21.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var21
//     assertTrue("Contract failed: equals-hashcode on var43 and var21", var43.equals(var21) ? var43.hashCode() == var21.hashCode() : true);
// 
//   }

}
