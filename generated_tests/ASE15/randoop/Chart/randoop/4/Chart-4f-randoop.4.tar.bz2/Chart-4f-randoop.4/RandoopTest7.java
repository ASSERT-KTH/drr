
import junit.framework.*;

public class RandoopTest7 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test1"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.SerialDate var1 = var0.getSerialDate();
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.SerialDate var4 = var1.getFollowingDayOfWeek(2);
//     org.jfree.data.time.SerialDate var6 = var4.getPreviousDayOfWeek(2);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     org.jfree.data.time.SerialDate var9 = var8.getSerialDate();
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.SerialDate var12 = var9.getFollowingDayOfWeek(2);
//     org.jfree.data.time.SerialDate var14 = var12.getPreviousDayOfWeek(2);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, var12);
//     org.jfree.data.time.SerialDate var16 = var6.getEndOfCurrentMonth(var15);
//     var16.setDescription("PlotOrientation.VERTICAL");
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var16);
//     long var20 = var19.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "20-December-2014"+ "'", var2.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1420012800000L);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test2"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    var0.setShadowVisible(true);
    var0.setMargin(0.5d);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    boolean var9 = var8.getAutoPopulateSeriesOutlinePaint();
    boolean var10 = var8.getDrawOutlines();
    boolean var11 = var8.getAutoPopulateSeriesOutlineStroke();
    var8.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.event.RendererChangeEvent var15 = null;
    var8.notifyListeners(var15);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
    java.awt.Font var25 = var19.getSeriesItemLabelFont(1);
    java.awt.Paint var27 = var19.lookupSeriesOutlinePaint((-1));
    org.jfree.chart.labels.ItemLabelPosition var29 = var19.getSeriesNegativeItemLabelPosition(2);
    double var30 = var29.getAngle();
    var8.setBasePositiveItemLabelPosition(var29);
    var0.setPositiveItemLabelPositionFallback(var29);
    var0.setShadowYOffset(0.0d);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var37.setBaseSeriesVisible(false, false);
    java.awt.Font var42 = null;
    var37.setSeriesItemLabelFont(3, var42, true);
    java.awt.Color var48 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var49 = var48.darker();
    var37.setBaseOutlinePaint((java.awt.Paint)var49);
    java.awt.Shape var51 = var37.getLegendLine();
    var0.setLegendBar(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test3"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    var1.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var15 = var1.getLocale();
    var1.setPositiveArrowVisible(false);
    org.jfree.data.time.RegularTimePeriod var18 = var1.getLast();
    org.jfree.chart.plot.WaferMapPlot var19 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.general.WaferMapDataset var20 = null;
    var19.setDataset(var20);
    boolean var22 = var1.hasListener((java.util.EventListener)var19);
    org.jfree.data.general.WaferMapDataset var23 = null;
    var19.setDataset(var23);
    org.jfree.data.xy.XYSeries var25 = null;
    org.jfree.data.xy.XYSeriesCollection var26 = new org.jfree.data.xy.XYSeriesCollection(var25);
    org.jfree.data.xy.XYSeries var27 = null;
    org.jfree.data.xy.XYSeriesCollection var28 = new org.jfree.data.xy.XYSeriesCollection(var27);
    boolean var29 = var26.hasListener((java.util.EventListener)var28);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var26, var30, var31);
    var32.setForegroundAlpha(100.0f);
    boolean var35 = var32.isAngleLabelsVisible();
    boolean var36 = var32.isAngleLabelsVisible();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var43 = var39.getItemFillPaint(1, (-1), false);
    java.awt.Font var45 = var39.getSeriesItemLabelFont(1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var49 = var48.getDefaultEntityRadius();
    java.awt.Shape var51 = var48.getSeriesShape(1);
    org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var54 = var53.getTickLabelPaint();
    var48.setSeriesOutlinePaint(0, var54);
    var39.setBaseFillPaint(var54, true);
    var32.setRadiusGridlinePaint(var54);
    var32.setOutlineVisible(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var63 = var61.getRenderer(0);
    java.awt.Paint var64 = var61.getDomainCrosshairPaint();
    java.awt.Paint var65 = var61.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var66 = var61.getDomainAxisLocation();
    org.jfree.data.xy.XYSeries var67 = null;
    org.jfree.data.xy.XYSeriesCollection var68 = new org.jfree.data.xy.XYSeriesCollection(var67);
    org.jfree.data.xy.XYSeries var69 = null;
    org.jfree.data.xy.XYSeriesCollection var70 = new org.jfree.data.xy.XYSeriesCollection(var69);
    boolean var71 = var68.hasListener((java.util.EventListener)var70);
    org.jfree.chart.axis.ValueAxis var72 = null;
    org.jfree.chart.renderer.PolarItemRenderer var73 = null;
    org.jfree.chart.plot.PolarPlot var74 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var68, var72, var73);
    var74.setForegroundAlpha(100.0f);
    boolean var77 = var74.isAngleLabelsVisible();
    boolean var78 = var74.isAngleLabelsVisible();
    boolean var79 = var74.isDomainZoomable();
    var61.setParent((org.jfree.chart.plot.Plot)var74);
    org.jfree.chart.event.RendererChangeEvent var81 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var61);
    var32.rendererChanged(var81);
    java.lang.Object var83 = var81.getRenderer();
    java.lang.Object var84 = var81.getSource();
    var19.rendererChanged(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test4"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    org.jfree.chart.plot.PlotRenderingInfo var2 = var1.getPlotInfo();
    java.awt.geom.Rectangle2D var3 = var1.getChartArea();
    java.lang.Object var4 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test5"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setMaximumCategoryLabelLines(3);
    org.jfree.chart.block.LineBorder var8 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var9 = var8.getPaint();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    java.lang.String var12 = var11.getID();
    java.lang.String var13 = var11.getToolTipText();
    org.jfree.chart.util.HorizontalAlignment var14 = var11.getTextAlignment();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle();
    java.lang.String var17 = var16.getID();
    org.jfree.chart.util.RectangleInsets var18 = var16.getPadding();
    var16.setMaximumLinesToDisplay(1);
    var16.setToolTipText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.awt.geom.Rectangle2D var23 = var16.getBounds();
    org.jfree.data.xy.XYDataItem var26 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)12.0d);
    java.lang.Object var27 = var11.draw(var15, var23, (java.lang.Object)100.0d);
    var8.draw(var10, var23);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var31 = var29.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var34 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var35 = var34.getXValue();
    java.lang.String var36 = var34.toString();
    org.jfree.data.xy.XYDataItem var39 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var40 = var39.getXValue();
    var39.setY(0.0d);
    int var43 = var34.compareTo((java.lang.Object)var39);
    java.lang.Number var44 = var39.getX();
    var29.setDomainCrosshairColumnKey((java.lang.Comparable)var39);
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var49 = var47.getRangeAxisLocation(1);
    org.jfree.chart.util.RectangleEdge var50 = var47.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var52 = var47.getDomainAxisLocation(12);
    var29.setDomainAxisLocation(1969, var52);
    org.jfree.chart.util.RectangleEdge var55 = var29.getRangeAxisEdge(1);
    double var56 = var0.getCategorySeriesMiddle(5, 20, (-293504), 5, 0.025d, var23, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "[-1.0, 0.0]"+ "'", var36.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + (byte)(-1)+ "'", var44.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test6"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)1.0d);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.util.Size2D var9 = var7.arrange(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test7"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    java.awt.Shape var13 = var1.getDownArrow();
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    boolean var17 = var15.equals((java.lang.Object)(short)(-1));
    java.lang.Number var18 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var15);
    org.jfree.chart.entity.XYItemEntity var23 = new org.jfree.chart.entity.XYItemEntity(var13, (org.jfree.data.xy.XYDataset)var15, 10, 100, "", "Pie 3D Plot");
    org.jfree.data.general.SeriesChangeEvent var24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)100);
    org.jfree.data.general.SeriesChangeInfo var25 = var24.getSummary();
    org.jfree.data.general.SeriesChangeInfo var26 = null;
    var24.setSummary(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + Double.NaN+ "'", var18.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test8"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var1.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var4 = var1.getTickLabelFont();
    var1.resizeRange2(4.0d, 100.0d);
    java.lang.String var8 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "December 2014"+ "'", var8.equals("December 2014"));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test9"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation(12);
    var0.setRangeCrosshairValue((-1.99999d), true);
    java.lang.String var9 = var0.getPlotType();
    var0.setRangeCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Category Plot"+ "'", var9.equals("Category Plot"));

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test10"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     var2.setBaseSeriesVisible(false, false);
//     java.awt.Paint var6 = var2.getBaseOutlinePaint();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
//     var2.setLegendTextPaint(3, var14);
//     java.lang.Boolean var17 = var2.getSeriesShapesVisible(2);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
//     java.util.List var23 = var20.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     var28.setBaseStroke(var34);
//     var25.setMinorTickMarkStroke(var34);
//     var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var39 = var25.getLocale();
//     var25.setPositiveArrowVisible(false);
//     double var42 = var25.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var25};
//     var20.setDomainAxes(var43);
//     org.jfree.chart.util.RectangleEdge var46 = var20.getRangeAxisEdge(0);
//     org.jfree.data.xy.XYSeries var48 = null;
//     org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
//     org.jfree.data.xy.XYSeries var50 = null;
//     org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
//     boolean var52 = var49.hasListener((java.util.EventListener)var51);
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var54 = null;
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var49, var53, var54);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var55);
//     boolean var57 = var20.equals((java.lang.Object)"");
//     org.jfree.data.xy.XYSeries var58 = null;
//     org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
//     org.jfree.data.xy.XYSeries var60 = null;
//     org.jfree.data.xy.XYSeriesCollection var61 = new org.jfree.data.xy.XYSeriesCollection(var60);
//     boolean var62 = var59.hasListener((java.util.EventListener)var61);
//     double var63 = var61.getIntervalPositionFactor();
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var65 = var2.initialise(var18, var19, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.data.xy.XYDataset)var61, var64);
//     int var66 = var65.getLastItemIndex();
//     org.jfree.chart.plot.XYCrosshairState var67 = new org.jfree.chart.plot.XYCrosshairState();
//     var65.setCrosshairState(var67);
//     org.jfree.data.xy.XYSeries var69 = null;
//     org.jfree.data.xy.XYSeriesCollection var70 = new org.jfree.data.xy.XYSeriesCollection(var69);
//     org.jfree.data.xy.XYSeries var71 = null;
//     org.jfree.data.xy.XYSeriesCollection var72 = new org.jfree.data.xy.XYSeriesCollection(var71);
//     boolean var73 = var70.hasListener((java.util.EventListener)var72);
//     double var75 = var72.getDomainUpperBound(true);
//     boolean var76 = var72.isAutoWidth();
//     var65.startSeriesPass((org.jfree.data.xy.XYDataset)var72, 2147483647, 0, (-237), 15, 2014);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       boolean var85 = var72.isSelected((-524290), 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test11"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
    boolean var2 = var1.getAutoPopulateSeriesStroke();
    java.lang.Object var3 = var1.clone();
    boolean var4 = var1.getShapesVisible();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var7.setBaseSeriesVisible(false, false);
    java.awt.Font var12 = null;
    var7.setSeriesItemLabelFont(3, var12, true);
    java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var19 = var18.darker();
    var7.setBaseOutlinePaint((java.awt.Paint)var19);
    org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var22 = var21.getFont();
    var7.setBaseLegendTextFont(var22);
    org.jfree.chart.renderer.xy.XYBarRenderer var24 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var25 = var24.getNegativeItemLabelPositionFallback();
    var24.setShadowVisible(true);
    var24.setMargin(0.5d);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    boolean var33 = var32.getAutoPopulateSeriesOutlinePaint();
    boolean var34 = var32.getDrawOutlines();
    boolean var35 = var32.getAutoPopulateSeriesOutlineStroke();
    var32.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.event.RendererChangeEvent var39 = null;
    var32.notifyListeners(var39);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var47 = var43.getItemFillPaint(1, (-1), false);
    java.awt.Font var49 = var43.getSeriesItemLabelFont(1);
    java.awt.Paint var51 = var43.lookupSeriesOutlinePaint((-1));
    org.jfree.chart.labels.ItemLabelPosition var53 = var43.getSeriesNegativeItemLabelPosition(2);
    double var54 = var53.getAngle();
    var32.setBasePositiveItemLabelPosition(var53);
    var24.setPositiveItemLabelPositionFallback(var53);
    var7.setBaseNegativeItemLabelPosition(var53);
    boolean var60 = var7.getItemShapeFilled(1, (-237));
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var63 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var63.setBaseSeriesVisible(false, false);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var67 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    var63.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var67);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var71 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var71.setBaseSeriesVisible(false, false);
    java.awt.Paint var75 = var71.getBaseOutlinePaint();
    boolean var76 = var67.equals((java.lang.Object)var71);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var79 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var79.setBaseSeriesVisible(false, false);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var83 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    var79.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var83);
    var71.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var83);
    org.jfree.chart.labels.ItemLabelPosition var86 = var71.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var87 = var86.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var88 = var86.getRotationAnchor();
    var7.setBasePositiveItemLabelPosition(var86, false);
    boolean var91 = var1.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test12"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint((-1));
    org.jfree.chart.StandardChartTheme var7 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
    var8.setLabelPaint(var16);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var24 = var20.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
    var20.setBaseStroke(var26);
    var8.setLabelOutlineStroke(var26);
    double var29 = var8.getInteriorGap();
    java.awt.Paint var30 = var8.getLabelShadowPaint();
    var7.setPlotOutlinePaint(var30);
    org.jfree.chart.plot.IntervalMarker var32 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.08d, var30);
    var0.setPaint(10, var30);
    java.awt.Paint var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-1), var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test13"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.chart.axis.CategoryAnchor var3 = var0.getDomainGridlinePosition();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var7 = var5.getRangeAxisLocation(1);
    var0.setRangeAxisLocation(0, var7, false);
    var0.clearDomainMarkers((-3));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test14"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(90.0d);
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1);
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var7 = var6.getItemCount();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year(1);
//     java.util.Date var10 = var9.getStart();
//     var6.add((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)Double.NaN, true);
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     var4.setMaximumItemAge(0L);
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange();
//     java.lang.String var20 = var19.toString();
//     var18.setRangeWithMargins((org.jfree.data.Range)var19);
//     java.util.Date var22 = var19.getLowerDate();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var22);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)2, true);
//     int var27 = var23.getMonth();
//     int var28 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var20.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test15"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    var0.clearSectionOutlinePaints(false);
    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder();
    boolean var5 = var0.equals((java.lang.Object)var4);
    java.awt.Stroke var6 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    org.jfree.chart.event.AxisChangeEvent var9 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var8);
    var0.axisChanged(var9);
    java.awt.Paint var11 = var0.getLabelLinkPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test16"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setIncludeBaseInRange(true);
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var6 = var5.getPlot();
    org.jfree.chart.plot.CategoryPlot var7 = var5.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var5.setSeriesURLGenerator(2, var9, true);
    double var12 = var5.getXOffset();
    org.jfree.chart.labels.ItemLabelPosition var16 = var5.getPositiveItemLabelPosition(68, 10, false);
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var20 = var19.getPlot();
    org.jfree.chart.plot.CategoryPlot var21 = var19.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var23 = null;
    var19.setSeriesURLGenerator(2, var23, true);
    org.jfree.chart.urls.CategoryURLGenerator var27 = null;
    var19.setSeriesURLGenerator(10, var27);
    var19.setMinimumBarLength(1.0d);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var31 = null;
    var19.setLegendItemToolTipGenerator(var31);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = var19.getLegendItemLabelGenerator();
    var5.setLegendItemLabelGenerator(var33);
    var0.setLegendItemToolTipGenerator(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test17"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var5 = var0.getDataset(1);
    int var6 = var0.getWeight();
    int var7 = var0.getDatasetCount();
    var0.setBackgroundImageAlignment((-16777216));
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = var11.getRenderer(0);
    java.awt.Paint var14 = var11.getDomainCrosshairPaint();
    java.awt.Paint var15 = var11.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var16 = var11.getDomainAxisLocation();
    java.awt.Paint var17 = var11.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation();
    var0.setDomainAxisLocation(68, var18, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test18"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    org.jfree.data.xy.XYSeries var15 = null;
    org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
    boolean var17 = var14.hasListener((java.util.EventListener)var16);
    boolean var18 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
    java.lang.String var20 = var19.getID();
    org.jfree.chart.util.RectangleInsets var21 = var19.getPadding();
    var1.setLabelInsets(var21);
    var1.resizeRange2((-1.0d), (-1.88d));
    double var26 = var1.getAutoRangeMinimumSize();
    org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("[-1.0, 0.0]");
    float var29 = var28.getMinorTickMarkOutsideLength();
    java.lang.Class var30 = var28.getMajorTickTimePeriodClass();
    var1.setMinorTickTimePeriodClass(var30);
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.lang.Object var34 = var33.clone();
    org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle();
    java.lang.String var36 = var35.getID();
    org.jfree.chart.util.RectangleInsets var37 = var35.getPadding();
    double var39 = var37.trimWidth(1.0E-5d);
    var33.setPadding(var37);
    var1.setLabelInsets(var37, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1.99999d));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test19"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
    var2.setBaseStroke(var8);
    org.jfree.chart.annotations.XYAnnotation var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addAnnotation(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test20"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var1.setBarPainter(var26);
//     java.awt.Font var28 = var1.getExtraLargeFont();
//     java.awt.Paint var29 = var1.getCrosshairPaint();
//     java.awt.Paint var30 = var1.getSubtitlePaint();
//     org.jfree.chart.StandardChartTheme var32 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.StandardChartTheme var34 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var35 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var36 = var35.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var43 = var39.getItemFillPaint(1, (-1), false);
//     var35.setLabelPaint(var43);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var51 = var47.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var53 = var52.getBaseSectionOutlineStroke();
//     var47.setBaseStroke(var53);
//     var35.setLabelOutlineStroke(var53);
//     double var56 = var35.getInteriorGap();
//     java.awt.Paint var57 = var35.getLabelShadowPaint();
//     var34.setPlotOutlinePaint(var57);
//     java.awt.Font var59 = var34.getLargeFont();
//     var32.setSmallFont(var59);
//     var1.setRegularFont(var59);
//     
//     // Checks the contract:  equals-hashcode on var2 and var35
//     assertTrue("Contract failed: equals-hashcode on var2 and var35", var2.equals(var35) ? var2.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var52
//     assertTrue("Contract failed: equals-hashcode on var19 and var52", var19.equals(var52) ? var19.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var2
//     assertTrue("Contract failed: equals-hashcode on var35 and var2", var35.equals(var2) ? var35.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var19
//     assertTrue("Contract failed: equals-hashcode on var52 and var19", var52.equals(var19) ? var52.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test21"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     var5.setBaseStroke(var11);
//     var2.setMinorTickMarkStroke(var11);
//     var2.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var16 = var2.getLocale();
//     org.jfree.chart.axis.TickUnitSource var17 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var16);
//     java.text.NumberFormat var18 = java.text.NumberFormat.getPercentInstance(var16);
//     org.jfree.chart.axis.TickUnitSource var19 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var16);
//     java.lang.ClassLoader var20 = null;
//     java.util.ResourceBundle.Control var21 = null;
//     java.util.ResourceBundle var22 = java.util.ResourceBundle.getBundle("PieLabelLinkStyle.CUBIC_CURVE", var16, var20, var21);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test22"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    java.awt.Stroke var18 = var0.getDomainGridlineStroke();
    var0.setBackgroundAlpha(2.0f);
    var0.clearDomainMarkers();
    var0.setDomainGridlinesVisible(false);
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test23"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.util.RectangleEdge var1 = var0.getRangeAxisEdge();
    var0.setDomainGridlinesVisible(false);
    boolean var4 = var0.isDomainMinorGridlinesVisible();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var7 = var5.getRangeAxisLocation(1);
    org.jfree.chart.util.RectangleEdge var8 = var5.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation(12);
    var0.setDomainAxisLocation(var10);
    int var12 = var0.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test24"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    boolean var2 = var0.equals((java.lang.Object)1.0f);
    org.jfree.chart.util.VerticalAlignment var3 = var0.getVerticalAlignment();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.util.HorizontalAlignment var6 = var4.getTextAlignment();
    boolean var8 = var6.equals((java.lang.Object)(-1L));
    var0.setTextAlignment(var6);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    boolean var12 = var10.equals((java.lang.Object)1.0f);
    org.jfree.chart.util.VerticalAlignment var13 = var10.getVerticalAlignment();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var15 = var14.clone();
    org.jfree.chart.util.HorizontalAlignment var16 = var14.getTextAlignment();
    boolean var18 = var16.equals((java.lang.Object)(-1L));
    var10.setTextAlignment(var16);
    var0.setTextAlignment(var16);
    java.awt.Font var21 = var0.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test25"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var9.setAntiAlias(true);
    java.awt.Image var12 = var9.getBackgroundImage();
    java.lang.Object var13 = var9.getTextAntiAlias();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeEvent var15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var14);
    var9.titleChanged(var15);
    org.jfree.chart.event.ChartChangeEventType var17 = var15.getType();
    org.jfree.chart.title.Title var18 = var15.getTitle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test26"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    int var5 = var2.getColumnCount();
    java.lang.Boolean var7 = var2.getSeriesVisibleInLegend(1);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    java.lang.String var12 = var11.getID();
    org.jfree.chart.util.RectangleInsets var13 = var11.getPadding();
    var11.setMaximumLinesToDisplay(1);
    var11.setToolTipText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.awt.geom.Rectangle2D var18 = var11.getBounds();
    java.awt.geom.Point2D var19 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(Double.POSITIVE_INFINITY, 12.0d, var18);
    var2.setLegendShape(96, (java.awt.Shape)var18);
    org.jfree.data.general.DefaultPieDataset var21 = new org.jfree.data.general.DefaultPieDataset();
    int var23 = var21.getIndex((java.lang.Comparable)1969);
    org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var28 = var27.getItemCount();
    java.lang.Object var29 = var27.clone();
    var27.setNotify(true);
    long var32 = var27.getMaximumItemAge();
    org.jfree.data.time.Year var34 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, 1.0d);
    java.lang.Object var37 = var36.clone();
    var27.add(var36, false);
    org.jfree.chart.entity.PieSectionEntity var42 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape)var18, (org.jfree.data.general.PieDataset)var21, 96, 96, (java.lang.Comparable)var36, "Value", "ChartChangeEventType.GENERAL");
    java.lang.String var43 = var42.toString();
    java.lang.String var44 = var42.toString();
    var42.setSectionIndex(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test27"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.data.xy.XYSeries var6 = null;
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
    org.jfree.data.xy.XYSeries var8 = null;
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
    boolean var10 = var7.hasListener((java.util.EventListener)var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var7, var11, var12);
    java.awt.Paint var14 = var13.getRadiusGridlinePaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = var15.getRenderer(0);
    java.awt.Paint var18 = var15.getDomainCrosshairPaint();
    java.awt.Paint var19 = var15.getRangeMinorGridlinePaint();
    java.awt.Paint var20 = var15.getNoDataMessagePaint();
    var13.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
    boolean var22 = var2.hasListener((java.util.EventListener)var15);
    double var23 = var15.getGap();
    java.awt.Paint var24 = var15.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test28"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var4 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var5 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var3, var4);
    var3.setMinimumIntegerDigits(10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1, var3);
    java.lang.String var10 = var3.format(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var12 = var3.parseObject("");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0,000,000,000%"+ "'", var10.equals("0,000,000,000%"));

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test29"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    var2.setBaseSeriesVisible(true);
    var2.setDrawOutlines(true);
    org.jfree.chart.renderer.xy.XYBarRenderer var11 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var11.getNegativeItemLabelPositionFallback();
    var11.setShadowVisible(true);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var21 = var17.getItemFillPaint(1, (-1), false);
    java.awt.Font var23 = var17.getSeriesItemLabelFont(1);
    java.awt.Paint var25 = var17.lookupSeriesOutlinePaint((-1));
    org.jfree.chart.labels.ItemLabelPosition var27 = var17.getSeriesNegativeItemLabelPosition(2);
    double var28 = var27.getAngle();
    var11.setNegativeItemLabelPositionFallback(var27);
    var2.setBaseNegativeItemLabelPosition(var27);
    java.text.NumberFormat var32 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var33 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var34 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var32, var33);
    java.text.NumberFormat var35 = var34.getYFormat();
    var2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var34, false);
    java.text.DateFormat var38 = var34.getXDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test30"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    var2.setMinimumFractionDigits(1969);
    var2.setMaximumFractionDigits(3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var2.parse("0,0,-2,2,2,2,2,2");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test31"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var2 = var1.getAdjustForDaylightSaving();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(1);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange(var5, var8);
    long var10 = var1.toTimelineValue(var5);
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10, false);
    org.jfree.data.category.CategoryDataset var13 = var0.getDataset();
    org.jfree.chart.plot.PlotOrientation var14 = var0.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-17478676800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test32"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("ChartChangeEventType.GENERAL");
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    org.jfree.chart.axis.NumberTickUnit var4 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test33"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var2.setSeriesURLGenerator(10, var10);
    java.awt.Paint var15 = var2.getItemOutlinePaint(10, 96, false);
    int var16 = var2.getColumnCount();
    org.jfree.chart.LegendItem var19 = var2.getLegendItem(0, 96);
    org.jfree.chart.urls.CategoryURLGenerator var21 = var2.getSeriesURLGenerator(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test34"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    var1.setPlotOutlinePaint(var24);
    java.awt.Font var26 = var1.getLargeFont();
    java.awt.Paint var27 = var1.getAxisLabelPaint();
    java.awt.Paint var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setErrorIndicatorPaint(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test35"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var2 = var1.getAdjustForDaylightSaving();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(1);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange(var5, var8);
    long var10 = var1.toTimelineValue(var5);
    var0.setTimeline((org.jfree.chart.axis.Timeline)var1);
    org.jfree.chart.axis.DateTickMarkPosition var12 = var0.getTickMarkPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-17478676800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test36"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    var0.clearSectionOutlinePaints(false);
    double var4 = var0.getMaximumLabelWidth();
    var0.setPieIndex(100);
    org.jfree.chart.StandardChartTheme var8 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
    var9.setLabelPaint(var17);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var25 = var21.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
    var21.setBaseStroke(var27);
    var9.setLabelOutlineStroke(var27);
    double var30 = var9.getInteriorGap();
    java.awt.Paint var31 = var9.getLabelShadowPaint();
    var8.setPlotOutlinePaint(var31);
    org.jfree.chart.renderer.category.BarPainter var33 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var8.setBarPainter(var33);
    java.awt.Font var35 = var8.getExtraLargeFont();
    java.awt.Paint var36 = var8.getCrosshairPaint();
    var0.setLabelPaint(var36);
    org.jfree.chart.plot.PieLabelLinkStyle var38 = var0.getLabelLinkStyle();
    var0.setMinimumArcAngleToDraw(2.0d);
    double var41 = var0.getStartAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 90.0d);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test37"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var4, true);
    org.jfree.data.xy.XYSeries var13 = var10.createCopy((-1), 1);
    org.jfree.data.xy.XYDataItem var16 = var10.addOrUpdate((java.lang.Number)1.0E-5d, (java.lang.Number)(short)(-1));
    var10.setMaximumItemCount(0);
    int var20 = var10.indexOf((java.lang.Number)0.0d);
    var10.setDescription("[size=90]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test38"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var4.setBaseSeriesVisible(false, false);
    java.awt.Font var9 = null;
    var4.setSeriesItemLabelFont(3, var9, true);
    org.jfree.chart.labels.ItemLabelPosition var12 = var4.getBasePositiveItemLabelPosition();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    var0.setPositiveItemLabelPositionFallback(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var18 = var17.getItemCount();
    org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(1);
    java.util.Date var21 = var20.getStart();
    var17.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var26 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var20, true);
    org.jfree.data.xy.XYSeries var29 = var26.createCopy((-1), 1);
    boolean var30 = var0.equals((java.lang.Object)var26);
    double var31 = var0.getShadowXOffset();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var36 = var35.getDefaultEntityRadius();
    java.awt.Shape var38 = var35.getSeriesShape(1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
    var42.setSeriesOutlineStroke(0, var45, true);
    var35.setSeriesOutlineStroke(2, var45);
    var0.setSeriesOutlineStroke(1, var45, true);
    org.jfree.chart.annotations.XYAnnotation var51 = null;
    boolean var52 = var0.removeAnnotation(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test39"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange(0.0d, Double.NaN);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.lang.String var5 = var4.getID();
    org.jfree.chart.util.RectangleInsets var6 = var4.getPadding();
    double var7 = var6.getTop();
    double var8 = var6.getBottom();
    var0.setLabelInsets(var6, true);
    java.lang.String var11 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test40"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(0.12d, "{0}: ({1}, {2})", "0,000,000,000%", true);
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d, (java.text.NumberFormat)var5, 255);
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
    var12.setBaseStroke(var18);
    var9.setMinorTickMarkStroke(var18);
    var9.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var23 = var9.getLocale();
    org.jfree.chart.axis.TickUnitSource var24 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var23);
    java.text.NumberFormat var25 = java.text.NumberFormat.getPercentInstance(var23);
    boolean var26 = var5.equals((java.lang.Object)var23);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var29 = var27.getRangeAxisLocation(1);
    org.jfree.chart.util.RectangleEdge var30 = var27.getRangeAxisEdge();
    org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.chart.plot.PlotRenderingInfo var34 = var33.getPlotInfo();
    org.jfree.chart.plot.CrosshairState var35 = new org.jfree.chart.plot.CrosshairState();
    var35.updateCrosshairY((-1.0d));
    org.jfree.chart.plot.CrosshairState var38 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var45 = null;
    var38.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var45);
    var38.updateCrosshairX(90.0d);
    org.jfree.chart.plot.CrosshairState var49 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.data.xy.XYSeries var50 = null;
    org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
    org.jfree.data.xy.XYSeries var52 = null;
    org.jfree.data.xy.XYSeriesCollection var53 = new org.jfree.data.xy.XYSeriesCollection(var52);
    boolean var54 = var51.hasListener((java.util.EventListener)var53);
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.PolarItemRenderer var56 = null;
    org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var51, var55, var56);
    org.jfree.chart.plot.PlotRenderingInfo var60 = null;
    java.awt.geom.Rectangle2D var61 = null;
    org.jfree.chart.util.RectangleAnchor var62 = null;
    java.awt.geom.Point2D var63 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var62);
    var57.zoomDomainAxes(100.0d, (-1.0d), var60, var63);
    var49.setAnchor(var63);
    var38.setAnchor(var63);
    var35.setAnchor(var63);
    var27.zoomDomainAxes(0.0d, 2.0d, var34, var63);
    java.awt.geom.Rectangle2D var69 = var34.getDataArea();
    boolean var70 = var5.equals((java.lang.Object)var69);
    java.text.NumberFormat var71 = java.text.NumberFormat.getNumberInstance();
    java.util.Currency var72 = var71.getCurrency();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setCurrency(var72);
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test41"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     boolean var2 = var0.equals(var1);
//     int var3 = var0.getYear();
//     int var4 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test42"); }
// 
// 
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.08d, (-1.99999d));
//     org.jfree.data.Range var3 = var2.getWidthRange();
//     double var4 = var2.getWidth();
//     org.jfree.chart.block.LengthConstraintType var5 = var2.getWidthConstraintType();
//     org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var10.setBaseStroke(var16);
//     var7.setMinorTickMarkStroke(var16);
//     org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange();
//     var7.setRangeWithMargins((org.jfree.data.Range)var19);
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     java.lang.String var22 = var21.toString();
//     var7.setRange((org.jfree.data.Range)var21);
//     org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange();
//     java.lang.String var25 = var24.toString();
//     boolean var26 = var21.intersects((org.jfree.data.Range)var24);
//     org.jfree.data.Range var28 = org.jfree.data.Range.shift((org.jfree.data.Range)var24, (-6.21357408E13d));
//     org.jfree.chart.block.RectangleConstraint var29 = var2.toRangeWidth(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.08d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var25.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test43"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var2.setSeriesURLGenerator(10, var10);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var2.getBaseItemLabelGenerator();
    var2.setShadowVisible(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = null;
    var2.setSeriesToolTipGenerator(5, var16, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test44"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(4);
//     long var2 = var1.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-62009510400001L));
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test45"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    var1.setPlotOutlinePaint(var24);
    org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var1.setBarPainter(var26);
    org.jfree.data.xy.XYSeries var28 = null;
    org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
    org.jfree.data.xy.XYSeries var30 = null;
    org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
    boolean var32 = var29.hasListener((java.util.EventListener)var31);
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var29, var33, var34);
    var35.setForegroundAlpha(100.0f);
    var35.setAngleGridlinesVisible(true);
    java.awt.Paint var40 = var35.getBackgroundPaint();
    var1.setGridBandAlternatePaint(var40);
    org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var42);
    org.jfree.chart.plot.PieLabelLinkStyle var44 = var1.getLabelLinkStyle();
    java.awt.Font var45 = var1.getLargeFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test46"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1);
    java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test47"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    var0.setShadowVisible(true);
    double var4 = var0.getBarAlignmentFactor();
    boolean var5 = var0.isDrawBarOutline();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test48"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var9 = var8.getItemCount();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(1);
//     java.util.Date var12 = var11.getStart();
//     var8.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var11, true);
//     var3.addSeries(var17);
//     var17.add(0.08d, (java.lang.Number)1.0d, true);
//     var17.add(12.0d, (java.lang.Number)0.12d);
//     var17.add(0.0d, (java.lang.Number)0.0d);
//     org.jfree.data.xy.XYDataItem var30 = var17.remove(0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test49"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat((-5.95d), "20-December-2014", "PlotEntity: tooltip = null", true);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test50"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    java.awt.Paint var25 = var0.getDomainCrosshairPaint();
    boolean var26 = var0.isDomainMinorGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var28 = var0.getDomainAxisLocation(100);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = var0.getRendererForDataset(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test51"); }


    org.jfree.chart.util.PaintMap var0 = new org.jfree.chart.util.PaintMap();
    java.awt.Paint var2 = var0.getPaint((java.lang.Comparable)12.0d);
    org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
    java.lang.Object var4 = null;
    boolean var5 = var3.equals(var4);
    java.awt.Paint var6 = var0.getPaint((java.lang.Comparable)var5);
    java.awt.Paint var8 = var0.getPaint((java.lang.Comparable)(-6.21357408E13d));
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test52"); }


    java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    java.text.NumberFormat var5 = var4.getYFormat();
    java.text.DateFormat var6 = var4.getXDateFormat();
    org.jfree.chart.urls.StandardXYURLGenerator var10 = new org.jfree.chart.urls.StandardXYURLGenerator("$0.00", "DomainOrder.NONE", "");
    java.awt.Shape var15 = null;
    org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var18 = null;
    org.jfree.data.xy.XYSeriesCollection var19 = new org.jfree.data.xy.XYSeriesCollection(var18);
    org.jfree.data.xy.XYSeries var20 = null;
    org.jfree.data.xy.XYSeriesCollection var21 = new org.jfree.data.xy.XYSeriesCollection(var20);
    boolean var22 = var19.hasListener((java.util.EventListener)var21);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var19, var23, var24);
    java.awt.Paint var26 = var25.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var15, var17, var26);
    java.lang.String var28 = var27.getDescription();
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    boolean var30 = var27.equals((java.lang.Object)var29);
    org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var33 = var32.getItemCount();
    org.jfree.data.time.Year var35 = new org.jfree.data.time.Year(1);
    java.util.Date var36 = var35.getStart();
    var32.add((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var40 = null;
    org.jfree.data.xy.XYSeriesCollection var41 = new org.jfree.data.xy.XYSeriesCollection(var40);
    org.jfree.data.xy.XYSeries var42 = null;
    org.jfree.data.xy.XYSeriesCollection var43 = new org.jfree.data.xy.XYSeriesCollection(var42);
    boolean var44 = var41.hasListener((java.util.EventListener)var43);
    double var45 = var43.getIntervalPositionFactor();
    var32.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var43);
    var27.setDataset((org.jfree.data.general.Dataset)var43);
    java.lang.String var50 = var10.generateURL((org.jfree.data.xy.XYDataset)var43, 100, (-16777216));
    org.jfree.chart.renderer.xy.XYAreaRenderer var51 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var10);
    boolean var52 = var51.getUseFillPaint();
    var51.setUseFillPaint(false);
    org.jfree.chart.plot.PiePlot3D var59 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.data.general.DatasetGroup var60 = var59.getDatasetGroup();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var63 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var63.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var69 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var73 = var69.getItemFillPaint(1, (-1), false);
    var63.setBaseLegendTextPaint(var73);
    var59.setLabelLinkPaint(var73);
    org.jfree.chart.block.BlockBorder var76 = new org.jfree.chart.block.BlockBorder(100.0d, 10.0d, 0.14d, 100.0d, var73);
    var51.setBaseOutlinePaint(var73, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Pie 3D Plot"+ "'", var28.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + "$0.00?DomainOrder.NONE=100&amp;=-16777216"+ "'", var50.equals("$0.00?DomainOrder.NONE=100&amp;=-16777216"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test53"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("[size=0.025]", var1, 0.025d, 0.8f, 100.0f);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test54"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    var1.setPlotOutlinePaint(var24);
    org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var1.setBarPainter(var26);
    java.lang.String var28 = var1.getName();
    java.awt.Font var29 = var1.getLargeFont();
    org.jfree.chart.plot.PieLabelLinkStyle var30 = var1.getLabelLinkStyle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "[-1.0, 0.0]"+ "'", var28.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test55"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d);
    var0.clearDomainMarkers();
    java.util.List var21 = var0.getAnnotations();
    int var22 = var0.getCrosshairDatasetIndex();
    org.jfree.data.category.CategoryDataset var23 = var0.getDataset();
    org.jfree.chart.StandardChartTheme var25 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var34 = var30.getItemFillPaint(1, (-1), false);
    var26.setLabelPaint(var34);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var42 = var38.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var44 = var43.getBaseSectionOutlineStroke();
    var38.setBaseStroke(var44);
    var26.setLabelOutlineStroke(var44);
    double var47 = var26.getInteriorGap();
    java.awt.Paint var48 = var26.getLabelShadowPaint();
    var25.setPlotOutlinePaint(var48);
    org.jfree.chart.renderer.category.BarPainter var50 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var25.setBarPainter(var50);
    org.jfree.data.xy.XYSeries var52 = null;
    org.jfree.data.xy.XYSeriesCollection var53 = new org.jfree.data.xy.XYSeriesCollection(var52);
    org.jfree.data.xy.XYSeries var54 = null;
    org.jfree.data.xy.XYSeriesCollection var55 = new org.jfree.data.xy.XYSeriesCollection(var54);
    boolean var56 = var53.hasListener((java.util.EventListener)var55);
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.renderer.PolarItemRenderer var58 = null;
    org.jfree.chart.plot.PolarPlot var59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var53, var57, var58);
    var59.setForegroundAlpha(100.0f);
    var59.setAngleGridlinesVisible(true);
    java.awt.Paint var64 = var59.getBackgroundPaint();
    var25.setGridBandAlternatePaint(var64);
    java.awt.Paint var66 = var25.getShadowPaint();
    var0.setRangeMinorGridlinePaint(var66);
    org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var70 = var69.getOutlineStroke();
    org.jfree.chart.util.Layer var71 = null;
    boolean var72 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var69, var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test56"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    boolean var1 = var0.getGenerateEntities();
    double var2 = var0.getTranslateY();
    var0.setGenerateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test57"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.annotations.XYAnnotation var7 = null;
    boolean var8 = var2.removeAnnotation(var7);
    java.awt.Paint var10 = var2.lookupSeriesFillPaint(96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test58"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.plot.CombinedRangeXYPlot var5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var6 = null;
    var5.plotChanged(var6);
    java.util.List var8 = var5.getSubplots();
    org.jfree.chart.axis.AxisLocation var10 = var5.getDomainAxisLocation(1969);
    var0.setDomainAxisLocation(2, var10);
    var0.configureDomainAxes();
    var0.setRangeCrosshairVisible(true);
    java.awt.Paint var15 = var0.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test59"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var1.setBarPainter(var26);
//     org.jfree.data.xy.XYSeries var28 = null;
//     org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     boolean var32 = var29.hasListener((java.util.EventListener)var31);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var29, var33, var34);
//     var35.setForegroundAlpha(100.0f);
//     var35.setAngleGridlinesVisible(true);
//     java.awt.Paint var40 = var35.getBackgroundPaint();
//     var1.setGridBandAlternatePaint(var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = var1.getDrawingSupplier();
//     java.awt.Color var46 = java.awt.Color.getHSBColor((-1.0f), (-1.0f), (-1.0f));
//     var1.setErrorIndicatorPaint((java.awt.Paint)var46);
//     java.awt.Paint var48 = var1.getTickLabelPaint();
//     org.jfree.chart.plot.DrawingSupplier var49 = var1.getDrawingSupplier();
//     
//     // Checks the contract:  equals-hashcode on var42 and var49
//     assertTrue("Contract failed: equals-hashcode on var42 and var49", var42.equals(var49) ? var42.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var42
//     assertTrue("Contract failed: equals-hashcode on var49 and var42", var49.equals(var42) ? var49.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test60"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    var2.setLegendTextPaint(3, var14);
    java.lang.Boolean var17 = var2.getSeriesShapesVisible(2);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
    java.util.List var23 = var20.getSubplots();
    org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
    var28.setBaseStroke(var34);
    var25.setMinorTickMarkStroke(var34);
    var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var39 = var25.getLocale();
    var25.setPositiveArrowVisible(false);
    double var42 = var25.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var25};
    var20.setDomainAxes(var43);
    org.jfree.chart.util.RectangleEdge var46 = var20.getRangeAxisEdge(0);
    org.jfree.data.xy.XYSeries var48 = null;
    org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
    org.jfree.data.xy.XYSeries var50 = null;
    org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
    boolean var52 = var49.hasListener((java.util.EventListener)var51);
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var49, var53, var54);
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var55);
    boolean var57 = var20.equals((java.lang.Object)"");
    org.jfree.data.xy.XYSeries var58 = null;
    org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
    org.jfree.data.xy.XYSeries var60 = null;
    org.jfree.data.xy.XYSeriesCollection var61 = new org.jfree.data.xy.XYSeriesCollection(var60);
    boolean var62 = var59.hasListener((java.util.EventListener)var61);
    double var63 = var61.getIntervalPositionFactor();
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var65 = var2.initialise(var18, var19, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.data.xy.XYDataset)var61, var64);
    org.jfree.chart.renderer.xy.XYItemRenderer var67 = var20.getRenderer(3);
    java.awt.Stroke var68 = var20.getDomainMinorGridlineStroke();
    java.awt.Paint var69 = var20.getRangeMinorGridlinePaint();
    org.jfree.chart.annotations.XYAnnotation var70 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var72 = var20.removeAnnotation(var70, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test61"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var1 = var0.getTickLabelPaint();
    java.lang.String var2 = var0.getLabel();
    var0.setFixedDimension(Double.NaN);
    var0.setFixedDimension(100.0d);
    var0.setLabelAngle((-3.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test62"); }


    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    java.awt.Font var25 = var2.getLabelFont();
    org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = var27.getRenderer(0);
    java.awt.Paint var30 = var27.getDomainCrosshairPaint();
    java.awt.Paint var31 = var27.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var32 = var27.getDomainAxisLocation();
    java.awt.Paint var33 = var27.getDomainZeroBaselinePaint();
    var26.setRangeTickBandPaint(var33);
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("Pie 3D Plot", var25, var33, 0.0f);
    org.jfree.chart.util.ObjectList var37 = new org.jfree.chart.util.ObjectList();
    org.jfree.data.xy.XYSeries var38 = null;
    org.jfree.data.xy.XYSeriesCollection var39 = new org.jfree.data.xy.XYSeriesCollection(var38);
    org.jfree.data.xy.XYSeries var40 = null;
    org.jfree.data.xy.XYSeriesCollection var41 = new org.jfree.data.xy.XYSeriesCollection(var40);
    boolean var42 = var39.hasListener((java.util.EventListener)var41);
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.PolarItemRenderer var44 = null;
    org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var39, var43, var44);
    org.jfree.chart.axis.TickUnit var46 = var45.getAngleTickUnit();
    org.jfree.chart.event.PlotChangeListener var47 = null;
    var45.addChangeListener(var47);
    var45.setAngleLabelsVisible(false);
    boolean var51 = var37.equals((java.lang.Object)var45);
    boolean var52 = var36.equals((java.lang.Object)var45);
    java.awt.Font var53 = var45.getAngleLabelFont();
    org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test63"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var1 = var0.getAdjustForDaylightSaving();
    org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(1);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
    java.util.Date var7 = var6.getStart();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange(var4, var7);
    long var9 = var0.toTimelineValue(var4);
    int var10 = var0.getSegmentsExcluded();
    org.jfree.chart.axis.SegmentedTimeline.Segment var12 = var0.getSegment(0L);
    var0.setAdjustForDaylightSaving(false);
    org.jfree.chart.axis.AxisState var16 = new org.jfree.chart.axis.AxisState((-6.21357408E13d));
    var16.cursorDown((-6.21357408E13d));
    var16.cursorRight(0.2d);
    java.util.List var21 = var16.getTicks();
    var0.addExceptions(var21);
    int var23 = var0.getGroupSegmentCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-17478676800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 96);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test64"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("{0}: ({1}, {2})", "", "$0.00?DomainOrder.NONE=31&amp;=255", "PlotEntity: tooltip = Pie 3D Plot");

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test65"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(0.12d, "{0}: ({1}, {2})", "0,000,000,000%", true);
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d, (java.text.NumberFormat)var5, 255);
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
    var12.setBaseStroke(var18);
    var9.setMinorTickMarkStroke(var18);
    var9.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var23 = var9.getLocale();
    org.jfree.chart.axis.TickUnitSource var24 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var23);
    java.text.NumberFormat var25 = java.text.NumberFormat.getPercentInstance(var23);
    boolean var26 = var5.equals((java.lang.Object)var23);
    java.text.NumberFormat var29 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var30 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var31 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var29, var30);
    var30.setMaximumFractionDigits(0);
    java.text.NumberFormat var35 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var37 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var38 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var39 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var37, var38);
    var37.setMinimumIntegerDigits(10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var42 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var35, var37);
    org.jfree.chart.labels.StandardPieToolTipGenerator var43 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var30, var35);
    var5.setExponentFormat(var35);
    java.text.ParsePosition var46 = null;
    java.lang.Number var47 = var5.parse("ThreadContext", var46);
    java.text.NumberFormat var48 = var5.getExponentFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test66"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var9 = var8.getItemCount();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(1);
//     java.util.Date var12 = var11.getStart();
//     var8.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var11, true);
//     var3.addSeries(var17);
//     java.util.List var19 = var17.getItems();
//     java.beans.PropertyChangeListener var20 = null;
//     var17.addPropertyChangeListener(var20);
//     var17.add((java.lang.Number)10.0f, (java.lang.Number)0.05d);
//     org.jfree.data.xy.XYDataItem var27 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var28 = var27.getXValue();
//     java.lang.String var29 = var27.toString();
//     org.jfree.data.xy.XYDataItem var32 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var33 = var32.getXValue();
//     var32.setY(0.0d);
//     int var36 = var27.compareTo((java.lang.Object)var32);
//     java.lang.Number var37 = var32.getY();
//     var17.add(var32, true);
//     org.jfree.data.xy.XYDataItem var42 = var17.addOrUpdate(0.2d, 0.12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "[-1.0, 0.0]"+ "'", var29.equals("[-1.0, 0.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + 0.0d+ "'", var37.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test67"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    double var13 = var1.getUpperMargin();
    java.util.Locale var14 = var1.getLocale();
    org.jfree.chart.axis.TickUnitSource var15 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var14);
    java.lang.Object var16 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test68"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var1 = null;
    var0.plotChanged(var1);
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    org.jfree.data.Range var17 = var5.getDefaultAutoRange();
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var5);
    java.lang.String var19 = var0.getPlotType();
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
    java.awt.Paint var23 = var20.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var25 = var20.getDataset(1);
    int var26 = var20.getWeight();
    java.lang.Object var27 = null;
    boolean var28 = var20.equals(var27);
    java.awt.Stroke var29 = var20.getRangeCrosshairStroke();
    var0.setDomainCrosshairStroke(var29);
    java.lang.String var31 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "Combined Range XYPlot"+ "'", var19.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "Combined Range XYPlot"+ "'", var31.equals("Combined Range XYPlot"));

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test69"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var6 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)100.0d);
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection();
    var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var7);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("null");
    boolean var12 = var10.isHiddenValue(644288400000L);
    java.awt.Shape var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var20 = null;
    org.jfree.data.xy.XYSeriesCollection var21 = new org.jfree.data.xy.XYSeriesCollection(var20);
    org.jfree.data.xy.XYSeries var22 = null;
    org.jfree.data.xy.XYSeriesCollection var23 = new org.jfree.data.xy.XYSeriesCollection(var22);
    boolean var24 = var21.hasListener((java.util.EventListener)var23);
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var21, var25, var26);
    java.awt.Paint var28 = var27.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var17, var19, var28);
    java.lang.String var30 = var29.getDescription();
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
    boolean var32 = var29.equals((java.lang.Object)var31);
    java.util.TimeZone var33 = var31.getTimeZone();
    var10.setTimeZone(var33);
    org.jfree.chart.axis.TickUnitSource var35 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var33);
    org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection(var1, var33);
    var36.setSelected(0, 0, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "Pie 3D Plot"+ "'", var30.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test70"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)98.0d);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var6 = var5.getItemCount();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(1);
//     java.util.Date var9 = var8.getStart();
//     var5.add((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)Double.NaN, true);
//     var3.delete((org.jfree.data.time.RegularTimePeriod)var8);
//     var3.setMaximumItemAge(0L);
//     org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange();
//     java.lang.String var19 = var18.toString();
//     var17.setRangeWithMargins((org.jfree.data.Range)var18);
//     java.util.Date var21 = var18.getLowerDate();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(var21);
//     var3.add((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)2, true);
//     org.jfree.data.time.TimeSeriesDataItem var26 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.chart.axis.PeriodAxis var28 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var29 = new org.jfree.data.time.DateRange();
//     java.lang.String var30 = var29.toString();
//     var28.setRangeWithMargins((org.jfree.data.Range)var29);
//     java.util.Date var32 = var29.getLowerDate();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month(var32);
//     org.jfree.data.time.RegularTimePeriod var34 = var33.next();
//     java.lang.String var35 = var33.toString();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var19.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var30.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "December 1969"+ "'", var35.equals("December 1969"));
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test71"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    java.awt.Paint var5 = var0.getNoDataMessagePaint();
    boolean var6 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.data.xy.XYSeries var8 = null;
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
    org.jfree.data.xy.XYSeries var10 = null;
    org.jfree.data.xy.XYSeriesCollection var11 = new org.jfree.data.xy.XYSeriesCollection(var10);
    boolean var12 = var9.hasListener((java.util.EventListener)var11);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.PolarItemRenderer var14 = null;
    org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, var13, var14);
    org.jfree.chart.axis.TickUnit var16 = var15.getAngleTickUnit();
    java.awt.Paint var17 = var15.getRadiusGridlinePaint();
    org.jfree.chart.LegendItemCollection var18 = var15.getLegendItems();
    var7.setFixedLegendItems(var18);
    java.awt.Paint var20 = var7.getRangeCrosshairPaint();
    var0.remove((org.jfree.chart.plot.XYPlot)var7);
    var7.setDomainCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test72"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var5 = var4.getRangeGridlineStroke();
    boolean var6 = var4.canSelectByPoint();
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var8 = var7.getTickLabelPaint();
    java.lang.String var9 = var7.getLabel();
    var7.setFixedDimension(Double.NaN);
    var7.setLabelAngle(0.0d);
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    org.jfree.data.xy.XYSeries var16 = null;
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection(var16);
    boolean var18 = var15.hasListener((java.util.EventListener)var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var15, var19, var20);
    var21.setForegroundAlpha(100.0f);
    var21.setAngleGridlinesVisible(true);
    java.awt.Paint var26 = var21.getBackgroundPaint();
    var7.setAxisLinePaint(var26);
    var4.setDomainTickBandPaint(var26);
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((-1.88d), Double.NaN, 0.0d, 45.0d, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test73"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var20 = var18.getRangeAxisLocation(1);
    org.jfree.chart.util.RectangleEdge var21 = var18.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var23 = var18.getDomainAxisLocation(12);
    var0.setDomainAxisLocation(1969, var23);
    org.jfree.chart.LegendItemCollection var25 = var0.getLegendItems();
    var0.setRangePannable(true);
    int var28 = var0.getCrosshairDatasetIndex();
    org.jfree.chart.axis.AxisLocation var30 = var0.getRangeAxisLocation(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test74"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.urls.CategoryURLGenerator var12 = var2.getURLGenerator((-1), 100, true);
    var2.setBaseItemLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test75"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var5 = var0.getDataset(1);
    int var6 = var0.getWeight();
    int var7 = var0.getDatasetCount();
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = var8.getRenderer(0);
    java.util.List var11 = var8.getSubplots();
    org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var20 = var16.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
    var16.setBaseStroke(var22);
    var13.setMinorTickMarkStroke(var22);
    var13.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var27 = var13.getLocale();
    var13.setPositiveArrowVisible(false);
    double var30 = var13.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var31 = new org.jfree.chart.axis.ValueAxis[] { var13};
    var8.setDomainAxes(var31);
    var0.setRangeAxes(var31);
    org.jfree.chart.axis.AxisSpace var34 = new org.jfree.chart.axis.AxisSpace();
    var0.setFixedRangeAxisSpace(var34, true);
    java.lang.String var37 = var34.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test76"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    boolean var11 = var8.hasListener((java.util.EventListener)var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
    java.awt.Paint var15 = var14.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var19 = var18.getMinorTickMarkPaint();
    var16.setLinePaint(var19);
    java.lang.String var21 = var16.getToolTipText();
    java.awt.Stroke var22 = null;
    var16.setOutlineStroke(var22);
    boolean var24 = var16.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + ""+ "'", var21.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test77"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    double var9 = var2.getXOffset();
    org.jfree.chart.plot.CategoryPlot var10 = var2.getPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var14 = var13.getPlot();
    org.jfree.chart.plot.CategoryPlot var15 = var13.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var13.setSeriesURLGenerator(2, var17, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var13.setSeriesToolTipGenerator(0, var21);
    org.jfree.chart.labels.CategoryToolTipGenerator var23 = null;
    var13.setBaseToolTipGenerator(var23, true);
    java.awt.Paint var26 = var13.getShadowPaint();
    var2.setBaseItemLabelPaint(var26, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test78"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var1 = var0.getAdjustForDaylightSaving();
    long var2 = var0.getSegmentsGroupSize();
    java.util.Date var4 = var0.getDate((-1L));
    boolean var7 = var0.containsDomainRange(1L, 23640L);
    var0.addException(1417420800000L, 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test79"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
    java.awt.Stroke var27 = var0.getDomainGridlineStroke();
    org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = var28.getRenderer(0);
    java.awt.Paint var31 = var28.getDomainCrosshairPaint();
    java.awt.Paint var32 = var28.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var33 = var28.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var34 = var33.getOpposite();
    org.jfree.chart.axis.AxisLocation var35 = var34.getOpposite();
    var0.setRangeAxisLocation(var35);
    org.jfree.chart.plot.CombinedRangeXYPlot var37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var38 = null;
    var37.plotChanged(var38);
    java.util.List var40 = var37.getSubplots();
    org.jfree.chart.axis.AxisLocation var42 = var37.getDomainAxisLocation(1969);
    org.jfree.chart.axis.AxisLocation var43 = var42.getOpposite();
    var0.setRangeAxisLocation(var43);
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.general.DefaultPieDataset var46 = new org.jfree.data.general.DefaultPieDataset();
    java.lang.Object var47 = var46.clone();
    org.jfree.data.time.Year var49 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 1.0d);
    org.jfree.chart.title.LegendItemBlockContainer var52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var45, (org.jfree.data.general.Dataset)var46, (java.lang.Comparable)1.0d);
    org.jfree.chart.block.CenterArrangement var53 = new org.jfree.chart.block.CenterArrangement();
    var52.setArrangement((org.jfree.chart.block.Arrangement)var53);
    org.jfree.data.xy.XYSeries var56 = null;
    org.jfree.data.xy.XYSeriesCollection var57 = new org.jfree.data.xy.XYSeriesCollection(var56);
    org.jfree.data.xy.XYSeries var58 = null;
    org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
    boolean var60 = var57.hasListener((java.util.EventListener)var59);
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.PolarItemRenderer var62 = null;
    org.jfree.chart.plot.PolarPlot var63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var57, var61, var62);
    org.jfree.chart.JFreeChart var64 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var63);
    java.awt.image.BufferedImage var67 = var64.createBufferedImage(68, 2);
    org.jfree.chart.title.LegendTitle var68 = var64.getLegend();
    java.lang.Object var69 = null;
    var53.add((org.jfree.chart.block.Block)var68, var69);
    java.awt.Paint var71 = var68.getItemPaint();
    java.lang.String var72 = var68.getID();
    boolean var73 = var43.equals((java.lang.Object)var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test80"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getRangeGridlineStroke();
    org.jfree.data.general.DatasetGroup var2 = var0.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test81"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    var1.setPlotOutlinePaint(var24);
    org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var1.setBarPainter(var26);
    org.jfree.data.xy.XYSeries var28 = null;
    org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
    org.jfree.data.xy.XYSeries var30 = null;
    org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
    boolean var32 = var29.hasListener((java.util.EventListener)var31);
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var29, var33, var34);
    var35.setForegroundAlpha(100.0f);
    var35.setAngleGridlinesVisible(true);
    java.awt.Paint var40 = var35.getBackgroundPaint();
    var1.setGridBandAlternatePaint(var40);
    org.jfree.chart.plot.DrawingSupplier var42 = var1.getDrawingSupplier();
    java.awt.Color var46 = java.awt.Color.getHSBColor((-1.0f), (-1.0f), (-1.0f));
    var1.setErrorIndicatorPaint((java.awt.Paint)var46);
    java.awt.Paint var48 = var1.getTickLabelPaint();
    org.jfree.chart.util.PaintMap var49 = new org.jfree.chart.util.PaintMap();
    java.awt.Paint var51 = var49.getPaint((java.lang.Comparable)12.0d);
    var49.clear();
    org.jfree.data.xy.XYDataItem var55 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var56 = var55.getXValue();
    var55.setY(0.0d);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var61 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var62 = var61.getDefaultEntityRadius();
    var61.setAutoPopulateSeriesShape(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var65 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var66 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var68 = var66.getRenderer(0);
    java.awt.Paint var69 = var66.getDomainCrosshairPaint();
    java.awt.Paint var70 = var66.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var71 = var66.getDomainAxisLocation();
    java.awt.Paint var72 = var66.getDomainZeroBaselinePaint();
    var65.setRangeTickBandPaint(var72);
    var61.setBaseItemLabelPaint(var72);
    var61.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var77 = var61.getBasePaint();
    var49.put((java.lang.Comparable)0.0d, var77);
    var1.setAxisLabelPaint(var77);
    java.awt.Paint var80 = var1.getGridBandAlternatePaint();
    java.lang.String var81 = var1.getName();
    org.jfree.chart.renderer.xy.GradientXYBarPainter var85 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(8.0d, (-1.0d), (-1.0d));
    var1.setXYBarPainter((org.jfree.chart.renderer.xy.XYBarPainter)var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var81 + "' != '" + "[-1.0, 0.0]"+ "'", var81.equals("[-1.0, 0.0]"));

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test82"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    var0.clearSectionOutlinePaints(false);
    double var4 = var0.getMaximumLabelWidth();
    java.awt.Paint var5 = var0.getBaseSectionOutlinePaint();
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    var0.setShadowYOffset(0.025d);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    org.jfree.data.xy.XYSeries var11 = null;
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
    boolean var13 = var10.hasListener((java.util.EventListener)var12);
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var10, var14, var15);
    var16.setForegroundAlpha(100.0f);
    boolean var19 = var16.isAngleLabelsVisible();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var26 = var22.getItemFillPaint(1, (-1), false);
    java.awt.Font var28 = var22.getSeriesItemLabelFont(1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var32 = var31.getDefaultEntityRadius();
    java.awt.Shape var34 = var31.getSeriesShape(1);
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var37 = var36.getTickLabelPaint();
    var31.setSeriesOutlinePaint(0, var37);
    var22.setBaseFillPaint(var37, true);
    java.awt.Paint[] var41 = new java.awt.Paint[] { var37};
    java.awt.Color var45 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var46 = var45.darker();
    java.awt.Paint[] var47 = new java.awt.Paint[] { var45};
    org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var49 = var48.getFont();
    java.awt.Color var53 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var54 = var53.getRGB();
    var48.setBackgroundPaint((java.awt.Paint)var53);
    java.awt.Paint[] var56 = new java.awt.Paint[] { var53};
    java.awt.Stroke[] var57 = null;
    org.jfree.chart.plot.PiePlot3D var58 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var59 = var58.getBaseSectionOutlineStroke();
    var58.clearSectionOutlinePaints(false);
    org.jfree.chart.block.BlockBorder var62 = new org.jfree.chart.block.BlockBorder();
    boolean var63 = var58.equals((java.lang.Object)var62);
    java.awt.Stroke var64 = var58.getBaseSectionOutlineStroke();
    java.awt.Stroke[] var65 = new java.awt.Stroke[] { var64};
    java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.awt.Shape[] var68 = new java.awt.Shape[] { var67};
    org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier(var41, var47, var56, var57, var65, var68);
    java.awt.Paint var70 = var69.getNextFillPaint();
    var16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var69);
    java.awt.Stroke var72 = var69.getNextOutlineStroke();
    var0.setLabelLinkStroke(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test83"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    java.awt.Paint var4 = var3.getAggregatedItemsPaint();
    org.jfree.chart.util.TableOrder var5 = var3.getDataExtractOrder();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    var3.setLimit(0.08d);
    double var9 = var3.getLimit();
    org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var11 = var10.getDataExtractOrder();
    var3.setDataExtractOrder(var11);
    org.jfree.chart.util.ObjectList var14 = new org.jfree.chart.util.ObjectList(10);
    int var16 = var14.indexOf((java.lang.Object)(byte)10);
    org.jfree.chart.renderer.category.BarRenderer3D var19 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var20 = var19.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var22 = null;
    var19.setSeriesURLGenerator(0, var22);
    org.jfree.chart.plot.CombinedRangeXYPlot var24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = var26.getRenderer(0);
    java.awt.Paint var29 = var26.getDomainCrosshairPaint();
    java.awt.Paint var30 = var26.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var31 = var26.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var32 = var31.getOpposite();
    var24.setRangeAxisLocation(100, var32, false);
    var24.mapDatasetToDomainAxis(1, 0);
    boolean var38 = var19.hasListener((java.util.EventListener)var24);
    int var39 = var14.indexOf((java.lang.Object)var24);
    java.awt.Paint var40 = var24.getBackgroundPaint();
    var3.setAggregatedItemsPaint(var40);
    org.jfree.data.xy.XYSeries var43 = null;
    org.jfree.data.xy.XYSeriesCollection var44 = new org.jfree.data.xy.XYSeriesCollection(var43);
    org.jfree.data.xy.XYSeries var45 = null;
    org.jfree.data.xy.XYSeriesCollection var46 = new org.jfree.data.xy.XYSeriesCollection(var45);
    boolean var47 = var44.hasListener((java.util.EventListener)var46);
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.PolarItemRenderer var49 = null;
    org.jfree.chart.plot.PolarPlot var50 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var44, var48, var49);
    org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var50);
    org.jfree.chart.title.LegendTitle var53 = var51.getLegend(4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setPieChart(var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test84"); }


    org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.chart.RenderingSource var1 = null;
    var0.setRenderingSource(var1);
    org.jfree.chart.RenderingSource var3 = var0.getRenderingSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test85"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var6 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var5, var6);
    var3.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var7, false);
    java.lang.String var10 = var7.getNullYString();
    org.jfree.chart.renderer.xy.XYStepRenderer var11 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    org.jfree.chart.annotations.XYAnnotation var12 = null;
    boolean var13 = var11.removeAnnotation(var12);
    int var14 = var11.getPassCount();
    org.jfree.chart.urls.StandardXYURLGenerator var19 = new org.jfree.chart.urls.StandardXYURLGenerator("$0.00", "DomainOrder.NONE", "");
    var11.setSeriesURLGenerator(3, (org.jfree.chart.urls.XYURLGenerator)var19);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0, (org.jfree.chart.labels.XYToolTipGenerator)var7, (org.jfree.chart.urls.XYURLGenerator)var19);
    boolean var22 = var21.getBaseSeriesVisible();
    var21.setShapesFilled(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "null"+ "'", var10.equals("null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test86"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    var7.setForegroundAlpha(100.0f);
    var7.setAngleGridlinesVisible(true);
    org.jfree.chart.plot.PlotOrientation var12 = var7.getOrientation();
    var7.removeCornerTextItem("$0.00?DomainOrder.NONE=1&amp;=96");
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    var7.handleClick(100, 2, var17);
    java.awt.Paint var19 = var7.getAngleLabelPaint();
    org.jfree.data.xy.XYDataset var20 = null;
    var7.setDataset(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test87"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    var1.setPlotOutlinePaint(var24);
    boolean var26 = var1.isShadowVisible();
    org.jfree.chart.plot.PieLabelLinkStyle var27 = var1.getLabelLinkStyle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test88"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var2 = var1.getTickLabelPaint();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var6 = var5.getItemCount();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(1);
    java.util.Date var9 = var8.getStart();
    var5.add((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var14 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var8, true);
    org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(1);
    org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("$0.00?DomainOrder.NONE=3&amp;=2", (org.jfree.data.time.RegularTimePeriod)var8, (org.jfree.data.time.RegularTimePeriod)var16);
    var17.setNegativeArrowVisible(true);
    var17.setVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    double var23 = var22.getUpperClip();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.data.Range var26 = var22.findRangeBounds(var24, false);
    double var27 = var22.getMaximumBarWidth();
    var22.setIncludeBaseInRange(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = var22.getSeriesToolTipGenerator(0);
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    boolean var33 = var32.isRangeMinorGridlinesVisible();
    org.jfree.chart.axis.AxisSpace var34 = var32.getFixedRangeAxisSpace();
    java.awt.Paint var35 = var32.getDomainCrosshairPaint();
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var39 = var38.getOutlineStroke();
    double var40 = var38.getValue();
    java.awt.Color var44 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var45 = var44.getRGB();
    java.lang.String var46 = var44.toString();
    var38.setLabelPaint((java.awt.Paint)var44);
    org.jfree.chart.util.LengthAdjustmentType var48 = var38.getLabelOffsetType();
    java.awt.Font var49 = var38.getLabelFont();
    org.jfree.chart.util.Layer var50 = null;
    boolean var52 = var32.removeDomainMarker(3, (org.jfree.chart.plot.Marker)var38, var50, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var46.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test89"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var1 = var0.getShadowsVisible();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = null;
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var19 = var18.getOutlineStroke();
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawRangeMarker(var2, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.plot.Marker)var18, var20);
//     org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var30 = var26.getItemFillPaint(1, (-1), false);
//     var22.setLabelPaint(var30);
//     org.jfree.data.general.PieDataset var32 = var22.getDataset();
//     var22.setAutoPopulateSectionOutlinePaint(false);
//     float var35 = var22.getBackgroundImageAlpha();
//     java.awt.Paint var36 = var22.getNoDataMessagePaint();
//     var18.setPaint(var36);
//     org.jfree.chart.util.RectangleInsets var38 = var18.getLabelOffset();
//     org.jfree.chart.util.UnitType var39 = var38.getUnitType();
//     org.jfree.chart.util.RectangleInsets var44 = new org.jfree.chart.util.RectangleInsets(var39, 4.0d, 0.0d, 4.0d, 8.0d);
//     java.awt.geom.Rectangle2D var45 = null;
//     var44.trim(var45);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test90"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range((-5.95d), 2.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test91"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("null");
    boolean var3 = var1.isHiddenValue(644288400000L);
    java.awt.Shape var8 = null;
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var11 = null;
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    boolean var15 = var12.hasListener((java.util.EventListener)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
    java.awt.Paint var19 = var18.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var8, var10, var19);
    java.lang.String var21 = var20.getDescription();
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    boolean var23 = var20.equals((java.lang.Object)var22);
    java.util.TimeZone var24 = var22.getTimeZone();
    var1.setTimeZone(var24);
    var1.configure();
    org.jfree.chart.axis.DateTickMarkPosition var27 = var1.getTickMarkPosition();
    org.jfree.chart.plot.CombinedRangeXYPlot var28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var29 = null;
    var28.plotChanged(var29);
    java.util.List var31 = var28.getSubplots();
    org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var34 = var33.getItemCount();
    org.jfree.data.time.Year var36 = new org.jfree.data.time.Year(1);
    java.util.Date var37 = var36.getStart();
    var33.add((org.jfree.data.time.RegularTimePeriod)var36, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var41 = null;
    org.jfree.data.xy.XYSeriesCollection var42 = new org.jfree.data.xy.XYSeriesCollection(var41);
    org.jfree.data.xy.XYSeries var43 = null;
    org.jfree.data.xy.XYSeriesCollection var44 = new org.jfree.data.xy.XYSeriesCollection(var43);
    boolean var45 = var42.hasListener((java.util.EventListener)var44);
    double var46 = var44.getIntervalPositionFactor();
    var33.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var44);
    boolean var48 = var28.equals((java.lang.Object)var33);
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var51 = var50.getOutlineStroke();
    double var52 = var50.getValue();
    java.awt.Color var56 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var57 = var56.getRGB();
    java.lang.String var58 = var56.toString();
    var50.setLabelPaint((java.awt.Paint)var56);
    org.jfree.chart.util.Layer var60 = null;
    boolean var61 = var28.removeDomainMarker((org.jfree.chart.plot.Marker)var50, var60);
    org.jfree.chart.event.MarkerChangeEvent var62 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var50);
    java.awt.Paint var63 = var50.getPaint();
    var50.setValue(0.5d);
    boolean var66 = var27.equals((java.lang.Object)var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Pie 3D Plot"+ "'", var21.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var58.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test92"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    var0.clearSectionOutlinePaints(false);
    int var4 = var0.getPieIndex();
    java.awt.Image var5 = null;
    var0.setBackgroundImage(var5);
    var0.setIgnoreZeroValues(false);
    org.jfree.chart.LegendItemCollection var9 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var11 = var9.get(28);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test93"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
//     java.text.NumberFormat var5 = var4.getYFormat();
//     boolean var6 = var0.equals((java.lang.Object)var5);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPositionFallback();
//     boolean var8 = var0.getShadowsVisible();
//     var0.setAutoPopulateSeriesShape(false);
//     java.awt.Shape var14 = var0.getItemShape(4, 31, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test94"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     boolean var6 = var5.getAutoPopulateSeriesOutlinePaint();
//     org.jfree.data.xy.XYSeries var8 = null;
//     org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
//     org.jfree.data.xy.XYSeries var10 = null;
//     org.jfree.data.xy.XYSeriesCollection var11 = new org.jfree.data.xy.XYSeriesCollection(var10);
//     boolean var12 = var9.hasListener((java.util.EventListener)var11);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var14 = null;
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var9, var13, var14);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleAnchor var20 = null;
//     java.awt.geom.Point2D var21 = org.jfree.chart.util.RectangleAnchor.coordinates(var19, var20);
//     var15.zoomDomainAxes(100.0d, (-1.0d), var18, var21);
//     java.lang.String var23 = var15.getNoDataMessage();
//     java.awt.Stroke var24 = var15.getAngleGridlineStroke();
//     var5.setSeriesStroke(100, var24);
//     var0.setRangeMinorGridlineStroke(var24);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year(1);
//     long var29 = var28.getLastMillisecond();
//     boolean var30 = var0.equals((java.lang.Object)var28);
//     boolean var31 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.plot.CombinedDomainXYPlot var33 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var34 = var33.getRangeGridlineStroke();
//     boolean var35 = var33.canSelectByPoint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = var36.getRenderer(0);
//     java.awt.Paint var39 = var36.getDomainCrosshairPaint();
//     org.jfree.data.xy.XYDataset var41 = var36.getDataset(1);
//     int var42 = var36.getWeight();
//     int var43 = var36.getDatasetCount();
//     var36.setBackgroundImageAlignment((-16777216));
//     org.jfree.chart.plot.CombinedRangeXYPlot var46 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.event.PlotChangeEvent var47 = null;
//     var46.plotChanged(var47);
//     java.util.List var49 = var46.getSubplots();
//     org.jfree.data.time.TimeSeries var51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var52 = var51.getItemCount();
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year(1);
//     java.util.Date var55 = var54.getStart();
//     var51.add((org.jfree.data.time.RegularTimePeriod)var54, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var59 = null;
//     org.jfree.data.xy.XYSeriesCollection var60 = new org.jfree.data.xy.XYSeriesCollection(var59);
//     org.jfree.data.xy.XYSeries var61 = null;
//     org.jfree.data.xy.XYSeriesCollection var62 = new org.jfree.data.xy.XYSeriesCollection(var61);
//     boolean var63 = var60.hasListener((java.util.EventListener)var62);
//     double var64 = var62.getIntervalPositionFactor();
//     var51.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var62);
//     boolean var66 = var46.equals((java.lang.Object)var51);
//     org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var69 = var68.getOutlineStroke();
//     double var70 = var68.getValue();
//     java.awt.Color var74 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     int var75 = var74.getRGB();
//     java.lang.String var76 = var74.toString();
//     var68.setLabelPaint((java.awt.Paint)var74);
//     org.jfree.chart.util.Layer var78 = null;
//     boolean var79 = var46.removeDomainMarker((org.jfree.chart.plot.Marker)var68, var78);
//     org.jfree.chart.event.MarkerChangeEvent var80 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var68);
//     var36.markerChanged(var80);
//     var33.markerChanged(var80);
//     org.jfree.chart.plot.Marker var83 = var80.getMarker();
//     org.jfree.chart.util.Layer var84 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.addDomainMarker((-16777216), var83, var84, false);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-62104204800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == (-16777216));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var76 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var76.equals("java.awt.Color[r=0,g=0,b=0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test95"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     boolean var1 = var0.getAdjustForDaylightSaving();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(1);
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange(var4, var7);
//     long var9 = var0.toTimelineValue(var4);
//     int var10 = var0.getSegmentsExcluded();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(1);
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var13);
//     long var15 = var0.getTime(var13);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var18 = var17.getItemCount();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(1);
//     java.util.Date var21 = var20.getStart();
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("null");
//     boolean var25 = var23.isHiddenValue(644288400000L);
//     java.awt.Shape var30 = null;
//     org.jfree.chart.plot.PiePlot3D var31 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var32 = var31.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var33 = null;
//     org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
//     org.jfree.data.xy.XYSeries var35 = null;
//     org.jfree.data.xy.XYSeriesCollection var36 = new org.jfree.data.xy.XYSeriesCollection(var35);
//     boolean var37 = var34.hasListener((java.util.EventListener)var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var39 = null;
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var34, var38, var39);
//     java.awt.Paint var41 = var40.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var30, var32, var41);
//     java.lang.String var43 = var42.getDescription();
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     boolean var45 = var42.equals((java.lang.Object)var44);
//     java.util.TimeZone var46 = var44.getTimeZone();
//     var23.setTimeZone(var46);
//     org.jfree.data.time.Year var48 = new org.jfree.data.time.Year(var21, var46);
//     org.jfree.data.time.TimeSeriesCollection var49 = new org.jfree.data.time.TimeSeriesCollection(var17, var46);
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year(var13, var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-17478676800000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-62135740800000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "Pie 3D Plot"+ "'", var43.equals("Pie 3D Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test96"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var9.setAntiAlias(true);
    java.awt.Image var12 = var9.getBackgroundImage();
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var21 = var17.getItemFillPaint(1, (-1), false);
    var13.setLabelPaint(var21);
    org.jfree.data.general.PieDataset var23 = var13.getDataset();
    boolean var24 = var13.getSimpleLabels();
    double var25 = var13.getDepthFactor();
    org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    java.lang.Object var27 = var26.clone();
    var9.addSubtitle((org.jfree.chart.title.Title)var26);
    org.jfree.chart.util.RectangleEdge var29 = var26.getLegendItemGraphicEdge();
    java.awt.Paint var30 = var26.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test97"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.util.List var1 = var0.getAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test98"); }


    org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var3.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var6);
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
    var8.clearSectionOutlinePaints(false);
    double var12 = var8.getMaximumLabelWidth();
    java.awt.Paint var13 = null;
    var8.setLabelShadowPaint(var13);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("$0.00?DomainOrder.NONE=3&amp;=2", var6, (org.jfree.chart.plot.Plot)var8, false);
    org.jfree.chart.title.TextTitle var17 = var16.getTitle();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var21.setBaseSeriesVisible(false, false);
    java.awt.Paint var25 = var21.getBaseOutlinePaint();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var33 = var29.getItemFillPaint(1, (-1), false);
    var21.setLegendTextPaint(3, var33);
    java.lang.Boolean var36 = var21.getSeriesShapesVisible(2);
    java.awt.Graphics2D var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = var39.getRenderer(0);
    java.util.List var42 = var39.getSubplots();
    org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var51 = var47.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var53 = var52.getBaseSectionOutlineStroke();
    var47.setBaseStroke(var53);
    var44.setMinorTickMarkStroke(var53);
    var44.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var58 = var44.getLocale();
    var44.setPositiveArrowVisible(false);
    double var61 = var44.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var62 = new org.jfree.chart.axis.ValueAxis[] { var44};
    var39.setDomainAxes(var62);
    org.jfree.chart.util.RectangleEdge var65 = var39.getRangeAxisEdge(0);
    org.jfree.data.xy.XYSeries var67 = null;
    org.jfree.data.xy.XYSeriesCollection var68 = new org.jfree.data.xy.XYSeriesCollection(var67);
    org.jfree.data.xy.XYSeries var69 = null;
    org.jfree.data.xy.XYSeriesCollection var70 = new org.jfree.data.xy.XYSeriesCollection(var69);
    boolean var71 = var68.hasListener((java.util.EventListener)var70);
    org.jfree.chart.axis.ValueAxis var72 = null;
    org.jfree.chart.renderer.PolarItemRenderer var73 = null;
    org.jfree.chart.plot.PolarPlot var74 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var68, var72, var73);
    org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var74);
    boolean var76 = var39.equals((java.lang.Object)"");
    org.jfree.data.xy.XYSeries var77 = null;
    org.jfree.data.xy.XYSeriesCollection var78 = new org.jfree.data.xy.XYSeriesCollection(var77);
    org.jfree.data.xy.XYSeries var79 = null;
    org.jfree.data.xy.XYSeriesCollection var80 = new org.jfree.data.xy.XYSeriesCollection(var79);
    boolean var81 = var78.hasListener((java.util.EventListener)var80);
    double var82 = var80.getIntervalPositionFactor();
    org.jfree.chart.plot.PlotRenderingInfo var83 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var84 = var21.initialise(var37, var38, (org.jfree.chart.plot.XYPlot)var39, (org.jfree.data.xy.XYDataset)var80, var83);
    java.awt.Font var85 = var21.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var86 = new org.jfree.chart.title.TextTitle("", var85);
    var17.setFont(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test99"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    var0.clear();
    var0.clear();

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test100"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.PeriodAxis var6 = new org.jfree.chart.axis.PeriodAxis("Pie 3D Plot");
    java.awt.geom.Rectangle2D var7 = null;
    var2.drawRangeGridline(var3, var4, (org.jfree.chart.axis.ValueAxis)var6, var7, 0.12d);
    double var10 = var2.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0E-8d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test101"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     java.awt.Font var12 = var6.getSeriesItemLabelFont(1);
//     java.awt.Paint var14 = var6.lookupSeriesOutlinePaint((-1));
//     org.jfree.chart.labels.ItemLabelPosition var16 = var6.getSeriesNegativeItemLabelPosition(2);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis();
//     boolean var18 = var16.equals((java.lang.Object)var17);
//     org.jfree.chart.text.TextAnchor var19 = var16.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("[-1.0, 0.0]", var1, (-1.0f), 10.0f, var19, 0.0d, 0.0f, 0.0f);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test102"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var4.setBaseStroke(var10);
//     var1.setMinorTickMarkStroke(var10);
//     var1.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var15 = var1.getLocale();
//     org.jfree.chart.axis.TickUnitSource var16 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var15);
//     org.jfree.chart.axis.TickUnitSource var17 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var15);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var15);
//     org.jfree.chart.axis.TickUnitSource var19 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var15);
//     
//     // Checks the contract:  equals-hashcode on var16 and var19
//     assertTrue("Contract failed: equals-hashcode on var16 and var19", var16.equals(var19) ? var16.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var16
//     assertTrue("Contract failed: equals-hashcode on var19 and var16", var19.equals(var16) ? var19.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test103"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(1);
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(1);
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange(var3, var6);
//     org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
//     java.awt.Paint var10 = var8.getLabelBackgroundPaint();
//     boolean var11 = var7.equals((java.lang.Object)var10);
//     org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(0.08d, (-1.99999d));
//     org.jfree.data.Range var15 = var14.getWidthRange();
//     double var16 = var14.getWidth();
//     org.jfree.chart.block.RectangleConstraint var17 = var14.toUnconstrainedHeight();
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var20 = var19.clone();
//     boolean var21 = var18.equals((java.lang.Object)var19);
//     org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine();
//     var18.addLine(var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.util.Size2D var25 = var22.calculateDimensions(var24);
//     org.jfree.chart.util.Size2D var26 = var14.calculateConstrainedSize(var25);
//     org.jfree.chart.block.LengthConstraintType var27 = var14.getHeightConstraintType();
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var31 = new org.jfree.data.time.DateRange();
//     java.lang.String var32 = var31.toString();
//     var30.setRangeWithMargins((org.jfree.data.Range)var31);
//     org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var37 = new org.jfree.data.time.DateRange();
//     java.lang.String var38 = var37.toString();
//     var36.setRangeWithMargins((org.jfree.data.Range)var37);
//     boolean var42 = var37.intersects(Double.NaN, 0.5d);
//     double var43 = var37.getCentralValue();
//     org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint(0.08d, (-1.99999d));
//     org.jfree.data.Range var47 = var46.getWidthRange();
//     double var48 = var46.getWidth();
//     org.jfree.chart.block.LengthConstraintType var49 = var46.getWidthConstraintType();
//     org.jfree.chart.axis.PeriodAxis var52 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var55 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var59 = var55.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var60 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var61 = var60.getBaseSectionOutlineStroke();
//     var55.setBaseStroke(var61);
//     var52.setMinorTickMarkStroke(var61);
//     org.jfree.data.time.DateRange var64 = new org.jfree.data.time.DateRange();
//     var52.setRangeWithMargins((org.jfree.data.Range)var64);
//     org.jfree.data.time.DateRange var66 = new org.jfree.data.time.DateRange();
//     java.lang.String var67 = var66.toString();
//     var52.setRange((org.jfree.data.Range)var66);
//     org.jfree.chart.block.RectangleConstraint var71 = new org.jfree.chart.block.RectangleConstraint(0.08d, (-1.99999d));
//     org.jfree.data.Range var72 = var71.getWidthRange();
//     double var73 = var71.getWidth();
//     org.jfree.chart.block.LengthConstraintType var74 = var71.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var75 = new org.jfree.chart.block.RectangleConstraint(90.0d, (org.jfree.data.Range)var37, var49, 45.0d, (org.jfree.data.Range)var66, var74);
//     org.jfree.chart.block.RectangleConstraint var76 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range)var7, var27, 90.0d, (org.jfree.data.Range)var31, var74);
//     
//     // Checks the contract:  equals-hashcode on var8 and var60
//     assertTrue("Contract failed: equals-hashcode on var8 and var60", var8.equals(var60) ? var8.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var8
//     assertTrue("Contract failed: equals-hashcode on var60 and var8", var60.equals(var8) ? var60.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test104"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getSeriesKey(4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test105"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.awt.Paint var3 = var0.getDomainCrosshairPaint();
//     org.jfree.data.xy.XYDataset var5 = var0.getDataset(1);
//     int var6 = var0.getWeight();
//     java.lang.Object var7 = null;
//     boolean var8 = var0.equals(var7);
//     java.awt.Stroke var9 = var0.getRangeCrosshairStroke();
//     org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.event.PlotChangeEvent var13 = null;
//     var12.plotChanged(var13);
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = var15.getRenderer(0);
//     java.util.List var18 = var15.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var27 = var23.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var29 = var28.getBaseSectionOutlineStroke();
//     var23.setBaseStroke(var29);
//     var20.setMinorTickMarkStroke(var29);
//     var20.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var34 = var20.getLocale();
//     var20.setPositiveArrowVisible(false);
//     double var37 = var20.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var38 = new org.jfree.chart.axis.ValueAxis[] { var20};
//     var15.setDomainAxes(var38);
//     java.awt.Paint var40 = var15.getDomainCrosshairPaint();
//     org.jfree.chart.util.Layer var41 = null;
//     java.util.Collection var42 = var15.getDomainMarkers(var41);
//     boolean var43 = var12.equals((java.lang.Object)var41);
//     org.jfree.chart.entity.EntityCollection var45 = null;
//     org.jfree.chart.ChartRenderingInfo var46 = new org.jfree.chart.ChartRenderingInfo(var45);
//     java.lang.Object var47 = var46.clone();
//     org.jfree.chart.entity.EntityCollection var48 = var46.getEntityCollection();
//     org.jfree.chart.plot.PlotRenderingInfo var49 = new org.jfree.chart.plot.PlotRenderingInfo(var46);
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var51 = var50.getRangeGridlineStroke();
//     java.awt.Paint var52 = var50.getDomainTickBandPaint();
//     org.jfree.chart.plot.ValueMarker var54 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var55 = var54.getOutlineStroke();
//     double var56 = var54.getValue();
//     org.jfree.chart.util.Layer var57 = null;
//     boolean var58 = var50.removeRangeMarker((org.jfree.chart.plot.Marker)var54, var57);
//     java.awt.geom.Point2D var59 = var50.getQuadrantOrigin();
//     var12.panRangeAxes((-0.30102999566398114d), var49, var59);
//     org.jfree.chart.plot.CrosshairState var61 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.chart.plot.PlotOrientation var68 = null;
//     var61.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var68);
//     var61.updateCrosshairX(90.0d);
//     org.jfree.chart.plot.CrosshairState var72 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.data.xy.XYSeries var73 = null;
//     org.jfree.data.xy.XYSeriesCollection var74 = new org.jfree.data.xy.XYSeriesCollection(var73);
//     org.jfree.data.xy.XYSeries var75 = null;
//     org.jfree.data.xy.XYSeriesCollection var76 = new org.jfree.data.xy.XYSeriesCollection(var75);
//     boolean var77 = var74.hasListener((java.util.EventListener)var76);
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var79 = null;
//     org.jfree.chart.plot.PolarPlot var80 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var74, var78, var79);
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     java.awt.geom.Rectangle2D var84 = null;
//     org.jfree.chart.util.RectangleAnchor var85 = null;
//     java.awt.geom.Point2D var86 = org.jfree.chart.util.RectangleAnchor.coordinates(var84, var85);
//     var80.zoomDomainAxes(100.0d, (-1.0d), var83, var86);
//     var72.setAnchor(var86);
//     var61.setAnchor(var86);
//     var0.zoomRangeAxes(45.0d, 9.990000000000001E-6d, var49, var86);
//     
//     // Checks the contract:  equals-hashcode on var0 and var50
//     assertTrue("Contract failed: equals-hashcode on var0 and var50", var0.equals(var50) ? var0.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var0
//     assertTrue("Contract failed: equals-hashcode on var50 and var0", var50.equals(var0) ? var50.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test106"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var1 = var0.getAdjustForDaylightSaving();
    org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(1);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
    java.util.Date var7 = var6.getStart();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange(var4, var7);
    long var9 = var0.toTimelineValue(var4);
    long var10 = var0.getSegmentsExcludedSize();
    org.jfree.chart.util.StandardGradientPaintTransformer var11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var14 = var12.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var17 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var18 = var17.getXValue();
    java.lang.String var19 = var17.toString();
    org.jfree.data.xy.XYDataItem var22 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var23 = var22.getXValue();
    var22.setY(0.0d);
    int var26 = var17.compareTo((java.lang.Object)var22);
    java.lang.Number var27 = var22.getX();
    var12.setDomainCrosshairColumnKey((java.lang.Comparable)var22);
    boolean var29 = var12.isRangeMinorGridlinesVisible();
    var12.setRangeCrosshairValue(0.0d);
    var12.clearDomainMarkers();
    java.util.List var33 = var12.getAnnotations();
    boolean var34 = var11.equals((java.lang.Object)var33);
    var0.addExceptions(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-17478676800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "[-1.0, 0.0]"+ "'", var19.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + (byte)(-1)+ "'", var27.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test107"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    java.awt.Paint var11 = var0.getShadowPaint();
    var0.setShadowYOffset(9.990000000000001E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test108"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.xy.DefaultXYDataset var4 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.general.DatasetGroup var5 = var4.getGroup();
    var1.setGroup(var5);
    java.lang.String var7 = var5.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "NOID"+ "'", var7.equals("NOID"));

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test109"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    var2.setLegendTextPaint(3, var14);
    java.lang.Boolean var17 = var2.getSeriesShapesVisible(2);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
    java.util.List var23 = var20.getSubplots();
    org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
    var28.setBaseStroke(var34);
    var25.setMinorTickMarkStroke(var34);
    var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var39 = var25.getLocale();
    var25.setPositiveArrowVisible(false);
    double var42 = var25.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var25};
    var20.setDomainAxes(var43);
    org.jfree.chart.util.RectangleEdge var46 = var20.getRangeAxisEdge(0);
    org.jfree.data.xy.XYSeries var48 = null;
    org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
    org.jfree.data.xy.XYSeries var50 = null;
    org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
    boolean var52 = var49.hasListener((java.util.EventListener)var51);
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var49, var53, var54);
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var55);
    boolean var57 = var20.equals((java.lang.Object)"");
    org.jfree.data.xy.XYSeries var58 = null;
    org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
    org.jfree.data.xy.XYSeries var60 = null;
    org.jfree.data.xy.XYSeriesCollection var61 = new org.jfree.data.xy.XYSeriesCollection(var60);
    boolean var62 = var59.hasListener((java.util.EventListener)var61);
    double var63 = var61.getIntervalPositionFactor();
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var65 = var2.initialise(var18, var19, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.data.xy.XYDataset)var61, var64);
    java.awt.Font var66 = var2.getBaseItemLabelFont();
    org.jfree.chart.urls.XYURLGenerator var68 = var2.getSeriesURLGenerator(68);
    var2.setSeriesVisible(0, (java.lang.Boolean)false);
    var2.setDataBoundsIncludesVisibleSeriesOnly(true);
    var2.setDrawOutlines(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test110"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    boolean var3 = var2.getAutoRangeStickyZero();
    org.jfree.chart.event.AxisChangeEvent var4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var2);
    var0.axisChanged(var4);
    org.jfree.chart.axis.Axis var6 = var4.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test111"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot();
    java.awt.Paint var4 = var3.getAggregatedItemsPaint();
    org.jfree.chart.util.TableOrder var5 = var3.getDataExtractOrder();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    var3.setLimit(0.08d);
    double var9 = var3.getLimit();
    double var10 = var3.getLimit();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.08d);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test112"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     double var3 = var1.getDomainLowerBound(false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == Double.NaN);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test113"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat((-3.99999d), "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[size=0.025]", true);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test114"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var4.setBaseSeriesVisible(false, false);
    java.awt.Font var9 = null;
    var4.setSeriesItemLabelFont(3, var9, true);
    org.jfree.chart.labels.ItemLabelPosition var12 = var4.getBasePositiveItemLabelPosition();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    var0.setPositiveItemLabelPositionFallback(var12);
    var0.setDefaultEntityRadius(0);
    java.awt.Shape var18 = var0.getLegendBar();
    org.jfree.chart.plot.XYPlot var19 = null;
    var0.setPlot(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test115"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    java.awt.Paint var11 = var0.getShadowPaint();
    java.awt.Shape var12 = var0.getLegendItemShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test116"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    boolean var3 = var0.isRangeZeroBaselineVisible();
    double var4 = var0.getRangeCrosshairValue();
    var0.setAnchorValue(0.5d);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    boolean var10 = var9.getAutoPopulateSeriesOutlinePaint();
    boolean var11 = var9.getDrawOutlines();
    boolean var12 = var9.getAutoPopulateSeriesOutlineStroke();
    var9.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.event.RendererChangeEvent var16 = null;
    var9.notifyListeners(var16);
    org.jfree.chart.LegendItemCollection var18 = var9.getLegendItems();
    int var19 = var18.getItemCount();
    var0.setFixedLegendItems(var18);
    int var21 = var18.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test117"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.chart.util.RectangleEdge var3 = var0.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation(12);
    var0.setRangeCrosshairValue((-1.99999d), true);
    double var9 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.PlotOrientation var10 = var0.getOrientation();
    java.awt.Stroke var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeZeroBaselineStroke(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.99999d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test118"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("December 2014");
//     var2.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Font var5 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("", var5);
//     java.lang.Object var7 = var6.clone();
//     org.jfree.chart.util.LogFormat var13 = new org.jfree.chart.util.LogFormat(0.12d, "{0}: ({1}, {2})", "0,000,000,000%", true);
//     org.jfree.chart.axis.NumberTickUnit var15 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d, (java.text.NumberFormat)var13, 255);
//     org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var24 = var20.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     var20.setBaseStroke(var26);
//     var17.setMinorTickMarkStroke(var26);
//     var17.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var31 = var17.getLocale();
//     org.jfree.chart.axis.TickUnitSource var32 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var31);
//     java.text.NumberFormat var33 = java.text.NumberFormat.getPercentInstance(var31);
//     boolean var34 = var13.equals((java.lang.Object)var31);
//     boolean var35 = var6.equals((java.lang.Object)var31);
//     org.jfree.data.xy.XYSeries var37 = null;
//     org.jfree.data.xy.XYSeriesCollection var38 = new org.jfree.data.xy.XYSeriesCollection(var37);
//     org.jfree.data.xy.XYSeries var39 = null;
//     org.jfree.data.xy.XYSeriesCollection var40 = new org.jfree.data.xy.XYSeriesCollection(var39);
//     boolean var41 = var38.hasListener((java.util.EventListener)var40);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var43 = null;
//     org.jfree.chart.plot.PolarPlot var44 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var38, var42, var43);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var44);
//     var45.clearSubtitles();
//     java.awt.Image var47 = null;
//     var45.setBackgroundImage(var47);
//     java.awt.Paint var49 = var45.getBorderPaint();
//     var6.setPaint(var49);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.text.TextBlock var52 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var54 = var53.clone();
//     boolean var55 = var52.equals((java.lang.Object)var53);
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.util.Size2D var57 = var52.calculateDimensions(var56);
//     org.jfree.chart.plot.PiePlot3D var60 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var61 = var60.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var64 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var68 = var64.getItemFillPaint(1, (-1), false);
//     var60.setLabelPaint(var68);
//     org.jfree.data.general.PieDataset var70 = var60.getDataset();
//     boolean var71 = var60.getSimpleLabels();
//     double var72 = var60.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
//     org.jfree.chart.title.TextTitle var74 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var75 = var74.getID();
//     org.jfree.chart.util.RectangleInsets var76 = var74.getPadding();
//     double var78 = var76.extendWidth(10.0d);
//     var73.setItemLabelPadding(var76);
//     org.jfree.chart.block.BlockContainer var80 = null;
//     var73.setWrapper(var80);
//     org.jfree.chart.util.RectangleAnchor var82 = var73.getLegendItemGraphicAnchor();
//     java.awt.geom.Rectangle2D var83 = org.jfree.chart.util.RectangleAnchor.createRectangle(var57, 12.0d, 1.0E-5d, var82);
//     java.lang.Object var84 = null;
//     java.lang.Object var85 = var6.draw(var51, var83, var84);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test119"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    boolean var11 = var8.hasListener((java.util.EventListener)var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
    java.awt.Paint var15 = var14.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var19 = var18.getMinorTickMarkPaint();
    var16.setLinePaint(var19);
    java.lang.String var21 = var16.getDescription();
    var16.setURLText("TimePeriodAnchor.START");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Pie 3D Plot"+ "'", var21.equals("Pie 3D Plot"));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test120"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.08d, (-1.99999d));
    org.jfree.data.Range var3 = var2.getWidthRange();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedHeight(1.0E-5d);
    double var6 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.99999d));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test121"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    java.awt.Stroke var18 = var0.getDomainGridlineStroke();
    java.io.ObjectOutputStream var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test122"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var1 = var0.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test123"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Shape var4 = var2.getSeriesShape(10);
    org.jfree.chart.plot.DrawingSupplier var5 = var2.getDrawingSupplier();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var8 = var6.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var11 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var12 = var11.getXValue();
    java.lang.String var13 = var11.toString();
    org.jfree.data.xy.XYDataItem var16 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var17 = var16.getXValue();
    var16.setY(0.0d);
    int var20 = var11.compareTo((java.lang.Object)var16);
    java.lang.Number var21 = var16.getX();
    var6.setDomainCrosshairColumnKey((java.lang.Comparable)var16);
    boolean var23 = var6.isRangeMinorGridlinesVisible();
    java.awt.Stroke var24 = var6.getDomainGridlineStroke();
    var6.setBackgroundAlpha(2.0f);
    java.awt.Paint var27 = var6.getRangeCrosshairPaint();
    var2.setBasePaint(var27, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "[-1.0, 0.0]"+ "'", var13.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (byte)(-1)+ "'", var21.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test124"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
//     org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var6 = var5.getXValue();
//     java.lang.String var7 = var5.toString();
//     org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var11 = var10.getXValue();
//     var10.setY(0.0d);
//     int var14 = var5.compareTo((java.lang.Object)var10);
//     java.lang.Number var15 = var10.getX();
//     var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var20 = var18.getRangeAxisLocation(1);
//     org.jfree.chart.util.RectangleEdge var21 = var18.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var23 = var18.getDomainAxisLocation(12);
//     var0.setDomainAxisLocation(1969, var23);
//     org.jfree.chart.LegendItemCollection var25 = var0.getLegendItems();
//     var0.setAnchorValue(0.0d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var0.getDomainMarkers(var29);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var0.getRangeMarkers(2147483647, var32);
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var38 = var37.getItemCount();
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year(1);
//     java.util.Date var41 = var40.getStart();
//     var37.add((org.jfree.data.time.RegularTimePeriod)var40, (java.lang.Number)Double.NaN, true);
//     var35.delete((org.jfree.data.time.RegularTimePeriod)var40);
//     var35.setMaximumItemAge(0L);
//     org.jfree.chart.axis.PeriodAxis var49 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange();
//     java.lang.String var51 = var50.toString();
//     var49.setRangeWithMargins((org.jfree.data.Range)var50);
//     java.util.Date var53 = var50.getLowerDate();
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month(var53);
//     var35.add((org.jfree.data.time.RegularTimePeriod)var54, (java.lang.Number)2, true);
//     var0.setDomainCrosshairColumnKey((java.lang.Comparable)var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var51.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test125"); }
// 
// 
//     org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = var2.getRenderer(0);
//     java.awt.Paint var5 = var2.getDomainCrosshairPaint();
//     java.awt.Paint var6 = var2.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var8 = var7.getOpposite();
//     var0.setRangeAxisLocation(100, var8, false);
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var13 = var12.getOutlineStroke();
//     double var14 = var12.getValue();
//     java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     int var19 = var18.getRGB();
//     java.lang.String var20 = var18.toString();
//     var12.setLabelPaint((java.awt.Paint)var18);
//     org.jfree.chart.util.LengthAdjustmentType var22 = var12.getLabelOffsetType();
//     org.jfree.chart.util.Layer var23 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var12, var23);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.data.general.DatasetGroup var26 = var25.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     var29.setBaseSeriesVisible(false, false);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var39 = var35.getItemFillPaint(1, (-1), false);
//     var29.setBaseLegendTextPaint(var39);
//     var25.setLabelLinkPaint(var39);
//     var0.setRangeTickBandPaint(var39);
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var46 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var50 = var46.getItemFillPaint(1, (-1), false);
//     java.awt.Font var52 = var46.getSeriesItemLabelFont(1);
//     java.awt.Paint var54 = var46.lookupSeriesOutlinePaint((-1));
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var58 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var62 = var58.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var63 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var64 = var63.getBaseSectionOutlineStroke();
//     var58.setBaseStroke(var64);
//     org.jfree.chart.labels.XYItemLabelGenerator var66 = var58.getBaseItemLabelGenerator();
//     java.awt.Color var71 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     java.awt.Color var72 = java.awt.Color.getColor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var71);
//     var58.setBaseItemLabelPaint((java.awt.Paint)var71);
//     var46.setSeriesOutlinePaint(100, (java.awt.Paint)var71, true);
//     var0.setRangeCrosshairPaint((java.awt.Paint)var71);
//     
//     // Checks the contract:  equals-hashcode on var35 and var46
//     assertTrue("Contract failed: equals-hashcode on var35 and var46", var35.equals(var46) ? var35.hashCode() == var46.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var46.", var35.equals(var46) == var46.equals(var35));
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test126"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    var0.setSeparatorsVisible(false);
    var0.setSectionDepth((-1.99999d));
    boolean var5 = var0.getSeparatorsVisible();
    boolean var6 = var0.getAutoPopulateSectionPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test127"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = var1.getRenderer(0);
//     java.awt.Paint var4 = var1.getDomainCrosshairPaint();
//     java.awt.Paint var5 = var1.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var6 = var1.getDomainAxisLocation();
//     org.jfree.data.xy.XYSeries var7 = null;
//     org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
//     org.jfree.data.xy.XYSeries var9 = null;
//     org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
//     boolean var11 = var8.hasListener((java.util.EventListener)var10);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
//     var14.setForegroundAlpha(100.0f);
//     boolean var17 = var14.isAngleLabelsVisible();
//     boolean var18 = var14.isAngleLabelsVisible();
//     boolean var19 = var14.isDomainZoomable();
//     var1.setParent((org.jfree.chart.plot.Plot)var14);
//     org.jfree.chart.event.RendererChangeEvent var21 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var1);
//     var0.rendererChanged(var21);
//     boolean var23 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var25 = var24.getRangeGridlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var28 = var27.getShadowsVisible();
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = null;
//     org.jfree.chart.axis.PeriodAxis var32 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var39 = var35.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     var35.setBaseStroke(var41);
//     var32.setMinorTickMarkStroke(var41);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var46 = var45.getOutlineStroke();
//     java.awt.geom.Rectangle2D var47 = null;
//     var27.drawRangeMarker(var29, var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.plot.Marker)var45, var47);
//     org.jfree.chart.plot.PiePlot3D var49 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var50 = var49.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var57 = var53.getItemFillPaint(1, (-1), false);
//     var49.setLabelPaint(var57);
//     org.jfree.data.general.PieDataset var59 = var49.getDataset();
//     var49.setAutoPopulateSectionOutlinePaint(false);
//     float var62 = var49.getBackgroundImageAlpha();
//     java.awt.Paint var63 = var49.getNoDataMessagePaint();
//     var45.setPaint(var63);
//     org.jfree.chart.util.Layer var65 = null;
//     boolean var66 = var24.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var45, var65);
//     var24.setRangeCrosshairValue(0.12d, true);
//     java.awt.Stroke var70 = var24.getOutlineStroke();
//     var0.setRangeMinorGridlineStroke(var70);
//     var0.mapDatasetToDomainAxis(2, 0);
//     org.jfree.data.time.Month var76 = new org.jfree.data.time.Month();
//     java.lang.String var77 = var76.toString();
//     org.jfree.data.time.Year var78 = var76.getYear();
//     org.jfree.data.time.Day var79 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var80 = var79.next();
//     org.jfree.chart.axis.PeriodAxis var81 = new org.jfree.chart.axis.PeriodAxis("Polar Plot", (org.jfree.data.time.RegularTimePeriod)var76, var80);
//     long var82 = var76.getLastMillisecond();
//     org.jfree.data.general.DefaultPieDataset var83 = new org.jfree.data.general.DefaultPieDataset();
//     java.lang.Object var84 = var83.clone();
//     org.jfree.chart.plot.PiePlot var85 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset)var83);
//     org.jfree.data.category.CategoryDataset var86 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var82, (org.jfree.data.KeyedValues)var83);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var87 = var0.getRendererForDataset(var86);
//     org.jfree.data.Range var89 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var86, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0.5f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var77 + "' != '" + "December 2014"+ "'", var77.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var89);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test128"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.data.general.PieDataset var10 = var0.getDataset();
    var0.setAutoPopulateSectionOutlinePaint(false);
    float var13 = var0.getBackgroundImageAlpha();
    java.awt.Paint var14 = var0.getNoDataMessagePaint();
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var18 = var17.getPlot();
    org.jfree.chart.plot.CategoryPlot var19 = var17.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var17.setSeriesURLGenerator(2, var21, true);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var17.setSeriesURLGenerator(10, var25);
    org.jfree.chart.labels.CategoryItemLabelGenerator var27 = var17.getBaseItemLabelGenerator();
    var17.setShadowVisible(true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var17.getLegendItemURLGenerator();
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var32 = var31.getTickLabelPaint();
    java.lang.String var33 = var31.getLabel();
    var31.setFixedDimension(Double.NaN);
    org.jfree.data.xy.XYSeries var36 = null;
    org.jfree.data.xy.XYSeriesCollection var37 = new org.jfree.data.xy.XYSeriesCollection(var36);
    org.jfree.data.xy.XYSeries var38 = null;
    org.jfree.data.xy.XYSeriesCollection var39 = new org.jfree.data.xy.XYSeriesCollection(var38);
    boolean var40 = var37.hasListener((java.util.EventListener)var39);
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.PolarItemRenderer var42 = null;
    org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var37, var41, var42);
    java.awt.Paint var44 = var43.getRadiusGridlinePaint();
    var31.setAxisLinePaint(var44);
    var17.setBaseOutlinePaint(var44, true);
    var0.setBaseSectionOutlinePaint(var44);
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test129"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    org.jfree.chart.plot.PlotOrientation var8 = var7.getOrientation();
    java.lang.String var9 = var7.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Polar Plot"+ "'", var9.equals("Polar Plot"));

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test130"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     var4.setBaseSeriesVisible(false, false);
//     java.awt.Font var9 = null;
//     var4.setSeriesItemLabelFont(3, var9, true);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var4.getBasePositiveItemLabelPosition();
//     boolean var14 = var12.equals((java.lang.Object)0.0f);
//     var0.setPositiveItemLabelPositionFallback(var12);
//     var0.setDefaultEntityRadius(0);
//     java.awt.Shape var18 = var0.getLegendBar();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var22 = var21.getDefaultEntityRadius();
//     java.awt.Shape var24 = var21.getSeriesShape(1);
//     org.jfree.chart.LegendItemCollection var25 = var21.getLegendItems();
//     org.jfree.chart.labels.StandardXYSeriesLabelGenerator var26 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
//     java.lang.Object var27 = var26.clone();
//     var21.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var26);
//     var0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var26);
//     org.jfree.chart.urls.XYURLGenerator var30 = var0.getBaseURLGenerator();
//     org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var34 = var33.getPlot();
//     org.jfree.chart.plot.CategoryPlot var35 = var33.getPlot();
//     org.jfree.chart.urls.CategoryURLGenerator var37 = null;
//     var33.setSeriesURLGenerator(2, var37, true);
//     double var40 = var33.getXOffset();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var44 = var33.getItemLabelGenerator(96, 10, false);
//     org.jfree.chart.labels.ItemLabelPosition var45 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var46 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     java.lang.Object var47 = var46.clone();
//     boolean var48 = var45.equals(var47);
//     var33.setPositiveItemLabelPositionFallback(var45);
//     var0.setPositiveItemLabelPositionFallback(var45);
//     
//     // Checks the contract:  equals-hashcode on var12 and var45
//     assertTrue("Contract failed: equals-hashcode on var12 and var45", var12.equals(var45) ? var12.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var12
//     assertTrue("Contract failed: equals-hashcode on var45 and var12", var45.equals(var12) ? var45.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test131"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
//     var0.setShadowVisible(true);
//     double var4 = var0.getBarAlignmentFactor();
//     org.jfree.chart.util.GradientPaintTransformer var5 = null;
//     var0.setGradientPaintTransformer(var5);
//     boolean var7 = var0.getUseYInterval();
//     double var8 = var0.getShadowXOffset();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     var11.setBaseSeriesVisible(false, false);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var21 = var17.getItemFillPaint(1, (-1), false);
//     var11.setBaseLegendTextPaint(var21);
//     org.jfree.chart.labels.XYItemLabelGenerator var24 = null;
//     var11.setSeriesItemLabelGenerator(3, var24, false);
//     int var27 = var11.getPassCount();
//     org.jfree.data.xy.XYSeries var28 = null;
//     org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     boolean var32 = var29.hasListener((java.util.EventListener)var31);
//     double var33 = var31.getIntervalPositionFactor();
//     org.jfree.data.Range var34 = var11.findRangeBounds((org.jfree.data.xy.XYDataset)var31);
//     double var36 = var31.getDomainLowerBound(true);
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var39 = var38.getItemCount();
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year(1);
//     java.util.Date var42 = var41.getStart();
//     var38.add((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var46 = null;
//     org.jfree.data.xy.XYSeriesCollection var47 = new org.jfree.data.xy.XYSeriesCollection(var46);
//     org.jfree.data.xy.XYSeries var48 = null;
//     org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
//     boolean var50 = var47.hasListener((java.util.EventListener)var49);
//     double var51 = var49.getIntervalPositionFactor();
//     var38.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var49);
//     org.jfree.data.Range var53 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var49);
//     org.jfree.data.xy.XYSeries var54 = null;
//     org.jfree.data.xy.XYSeriesCollection var55 = new org.jfree.data.xy.XYSeriesCollection(var54);
//     org.jfree.data.xy.XYSeries var56 = null;
//     org.jfree.data.xy.XYSeriesCollection var57 = new org.jfree.data.xy.XYSeriesCollection(var56);
//     boolean var58 = var55.hasListener((java.util.EventListener)var57);
//     double var59 = var57.getIntervalPositionFactor();
//     org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var57);
//     org.jfree.data.time.TimeSeries var62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var63 = var62.getItemCount();
//     org.jfree.data.time.Year var65 = new org.jfree.data.time.Year(1);
//     java.util.Date var66 = var65.getStart();
//     var62.add((org.jfree.data.time.RegularTimePeriod)var65, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var71 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var65, true);
//     org.jfree.data.xy.XYSeries var74 = var71.createCopy((-1), 1);
//     int var75 = var57.indexOf(var71);
//     var49.addSeries(var71);
//     var31.addSeries(var71);
//     org.jfree.data.Range var78 = var0.findRangeBounds((org.jfree.data.xy.XYDataset)var31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var81 = var31.getYValue((-237), 40);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var78);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test132"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.08d, (-1.99999d));
    org.jfree.data.Range var3 = var2.getWidthRange();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedHeight(1.0E-5d);
    org.jfree.data.Range var6 = var5.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test133"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(2.0f, (-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test134"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
    var1.setRangeWithMargins((org.jfree.data.Range)var13);
    java.lang.Object var15 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test135"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var3.setBaseSeriesVisible(false, false);
    java.awt.Font var8 = null;
    var3.setSeriesItemLabelFont(3, var8, true);
    java.awt.Color var14 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var15 = var14.darker();
    var3.setBaseOutlinePaint((java.awt.Paint)var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var18 = var17.getFont();
    var3.setBaseLegendTextFont(var18);
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM] version [-1.0, 0.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY [Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]:None\n[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM] LICENCE TERMS:\n[-1.0, 0.0]", var18);
    org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var30 = var26.getItemFillPaint(1, (-1), false);
    var22.setLabelPaint(var30);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var38 = var34.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var40 = var39.getBaseSectionOutlineStroke();
    var34.setBaseStroke(var40);
    var22.setLabelOutlineStroke(var40);
    double var43 = var22.getInteriorGap();
    java.awt.Paint var44 = var22.getLabelShadowPaint();
    java.awt.Font var45 = var22.getLabelFont();
    org.jfree.chart.plot.CombinedDomainXYPlot var46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = var47.getRenderer(0);
    java.awt.Paint var50 = var47.getDomainCrosshairPaint();
    java.awt.Paint var51 = var47.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var52 = var47.getDomainAxisLocation();
    java.awt.Paint var53 = var47.getDomainZeroBaselinePaint();
    var46.setRangeTickBandPaint(var53);
    org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("Pie 3D Plot", var45, var53, 0.0f);
    java.awt.Paint var57 = var56.getPaint();
    var20.addFragment(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test136"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
    org.jfree.data.xy.XYSeries var6 = null;
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
    org.jfree.data.xy.XYSeries var8 = null;
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
    boolean var10 = var7.hasListener((java.util.EventListener)var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var7, var11, var12);
    var13.setForegroundAlpha(100.0f);
    boolean var16 = var13.isAngleLabelsVisible();
    boolean var17 = var13.isAngleLabelsVisible();
    boolean var18 = var13.isDomainZoomable();
    var0.setParent((org.jfree.chart.plot.Plot)var13);
    org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var0);
    java.lang.String var21 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Combined_Domain_XYPlot"+ "'", var21.equals("Combined_Domain_XYPlot"));

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test137"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
    boolean var2 = var1.getAutoPopulateSeriesStroke();
    java.lang.Object var3 = var1.clone();
    var1.setDefaultEntityRadius(3);
    boolean var6 = var1.getPlotArea();
    boolean var7 = var1.getShapesVisible();
    boolean var8 = var1.getDataBoundsIncludesVisibleSeriesOnly();
    boolean var9 = var1.isOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test138"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    java.awt.Font var3 = var1.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test139"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    java.awt.Paint var1 = var0.getAggregatedItemsPaint();
    org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test140"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     var2.setBaseSeriesVisible(false, false);
//     java.awt.Paint var6 = var2.getBaseOutlinePaint();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
//     var2.setLegendTextPaint(3, var14);
//     java.lang.Boolean var17 = var2.getSeriesShapesVisible(2);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
//     java.util.List var23 = var20.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     var28.setBaseStroke(var34);
//     var25.setMinorTickMarkStroke(var34);
//     var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var39 = var25.getLocale();
//     var25.setPositiveArrowVisible(false);
//     double var42 = var25.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var25};
//     var20.setDomainAxes(var43);
//     org.jfree.chart.util.RectangleEdge var46 = var20.getRangeAxisEdge(0);
//     org.jfree.data.xy.XYSeries var48 = null;
//     org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
//     org.jfree.data.xy.XYSeries var50 = null;
//     org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
//     boolean var52 = var49.hasListener((java.util.EventListener)var51);
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var54 = null;
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var49, var53, var54);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var55);
//     boolean var57 = var20.equals((java.lang.Object)"");
//     org.jfree.data.xy.XYSeries var58 = null;
//     org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
//     org.jfree.data.xy.XYSeries var60 = null;
//     org.jfree.data.xy.XYSeriesCollection var61 = new org.jfree.data.xy.XYSeriesCollection(var60);
//     boolean var62 = var59.hasListener((java.util.EventListener)var61);
//     double var63 = var61.getIntervalPositionFactor();
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var65 = var2.initialise(var18, var19, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.data.xy.XYDataset)var61, var64);
//     int var66 = var65.getLastItemIndex();
//     org.jfree.chart.plot.XYCrosshairState var67 = new org.jfree.chart.plot.XYCrosshairState();
//     var65.setCrosshairState(var67);
//     org.jfree.data.xy.XYSeries var69 = null;
//     org.jfree.data.xy.XYSeriesCollection var70 = new org.jfree.data.xy.XYSeriesCollection(var69);
//     org.jfree.data.xy.XYSeries var71 = null;
//     org.jfree.data.xy.XYSeriesCollection var72 = new org.jfree.data.xy.XYSeriesCollection(var71);
//     boolean var73 = var70.hasListener((java.util.EventListener)var72);
//     double var75 = var72.getDomainUpperBound(true);
//     boolean var76 = var72.isAutoWidth();
//     var65.startSeriesPass((org.jfree.data.xy.XYDataset)var72, 2147483647, 0, (-237), 15, 2014);
//     org.jfree.data.xy.XYDatasetSelectionState var83 = null;
//     var65.setSelectionState(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1.0E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test141"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    java.awt.Paint var4 = var2.getLabelBackgroundPaint();
    org.jfree.chart.entity.PlotEntity var7 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var2, "Pie 3D Plot", "[-1.0, 0.0]");
    java.lang.String var8 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "PlotEntity: tooltip = Pie 3D Plot"+ "'", var8.equals("PlotEntity: tooltip = Pie 3D Plot"));

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test142"); }
// 
// 
//     org.jfree.chart.entity.EntityCollection var0 = null;
//     org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
//     var2.resizeRange2(100.0d, 4.0d);
//     org.jfree.chart.util.RectangleInsets var6 = var2.getLabelInsets();
//     var2.setMinorTickMarksVisible(true);
//     double var9 = var2.getUpperMargin();
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var14 = var13.getID();
//     java.lang.String var15 = var13.getToolTipText();
//     org.jfree.chart.util.HorizontalAlignment var16 = var13.getTextAlignment();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var19 = var18.getID();
//     org.jfree.chart.util.RectangleInsets var20 = var18.getPadding();
//     var18.setMaximumLinesToDisplay(1);
//     var18.setToolTipText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.awt.geom.Rectangle2D var25 = var18.getBounds();
//     org.jfree.data.xy.XYDataItem var28 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)12.0d);
//     java.lang.Object var29 = var13.draw(var17, var25, (java.lang.Object)100.0d);
//     boolean var30 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0d, (-1.88d), var25);
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var2.valueToJava2D(0.0d, var25, var31);
//     var1.setChartArea(var25);
//     org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
//     java.awt.Paint var36 = var34.getLabelBackgroundPaint();
//     double var37 = var34.getMinimumArcAngleToDraw();
//     org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape)var25, (org.jfree.chart.plot.Plot)var34);
//     org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var40 = var39.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var47 = var43.getItemFillPaint(1, (-1), false);
//     var39.setLabelPaint(var47);
//     org.jfree.data.general.PieDataset var49 = var39.getDataset();
//     boolean var50 = var39.getSimpleLabels();
//     double var51 = var39.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var54 = var53.getID();
//     org.jfree.chart.util.RectangleInsets var55 = var53.getPadding();
//     double var57 = var55.extendWidth(10.0d);
//     var52.setItemLabelPadding(var55);
//     org.jfree.chart.block.BlockContainer var59 = null;
//     var52.setWrapper(var59);
//     org.jfree.chart.util.RectangleAnchor var61 = var52.getLegendItemGraphicAnchor();
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var61);
//     org.jfree.data.time.Month var66 = new org.jfree.data.time.Month();
//     java.lang.String var67 = var66.toString();
//     org.jfree.data.time.Year var68 = var66.getYear();
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var70 = var69.next();
//     org.jfree.chart.axis.PeriodAxis var71 = new org.jfree.chart.axis.PeriodAxis("Polar Plot", (org.jfree.data.time.RegularTimePeriod)var66, var70);
//     long var72 = var66.getLastMillisecond();
//     org.jfree.data.general.DefaultPieDataset var73 = new org.jfree.data.general.DefaultPieDataset();
//     java.lang.Object var74 = var73.clone();
//     org.jfree.chart.plot.PiePlot var75 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset)var73);
//     org.jfree.data.category.CategoryDataset var76 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var72, (org.jfree.data.KeyedValues)var73);
//     org.jfree.data.general.PieDataset var78 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var76, 4);
//     org.jfree.data.time.TimeSeries var81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var82 = var81.getItemCount();
//     org.jfree.data.time.Year var84 = new org.jfree.data.time.Year(1);
//     java.util.Date var85 = var84.getStart();
//     var81.add((org.jfree.data.time.RegularTimePeriod)var84, (java.lang.Number)Double.NaN, true);
//     org.jfree.chart.entity.CategoryItemEntity var89 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var25, "Size2D[width=0.05, height=0.0]", "WMAP_Plot", var76, (java.lang.Comparable)(-1L), (java.lang.Comparable)Double.NaN);
//     java.lang.Comparable var90 = var89.getColumnKey();
//     java.lang.Comparable var91 = var89.getRowKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1.0E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0.12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 12.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var67 + "' != '" + "December 2014"+ "'", var67.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var90 + "' != '" + Double.NaN+ "'", var90.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var91 + "' != '" + (-1L)+ "'", var91.equals((-1L)));
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test143"); }


    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var3 = var2.clone();
    boolean var4 = var1.equals((java.lang.Object)var2);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.text.TextBlockAnchor var8 = null;
    java.awt.Shape var12 = var1.calculateBounds(var5, 100.0f, 10.0f, var8, 0.0f, 0.5f, 0.12d);
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var16.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var19 = var16.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("", var19);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var24 = var23.getDefaultEntityRadius();
    var23.setAutoPopulateSeriesShape(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var28 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = var28.getRenderer(0);
    java.awt.Paint var31 = var28.getDomainCrosshairPaint();
    java.awt.Paint var32 = var28.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var33 = var28.getDomainAxisLocation();
    java.awt.Paint var34 = var28.getDomainZeroBaselinePaint();
    var27.setRangeTickBandPaint(var34);
    var23.setBaseItemLabelPaint(var34);
    var23.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var40 = var23.lookupSeriesFillPaint((-1));
    var1.addLine("null", var19, var40);
    org.jfree.chart.text.TextLine var42 = new org.jfree.chart.text.TextLine("AxisLocation.TOP_OR_RIGHT", var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test144"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var9 = var8.getItemCount();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(1);
//     java.util.Date var12 = var11.getStart();
//     var8.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var11, true);
//     var3.addSeries(var17);
//     var17.add(0.08d, (java.lang.Number)1.0d, true);
//     var17.add(12.0d, (java.lang.Number)0.12d);
//     var17.clear();
//     var17.setNotify(true);
//     int var29 = var17.getMaximumItemCount();
//     java.util.List var30 = var17.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test145"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var1 = null;
    var0.plotChanged(var1);
    java.lang.Object var3 = var0.clone();
    java.lang.String var4 = var0.getPlotType();
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    java.awt.Paint var6 = var0.getRangeGridlinePaint();
    java.awt.Paint var7 = var0.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Combined Range XYPlot"+ "'", var4.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test146"); }


    org.jfree.chart.plot.XYCrosshairState var0 = new org.jfree.chart.plot.XYCrosshairState();
    double var1 = var0.getAnchorY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test147"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var4.setBaseSeriesVisible(false, false);
    java.awt.Font var9 = null;
    var4.setSeriesItemLabelFont(3, var9, true);
    org.jfree.chart.labels.ItemLabelPosition var12 = var4.getBasePositiveItemLabelPosition();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    var0.setPositiveItemLabelPositionFallback(var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var18 = var17.getItemCount();
    org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(1);
    java.util.Date var21 = var20.getStart();
    var17.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var26 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var20, true);
    org.jfree.data.xy.XYSeries var29 = var26.createCopy((-1), 1);
    boolean var30 = var0.equals((java.lang.Object)var26);
    double var31 = var0.getShadowXOffset();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var36 = var35.getDefaultEntityRadius();
    java.awt.Shape var38 = var35.getSeriesShape(1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
    var42.setSeriesOutlineStroke(0, var45, true);
    var35.setSeriesOutlineStroke(2, var45);
    var0.setSeriesOutlineStroke(1, var45, true);
    var0.setDrawBarOutline(false);
    java.awt.Paint var56 = var0.getItemPaint(20, (-3), true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test148"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
//     org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
//     org.jfree.chart.urls.CategoryURLGenerator var6 = null;
//     var2.setSeriesURLGenerator(2, var6, true);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var9.clearSectionOutlinePaints(false);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     java.awt.Paint var15 = var9.getBaseSectionOutlinePaint();
//     var2.setWallPaint(var15);
//     org.jfree.chart.plot.CategoryPlot var17 = var2.getPlot();
//     var2.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var23 = var22.getPlot();
//     org.jfree.chart.plot.CategoryPlot var24 = var22.getPlot();
//     org.jfree.chart.urls.CategoryURLGenerator var26 = null;
//     var22.setSeriesURLGenerator(2, var26, true);
//     org.jfree.chart.urls.CategoryURLGenerator var30 = null;
//     var22.setSeriesURLGenerator(10, var30);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var22.getBaseItemLabelGenerator();
//     var22.setShadowVisible(true);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var35 = var22.getLegendItemURLGenerator();
//     java.awt.Font var37 = var22.getSeriesItemLabelFont((-1));
//     java.awt.Paint var38 = var22.getBasePaint();
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var41 = var39.getRangeAxisLocation(1);
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     java.lang.String var44 = var43.toString();
//     org.jfree.data.time.Year var45 = var43.getYear();
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var47 = var46.next();
//     org.jfree.chart.axis.PeriodAxis var48 = new org.jfree.chart.axis.PeriodAxis("Polar Plot", (org.jfree.data.time.RegularTimePeriod)var43, var47);
//     long var49 = var43.getLastMillisecond();
//     org.jfree.data.general.DefaultPieDataset var50 = new org.jfree.data.general.DefaultPieDataset();
//     java.lang.Object var51 = var50.clone();
//     org.jfree.chart.plot.PiePlot var52 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset)var50);
//     org.jfree.data.category.CategoryDataset var53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var49, (org.jfree.data.KeyedValues)var50);
//     var39.setDataset(var53);
//     org.jfree.data.Range var56 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var53, false);
//     org.jfree.data.Range var57 = var22.findRangeBounds(var53);
//     org.jfree.data.Range var59 = var2.findRangeBounds(var53, false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "December 2014"+ "'", var44.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var59);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test149"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    var2.setLegendTextPaint(3, var14);
    java.lang.Boolean var17 = var2.getSeriesShapesVisible(2);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
    java.util.List var23 = var20.getSubplots();
    org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
    var28.setBaseStroke(var34);
    var25.setMinorTickMarkStroke(var34);
    var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var39 = var25.getLocale();
    var25.setPositiveArrowVisible(false);
    double var42 = var25.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var25};
    var20.setDomainAxes(var43);
    org.jfree.chart.util.RectangleEdge var46 = var20.getRangeAxisEdge(0);
    org.jfree.data.xy.XYSeries var48 = null;
    org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
    org.jfree.data.xy.XYSeries var50 = null;
    org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
    boolean var52 = var49.hasListener((java.util.EventListener)var51);
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var49, var53, var54);
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var55);
    boolean var57 = var20.equals((java.lang.Object)"");
    org.jfree.data.xy.XYSeries var58 = null;
    org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
    org.jfree.data.xy.XYSeries var60 = null;
    org.jfree.data.xy.XYSeriesCollection var61 = new org.jfree.data.xy.XYSeriesCollection(var60);
    boolean var62 = var59.hasListener((java.util.EventListener)var61);
    double var63 = var61.getIntervalPositionFactor();
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var65 = var2.initialise(var18, var19, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.data.xy.XYDataset)var61, var64);
    int var66 = var65.getLastItemIndex();
    var65.setProcessVisibleItemsOnly(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test150"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset();
    java.lang.Object var2 = var1.clone();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)1.0d);
    java.lang.String var8 = var7.getURLText();
    java.lang.String var9 = var7.getToolTipText();
    java.lang.Object var10 = var7.clone();
    java.lang.String var11 = var7.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test151"); }
// 
// 
//     org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.event.PlotChangeEvent var1 = null;
//     var0.plotChanged(var1);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.AxisLocation var4 = var0.getDomainAxisLocation();
//     java.lang.Object var5 = var0.clone();
//     java.lang.String var6 = var0.getNoDataMessage();
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = var7.getRenderer(0);
//     java.util.List var10 = var7.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var19 = var15.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var15.setBaseStroke(var21);
//     var12.setMinorTickMarkStroke(var21);
//     var12.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var26 = var12.getLocale();
//     var12.setPositiveArrowVisible(false);
//     double var29 = var12.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var12};
//     var7.setDomainAxes(var30);
//     org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge(0);
//     org.jfree.data.xy.XYSeries var35 = null;
//     org.jfree.data.xy.XYSeriesCollection var36 = new org.jfree.data.xy.XYSeriesCollection(var35);
//     org.jfree.data.xy.XYSeries var37 = null;
//     org.jfree.data.xy.XYSeriesCollection var38 = new org.jfree.data.xy.XYSeriesCollection(var37);
//     boolean var39 = var36.hasListener((java.util.EventListener)var38);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var36, var40, var41);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var42);
//     boolean var44 = var7.equals((java.lang.Object)"");
//     org.jfree.chart.axis.AxisLocation var46 = var7.getDomainAxisLocation(10);
//     var0.add((org.jfree.chart.plot.XYPlot)var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var48 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = var48.getRenderer(0);
//     org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var52 = var51.getRangeGridlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var55 = var54.getShadowsVisible();
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.plot.CategoryPlot var57 = null;
//     org.jfree.chart.axis.PeriodAxis var59 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var62 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var66 = var62.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var67 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var68 = var67.getBaseSectionOutlineStroke();
//     var62.setBaseStroke(var68);
//     var59.setMinorTickMarkStroke(var68);
//     org.jfree.chart.plot.ValueMarker var72 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var73 = var72.getOutlineStroke();
//     java.awt.geom.Rectangle2D var74 = null;
//     var54.drawRangeMarker(var56, var57, (org.jfree.chart.axis.ValueAxis)var59, (org.jfree.chart.plot.Marker)var72, var74);
//     org.jfree.chart.plot.PiePlot3D var76 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var77 = var76.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var80 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var84 = var80.getItemFillPaint(1, (-1), false);
//     var76.setLabelPaint(var84);
//     org.jfree.data.general.PieDataset var86 = var76.getDataset();
//     var76.setAutoPopulateSectionOutlinePaint(false);
//     float var89 = var76.getBackgroundImageAlpha();
//     java.awt.Paint var90 = var76.getNoDataMessagePaint();
//     var72.setPaint(var90);
//     org.jfree.chart.util.Layer var92 = null;
//     boolean var93 = var51.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var72, var92);
//     var51.setRangeCrosshairValue(0.12d, true);
//     java.awt.Stroke var97 = var51.getOutlineStroke();
//     var48.setRangeMinorGridlineStroke(var97);
//     var7.setRangeMinorGridlineStroke(var97);
//     
//     // Checks the contract:  equals-hashcode on var20 and var67
//     assertTrue("Contract failed: equals-hashcode on var20 and var67", var20.equals(var67) ? var20.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var20
//     assertTrue("Contract failed: equals-hashcode on var67 and var20", var67.equals(var20) ? var67.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test152"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    var5.setBaseStroke(var11);
    var2.setMinorTickMarkStroke(var11);
    var2.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var16 = var2.getLocale();
    var2.setPositiveArrowVisible(false);
    double var19 = var2.getAutoRangeMinimumSize();
    org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var21 = var20.previous();
    var2.setFirst((org.jfree.data.time.RegularTimePeriod)var20);
    org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("Pie 3D Plot");
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis)var24);
    var24.configure();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var30 = var29.getDefaultEntityRadius();
    java.awt.Shape var32 = var29.getSeriesShape(1);
    org.jfree.chart.LegendItemCollection var33 = var29.getLegendItems();
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
    boolean var35 = var34.isDomainCrosshairLockedOnData();
    boolean var36 = var34.isDomainZoomable();
    var34.setDomainMinorGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test153"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     java.awt.Paint var2 = var0.getLabelBackgroundPaint();
//     org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var4 = var3.getTickLabelPaint();
//     var0.setOutlinePaint(var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
//     java.awt.Paint var10 = var8.getLabelBackgroundPaint();
//     java.lang.Integer var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.plot.PiePlotState var13 = var0.initialise(var6, var7, (org.jfree.chart.plot.PiePlot)var8, var11, var12);
//     boolean var14 = var8.getAutoPopulateSectionPaint();
//     org.jfree.chart.util.Rotation var15 = var8.getDirection();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.SerialDate var17 = var16.getSerialDate();
//     java.lang.String var18 = var17.toString();
//     org.jfree.data.time.SerialDate var20 = var17.getFollowingDayOfWeek(2);
//     org.jfree.data.time.SerialDate var22 = var20.getPreviousDayOfWeek(2);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.SerialDate var25 = var24.getSerialDate();
//     java.lang.String var26 = var25.toString();
//     org.jfree.data.time.SerialDate var28 = var25.getFollowingDayOfWeek(2);
//     org.jfree.data.time.SerialDate var30 = var28.getPreviousDayOfWeek(2);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2, var28);
//     org.jfree.data.time.SerialDate var32 = var22.getEndOfCurrentMonth(var31);
//     boolean var33 = var15.equals((java.lang.Object)var22);
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle("hi!");
//     boolean var36 = var35.getExpandToFitSpace();
//     java.awt.Paint var37 = var35.getPaint();
//     boolean var38 = var15.equals((java.lang.Object)var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test154"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
    boolean var27 = var0.isRangeZoomable();
    var0.clearDomainAxes();
    var0.setDomainCrosshairValue(0.2d, true);
    int var32 = var0.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test155"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
    java.awt.Stroke var27 = var0.getDomainGridlineStroke();
    org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var32 = var31.getItemCount();
    org.jfree.data.time.Year var34 = new org.jfree.data.time.Year(1);
    java.util.Date var35 = var34.getStart();
    var31.add((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var40 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var34, true);
    org.jfree.data.time.Year var42 = new org.jfree.data.time.Year(1);
    org.jfree.chart.axis.PeriodAxis var43 = new org.jfree.chart.axis.PeriodAxis("$0.00?DomainOrder.NONE=3&amp;=2", (org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var42);
    var43.setNegativeArrowVisible(true);
    var43.setVisible(true);
    var43.setMinorTickMarkOutsideLength(0.0f);
    boolean var50 = var43.isPositiveArrowVisible();
    var0.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis)var43, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test156"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getRangeGridlineStroke();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var4 = var3.getShadowsVisible();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var15 = var11.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
    var11.setBaseStroke(var17);
    var8.setMinorTickMarkStroke(var17);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var22 = var21.getOutlineStroke();
    java.awt.geom.Rectangle2D var23 = null;
    var3.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.plot.Marker)var21, var23);
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var33 = var29.getItemFillPaint(1, (-1), false);
    var25.setLabelPaint(var33);
    org.jfree.data.general.PieDataset var35 = var25.getDataset();
    var25.setAutoPopulateSectionOutlinePaint(false);
    float var38 = var25.getBackgroundImageAlpha();
    java.awt.Paint var39 = var25.getNoDataMessagePaint();
    var21.setPaint(var39);
    org.jfree.chart.util.Layer var41 = null;
    boolean var42 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var21, var41);
    var0.setRangeGridlinesVisible(false);
    var0.setRangePannable(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test157"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    java.util.List var9 = var1.getItems();
    boolean var10 = var1.getNotify();
    org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var15 = var14.getItemCount();
    org.jfree.data.time.Year var17 = new org.jfree.data.time.Year(1);
    java.util.Date var18 = var17.getStart();
    var14.add((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)Double.NaN, true);
    var12.delete((org.jfree.data.time.RegularTimePeriod)var17);
    org.jfree.data.time.RegularTimePeriod var23 = var17.next();
    java.lang.Number var24 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var17);
    java.lang.String var25 = var1.getRangeDescription();
    boolean var26 = var1.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + Double.NaN+ "'", var24.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Value"+ "'", var25.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test158"); }


    java.text.NumberFormat var2 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var4 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var4, var5);
    var4.setMinimumIntegerDigits(10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var2, var4);
    java.util.Currency var10 = var4.getCurrency();
    java.math.RoundingMode var11 = var4.getRoundingMode();
    int var12 = var4.getMaximumIntegerDigits();
    java.text.DateFormat var13 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var14 = new org.jfree.chart.labels.StandardXYToolTipGenerator("[-1.0, 0.0]", var4, var13);
    java.lang.String var15 = var14.getFormatString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "[-1.0, 0.0]"+ "'", var15.equals("[-1.0, 0.0]"));

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test159"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var9 = var8.getItemCount();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(1);
//     java.util.Date var12 = var11.getStart();
//     var8.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var11, true);
//     var3.addSeries(var17);
//     java.beans.PropertyChangeListener var19 = null;
//     var17.addPropertyChangeListener(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test160"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(1);
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(1);
    java.util.Date var6 = var5.getStart();
    org.jfree.data.time.DateRange var7 = new org.jfree.data.time.DateRange(var3, var6);
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
    java.awt.Paint var10 = var8.getLabelBackgroundPaint();
    boolean var11 = var7.equals((java.lang.Object)var10);
    var0.setSeparatorPaint(var10);
    double var13 = var0.getOuterSeparatorExtension();
    var0.setSectionDepth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test161"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    int var2 = var0.getIndex((java.lang.Comparable)1969);
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset)var0);
    var3.setOuterSeparatorExtension(0.08d);
    org.jfree.chart.StandardChartTheme var7 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
    var8.setLabelPaint(var16);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var24 = var20.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
    var20.setBaseStroke(var26);
    var8.setLabelOutlineStroke(var26);
    double var29 = var8.getInteriorGap();
    java.awt.Paint var30 = var8.getLabelShadowPaint();
    var7.setPlotOutlinePaint(var30);
    org.jfree.chart.renderer.category.BarPainter var32 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var7.setBarPainter(var32);
    java.awt.Font var34 = var7.getExtraLargeFont();
    java.awt.Paint var35 = var7.getWallPaint();
    var3.setLabelBackgroundPaint(var35);
    var3.setSeparatorsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test162"); }


    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(0.12d, "{0}: ({1}, {2})", "0,000,000,000%", true);
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(1.0E-5d, (java.text.NumberFormat)var5, 255);
    org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
    var12.setBaseStroke(var18);
    var9.setMinorTickMarkStroke(var18);
    var9.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var23 = var9.getLocale();
    org.jfree.chart.axis.TickUnitSource var24 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var23);
    java.text.NumberFormat var25 = java.text.NumberFormat.getPercentInstance(var23);
    boolean var26 = var5.equals((java.lang.Object)var23);
    java.lang.Object var27 = var5.clone();
    org.jfree.chart.util.LogFormat var33 = new org.jfree.chart.util.LogFormat(0.12d, "{0}: ({1}, {2})", "0,000,000,000%", true);
    java.lang.StringBuffer var35 = null;
    java.text.FieldPosition var36 = null;
    java.lang.StringBuffer var37 = var33.format((-1L), var35, var36);
    java.text.FieldPosition var38 = null;
    java.lang.StringBuffer var39 = var5.format(1.025d, var35, var38);
    java.text.NumberFormat var40 = var5.getExponentFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test163"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    org.jfree.chart.annotations.XYAnnotation var1 = null;
    boolean var2 = var0.removeAnnotation(var1);
    var0.setStepPoint(9.990000000000001E-6d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test164"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.resizeRange2(100.0d, 4.0d);
    var0.setRangeAboutValue(0.08d, 4.0d);
    var0.setAutoRangeIncludesZero(true);
    var0.setRangeAboutValue(0.0d, 1.025d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test165"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d);
    var0.clearDomainMarkers();
    java.util.List var21 = var0.getAnnotations();
    int var22 = var0.getCrosshairDatasetIndex();
    org.jfree.chart.axis.AxisSpace var23 = null;
    var0.setFixedRangeAxisSpace(var23);
    java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test166"); }
// 
// 
//     org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var4 = var3.getItemCount();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
//     java.util.Date var7 = var6.getStart();
//     var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var6, true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(1);
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("$0.00?DomainOrder.NONE=3&amp;=2", (org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var14);
//     var0.setValue((java.lang.Comparable)"$0.00?DomainOrder.NONE=3&amp;=2", (java.lang.Number)10.0d);
//     var0.clear();
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.SerialDate var20 = var19.getSerialDate();
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.time.SerialDate var23 = var20.getFollowingDayOfWeek(2);
//     var0.setValue((java.lang.Comparable)var20, 1.0d);
//     var0.clear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var28 = var0.getValue((java.lang.Comparable)2);
//       fail("Expected exception of type org.jfree.data.UnknownKeyException");
//     } catch (org.jfree.data.UnknownKeyException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test167"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var1 = null;
    var0.plotChanged(var1);
    java.lang.Object var3 = var0.clone();
    var0.setWeight((-524290));
    org.jfree.chart.plot.Plot var6 = var0.getRootPlot();
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    boolean var11 = var8.hasListener((java.util.EventListener)var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
    java.awt.Paint var15 = var14.getRadiusGridlinePaint();
    var0.setOutlinePaint(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test168"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var9.clearSubtitles();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    var9.setBackgroundImageAlpha(10.0f);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var18 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var19 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var20 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var18, var19);
    var16.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var20, false);
    org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
    var23.setLabelPaint(var31);
    org.jfree.data.general.PieDataset var33 = var23.getDataset();
    boolean var34 = var23.getSimpleLabels();
    double var35 = var23.getDepthFactor();
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
    java.lang.String var38 = var37.getID();
    org.jfree.chart.util.RectangleInsets var39 = var37.getPadding();
    double var41 = var39.extendWidth(10.0d);
    var36.setItemLabelPadding(var39);
    org.jfree.chart.block.BlockContainer var43 = null;
    var36.setWrapper(var43);
    boolean var45 = var20.equals((java.lang.Object)var36);
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var47 = var46.clone();
    org.jfree.chart.util.HorizontalAlignment var48 = var46.getTextAlignment();
    boolean var50 = var48.equals((java.lang.Object)(-1L));
    var36.setHorizontalAlignment(var48);
    var9.addLegend(var36);
    java.awt.Paint var53 = var9.getBackgroundPaint();
    java.lang.Object var54 = var9.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test169"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var1 = var0.getShadowsVisible();
    org.jfree.chart.renderer.category.BarPainter var2 = var0.getBarPainter();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var4 = var3.getShadowsVisible();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = null;
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var15 = var11.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
    var11.setBaseStroke(var17);
    var8.setMinorTickMarkStroke(var17);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var22 = var21.getOutlineStroke();
    java.awt.geom.Rectangle2D var23 = null;
    var3.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.plot.Marker)var21, var23);
    var3.setShadowYOffset(4.0d);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var33 = var29.getItemFillPaint(1, (-1), false);
    java.awt.Font var35 = var29.getSeriesItemLabelFont(1);
    java.awt.Paint var37 = var29.lookupSeriesOutlinePaint((-1));
    org.jfree.chart.labels.ItemLabelPosition var39 = var29.getSeriesNegativeItemLabelPosition(2);
    var3.setBaseNegativeItemLabelPosition(var39);
    var0.setPositiveItemLabelPositionFallback(var39);
    double var42 = var0.getUpperClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test170"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var2 = var1.getItemCount();
//     org.jfree.data.time.TimeSeries var3 = null;
//     org.jfree.data.time.TimeSeries var4 = var1.addAndOrUpdate(var3);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test171"); }


    org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var2 = var1.getAdjustForDaylightSaving();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(1);
    java.util.Date var8 = var7.getStart();
    org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange(var5, var8);
    long var10 = var1.toTimelineValue(var5);
    org.jfree.data.time.Year var12 = new org.jfree.data.time.Year(1);
    java.util.Date var13 = var12.getStart();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("null");
    boolean var17 = var15.isHiddenValue(644288400000L);
    java.awt.Shape var22 = null;
    org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var25 = null;
    org.jfree.data.xy.XYSeriesCollection var26 = new org.jfree.data.xy.XYSeriesCollection(var25);
    org.jfree.data.xy.XYSeries var27 = null;
    org.jfree.data.xy.XYSeriesCollection var28 = new org.jfree.data.xy.XYSeriesCollection(var27);
    boolean var29 = var26.hasListener((java.util.EventListener)var28);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.PolarItemRenderer var31 = null;
    org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var26, var30, var31);
    java.awt.Paint var33 = var32.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var22, var24, var33);
    java.lang.String var35 = var34.getDescription();
    org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
    boolean var37 = var34.equals((java.lang.Object)var36);
    java.util.TimeZone var38 = var36.getTimeZone();
    var15.setTimeZone(var38);
    org.jfree.data.time.Year var40 = new org.jfree.data.time.Year(var13, var38);
    org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(var5, var38);
    org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("TimePeriodAnchor.START", var38);
    org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var42);
    boolean var44 = var42.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-17478676800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "Pie 3D Plot"+ "'", var35.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test172"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.zoomRange(0.0d, Double.NaN);
    org.jfree.chart.event.AxisChangeEvent var4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test173"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d);
    var0.clearDomainMarkers();
    java.util.List var21 = var0.getAnnotations();
    java.awt.Stroke var22 = var0.getRangeGridlineStroke();
    boolean var23 = var0.isRangeMinorGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test174"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    double var5 = var3.getIntervalPositionFactor();
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var3);
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var9 = var8.getItemCount();
    org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(1);
    java.util.Date var12 = var11.getStart();
    var8.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var11, true);
    org.jfree.data.xy.XYSeries var20 = var17.createCopy((-1), 1);
    int var21 = var3.indexOf(var17);
    org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var30 = var26.getItemFillPaint(1, (-1), false);
    var22.setLabelPaint(var30);
    org.jfree.chart.event.ChartChangeEvent var32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22);
    org.jfree.chart.urls.PieURLGenerator var33 = var22.getURLGenerator();
    var22.setDarkerSides(true);
    float var36 = var22.getBackgroundImageAlpha();
    org.jfree.data.xy.XYDataItem var39 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var40 = var39.getXValue();
    var39.setY(0.0d);
    var39.setY(0.12d);
    java.lang.Object var45 = var39.clone();
    java.awt.Paint var46 = var22.getSectionOutlinePaint((java.lang.Comparable)var39);
    var17.add(var39, false);
    org.jfree.data.time.TimeSeries var51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var39, "SerialDate.weekInMonthToString(): invalid code.", "Category Plot");
    org.jfree.data.time.Year var53 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var53, 1.0d);
    java.lang.Object var56 = var55.clone();
    var51.add(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test175"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    java.awt.Paint var25 = var0.getDomainCrosshairPaint();
    boolean var26 = var0.isDomainMinorGridlinesVisible();
    var0.setGap(Double.POSITIVE_INFINITY);
    org.jfree.chart.plot.CombinedRangeXYPlot var29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var30 = null;
    var29.plotChanged(var30);
    java.util.List var32 = var29.getSubplots();
    org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var35 = var34.getItemCount();
    org.jfree.data.time.Year var37 = new org.jfree.data.time.Year(1);
    java.util.Date var38 = var37.getStart();
    var34.add((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var42 = null;
    org.jfree.data.xy.XYSeriesCollection var43 = new org.jfree.data.xy.XYSeriesCollection(var42);
    org.jfree.data.xy.XYSeries var44 = null;
    org.jfree.data.xy.XYSeriesCollection var45 = new org.jfree.data.xy.XYSeriesCollection(var44);
    boolean var46 = var43.hasListener((java.util.EventListener)var45);
    double var47 = var45.getIntervalPositionFactor();
    var34.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var45);
    boolean var49 = var29.equals((java.lang.Object)var34);
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var52 = var51.getOutlineStroke();
    double var53 = var51.getValue();
    java.awt.Color var57 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var58 = var57.getRGB();
    java.lang.String var59 = var57.toString();
    var51.setLabelPaint((java.awt.Paint)var57);
    org.jfree.chart.util.Layer var61 = null;
    boolean var62 = var29.removeDomainMarker((org.jfree.chart.plot.Marker)var51, var61);
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var51);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var66 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var67 = var66.getDefaultEntityRadius();
    java.awt.Shape var69 = var66.getSeriesShape(1);
    org.jfree.chart.LegendItemCollection var70 = var66.getLegendItems();
    var66.setBaseLinesVisible(false);
    java.lang.Boolean var74 = var66.getSeriesShapesVisible((-16777216));
    var0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var66);
    org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.PeriodAxis var79 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var80 = var79.getRange();
    org.jfree.data.xy.XYSeries var81 = null;
    org.jfree.data.xy.XYSeriesCollection var82 = new org.jfree.data.xy.XYSeriesCollection(var81);
    org.jfree.data.xy.XYSeries var83 = null;
    org.jfree.data.xy.XYSeriesCollection var84 = new org.jfree.data.xy.XYSeriesCollection(var83);
    boolean var85 = var82.hasListener((java.util.EventListener)var84);
    org.jfree.chart.axis.ValueAxis var86 = null;
    org.jfree.chart.renderer.PolarItemRenderer var87 = null;
    org.jfree.chart.plot.PolarPlot var88 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var82, var86, var87);
    var88.setForegroundAlpha(100.0f);
    boolean var91 = var88.isAngleLabelsVisible();
    boolean var92 = var88.isAngleLabelsVisible();
    boolean var93 = var88.isDomainZoomable();
    java.lang.Object var94 = var88.clone();
    boolean var95 = var88.isAngleGridlinesVisible();
    boolean var96 = var80.equals((java.lang.Object)var88);
    var77.setRange(var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-524290), (org.jfree.chart.axis.ValueAxis)var77, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var59.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test176"); }


    org.jfree.chart.StandardChartTheme var3 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    var4.setLabelPaint(var12);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var20 = var16.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
    var16.setBaseStroke(var22);
    var4.setLabelOutlineStroke(var22);
    double var25 = var4.getInteriorGap();
    java.awt.Paint var26 = var4.getLabelShadowPaint();
    var3.setPlotOutlinePaint(var26);
    org.jfree.chart.plot.IntervalMarker var28 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.08d, var26);
    org.jfree.chart.util.RectangleAnchor var29 = var28.getLabelAnchor();
    java.lang.Object var30 = var28.clone();
    org.jfree.chart.renderer.xy.XYAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYAreaRenderer(1);
    java.awt.Shape var33 = var32.getLegendArea();
    org.jfree.chart.util.GradientPaintTransformer var34 = var32.getGradientTransformer();
    var28.setGradientPaintTransformer(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test177"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var2.getRenderer(0);
    java.awt.Paint var5 = var2.getDomainCrosshairPaint();
    java.awt.Paint var6 = var2.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var8 = var7.getOpposite();
    var0.setRangeAxisLocation(100, var8, false);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    java.awt.geom.Point2D var13 = null;
    var0.zoomRangeAxes(0.12d, var12, var13, false);
    double var16 = var0.getDomainCrosshairValue();
    org.jfree.chart.plot.CrosshairState var17 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.data.xy.XYSeries var22 = null;
    org.jfree.data.xy.XYSeriesCollection var23 = new org.jfree.data.xy.XYSeriesCollection(var22);
    org.jfree.data.xy.XYSeries var24 = null;
    org.jfree.data.xy.XYSeriesCollection var25 = new org.jfree.data.xy.XYSeriesCollection(var24);
    boolean var26 = var23.hasListener((java.util.EventListener)var25);
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.PolarItemRenderer var28 = null;
    org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var23, var27, var28);
    var29.setForegroundAlpha(100.0f);
    var29.setAngleGridlinesVisible(true);
    org.jfree.chart.plot.PlotOrientation var34 = var29.getOrientation();
    var17.updateCrosshairPoint(0.0d, 0.0d, 0.0d, 5.0d, var34);
    var0.setOrientation(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test178"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var9.clearSubtitles();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    var9.setBackgroundImageAlpha(10.0f);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var18 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var19 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var20 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var18, var19);
    var16.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var20, false);
    org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
    var23.setLabelPaint(var31);
    org.jfree.data.general.PieDataset var33 = var23.getDataset();
    boolean var34 = var23.getSimpleLabels();
    double var35 = var23.getDepthFactor();
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
    java.lang.String var38 = var37.getID();
    org.jfree.chart.util.RectangleInsets var39 = var37.getPadding();
    double var41 = var39.extendWidth(10.0d);
    var36.setItemLabelPadding(var39);
    org.jfree.chart.block.BlockContainer var43 = null;
    var36.setWrapper(var43);
    boolean var45 = var20.equals((java.lang.Object)var36);
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var47 = var46.clone();
    org.jfree.chart.util.HorizontalAlignment var48 = var46.getTextAlignment();
    boolean var50 = var48.equals((java.lang.Object)(-1L));
    var36.setHorizontalAlignment(var48);
    var9.addLegend(var36);
    java.awt.geom.Rectangle2D var53 = var36.getBounds();
    org.jfree.chart.util.RectangleInsets var54 = var36.getItemLabelPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test179"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("[-1.0, 0.0]");
//     org.jfree.chart.axis.SegmentedTimeline var2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     boolean var3 = var2.getAdjustForDaylightSaving();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(1);
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(1);
//     java.util.Date var9 = var8.getStart();
//     org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange(var6, var9);
//     long var11 = var2.toTimelineValue(var6);
//     int var12 = var2.getSegmentsExcluded();
//     int var13 = var2.getGroupSegmentCount();
//     boolean var16 = var2.containsDomainRange(86400000L, 86400000L);
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var19 = var18.getItemCount();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(1);
//     java.util.Date var22 = var21.getStart();
//     var18.add((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var26 = null;
//     org.jfree.data.xy.XYSeriesCollection var27 = new org.jfree.data.xy.XYSeriesCollection(var26);
//     org.jfree.data.xy.XYSeries var28 = null;
//     org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
//     boolean var30 = var27.hasListener((java.util.EventListener)var29);
//     double var31 = var29.getIntervalPositionFactor();
//     var18.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var29);
//     org.jfree.data.xy.XYSeries var33 = null;
//     org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
//     org.jfree.data.xy.XYSeries var35 = null;
//     org.jfree.data.xy.XYSeriesCollection var36 = new org.jfree.data.xy.XYSeriesCollection(var35);
//     boolean var37 = var34.hasListener((java.util.EventListener)var36);
//     double var39 = var36.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var42 = var41.getItemCount();
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year(1);
//     java.util.Date var45 = var44.getStart();
//     var41.add((org.jfree.data.time.RegularTimePeriod)var44, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var50 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var44, true);
//     var36.addSeries(var50);
//     java.util.List var52 = var50.getItems();
//     org.jfree.data.Range var54 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset)var29, var52, true);
//     var2.addExceptions(var52);
//     var1.setTimeline((org.jfree.chart.axis.Timeline)var2);
//     org.jfree.chart.axis.SegmentedTimeline var57 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     boolean var58 = var57.getAdjustForDaylightSaving();
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year(1);
//     java.util.Date var61 = var60.getStart();
//     org.jfree.data.time.Year var63 = new org.jfree.data.time.Year(1);
//     java.util.Date var64 = var63.getStart();
//     org.jfree.data.time.DateRange var65 = new org.jfree.data.time.DateRange(var61, var64);
//     long var66 = var57.toTimelineValue(var61);
//     long var67 = var57.getSegmentsExcludedSize();
//     var2.setBaseTimeline(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-17478676800000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == (-17478676800000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 61200000L);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test180"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var4.setBaseSeriesVisible(false, false);
    java.awt.Font var9 = null;
    var4.setSeriesItemLabelFont(3, var9, true);
    org.jfree.chart.labels.ItemLabelPosition var12 = var4.getBasePositiveItemLabelPosition();
    boolean var14 = var12.equals((java.lang.Object)0.0f);
    var0.setPositiveItemLabelPositionFallback(var12);
    var0.setDefaultEntityRadius(0);
    java.awt.Shape var18 = var0.getLegendBar();
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = var19.getRenderer(0);
    java.util.List var22 = var19.getSubplots();
    org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
    var27.setBaseStroke(var33);
    var24.setMinorTickMarkStroke(var33);
    var24.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var38 = var24.getLocale();
    var24.setPositiveArrowVisible(false);
    double var41 = var24.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var24};
    var19.setDomainAxes(var42);
    org.jfree.chart.util.RectangleEdge var45 = var19.getRangeAxisEdge(0);
    java.awt.Stroke var46 = var19.getDomainGridlineStroke();
    org.jfree.chart.plot.CombinedDomainXYPlot var47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = var47.getRenderer(0);
    java.awt.Paint var50 = var47.getDomainCrosshairPaint();
    java.awt.Paint var51 = var47.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var52 = var47.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var53 = var52.getOpposite();
    org.jfree.chart.axis.AxisLocation var54 = var53.getOpposite();
    var19.setRangeAxisLocation(var54);
    org.jfree.chart.entity.PlotEntity var56 = new org.jfree.chart.entity.PlotEntity(var18, (org.jfree.chart.plot.Plot)var19);
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.clone(var18);
    org.jfree.chart.plot.PiePlot3D var58 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var59 = var58.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var62 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var66 = var62.getItemFillPaint(1, (-1), false);
    var58.setLabelPaint(var66);
    org.jfree.chart.event.ChartChangeEvent var68 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var58);
    org.jfree.chart.urls.PieURLGenerator var69 = var58.getURLGenerator();
    var58.setDarkerSides(true);
    float var72 = var58.getBackgroundImageAlpha();
    org.jfree.chart.entity.PlotEntity var73 = new org.jfree.chart.entity.PlotEntity(var57, (org.jfree.chart.plot.Plot)var58);
    java.lang.Object var74 = var73.clone();
    org.jfree.chart.plot.Plot var75 = var73.getPlot();
    var73.setURLText("PlotOrientation.VERTICAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test181"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
//     java.awt.Paint var11 = var0.getShadowPaint();
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     org.jfree.data.xy.XYSeries var15 = null;
//     org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
//     boolean var17 = var14.hasListener((java.util.EventListener)var16);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var14, var18, var19);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var20);
//     var21.setAntiAlias(true);
//     java.awt.Image var24 = var21.getBackgroundImage();
//     java.lang.Object var25 = var21.getTextAntiAlias();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var27 = var26.getBackgroundPaint();
//     var21.removeSubtitle((org.jfree.chart.title.Title)var26);
//     var21.setBorderVisible(true);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var37 = var33.getItemFillPaint(1, (-1), false);
//     java.awt.Font var39 = var33.getSeriesItemLabelFont(1);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var43 = var42.getDefaultEntityRadius();
//     java.awt.Shape var45 = var42.getSeriesShape(1);
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var48 = var47.getTickLabelPaint();
//     var42.setSeriesOutlinePaint(0, var48);
//     var33.setBaseFillPaint(var48, true);
//     var21.setBackgroundPaint(var48);
//     var0.setLabelLinkPaint(var48);
//     
//     // Checks the contract:  equals-hashcode on var4 and var42
//     assertTrue("Contract failed: equals-hashcode on var4 and var42", var4.equals(var42) ? var4.hashCode() == var42.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var42.", var4.equals(var42) == var42.equals(var4));
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test182"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset)var1);
    java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NaN+ "'", var6.equals(Double.NaN));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test183"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    var0.setSeriesCreateEntities(10, (java.lang.Boolean)true, false);
    boolean var5 = var0.getAutoPopulateSeriesOutlineStroke();
    var0.setSeriesLinesVisible(3, (java.lang.Boolean)true);
    boolean var11 = var0.getItemShapeFilled(31, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test184"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    double var2 = var0.getBarAlignmentFactor();
    org.jfree.chart.labels.XYToolTipGenerator var4 = var0.getSeriesToolTipGenerator(0);
    java.awt.Stroke var5 = var0.getBaseOutlineStroke();
    org.jfree.chart.labels.ItemLabelPosition var9 = var0.getNegativeItemLabelPosition(4, (-293504), true);
    java.awt.Paint var10 = var0.getBaseLegendTextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test185"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getRangeGridlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var4 = var3.getShadowsVisible();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var15 = var11.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
//     var11.setBaseStroke(var17);
//     var8.setMinorTickMarkStroke(var17);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var22 = var21.getOutlineStroke();
//     java.awt.geom.Rectangle2D var23 = null;
//     var3.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var33 = var29.getItemFillPaint(1, (-1), false);
//     var25.setLabelPaint(var33);
//     org.jfree.data.general.PieDataset var35 = var25.getDataset();
//     var25.setAutoPopulateSectionOutlinePaint(false);
//     float var38 = var25.getBackgroundImageAlpha();
//     java.awt.Paint var39 = var25.getNoDataMessagePaint();
//     var21.setPaint(var39);
//     org.jfree.chart.util.Layer var41 = null;
//     boolean var42 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var21, var41);
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.axis.NumberAxis var45 = null;
//     java.awt.Font var50 = null;
//     org.jfree.chart.axis.MarkerAxisBand var51 = new org.jfree.chart.axis.MarkerAxisBand(var45, 100.0d, 100.0d, (-1.0d), 1.0d, var50);
//     var44.setMarkerBand(var51);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Paint var55 = var54.getOutlinePaint();
//     boolean var56 = var51.equals((java.lang.Object)var54);
//     java.awt.Graphics2D var57 = null;
//     org.jfree.chart.axis.PeriodAxis var60 = new org.jfree.chart.axis.PeriodAxis("December 2014");
//     var60.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Font var63 = var60.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var64 = new org.jfree.chart.block.LabelBlock("", var63);
//     java.lang.String var65 = var64.getToolTipText();
//     java.awt.geom.Rectangle2D var66 = var64.getBounds();
//     org.jfree.chart.axis.CategoryAxis3D var67 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.title.TextTitle var70 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var71 = var70.getID();
//     org.jfree.chart.util.RectangleInsets var72 = var70.getPadding();
//     var70.setMaximumLinesToDisplay(1);
//     var70.setToolTipText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.awt.geom.Rectangle2D var77 = var70.getBounds();
//     org.jfree.chart.util.RectangleEdge var78 = null;
//     double var79 = var67.getCategoryEnd(255, 10, var77, var78);
//     org.jfree.chart.plot.ValueMarker var81 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.util.RectangleAnchor var82 = var81.getLabelAnchor();
//     java.awt.Shape var85 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var77, var82, 45.0d, 1.0d);
//     var51.draw(var57, var66, var77, (-0.30102999566398114d), (-0.30102999566398114d));
//     var0.drawBackground(var43, var77);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test186"); }


    org.jfree.chart.renderer.xy.GradientXYBarPainter var0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test187"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var0);
    org.jfree.chart.util.RectangleInsets var2 = new org.jfree.chart.util.RectangleInsets();
    var0.setPadding(var2);
    org.jfree.chart.StandardChartTheme var5 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.util.RectangleInsets var6 = var5.getAxisOffset();
    double var7 = var6.getBottom();
    org.jfree.chart.ChartRenderingInfo var8 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    var9.resizeRange2(100.0d, 4.0d);
    org.jfree.chart.util.RectangleInsets var13 = var9.getLabelInsets();
    var9.setMinorTickMarksVisible(true);
    double var16 = var9.getUpperMargin();
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
    java.lang.String var21 = var20.getID();
    java.lang.String var22 = var20.getToolTipText();
    org.jfree.chart.util.HorizontalAlignment var23 = var20.getTextAlignment();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    java.lang.String var26 = var25.getID();
    org.jfree.chart.util.RectangleInsets var27 = var25.getPadding();
    var25.setMaximumLinesToDisplay(1);
    var25.setToolTipText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.awt.geom.Rectangle2D var32 = var25.getBounds();
    org.jfree.data.xy.XYDataItem var35 = new org.jfree.data.xy.XYDataItem((java.lang.Number)100.0d, (java.lang.Number)12.0d);
    java.lang.Object var36 = var20.draw(var24, var32, (java.lang.Object)100.0d);
    boolean var37 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0d, (-1.88d), var32);
    org.jfree.chart.util.RectangleEdge var38 = null;
    double var39 = var9.valueToJava2D(0.0d, var32, var38);
    var8.setChartArea(var32);
    java.awt.geom.Rectangle2D var41 = var6.createInsetRectangle(var32);
    java.awt.geom.Rectangle2D var44 = var2.createOutsetRectangle(var32, false, true);
    org.jfree.chart.plot.CombinedRangeXYPlot var45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = var47.getRenderer(0);
    java.awt.Paint var50 = var47.getDomainCrosshairPaint();
    java.awt.Paint var51 = var47.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var52 = var47.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var53 = var52.getOpposite();
    var45.setRangeAxisLocation(100, var53, false);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var58 = var57.getOutlineStroke();
    double var59 = var57.getValue();
    java.awt.Color var63 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var64 = var63.getRGB();
    java.lang.String var65 = var63.toString();
    var57.setLabelPaint((java.awt.Paint)var63);
    org.jfree.chart.util.LengthAdjustmentType var67 = var57.getLabelOffsetType();
    org.jfree.chart.util.Layer var68 = null;
    var45.addRangeMarker((org.jfree.chart.plot.Marker)var57, var68);
    org.jfree.chart.plot.PiePlot3D var70 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.data.general.DatasetGroup var71 = var70.getDatasetGroup();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var74 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var74.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var80 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var84 = var80.getItemFillPaint(1, (-1), false);
    var74.setBaseLegendTextPaint(var84);
    var70.setLabelLinkPaint(var84);
    var45.setRangeTickBandPaint(var84);
    org.jfree.chart.title.LegendTitle var88 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var45);
    org.jfree.chart.entity.TitleEntity var91 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape)var44, (org.jfree.chart.title.Title)var88, "0,0,0,0,0,0,0,0", "December 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var65.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test188"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var9.clearSectionOutlinePaints(false);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
    boolean var14 = var9.equals((java.lang.Object)var13);
    java.awt.Paint var15 = var9.getBaseSectionOutlinePaint();
    var2.setWallPaint(var15);
    org.jfree.chart.plot.CategoryPlot var17 = var2.getPlot();
    java.awt.Paint var21 = var2.getItemLabelPaint((-16777216), 0, false);
    java.lang.Object var22 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test189"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var2.resizeRange2(100.0d, 4.0d);
    var2.setRangeAboutValue(0.08d, 4.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = var9.getRenderer(0);
    java.util.List var12 = var9.getSubplots();
    org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var21 = var17.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
    var17.setBaseStroke(var23);
    var14.setMinorTickMarkStroke(var23);
    var14.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var28 = var14.getLocale();
    var14.setPositiveArrowVisible(false);
    double var31 = var14.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var32 = new org.jfree.chart.axis.ValueAxis[] { var14};
    var9.setDomainAxes(var32);
    org.jfree.chart.util.RectangleEdge var35 = var9.getRangeAxisEdge(0);
    boolean var36 = var9.isRangeZoomable();
    boolean var37 = var2.equals((java.lang.Object)var9);
    org.jfree.chart.renderer.PolarItemRenderer var38 = null;
    org.jfree.chart.plot.PolarPlot var39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, (org.jfree.chart.axis.ValueAxis)var2, var38);
    org.jfree.data.Range var40 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var44 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var1, 20, (-0.30102999566398114d), (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test190"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    java.lang.Object[][] var2 = var0.getContents();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test191"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var4 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var4, var5);
    var2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var6, false);
    org.jfree.chart.labels.XYItemLabelGenerator var12 = var2.getItemLabelGenerator(3, 2, false);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
    var19.setBaseStroke(var25);
    var16.setMinorTickMarkStroke(var25);
    var16.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.awt.geom.Rectangle2D var30 = null;
    var2.drawDomainGridLine(var13, var14, (org.jfree.chart.axis.ValueAxis)var16, var30, Double.POSITIVE_INFINITY);
    org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
    var34.clearSectionOutlinePaints(false);
    double var38 = var34.getMaximumLabelWidth();
    java.awt.Paint var39 = null;
    var34.setLabelShadowPaint(var39);
    org.jfree.chart.plot.CombinedRangeXYPlot var41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var42 = null;
    var41.plotChanged(var42);
    java.util.List var44 = var41.getSubplots();
    org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var47 = var46.getItemCount();
    org.jfree.data.time.Year var49 = new org.jfree.data.time.Year(1);
    java.util.Date var50 = var49.getStart();
    var46.add((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var54 = null;
    org.jfree.data.xy.XYSeriesCollection var55 = new org.jfree.data.xy.XYSeriesCollection(var54);
    org.jfree.data.xy.XYSeries var56 = null;
    org.jfree.data.xy.XYSeriesCollection var57 = new org.jfree.data.xy.XYSeriesCollection(var56);
    boolean var58 = var55.hasListener((java.util.EventListener)var57);
    double var59 = var57.getIntervalPositionFactor();
    var46.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var57);
    boolean var61 = var41.equals((java.lang.Object)var46);
    org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var64 = var63.getOutlineStroke();
    double var65 = var63.getValue();
    java.awt.Color var69 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var70 = var69.getRGB();
    java.lang.String var71 = var69.toString();
    var63.setLabelPaint((java.awt.Paint)var69);
    org.jfree.chart.util.Layer var73 = null;
    boolean var74 = var41.removeDomainMarker((org.jfree.chart.plot.Marker)var63, var73);
    org.jfree.chart.event.MarkerChangeEvent var75 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var63);
    java.awt.Paint var76 = var63.getPaint();
    var34.setLabelOutlinePaint(var76);
    var2.setSeriesPaint(68, var76, false);
    boolean var80 = var2.getUseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var71.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test192"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
//     org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
//     org.jfree.chart.urls.CategoryURLGenerator var6 = null;
//     var2.setSeriesURLGenerator(2, var6, true);
//     org.jfree.chart.urls.CategoryURLGenerator var10 = null;
//     var2.setSeriesURLGenerator(10, var10);
//     var2.setMinimumBarLength(1.0d);
//     java.awt.Paint var14 = var2.getShadowPaint();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var17 = var15.getRangeAxisLocation(1);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     org.jfree.data.time.Year var21 = var19.getYear();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var23 = var22.next();
//     org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("Polar Plot", (org.jfree.data.time.RegularTimePeriod)var19, var23);
//     long var25 = var19.getLastMillisecond();
//     org.jfree.data.general.DefaultPieDataset var26 = new org.jfree.data.general.DefaultPieDataset();
//     java.lang.Object var27 = var26.clone();
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset)var26);
//     org.jfree.data.category.CategoryDataset var29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var25, (org.jfree.data.KeyedValues)var26);
//     var15.setDataset(var29);
//     org.jfree.data.Range var32 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var29, false);
//     org.jfree.data.Range var33 = var2.findRangeBounds(var29);
//     java.lang.Number var34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test193"); }


    java.text.DateFormat var1 = null;
    java.text.NumberFormat var3 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var6 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var5, var6);
    var5.setMinimumIntegerDigits(10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var3, var5);
    java.lang.String var12 = var5.format(0.0d);
    java.lang.String var14 = var5.format(0L);
    var5.setMaximumIntegerDigits(1);
    java.math.RoundingMode var17 = var5.getRoundingMode();
    org.jfree.chart.labels.StandardXYToolTipGenerator var18 = new org.jfree.chart.labels.StandardXYToolTipGenerator("SerialDate.weekInMonthToString(): invalid code.", var1, var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "0,000,000,000%"+ "'", var12.equals("0,000,000,000%"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "0,000,000,000%"+ "'", var14.equals("0,000,000,000%"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test194"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test195"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("ThreadContext");

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test196"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var4 = var3.getItemCount();
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
    java.util.Date var7 = var6.getStart();
    var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)Double.NaN, true);
    var1.delete((org.jfree.data.time.RegularTimePeriod)var6);
    java.lang.String var12 = var1.getRangeDescription();
    org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(1);
    java.util.Date var15 = var14.getStart();
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("null");
    boolean var19 = var17.isHiddenValue(644288400000L);
    java.awt.Shape var24 = null;
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var27 = null;
    org.jfree.data.xy.XYSeriesCollection var28 = new org.jfree.data.xy.XYSeriesCollection(var27);
    org.jfree.data.xy.XYSeries var29 = null;
    org.jfree.data.xy.XYSeriesCollection var30 = new org.jfree.data.xy.XYSeriesCollection(var29);
    boolean var31 = var28.hasListener((java.util.EventListener)var30);
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.PolarItemRenderer var33 = null;
    org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var28, var32, var33);
    java.awt.Paint var35 = var34.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var24, var26, var35);
    java.lang.String var37 = var36.getDescription();
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    boolean var39 = var36.equals((java.lang.Object)var38);
    java.util.TimeZone var40 = var38.getTimeZone();
    var17.setTimeZone(var40);
    org.jfree.data.time.Year var42 = new org.jfree.data.time.Year(var15, var40);
    org.jfree.data.time.TimeSeriesCollection var43 = new org.jfree.data.time.TimeSeriesCollection(var1, var40);
    java.util.List var44 = var1.getItems();
    var1.setMaximumItemAge(1418759999999L);
    java.lang.String var47 = var1.getDomainDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Value"+ "'", var12.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "Pie 3D Plot"+ "'", var37.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "Time"+ "'", var47.equals("Time"));

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test197"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var2 = var1.clone();
    boolean var3 = var0.equals((java.lang.Object)var1);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.util.Size2D var5 = var0.calculateDimensions(var4);
    org.jfree.chart.util.HorizontalAlignment var6 = var0.getLineAlignment();
    java.lang.String var7 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var7.equals("HorizontalAlignment.CENTER"));

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test198"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
    boolean var2 = var1.getAutoPopulateSeriesStroke();
    java.lang.Object var3 = var1.clone();
    var1.setDefaultEntityRadius(3);
    boolean var6 = var1.getPlotArea();
    var1.setRangeBase(45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test199"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var6 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)100.0d);
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection();
    var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var7);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("null");
    boolean var12 = var10.isHiddenValue(644288400000L);
    java.awt.Shape var17 = null;
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var20 = null;
    org.jfree.data.xy.XYSeriesCollection var21 = new org.jfree.data.xy.XYSeriesCollection(var20);
    org.jfree.data.xy.XYSeries var22 = null;
    org.jfree.data.xy.XYSeriesCollection var23 = new org.jfree.data.xy.XYSeriesCollection(var22);
    boolean var24 = var21.hasListener((java.util.EventListener)var23);
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.PolarItemRenderer var26 = null;
    org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var21, var25, var26);
    java.awt.Paint var28 = var27.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var17, var19, var28);
    java.lang.String var30 = var29.getDescription();
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
    boolean var32 = var29.equals((java.lang.Object)var31);
    java.util.TimeZone var33 = var31.getTimeZone();
    var10.setTimeZone(var33);
    org.jfree.chart.axis.TickUnitSource var35 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var33);
    org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection(var1, var33);
    org.jfree.data.xy.XYSeries var37 = null;
    org.jfree.data.xy.XYSeriesCollection var38 = new org.jfree.data.xy.XYSeriesCollection(var37);
    var38.clearSelection();
    var38.clearSelection();
    var38.removeAllSeries();
    var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var38);
    java.util.List var43 = var38.getSeries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "Pie 3D Plot"+ "'", var30.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test200"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    java.awt.Shape var13 = var1.getDownArrow();
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    boolean var17 = var15.equals((java.lang.Object)(short)(-1));
    java.lang.Number var18 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var15);
    org.jfree.chart.entity.XYItemEntity var23 = new org.jfree.chart.entity.XYItemEntity(var13, (org.jfree.data.xy.XYDataset)var15, 10, 100, "", "Pie 3D Plot");
    java.lang.String var24 = var23.toString();
    org.jfree.data.xy.XYDataset var25 = var23.getDataset();
    var23.setSeriesIndex((-237));
    var23.setItem(1);
    var23.setToolTipText("PieLabelLinkStyle.STANDARD");
    var23.setSeriesIndex(2147483647);
    var23.setItem(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + Double.NaN+ "'", var18.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test201"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getID();
    org.jfree.chart.util.RectangleInsets var2 = var0.getPadding();
    double var3 = var0.getContentYOffset();
    org.jfree.chart.util.RectangleEdge var4 = var0.getPosition();
    org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var5.getNegativeItemLabelPositionFallback();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var9.setBaseSeriesVisible(false, false);
    java.awt.Font var14 = null;
    var9.setSeriesItemLabelFont(3, var14, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var9.getBasePositiveItemLabelPosition();
    boolean var19 = var17.equals((java.lang.Object)0.0f);
    var5.setPositiveItemLabelPositionFallback(var17);
    var5.setDefaultEntityRadius(0);
    java.awt.Shape var23 = var5.getLegendBar();
    boolean var24 = var4.equals((java.lang.Object)var5);
    org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot();
    org.jfree.data.time.Year var27 = new org.jfree.data.time.Year(1);
    java.util.Date var28 = var27.getStart();
    org.jfree.data.time.Year var30 = new org.jfree.data.time.Year(1);
    java.util.Date var31 = var30.getStart();
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange(var28, var31);
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
    java.awt.Paint var35 = var33.getLabelBackgroundPaint();
    boolean var36 = var32.equals((java.lang.Object)var35);
    var25.setSeparatorPaint(var35);
    java.awt.Stroke var38 = var25.getBaseSectionOutlineStroke();
    boolean var39 = var4.equals((java.lang.Object)var25);
    org.jfree.chart.plot.DrawingSupplier var40 = var25.getDrawingSupplier();
    org.jfree.chart.plot.CrosshairState var41 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var48 = null;
    var41.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var48);
    boolean var50 = var25.equals((java.lang.Object)var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test202"); }


    org.jfree.chart.plot.CrosshairState var0 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var7 = null;
    var0.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    org.jfree.data.xy.XYSeries var11 = null;
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
    boolean var13 = var10.hasListener((java.util.EventListener)var12);
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.PolarItemRenderer var15 = null;
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var10, var14, var15);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleAnchor var21 = null;
    java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var20, var21);
    var16.zoomDomainAxes(100.0d, (-1.0d), var19, var22);
    var0.setAnchor(var22);
    var0.setCrosshairY(0.5d);
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleAnchor var28 = null;
    java.awt.geom.Point2D var29 = org.jfree.chart.util.RectangleAnchor.coordinates(var27, var28);
    var0.setAnchor(var29);
    int var31 = var0.getDomainAxisIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test203"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.removeCategoryLabelToolTip((java.lang.Comparable)(short)100);
    var0.clearCategoryLabelToolTips();

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test204"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     var1.removeAllSeries();
//     org.jfree.data.xy.XYSeries var3 = null;
//     org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
//     org.jfree.data.xy.XYSeries var5 = null;
//     org.jfree.data.xy.XYSeriesCollection var6 = new org.jfree.data.xy.XYSeriesCollection(var5);
//     boolean var7 = var4.hasListener((java.util.EventListener)var6);
//     double var9 = var6.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var12 = var11.getItemCount();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(1);
//     java.util.Date var15 = var14.getStart();
//     var11.add((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var14, true);
//     var6.addSeries(var20);
//     org.jfree.data.DomainOrder var22 = var6.getDomainOrder();
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var25 = var24.getItemCount();
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year(1);
//     java.util.Date var28 = var27.getStart();
//     var24.add((org.jfree.data.time.RegularTimePeriod)var27, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var32 = null;
//     org.jfree.data.xy.XYSeriesCollection var33 = new org.jfree.data.xy.XYSeriesCollection(var32);
//     org.jfree.data.xy.XYSeries var34 = null;
//     org.jfree.data.xy.XYSeriesCollection var35 = new org.jfree.data.xy.XYSeriesCollection(var34);
//     boolean var36 = var33.hasListener((java.util.EventListener)var35);
//     double var37 = var35.getIntervalPositionFactor();
//     var24.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var35);
//     org.jfree.data.xy.XYSeries var39 = null;
//     org.jfree.data.xy.XYSeriesCollection var40 = new org.jfree.data.xy.XYSeriesCollection(var39);
//     org.jfree.data.xy.XYSeries var41 = null;
//     org.jfree.data.xy.XYSeriesCollection var42 = new org.jfree.data.xy.XYSeriesCollection(var41);
//     boolean var43 = var40.hasListener((java.util.EventListener)var42);
//     double var45 = var42.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var48 = var47.getItemCount();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year(1);
//     java.util.Date var51 = var50.getStart();
//     var47.add((org.jfree.data.time.RegularTimePeriod)var50, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var56 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var50, true);
//     var42.addSeries(var56);
//     java.util.List var58 = var56.getItems();
//     org.jfree.data.Range var60 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset)var35, var58, true);
//     org.jfree.data.Range var62 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var6, var58, true);
//     org.jfree.data.Range var64 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1, var58, false);
//     org.jfree.data.time.TimeSeries var66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var67 = var66.getItemCount();
//     org.jfree.data.time.Year var69 = new org.jfree.data.time.Year(1);
//     org.jfree.data.time.TimeSeriesDataItem var71 = var66.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var69, (java.lang.Number)100.0d);
//     int var72 = var1.indexOf(var66);
//     java.lang.Object var73 = var1.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test205"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
//     org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var6 = var5.getXValue();
//     java.lang.String var7 = var5.toString();
//     org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var11 = var10.getXValue();
//     var10.setY(0.0d);
//     int var14 = var5.compareTo((java.lang.Object)var10);
//     java.lang.Number var15 = var10.getX();
//     var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var20 = var18.getRangeAxisLocation(1);
//     org.jfree.chart.util.RectangleEdge var21 = var18.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisLocation var23 = var18.getDomainAxisLocation(12);
//     var0.setDomainAxisLocation(1969, var23);
//     org.jfree.chart.LegendItemCollection var25 = var0.getLegendItems();
//     java.awt.Paint var26 = var0.getRangeGridlinePaint();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.entity.EntityCollection var28 = null;
//     org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo(var28);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = var29.getPlotInfo();
//     java.awt.geom.Rectangle2D var31 = var29.getChartArea();
//     var0.drawBackground(var27, var31);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test206"); }
// 
// 
//     org.jfree.data.time.DateRange var0 = new org.jfree.data.time.DateRange();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift((org.jfree.data.Range)var0, 0.0d);
//     java.lang.String var4 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var1.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var4.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test207"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    var2.setLegendTextPaint(3, var14);
    java.lang.Boolean var17 = var2.getSeriesShapesVisible(2);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
    java.util.List var23 = var20.getSubplots();
    org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
    var28.setBaseStroke(var34);
    var25.setMinorTickMarkStroke(var34);
    var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var39 = var25.getLocale();
    var25.setPositiveArrowVisible(false);
    double var42 = var25.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var25};
    var20.setDomainAxes(var43);
    org.jfree.chart.util.RectangleEdge var46 = var20.getRangeAxisEdge(0);
    org.jfree.data.xy.XYSeries var48 = null;
    org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
    org.jfree.data.xy.XYSeries var50 = null;
    org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
    boolean var52 = var49.hasListener((java.util.EventListener)var51);
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var49, var53, var54);
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var55);
    boolean var57 = var20.equals((java.lang.Object)"");
    org.jfree.data.xy.XYSeries var58 = null;
    org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
    org.jfree.data.xy.XYSeries var60 = null;
    org.jfree.data.xy.XYSeriesCollection var61 = new org.jfree.data.xy.XYSeriesCollection(var60);
    boolean var62 = var59.hasListener((java.util.EventListener)var61);
    double var63 = var61.getIntervalPositionFactor();
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var65 = var2.initialise(var18, var19, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.data.xy.XYDataset)var61, var64);
    boolean var66 = var65.getProcessVisibleItemsOnly();
    org.jfree.data.xy.DefaultXYDataset var67 = new org.jfree.data.xy.DefaultXYDataset();
    var67.validateObject();
    org.jfree.data.Range var69 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var67);
    org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var74 = var73.getItemCount();
    org.jfree.data.time.Year var76 = new org.jfree.data.time.Year(1);
    java.util.Date var77 = var76.getStart();
    var73.add((org.jfree.data.time.RegularTimePeriod)var76, (java.lang.Number)Double.NaN, true);
    var71.delete((org.jfree.data.time.RegularTimePeriod)var76);
    int var82 = var67.indexOf((java.lang.Comparable)var76);
    org.jfree.data.Range var84 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var67, false);
    java.lang.Object var85 = var67.clone();
    var65.startSeriesPass((org.jfree.data.xy.XYDataset)var67, 100, 1, 4, 68, 1);
    var65.setProcessVisibleItemsOnly(true);
    var65.setProcessVisibleItemsOnly(false);
    org.jfree.chart.plot.PlotRenderingInfo var96 = var65.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var96);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test208"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    var1.clearSelection();
    var1.clearSelection();
    var1.removeAllSeries();
    var1.clearSelection();

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test209"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    java.awt.Paint var5 = var0.getNoDataMessagePaint();
    boolean var6 = var0.isRangeGridlinesVisible();
    var0.mapDatasetToRangeAxis(1969, 3);
    java.awt.Paint var10 = var0.getRangeTickBandPaint();
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = var11.getRenderer(0);
    java.awt.Paint var14 = var11.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var16 = var11.getDataset(1);
    int var17 = var11.getWeight();
    int var18 = var11.getDatasetCount();
    org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = var19.getRenderer(0);
    java.util.List var22 = var19.getSubplots();
    org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
    var27.setBaseStroke(var33);
    var24.setMinorTickMarkStroke(var33);
    var24.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var38 = var24.getLocale();
    var24.setPositiveArrowVisible(false);
    double var41 = var24.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var24};
    var19.setDomainAxes(var42);
    var11.setRangeAxes(var42);
    var0.setRangeAxes(var42);
    var0.setDomainMinorGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test210"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.data.general.PieDataset var10 = var0.getDataset();
//     var0.setAutoPopulateSectionOutlinePaint(false);
//     float var13 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisState var15 = new org.jfree.chart.axis.AxisState(0.12d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.util.RectangleEdge var18 = var17.getRangeAxisEdge();
//     org.jfree.chart.util.RectangleEdge var19 = org.jfree.chart.util.RectangleEdge.opposite(var18);
//     var15.moveCursor(10.0d, var18);
//     org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var30 = var26.getItemFillPaint(1, (-1), false);
//     var22.setLabelPaint(var30);
//     org.jfree.data.general.PieDataset var32 = var22.getDataset();
//     boolean var33 = var22.getSimpleLabels();
//     double var34 = var22.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var37 = var36.getID();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getPadding();
//     double var40 = var38.extendWidth(10.0d);
//     var35.setItemLabelPadding(var38);
//     org.jfree.chart.block.BlockContainer var42 = null;
//     var35.setWrapper(var42);
//     org.jfree.chart.util.RectangleInsets var44 = var35.getLegendItemGraphicPadding();
//     double var45 = var35.getHeight();
//     org.jfree.chart.plot.CombinedDomainXYPlot var46 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = var46.getRenderer(0);
//     java.util.List var49 = var46.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var51 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var54 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var58 = var54.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var59 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var60 = var59.getBaseSectionOutlineStroke();
//     var54.setBaseStroke(var60);
//     var51.setMinorTickMarkStroke(var60);
//     var51.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var65 = var51.getLocale();
//     var51.setPositiveArrowVisible(false);
//     double var68 = var51.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var69 = new org.jfree.chart.axis.ValueAxis[] { var51};
//     var46.setDomainAxes(var69);
//     org.jfree.chart.util.RectangleEdge var72 = var46.getRangeAxisEdge(0);
//     var35.setLegendItemGraphicEdge(var72);
//     var15.moveCursor((-1.88d), var72);
//     boolean var75 = var0.equals((java.lang.Object)var15);
//     
//     // Checks the contract:  equals-hashcode on var0 and var22
//     assertTrue("Contract failed: equals-hashcode on var0 and var22", var0.equals(var22) ? var0.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var0
//     assertTrue("Contract failed: equals-hashcode on var22 and var0", var22.equals(var0) ? var22.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test211"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = null;
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("Pie 3D Plot");
    java.awt.geom.Rectangle2D var8 = null;
    var3.drawRangeGridline(var4, var5, (org.jfree.chart.axis.ValueAxis)var7, var8, 0.12d);
    org.jfree.chart.annotations.CategoryAnnotation var11 = null;
    boolean var12 = var3.removeAnnotation(var11);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var3);
    org.jfree.chart.axis.CategoryAnchor var14 = var0.getDomainGridlinePosition();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var16 = var15.getShadowsVisible();
    org.jfree.chart.renderer.category.BarPainter var17 = var15.getBarPainter();
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var15.setBaseItemLabelGenerator(var18);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = null;
    var15.setLegendItemToolTipGenerator(var20);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.labels.ItemLabelPosition var23 = var15.getBaseNegativeItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test212"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
    var2.setSeriesOutlineStroke(0, var5, true);
    java.lang.Boolean var9 = null;
    var2.setSeriesItemLabelsVisible(2, var9);
    var2.setUseOutlinePaint(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    double var14 = var13.getRangeCrosshairValue();
    java.awt.Color var19 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var20 = var19.darker();
    java.awt.Paint var21 = null;
    boolean var22 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var19, var21);
    java.awt.Color var23 = java.awt.Color.getColor("0,0,0,0,0,0,0,0", var19);
    int var24 = var23.getAlpha();
    var13.setRangeCrosshairPaint((java.awt.Paint)var23);
    var2.setBaseItemLabelPaint((java.awt.Paint)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 255);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test213"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    var7.setForegroundAlpha(100.0f);
    boolean var10 = var7.isAngleLabelsVisible();
    boolean var11 = var7.isAngleLabelsVisible();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    java.awt.Font var20 = var14.getSeriesItemLabelFont(1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var24 = var23.getDefaultEntityRadius();
    java.awt.Shape var26 = var23.getSeriesShape(1);
    org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var29 = var28.getTickLabelPaint();
    var23.setSeriesOutlinePaint(0, var29);
    var14.setBaseFillPaint(var29, true);
    var7.setRadiusGridlinePaint(var29);
    var7.setOutlineVisible(true);
    org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = var36.getRenderer(0);
    java.awt.Paint var39 = var36.getDomainCrosshairPaint();
    java.awt.Paint var40 = var36.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var41 = var36.getDomainAxisLocation();
    org.jfree.data.xy.XYSeries var42 = null;
    org.jfree.data.xy.XYSeriesCollection var43 = new org.jfree.data.xy.XYSeriesCollection(var42);
    org.jfree.data.xy.XYSeries var44 = null;
    org.jfree.data.xy.XYSeriesCollection var45 = new org.jfree.data.xy.XYSeriesCollection(var44);
    boolean var46 = var43.hasListener((java.util.EventListener)var45);
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.renderer.PolarItemRenderer var48 = null;
    org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var43, var47, var48);
    var49.setForegroundAlpha(100.0f);
    boolean var52 = var49.isAngleLabelsVisible();
    boolean var53 = var49.isAngleLabelsVisible();
    boolean var54 = var49.isDomainZoomable();
    var36.setParent((org.jfree.chart.plot.Plot)var49);
    org.jfree.chart.event.RendererChangeEvent var56 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var36);
    var7.rendererChanged(var56);
    java.lang.Object var58 = var56.getRenderer();
    org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var60 = var59.clone();
    org.jfree.chart.util.HorizontalAlignment var61 = var59.getTextAlignment();
    org.jfree.data.xy.XYSeries var63 = null;
    org.jfree.data.xy.XYSeriesCollection var64 = new org.jfree.data.xy.XYSeriesCollection(var63);
    org.jfree.data.xy.XYSeries var65 = null;
    org.jfree.data.xy.XYSeriesCollection var66 = new org.jfree.data.xy.XYSeriesCollection(var65);
    boolean var67 = var64.hasListener((java.util.EventListener)var66);
    org.jfree.chart.axis.ValueAxis var68 = null;
    org.jfree.chart.renderer.PolarItemRenderer var69 = null;
    org.jfree.chart.plot.PolarPlot var70 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var64, var68, var69);
    org.jfree.chart.JFreeChart var71 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var70);
    var71.clearSubtitles();
    java.awt.Image var73 = null;
    var71.setBackgroundImage(var73);
    java.awt.Paint var75 = var71.getBorderPaint();
    var59.addChangeListener((org.jfree.chart.event.TitleChangeListener)var71);
    var56.setChart(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test214"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("$0.00?DomainOrder.NONE=3&amp;=2");
    org.jfree.chart.plot.CombinedRangeXYPlot var2 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var4 = var3.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var11 = var7.getItemFillPaint(1, (-1), false);
    var3.setLabelPaint(var11);
    org.jfree.data.general.PieDataset var13 = var3.getDataset();
    boolean var14 = var3.getSimpleLabels();
    double var15 = var3.getDepthFactor();
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.lang.String var18 = var17.getID();
    org.jfree.chart.util.RectangleInsets var19 = var17.getPadding();
    double var21 = var19.extendWidth(10.0d);
    var16.setItemLabelPadding(var19);
    org.jfree.chart.block.BlockContainer var23 = null;
    var16.setWrapper(var23);
    org.jfree.chart.util.RectangleInsets var25 = var16.getLegendItemGraphicPadding();
    boolean var26 = var2.equals((java.lang.Object)var25);
    boolean var28 = var25.equals((java.lang.Object)"PlotOrientation.VERTICAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test215"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    int var3 = var1.indexOf((java.lang.Object)(byte)10);
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var7 = var6.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var9 = null;
    var6.setSeriesURLGenerator(0, var9);
    org.jfree.chart.plot.CombinedRangeXYPlot var11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = var13.getRenderer(0);
    java.awt.Paint var16 = var13.getDomainCrosshairPaint();
    java.awt.Paint var17 = var13.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var18 = var13.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var19 = var18.getOpposite();
    var11.setRangeAxisLocation(100, var19, false);
    var11.mapDatasetToDomainAxis(1, 0);
    boolean var25 = var6.hasListener((java.util.EventListener)var11);
    int var26 = var1.indexOf((java.lang.Object)var11);
    java.awt.Stroke var27 = var11.getDomainZeroBaselineStroke();
    double var28 = var11.getGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 5.0d);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test216"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    boolean var1 = var0.getGenerateEntities();
    var0.setTranslateY(0.025d);
    var0.setTranslateY(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test217"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    var1.setPlotOutlinePaint(var24);
    org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var1.setBarPainter(var26);
    org.jfree.data.xy.XYSeries var28 = null;
    org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
    org.jfree.data.xy.XYSeries var30 = null;
    org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
    boolean var32 = var29.hasListener((java.util.EventListener)var31);
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var29, var33, var34);
    var35.setForegroundAlpha(100.0f);
    var35.setAngleGridlinesVisible(true);
    java.awt.Paint var40 = var35.getBackgroundPaint();
    var1.setGridBandAlternatePaint(var40);
    org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    var1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var42);
    java.awt.Paint var44 = var1.getShadowPaint();
    org.jfree.chart.util.RectangleInsets var45 = var1.getAxisOffset();
    java.awt.Paint var46 = var1.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test218"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.awt.Paint var3 = var0.getDomainCrosshairPaint();
//     java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
//     org.jfree.data.xy.XYSeries var6 = null;
//     org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
//     org.jfree.data.xy.XYSeries var8 = null;
//     org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
//     boolean var10 = var7.hasListener((java.util.EventListener)var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var12 = null;
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var7, var11, var12);
//     var13.setForegroundAlpha(100.0f);
//     boolean var16 = var13.isAngleLabelsVisible();
//     boolean var17 = var13.isAngleLabelsVisible();
//     boolean var18 = var13.isDomainZoomable();
//     var0.setParent((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.event.RendererChangeEvent var20 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var0);
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D("$0.00?DomainOrder.NONE=3&amp;=2");
//     org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     var27.setBaseStroke(var33);
//     var24.setMinorTickMarkStroke(var33);
//     org.jfree.data.time.DateRange var36 = new org.jfree.data.time.DateRange();
//     var24.setRangeWithMargins((org.jfree.data.Range)var36);
//     org.jfree.data.time.DateRange var38 = new org.jfree.data.time.DateRange();
//     java.lang.String var39 = var38.toString();
//     var24.setRange((org.jfree.data.Range)var38);
//     var22.setRange((org.jfree.data.Range)var38);
//     int var42 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var22);
//     org.jfree.chart.axis.NumberTickUnit var43 = var22.getTickUnit();
//     java.awt.Shape var44 = var22.getDownArrow();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var39.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test219"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("DateTickUnit[DateTickUnitType.DAY, 1]", "0,0,0,0,0,0,0,0", "poly", "SerialDate.weekInMonthToString(): invalid code.");
    var4.setCopyright("Rotation.CLOCKWISE");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test220"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test221"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var4 = var3.getItemCount();
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
    java.util.Date var7 = var6.getStart();
    var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)Double.NaN, true);
    var1.delete((org.jfree.data.time.RegularTimePeriod)var6);
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test222"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var1.setBarPainter(var26);
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("December 2014");
//     var30.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Font var33 = var30.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var34 = new org.jfree.chart.block.LabelBlock("", var33);
//     var34.setToolTipText("ThreadContext");
//     org.jfree.chart.axis.PeriodAxis var38 = new org.jfree.chart.axis.PeriodAxis("December 2014");
//     var38.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Font var41 = var38.getTickLabelFont();
//     var34.setFont(var41);
//     var1.setSmallFont(var41);
//     var1.setShadowVisible(false);
//     java.awt.Paint var46 = var1.getPlotOutlinePaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var47 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = var47.getRenderer(0);
//     java.util.List var50 = var47.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var52 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var55 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var59 = var55.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var60 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var61 = var60.getBaseSectionOutlineStroke();
//     var55.setBaseStroke(var61);
//     var52.setMinorTickMarkStroke(var61);
//     var52.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var66 = var52.getLocale();
//     var52.setPositiveArrowVisible(false);
//     double var69 = var52.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var70 = new org.jfree.chart.axis.ValueAxis[] { var52};
//     var47.setDomainAxes(var70);
//     java.awt.Paint var72 = var47.getDomainCrosshairPaint();
//     boolean var73 = var47.isDomainMinorGridlinesVisible();
//     var47.setGap(Double.POSITIVE_INFINITY);
//     org.jfree.chart.plot.CombinedDomainXYPlot var76 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var78 = var76.getRenderer(0);
//     java.awt.Paint var79 = var76.getDomainCrosshairPaint();
//     java.awt.Paint var80 = var76.getRangeMinorGridlinePaint();
//     java.awt.Paint var81 = var76.getNoDataMessagePaint();
//     org.jfree.data.xy.XYSeries var82 = null;
//     org.jfree.data.xy.XYSeriesCollection var83 = new org.jfree.data.xy.XYSeriesCollection(var82);
//     org.jfree.data.xy.XYSeries var84 = null;
//     org.jfree.data.xy.XYSeriesCollection var85 = new org.jfree.data.xy.XYSeriesCollection(var84);
//     boolean var86 = var83.hasListener((java.util.EventListener)var85);
//     org.jfree.chart.axis.ValueAxis var87 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var88 = null;
//     org.jfree.chart.plot.PolarPlot var89 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var83, var87, var88);
//     var89.setForegroundAlpha(100.0f);
//     var89.setAngleGridlinesVisible(true);
//     org.jfree.chart.plot.PlotOrientation var94 = var89.getOrientation();
//     var76.setOrientation(var94);
//     var47.setOrientation(var94);
//     java.awt.Paint var97 = var47.getDomainZeroBaselinePaint();
//     var1.setTickLabelPaint(var97);
//     
//     // Checks the contract:  equals-hashcode on var19 and var60
//     assertTrue("Contract failed: equals-hashcode on var19 and var60", var19.equals(var60) ? var19.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var19
//     assertTrue("Contract failed: equals-hashcode on var60 and var19", var60.equals(var19) ? var60.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test223"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = var0.getRenderer((-237));
    org.jfree.chart.axis.AxisLocation var20 = var0.getDomainAxisLocation(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test224"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var9.clearSectionOutlinePaints(false);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
    boolean var14 = var9.equals((java.lang.Object)var13);
    java.awt.Paint var15 = var9.getBaseSectionOutlinePaint();
    var2.setWallPaint(var15);
    org.jfree.chart.plot.CategoryPlot var17 = var2.getPlot();
    int var18 = var2.getRowCount();
    org.jfree.chart.urls.CategoryURLGenerator var19 = var2.getBaseURLGenerator();
    double var20 = var2.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 4.0d);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test225"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var2.setLabelOutlineStroke(var20);
    double var23 = var2.getInteriorGap();
    java.awt.Paint var24 = var2.getLabelShadowPaint();
    var1.setPlotOutlinePaint(var24);
    org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var1.setBarPainter(var26);
    org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var30.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var33 = var30.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var34 = new org.jfree.chart.block.LabelBlock("", var33);
    var34.setToolTipText("ThreadContext");
    org.jfree.chart.axis.PeriodAxis var38 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var38.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var41 = var38.getTickLabelFont();
    var34.setFont(var41);
    var1.setSmallFont(var41);
    var1.setShadowVisible(false);
    java.awt.Paint var46 = var1.getGridBandPaint();
    java.awt.Paint var47 = var1.getRangeGridlinePaint();
    java.awt.Font var48 = var1.getLargeFont();
    org.jfree.chart.axis.CategoryAxis3D var49 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var50 = var49.getTickLabelPaint();
    java.lang.String var51 = var49.getLabel();
    var49.setFixedDimension(Double.NaN);
    var49.setLabelAngle(0.0d);
    org.jfree.data.xy.XYSeries var56 = null;
    org.jfree.data.xy.XYSeriesCollection var57 = new org.jfree.data.xy.XYSeriesCollection(var56);
    org.jfree.data.xy.XYSeries var58 = null;
    org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
    boolean var60 = var57.hasListener((java.util.EventListener)var59);
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.PolarItemRenderer var62 = null;
    org.jfree.chart.plot.PolarPlot var63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var57, var61, var62);
    var63.setForegroundAlpha(100.0f);
    var63.setAngleGridlinesVisible(true);
    java.awt.Paint var68 = var63.getBackgroundPaint();
    var49.setAxisLinePaint(var68);
    var1.setRangeGridlinePaint(var68);
    java.awt.Font var71 = var1.getExtraLargeFont();
    java.awt.Paint var72 = var1.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test226"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    org.jfree.data.xy.XYSeries var15 = null;
    org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
    boolean var17 = var14.hasListener((java.util.EventListener)var16);
    boolean var18 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
    java.lang.String var20 = var19.getID();
    org.jfree.chart.util.RectangleInsets var21 = var19.getPadding();
    var1.setLabelInsets(var21);
    var1.resizeRange2((-1.0d), (-1.88d));
    int var26 = var1.getMinorTickCount();
    java.awt.Stroke var27 = var1.getMinorTickMarkStroke();
    var1.setTickMarkInsideLength(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test227"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var2.getRenderer(0);
    java.util.List var5 = var2.getSubplots();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var10.setBaseStroke(var16);
    var7.setMinorTickMarkStroke(var16);
    var7.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var21 = var7.getLocale();
    var7.setPositiveArrowVisible(false);
    double var24 = var7.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var2.setDomainAxes(var25);
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = var27.getRenderer(0);
    java.util.List var30 = var27.getSubplots();
    org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
    var27.setFixedRangeAxisSpace(var31, false);
    var2.setFixedRangeAxisSpace(var31);
    java.awt.Color var38 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var39 = var38.getRGB();
    int var40 = var38.getAlpha();
    var2.setDomainGridlinePaint((java.awt.Paint)var38);
    org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.025d, (java.awt.Paint)var38);
    java.lang.Object var43 = var42.clone();
    var42.setLabel("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test228"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
//     java.text.NumberFormat var5 = var4.getYFormat();
//     boolean var6 = var0.equals((java.lang.Object)var5);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPositionFallback();
//     boolean var8 = var0.getShadowsVisible();
//     java.text.NumberFormat var10 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var11 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var10, var11);
//     java.text.NumberFormat var13 = var12.getYFormat();
//     java.text.DateFormat var14 = var12.getXDateFormat();
//     java.lang.String var15 = var12.getNullYString();
//     var0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var12, true);
//     java.awt.Shape var19 = null;
//     var0.setSeriesShape(0, var19);
//     org.jfree.chart.LegendItem var23 = var0.getLegendItem(1969, 255);
//     var0.setAutoPopulateSeriesStroke(false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "null"+ "'", var15.equals("null"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test229"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("null");
    boolean var3 = var1.isHiddenValue(644288400000L);
    java.awt.Shape var8 = null;
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var11 = null;
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    boolean var15 = var12.hasListener((java.util.EventListener)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
    java.awt.Paint var19 = var18.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var8, var10, var19);
    java.lang.String var21 = var20.getDescription();
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    boolean var23 = var20.equals((java.lang.Object)var22);
    java.util.TimeZone var24 = var22.getTimeZone();
    var1.setTimeZone(var24);
    org.jfree.data.time.Year var27 = new org.jfree.data.time.Year(1);
    java.util.Date var28 = var27.getStart();
    org.jfree.data.time.Year var30 = new org.jfree.data.time.Year(1);
    java.util.Date var31 = var30.getStart();
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange(var28, var31);
    var1.setMinimumDate(var28);
    org.jfree.data.Range var34 = var1.getRange();
    org.jfree.chart.axis.PeriodAxis var36 = new org.jfree.chart.axis.PeriodAxis("[-1.0, 0.0]");
    float var37 = var36.getMinorTickMarkOutsideLength();
    java.awt.Shape var38 = var36.getLeftArrow();
    java.util.TimeZone var39 = var36.getTimeZone();
    var1.setTimeZone(var39);
    org.jfree.chart.axis.DateTickMarkPosition var41 = var1.getTickMarkPosition();
    org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var43 = var42.getTickUnit();
    org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var47 = var46.getPlot();
    org.jfree.chart.plot.CategoryPlot var48 = var46.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var50 = null;
    var46.setSeriesURLGenerator(2, var50, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var46.setSeriesToolTipGenerator(0, var54);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var56 = null;
    var46.setLegendItemURLGenerator(var56);
    boolean var58 = var43.equals((java.lang.Object)var56);
    var1.setTickUnit(var43, false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Pie 3D Plot"+ "'", var21.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test230"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var1 = var0.getShadowsVisible();
    double var2 = var0.getShadowXOffset();
    org.jfree.data.general.SeriesChangeInfo var3 = null;
    org.jfree.data.general.SeriesChangeEvent var4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var0, var3);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setBaseItemLabelGenerator(var5, false);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var0.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test231"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("null");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Stroke var6 = var5.getMinorTickMarkStroke();
//     org.jfree.chart.LegendItemCollection var7 = new org.jfree.chart.LegendItemCollection();
//     boolean var8 = var5.equals((java.lang.Object)var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var11 = new org.jfree.chart.axis.AxisState((-6.21357408E13d));
//     var11.cursorDown((-6.21357408E13d));
//     java.util.List var14 = null;
//     var11.setTicks(var14);
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var17 = var16.getTickLabelPaint();
//     java.lang.String var18 = var16.getLabel();
//     org.jfree.data.xy.XYDataItem var21 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var22 = var21.getXValue();
//     double var23 = var21.getYValue();
//     java.awt.Paint var24 = var16.getTickLabelPaint((java.lang.Comparable)var23);
//     var16.configure();
//     org.jfree.chart.util.RectangleInsets var26 = var16.getTickLabelInsets();
//     double var28 = var26.calculateTopOutset(0.05d);
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     org.jfree.data.xy.XYSeries var32 = null;
//     org.jfree.data.xy.XYSeriesCollection var33 = new org.jfree.data.xy.XYSeriesCollection(var32);
//     boolean var34 = var31.hasListener((java.util.EventListener)var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var36 = null;
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var31, var35, var36);
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var37);
//     var38.clearSubtitles();
//     java.awt.RenderingHints var40 = var38.getRenderingHints();
//     var38.setBackgroundImageAlpha(10.0f);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.text.NumberFormat var47 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var48 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var49 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var47, var48);
//     var45.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var49, false);
//     org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var53 = var52.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var56 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var60 = var56.getItemFillPaint(1, (-1), false);
//     var52.setLabelPaint(var60);
//     org.jfree.data.general.PieDataset var62 = var52.getDataset();
//     boolean var63 = var52.getSimpleLabels();
//     double var64 = var52.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var52);
//     org.jfree.chart.title.TextTitle var66 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var67 = var66.getID();
//     org.jfree.chart.util.RectangleInsets var68 = var66.getPadding();
//     double var70 = var68.extendWidth(10.0d);
//     var65.setItemLabelPadding(var68);
//     org.jfree.chart.block.BlockContainer var72 = null;
//     var65.setWrapper(var72);
//     boolean var74 = var49.equals((java.lang.Object)var65);
//     org.jfree.chart.title.TextTitle var75 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var76 = var75.clone();
//     org.jfree.chart.util.HorizontalAlignment var77 = var75.getTextAlignment();
//     boolean var79 = var77.equals((java.lang.Object)(-1L));
//     var65.setHorizontalAlignment(var77);
//     var38.addLegend(var65);
//     java.awt.geom.Rectangle2D var82 = var65.getBounds();
//     java.awt.geom.Rectangle2D var83 = var26.createOutsetRectangle(var82);
//     org.jfree.chart.plot.CombinedDomainXYPlot var84 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.util.RectangleEdge var85 = var84.getRangeAxisEdge();
//     java.util.List var86 = var5.refreshTicks(var9, var11, var82, var85);
//     double var87 = var1.java2DToValue(0.0d, var3, var85);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test232"); }


    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var11 = var7.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
    var7.setBaseStroke(var13);
    var4.setMinorTickMarkStroke(var13);
    var4.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var18 = var4.getLocale();
    org.jfree.chart.axis.TickUnitSource var19 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var18);
    org.jfree.chart.labels.StandardPieToolTipGenerator var20 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var18);
    org.jfree.chart.labels.StandardPieToolTipGenerator var21 = new org.jfree.chart.labels.StandardPieToolTipGenerator("$0.00?DomainOrder.NONE=3&amp;=2", var18);
    org.jfree.chart.labels.StandardPieToolTipGenerator var22 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var18);
    org.jfree.chart.axis.TickUnitSource var23 = org.jfree.chart.axis.LogAxis.createLogTickUnits(var18);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChartEntity: tooltip = null", var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test233"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(0.12d, "{0}: ({1}, {2})", "0,000,000,000%", true);
    java.lang.StringBuffer var6 = null;
    java.text.FieldPosition var7 = null;
    java.lang.StringBuffer var8 = var4.format((-1L), var6, var7);
    java.text.ParsePosition var10 = null;
    java.lang.Number var11 = var4.parse("PlotEntity: tooltip = Pie 3D Plot", var10);
    int var12 = var4.getMaximumIntegerDigits();
    java.lang.String var14 = var4.format((-17474108400001L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "{0}: ({1}, {2})^\uFFFD"+ "'", var14.equals("{0}: ({1}, {2})^\uFFFD"));

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test234"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var1.setBarPainter(var26);
//     org.jfree.chart.plot.PieLabelLinkStyle var28 = var1.getLabelLinkStyle();
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var37 = var33.getItemFillPaint(1, (-1), false);
//     var29.setLabelPaint(var37);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var45 = var41.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var46 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
//     var41.setBaseStroke(var47);
//     var29.setLabelOutlineStroke(var47);
//     boolean var50 = var28.equals((java.lang.Object)var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var29
//     assertTrue("Contract failed: equals-hashcode on var2 and var29", var2.equals(var29) ? var2.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var46
//     assertTrue("Contract failed: equals-hashcode on var19 and var46", var19.equals(var46) ? var19.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var2
//     assertTrue("Contract failed: equals-hashcode on var29 and var2", var29.equals(var2) ? var29.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var19
//     assertTrue("Contract failed: equals-hashcode on var46 and var19", var46.equals(var19) ? var46.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test235"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var2.setSeriesURLGenerator(10, var10);
    var2.setMinimumBarLength(1.0d);
    java.awt.Paint var14 = var2.getShadowPaint();
    java.awt.Stroke var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlineStroke(var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test236"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
    var1.setRangeWithMargins((org.jfree.data.Range)var13);
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var1.java2DToValue(0.08d, var16, var17);
    var1.setAutoRange(false);
    var1.setTickMarkOutsideLength((-1.0f));
    org.jfree.chart.axis.PeriodAxisLabelInfo[] var23 = var1.getLabelInfo();
    var1.zoomRange(0.0d, 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test237"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    var0.clearSectionOutlinePaints(false);
    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder();
    boolean var5 = var0.equals((java.lang.Object)var4);
    boolean var6 = var0.getAutoPopulateSectionPaint();
    org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
    var0.setSectionOutlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test238"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var0.getRenderer();
    boolean var20 = var0.isRangeZoomable();
    org.jfree.chart.axis.ValueAxis var22 = var0.getRangeAxisForDataset(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test239"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var5 = var0.getDataset(1);
    int var6 = var0.getWeight();
    org.jfree.data.time.TimeSeries var7 = null;
    org.jfree.data.time.TimeSeriesCollection var8 = new org.jfree.data.time.TimeSeriesCollection(var7);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis();
    var9.resizeRange2(100.0d, 4.0d);
    var9.setRangeAboutValue(0.08d, 4.0d);
    org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = var16.getRenderer(0);
    java.util.List var19 = var16.getSubplots();
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var28 = var24.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
    var24.setBaseStroke(var30);
    var21.setMinorTickMarkStroke(var30);
    var21.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var35 = var21.getLocale();
    var21.setPositiveArrowVisible(false);
    double var38 = var21.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var39 = new org.jfree.chart.axis.ValueAxis[] { var21};
    var16.setDomainAxes(var39);
    org.jfree.chart.util.RectangleEdge var42 = var16.getRangeAxisEdge(0);
    boolean var43 = var16.isRangeZoomable();
    boolean var44 = var9.equals((java.lang.Object)var16);
    org.jfree.chart.renderer.PolarItemRenderer var45 = null;
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, (org.jfree.chart.axis.ValueAxis)var9, var45);
    org.jfree.data.Range var47 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var8);
    var0.setDataset((org.jfree.data.xy.XYDataset)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test240"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var3 = var2.getRange();
    org.jfree.data.xy.XYSeries var4 = null;
    org.jfree.data.xy.XYSeriesCollection var5 = new org.jfree.data.xy.XYSeriesCollection(var4);
    org.jfree.data.xy.XYSeries var6 = null;
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
    boolean var8 = var5.hasListener((java.util.EventListener)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var5, var9, var10);
    var11.setForegroundAlpha(100.0f);
    boolean var14 = var11.isAngleLabelsVisible();
    boolean var15 = var11.isAngleLabelsVisible();
    boolean var16 = var11.isDomainZoomable();
    java.lang.Object var17 = var11.clone();
    boolean var18 = var11.isAngleGridlinesVisible();
    boolean var19 = var3.equals((java.lang.Object)var11);
    var0.setRange(var3);
    java.text.NumberFormat var22 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var24 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var25 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var26 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var24, var25);
    var24.setMinimumIntegerDigits(10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var29 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var22, var24);
    java.lang.String var31 = var24.format(0.0d);
    java.lang.String var33 = var24.format(0L);
    var24.setMaximumIntegerDigits(1);
    java.math.RoundingMode var36 = var24.getRoundingMode();
    var0.setNumberFormatOverride(var24);
    org.jfree.chart.axis.AxisCollection var38 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var39 = var38.getAxesAtRight();
    boolean var40 = var0.equals((java.lang.Object)var38);
    org.jfree.chart.axis.NumberTickUnit var41 = var0.getTickUnit();
    var0.resizeRange(8.0d, 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "0,000,000,000%"+ "'", var31.equals("0,000,000,000%"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "0,000,000,000%"+ "'", var33.equals("0,000,000,000%"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest7.test241"); }
// 
// 
//     org.jfree.chart.util.PaintMap var0 = new org.jfree.chart.util.PaintMap();
//     java.awt.Paint var2 = var0.getPaint((java.lang.Comparable)12.0d);
//     var0.clear();
//     java.lang.Object var4 = var0.clone();
//     java.lang.Object var5 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var4 and var5
//     assertTrue("Contract failed: equals-hashcode on var4 and var5", var4.equals(var5) ? var4.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var4
//     assertTrue("Contract failed: equals-hashcode on var5 and var4", var5.equals(var4) ? var5.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test242"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    var2.setMaximumCategoryLabelLines(3);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var8.setBaseSeriesVisible(false, false);
    java.awt.Font var13 = null;
    var8.setSeriesItemLabelFont(3, var13, true);
    java.awt.Color var19 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var20 = var19.darker();
    var8.setBaseOutlinePaint((java.awt.Paint)var20);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var23 = var22.getFont();
    var8.setBaseLegendTextFont(var23);
    var2.setTickLabelFont((java.lang.Comparable)(byte)1, var23);
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("hi!");
    boolean var28 = var27.getExpandToFitSpace();
    java.awt.Paint var29 = var27.getPaint();
    var0.addLine("black", var23, var29);
    org.jfree.chart.text.TextLine var31 = var0.getLastLine();
    org.jfree.chart.text.TextFragment var32 = var31.getLastTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test243"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var1 = null;
    var0.plotChanged(var1);
    java.lang.Object var3 = var0.clone();
    java.lang.String var4 = var0.getPlotType();
    org.jfree.chart.LegendItemCollection var5 = var0.getLegendItems();
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = var8.getRenderer(0);
    java.util.List var11 = var8.getSubplots();
    org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var20 = var16.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
    var16.setBaseStroke(var22);
    var13.setMinorTickMarkStroke(var22);
    var13.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var27 = var13.getLocale();
    var13.setPositiveArrowVisible(false);
    double var30 = var13.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var31 = new org.jfree.chart.axis.ValueAxis[] { var13};
    var8.setDomainAxes(var31);
    org.jfree.chart.util.RectangleEdge var34 = var8.getRangeAxisEdge(0);
    boolean var35 = var8.isRangeZoomable();
    org.jfree.chart.ChartRenderingInfo var37 = new org.jfree.chart.ChartRenderingInfo();
    org.jfree.chart.plot.PlotRenderingInfo var38 = var37.getPlotInfo();
    org.jfree.data.xy.XYSeries var39 = null;
    org.jfree.data.xy.XYSeriesCollection var40 = new org.jfree.data.xy.XYSeriesCollection(var39);
    org.jfree.data.xy.XYSeries var41 = null;
    org.jfree.data.xy.XYSeriesCollection var42 = new org.jfree.data.xy.XYSeriesCollection(var41);
    boolean var43 = var40.hasListener((java.util.EventListener)var42);
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.PolarItemRenderer var45 = null;
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var40, var44, var45);
    var46.setForegroundAlpha(100.0f);
    var46.setAngleGridlinesVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var52 = null;
    java.awt.geom.Rectangle2D var53 = null;
    org.jfree.chart.util.RectangleAnchor var54 = null;
    java.awt.geom.Point2D var55 = org.jfree.chart.util.RectangleAnchor.coordinates(var53, var54);
    var46.zoomDomainAxes(0.14d, var52, var55);
    var8.panRangeAxes(0.5d, var38, var55);
    var0.handleClick(15, 1, var38);
    int var59 = var0.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Combined Range XYPlot"+ "'", var4.equals("Combined Range XYPlot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test244"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    var0.setRangeCrosshairValue(0.0d);
    int var20 = var0.getDatasetCount();
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var24 = var23.getTickLabelPaint();
    org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var28 = var27.getItemCount();
    org.jfree.data.time.Year var30 = new org.jfree.data.time.Year(1);
    java.util.Date var31 = var30.getStart();
    var27.add((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var36 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var30, true);
    org.jfree.data.time.Year var38 = new org.jfree.data.time.Year(1);
    org.jfree.chart.axis.PeriodAxis var39 = new org.jfree.chart.axis.PeriodAxis("$0.00?DomainOrder.NONE=3&amp;=2", (org.jfree.data.time.RegularTimePeriod)var30, (org.jfree.data.time.RegularTimePeriod)var38);
    var39.setNegativeArrowVisible(true);
    var39.setVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    double var45 = var44.getUpperClip();
    org.jfree.data.category.CategoryDataset var46 = null;
    org.jfree.data.Range var48 = var44.findRangeBounds(var46, false);
    double var49 = var44.getMaximumBarWidth();
    var44.setIncludeBaseInRange(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var53 = var44.getSeriesToolTipGenerator(0);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var22, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var44);
    var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var44, false);
    var44.setBaseSeriesVisibleInLegend(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test245"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    java.lang.String var7 = var5.toString();
    org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var11 = var10.getXValue();
    var10.setY(0.0d);
    int var14 = var5.compareTo((java.lang.Object)var10);
    java.lang.Number var15 = var10.getX();
    var0.setDomainCrosshairColumnKey((java.lang.Comparable)var10);
    boolean var17 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var0.getRenderer();
    boolean var20 = var0.isRangeZoomable();
    int var21 = var0.getCrosshairDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "[-1.0, 0.0]"+ "'", var7.equals("[-1.0, 0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (byte)(-1)+ "'", var15.equals((byte)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest7.test246"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getRangeGridlineStroke();
    java.awt.Paint var2 = var0.getDomainTickBandPaint();
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var5 = var4.getOutlineStroke();
    double var6 = var4.getValue();
    org.jfree.chart.util.Layer var7 = null;
    boolean var8 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var4, var7);
    java.awt.Stroke var9 = var4.getStroke();
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = var10.getRenderer(0);
    java.awt.Paint var13 = var10.getDomainCrosshairPaint();
    java.awt.Paint var14 = var10.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var15 = var10.getDomainAxisLocation();
    org.jfree.data.xy.XYSeries var16 = null;
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection(var16);
    org.jfree.data.xy.XYSeries var18 = null;
    org.jfree.data.xy.XYSeriesCollection var19 = new org.jfree.data.xy.XYSeriesCollection(var18);
    boolean var20 = var17.hasListener((java.util.EventListener)var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.PolarItemRenderer var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var17, var21, var22);
    var23.setForegroundAlpha(100.0f);
    boolean var26 = var23.isAngleLabelsVisible();
    boolean var27 = var23.isAngleLabelsVisible();
    boolean var28 = var23.isDomainZoomable();
    var10.setParent((org.jfree.chart.plot.Plot)var23);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var32 = var30.getRangeAxisLocation(1);
    org.jfree.chart.util.RectangleEdge var33 = var30.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var35 = var30.getDomainAxisLocation(12);
    var10.setRangeAxisLocation(var35, true);
    var10.clearAnnotations();
    org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = var39.getRenderer(0);
    java.util.List var42 = var39.getSubplots();
    org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var51 = var47.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var53 = var52.getBaseSectionOutlineStroke();
    var47.setBaseStroke(var53);
    var44.setMinorTickMarkStroke(var53);
    var44.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var58 = var44.getLocale();
    var44.setPositiveArrowVisible(false);
    double var61 = var44.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var62 = new org.jfree.chart.axis.ValueAxis[] { var44};
    var39.setDomainAxes(var62);
    org.jfree.chart.util.RectangleEdge var65 = var39.getRangeAxisEdge(0);
    java.awt.Stroke var66 = var39.getDomainGridlineStroke();
    var10.setRangeMinorGridlineStroke(var66);
    var4.setOutlineStroke(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

}
