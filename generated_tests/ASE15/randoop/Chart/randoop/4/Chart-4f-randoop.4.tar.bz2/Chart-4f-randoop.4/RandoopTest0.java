
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("hi!", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)0.0d);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(byte)1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.IntervalXYDelegate var1 = new org.jfree.data.xy.IntervalXYDelegate(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var5 = new org.jfree.chart.entity.TitleEntity(var0, (org.jfree.chart.title.Title)var2, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getInstance(var0);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)'#');

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.awt.Paint var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 10.0d, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, 10.0f, var4, 1.0d, var6);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesFillPaint((-1), var4, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, 1.0f, var4, 1.0d, 10.0f, 100.0f);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    org.jfree.chart.util.Layer var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addAnnotation(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(100.0d);
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setHorizontalAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    org.jfree.chart.util.RectangleEdge var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPosition(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(var0, 100);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, (-1.0f), 10.0f, 0.0d, (-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, 1, var2);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var1.getEndYValue((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var13 = var9.getItemFillPaint(1, (-1), false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem(var0, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var4, var6, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 10.0d, 0, (java.lang.Comparable)3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test36() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getID();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getPadding();
//     java.awt.geom.Rectangle2D var3 = null;
//     var2.trim(var3);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
//     org.jfree.chart.axis.TickUnit var8 = var7.getAngleTickUnit();
//     double var9 = var7.getMaxRadius();
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.axis.CategoryAnchor var1 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var0.getCategoryJava2DCoordinate(var1, 0, 3, var4, var5);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 1.0d);
//     java.util.Calendar var4 = null;
//     var1.peg(var4);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
//     java.awt.Paint var8 = var7.getRadiusGridlinePaint();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var7.drawOutline(var9, var10);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addSeries((java.lang.Comparable)0.0d, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, 0.0f, var4, 0.0d, var6);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Font var7 = null;
    var2.setSeriesItemLabelFont(3, var7, true);
    java.awt.Shape var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShape((-1), var11, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var3);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    var2.setLabelPaint(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("hi!", var1, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getXValue(0, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.labels.ItemLabelPosition var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseNegativeItemLabelPosition(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    java.awt.Shape var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PieSectionEntity var7 = new org.jfree.chart.entity.PieSectionEntity(var0, var1, 0, 10, (java.lang.Comparable)(-1), "hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
    var2.setBaseStroke(var8);
    org.jfree.chart.labels.ItemLabelPosition var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseNegativeItemLabelPosition(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var3 = var2.getDefaultEntityRadius();
//     java.awt.Shape var5 = var2.getSeriesShape(1);
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var8 = var7.getTickLabelPaint();
//     var2.setSeriesOutlinePaint(0, var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = null;
//     org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var20 = var16.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     var16.setBaseStroke(var22);
//     var13.setMinorTickMarkStroke(var22);
//     java.awt.geom.Rectangle2D var25 = null;
//     var2.fillRangeGridBand(var10, var11, (org.jfree.chart.axis.ValueAxis)var13, var25, 0.0d, 0.5d);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    org.jfree.chart.axis.TickUnit var8 = var7.getAngleTickUnit();
    java.awt.Paint var9 = var7.getRadiusGridlinePaint();
    var7.removeCornerTextItem("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getSeriesKey(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.renderer.xy.XYBarPainter var0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    var1.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.TimeZone var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "$0.00");

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 3, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "[-1.0, 0.0]", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
    var1.setRangeWithMargins((org.jfree.data.Range)var13);
    java.lang.Class var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeTimePeriodClass(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance(var0);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 12.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var10 = var9.getDefaultEntityRadius();
    java.awt.Shape var12 = var9.getSeriesShape(1);
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var15 = var14.getTickLabelPaint();
    var9.setSeriesOutlinePaint(0, var15);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var20.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var30 = var26.getItemFillPaint(1, (-1), false);
    var20.setBaseLegendTextPaint(var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var39 = var35.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
    var35.setBaseStroke(var41);
    var32.setAxisLineStroke(var41);
    java.awt.Shape var45 = null;
    org.jfree.chart.plot.PiePlot3D var46 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var50 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var54 = var50.getItemFillPaint(1, (-1), false);
    var46.setLabelPaint(var54);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var58 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var62 = var58.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var63 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var64 = var63.getBaseSectionOutlineStroke();
    var58.setBaseStroke(var64);
    var46.setLabelOutlineStroke(var64);
    org.jfree.chart.axis.CategoryAxis3D var67 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var68 = var67.getTickLabelPaint();
    java.lang.String var69 = var67.getLabel();
    var67.setFixedDimension(Double.NaN);
    org.jfree.data.xy.XYSeries var72 = null;
    org.jfree.data.xy.XYSeriesCollection var73 = new org.jfree.data.xy.XYSeriesCollection(var72);
    org.jfree.data.xy.XYSeries var74 = null;
    org.jfree.data.xy.XYSeriesCollection var75 = new org.jfree.data.xy.XYSeriesCollection(var74);
    boolean var76 = var73.hasListener((java.util.EventListener)var75);
    org.jfree.chart.axis.ValueAxis var77 = null;
    org.jfree.chart.renderer.PolarItemRenderer var78 = null;
    org.jfree.chart.plot.PolarPlot var79 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var73, var77, var78);
    java.awt.Paint var80 = var79.getRadiusGridlinePaint();
    var67.setAxisLinePaint(var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem(var0, "$0.00", "[-1.0, 0.0]", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", true, var5, true, var15, false, var30, var41, true, var45, var64, var80);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, var1);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1);
// 
//   }

//  public void test81() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var1 = var0.getTickLabelPaint();
    java.awt.Font var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelFont(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(100.0d);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    org.jfree.data.xy.XYSeries var5 = null;
    org.jfree.data.xy.XYSeriesCollection var6 = new org.jfree.data.xy.XYSeriesCollection(var5);
    boolean var7 = var4.hasListener((java.util.EventListener)var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.PolarItemRenderer var9 = null;
    org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var4, var8, var9);
    org.jfree.chart.axis.TickUnit var11 = var10.getAngleTickUnit();
    java.awt.Paint var12 = var10.getRadiusGridlinePaint();
    var0.setPaint(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(100.0d, 0.08d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.xy.XYSeries var1 = null;
//     org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
//     org.jfree.data.xy.XYSeries var3 = null;
//     org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
//     boolean var5 = var2.hasListener((java.util.EventListener)var4);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     var9.draw(var10, var11, var12);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("hi!", "hi!");
    java.lang.String var3 = var2.getEmail();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "hi!"+ "'", var3.equals("hi!"));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
    var2.setSeriesOutlineStroke(0, var5, true);
    var2.setSeriesCreateEntities(0, (java.lang.Boolean)false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.data.general.PieDataset var10 = var0.getDataset();
//     boolean var11 = var0.getSimpleLabels();
//     double var12 = var0.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var15 = var14.getID();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getPadding();
//     double var18 = var16.extendWidth(10.0d);
//     var13.setItemLabelPadding(var16);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, 1.0d, Double.NaN);
//     java.lang.Object var27 = var13.draw(var20, var21, (java.lang.Object)var23);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 1.0d, 0.08d, var3);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleAnchor var12 = null;
//     java.awt.geom.Point2D var13 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var12);
//     var7.zoomDomainAxes(100.0d, (-1.0d), var10, var13);
//     java.lang.String var15 = var7.getNoDataMessage();
//     java.awt.Stroke var16 = var7.getAngleGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     org.jfree.data.xy.XYSeries var20 = null;
//     org.jfree.data.xy.XYSeriesCollection var21 = new org.jfree.data.xy.XYSeriesCollection(var20);
//     org.jfree.data.xy.XYSeries var22 = null;
//     org.jfree.data.xy.XYSeriesCollection var23 = new org.jfree.data.xy.XYSeriesCollection(var22);
//     boolean var24 = var21.hasListener((java.util.EventListener)var23);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var26 = null;
//     org.jfree.chart.plot.PolarPlot var27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var21, var25, var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleAnchor var32 = null;
//     java.awt.geom.Point2D var33 = org.jfree.chart.util.RectangleAnchor.coordinates(var31, var32);
//     var27.zoomDomainAxes(100.0d, (-1.0d), var30, var33);
//     var7.zoomRangeAxes((-1.0d), 10.0d, var19, var33);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(100.0d);
    org.jfree.chart.util.RectangleEdge var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPosition(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    java.awt.Color var1 = java.awt.Color.getColor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)100);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("null");

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getKey(3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var1.getSeriesKey(3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.lang.Class var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeTimePeriodClass(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.getXValue(100, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    boolean var3 = var2.getAutoPopulateSeriesOutlinePaint();
    org.jfree.data.xy.XYSeries var5 = null;
    org.jfree.data.xy.XYSeriesCollection var6 = new org.jfree.data.xy.XYSeriesCollection(var5);
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    boolean var9 = var6.hasListener((java.util.EventListener)var8);
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var6, var10, var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleAnchor var17 = null;
    java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
    var12.zoomDomainAxes(100.0d, (-1.0d), var15, var18);
    java.lang.String var20 = var12.getNoDataMessage();
    java.awt.Stroke var21 = var12.getAngleGridlineStroke();
    var2.setSeriesStroke(100, var21);
    java.io.ObjectOutputStream var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var21, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var1.getStartX(0, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var4 = var3.getItemCount();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
//     org.jfree.data.time.TimeSeriesDataItem var8 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)100.0d);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var0.getCategorySeriesMiddle((java.lang.Comparable)Double.POSITIVE_INFINITY, (java.lang.Comparable)100.0d, var9, 0.12d, var11, var12);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDownArrow(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var6 = var5.getRGB();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("", var1, (java.awt.Paint)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-16777216));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    java.awt.Font var8 = var2.getSeriesItemLabelFont(1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var12 = var11.getDefaultEntityRadius();
    java.awt.Shape var14 = var11.getSeriesShape(1);
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var17 = var16.getTickLabelPaint();
    var11.setSeriesOutlinePaint(0, var17);
    var2.setBaseFillPaint(var17, true);
    var2.setBaseSeriesVisibleInLegend(false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesCreateEntities((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    java.awt.Font var8 = var2.getSeriesItemLabelFont(1);
    org.jfree.chart.annotations.XYAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(1.0E-8d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 10);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getID();
    org.jfree.chart.util.RectangleInsets var2 = var0.getPadding();
    double var4 = var2.extendWidth(10.0d);
    double var6 = var2.calculateTopOutset(12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var4 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var4, var5);
    var2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var6, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var12.setBaseSeriesVisible(false, false);
    java.awt.Font var17 = null;
    var12.setSeriesItemLabelFont(3, var17, true);
    org.jfree.chart.labels.ItemLabelPosition var20 = var12.getBasePositiveItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesNegativeItemLabelPosition((-16777216), var20, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
//     var7.setForegroundAlpha(100.0f);
//     boolean var10 = var7.isAngleLabelsVisible();
//     boolean var11 = var7.isAngleLabelsVisible();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     java.awt.Font var20 = var14.getSeriesItemLabelFont(1);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var24 = var23.getDefaultEntityRadius();
//     java.awt.Shape var26 = var23.getSeriesShape(1);
//     org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var29 = var28.getTickLabelPaint();
//     var23.setSeriesOutlinePaint(0, var29);
//     var14.setBaseFillPaint(var29, true);
//     var7.setRadiusGridlinePaint(var29);
//     var7.setOutlineVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleAnchor var39 = null;
//     java.awt.geom.Point2D var40 = org.jfree.chart.util.RectangleAnchor.coordinates(var38, var39);
//     var7.zoomRangeAxes(0.0d, var37, var40, true);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.xy.XYSeries var3 = null;
//     org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
//     org.jfree.data.xy.XYSeries var5 = null;
//     org.jfree.data.xy.XYSeriesCollection var6 = new org.jfree.data.xy.XYSeriesCollection(var5);
//     boolean var7 = var4.hasListener((java.util.EventListener)var6);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var4, var8, var9);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleAnchor var15 = null;
//     java.awt.geom.Point2D var16 = org.jfree.chart.util.RectangleAnchor.coordinates(var14, var15);
//     var10.zoomDomainAxes(100.0d, (-1.0d), var13, var16);
//     org.jfree.chart.plot.PlotState var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     var0.draw(var1, var2, var16, var18, var19);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
//     java.util.Date var5 = var4.getStart();
//     org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(var2, var5);
//     org.jfree.data.Range var7 = null;
//     boolean var8 = var6.intersects(var7);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var7.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
    var7.setBaseLegendTextPaint(var17);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    boolean var22 = var21.getAutoPopulateSeriesOutlinePaint();
    org.jfree.data.xy.XYSeries var24 = null;
    org.jfree.data.xy.XYSeriesCollection var25 = new org.jfree.data.xy.XYSeriesCollection(var24);
    org.jfree.data.xy.XYSeries var26 = null;
    org.jfree.data.xy.XYSeriesCollection var27 = new org.jfree.data.xy.XYSeriesCollection(var26);
    boolean var28 = var25.hasListener((java.util.EventListener)var27);
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var25, var29, var30);
    org.jfree.chart.plot.PlotRenderingInfo var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleAnchor var36 = null;
    java.awt.geom.Point2D var37 = org.jfree.chart.util.RectangleAnchor.coordinates(var35, var36);
    var31.zoomDomainAxes(100.0d, (-1.0d), var34, var37);
    java.lang.String var39 = var31.getNoDataMessage();
    java.awt.Stroke var40 = var31.getAngleGridlineStroke();
    var21.setSeriesStroke(100, var40);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var44 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var48 = var44.getItemFillPaint(1, (-1), false);
    java.awt.Font var50 = var44.getSeriesItemLabelFont(1);
    java.awt.Paint var52 = var44.lookupSeriesOutlinePaint((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem(var0, "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "Value", var4, var17, var40, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    var0.validateObject();
    org.jfree.data.DomainOrder var2 = var0.getDomainOrder();
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "DomainOrder.NONE"+ "'", var3.equals("DomainOrder.NONE"));

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     boolean var7 = var3.isAutoWidth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var10 = var3.getEndY(0, 2);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(1.0d, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var9.clearSubtitles();
    org.jfree.chart.event.ChartProgressListener var11 = null;
    var9.removeProgressListener(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var14 = var9.getSubtitle(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var4, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.delete(3, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0f, 0.5f, 0.0d, 100.0f, (-1.0f));

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSelected(1, (-16777216), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var4 = var3.getItemCount();
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
    java.util.Date var7 = var6.getStart();
    var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)Double.NaN, true);
    var1.delete((org.jfree.data.time.RegularTimePeriod)var6);
    java.lang.String var12 = var1.getRangeDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var14 = var1.getDataItem(3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Value"+ "'", var12.equals("Value"));

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var0.getY((-1), (-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var0);
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset)var1);
    org.jfree.chart.util.SortOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.sortByValues(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
//     var27.setSeriesOutlineStroke(0, var30, true);
//     org.jfree.data.xy.XYSeries var33 = null;
//     org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
//     org.jfree.data.xy.XYSeries var35 = null;
//     org.jfree.data.xy.XYSeriesCollection var36 = new org.jfree.data.xy.XYSeriesCollection(var35);
//     boolean var37 = var34.hasListener((java.util.EventListener)var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var39 = null;
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var34, var38, var39);
//     var40.setForegroundAlpha(100.0f);
//     boolean var43 = var40.isAngleLabelsVisible();
//     boolean var44 = var40.isAngleLabelsVisible();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var51 = var47.getItemFillPaint(1, (-1), false);
//     java.awt.Font var53 = var47.getSeriesItemLabelFont(1);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var56 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var57 = var56.getDefaultEntityRadius();
//     java.awt.Shape var59 = var56.getSeriesShape(1);
//     org.jfree.chart.axis.CategoryAxis3D var61 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var62 = var61.getTickLabelPaint();
//     var56.setSeriesOutlinePaint(0, var62);
//     var47.setBaseFillPaint(var62, true);
//     var40.setRadiusGridlinePaint(var62);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var69 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.PiePlot3D var71 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var72 = var71.getBaseSectionOutlineStroke();
//     var69.setSeriesOutlineStroke(0, var72, true);
//     org.jfree.chart.plot.IntervalMarker var76 = new org.jfree.chart.plot.IntervalMarker(0.14d, 0.0d, var24, var30, var62, var72, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var19 and var29
//     assertTrue("Contract failed: equals-hashcode on var19 and var29", var19.equals(var29) ? var19.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var71
//     assertTrue("Contract failed: equals-hashcode on var19 and var71", var19.equals(var71) ? var19.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var19
//     assertTrue("Contract failed: equals-hashcode on var29 and var19", var29.equals(var19) ? var29.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var71
//     assertTrue("Contract failed: equals-hashcode on var29 and var71", var29.equals(var71) ? var29.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var19
//     assertTrue("Contract failed: equals-hashcode on var71 and var19", var71.equals(var19) ? var71.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var29
//     assertTrue("Contract failed: equals-hashcode on var71 and var29", var71.equals(var29) ? var71.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var27
//     assertTrue("Contract failed: equals-hashcode on var6 and var27", var6.equals(var27) ? var6.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var56
//     assertTrue("Contract failed: equals-hashcode on var6 and var56", var6.equals(var56) ? var6.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var69
//     assertTrue("Contract failed: equals-hashcode on var6 and var69", var6.equals(var69) ? var6.hashCode() == var69.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var27.", var6.equals(var27) == var27.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var56.", var6.equals(var56) == var56.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var69.", var6.equals(var69) == var69.equals(var6));
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var4 = var3.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var11 = var7.getItemFillPaint(1, (-1), false);
//     var3.setLabelPaint(var11);
//     org.jfree.data.general.PieDataset var13 = var3.getDataset();
//     boolean var14 = var3.getSimpleLabels();
//     double var15 = var3.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var18 = var17.getID();
//     org.jfree.chart.util.RectangleInsets var19 = var17.getPadding();
//     double var21 = var19.extendWidth(10.0d);
//     var16.setItemLabelPadding(var19);
//     org.jfree.chart.block.BlockContainer var23 = null;
//     var16.setWrapper(var23);
//     org.jfree.chart.util.RectangleAnchor var25 = var16.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var26 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, Double.POSITIVE_INFINITY, 12.0d, var25);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    var2.setBaseLegendTextPaint(var12);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var17.setBaseSeriesVisible(false, false);
    java.awt.Font var22 = null;
    var17.setSeriesItemLabelFont(3, var22, true);
    org.jfree.chart.labels.ItemLabelPosition var25 = var17.getBasePositiveItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesNegativeItemLabelPosition((-1), var25, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var2 = var1.getItemCount();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
//     java.util.Date var5 = var4.getStart();
//     var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 12.0d);
//     java.util.Calendar var11 = null;
//     var4.peg(var11);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var4, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.update((java.lang.Number)(short)(-1), (java.lang.Number)1L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var4, true);
    java.lang.Number var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var12 = var10.remove(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie 3D Plot", "", var3);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.5d, 0.0d, 0.14d, 0.08d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
    var1.setLabelPaint(var9);
    org.jfree.data.general.PieDataset var11 = var1.getDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var12 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(2, var1);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var2 = var0.getValue(3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    java.util.TimeZone var1 = null;
    org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
    var6.setBaseStroke(var12);
    var3.setMinorTickMarkStroke(var12);
    var3.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var17 = var3.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("Pie 3D Plot", var1, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleAnchor var9 = null;
    java.awt.geom.Point2D var10 = org.jfree.chart.util.RectangleAnchor.coordinates(var8, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(0.14d, var7, var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     org.jfree.chart.annotations.XYAnnotation var1 = null;
//     boolean var2 = var0.removeAnnotation(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = var4.getRenderer(0);
//     java.util.List var7 = var4.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var9 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var12.setBaseStroke(var18);
//     var9.setMinorTickMarkStroke(var18);
//     var9.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var23 = var9.getLocale();
//     var9.setPositiveArrowVisible(false);
//     double var26 = var9.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var27 = new org.jfree.chart.axis.ValueAxis[] { var9};
//     var4.setDomainAxes(var27);
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var37 = var33.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var38 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var39 = var38.getBaseSectionOutlineStroke();
//     var33.setBaseStroke(var39);
//     var30.setMinorTickMarkStroke(var39);
//     org.jfree.data.xy.XYSeries var42 = null;
//     org.jfree.data.xy.XYSeriesCollection var43 = new org.jfree.data.xy.XYSeriesCollection(var42);
//     org.jfree.data.xy.XYSeries var44 = null;
//     org.jfree.data.xy.XYSeriesCollection var45 = new org.jfree.data.xy.XYSeriesCollection(var44);
//     boolean var46 = var43.hasListener((java.util.EventListener)var45);
//     boolean var47 = var30.equals((java.lang.Object)var46);
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var52 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var56 = var52.getItemFillPaint(1, (-1), false);
//     java.awt.Font var58 = var52.getSeriesItemLabelFont(1);
//     java.awt.Paint var60 = var52.lookupSeriesOutlinePaint((-1));
//     org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = var61.getRenderer(0);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var66 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     boolean var67 = var66.getAutoPopulateSeriesOutlinePaint();
//     org.jfree.data.xy.XYSeries var69 = null;
//     org.jfree.data.xy.XYSeriesCollection var70 = new org.jfree.data.xy.XYSeriesCollection(var69);
//     org.jfree.data.xy.XYSeries var71 = null;
//     org.jfree.data.xy.XYSeriesCollection var72 = new org.jfree.data.xy.XYSeriesCollection(var71);
//     boolean var73 = var70.hasListener((java.util.EventListener)var72);
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var75 = null;
//     org.jfree.chart.plot.PolarPlot var76 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var70, var74, var75);
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     java.awt.geom.Rectangle2D var80 = null;
//     org.jfree.chart.util.RectangleAnchor var81 = null;
//     java.awt.geom.Point2D var82 = org.jfree.chart.util.RectangleAnchor.coordinates(var80, var81);
//     var76.zoomDomainAxes(100.0d, (-1.0d), var79, var82);
//     java.lang.String var84 = var76.getNoDataMessage();
//     java.awt.Stroke var85 = var76.getAngleGridlineStroke();
//     var66.setSeriesStroke(100, var85);
//     var61.setRangeMinorGridlineStroke(var85);
//     var0.drawDomainLine(var3, (org.jfree.chart.plot.XYPlot)var4, (org.jfree.chart.axis.ValueAxis)var30, var48, 1.0E-8d, var60, var85);
//     
//     // Checks the contract:  equals-hashcode on var52 and var66
//     assertTrue("Contract failed: equals-hashcode on var52 and var66", var52.equals(var66) ? var52.hashCode() == var66.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var52 and var66.", var52.equals(var66) == var66.equals(var52));
//     
//     // Checks the contract:  equals-hashcode on var17 and var38
//     assertTrue("Contract failed: equals-hashcode on var17 and var38", var17.equals(var38) ? var17.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var17
//     assertTrue("Contract failed: equals-hashcode on var38 and var17", var38.equals(var17) ? var38.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 0);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.LineUtilities.clipLine(var0, var1);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainZeroBaselineStroke(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     var2.setBaseSeriesVisible(false, false);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     var2.setBaseLegendTextPaint(var12);
//     org.jfree.chart.labels.XYItemLabelGenerator var15 = null;
//     var2.setSeriesItemLabelGenerator(3, var15, false);
//     int var18 = var2.getPassCount();
//     org.jfree.data.xy.XYSeries var19 = null;
//     org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection(var19);
//     org.jfree.data.xy.XYSeries var21 = null;
//     org.jfree.data.xy.XYSeriesCollection var22 = new org.jfree.data.xy.XYSeriesCollection(var21);
//     boolean var23 = var20.hasListener((java.util.EventListener)var22);
//     double var24 = var22.getIntervalPositionFactor();
//     org.jfree.data.Range var25 = var2.findRangeBounds((org.jfree.data.xy.XYDataset)var22);
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.axis.PeriodAxis var29 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var36 = var32.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var38 = var37.getBaseSectionOutlineStroke();
//     var32.setBaseStroke(var38);
//     var29.setMinorTickMarkStroke(var38);
//     org.jfree.data.time.DateRange var41 = new org.jfree.data.time.DateRange();
//     var29.setRangeWithMargins((org.jfree.data.Range)var41);
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var29.java2DToValue(0.08d, var44, var45);
//     org.jfree.chart.axis.PeriodAxis var48 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var51 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var55 = var51.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var56 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var57 = var56.getBaseSectionOutlineStroke();
//     var51.setBaseStroke(var57);
//     var48.setMinorTickMarkStroke(var57);
//     org.jfree.data.time.DateRange var60 = new org.jfree.data.time.DateRange();
//     var48.setRangeWithMargins((org.jfree.data.Range)var60);
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var48.java2DToValue(0.08d, var63, var64);
//     org.jfree.chart.util.Layer var66 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     var2.drawAnnotations(var26, var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var48, var66, var67);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    boolean var11 = var8.hasListener((java.util.EventListener)var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
    java.awt.Paint var15 = var14.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
    java.lang.String var17 = var16.getDescription();
    java.lang.String var18 = var16.getToolTipText();
    java.awt.Shape var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setLine(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Pie 3D Plot"+ "'", var17.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var12.setBaseStroke(var18);
//     var0.setLabelOutlineStroke(var18);
//     boolean var22 = var0.equals((java.lang.Object)'4');
//     java.awt.Shape var27 = null;
//     org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var29 = var28.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     org.jfree.data.xy.XYSeries var32 = null;
//     org.jfree.data.xy.XYSeriesCollection var33 = new org.jfree.data.xy.XYSeriesCollection(var32);
//     boolean var34 = var31.hasListener((java.util.EventListener)var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var36 = null;
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var31, var35, var36);
//     java.awt.Paint var38 = var37.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var27, var29, var38);
//     var0.setLabelOutlineStroke(var29);
//     
//     // Checks the contract:  equals-hashcode on var17 and var28
//     assertTrue("Contract failed: equals-hashcode on var17 and var28", var17.equals(var28) ? var17.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var17
//     assertTrue("Contract failed: equals-hashcode on var28 and var17", var28.equals(var17) ? var28.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)100.0d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    var2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var6);
    org.jfree.chart.labels.XYSeriesLabelGenerator var8 = var2.getLegendItemLabelGenerator();
    org.jfree.chart.labels.XYItemLabelGenerator var9 = var2.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Pie 3D Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("December 2014", var1);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var1 = var0.getShadowsVisible();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = null;
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var19 = var18.getOutlineStroke();
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawRangeMarker(var2, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.plot.Marker)var18, var20);
//     org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
//     var23.setLabelPaint(var31);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var39 = var35.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     var35.setBaseStroke(var41);
//     var23.setLabelOutlineStroke(var41);
//     var0.setSeriesOutlineStroke(10, var41);
//     
//     // Checks the contract:  equals-hashcode on var13 and var40
//     assertTrue("Contract failed: equals-hashcode on var13 and var40", var13.equals(var40) ? var13.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var13
//     assertTrue("Contract failed: equals-hashcode on var40 and var13", var40.equals(var13) ? var40.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var0);
    org.jfree.chart.util.SortOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByValues(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    int var1 = var0.getSeriesCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.getYValue(0, (-16777216));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.xy.XYSeries var1 = null;
//     org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
//     org.jfree.data.xy.XYSeries var3 = null;
//     org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
//     boolean var5 = var2.hasListener((java.util.EventListener)var4);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
//     var9.clearSubtitles();
//     org.jfree.chart.event.ChartProgressListener var11 = null;
//     var9.removeProgressListener(var11);
//     org.jfree.chart.event.TitleChangeEvent var13 = null;
//     var9.titleChanged(var13);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.awt.Paint var3 = var0.getDomainCrosshairPaint();
//     java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = var6.getRenderer(0);
//     java.awt.Paint var9 = var6.getDomainCrosshairPaint();
//     java.awt.Paint var10 = var6.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
//     var0.setRangeAxisLocation(var11, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleAnchor var12 = null;
//     java.awt.geom.Point2D var13 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var12);
//     var7.zoomDomainAxes(100.0d, (-1.0d), var10, var13);
//     java.lang.String var15 = var7.getNoDataMessage();
//     java.awt.Stroke var16 = var7.getAngleGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.data.xy.XYSeries var19 = null;
//     org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection(var19);
//     org.jfree.data.xy.XYSeries var21 = null;
//     org.jfree.data.xy.XYSeriesCollection var22 = new org.jfree.data.xy.XYSeriesCollection(var21);
//     boolean var23 = var20.hasListener((java.util.EventListener)var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var25 = null;
//     org.jfree.chart.plot.PolarPlot var26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var20, var24, var25);
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleAnchor var31 = null;
//     java.awt.geom.Point2D var32 = org.jfree.chart.util.RectangleAnchor.coordinates(var30, var31);
//     var26.zoomDomainAxes(100.0d, (-1.0d), var29, var32);
//     var7.zoomDomainAxes(Double.NaN, var18, var32, false);
//     
//     // Checks the contract:  equals-hashcode on var7 and var26
//     assertTrue("Contract failed: equals-hashcode on var7 and var26", var7.equals(var26) ? var7.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var7
//     assertTrue("Contract failed: equals-hashcode on var26 and var7", var26.equals(var7) ? var26.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var11 = var7.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
    var7.setBaseStroke(var13);
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
    var15.setLabelPaint(var23);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
    var27.setBaseStroke(var33);
    var15.setLabelOutlineStroke(var33);
    boolean var37 = var15.equals((java.lang.Object)'4');
    java.awt.Paint var38 = var15.getBaseSectionPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem(var0, "", "[-1.0, 0.0]", "java.awt.Color[r=0,g=0,b=0]", var4, var13, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(3, (-16777216), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
//     org.jfree.chart.urls.PieURLGenerator var11 = var0.getURLGenerator();
//     var0.setDarkerSides(true);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var17 = var16.getDefaultEntityRadius();
//     java.awt.Shape var19 = var16.getSeriesShape(1);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var22 = var21.getTickLabelPaint();
//     var16.setSeriesOutlinePaint(0, var22);
//     var0.setBaseSectionOutlinePaint(var22);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var16.", var4.equals(var16) == var16.equals(var4));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getKey(3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var3 = var2.getLabelAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var3, 0.0d, 0.12d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 100.0f, 10.0f, (-1.88d), 10.0f, 2.0f);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    boolean var3 = var2.getAutoPopulateSeriesOutlinePaint();
    boolean var4 = var2.getDrawOutlines();
    boolean var5 = var2.getAutoPopulateSeriesOutlineStroke();
    var2.removeAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.util.RectangleAnchor var5 = var4.getLabelAnchor();
//     java.awt.geom.Rectangle2D var6 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.12d, 1.0E-5d, var5);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    var2.setBaseLegendTextPaint(var12);
    org.jfree.chart.labels.XYItemLabelGenerator var15 = null;
    var2.setSeriesItemLabelGenerator(3, var15, false);
    int var18 = var2.getPassCount();
    org.jfree.data.xy.XYSeries var19 = null;
    org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection(var19);
    org.jfree.data.xy.XYSeries var21 = null;
    org.jfree.data.xy.XYSeriesCollection var22 = new org.jfree.data.xy.XYSeriesCollection(var21);
    boolean var23 = var20.hasListener((java.util.EventListener)var22);
    double var24 = var22.getIntervalPositionFactor();
    org.jfree.data.Range var25 = var2.findRangeBounds((org.jfree.data.xy.XYDataset)var22);
    double var26 = var22.getIntervalPositionFactor();
    org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var31 = var30.getItemCount();
    org.jfree.data.time.Year var33 = new org.jfree.data.time.Year(1);
    java.util.Date var34 = var33.getStart();
    var30.add((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)Double.NaN, true);
    var28.delete((org.jfree.data.time.RegularTimePeriod)var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var39 = var22.getSeries((java.lang.Comparable)var33);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var1 = var0.getNegativeItemLabelPositionFallback();
    var0.setShadowVisible(true);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = var6.getRenderer(0);
    java.awt.Paint var9 = var6.getDomainCrosshairPaint();
    java.awt.Paint var10 = var6.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var14.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var24 = var20.getItemFillPaint(1, (-1), false);
    var14.setBaseLegendTextPaint(var24);
    org.jfree.chart.labels.XYItemLabelGenerator var27 = null;
    var14.setSeriesItemLabelGenerator(3, var27, false);
    int var30 = var14.getPassCount();
    org.jfree.data.xy.XYSeries var31 = null;
    org.jfree.data.xy.XYSeriesCollection var32 = new org.jfree.data.xy.XYSeriesCollection(var31);
    org.jfree.data.xy.XYSeries var33 = null;
    org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
    boolean var35 = var32.hasListener((java.util.EventListener)var34);
    double var36 = var34.getIntervalPositionFactor();
    org.jfree.data.Range var37 = var14.findRangeBounds((org.jfree.data.xy.XYDataset)var34);
    org.jfree.data.DomainOrder var38 = var34.getDomainOrder();
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.xy.XYItemRendererState var40 = var0.initialise(var4, var5, (org.jfree.chart.plot.XYPlot)var6, (org.jfree.data.xy.XYDataset)var34, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    var2.setBaseLegendTextPaint(var12);
    boolean var14 = var2.getDataBoundsIncludesVisibleSeriesOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 0.14d, 0.5f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
//     java.lang.String var3 = var2.toString();
//     var1.setRangeWithMargins((org.jfree.data.Range)var2);
//     boolean var7 = var2.intersects(Double.NaN, 0.5d);
//     double var8 = var2.getCentralValue();
//     double var9 = var2.getUpperBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0d);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var1.getSeriesKey(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    java.util.Collection var3 = var1.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var5 = var1.getTimePeriod((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var1 = var0.isDrawBarOutline();
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlinePaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
//     var0.setFixedRangeAxisSpace(var4, false);
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = var4.shrink(var7, var8);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getIntegerInstance(var0);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    var0.setFixedRangeAxisSpace(var4, false);
    java.util.List var7 = var0.getSubplots();
    org.jfree.chart.annotations.XYAnnotation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var0.removeAnnotation(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var12.setBaseStroke(var18);
//     var0.setLabelOutlineStroke(var18);
//     double var21 = var0.getInteriorGap();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var25 = var24.getDefaultEntityRadius();
//     java.awt.Shape var27 = var24.getSeriesShape(1);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     var31.setSeriesOutlineStroke(0, var34, true);
//     var24.setSeriesOutlineStroke(2, var34);
//     var0.setLabelLinkStroke(var34);
//     
//     // Checks the contract:  equals-hashcode on var17 and var33
//     assertTrue("Contract failed: equals-hashcode on var17 and var33", var17.equals(var33) ? var17.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var17
//     assertTrue("Contract failed: equals-hashcode on var33 and var17", var33.equals(var17) ? var33.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var24
//     assertTrue("Contract failed: equals-hashcode on var4 and var24", var4.equals(var24) ? var4.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var31
//     assertTrue("Contract failed: equals-hashcode on var4 and var31", var4.equals(var31) ? var4.hashCode() == var31.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var24.", var4.equals(var24) == var24.equals(var4));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var4 and var31.", var4.equals(var31) == var31.equals(var4));
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    var0.validateObject();
    org.jfree.data.DomainOrder var2 = var0.getDomainOrder();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getYValue(2, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     org.jfree.chart.annotations.XYAnnotation var1 = null;
//     boolean var2 = var0.removeAnnotation(var1);
//     int var3 = var0.getPassCount();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = var7.getRenderer(0);
//     java.awt.Paint var10 = var7.getDomainCrosshairPaint();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var13 = var12.getMinorTickMarkPaint();
//     org.jfree.chart.axis.PeriodAxis var15 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var16 = var15.getMinorTickMarkPaint();
//     org.jfree.data.xy.XYSeries var17 = null;
//     org.jfree.data.xy.XYSeriesCollection var18 = new org.jfree.data.xy.XYSeriesCollection(var17);
//     org.jfree.data.xy.XYSeries var19 = null;
//     org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection(var19);
//     boolean var21 = var18.hasListener((java.util.EventListener)var20);
//     double var23 = var20.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var26 = var25.getItemCount();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year(1);
//     java.util.Date var29 = var28.getStart();
//     var25.add((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var34 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var28, true);
//     var20.addSeries(var34);
//     var0.drawItem(var4, var5, var6, (org.jfree.chart.plot.XYPlot)var7, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.data.xy.XYDataset)var20, 2, 0, false, (-1));
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    java.io.ObjectOutputStream var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var4 = var0.getDomainAxisForDataset(1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0, true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    var5.setBaseStroke(var11);
    var2.setMinorTickMarkStroke(var11);
    var2.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var16 = var2.getLocale();
    var2.setPositiveArrowVisible(false);
    org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var21 = var20.getItemCount();
    org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(1);
    java.util.Date var24 = var23.getStart();
    var20.add((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var28 = null;
    org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
    org.jfree.data.xy.XYSeries var30 = null;
    org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
    boolean var32 = var29.hasListener((java.util.EventListener)var31);
    double var33 = var31.getIntervalPositionFactor();
    var20.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var31);
    org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var37 = var36.getItemCount();
    org.jfree.data.time.Year var39 = new org.jfree.data.time.Year(1);
    java.util.Date var40 = var39.getStart();
    var36.add((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)Double.NaN, true);
    org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, 12.0d);
    java.lang.Number var46 = var20.getValue((org.jfree.data.time.RegularTimePeriod)var39);
    var2.setFirst((org.jfree.data.time.RegularTimePeriod)var39);
    org.jfree.data.time.TimeSeries var49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var50 = var49.getItemCount();
    org.jfree.data.time.Year var52 = new org.jfree.data.time.Year(1);
    java.util.Date var53 = var52.getStart();
    var49.add((org.jfree.data.time.RegularTimePeriod)var52, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var58 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var52, true);
    java.util.TimeZone var59 = null;
    org.jfree.chart.axis.PeriodAxis var62 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var65 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var69 = var65.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var70 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var71 = var70.getBaseSectionOutlineStroke();
    var65.setBaseStroke(var71);
    var62.setMinorTickMarkStroke(var71);
    var62.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var76 = var62.getLocale();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var77 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("$0.00", var76);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.PeriodAxis var78 = new org.jfree.chart.axis.PeriodAxis("$0.00?DomainOrder.NONE=3&amp;=2", (org.jfree.data.time.RegularTimePeriod)var39, (org.jfree.data.time.RegularTimePeriod)var52, var59, var76);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + Double.NaN+ "'", var46.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 1.0d, Double.NaN);
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = null;
//     org.jfree.chart.util.Size2D var8 = var4.arrange(var5, var6, var7);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var1 = var0.getTickLabelPaint();
//     java.lang.String var2 = var0.getLabel();
//     var0.setFixedDimension(Double.NaN);
//     var0.setFixedDimension(100.0d);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     org.jfree.chart.axis.AxisState var11 = null;
//     var0.drawTickMarks(var7, 0.5d, var9, var10, var11);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = var17.getRenderer(0);
//     java.util.List var20 = var17.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var22 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var29 = var25.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
//     var25.setBaseStroke(var31);
//     var22.setMinorTickMarkStroke(var31);
//     var22.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var36 = var22.getLocale();
//     var22.setPositiveArrowVisible(false);
//     double var39 = var22.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var40 = new org.jfree.chart.axis.ValueAxis[] { var22};
//     var17.setDomainAxes(var40);
//     org.jfree.chart.util.RectangleEdge var43 = var17.getRangeAxisEdge(0);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     org.jfree.chart.axis.AxisState var45 = var0.draw(var13, 0.0d, var15, var16, var43, var44);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.removeCategoryLabelToolTip((java.lang.Comparable)(short)100);
//     var0.setAxisLineVisible(true);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = var9.getRenderer(0);
//     java.util.List var12 = var9.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var21 = var17.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var17.setBaseStroke(var23);
//     var14.setMinorTickMarkStroke(var23);
//     var14.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var28 = var14.getLocale();
//     var14.setPositiveArrowVisible(false);
//     double var31 = var14.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var32 = new org.jfree.chart.axis.ValueAxis[] { var14};
//     var9.setDomainAxes(var32);
//     org.jfree.chart.util.RectangleEdge var35 = var9.getRangeAxisEdge(0);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.chart.axis.AxisState var37 = var0.draw(var5, 1.0d, var7, var8, var35, var36);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    double var1 = var0.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var4.setBaseStroke(var10);
//     var1.setMinorTickMarkStroke(var10);
//     var1.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var15 = var1.getLocale();
//     var1.setPositiveArrowVisible(false);
//     double var18 = var1.getAutoRangeMinimumSize();
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     java.awt.Paint var23 = var21.getLabelBackgroundPaint();
//     org.jfree.chart.entity.PlotEntity var26 = new org.jfree.chart.entity.PlotEntity(var20, (org.jfree.chart.plot.Plot)var21, "Pie 3D Plot", "[-1.0, 0.0]");
//     var1.setRightArrow(var20);
//     
//     // Checks the contract:  equals-hashcode on var9 and var21
//     assertTrue("Contract failed: equals-hashcode on var9 and var21", var9.equals(var21) ? var9.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var9
//     assertTrue("Contract failed: equals-hashcode on var21 and var9", var21.equals(var9) ? var21.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.resizeRange2(100.0d, 4.0d);
    org.jfree.chart.util.RectangleInsets var4 = var0.getLabelInsets();
    org.jfree.chart.axis.MarkerAxisBand var5 = var0.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var2 = var1.getItemCount();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
//     java.util.Date var5 = var4.getStart();
//     var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var9 = null;
//     org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
//     org.jfree.data.xy.XYSeries var11 = null;
//     org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
//     boolean var13 = var10.hasListener((java.util.EventListener)var12);
//     double var14 = var12.getIntervalPositionFactor();
//     var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var12);
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var18 = var17.getItemCount();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(1);
//     java.util.Date var21 = var20.getStart();
//     var17.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 12.0d);
//     java.lang.Number var27 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var20);
//     java.util.Calendar var28 = null;
//     long var29 = var20.getLastMillisecond(var28);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(1);
//     long var3 = var2.getLastMillisecond();
//     java.awt.Shape var8 = null;
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var11 = null;
//     org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     boolean var15 = var12.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
//     java.awt.Paint var19 = var18.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var8, var10, var19);
//     var0.setTickLabelPaint((java.lang.Comparable)var3, var19);
//     float var22 = var0.getMaximumCategoryLabelWidthRatio();
//     var0.setLowerMargin(1.0E-8d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-62104204800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.0f);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 1);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = var1.getRenderer(0);
//     java.awt.Paint var4 = var1.getDomainCrosshairPaint();
//     java.awt.Paint var5 = var1.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var6 = var1.getDomainAxisLocation();
//     java.awt.Paint var7 = var1.getDomainZeroBaselinePaint();
//     var0.setRangeTickBandPaint(var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = var9.getRenderer(0);
//     java.awt.Paint var12 = var9.getDomainCrosshairPaint();
//     java.awt.Paint var13 = var9.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var14 = var9.getDomainAxisLocation();
//     var0.remove((org.jfree.chart.plot.XYPlot)var9);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(1);
//     long var4 = var3.getLastMillisecond();
//     java.awt.Shape var9 = null;
//     org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var12 = null;
//     org.jfree.data.xy.XYSeriesCollection var13 = new org.jfree.data.xy.XYSeriesCollection(var12);
//     org.jfree.data.xy.XYSeries var14 = null;
//     org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
//     boolean var16 = var13.hasListener((java.util.EventListener)var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var13, var17, var18);
//     java.awt.Paint var20 = var19.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var9, var11, var20);
//     var1.setTickLabelPaint((java.lang.Comparable)var4, var20);
//     float var23 = var1.getMaximumCategoryLabelWidthRatio();
//     org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     var28.setBaseStroke(var34);
//     var25.setMinorTickMarkStroke(var34);
//     var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var39 = var25.getLocale();
//     org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var43 = var42.getPlot();
//     org.jfree.chart.plot.CategoryPlot var44 = var42.getPlot();
//     org.jfree.chart.urls.CategoryURLGenerator var46 = null;
//     var42.setSeriesURLGenerator(2, var46, true);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var1, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
//     java.lang.String var3 = var2.toString();
//     var1.setRangeWithMargins((org.jfree.data.Range)var2);
//     double var5 = var2.getLowerBound();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var4 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var4, var5);
    var2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var6, false);
    org.jfree.chart.labels.XYItemLabelGenerator var12 = var2.getItemLabelGenerator(3, 2, false);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
    var19.setBaseStroke(var25);
    var16.setMinorTickMarkStroke(var25);
    var16.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.awt.geom.Rectangle2D var30 = null;
    var2.drawDomainGridLine(var13, var14, (org.jfree.chart.axis.ValueAxis)var16, var30, Double.POSITIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShapesVisible((-16777216), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getRangeGridlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var4 = var3.getShadowsVisible();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var15 = var11.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
//     var11.setBaseStroke(var17);
//     var8.setMinorTickMarkStroke(var17);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var22 = var21.getOutlineStroke();
//     java.awt.geom.Rectangle2D var23 = null;
//     var3.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var33 = var29.getItemFillPaint(1, (-1), false);
//     var25.setLabelPaint(var33);
//     org.jfree.data.general.PieDataset var35 = var25.getDataset();
//     var25.setAutoPopulateSectionOutlinePaint(false);
//     float var38 = var25.getBackgroundImageAlpha();
//     java.awt.Paint var39 = var25.getNoDataMessagePaint();
//     var21.setPaint(var39);
//     org.jfree.chart.util.Layer var41 = null;
//     boolean var42 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var21, var41);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var49 = var45.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var50 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var51 = var50.getBaseSectionOutlineStroke();
//     var45.setBaseStroke(var51);
//     var21.setOutlineStroke(var51);
//     
//     // Checks the contract:  equals-hashcode on var16 and var50
//     assertTrue("Contract failed: equals-hashcode on var16 and var50", var16.equals(var50) ? var16.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var16
//     assertTrue("Contract failed: equals-hashcode on var50 and var16", var50.equals(var16) ? var50.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     var1.setLabelPaint(var9);
//     org.jfree.data.general.PieDataset var11 = var1.getDataset();
//     boolean var12 = var1.getSimpleLabels();
//     double var13 = var1.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var16 = var15.getID();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getPadding();
//     double var19 = var17.extendWidth(10.0d);
//     var14.setItemLabelPadding(var17);
//     org.jfree.chart.block.BlockContainer var21 = null;
//     var14.setWrapper(var21);
//     org.jfree.chart.util.RectangleAnchor var23 = var14.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var23);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(var0, 10);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var4 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var5 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var3, var4);
    var3.setMinimumIntegerDigits(10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1, var3);
    java.text.AttributedString var10 = null;
    var8.setAttributedLabel(1, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
//     long var5 = var4.getLastMillisecond();
//     java.awt.Shape var10 = null;
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     org.jfree.data.xy.XYSeries var15 = null;
//     org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
//     boolean var17 = var14.hasListener((java.util.EventListener)var16);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var14, var18, var19);
//     java.awt.Paint var21 = var20.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var10, var12, var21);
//     var2.setTickLabelPaint((java.lang.Comparable)var5, var21);
//     java.awt.Shape var28 = null;
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var31 = null;
//     org.jfree.data.xy.XYSeriesCollection var32 = new org.jfree.data.xy.XYSeriesCollection(var31);
//     org.jfree.data.xy.XYSeries var33 = null;
//     org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
//     boolean var35 = var32.hasListener((java.util.EventListener)var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var37 = null;
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var32, var36, var37);
//     java.awt.Paint var39 = var38.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var28, var30, var39);
//     org.jfree.chart.plot.PiePlot3D var41 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var42 = var41.getBaseSectionOutlineStroke();
//     java.awt.Paint var43 = var41.getLabelBackgroundPaint();
//     org.jfree.chart.axis.CategoryAxis3D var44 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var45 = var44.getTickLabelPaint();
//     var41.setOutlinePaint(var45);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     boolean var50 = var49.getAutoPopulateSeriesOutlinePaint();
//     org.jfree.data.xy.XYSeries var52 = null;
//     org.jfree.data.xy.XYSeriesCollection var53 = new org.jfree.data.xy.XYSeriesCollection(var52);
//     org.jfree.data.xy.XYSeries var54 = null;
//     org.jfree.data.xy.XYSeriesCollection var55 = new org.jfree.data.xy.XYSeriesCollection(var54);
//     boolean var56 = var53.hasListener((java.util.EventListener)var55);
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var58 = null;
//     org.jfree.chart.plot.PolarPlot var59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var53, var57, var58);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleAnchor var64 = null;
//     java.awt.geom.Point2D var65 = org.jfree.chart.util.RectangleAnchor.coordinates(var63, var64);
//     var59.zoomDomainAxes(100.0d, (-1.0d), var62, var65);
//     java.lang.String var67 = var59.getNoDataMessage();
//     java.awt.Stroke var68 = var59.getAngleGridlineStroke();
//     var49.setSeriesStroke(100, var68);
//     org.jfree.chart.plot.IntervalMarker var71 = new org.jfree.chart.plot.IntervalMarker((-1.88d), 1.0E-8d, var21, var30, var45, var68, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var38
//     assertTrue("Contract failed: equals-hashcode on var20 and var38", var20.equals(var38) ? var20.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var59
//     assertTrue("Contract failed: equals-hashcode on var20 and var59", var20.equals(var59) ? var20.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var20
//     assertTrue("Contract failed: equals-hashcode on var38 and var20", var38.equals(var20) ? var38.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var59
//     assertTrue("Contract failed: equals-hashcode on var38 and var59", var38.equals(var59) ? var38.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var20
//     assertTrue("Contract failed: equals-hashcode on var59 and var20", var59.equals(var20) ? var59.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var38
//     assertTrue("Contract failed: equals-hashcode on var59 and var38", var59.equals(var38) ? var59.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var40
//     assertTrue("Contract failed: equals-hashcode on var22 and var40", var22.equals(var40) ? var22.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var22
//     assertTrue("Contract failed: equals-hashcode on var40 and var22", var40.equals(var22) ? var40.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.xy.XYSeries var1 = null;
//     org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
//     org.jfree.data.xy.XYSeries var3 = null;
//     org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
//     boolean var5 = var2.hasListener((java.util.EventListener)var4);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
//     var9.clearSubtitles();
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     org.jfree.data.xy.XYSeries var15 = null;
//     org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
//     boolean var17 = var14.hasListener((java.util.EventListener)var16);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var14, var18, var19);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleAnchor var25 = null;
//     java.awt.geom.Point2D var26 = org.jfree.chart.util.RectangleAnchor.coordinates(var24, var25);
//     var20.zoomDomainAxes(100.0d, (-1.0d), var23, var26);
//     org.jfree.chart.ChartRenderingInfo var28 = new org.jfree.chart.ChartRenderingInfo();
//     var9.draw(var11, var12, var26, var28);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Image var1 = org.jfree.chart.util.SerialUtilities.readImage(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    double var9 = var2.getXOffset();
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addAnnotation(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5d);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.text.NumberFormat var4 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var4, var5);
//     var2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var6, false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     var9.setLabelPaint(var17);
//     org.jfree.data.general.PieDataset var19 = var9.getDataset();
//     boolean var20 = var9.getSimpleLabels();
//     double var21 = var9.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9);
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var24 = var23.getID();
//     org.jfree.chart.util.RectangleInsets var25 = var23.getPadding();
//     double var27 = var25.extendWidth(10.0d);
//     var22.setItemLabelPadding(var25);
//     org.jfree.chart.block.BlockContainer var29 = null;
//     var22.setWrapper(var29);
//     boolean var31 = var6.equals((java.lang.Object)var22);
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     java.lang.Object var34 = null;
//     java.lang.Object var35 = var22.draw(var32, var33, var34);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var9 = var8.getItemCount();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(1);
//     java.util.Date var12 = var11.getStart();
//     var8.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var11, true);
//     var3.addSeries(var17);
//     java.util.List var19 = var17.getItems();
//     java.lang.Number var20 = null;
//     java.lang.Number var21 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.xy.XYDataItem var22 = var17.addOrUpdate(var20, var21);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addValue(var1, (java.lang.Number)45.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
//     org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
//     org.jfree.chart.urls.CategoryURLGenerator var6 = null;
//     var2.setSeriesURLGenerator(2, var6, true);
//     org.jfree.chart.urls.CategoryURLGenerator var10 = null;
//     var2.setSeriesURLGenerator(10, var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var2.drawOutline(var12, var13, var14);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var4.setBaseStroke(var10);
//     var1.setMinorTickMarkStroke(var10);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
//     var1.setRangeWithMargins((org.jfree.data.Range)var13);
//     var1.setTickMarkInsideLength((-1.0f));
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var25 = var21.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     var21.setBaseStroke(var27);
//     var18.setMinorTickMarkStroke(var27);
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     org.jfree.data.xy.XYSeries var32 = null;
//     org.jfree.data.xy.XYSeriesCollection var33 = new org.jfree.data.xy.XYSeriesCollection(var32);
//     boolean var34 = var31.hasListener((java.util.EventListener)var33);
//     boolean var35 = var18.equals((java.lang.Object)var34);
//     java.lang.Class var36 = var18.getMinorTickTimePeriodClass();
//     var1.setMinorTickTimePeriodClass(var36);
//     
//     // Checks the contract:  equals-hashcode on var9 and var26
//     assertTrue("Contract failed: equals-hashcode on var9 and var26", var9.equals(var26) ? var9.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var9
//     assertTrue("Contract failed: equals-hashcode on var26 and var9", var26.equals(var9) ? var26.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
//     var7.setForegroundAlpha(100.0f);
//     var7.setAngleGridlinesVisible(true);
//     java.awt.Paint var12 = var7.getBackgroundPaint();
//     var7.setAngleGridlinesVisible(false);
//     var7.zoom(0.5d);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.data.general.PieDataset var10 = var0.getDataset();
    boolean var11 = var0.getSimpleLabels();
    double var12 = var0.getDepthFactor();
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.lang.String var15 = var14.getID();
    org.jfree.chart.util.RectangleInsets var16 = var14.getPadding();
    double var18 = var16.extendWidth(10.0d);
    var13.setItemLabelPadding(var16);
    org.jfree.chart.block.BlockContainer var20 = null;
    var13.setWrapper(var20);
    org.jfree.chart.util.RectangleInsets var22 = var13.getLegendItemGraphicPadding();
    double var24 = var22.calculateBottomOutset(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     var1.setLabelPaint(var9);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var13.setBaseStroke(var19);
//     var1.setLabelOutlineStroke(var19);
//     double var22 = var1.getInteriorGap();
//     java.awt.Paint var23 = var1.getLabelShadowPaint();
//     java.awt.Font var24 = var1.getLabelFont();
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = var26.getRenderer(0);
//     java.awt.Paint var29 = var26.getDomainCrosshairPaint();
//     java.awt.Paint var30 = var26.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var31 = var26.getDomainAxisLocation();
//     java.awt.Paint var32 = var26.getDomainZeroBaselinePaint();
//     var25.setRangeTickBandPaint(var32);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("Pie 3D Plot", var24, var32, 0.0f);
//     org.jfree.chart.plot.PiePlot3D var36 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var37 = var36.getBaseSectionOutlineStroke();
//     var36.clearSectionOutlinePaints(false);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder();
//     boolean var41 = var36.equals((java.lang.Object)var40);
//     java.awt.Paint var42 = var36.getBaseSectionOutlinePaint();
//     boolean var43 = var35.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var18 and var36
//     assertTrue("Contract failed: equals-hashcode on var18 and var36", var18.equals(var36) ? var18.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var18
//     assertTrue("Contract failed: equals-hashcode on var36 and var18", var36.equals(var18) ? var36.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.5d, (-1.88d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var7 = null;
//     org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
//     org.jfree.data.xy.XYSeries var9 = null;
//     org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
//     boolean var11 = var8.hasListener((java.util.EventListener)var10);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
//     java.awt.Paint var15 = var14.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
//     java.lang.String var17 = var16.getDescription();
//     java.lang.String var18 = var16.getToolTipText();
//     var16.setSeriesIndex(1);
//     org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     var21.clearSectionOutlinePaints(false);
//     double var25 = var21.getMaximumLabelWidth();
//     java.awt.Paint var26 = var21.getBaseSectionOutlinePaint();
//     var16.setLinePaint(var26);
//     
//     // Checks the contract:  equals-hashcode on var5 and var21
//     assertTrue("Contract failed: equals-hashcode on var5 and var21", var5.equals(var21) ? var5.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var5
//     assertTrue("Contract failed: equals-hashcode on var21 and var5", var21.equals(var5) ? var21.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getRangeGridlineStroke();
//     java.awt.Paint var2 = var0.getDomainTickBandPaint();
//     java.util.List var4 = null;
//     var0.mapDatasetToRangeAxes(2, var4);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("DomainOrder.NONE");

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = null;
//     var0.setChartArea(var1);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var3 = var2.getDefaultEntityRadius();
//     java.awt.Shape var5 = var2.getSeriesShape(1);
//     org.jfree.chart.LegendItemCollection var6 = var2.getLegendItems();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var9 = var8.getRangeGridlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var12 = var11.getShadowsVisible();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     var19.setBaseStroke(var25);
//     var16.setMinorTickMarkStroke(var25);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var30 = var29.getOutlineStroke();
//     java.awt.geom.Rectangle2D var31 = null;
//     var11.drawRangeMarker(var13, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.plot.Marker)var29, var31);
//     org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var41 = var37.getItemFillPaint(1, (-1), false);
//     var33.setLabelPaint(var41);
//     org.jfree.data.general.PieDataset var43 = var33.getDataset();
//     var33.setAutoPopulateSectionOutlinePaint(false);
//     float var46 = var33.getBackgroundImageAlpha();
//     java.awt.Paint var47 = var33.getNoDataMessagePaint();
//     var29.setPaint(var47);
//     org.jfree.chart.util.Layer var49 = null;
//     boolean var50 = var8.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var29, var49);
//     org.jfree.chart.axis.PeriodAxis var52 = new org.jfree.chart.axis.PeriodAxis("Pie 3D Plot");
//     java.awt.geom.Rectangle2D var53 = null;
//     java.awt.Color var58 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     java.awt.Color var59 = var58.darker();
//     java.awt.Color var60 = var59.darker();
//     java.awt.Color var61 = var60.darker();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var64 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     boolean var65 = var64.getAutoPopulateSeriesOutlinePaint();
//     boolean var66 = var64.getDrawOutlines();
//     boolean var67 = var64.getAutoPopulateSeriesOutlineStroke();
//     var64.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
//     java.awt.Stroke var72 = var64.lookupSeriesOutlineStroke(100);
//     var2.drawDomainLine(var7, (org.jfree.chart.plot.XYPlot)var8, (org.jfree.chart.axis.ValueAxis)var52, var53, 0.2d, (java.awt.Paint)var60, var72);
//     
//     // Checks the contract:  equals-hashcode on var2 and var64
//     assertTrue("Contract failed: equals-hashcode on var2 and var64", var2.equals(var64) ? var2.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var64
//     assertTrue("Contract failed: equals-hashcode on var37 and var64", var37.equals(var64) ? var37.hashCode() == var64.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var64.", var2.equals(var64) == var64.equals(var2));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var37 and var64.", var37.equals(var64) == var64.equals(var37));
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var3, 10, 3.0d, Double.POSITIVE_INFINITY);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    boolean var3 = var1.equals((java.lang.Object)(short)(-1));
    java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var1.getX(1969, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + Double.NaN+ "'", var4.equals(Double.NaN));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getStartY(10, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    org.jfree.chart.plot.XYPlot var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.remove(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var1.getStartYValue(1969, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.axis.TickUnit var9 = var8.getAngleTickUnit();
    java.awt.Paint var10 = var8.getRadiusGridlinePaint();
    org.jfree.chart.LegendItemCollection var11 = var8.getLegendItems();
    var0.setFixedLegendItems(var11);
    java.awt.Stroke var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlineStroke(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     java.text.NumberFormat var0 = java.text.NumberFormat.getCurrencyInstance();
//     java.lang.String var2 = var0.format(0L);
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.data.general.DatasetGroup var4 = var3.getDatasetGroup();
//     java.awt.Paint var5 = var3.getLabelBackgroundPaint();
//     java.lang.StringBuffer var6 = null;
//     java.text.FieldPosition var7 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.StringBuffer var8 = var0.format((java.lang.Object)var5, var6, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "$0.00"+ "'", var2.equals("$0.00"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
//     var2.setSeriesOutlineStroke(0, var5, true);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var9.clearSectionOutlinePaints(false);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     java.awt.Stroke var15 = var9.getBaseSectionOutlineStroke();
//     var2.setSeriesStroke(3, var15, false);
//     
//     // Checks the contract:  equals-hashcode on var4 and var9
//     assertTrue("Contract failed: equals-hashcode on var4 and var9", var4.equals(var9) ? var4.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var4
//     assertTrue("Contract failed: equals-hashcode on var9 and var4", var9.equals(var4) ? var9.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, 2.0f);
    org.jfree.chart.axis.Axis var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var5 = new org.jfree.chart.entity.AxisEntity(var2, var3, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var0);
    org.jfree.chart.util.SortOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.sortByKeys(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.chart.util.SortOrder var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.sortByKeys(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var8.removeCornerTextItem("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
    var2.setBaseStroke(var8);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = var2.getBaseItemLabelGenerator();
    boolean var12 = var2.equals((java.lang.Object)(short)100);
    boolean var13 = var2.getBaseCreateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    boolean var2 = var1.getExpandToFitSpace();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var5 = var1.arrange(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Font var7 = null;
    var2.setSeriesItemLabelFont(3, var7, true);
    java.awt.Color var13 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var14 = var13.darker();
    var2.setBaseOutlinePaint((java.awt.Paint)var14);
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var17 = var16.getFont();
    var2.setBaseLegendTextFont(var17);
    java.awt.Paint var20 = var2.lookupLegendTextPaint(3);
    boolean var23 = var2.getItemShapeFilled(2, 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var1 = var0.getAdjustForDaylightSaving();
    org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(1);
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
    java.util.Date var7 = var6.getStart();
    org.jfree.data.time.DateRange var8 = new org.jfree.data.time.DateRange(var4, var7);
    long var9 = var0.toTimelineValue(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-17478676800000L));

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.resizeRange2(100.0d, 4.0d);
//     var0.setRangeAboutValue(0.08d, 4.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = var7.getRenderer(0);
//     java.util.List var10 = var7.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var19 = var15.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var15.setBaseStroke(var21);
//     var12.setMinorTickMarkStroke(var21);
//     var12.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var26 = var12.getLocale();
//     var12.setPositiveArrowVisible(false);
//     double var29 = var12.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var12};
//     var7.setDomainAxes(var30);
//     org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge(0);
//     boolean var34 = var7.isRangeZoomable();
//     boolean var35 = var0.equals((java.lang.Object)var7);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.axis.AxisState var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = var39.getRenderer(0);
//     java.util.List var42 = var39.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var44 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var51 = var47.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var53 = var52.getBaseSectionOutlineStroke();
//     var47.setBaseStroke(var53);
//     var44.setMinorTickMarkStroke(var53);
//     var44.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var58 = var44.getLocale();
//     var44.setPositiveArrowVisible(false);
//     double var61 = var44.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var62 = new org.jfree.chart.axis.ValueAxis[] { var44};
//     var39.setDomainAxes(var62);
//     org.jfree.chart.util.RectangleEdge var65 = var39.getRangeAxisEdge(0);
//     java.util.List var66 = var0.refreshTicks(var36, var37, var38, var65);
// 
//   }

//  public void test262() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var19 = var5.getLocale();
//     var5.setPositiveArrowVisible(false);
//     double var22 = var5.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
//     var0.setDomainAxes(var23);
//     var0.clearAnnotations();
//     org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine();
//     org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = var27.getRenderer(0);
//     java.util.List var30 = var27.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var32 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var39 = var35.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     var35.setBaseStroke(var41);
//     var32.setMinorTickMarkStroke(var41);
//     var32.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var46 = var32.getLocale();
//     var32.setPositiveArrowVisible(false);
//     double var49 = var32.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var50 = new org.jfree.chart.axis.ValueAxis[] { var32};
//     var27.setDomainAxes(var50);
//     boolean var52 = var26.equals((java.lang.Object)var50);
//     var0.setRangeAxes(var50);
//     
//     // Checks the contract:  equals-hashcode on var13 and var40
//     assertTrue("Contract failed: equals-hashcode on var13 and var40", var13.equals(var40) ? var13.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var13
//     assertTrue("Contract failed: equals-hashcode on var40 and var13", var40.equals(var13) ? var40.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    boolean var11 = var8.hasListener((java.util.EventListener)var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
    java.awt.Paint var15 = var14.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
    java.lang.String var17 = var16.getDescription();
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
    boolean var19 = var16.equals((java.lang.Object)var18);
    org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var22 = var21.getItemCount();
    org.jfree.data.time.Year var24 = new org.jfree.data.time.Year(1);
    java.util.Date var25 = var24.getStart();
    var21.add((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var29 = null;
    org.jfree.data.xy.XYSeriesCollection var30 = new org.jfree.data.xy.XYSeriesCollection(var29);
    org.jfree.data.xy.XYSeries var31 = null;
    org.jfree.data.xy.XYSeriesCollection var32 = new org.jfree.data.xy.XYSeriesCollection(var31);
    boolean var33 = var30.hasListener((java.util.EventListener)var32);
    double var34 = var32.getIntervalPositionFactor();
    var21.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var32);
    var16.setDataset((org.jfree.data.general.Dataset)var32);
    org.jfree.chart.util.GradientPaintTransformer var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setFillPaintTransformer(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Pie 3D Plot"+ "'", var17.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.5d);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
    var2.setBaseStroke(var8);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = var2.getBaseItemLabelGenerator();
    java.awt.Paint var12 = var2.lookupLegendTextPaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, 2.0f);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, Double.NaN, 1.0f, 10.0f);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    double var5 = var3.getIntervalPositionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var3.getYValue(1, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.Range var2 = var1.getRange();
//     boolean var3 = var1.isMinorTickMarksVisible();
//     org.jfree.data.Range var4 = null;
//     var1.setRange(var4);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    org.jfree.data.xy.XYSeries var11 = null;
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
    boolean var13 = var10.hasListener((java.util.EventListener)var12);
    double var14 = var12.getIntervalPositionFactor();
    var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var12);
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var18 = var17.getItemCount();
    org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(1);
    java.util.Date var21 = var20.getStart();
    var17.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)Double.NaN, true);
    org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 12.0d);
    java.lang.Number var27 = var1.getValue((org.jfree.data.time.RegularTimePeriod)var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var29 = var1.getTimePeriod((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + Double.NaN+ "'", var27.equals(Double.NaN));

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = var2.getRenderer(0);
//     java.awt.Paint var5 = var2.getDomainCrosshairPaint();
//     java.awt.Paint var6 = var2.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var8 = var7.getOpposite();
//     var0.setRangeAxisLocation(100, var8, false);
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var12.getRenderer(0);
//     java.awt.Paint var15 = var12.getDomainCrosshairPaint();
//     java.awt.Paint var16 = var12.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var17 = var12.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var18 = var17.getOpposite();
//     var0.setRangeAxisLocation(2, var18);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("$0.00", "DomainOrder.NONE", "");
//     java.awt.Shape var8 = null;
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var11 = null;
//     org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     boolean var15 = var12.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
//     java.awt.Paint var19 = var18.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var8, var10, var19);
//     java.lang.String var21 = var20.getDescription();
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     boolean var23 = var20.equals((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var26 = var25.getItemCount();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year(1);
//     java.util.Date var29 = var28.getStart();
//     var25.add((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var33 = null;
//     org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
//     org.jfree.data.xy.XYSeries var35 = null;
//     org.jfree.data.xy.XYSeriesCollection var36 = new org.jfree.data.xy.XYSeriesCollection(var35);
//     boolean var37 = var34.hasListener((java.util.EventListener)var36);
//     double var38 = var36.getIntervalPositionFactor();
//     var25.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var36);
//     var20.setDataset((org.jfree.data.general.Dataset)var36);
//     java.lang.String var43 = var3.generateURL((org.jfree.data.xy.XYDataset)var36, 100, (-16777216));
//     org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
//     var44.clearSectionOutlinePaints(false);
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder();
//     boolean var49 = var44.equals((java.lang.Object)var48);
//     java.awt.Stroke var50 = var44.getBaseSectionOutlineStroke();
//     boolean var51 = var36.hasListener((java.util.EventListener)var44);
//     
//     // Checks the contract:  equals-hashcode on var9 and var44
//     assertTrue("Contract failed: equals-hashcode on var9 and var44", var9.equals(var44) ? var9.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var9
//     assertTrue("Contract failed: equals-hashcode on var44 and var9", var44.equals(var9) ? var44.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.time.TimePeriodAnchor var4 = var1.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSelected(68, 100, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.resizeRange2(100.0d, 4.0d);
    org.jfree.data.RangeType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getRangeGridlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var4 = var3.getShadowsVisible();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var15 = var11.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
//     var11.setBaseStroke(var17);
//     var8.setMinorTickMarkStroke(var17);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var22 = var21.getOutlineStroke();
//     java.awt.geom.Rectangle2D var23 = null;
//     var3.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.plot.Marker)var21, var23);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var33 = var29.getItemFillPaint(1, (-1), false);
//     var25.setLabelPaint(var33);
//     org.jfree.data.general.PieDataset var35 = var25.getDataset();
//     var25.setAutoPopulateSectionOutlinePaint(false);
//     float var38 = var25.getBackgroundImageAlpha();
//     java.awt.Paint var39 = var25.getNoDataMessagePaint();
//     var21.setPaint(var39);
//     org.jfree.chart.util.Layer var41 = null;
//     boolean var42 = var0.removeRangeMarker(0, (org.jfree.chart.plot.Marker)var21, var41);
//     org.jfree.chart.plot.CombinedDomainXYPlot var43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = var43.getRenderer(0);
//     java.awt.Paint var46 = var43.getDomainCrosshairPaint();
//     java.awt.Paint var47 = var43.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var48 = var43.getDomainAxisLocation();
//     var0.setRangeAxisLocation(var48);
//     
//     // Checks the contract:  equals-hashcode on var0 and var43
//     assertTrue("Contract failed: equals-hashcode on var0 and var43", var0.equals(var43) ? var0.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var0
//     assertTrue("Contract failed: equals-hashcode on var43 and var0", var43.equals(var0) ? var43.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getEndY(3, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    var0.validateObject();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var0);
    double[] var4 = null;
    double[][] var5 = new double[][] { var4};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addSeries((java.lang.Comparable)"$0.00?DomainOrder.NONE=100&amp;=-16777216", var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    java.awt.Font var8 = var2.getSeriesItemLabelFont(1);
    java.awt.Paint var10 = var2.lookupSeriesOutlinePaint((-1));
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseFillPaint(var11, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (-1.0f));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 12.0d, 0.5f, 0.0f);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getRangeGridlineStroke();
    boolean var2 = var0.canSelectByPoint();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.data.xy.XYSeries var4 = null;
    org.jfree.data.xy.XYSeriesCollection var5 = new org.jfree.data.xy.XYSeriesCollection(var4);
    org.jfree.data.xy.XYSeries var6 = null;
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
    boolean var8 = var5.hasListener((java.util.EventListener)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var5, var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleAnchor var16 = null;
    java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
    var11.zoomDomainAxes(100.0d, (-1.0d), var14, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var19 = var0.findSubplot(var3, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
//     java.lang.String var3 = var2.toString();
//     var1.setRangeWithMargins((org.jfree.data.Range)var2);
//     java.util.Date var5 = var2.getLowerDate();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     int var7 = var6.getYearValue();
//     java.util.Calendar var8 = null;
//     var6.peg(var8);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     var1.setLabelPaint(var9);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var13.setBaseStroke(var19);
//     var1.setLabelOutlineStroke(var19);
//     double var22 = var1.getInteriorGap();
//     java.awt.Paint var23 = var1.getLabelShadowPaint();
//     java.awt.Font var24 = var1.getLabelFont();
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     java.awt.Paint var27 = var25.getLabelBackgroundPaint();
//     org.jfree.data.general.PieDataset var28 = var25.getDataset();
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     java.awt.Paint var31 = var30.getMinorTickMarkPaint();
//     var25.setOutlinePaint(var31);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.text.G2TextMeasurer var36 = new org.jfree.chart.text.G2TextMeasurer(var35);
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=0]", var24, var31, 2.0f, 1, (org.jfree.chart.text.TextMeasurer)var36);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("$0.00", "DomainOrder.NONE", "");
//     org.jfree.data.xy.XYSeries var4 = null;
//     org.jfree.data.xy.XYSeriesCollection var5 = new org.jfree.data.xy.XYSeriesCollection(var4);
//     org.jfree.data.xy.XYSeries var6 = null;
//     org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
//     boolean var8 = var5.hasListener((java.util.EventListener)var7);
//     double var10 = var7.getDomainUpperBound(true);
//     boolean var11 = var7.isAutoWidth();
//     java.lang.String var14 = var3.generateURL((org.jfree.data.xy.XYDataset)var7, 3, 2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var7.getEndYValue(1969, 0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "$0.00?DomainOrder.NONE=3&amp;=2"+ "'", var14.equals("$0.00?DomainOrder.NONE=3&amp;=2"));
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = var1.getRenderer(0);
    java.awt.Paint var4 = var1.getDomainCrosshairPaint();
    java.awt.Paint var5 = var1.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var6 = var1.getDomainAxisLocation();
    java.awt.Paint var7 = var1.getDomainZeroBaselinePaint();
    var0.setRangeTickBandPaint(var7);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var13 = var12.getShadowsVisible();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = null;
    org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var24 = var20.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
    var20.setBaseStroke(var26);
    var17.setMinorTickMarkStroke(var26);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var31 = var30.getOutlineStroke();
    java.awt.geom.Rectangle2D var32 = null;
    var12.drawRangeMarker(var14, var15, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.plot.Marker)var30, var32);
    org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var42 = var38.getItemFillPaint(1, (-1), false);
    var34.setLabelPaint(var42);
    org.jfree.data.general.PieDataset var44 = var34.getDataset();
    var34.setAutoPopulateSectionOutlinePaint(false);
    float var47 = var34.getBackgroundImageAlpha();
    java.awt.Paint var48 = var34.getNoDataMessagePaint();
    var30.setPaint(var48);
    org.jfree.chart.util.Layer var50 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var30, var50, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var6 = var5.getOpposite();
    org.jfree.chart.plot.PlotOrientation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var5, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var4 = var3.getItemCount();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
//     java.util.Date var7 = var6.getStart();
//     var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)Double.NaN, true);
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var6);
//     java.lang.Comparable[] var12 = new java.lang.Comparable[] { var6};
//     java.lang.Comparable[] var14 = new java.lang.Comparable[] { '4'};
//     double[] var15 = null;
//     double[][] var16 = new double[][] { var15};
//     org.jfree.data.category.CategoryDataset var17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var12, var14, var16);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, 2.0f);
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var11 = var7.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     var7.setBaseStroke(var13);
//     var4.setMinorTickMarkStroke(var13);
//     org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
//     var4.setRangeWithMargins((org.jfree.data.Range)var16);
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var4.java2DToValue(0.08d, var19, var20);
//     org.jfree.chart.entity.AxisEntity var22 = new org.jfree.chart.entity.AxisEntity(var2, (org.jfree.chart.axis.Axis)var4);
//     java.awt.Shape var27 = null;
//     org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var29 = var28.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     org.jfree.data.xy.XYSeries var32 = null;
//     org.jfree.data.xy.XYSeriesCollection var33 = new org.jfree.data.xy.XYSeriesCollection(var32);
//     boolean var34 = var31.hasListener((java.util.EventListener)var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var36 = null;
//     org.jfree.chart.plot.PolarPlot var37 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var31, var35, var36);
//     java.awt.Paint var38 = var37.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var27, var29, var38);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.String var41 = var39.getToolTipText();
//     var39.setSeriesIndex(1);
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     var39.setLine(var45);
//     boolean var47 = var22.equals((java.lang.Object)var45);
//     
//     // Checks the contract:  equals-hashcode on var12 and var28
//     assertTrue("Contract failed: equals-hashcode on var12 and var28", var12.equals(var28) ? var12.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var12
//     assertTrue("Contract failed: equals-hashcode on var28 and var12", var28.equals(var12) ? var28.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, 2.0f);
    org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var11 = var7.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
    var7.setBaseStroke(var13);
    var4.setMinorTickMarkStroke(var13);
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
    var4.setRangeWithMargins((org.jfree.data.Range)var16);
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var4.java2DToValue(0.08d, var19, var20);
    org.jfree.chart.entity.AxisEntity var22 = new org.jfree.chart.entity.AxisEntity(var2, (org.jfree.chart.axis.Axis)var4);
    org.jfree.chart.plot.Plot var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var26 = new org.jfree.chart.entity.PlotEntity(var2, var23, "", "$0.00?DomainOrder.NONE=100&amp;=-16777216");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == Double.POSITIVE_INFINITY);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var7 = null;
//     org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
//     org.jfree.data.xy.XYSeries var9 = null;
//     org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
//     boolean var11 = var8.hasListener((java.util.EventListener)var10);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
//     java.awt.Paint var15 = var14.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
//     java.lang.String var17 = var16.getDescription();
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     boolean var19 = var16.equals((java.lang.Object)var18);
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var22 = var21.getItemCount();
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year(1);
//     java.util.Date var25 = var24.getStart();
//     var21.add((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var29 = null;
//     org.jfree.data.xy.XYSeriesCollection var30 = new org.jfree.data.xy.XYSeriesCollection(var29);
//     org.jfree.data.xy.XYSeries var31 = null;
//     org.jfree.data.xy.XYSeriesCollection var32 = new org.jfree.data.xy.XYSeriesCollection(var31);
//     boolean var33 = var30.hasListener((java.util.EventListener)var32);
//     double var34 = var32.getIntervalPositionFactor();
//     var21.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var32);
//     var16.setDataset((org.jfree.data.general.Dataset)var32);
//     var16.setDescription("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Shape var43 = null;
//     org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var46 = null;
//     org.jfree.data.xy.XYSeriesCollection var47 = new org.jfree.data.xy.XYSeriesCollection(var46);
//     org.jfree.data.xy.XYSeries var48 = null;
//     org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
//     boolean var50 = var47.hasListener((java.util.EventListener)var49);
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var52 = null;
//     org.jfree.chart.plot.PolarPlot var53 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var47, var51, var52);
//     java.awt.Paint var54 = var53.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var43, var45, var54);
//     java.lang.String var56 = var55.getDescription();
//     java.lang.String var57 = var55.getToolTipText();
//     var55.setSeriesIndex(1);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     var55.setLine(var61);
//     var16.setLine(var61);
//     
//     // Checks the contract:  equals-hashcode on var5 and var44
//     assertTrue("Contract failed: equals-hashcode on var5 and var44", var5.equals(var44) ? var5.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var5
//     assertTrue("Contract failed: equals-hashcode on var44 and var5", var44.equals(var5) ? var44.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var53
//     assertTrue("Contract failed: equals-hashcode on var14 and var53", var14.equals(var53) ? var14.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var14
//     assertTrue("Contract failed: equals-hashcode on var53 and var14", var53.equals(var14) ? var53.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 1.0d, Double.NaN);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = null;
//     org.jfree.chart.util.Size2D var8 = var5.arrange(var6, var7);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.data.general.PieDataset var10 = var0.getDataset();
    boolean var11 = var0.getSimpleLabels();
    double var12 = var0.getDepthFactor();
    org.jfree.chart.urls.PieURLGenerator var13 = var0.getLegendLabelURLGenerator();
    java.awt.Color var17 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var0.setLabelOutlinePaint((java.awt.Paint)var18);
    var0.setAutoPopulateSectionOutlinePaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var2 = var1.getItemCount();
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var4 = var3.previous();
//     var1.add((org.jfree.data.time.RegularTimePeriod)var3, 0.12d, false);
//     java.util.Calendar var8 = null;
//     long var9 = var3.getMiddleMillisecond(var8);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.clear();
    org.jfree.chart.axis.SegmentedTimeline var2 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    boolean var3 = var2.getAdjustForDaylightSaving();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(1);
    java.util.Date var6 = var5.getStart();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(1);
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.DateRange var10 = new org.jfree.data.time.DateRange(var6, var9);
    long var11 = var2.toTimelineValue(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)var6);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-17478676800000L));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    boolean var11 = var8.hasListener((java.util.EventListener)var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
    java.awt.Paint var15 = var14.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    java.awt.Paint var19 = var18.getMinorTickMarkPaint();
    var16.setLinePaint(var19);
    java.lang.Comparable var21 = var16.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     var1.setLabelPaint(var9);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var13.setBaseStroke(var19);
//     var1.setLabelOutlineStroke(var19);
//     double var22 = var1.getInteriorGap();
//     java.awt.Paint var23 = var1.getLabelShadowPaint();
//     java.awt.Font var24 = var1.getLabelFont();
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = var26.getRenderer(0);
//     java.awt.Paint var29 = var26.getDomainCrosshairPaint();
//     java.awt.Paint var30 = var26.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var31 = var26.getDomainAxisLocation();
//     java.awt.Paint var32 = var26.getDomainZeroBaselinePaint();
//     var25.setRangeTickBandPaint(var32);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("Pie 3D Plot", var24, var32, 0.0f);
//     java.lang.String var36 = var35.getText();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.text.TextAnchor var38 = null;
//     float var39 = var35.calculateBaselineOffset(var37, var38);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Paint var4 = var2.getLabelBackgroundPaint();
//     org.jfree.chart.entity.PlotEntity var7 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var2, "Pie 3D Plot", "[-1.0, 0.0]");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var8 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var9 = null;
//     java.lang.String var10 = var7.getImageMapAreaTag(var8, var9);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0, false);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var1 = var0.getRangeGridlineStroke();
    java.awt.Paint var2 = var0.getDomainTickBandPaint();
    var0.mapDatasetToDomainAxis(255, 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var19 = var5.getLocale();
//     var5.setPositiveArrowVisible(false);
//     double var22 = var5.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
//     var0.setDomainAxes(var23);
//     org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
//     boolean var27 = var0.isRangeZoomable();
//     var0.mapDatasetToDomainAxis(100, 0);
//     org.jfree.chart.axis.PeriodAxis var32 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var39 = var35.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     var35.setBaseStroke(var41);
//     var32.setMinorTickMarkStroke(var41);
//     org.jfree.data.time.DateRange var44 = new org.jfree.data.time.DateRange();
//     var32.setRangeWithMargins((org.jfree.data.Range)var44);
//     var32.setTickMarkInsideLength((-1.0f));
//     java.awt.Paint var48 = var32.getLabelPaint();
//     var0.setDomainAxis((org.jfree.chart.axis.ValueAxis)var32);
//     
//     // Checks the contract:  equals-hashcode on var13 and var40
//     assertTrue("Contract failed: equals-hashcode on var13 and var40", var13.equals(var40) ? var13.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var13
//     assertTrue("Contract failed: equals-hashcode on var40 and var13", var40.equals(var13) ? var40.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = var2.getRenderer(0);
//     java.awt.Paint var5 = var2.getDomainCrosshairPaint();
//     java.awt.Paint var6 = var2.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var7 = var2.getDomainAxisLocation();
//     org.jfree.chart.axis.AxisLocation var8 = var7.getOpposite();
//     var0.setDomainAxisLocation(2, var7, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var0.", var2.equals(var0) == var0.equals(var2));
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.getStartXValue(10, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     boolean var1 = var0.getAdjustForDaylightSaving();
//     long var2 = var0.getSegmentsGroupSize();
//     org.jfree.chart.axis.PeriodAxis var4 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange();
//     java.lang.String var6 = var5.toString();
//     var4.setRangeWithMargins((org.jfree.data.Range)var5);
//     java.util.Date var8 = var5.getLowerDate();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var8);
//     long var10 = var0.toTimelineValue(var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       boolean var13 = var0.containsDomainRange(644288400000L, 0L);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 86400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var6.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 644288400000L);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var19 = var5.getLocale();
//     var5.setPositiveArrowVisible(false);
//     double var22 = var5.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
//     var0.setDomainAxes(var23);
//     org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
//     boolean var27 = var0.isRangeZoomable();
//     var0.clearDomainAxes();
//     var0.setDomainCrosshairValue(0.2d, true);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     var0.setDomainAxis(10, var33);
//     org.jfree.chart.plot.Marker var36 = null;
//     org.jfree.chart.util.Layer var37 = null;
//     var0.addRangeMarker(0, var36, var37);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    var2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var6);
    var2.setBaseShapesVisible(false);
    org.jfree.chart.LegendItemCollection var10 = var2.getLegendItems();
    org.jfree.chart.labels.XYToolTipGenerator var12 = var2.getSeriesToolTipGenerator(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    var5.setBaseStroke(var11);
    var2.setMinorTickMarkStroke(var11);
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    org.jfree.data.xy.XYSeries var16 = null;
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection(var16);
    boolean var18 = var15.hasListener((java.util.EventListener)var17);
    boolean var19 = var2.equals((java.lang.Object)var18);
    java.lang.Class var20 = var2.getMinorTickTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var21 = new org.jfree.chart.entity.AxisEntity(var0, (org.jfree.chart.axis.Axis)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var5 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var6 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var5, var6);
    var3.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var7, false);
    var0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var7);
    int var11 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimeSeries var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var2);
    org.jfree.data.time.TimePeriodAnchor var4 = var3.getXPosition();
    var1.setXPosition(var4);
    var1.removeAllSeries();
    
    // Checks the contract:  equals-hashcode on var1 and var3
    assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
    
    // Checks the contract:  equals-hashcode on var3 and var1
    assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    java.awt.Shape var8 = null;
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var11 = null;
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    boolean var15 = var12.hasListener((java.util.EventListener)var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.PolarItemRenderer var17 = null;
    org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
    java.awt.Paint var19 = var18.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var8, var10, var19);
    java.lang.String var21 = var20.getDescription();
    java.lang.String var22 = var20.getToolTipText();
    var20.setSeriesIndex(1);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    var20.setLine(var26);
    java.lang.StringBuffer var28 = null;
    java.text.FieldPosition var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.StringBuffer var30 = var1.format((java.lang.Object)var26, var28, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Pie 3D Plot"+ "'", var21.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + ""+ "'", var22.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange();
//     java.lang.String var3 = var2.toString();
//     var1.setRangeWithMargins((org.jfree.data.Range)var2);
//     java.util.Date var5 = var2.getLowerDate();
//     boolean var8 = var2.intersects(0.5d, 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    var0.setFixedRangeAxisSpace(var4, false);
    java.util.List var7 = var0.getSubplots();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var11 = var10.getLabelAnchor();
    org.jfree.chart.util.Layer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var10, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, 1969, var2);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    var2.setBaseLegendTextPaint(var12);
    org.jfree.chart.labels.XYItemLabelGenerator var15 = null;
    var2.setSeriesItemLabelGenerator(3, var15, false);
    java.awt.Font var19 = var2.getSeriesItemLabelFont(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var4.setBaseStroke(var10);
//     var1.setMinorTickMarkStroke(var10);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange();
//     var1.setRangeWithMargins((org.jfree.data.Range)var13);
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var1.java2DToValue(0.08d, var16, var17);
//     org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = var19.getRenderer(0);
//     java.util.List var22 = var19.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     var27.setBaseStroke(var33);
//     var24.setMinorTickMarkStroke(var33);
//     var24.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var38 = var24.getLocale();
//     var24.setPositiveArrowVisible(false);
//     double var41 = var24.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var24};
//     var19.setDomainAxes(var42);
//     org.jfree.chart.plot.CombinedDomainXYPlot var44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = var44.getRenderer(0);
//     java.util.List var47 = var44.getSubplots();
//     org.jfree.chart.axis.AxisSpace var48 = new org.jfree.chart.axis.AxisSpace();
//     var44.setFixedRangeAxisSpace(var48, false);
//     var19.setFixedRangeAxisSpace(var48);
//     boolean var52 = var1.equals((java.lang.Object)var48);
//     
//     // Checks the contract:  equals-hashcode on var9 and var32
//     assertTrue("Contract failed: equals-hashcode on var9 and var32", var9.equals(var32) ? var9.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var9
//     assertTrue("Contract failed: equals-hashcode on var32 and var9", var32.equals(var9) ? var32.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.data.general.PieDataset var10 = var0.getDataset();
    boolean var11 = var0.getSimpleLabels();
    double var12 = var0.getDepthFactor();
    org.jfree.chart.urls.PieURLGenerator var13 = var0.getLegendLabelURLGenerator();
    java.awt.Color var17 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var0.setLabelOutlinePaint((java.awt.Paint)var18);
    double var20 = var0.getStartAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 90.0d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var3 = var2.getDefaultEntityRadius();
    java.awt.Shape var5 = var2.getSeriesShape(1);
    org.jfree.chart.LegendItemCollection var6 = var2.getLegendItems();
    org.jfree.chart.plot.DrawingSupplier var7 = var2.getDrawingSupplier();
    var2.setDrawSeriesLineAsPath(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.resizeRange2(100.0d, 4.0d);
//     var0.setRangeAboutValue(0.08d, 4.0d);
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = var7.getRenderer(0);
//     java.util.List var10 = var7.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var19 = var15.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var15.setBaseStroke(var21);
//     var12.setMinorTickMarkStroke(var21);
//     var12.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var26 = var12.getLocale();
//     var12.setPositiveArrowVisible(false);
//     double var29 = var12.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var12};
//     var7.setDomainAxes(var30);
//     org.jfree.chart.util.RectangleEdge var33 = var7.getRangeAxisEdge(0);
//     boolean var34 = var7.isRangeZoomable();
//     boolean var35 = var0.equals((java.lang.Object)var7);
//     org.jfree.chart.plot.PiePlot3D var36 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var37 = var36.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var44 = var40.getItemFillPaint(1, (-1), false);
//     var36.setLabelPaint(var44);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var52 = var48.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var53 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var54 = var53.getBaseSectionOutlineStroke();
//     var48.setBaseStroke(var54);
//     var36.setLabelOutlineStroke(var54);
//     double var57 = var36.getInteriorGap();
//     java.awt.Paint var58 = var36.getLabelShadowPaint();
//     java.awt.Font var59 = var36.getLabelFont();
//     var7.setNoDataMessageFont(var59);
//     
//     // Checks the contract:  equals-hashcode on var20 and var53
//     assertTrue("Contract failed: equals-hashcode on var20 and var53", var20.equals(var53) ? var20.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var20
//     assertTrue("Contract failed: equals-hashcode on var53 and var20", var53.equals(var20) ? var53.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var4 = var3.getItemCount();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
//     java.util.Date var7 = var6.getStart();
//     var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)Double.NaN, true);
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var6);
//     long var12 = var6.getSerialIndex();
//     java.util.Calendar var13 = null;
//     long var14 = var6.getLastMillisecond(var13);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
    var1.setLabelPaint(var9);
    org.jfree.data.general.PieDataset var11 = var1.getDataset();
    boolean var12 = var1.getSimpleLabels();
    double var13 = var1.getDepthFactor();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1);
    java.lang.Object var15 = var14.clone();
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle();
    boolean var18 = var16.equals((java.lang.Object)1.0f);
    org.jfree.chart.util.VerticalAlignment var19 = var16.getVerticalAlignment();
    var14.setVerticalAlignment(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var21 = new org.jfree.chart.entity.TitleEntity(var0, (org.jfree.chart.title.Title)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getID();
//     org.jfree.chart.util.RectangleInsets var2 = var0.getPadding();
//     var0.setMaximumLinesToDisplay(1);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.util.Size2D var6 = var0.arrange(var5);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
//     double[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[])var0, (java.lang.Comparable[])var1, var2);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)'#');
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     var2.setBaseSeriesVisible(false, false);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     var2.setBaseLegendTextPaint(var12);
//     org.jfree.chart.labels.XYItemLabelGenerator var15 = null;
//     var2.setSeriesItemLabelGenerator(3, var15, false);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = var19.getRenderer(0);
//     java.util.List var22 = var19.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var24 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     var27.setBaseStroke(var33);
//     var24.setMinorTickMarkStroke(var33);
//     var24.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var38 = var24.getLocale();
//     var24.setPositiveArrowVisible(false);
//     double var41 = var24.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var24};
//     var19.setDomainAxes(var42);
//     org.jfree.chart.util.RectangleEdge var45 = var19.getRangeAxisEdge(0);
//     boolean var46 = var19.isRangeZoomable();
//     var19.clearDomainAxes();
//     var19.setDomainCrosshairValue(0.2d, true);
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     var19.setDomainAxis(10, var52);
//     org.jfree.chart.axis.PeriodAxis var55 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var58 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var62 = var58.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var63 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var64 = var63.getBaseSectionOutlineStroke();
//     var58.setBaseStroke(var64);
//     var55.setMinorTickMarkStroke(var64);
//     var55.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var69 = var55.getLocale();
//     var55.setPositiveArrowVisible(false);
//     double var72 = var55.getAutoRangeMinimumSize();
//     double var73 = var55.getFixedAutoRange();
//     org.jfree.chart.plot.ValueMarker var75 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var76 = var75.getOutlineStroke();
//     java.awt.geom.Rectangle2D var77 = null;
//     var2.drawDomainMarker(var18, (org.jfree.chart.plot.XYPlot)var19, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.chart.plot.Marker)var75, var77);
//     
//     // Checks the contract:  equals-hashcode on var32 and var63
//     assertTrue("Contract failed: equals-hashcode on var32 and var63", var32.equals(var63) ? var32.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var32
//     assertTrue("Contract failed: equals-hashcode on var63 and var32", var63.equals(var32) ? var63.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var3, "hi!", "", "[-1.0, 0.0]");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var13, "hi!", "", "[-1.0, 0.0]");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var17);
    java.lang.String var19 = var17.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var19.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var2 = var0.getValue(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var3 = var2.getDefaultEntityRadius();
    java.awt.Shape var5 = var2.getSeriesShape(1);
    org.jfree.chart.LegendItemCollection var6 = var2.getLegendItems();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var10.setBaseStroke(var16);
    org.jfree.chart.labels.XYItemLabelGenerator var18 = var10.getBaseItemLabelGenerator();
    boolean var20 = var10.equals((java.lang.Object)(short)100);
    java.awt.Paint var24 = var10.getItemOutlinePaint(2, 2, true);
    var2.setSeriesFillPaint(100, var24);
    boolean var26 = var2.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    java.awt.Paint var5 = var0.getNoDataMessagePaint();
    boolean var6 = var0.isRangeGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.data.Range var8 = var0.getDataRange(var7);
    org.jfree.chart.axis.PeriodAxis var11 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var14.setBaseStroke(var20);
    var11.setMinorTickMarkStroke(var20);
    var11.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var25 = var11.getLocale();
    var11.setPositiveArrowVisible(false);
    var0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var11, false);
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = var32.getRenderer(0);
    java.awt.Paint var35 = var32.getDomainCrosshairPaint();
    java.awt.Paint var36 = var32.getRangeMinorGridlinePaint();
    java.awt.Paint var37 = var32.getNoDataMessagePaint();
    boolean var38 = var32.isRangeGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    org.jfree.chart.plot.CrosshairState var41 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var48 = null;
    var41.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var48);
    org.jfree.data.xy.XYSeries var50 = null;
    org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
    org.jfree.data.xy.XYSeries var52 = null;
    org.jfree.data.xy.XYSeriesCollection var53 = new org.jfree.data.xy.XYSeriesCollection(var52);
    boolean var54 = var51.hasListener((java.util.EventListener)var53);
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.PolarItemRenderer var56 = null;
    org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var51, var55, var56);
    org.jfree.chart.plot.PlotRenderingInfo var60 = null;
    java.awt.geom.Rectangle2D var61 = null;
    org.jfree.chart.util.RectangleAnchor var62 = null;
    java.awt.geom.Point2D var63 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var62);
    var57.zoomDomainAxes(100.0d, (-1.0d), var60, var63);
    var41.setAnchor(var63);
    var32.panRangeAxes(10.0d, var40, var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes((-1.88d), var31, var63);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var4 = var3.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var11 = var7.getItemFillPaint(1, (-1), false);
//     var3.setLabelPaint(var11);
//     org.jfree.data.general.PieDataset var13 = var3.getDataset();
//     boolean var14 = var3.getSimpleLabels();
//     double var15 = var3.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var18 = var17.getID();
//     org.jfree.chart.util.RectangleInsets var19 = var17.getPadding();
//     double var21 = var19.extendWidth(10.0d);
//     var16.setItemLabelPadding(var19);
//     org.jfree.chart.block.BlockContainer var23 = null;
//     var16.setWrapper(var23);
//     org.jfree.chart.util.RectangleAnchor var25 = var16.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var26 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, (-1.0d), 0.0d, var25);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
//     var0.setFixedRangeAxisSpace(var4, false);
//     java.util.List var7 = var0.getSubplots();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.CrosshairState var10 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.data.xy.XYSeries var11 = null;
//     org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     boolean var15 = var12.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.util.RectangleAnchor var23 = null;
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
//     var18.zoomDomainAxes(100.0d, (-1.0d), var21, var24);
//     var10.setAnchor(var24);
//     var0.zoomDomainAxes(1.0E-8d, var9, var24, true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var3, "hi!", "", "[-1.0, 0.0]");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var13, "hi!", "", "[-1.0, 0.0]");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var17);
    var7.setInfo("");

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.chart.urls.StandardXYURLGenerator var5 = new org.jfree.chart.urls.StandardXYURLGenerator("$0.00", "DomainOrder.NONE", "");
//     org.jfree.data.xy.XYSeries var6 = null;
//     org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
//     org.jfree.data.xy.XYSeries var8 = null;
//     org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
//     boolean var10 = var7.hasListener((java.util.EventListener)var9);
//     double var12 = var9.getDomainUpperBound(true);
//     boolean var13 = var9.isAutoWidth();
//     java.lang.String var16 = var5.generateURL((org.jfree.data.xy.XYDataset)var9, 3, 2);
//     var1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var20 = var1.getStartY((-1), 255);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "$0.00?DomainOrder.NONE=3&amp;=2"+ "'", var16.equals("$0.00?DomainOrder.NONE=3&amp;=2"));
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    var1.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)"[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    int var9 = var1.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    java.text.NumberFormat var5 = var4.getYFormat();
    boolean var6 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getPositiveItemLabelPositionFallback();
    java.awt.Font var9 = var0.getLegendTextFont(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.AxisState var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var6 = var5.getTickLabelPaint();
//     java.lang.String var7 = var5.getLabel();
//     org.jfree.data.xy.XYDataItem var10 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var11 = var10.getXValue();
//     double var12 = var10.getYValue();
//     java.awt.Paint var13 = var5.getTickLabelPaint((java.lang.Comparable)var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.AxisState var15 = null;
//     org.jfree.data.xy.XYSeries var17 = null;
//     org.jfree.data.xy.XYSeriesCollection var18 = new org.jfree.data.xy.XYSeriesCollection(var17);
//     org.jfree.data.xy.XYSeries var19 = null;
//     org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection(var19);
//     boolean var21 = var18.hasListener((java.util.EventListener)var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var23 = null;
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, var22, var23);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var24);
//     var25.clearSubtitles();
//     java.awt.RenderingHints var27 = var25.getRenderingHints();
//     var25.setBackgroundImageAlpha(10.0f);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.text.NumberFormat var34 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var35 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var36 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var34, var35);
//     var32.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var36, false);
//     org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var40 = var39.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var47 = var43.getItemFillPaint(1, (-1), false);
//     var39.setLabelPaint(var47);
//     org.jfree.data.general.PieDataset var49 = var39.getDataset();
//     boolean var50 = var39.getSimpleLabels();
//     double var51 = var39.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var54 = var53.getID();
//     org.jfree.chart.util.RectangleInsets var55 = var53.getPadding();
//     double var57 = var55.extendWidth(10.0d);
//     var52.setItemLabelPadding(var55);
//     org.jfree.chart.block.BlockContainer var59 = null;
//     var52.setWrapper(var59);
//     boolean var61 = var36.equals((java.lang.Object)var52);
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var63 = var62.clone();
//     org.jfree.chart.util.HorizontalAlignment var64 = var62.getTextAlignment();
//     boolean var66 = var64.equals((java.lang.Object)(-1L));
//     var52.setHorizontalAlignment(var64);
//     var25.addLegend(var52);
//     java.awt.geom.Rectangle2D var69 = var52.getBounds();
//     org.jfree.chart.plot.CombinedDomainXYPlot var70 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = var70.getRenderer(0);
//     java.util.List var73 = var70.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var75 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var78 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var82 = var78.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var83 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var84 = var83.getBaseSectionOutlineStroke();
//     var78.setBaseStroke(var84);
//     var75.setMinorTickMarkStroke(var84);
//     var75.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var89 = var75.getLocale();
//     var75.setPositiveArrowVisible(false);
//     double var92 = var75.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var93 = new org.jfree.chart.axis.ValueAxis[] { var75};
//     var70.setDomainAxes(var93);
//     org.jfree.chart.util.RectangleEdge var96 = var70.getRangeAxisEdge(0);
//     java.util.List var97 = var5.refreshTicks(var14, var15, var69, var96);
//     java.util.List var98 = var1.refreshTicks(var2, var3, var4, var96);
// 
//   }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     org.jfree.data.xy.XYSeries var4 = null;
//     org.jfree.data.xy.XYSeriesCollection var5 = new org.jfree.data.xy.XYSeriesCollection(var4);
//     boolean var6 = var3.hasListener((java.util.EventListener)var5);
//     double var8 = var5.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var11 = var10.getItemCount();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(1);
//     java.util.Date var14 = var13.getStart();
//     var10.add((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var13, true);
//     var5.addSeries(var19);
//     org.jfree.chart.entity.XYItemEntity var25 = new org.jfree.chart.entity.XYItemEntity(var1, (org.jfree.data.xy.XYDataset)var5, 2, 1969, "December 2014", "December 2014");
//     java.util.List var26 = var5.getSeries();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var27 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var26);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Value", var1, (-1.0f), 0.0f, var4, 98.0d, var6);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.data.general.PieDataset var10 = var0.getDataset();
//     boolean var11 = var0.getSimpleLabels();
//     double var12 = var0.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.labels.PieSectionLabelGenerator var14 = var0.getLegendLabelGenerator();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.data.xy.XYSeries var17 = null;
//     org.jfree.data.xy.XYSeriesCollection var18 = new org.jfree.data.xy.XYSeriesCollection(var17);
//     org.jfree.data.xy.XYSeries var19 = null;
//     org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection(var19);
//     boolean var21 = var18.hasListener((java.util.EventListener)var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var23 = null;
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var18, var22, var23);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var24);
//     var25.clearSubtitles();
//     java.awt.RenderingHints var27 = var25.getRenderingHints();
//     var25.setBackgroundImageAlpha(10.0f);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.text.NumberFormat var34 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var35 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var36 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var34, var35);
//     var32.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var36, false);
//     org.jfree.chart.plot.PiePlot3D var39 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var40 = var39.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var47 = var43.getItemFillPaint(1, (-1), false);
//     var39.setLabelPaint(var47);
//     org.jfree.data.general.PieDataset var49 = var39.getDataset();
//     boolean var50 = var39.getSimpleLabels();
//     double var51 = var39.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var39);
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var54 = var53.getID();
//     org.jfree.chart.util.RectangleInsets var55 = var53.getPadding();
//     double var57 = var55.extendWidth(10.0d);
//     var52.setItemLabelPadding(var55);
//     org.jfree.chart.block.BlockContainer var59 = null;
//     var52.setWrapper(var59);
//     boolean var61 = var36.equals((java.lang.Object)var52);
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var63 = var62.clone();
//     org.jfree.chart.util.HorizontalAlignment var64 = var62.getTextAlignment();
//     boolean var66 = var64.equals((java.lang.Object)(-1L));
//     var52.setHorizontalAlignment(var64);
//     var25.addLegend(var52);
//     java.awt.geom.Rectangle2D var69 = var52.getBounds();
//     java.awt.geom.Point2D var70 = null;
//     org.jfree.chart.plot.PlotState var71 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     var0.draw(var15, var69, var70, var71, var72);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     var1.setLabelPaint(var9);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var13.setBaseStroke(var19);
//     var1.setLabelOutlineStroke(var19);
//     double var22 = var1.getInteriorGap();
//     java.awt.Paint var23 = var1.getLabelShadowPaint();
//     java.awt.Font var24 = var1.getLabelFont();
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var26 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = var26.getRenderer(0);
//     java.awt.Paint var29 = var26.getDomainCrosshairPaint();
//     java.awt.Paint var30 = var26.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var31 = var26.getDomainAxisLocation();
//     java.awt.Paint var32 = var26.getDomainZeroBaselinePaint();
//     var25.setRangeTickBandPaint(var32);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("Pie 3D Plot", var24, var32, 0.0f);
//     java.lang.String var36 = var35.getText();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.util.Size2D var38 = var35.calculateDimensions(var37);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.data.general.PieDataset var10 = var0.getDataset();
    boolean var11 = var0.getSimpleLabels();
    double var12 = var0.getDepthFactor();
    org.jfree.chart.urls.PieURLGenerator var13 = var0.getLegendLabelURLGenerator();
    java.awt.Color var17 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var0.setLabelOutlinePaint((java.awt.Paint)var18);
    org.jfree.data.general.DatasetGroup var20 = var0.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    int var5 = var2.getColumnCount();
    java.awt.Shape var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    org.jfree.data.xy.XYSeries var16 = null;
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection(var16);
    boolean var18 = var15.hasListener((java.util.EventListener)var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var15, var19, var20);
    java.awt.Paint var22 = var21.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var11, var13, var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-16777216), var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.getEndXValue(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    var2.setBaseLegendTextPaint(var12);
    var2.setSeriesShapesFilled(0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    java.awt.RenderingHints var10 = var9.getRenderingHints();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var13 = var9.createBufferedImage((-16777216), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var1.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var3, "hi!", "", "[-1.0, 0.0]");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var13, "hi!", "", "[-1.0, 0.0]");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var17);
    var17.setCopyright("December 1969");

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    java.awt.Shape var13 = var1.getDownArrow();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
    org.jfree.data.xy.XYSeries var6 = null;
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
    org.jfree.data.xy.XYSeries var8 = null;
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
    boolean var10 = var7.hasListener((java.util.EventListener)var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var7, var11, var12);
    var13.setForegroundAlpha(100.0f);
    boolean var16 = var13.isAngleLabelsVisible();
    boolean var17 = var13.isAngleLabelsVisible();
    boolean var18 = var13.isDomainZoomable();
    var0.setParent((org.jfree.chart.plot.Plot)var13);
    org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection();
    var0.setDataset((org.jfree.data.xy.XYDataset)var20);
    boolean var22 = var0.isDomainPannable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    org.jfree.chart.plot.CrosshairState var29 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var36 = null;
    var29.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var36);
    org.jfree.data.xy.XYSeries var38 = null;
    org.jfree.data.xy.XYSeriesCollection var39 = new org.jfree.data.xy.XYSeriesCollection(var38);
    org.jfree.data.xy.XYSeries var40 = null;
    org.jfree.data.xy.XYSeriesCollection var41 = new org.jfree.data.xy.XYSeriesCollection(var40);
    boolean var42 = var39.hasListener((java.util.EventListener)var41);
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.PolarItemRenderer var44 = null;
    org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var39, var43, var44);
    org.jfree.chart.plot.PlotRenderingInfo var48 = null;
    java.awt.geom.Rectangle2D var49 = null;
    org.jfree.chart.util.RectangleAnchor var50 = null;
    java.awt.geom.Point2D var51 = org.jfree.chart.util.RectangleAnchor.coordinates(var49, var50);
    var45.zoomDomainAxes(100.0d, (-1.0d), var48, var51);
    var29.setAnchor(var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(45.0d, var28, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var5 = var0.getDataset(1);
    var0.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(var0, 0);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    var2.setBaseLegendTextPaint(var12);
    org.jfree.chart.labels.XYItemLabelGenerator var15 = null;
    var2.setSeriesItemLabelGenerator(3, var15, false);
    int var18 = var2.getPassCount();
    org.jfree.data.xy.XYSeries var19 = null;
    org.jfree.data.xy.XYSeriesCollection var20 = new org.jfree.data.xy.XYSeriesCollection(var19);
    org.jfree.data.xy.XYSeries var21 = null;
    org.jfree.data.xy.XYSeriesCollection var22 = new org.jfree.data.xy.XYSeriesCollection(var21);
    boolean var23 = var20.hasListener((java.util.EventListener)var22);
    double var24 = var22.getIntervalPositionFactor();
    org.jfree.data.Range var25 = var2.findRangeBounds((org.jfree.data.xy.XYDataset)var22);
    org.jfree.data.DomainOrder var26 = var22.getDomainOrder();
    org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var30 = var22.getEndX(3, 3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var19 = var5.getLocale();
//     var5.setPositiveArrowVisible(false);
//     double var22 = var5.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
//     var0.setDomainAxes(var23);
//     org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
//     boolean var27 = var0.isRangeZoomable();
//     var0.clearDomainAxes();
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
//     var29.clearSectionOutlinePaints(false);
//     org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder();
//     boolean var34 = var29.equals((java.lang.Object)var33);
//     java.awt.Paint var35 = var29.getBaseSectionOutlinePaint();
//     var0.setRangeMinorGridlinePaint(var35);
//     
//     // Checks the contract:  equals-hashcode on var13 and var29
//     assertTrue("Contract failed: equals-hashcode on var13 and var29", var13.equals(var29) ? var13.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var13
//     assertTrue("Contract failed: equals-hashcode on var29 and var13", var29.equals(var13) ? var29.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
    var2.setBaseStroke(var8);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = var2.getBaseItemLabelGenerator();
    boolean var12 = var2.equals((java.lang.Object)(short)100);
    var2.setDrawOutlines(true);
    var2.setSeriesShapesVisible(100, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesCreateEntities((-16777216), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.awt.Paint var3 = var0.getDomainCrosshairPaint();
    java.awt.Paint var4 = var0.getRangeMinorGridlinePaint();
    java.awt.Paint var5 = var0.getNoDataMessagePaint();
    boolean var6 = var0.isRangeGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.plot.CrosshairState var9 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var16 = null;
    var9.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var16);
    org.jfree.data.xy.XYSeries var18 = null;
    org.jfree.data.xy.XYSeriesCollection var19 = new org.jfree.data.xy.XYSeriesCollection(var18);
    org.jfree.data.xy.XYSeries var20 = null;
    org.jfree.data.xy.XYSeriesCollection var21 = new org.jfree.data.xy.XYSeriesCollection(var20);
    boolean var22 = var19.hasListener((java.util.EventListener)var21);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.PolarItemRenderer var24 = null;
    org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var19, var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleAnchor var30 = null;
    java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
    var25.zoomDomainAxes(100.0d, (-1.0d), var28, var31);
    var9.setAnchor(var31);
    var0.panRangeAxes(10.0d, var8, var31);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    org.jfree.data.xy.XYSeries var36 = null;
    org.jfree.data.xy.XYSeriesCollection var37 = new org.jfree.data.xy.XYSeriesCollection(var36);
    org.jfree.data.xy.XYSeries var38 = null;
    org.jfree.data.xy.XYSeriesCollection var39 = new org.jfree.data.xy.XYSeriesCollection(var38);
    boolean var40 = var37.hasListener((java.util.EventListener)var39);
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.PolarItemRenderer var42 = null;
    org.jfree.chart.plot.PolarPlot var43 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var37, var41, var42);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    java.awt.geom.Rectangle2D var47 = null;
    org.jfree.chart.util.RectangleAnchor var48 = null;
    java.awt.geom.Point2D var49 = org.jfree.chart.util.RectangleAnchor.coordinates(var47, var48);
    var43.zoomDomainAxes(100.0d, (-1.0d), var46, var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var51 = var0.findSubplot(var35, var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Font var7 = null;
    var2.setSeriesItemLabelFont(3, var7, true);
    java.awt.Color var13 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    java.awt.Color var14 = var13.darker();
    var2.setBaseOutlinePaint((java.awt.Paint)var14);
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var17 = var16.getFont();
    var2.setBaseLegendTextFont(var17);
    java.awt.Paint var20 = var2.lookupLegendTextPaint(3);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var28 = var24.getItemFillPaint(1, (-1), false);
    java.awt.Font var30 = var24.getSeriesItemLabelFont(1);
    java.awt.Paint var32 = var24.lookupSeriesOutlinePaint((-1));
    org.jfree.chart.labels.ItemLabelPosition var34 = var24.getSeriesNegativeItemLabelPosition(2);
    double var35 = var34.getAngle();
    var2.setSeriesPositiveItemLabelPosition(100, var34, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.axis.TickUnit var9 = var8.getAngleTickUnit();
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var8.addChangeListener(var10);
    var8.setAngleLabelsVisible(false);
    boolean var14 = var0.equals((java.lang.Object)var8);
    boolean var15 = var8.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var1 = var0.getTickLabelPaint();
    java.lang.String var3 = var0.getCategoryLabelToolTip((java.lang.Comparable)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
//     org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
//     org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var8 = var7.getID();
//     org.jfree.chart.util.RectangleInsets var9 = var7.getPadding();
//     var7.setMaximumLinesToDisplay(1);
//     var7.setToolTipText("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.awt.geom.Rectangle2D var14 = var7.getBounds();
//     var2.drawDomainGridline(var5, var6, var14, 0.0d);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getYValue(255, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.time.TimePeriodAnchor var2 = var1.getXPosition();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.time.TimePeriodAnchor var4 = var1.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var6 = var1.getSeries(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.annotations.XYAnnotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var0.removeAnnotation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    double var5 = var3.getIntervalPositionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var3.getY(96, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5d);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Stroke var1 = var0.getRangeGridlineStroke();
//     java.awt.Paint var2 = var0.getDomainTickBandPaint();
//     java.awt.Stroke var3 = var0.getDomainGridlineStroke();
//     boolean var4 = var0.canSelectByPoint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = var6.getRenderer(0);
//     java.awt.Paint var9 = var6.getDomainCrosshairPaint();
//     java.awt.Paint var10 = var6.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var11 = var6.getDomainAxisLocation();
//     java.awt.Paint var12 = var6.getDomainZeroBaselinePaint();
//     var5.setRangeTickBandPaint(var12);
//     org.jfree.chart.axis.ValueAxis var15 = var5.getRangeAxisForDataset(0);
//     org.jfree.chart.event.PlotChangeEvent var16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var5);
//     var0.plotChanged(var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(1969, var1);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    java.lang.Object var3 = var1.clone();
    var1.removeAgedItems(100L, true);
    var1.setMaximumItemCount(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    var3.setMaximumFractionDigits(0);
    java.text.NumberFormat var8 = java.text.NumberFormat.getCurrencyInstance();
    java.text.NumberFormat var10 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var11 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var10, var11);
    var10.setMinimumIntegerDigits(10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var8, var10);
    org.jfree.chart.labels.StandardPieToolTipGenerator var16 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var3, var8);
    org.jfree.data.general.DefaultPieDataset var17 = new org.jfree.data.general.DefaultPieDataset();
    java.lang.Object var18 = var17.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var20 = var16.generateToolTip((org.jfree.data.general.PieDataset)var17, (java.lang.Comparable)"0,000,000,000%");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    var7.setForegroundAlpha(100.0f);
    var7.setAngleGridlinesVisible(true);
    java.awt.Paint var12 = var7.getBackgroundPaint();
    var7.setAngleGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var16 = var15.getFont();
    var7.setAngleLabelFont(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var12.setBaseStroke(var18);
//     var0.setLabelOutlineStroke(var18);
//     double var21 = var0.getInteriorGap();
//     java.awt.Paint var22 = var0.getLabelShadowPaint();
//     java.awt.Font var23 = var0.getLabelFont();
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     org.jfree.chart.plot.PlotState var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     var0.draw(var24, var25, var26, var27, var28);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = var1.getRenderer(0);
    java.awt.Paint var4 = var1.getDomainCrosshairPaint();
    java.awt.Paint var5 = var1.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var6 = var1.getDomainAxisLocation();
    java.awt.Paint var7 = var1.getDomainZeroBaselinePaint();
    var0.setRangeTickBandPaint(var7);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    var0.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var2.setSeriesURLGenerator(10, var10);
    var2.setDrawBarOutline(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var9.clearSubtitles();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    var9.setBackgroundImageAlpha(10.0f);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var18 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var19 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var20 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var18, var19);
    var16.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var20, false);
    org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
    var23.setLabelPaint(var31);
    org.jfree.data.general.PieDataset var33 = var23.getDataset();
    boolean var34 = var23.getSimpleLabels();
    double var35 = var23.getDepthFactor();
    org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
    java.lang.String var38 = var37.getID();
    org.jfree.chart.util.RectangleInsets var39 = var37.getPadding();
    double var41 = var39.extendWidth(10.0d);
    var36.setItemLabelPadding(var39);
    org.jfree.chart.block.BlockContainer var43 = null;
    var36.setWrapper(var43);
    boolean var45 = var20.equals((java.lang.Object)var36);
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var47 = var46.clone();
    org.jfree.chart.util.HorizontalAlignment var48 = var46.getTextAlignment();
    boolean var50 = var48.equals((java.lang.Object)(-1L));
    var36.setHorizontalAlignment(var48);
    var9.addLegend(var36);
    java.awt.geom.Rectangle2D var53 = var36.getBounds();
    boolean var54 = var36.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     var5.setBaseStroke(var11);
//     var2.setMinorTickMarkStroke(var11);
//     org.jfree.data.time.DateRange var14 = new org.jfree.data.time.DateRange();
//     var2.setRangeWithMargins((org.jfree.data.Range)var14);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var2.java2DToValue(0.08d, var17, var18);
//     var2.setAutoRange(false);
//     java.awt.Font var22 = var2.getTickLabelFont();
//     org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     var23.clearSectionOutlinePaints(false);
//     int var27 = var23.getPieIndex();
//     java.awt.Image var28 = null;
//     var23.setBackgroundImage(var28);
//     var23.setIgnoreZeroValues(false);
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("ThreadContext", var22, (org.jfree.chart.plot.Plot)var23, true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var23
//     assertTrue("Contract failed: equals-hashcode on var10 and var23", var10.equals(var23) ? var10.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var10
//     assertTrue("Contract failed: equals-hashcode on var23 and var10", var23.equals(var10) ? var23.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     java.lang.Object var10 = var0.clone();
//     var0.setMaximumLabelWidth(0.0d);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.data.xy.XYSeries var15 = null;
//     org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
//     org.jfree.data.xy.XYSeries var17 = null;
//     org.jfree.data.xy.XYSeriesCollection var18 = new org.jfree.data.xy.XYSeriesCollection(var17);
//     boolean var19 = var16.hasListener((java.util.EventListener)var18);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var21 = null;
//     org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var16, var20, var21);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var22);
//     var23.clearSubtitles();
//     java.awt.RenderingHints var25 = var23.getRenderingHints();
//     var23.setBackgroundImageAlpha(10.0f);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.text.NumberFormat var32 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var33 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var34 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var32, var33);
//     var30.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var34, false);
//     org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var38 = var37.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var45 = var41.getItemFillPaint(1, (-1), false);
//     var37.setLabelPaint(var45);
//     org.jfree.data.general.PieDataset var47 = var37.getDataset();
//     boolean var48 = var37.getSimpleLabels();
//     double var49 = var37.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37);
//     org.jfree.chart.title.TextTitle var51 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var52 = var51.getID();
//     org.jfree.chart.util.RectangleInsets var53 = var51.getPadding();
//     double var55 = var53.extendWidth(10.0d);
//     var50.setItemLabelPadding(var53);
//     org.jfree.chart.block.BlockContainer var57 = null;
//     var50.setWrapper(var57);
//     boolean var59 = var34.equals((java.lang.Object)var50);
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var61 = var60.clone();
//     org.jfree.chart.util.HorizontalAlignment var62 = var60.getTextAlignment();
//     boolean var64 = var62.equals((java.lang.Object)(-1L));
//     var50.setHorizontalAlignment(var62);
//     var23.addLegend(var50);
//     java.awt.geom.Rectangle2D var67 = var50.getBounds();
//     var0.drawOutline(var13, var67);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var3 = var2.getDefaultEntityRadius();
    var2.setDataBoundsIncludesVisibleSeriesOnly(false);
    org.jfree.chart.labels.XYToolTipGenerator var7 = var2.getSeriesToolTipGenerator(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    var0.setFixedRangeAxisSpace(var4, false);
    java.util.List var7 = var0.getSubplots();
    java.awt.Stroke var8 = var0.getDomainGridlineStroke();
    org.jfree.chart.annotations.XYAnnotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var0.removeAnnotation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getSeriesKey(1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.getEndXValue(100, 96);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
    var2.setBaseStroke(var8);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = var2.getBaseItemLabelGenerator();
    boolean var12 = var2.equals((java.lang.Object)(short)100);
    java.awt.Font var14 = null;
    var2.setSeriesItemLabelFont(0, var14);
    java.awt.Paint var17 = var2.lookupLegendTextPaint((-1));
    var2.setSeriesVisible(0, (java.lang.Boolean)true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = var1.getRenderer(0);
//     java.awt.Paint var4 = var1.getDomainCrosshairPaint();
//     java.awt.Paint var5 = var1.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var6 = var1.getDomainAxisLocation();
//     java.awt.Paint var7 = var1.getDomainZeroBaselinePaint();
//     var0.setRangeTickBandPaint(var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var12.getRenderer(0);
//     java.util.List var15 = var12.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var17 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var24 = var20.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     var20.setBaseStroke(var26);
//     var17.setMinorTickMarkStroke(var26);
//     var17.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var31 = var17.getLocale();
//     var17.setPositiveArrowVisible(false);
//     double var34 = var17.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var35 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var12.setDomainAxes(var35);
//     org.jfree.chart.plot.CombinedDomainXYPlot var37 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = var37.getRenderer(0);
//     java.util.List var40 = var37.getSubplots();
//     org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
//     var37.setFixedRangeAxisSpace(var41, false);
//     var12.setFixedRangeAxisSpace(var41);
//     java.awt.Color var48 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     int var49 = var48.getRGB();
//     int var50 = var48.getAlpha();
//     var12.setDomainGridlinePaint((java.awt.Paint)var48);
//     org.jfree.chart.plot.IntervalMarker var52 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.025d, (java.awt.Paint)var48);
//     java.lang.Object var53 = var52.clone();
//     org.jfree.chart.util.Layer var54 = null;
//     boolean var56 = var0.removeRangeMarker(100, (org.jfree.chart.plot.Marker)var52, var54, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var37
//     assertTrue("Contract failed: equals-hashcode on var1 and var37", var1.equals(var37) ? var1.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var1
//     assertTrue("Contract failed: equals-hashcode on var37 and var1", var37.equals(var1) ? var37.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var19 = var5.getLocale();
//     var5.setPositiveArrowVisible(false);
//     double var22 = var5.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
//     var0.setDomainAxes(var23);
//     java.awt.Paint var25 = var0.getDomainCrosshairPaint();
//     boolean var26 = var0.isDomainMinorGridlinesVisible();
//     org.jfree.chart.plot.PiePlot3D var27 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var28 = var27.getBaseSectionOutlineStroke();
//     var0.setDomainMinorGridlineStroke(var28);
//     
//     // Checks the contract:  equals-hashcode on var13 and var27
//     assertTrue("Contract failed: equals-hashcode on var13 and var27", var13.equals(var27) ? var13.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var13
//     assertTrue("Contract failed: equals-hashcode on var27 and var13", var27.equals(var13) ? var27.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = var2.getRenderer(0);
//     java.util.List var5 = var2.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var10.setBaseStroke(var16);
//     var7.setMinorTickMarkStroke(var16);
//     var7.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var21 = var7.getLocale();
//     var7.setPositiveArrowVisible(false);
//     double var24 = var7.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var7};
//     var2.setDomainAxes(var25);
//     org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = var27.getRenderer(0);
//     java.util.List var30 = var27.getSubplots();
//     org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
//     var27.setFixedRangeAxisSpace(var31, false);
//     var2.setFixedRangeAxisSpace(var31);
//     java.awt.Color var38 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     int var39 = var38.getRGB();
//     int var40 = var38.getAlpha();
//     var2.setDomainGridlinePaint((java.awt.Paint)var38);
//     org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.025d, (java.awt.Paint)var38);
//     java.lang.Object var43 = var42.clone();
//     org.jfree.chart.axis.PeriodAxis var45 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var52 = var48.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var53 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var54 = var53.getBaseSectionOutlineStroke();
//     var48.setBaseStroke(var54);
//     var45.setMinorTickMarkStroke(var54);
//     var45.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var59 = var45.getLocale();
//     org.jfree.chart.axis.TickUnitSource var60 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var59);
//     org.jfree.chart.labels.StandardPieToolTipGenerator var61 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var59);
//     boolean var62 = var42.equals((java.lang.Object)var59);
//     
//     // Checks the contract:  equals-hashcode on var15 and var53
//     assertTrue("Contract failed: equals-hashcode on var15 and var53", var15.equals(var53) ? var15.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var15
//     assertTrue("Contract failed: equals-hashcode on var53 and var15", var53.equals(var15) ? var53.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=0,b=0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var34 = var30.getItemFillPaint(1, (-1), false);
//     var26.setLabelPaint(var34);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var42 = var38.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var44 = var43.getBaseSectionOutlineStroke();
//     var38.setBaseStroke(var44);
//     var26.setLabelOutlineStroke(var44);
//     boolean var48 = var26.equals((java.lang.Object)'4');
//     org.jfree.chart.plot.PieLabelLinkStyle var49 = var26.getLabelLinkStyle();
//     var1.setLabelLinkStyle(var49);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var43
//     assertTrue("Contract failed: equals-hashcode on var19 and var43", var19.equals(var43) ? var19.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var19
//     assertTrue("Contract failed: equals-hashcode on var43 and var19", var43.equals(var19) ? var43.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var2.getRenderer(0);
    java.util.List var5 = var2.getSubplots();
    org.jfree.chart.axis.PeriodAxis var7 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var10.setBaseStroke(var16);
    var7.setMinorTickMarkStroke(var16);
    var7.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var21 = var7.getLocale();
    var7.setPositiveArrowVisible(false);
    double var24 = var7.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var25 = new org.jfree.chart.axis.ValueAxis[] { var7};
    var2.setDomainAxes(var25);
    org.jfree.chart.plot.CombinedDomainXYPlot var27 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = var27.getRenderer(0);
    java.util.List var30 = var27.getSubplots();
    org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
    var27.setFixedRangeAxisSpace(var31, false);
    var2.setFixedRangeAxisSpace(var31);
    java.awt.Color var38 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var39 = var38.getRGB();
    int var40 = var38.getAlpha();
    var2.setDomainGridlinePaint((java.awt.Paint)var38);
    org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.025d, (java.awt.Paint)var38);
    java.awt.Paint var43 = var42.getPaint();
    org.jfree.chart.event.MarkerChangeEvent var44 = null;
    var42.notifyListeners(var44);
    java.awt.Paint var46 = var42.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.category.CategoryDataset var1 = null;
    var0.setDataset(var1);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getID();
    java.lang.String var2 = var0.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.data.general.PieDataset var10 = var0.getDataset();
//     boolean var11 = var0.getSimpleLabels();
//     double var12 = var0.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.labels.PieSectionLabelGenerator var14 = var0.getLegendLabelGenerator();
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var17 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = var17.getRenderer(0);
//     java.awt.Paint var20 = var17.getDomainCrosshairPaint();
//     java.awt.Paint var21 = var17.getRangeMinorGridlinePaint();
//     java.awt.Paint var22 = var17.getNoDataMessagePaint();
//     boolean var23 = var17.isRangeGridlinesVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     org.jfree.chart.plot.CrosshairState var26 = new org.jfree.chart.plot.CrosshairState();
//     org.jfree.chart.plot.PlotOrientation var33 = null;
//     var26.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var33);
//     org.jfree.data.xy.XYSeries var35 = null;
//     org.jfree.data.xy.XYSeriesCollection var36 = new org.jfree.data.xy.XYSeriesCollection(var35);
//     org.jfree.data.xy.XYSeries var37 = null;
//     org.jfree.data.xy.XYSeriesCollection var38 = new org.jfree.data.xy.XYSeriesCollection(var37);
//     boolean var39 = var36.hasListener((java.util.EventListener)var38);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var36, var40, var41);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleAnchor var47 = null;
//     java.awt.geom.Point2D var48 = org.jfree.chart.util.RectangleAnchor.coordinates(var46, var47);
//     var42.zoomDomainAxes(100.0d, (-1.0d), var45, var48);
//     var26.setAnchor(var48);
//     var17.panRangeAxes(10.0d, var25, var48);
//     org.jfree.chart.plot.PlotState var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     var0.draw(var15, var16, var48, var52, var53);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
    boolean var7 = var2.equals((java.lang.Object)var6);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var2.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange(var0);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var4.setBaseStroke(var10);
//     var1.setMinorTickMarkStroke(var10);
//     var1.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var15 = var1.getLocale();
//     var1.setPositiveArrowVisible(false);
//     org.jfree.data.time.RegularTimePeriod var18 = var1.getLast();
//     org.jfree.chart.axis.PeriodAxis var20 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange();
//     java.lang.String var22 = var21.toString();
//     var20.setRangeWithMargins((org.jfree.data.Range)var21);
//     java.util.Date var24 = var21.getLowerDate();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(var24);
//     org.jfree.data.time.RegularTimePeriod var26 = var25.next();
//     var1.setLast((org.jfree.data.time.RegularTimePeriod)var25);
//     long var28 = var25.getSerialIndex();
//     java.lang.String var29 = var25.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var22.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 23640L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "December 1969"+ "'", var29.equals("December 1969"));
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var1 = null;
    var0.plotChanged(var1);
    java.util.List var3 = var0.getSubplots();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var6 = var5.getItemCount();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(1);
    java.util.Date var9 = var8.getStart();
    var5.add((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    org.jfree.data.xy.XYSeries var15 = null;
    org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
    boolean var17 = var14.hasListener((java.util.EventListener)var16);
    double var18 = var16.getIntervalPositionFactor();
    var5.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var16);
    boolean var20 = var0.equals((java.lang.Object)var5);
    org.jfree.chart.plot.ValueMarker var22 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var23 = var22.getOutlineStroke();
    double var24 = var22.getValue();
    java.awt.Color var28 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var29 = var28.getRGB();
    java.lang.String var30 = var28.toString();
    var22.setLabelPaint((java.awt.Paint)var28);
    org.jfree.chart.util.Layer var32 = null;
    boolean var33 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var22, var32);
    var0.setDomainCrosshairVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var30.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var14 = var10.getItemFillPaint(1, (-1), false);
    var2.setLegendTextPaint(3, var14);
    java.lang.Boolean var17 = var2.getSeriesShapesVisible(2);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = var20.getRenderer(0);
    java.util.List var23 = var20.getSubplots();
    org.jfree.chart.axis.PeriodAxis var25 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var33 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
    var28.setBaseStroke(var34);
    var25.setMinorTickMarkStroke(var34);
    var25.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var39 = var25.getLocale();
    var25.setPositiveArrowVisible(false);
    double var42 = var25.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var25};
    var20.setDomainAxes(var43);
    org.jfree.chart.util.RectangleEdge var46 = var20.getRangeAxisEdge(0);
    org.jfree.data.xy.XYSeries var48 = null;
    org.jfree.data.xy.XYSeriesCollection var49 = new org.jfree.data.xy.XYSeriesCollection(var48);
    org.jfree.data.xy.XYSeries var50 = null;
    org.jfree.data.xy.XYSeriesCollection var51 = new org.jfree.data.xy.XYSeriesCollection(var50);
    boolean var52 = var49.hasListener((java.util.EventListener)var51);
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.PolarItemRenderer var54 = null;
    org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var49, var53, var54);
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var55);
    boolean var57 = var20.equals((java.lang.Object)"");
    org.jfree.data.xy.XYSeries var58 = null;
    org.jfree.data.xy.XYSeriesCollection var59 = new org.jfree.data.xy.XYSeriesCollection(var58);
    org.jfree.data.xy.XYSeries var60 = null;
    org.jfree.data.xy.XYSeriesCollection var61 = new org.jfree.data.xy.XYSeriesCollection(var60);
    boolean var62 = var59.hasListener((java.util.EventListener)var61);
    double var63 = var61.getIntervalPositionFactor();
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var65 = var2.initialise(var18, var19, (org.jfree.chart.plot.XYPlot)var20, (org.jfree.data.xy.XYDataset)var61, var64);
    int var66 = var65.getLastItemIndex();
    org.jfree.data.xy.XYSeriesCollection var67 = new org.jfree.data.xy.XYSeriesCollection();
    var65.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var67);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var71 = var67.getEndX(96, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var3 = var2.getItemCount();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(1);
//     java.util.Date var6 = var5.getStart();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var5, true);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(1);
//     org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("$0.00?DomainOrder.NONE=3&amp;=2", (org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var13);
//     long var15 = var5.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-62104204800001L));
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Combined_Domain_XYPlot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setIncludeBaseInRange(true);
    org.jfree.chart.labels.CategoryToolTipGenerator var6 = var0.getToolTipGenerator(10, 2, true);
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = var7.getRenderer(0);
    java.util.List var10 = var7.getSubplots();
    org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var19 = var15.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
    var15.setBaseStroke(var21);
    var12.setMinorTickMarkStroke(var21);
    var12.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var26 = var12.getLocale();
    var12.setPositiveArrowVisible(false);
    double var29 = var12.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var12};
    var7.setDomainAxes(var30);
    double var32 = var7.getRangeCrosshairValue();
    java.awt.Paint var33 = var7.getRangeZeroBaselinePaint();
    var0.setBaseOutlinePaint(var33, true);
    org.jfree.chart.annotations.CategoryAnnotation var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Paint var4 = var2.getLabelBackgroundPaint();
//     org.jfree.chart.entity.PlotEntity var7 = new org.jfree.chart.entity.PlotEntity(var1, (org.jfree.chart.plot.Plot)var2, "Pie 3D Plot", "[-1.0, 0.0]");
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape(var9, 2.0d, 1.0f, 0.5f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.clone(var9);
//     var7.setArea(var14);
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var16 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var17 = null;
//     java.lang.String var18 = var7.getImageMapAreaTag(var16, var17);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var3 = var2.getDefaultEntityRadius();
//     java.awt.Shape var5 = var2.getSeriesShape(1);
//     org.jfree.chart.LegendItemCollection var6 = var2.getLegendItems();
//     org.jfree.chart.labels.StandardXYSeriesLabelGenerator var7 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
//     java.lang.Object var8 = var7.clone();
//     var2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var7);
//     org.jfree.data.xy.XYSeries var11 = null;
//     org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     boolean var15 = var12.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var18);
//     var19.clearSubtitles();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var27 = var23.getItemFillPaint(1, (-1), false);
//     java.awt.Font var29 = var23.getSeriesItemLabelFont(1);
//     java.awt.Paint var31 = var23.lookupSeriesOutlinePaint((-1));
//     org.jfree.chart.labels.ItemLabelPosition var33 = var23.getSeriesNegativeItemLabelPosition(2);
//     boolean var34 = var19.equals((java.lang.Object)var33);
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     var36.addCategoryLabelToolTip((java.lang.Comparable)1.0d, "hi!");
//     org.jfree.chart.event.ChartChangeEvent var40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
//     org.jfree.data.xy.XYSeries var42 = null;
//     org.jfree.data.xy.XYSeriesCollection var43 = new org.jfree.data.xy.XYSeriesCollection(var42);
//     org.jfree.data.xy.XYSeries var44 = null;
//     org.jfree.data.xy.XYSeriesCollection var45 = new org.jfree.data.xy.XYSeriesCollection(var44);
//     boolean var46 = var43.hasListener((java.util.EventListener)var45);
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var48 = null;
//     org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var43, var47, var48);
//     org.jfree.chart.JFreeChart var50 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var49);
//     var50.setAntiAlias(true);
//     java.awt.Image var53 = var50.getBackgroundImage();
//     var40.setChart(var50);
//     org.jfree.chart.event.ChartChangeEventType var55 = var40.getType();
//     org.jfree.chart.event.ChartChangeEvent var56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var19, var55);
//     
//     // Checks the contract:  equals-hashcode on var18 and var49
//     assertTrue("Contract failed: equals-hashcode on var18 and var49", var18.equals(var49) ? var18.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var18
//     assertTrue("Contract failed: equals-hashcode on var49 and var18", var49.equals(var18) ? var49.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     double var6 = var3.getDomainUpperBound(true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var9 = var8.getItemCount();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year(1);
//     java.util.Date var12 = var11.getStart();
//     var8.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var11, true);
//     var3.addSeries(var17);
//     var17.add(0.08d, (java.lang.Number)1.0d, true);
//     var17.add(12.0d, (java.lang.Number)0.12d);
//     var17.clear();
//     var17.setNotify(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var30 = var17.getY(255);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     int var1 = var0.getMaximumCategoryLabelLines();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.AxisState var4 = new org.jfree.chart.axis.AxisState((-6.21357408E13d));
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Paint var7 = var6.getTickLabelPaint();
//     java.lang.String var8 = var6.getLabel();
//     org.jfree.data.xy.XYDataItem var11 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
//     double var12 = var11.getXValue();
//     double var13 = var11.getYValue();
//     java.awt.Paint var14 = var6.getTickLabelPaint((java.lang.Comparable)var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.AxisState var16 = null;
//     org.jfree.data.xy.XYSeries var18 = null;
//     org.jfree.data.xy.XYSeriesCollection var19 = new org.jfree.data.xy.XYSeriesCollection(var18);
//     org.jfree.data.xy.XYSeries var20 = null;
//     org.jfree.data.xy.XYSeriesCollection var21 = new org.jfree.data.xy.XYSeriesCollection(var20);
//     boolean var22 = var19.hasListener((java.util.EventListener)var21);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var19, var23, var24);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var25);
//     var26.clearSubtitles();
//     java.awt.RenderingHints var28 = var26.getRenderingHints();
//     var26.setBackgroundImageAlpha(10.0f);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.text.NumberFormat var35 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var36 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var37 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var35, var36);
//     var33.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var37, false);
//     org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var44 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var48 = var44.getItemFillPaint(1, (-1), false);
//     var40.setLabelPaint(var48);
//     org.jfree.data.general.PieDataset var50 = var40.getDataset();
//     boolean var51 = var40.getSimpleLabels();
//     double var52 = var40.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40);
//     org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var55 = var54.getID();
//     org.jfree.chart.util.RectangleInsets var56 = var54.getPadding();
//     double var58 = var56.extendWidth(10.0d);
//     var53.setItemLabelPadding(var56);
//     org.jfree.chart.block.BlockContainer var60 = null;
//     var53.setWrapper(var60);
//     boolean var62 = var37.equals((java.lang.Object)var53);
//     org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle();
//     java.lang.Object var64 = var63.clone();
//     org.jfree.chart.util.HorizontalAlignment var65 = var63.getTextAlignment();
//     boolean var67 = var65.equals((java.lang.Object)(-1L));
//     var53.setHorizontalAlignment(var65);
//     var26.addLegend(var53);
//     java.awt.geom.Rectangle2D var70 = var53.getBounds();
//     org.jfree.chart.plot.CombinedDomainXYPlot var71 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = var71.getRenderer(0);
//     java.util.List var74 = var71.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var76 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var79 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var83 = var79.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var84 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var85 = var84.getBaseSectionOutlineStroke();
//     var79.setBaseStroke(var85);
//     var76.setMinorTickMarkStroke(var85);
//     var76.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var90 = var76.getLocale();
//     var76.setPositiveArrowVisible(false);
//     double var93 = var76.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var94 = new org.jfree.chart.axis.ValueAxis[] { var76};
//     var71.setDomainAxes(var94);
//     org.jfree.chart.util.RectangleEdge var97 = var71.getRangeAxisEdge(0);
//     java.util.List var98 = var6.refreshTicks(var15, var16, var70, var97);
//     java.util.List var99 = var0.refreshTicks(var2, var4, var5, var97);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     java.awt.Paint var2 = var0.getLabelBackgroundPaint();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     java.awt.Font var11 = var5.getSeriesItemLabelFont(1);
//     java.awt.Paint var13 = var5.lookupSeriesOutlinePaint((-1));
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var21 = var17.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var17.setBaseStroke(var23);
//     org.jfree.chart.labels.XYItemLabelGenerator var25 = var17.getBaseItemLabelGenerator();
//     java.awt.Color var30 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     java.awt.Color var31 = java.awt.Color.getColor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var30);
//     var17.setBaseItemLabelPaint((java.awt.Paint)var30);
//     var5.setSeriesOutlinePaint(100, (java.awt.Paint)var30, true);
//     var0.setLabelShadowPaint((java.awt.Paint)var30);
//     org.jfree.chart.axis.PeriodAxis var37 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var44 = var40.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var45 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var46 = var45.getBaseSectionOutlineStroke();
//     var40.setBaseStroke(var46);
//     var37.setMinorTickMarkStroke(var46);
//     var37.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var51 = var37.getLocale();
//     var37.setMinorTickCount(3);
//     boolean var54 = var0.equals((java.lang.Object)3);
//     
//     // Checks the contract:  equals-hashcode on var22 and var45
//     assertTrue("Contract failed: equals-hashcode on var22 and var45", var22.equals(var45) ? var22.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var22
//     assertTrue("Contract failed: equals-hashcode on var45 and var22", var45.equals(var22) ? var45.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    double var13 = var1.getUpperMargin();
    var1.setMinorTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100, "$0.00?DomainOrder.NONE=3&amp;=2", var2, var3, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var1 = null;
    var0.plotChanged(var1);
    java.util.List var3 = var0.getSubplots();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var6 = var5.getItemCount();
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(1);
    java.util.Date var9 = var8.getStart();
    var5.add((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    org.jfree.data.xy.XYSeries var15 = null;
    org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
    boolean var17 = var14.hasListener((java.util.EventListener)var16);
    double var18 = var16.getIntervalPositionFactor();
    var5.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var16);
    boolean var20 = var0.equals((java.lang.Object)var5);
    java.awt.Paint var21 = var0.getRangeGridlinePaint();
    java.io.ObjectOutputStream var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var21, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var19 = var5.getLocale();
//     var5.setPositiveArrowVisible(false);
//     double var22 = var5.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
//     var0.setDomainAxes(var23);
//     java.awt.Paint var25 = var0.getDomainCrosshairPaint();
//     boolean var26 = var0.isDomainMinorGridlinesVisible();
//     var0.setGap(Double.POSITIVE_INFINITY);
//     org.jfree.chart.event.RendererChangeEvent var29 = null;
//     var0.rendererChanged(var29);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
    var12.setBaseStroke(var18);
    var0.setLabelOutlineStroke(var18);
    java.awt.Paint var21 = var0.getBaseSectionOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    java.lang.Object var3 = var1.clone();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var8 = var7.getItemCount();
    org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(1);
    java.util.Date var11 = var10.getStart();
    var7.add((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)Double.NaN, true);
    var5.delete((org.jfree.data.time.RegularTimePeriod)var10);
    org.jfree.data.time.TimeSeriesDataItem var17 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, 45.0d);
    org.jfree.data.time.RegularTimePeriod var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var18, 0.025d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = var4.getRenderer(0);
    java.awt.Paint var7 = var4.getDomainCrosshairPaint();
    java.awt.Paint var8 = var4.getRangeMinorGridlinePaint();
    java.awt.Paint var9 = var4.getNoDataMessagePaint();
    boolean var10 = var4.isRangeGridlinesVisible();
    var4.mapDatasetToRangeAxis(1969, 3);
    java.util.List var14 = var4.getSubplots();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes(0, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1969, 255, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.axis.TickUnit var9 = var8.getAngleTickUnit();
    java.awt.Paint var10 = var8.getRadiusGridlinePaint();
    org.jfree.chart.LegendItemCollection var11 = var8.getLegendItems();
    var0.setFixedLegendItems(var11);
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var15 = var14.getRangeGridlineStroke();
    java.awt.Paint var16 = var14.getDomainTickBandPaint();
    org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var19 = var18.getOutlineStroke();
    double var20 = var18.getValue();
    org.jfree.chart.util.Layer var21 = null;
    boolean var22 = var14.removeRangeMarker((org.jfree.chart.plot.Marker)var18, var21);
    java.awt.geom.Point2D var23 = var14.getQuadrantOrigin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var24 = var0.findSubplot(var13, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getID();
    org.jfree.chart.util.RectangleInsets var2 = var0.getPadding();
    double var3 = var2.getTop();
    double var5 = var2.calculateRightInset(0.0d);
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var2.createInsetRectangle(var6, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.general.DefaultPieDataset var0 = new org.jfree.data.general.DefaultPieDataset();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setValue(var1, (java.lang.Number)2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
//     java.util.List var3 = var0.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     var8.setBaseStroke(var14);
//     var5.setMinorTickMarkStroke(var14);
//     var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var19 = var5.getLocale();
//     var5.setPositiveArrowVisible(false);
//     double var22 = var5.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
//     var0.setDomainAxes(var23);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     var0.handleClick(3, 3, var27);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var2.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var5 = var2.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("", var5);
    var6.setToolTipText("ThreadContext");
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var10.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var13 = var10.getTickLabelFont();
    var6.setFont(var13);
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setContentAlignmentPoint(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     var5.setBaseStroke(var11);
//     var2.setMinorTickMarkStroke(var11);
//     var2.setAutoRangeMinimumSize(0.5d);
//     java.util.Locale var16 = var2.getLocale();
//     java.lang.ClassLoader var17 = null;
//     java.util.ResourceBundle var18 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", var16, var17);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
    java.util.Date var2 = var1.getStart();
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis("null");
    boolean var6 = var4.isHiddenValue(644288400000L);
    java.awt.Shape var11 = null;
    org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    org.jfree.data.xy.XYSeries var16 = null;
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection(var16);
    boolean var18 = var15.hasListener((java.util.EventListener)var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var15, var19, var20);
    java.awt.Paint var22 = var21.getRadiusGridlinePaint();
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var11, var13, var22);
    java.lang.String var24 = var23.getDescription();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    boolean var26 = var23.equals((java.lang.Object)var25);
    java.util.TimeZone var27 = var25.getTimeZone();
    var4.setTimeZone(var27);
    org.jfree.data.time.Year var29 = new org.jfree.data.time.Year(var2, var27);
    java.util.Locale var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var31 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var27, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Pie 3D Plot"+ "'", var24.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("$0.00", "DomainOrder.NONE", "");
//     java.awt.Shape var8 = null;
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var11 = null;
//     org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     boolean var15 = var12.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
//     java.awt.Paint var19 = var18.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var8, var10, var19);
//     java.lang.String var21 = var20.getDescription();
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     boolean var23 = var20.equals((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var26 = var25.getItemCount();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year(1);
//     java.util.Date var29 = var28.getStart();
//     var25.add((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var33 = null;
//     org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
//     org.jfree.data.xy.XYSeries var35 = null;
//     org.jfree.data.xy.XYSeriesCollection var36 = new org.jfree.data.xy.XYSeriesCollection(var35);
//     boolean var37 = var34.hasListener((java.util.EventListener)var36);
//     double var38 = var36.getIntervalPositionFactor();
//     var25.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var36);
//     var20.setDataset((org.jfree.data.general.Dataset)var36);
//     java.lang.String var43 = var3.generateURL((org.jfree.data.xy.XYDataset)var36, 100, (-16777216));
//     org.jfree.chart.plot.CombinedDomainXYPlot var44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = var44.getRenderer(0);
//     java.util.List var47 = var44.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var49 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var52 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var56 = var52.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var57 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var58 = var57.getBaseSectionOutlineStroke();
//     var52.setBaseStroke(var58);
//     var49.setMinorTickMarkStroke(var58);
//     var49.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var63 = var49.getLocale();
//     var49.setPositiveArrowVisible(false);
//     double var66 = var49.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var67 = new org.jfree.chart.axis.ValueAxis[] { var49};
//     var44.setDomainAxes(var67);
//     org.jfree.chart.util.RectangleEdge var70 = var44.getRangeAxisEdge(0);
//     boolean var71 = var44.isRangeZoomable();
//     org.jfree.chart.axis.ValueAxis var72 = var44.getDomainAxis();
//     double var73 = var72.getUpperMargin();
//     org.jfree.chart.renderer.PolarItemRenderer var74 = null;
//     org.jfree.chart.plot.PolarPlot var75 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var36, var72, var74);
//     
//     // Checks the contract:  equals-hashcode on var9 and var57
//     assertTrue("Contract failed: equals-hashcode on var9 and var57", var9.equals(var57) ? var9.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var9
//     assertTrue("Contract failed: equals-hashcode on var57 and var9", var57.equals(var9) ? var57.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.util.PaintMap var0 = new org.jfree.chart.util.PaintMap();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var5 = var4.getDefaultEntityRadius();
    java.awt.Shape var7 = var4.getSeriesShape(1);
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var10 = var9.getTickLabelPaint();
    var4.setSeriesOutlinePaint(0, var10);
    var0.put((java.lang.Comparable)0, var10);
    java.lang.Comparable var13 = null;
    boolean var14 = var0.containsKey(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("0,000,000,000%");

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var3, "hi!", "", "[-1.0, 0.0]");
    var7.setName("null");
    java.awt.Image var10 = null;
    var7.setLogo(var10);
    java.awt.Image var12 = var7.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.axis.TickUnit var9 = var8.getAngleTickUnit();
    java.awt.Paint var10 = var8.getRadiusGridlinePaint();
    org.jfree.chart.LegendItemCollection var11 = var8.getLegendItems();
    var0.setFixedLegendItems(var11);
    java.util.Iterator var13 = var11.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
//     var1.setLabelPaint(var9);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var13.setBaseStroke(var19);
//     var1.setLabelOutlineStroke(var19);
//     double var22 = var1.getInteriorGap();
//     java.awt.Paint var23 = var1.getLabelShadowPaint();
//     java.awt.Font var24 = var1.getLabelFont();
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     java.awt.Paint var27 = var25.getLabelBackgroundPaint();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var34 = var30.getItemFillPaint(1, (-1), false);
//     java.awt.Font var36 = var30.getSeriesItemLabelFont(1);
//     java.awt.Paint var38 = var30.lookupSeriesOutlinePaint((-1));
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var46 = var42.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var47 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var48 = var47.getBaseSectionOutlineStroke();
//     var42.setBaseStroke(var48);
//     org.jfree.chart.labels.XYItemLabelGenerator var50 = var42.getBaseItemLabelGenerator();
//     java.awt.Color var55 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     java.awt.Color var56 = java.awt.Color.getColor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var55);
//     var42.setBaseItemLabelPaint((java.awt.Paint)var55);
//     var30.setSeriesOutlinePaint(100, (java.awt.Paint)var55, true);
//     var25.setLabelShadowPaint((java.awt.Paint)var55);
//     java.awt.Graphics2D var63 = null;
//     org.jfree.chart.text.G2TextMeasurer var64 = new org.jfree.chart.text.G2TextMeasurer(var63);
//     org.jfree.chart.text.TextBlock var65 = org.jfree.chart.text.TextUtilities.createTextBlock("December 1969", var24, (java.awt.Paint)var55, 0.0f, 1, (org.jfree.chart.text.TextMeasurer)var64);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var2.setBaseSeriesVisible(false, false);
    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    var2.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator)var6);
    org.jfree.data.xy.XYSeries var8 = null;
    org.jfree.data.xy.XYSeriesCollection var9 = new org.jfree.data.xy.XYSeriesCollection(var8);
    org.jfree.data.xy.XYSeries var10 = null;
    org.jfree.data.xy.XYSeriesCollection var11 = new org.jfree.data.xy.XYSeriesCollection(var10);
    boolean var12 = var9.hasListener((java.util.EventListener)var11);
    double var13 = var11.getIntervalPositionFactor();
    org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var16 = var6.generateLabel((org.jfree.data.xy.XYDataset)var11, 1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    var1.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var15 = var1.getLocale();
    java.text.NumberFormat var16 = java.text.NumberFormat.getCurrencyInstance(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var6 = var2.getItemFillPaint(1, (-1), false);
//     java.awt.Font var8 = var2.getSeriesItemLabelFont(1);
//     java.awt.Paint var10 = var2.lookupSeriesOutlinePaint((-1));
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     java.awt.Font var19 = var13.getSeriesItemLabelFont(1);
//     java.awt.Paint var21 = var13.lookupSeriesOutlinePaint((-1));
//     var2.setBaseFillPaint(var21);
//     boolean var23 = var2.getBaseSeriesVisibleInLegend();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = var25.getRenderer(0);
//     java.util.List var28 = var25.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var30 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var37 = var33.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var38 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var39 = var38.getBaseSectionOutlineStroke();
//     var33.setBaseStroke(var39);
//     var30.setMinorTickMarkStroke(var39);
//     var30.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var44 = var30.getLocale();
//     var30.setPositiveArrowVisible(false);
//     double var47 = var30.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var48 = new org.jfree.chart.axis.ValueAxis[] { var30};
//     var25.setDomainAxes(var48);
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var52 = var50.getRenderer(0);
//     java.util.List var53 = var50.getSubplots();
//     org.jfree.chart.axis.AxisSpace var54 = new org.jfree.chart.axis.AxisSpace();
//     var50.setFixedRangeAxisSpace(var54, false);
//     var25.setFixedRangeAxisSpace(var54);
//     org.jfree.chart.util.RectangleEdge var59 = var25.getRangeAxisEdge((-16777216));
//     org.jfree.chart.axis.PeriodAxis var61 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var64 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var68 = var64.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var69 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var70 = var69.getBaseSectionOutlineStroke();
//     var64.setBaseStroke(var70);
//     var61.setMinorTickMarkStroke(var70);
//     double var73 = var61.getUpperMargin();
//     java.util.Locale var74 = var61.getLocale();
//     java.awt.geom.Rectangle2D var75 = null;
//     var2.drawDomainGridLine(var24, (org.jfree.chart.plot.XYPlot)var25, (org.jfree.chart.axis.ValueAxis)var61, var75, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var38 and var69
//     assertTrue("Contract failed: equals-hashcode on var38 and var69", var38.equals(var69) ? var38.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var38
//     assertTrue("Contract failed: equals-hashcode on var69 and var38", var69.equals(var38) ? var69.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.util.RectangleEdge var3 = null;
//     double var4 = var0.java2DToValue(0.12d, var2, var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.AxisState var7 = new org.jfree.chart.axis.AxisState((-6.21357408E13d));
//     var7.cursorDown((-6.21357408E13d));
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = var11.getRenderer(0);
//     java.util.List var14 = var11.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var16 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     var19.setBaseStroke(var25);
//     var16.setMinorTickMarkStroke(var25);
//     var16.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var30 = var16.getLocale();
//     var16.setPositiveArrowVisible(false);
//     double var33 = var16.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var34 = new org.jfree.chart.axis.ValueAxis[] { var16};
//     var11.setDomainAxes(var34);
//     org.jfree.chart.util.RectangleEdge var37 = var11.getRangeAxisEdge(0);
//     java.util.List var38 = var0.refreshTicks(var5, var7, var10, var37);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState((-6.21357408E13d));
    var1.cursorDown((-6.21357408E13d));
    var1.setCursor(0.0d);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var3 = var2.getItemCount();
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(1);
    java.util.Date var6 = var5.getStart();
    var2.add((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var5, true);
    org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(1);
    org.jfree.chart.axis.PeriodAxis var14 = new org.jfree.chart.axis.PeriodAxis("$0.00?DomainOrder.NONE=3&amp;=2", (org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var13);
    double var15 = var14.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0E-8d);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     var0.setRenderer(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.xy.XYSeries var5 = null;
//     org.jfree.data.xy.XYSeriesCollection var6 = new org.jfree.data.xy.XYSeriesCollection(var5);
//     org.jfree.data.xy.XYSeries var7 = null;
//     org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
//     boolean var9 = var6.hasListener((java.util.EventListener)var8);
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var11 = null;
//     org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var6, var10, var11);
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleAnchor var17 = null;
//     java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
//     var12.zoomDomainAxes(100.0d, (-1.0d), var15, var18);
//     org.jfree.chart.plot.PlotState var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var0.draw(var3, var4, var18, var20, var21);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    java.awt.Paint var8 = var6.getLabelBackgroundPaint();
    org.jfree.chart.entity.PlotEntity var11 = new org.jfree.chart.entity.PlotEntity(var5, (org.jfree.chart.plot.Plot)var6, "Pie 3D Plot", "[-1.0, 0.0]");
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape(var13, 2.0d, 1.0f, 0.5f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.clone(var13);
    var11.setArea(var18);
    org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var28 = var24.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
    var24.setBaseStroke(var30);
    var21.setMinorTickMarkStroke(var30);
    org.jfree.data.time.DateRange var33 = new org.jfree.data.time.DateRange();
    var21.setRangeWithMargins((org.jfree.data.Range)var33);
    var21.setTickMarkInsideLength((-1.0f));
    java.awt.Paint var37 = var21.getLabelPaint();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Shape var42 = var40.getSeriesShape(10);
    org.jfree.chart.plot.CombinedDomainXYPlot var43 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = var43.getRenderer(0);
    java.util.List var46 = var43.getSubplots();
    org.jfree.chart.axis.PeriodAxis var48 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var51 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var55 = var51.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var56 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var57 = var56.getBaseSectionOutlineStroke();
    var51.setBaseStroke(var57);
    var48.setMinorTickMarkStroke(var57);
    var48.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var62 = var48.getLocale();
    var48.setPositiveArrowVisible(false);
    double var65 = var48.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var66 = new org.jfree.chart.axis.ValueAxis[] { var48};
    var43.setDomainAxes(var66);
    org.jfree.chart.util.RectangleEdge var69 = var43.getRangeAxisEdge(0);
    java.awt.Stroke var70 = var43.getDomainGridlineStroke();
    var40.setBaseStroke(var70, true);
    org.jfree.chart.plot.PiePlot3D var73 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var74 = var73.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var77 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var81 = var77.getItemFillPaint(1, (-1), false);
    var73.setLabelPaint(var81);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var85 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var89 = var85.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var90 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var91 = var90.getBaseSectionOutlineStroke();
    var85.setBaseStroke(var91);
    var73.setLabelOutlineStroke(var91);
    boolean var95 = var73.equals((java.lang.Object)'4');
    java.awt.Paint var96 = var73.getBaseSectionPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var97 = new org.jfree.chart.LegendItem(var0, "", "null", "", var18, var37, var70, var96);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("December 2014");
//     var2.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Font var5 = var2.getTickLabelFont();
//     org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("", var5);
//     var6.setToolTipText("ThreadContext");
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("December 2014");
//     var10.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
//     java.awt.Font var13 = var10.getTickLabelFont();
//     var6.setFont(var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var6.draw(var15, var16);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getUpperClip();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = null;
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     org.jfree.chart.event.AxisChangeEvent var8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var7);
//     org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var13.setBaseStroke(var19);
//     var10.setMinorTickMarkStroke(var19);
//     var10.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var24 = var10.getLocale();
//     var10.setPositiveArrowVisible(false);
//     double var27 = var10.getAutoRangeMinimumSize();
//     org.jfree.data.category.CategoryDataset var28 = null;
//     var0.drawItem(var2, var3, var4, var5, var7, (org.jfree.chart.axis.ValueAxis)var10, var28, 4, 3, false, 96);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.data.Range var2 = var1.getRange();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize((-1.99999d), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("null");
    boolean var3 = var1.isHiddenValue(644288400000L);
    boolean var5 = var1.isHiddenValue((-62135740800000L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    float[] var5 = new float[] { 100.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(96, 4, 10, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=0,g=0,b=0]", var1, 2.0f, 0.0f, var4, 0.08d, 1.0f, 10.0f);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var6 = var5.getShadowsVisible();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = null;
    org.jfree.chart.axis.PeriodAxis var10 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var17 = var13.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
    var13.setBaseStroke(var19);
    var10.setMinorTickMarkStroke(var19);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var24 = var23.getOutlineStroke();
    java.awt.geom.Rectangle2D var25 = null;
    var5.drawRangeMarker(var7, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.plot.Marker)var23, var25);
    org.jfree.chart.util.Layer var27 = null;
    boolean var28 = var0.removeDomainMarker((-1), (org.jfree.chart.plot.Marker)var23, var27);
    org.jfree.chart.text.TextAnchor var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.setLabelTextAnchor(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.Paint var1 = var0.getTickLabelPaint();
    java.lang.String var2 = var0.getLabel();
    org.jfree.data.xy.XYDataItem var5 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(byte)(-1), (java.lang.Number)0);
    double var6 = var5.getXValue();
    double var7 = var5.getYValue();
    java.awt.Paint var8 = var0.getTickLabelPaint((java.lang.Comparable)var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    org.jfree.data.xy.XYSeries var12 = null;
    org.jfree.data.xy.XYSeriesCollection var13 = new org.jfree.data.xy.XYSeriesCollection(var12);
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    boolean var16 = var13.hasListener((java.util.EventListener)var15);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.PolarItemRenderer var18 = null;
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var13, var17, var18);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var19);
    var20.clearSubtitles();
    java.awt.RenderingHints var22 = var20.getRenderingHints();
    var20.setBackgroundImageAlpha(10.0f);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.text.NumberFormat var29 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var30 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var31 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var29, var30);
    var27.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator)var31, false);
    org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var42 = var38.getItemFillPaint(1, (-1), false);
    var34.setLabelPaint(var42);
    org.jfree.data.general.PieDataset var44 = var34.getDataset();
    boolean var45 = var34.getSimpleLabels();
    double var46 = var34.getDepthFactor();
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle();
    java.lang.String var49 = var48.getID();
    org.jfree.chart.util.RectangleInsets var50 = var48.getPadding();
    double var52 = var50.extendWidth(10.0d);
    var47.setItemLabelPadding(var50);
    org.jfree.chart.block.BlockContainer var54 = null;
    var47.setWrapper(var54);
    boolean var56 = var31.equals((java.lang.Object)var47);
    org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle();
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.util.HorizontalAlignment var59 = var57.getTextAlignment();
    boolean var61 = var59.equals((java.lang.Object)(-1L));
    var47.setHorizontalAlignment(var59);
    var20.addLegend(var47);
    java.awt.geom.Rectangle2D var64 = var47.getBounds();
    org.jfree.chart.plot.CombinedDomainXYPlot var65 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var67 = var65.getRenderer(0);
    java.util.List var68 = var65.getSubplots();
    org.jfree.chart.axis.PeriodAxis var70 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var73 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var77 = var73.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var78 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var79 = var78.getBaseSectionOutlineStroke();
    var73.setBaseStroke(var79);
    var70.setMinorTickMarkStroke(var79);
    var70.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var84 = var70.getLocale();
    var70.setPositiveArrowVisible(false);
    double var87 = var70.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var88 = new org.jfree.chart.axis.ValueAxis[] { var70};
    var65.setDomainAxes(var88);
    org.jfree.chart.util.RectangleEdge var91 = var65.getRangeAxisEdge(0);
    java.util.List var92 = var0.refreshTicks(var9, var10, var64, var91);
    org.jfree.chart.plot.CombinedDomainXYPlot var93 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    java.awt.Stroke var94 = var93.getRangeGridlineStroke();
    boolean var95 = var93.canSelectByPoint();
    org.jfree.chart.entity.PlotEntity var96 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape)var64, (org.jfree.chart.plot.Plot)var93);
    org.jfree.data.xy.XYDataset var98 = null;
    var93.setDataset(2, var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 12.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    int var3 = var2.getDefaultEntityRadius();
    java.awt.Shape var5 = var2.getSeriesShape(1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
    var9.setSeriesOutlineStroke(0, var12, true);
    var2.setSeriesOutlineStroke(2, var12);
    boolean var16 = var2.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var4 = var3.getItemCount();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(1);
//     java.util.Date var7 = var6.getStart();
//     var3.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)Double.NaN, true);
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var6);
//     java.lang.String var12 = var1.getRangeDescription();
//     java.lang.Comparable var13 = var1.getKey();
//     org.jfree.data.xy.XYSeries var15 = null;
//     org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
//     org.jfree.data.xy.XYSeries var17 = null;
//     org.jfree.data.xy.XYSeriesCollection var18 = new org.jfree.data.xy.XYSeriesCollection(var17);
//     boolean var19 = var16.hasListener((java.util.EventListener)var18);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var21 = null;
//     org.jfree.chart.plot.PolarPlot var22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var16, var20, var21);
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     var25.addCategoryLabelToolTip((java.lang.Comparable)1.0d, "hi!");
//     org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
//     org.jfree.data.xy.XYSeries var31 = null;
//     org.jfree.data.xy.XYSeriesCollection var32 = new org.jfree.data.xy.XYSeriesCollection(var31);
//     org.jfree.data.xy.XYSeries var33 = null;
//     org.jfree.data.xy.XYSeriesCollection var34 = new org.jfree.data.xy.XYSeriesCollection(var33);
//     boolean var35 = var32.hasListener((java.util.EventListener)var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var37 = null;
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var32, var36, var37);
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var38);
//     var39.setAntiAlias(true);
//     java.awt.Image var42 = var39.getBackgroundImage();
//     var29.setChart(var39);
//     org.jfree.chart.event.ChartChangeEventType var44 = var29.getType();
//     java.lang.String var45 = var44.toString();
//     org.jfree.chart.event.ChartChangeEvent var46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var23, var44);
//     
//     // Checks the contract:  equals-hashcode on var22 and var38
//     assertTrue("Contract failed: equals-hashcode on var22 and var38", var22.equals(var38) ? var22.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var22
//     assertTrue("Contract failed: equals-hashcode on var38 and var22", var38.equals(var22) ? var38.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var39
//     assertTrue("Contract failed: equals-hashcode on var23 and var39", var23.equals(var39) ? var23.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var23
//     assertTrue("Contract failed: equals-hashcode on var39 and var23", var39.equals(var23) ? var39.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setIncludeBaseInRange(true);
    double var3 = var0.getMaximumBarWidth();
    java.lang.Object var4 = var0.clone();
    var0.setAutoPopulateSeriesStroke(true);
    org.jfree.chart.plot.CategoryPlot var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPlot(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    org.jfree.chart.axis.TickUnit var8 = var7.getAngleTickUnit();
    double var9 = var8.getSize();
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
    var10.setLabelPaint(var18);
    org.jfree.data.general.PieDataset var20 = var10.getDataset();
    var10.setAutoPopulateSectionOutlinePaint(false);
    float var23 = var10.getBackgroundImageAlpha();
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle();
    java.lang.String var25 = var24.getID();
    org.jfree.chart.util.RectangleInsets var26 = var24.getPadding();
    double var27 = var26.getTop();
    double var28 = var26.getBottom();
    var10.setSimpleLabelOffset(var26);
    int var30 = var8.compareTo((java.lang.Object)var10);
    boolean var31 = var10.getLabelLinksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 45.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.data.xy.XYSeries var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
    org.jfree.data.xy.XYSeries var2 = null;
    org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
    boolean var4 = var1.hasListener((java.util.EventListener)var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.PolarItemRenderer var6 = null;
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
    var7.setForegroundAlpha(100.0f);
    boolean var10 = var7.isAngleLabelsVisible();
    org.jfree.chart.LegendItemCollection var11 = var7.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
//     java.text.NumberFormat var3 = java.text.NumberFormat.getPercentInstance();
//     org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
//     java.text.NumberFormat var5 = var4.getYFormat();
//     java.text.DateFormat var6 = var4.getXDateFormat();
//     org.jfree.chart.urls.StandardXYURLGenerator var10 = new org.jfree.chart.urls.StandardXYURLGenerator("$0.00", "DomainOrder.NONE", "");
//     java.awt.Shape var15 = null;
//     org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var18 = null;
//     org.jfree.data.xy.XYSeriesCollection var19 = new org.jfree.data.xy.XYSeriesCollection(var18);
//     org.jfree.data.xy.XYSeries var20 = null;
//     org.jfree.data.xy.XYSeriesCollection var21 = new org.jfree.data.xy.XYSeriesCollection(var20);
//     boolean var22 = var19.hasListener((java.util.EventListener)var21);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var24 = null;
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var19, var23, var24);
//     java.awt.Paint var26 = var25.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var15, var17, var26);
//     java.lang.String var28 = var27.getDescription();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     boolean var30 = var27.equals((java.lang.Object)var29);
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
//     int var33 = var32.getItemCount();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year(1);
//     java.util.Date var36 = var35.getStart();
//     var32.add((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)Double.NaN, true);
//     org.jfree.data.xy.XYSeries var40 = null;
//     org.jfree.data.xy.XYSeriesCollection var41 = new org.jfree.data.xy.XYSeriesCollection(var40);
//     org.jfree.data.xy.XYSeries var42 = null;
//     org.jfree.data.xy.XYSeriesCollection var43 = new org.jfree.data.xy.XYSeriesCollection(var42);
//     boolean var44 = var41.hasListener((java.util.EventListener)var43);
//     double var45 = var43.getIntervalPositionFactor();
//     var32.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var43);
//     var27.setDataset((org.jfree.data.general.Dataset)var43);
//     java.lang.String var50 = var10.generateURL((org.jfree.data.xy.XYDataset)var43, 100, (-16777216));
//     org.jfree.chart.renderer.xy.XYAreaRenderer var51 = new org.jfree.chart.renderer.xy.XYAreaRenderer(100, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var10);
//     java.awt.Shape var56 = null;
//     org.jfree.chart.plot.PiePlot3D var57 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var58 = var57.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var59 = null;
//     org.jfree.data.xy.XYSeriesCollection var60 = new org.jfree.data.xy.XYSeriesCollection(var59);
//     org.jfree.data.xy.XYSeries var61 = null;
//     org.jfree.data.xy.XYSeriesCollection var62 = new org.jfree.data.xy.XYSeriesCollection(var61);
//     boolean var63 = var60.hasListener((java.util.EventListener)var62);
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var65 = null;
//     org.jfree.chart.plot.PolarPlot var66 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var60, var64, var65);
//     java.awt.Paint var67 = var66.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var56, var58, var67);
//     org.jfree.chart.util.GradientPaintTransformer var69 = var68.getFillPaintTransformer();
//     var51.setGradientTransformer(var69);
//     
//     // Checks the contract:  equals-hashcode on var16 and var57
//     assertTrue("Contract failed: equals-hashcode on var16 and var57", var16.equals(var57) ? var16.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var16
//     assertTrue("Contract failed: equals-hashcode on var57 and var16", var57.equals(var16) ? var57.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var66
//     assertTrue("Contract failed: equals-hashcode on var25 and var66", var25.equals(var66) ? var25.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var25
//     assertTrue("Contract failed: equals-hashcode on var66 and var25", var66.equals(var25) ? var66.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var68
//     assertTrue("Contract failed: equals-hashcode on var27 and var68", var27.equals(var68) ? var27.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var27
//     assertTrue("Contract failed: equals-hashcode on var68 and var27", var68.equals(var27) ? var68.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("$0.00?DomainOrder.NONE=3&amp;=2", var1, 10.0f, (-1.0f), var4, Double.POSITIVE_INFINITY, 100.0f, 10.0f);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Value");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
    boolean var27 = var0.isRangeZoomable();
    var0.clearDomainAxes();
    var0.clearDomainMarkers(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "[-1.0, 0.0]", "hi!", var3, "hi!", "", "[-1.0, 0.0]");
    var7.setCopyright("hi!");
    java.awt.Image var10 = null;
    var7.setLogo(var10);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.general.WaferMapDataset var1 = null;
    var0.setDataset(var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var7 = null;
//     org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
//     org.jfree.data.xy.XYSeries var9 = null;
//     org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
//     boolean var11 = var8.hasListener((java.util.EventListener)var10);
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var13 = null;
//     org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
//     java.awt.Paint var15 = var14.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var4, var6, var15);
//     java.lang.String var17 = var16.getDescription();
//     java.lang.String var18 = var16.getToolTipText();
//     var16.setSeriesIndex(1);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
//     var16.setLine(var22);
//     org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var32 = var28.getItemFillPaint(1, (-1), false);
//     var24.setLabelPaint(var32);
//     org.jfree.chart.event.ChartChangeEvent var34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var24);
//     org.jfree.chart.urls.PieURLGenerator var35 = var24.getURLGenerator();
//     var24.setDarkerSides(true);
//     var24.clearSectionPaints(false);
//     var24.setCircular(false);
//     org.jfree.chart.entity.PlotEntity var43 = new org.jfree.chart.entity.PlotEntity(var22, (org.jfree.chart.plot.Plot)var24, "December 2014");
//     org.jfree.chart.plot.CombinedDomainXYPlot var44 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = var44.getRenderer(0);
//     java.awt.Paint var47 = var44.getDomainCrosshairPaint();
//     java.awt.Paint var48 = var44.getRangeMinorGridlinePaint();
//     java.awt.Paint var49 = var44.getNoDataMessagePaint();
//     boolean var50 = var44.isRangeGridlinesVisible();
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.data.Range var52 = var44.getDataRange(var51);
//     org.jfree.chart.axis.PeriodAxis var55 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var58 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var62 = var58.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var63 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var64 = var63.getBaseSectionOutlineStroke();
//     var58.setBaseStroke(var64);
//     var55.setMinorTickMarkStroke(var64);
//     var55.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var69 = var55.getLocale();
//     var55.setPositiveArrowVisible(false);
//     var44.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var55, false);
//     org.jfree.chart.entity.PlotEntity var76 = new org.jfree.chart.entity.PlotEntity(var22, (org.jfree.chart.plot.Plot)var44, "Combined_Domain_XYPlot", "java.awt.Color[r=0,g=0,b=0]");
//     
//     // Checks the contract:  equals-hashcode on var5 and var63
//     assertTrue("Contract failed: equals-hashcode on var5 and var63", var5.equals(var63) ? var5.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var5
//     assertTrue("Contract failed: equals-hashcode on var63 and var5", var63.equals(var5) ? var63.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var4.setBaseStroke(var10);
//     var1.setMinorTickMarkStroke(var10);
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     org.jfree.data.xy.XYSeries var15 = null;
//     org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
//     boolean var17 = var14.hasListener((java.util.EventListener)var16);
//     boolean var18 = var1.equals((java.lang.Object)var17);
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var20 = var19.getID();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getPadding();
//     var1.setLabelInsets(var21);
//     org.jfree.chart.plot.PiePlot3D var23 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
//     var23.setLabelPaint(var31);
//     org.jfree.data.general.PieDataset var33 = var23.getDataset();
//     boolean var34 = var23.getSimpleLabels();
//     double var35 = var23.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
//     java.lang.Object var37 = var36.clone();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getMargin();
//     double var40 = var38.extendHeight(Double.NaN);
//     var1.setLabelInsets(var38);
//     double var42 = var38.getLeft();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0.0d);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var2 = var1.getOutlineStroke();
    double var3 = var1.getValue();
    java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var8 = var7.getRGB();
    java.lang.String var9 = var7.toString();
    var1.setLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.util.LengthAdjustmentType var11 = var1.getLabelOffsetType();
    org.jfree.chart.text.TextAnchor var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var9.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     var0.setLabelPaint(var8);
//     org.jfree.data.general.PieDataset var10 = var0.getDataset();
//     boolean var11 = var0.getSimpleLabels();
//     double var12 = var0.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.lang.Object var14 = var13.clone();
//     org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
//     var15.setLabelPaint(var23);
//     org.jfree.data.general.PieDataset var25 = var15.getDataset();
//     boolean var26 = var15.getSimpleLabels();
//     double var27 = var15.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var30 = var29.getID();
//     org.jfree.chart.util.RectangleInsets var31 = var29.getPadding();
//     double var33 = var31.extendWidth(10.0d);
//     var28.setItemLabelPadding(var31);
//     org.jfree.chart.block.BlockContainer var35 = null;
//     var28.setWrapper(var35);
//     org.jfree.chart.util.RectangleAnchor var37 = var28.getLegendItemGraphicLocation();
//     var13.setLegendItemGraphicAnchor(var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    java.awt.Paint var1 = var0.getAggregatedItemsPaint();
    java.awt.Shape var2 = var0.getLegendItemShape();
    org.jfree.data.xy.XYSeries var4 = null;
    org.jfree.data.xy.XYSeriesCollection var5 = new org.jfree.data.xy.XYSeriesCollection(var4);
    org.jfree.data.xy.XYSeries var6 = null;
    org.jfree.data.xy.XYSeriesCollection var7 = new org.jfree.data.xy.XYSeriesCollection(var6);
    boolean var8 = var5.hasListener((java.util.EventListener)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.PolarItemRenderer var10 = null;
    org.jfree.chart.plot.PolarPlot var11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var5, var9, var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var11);
    var12.clearSubtitles();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPieChart(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    java.util.List var9 = var1.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var1.getValue((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.resizeRange2(100.0d, 4.0d);
    var0.setRangeAboutValue(0.08d, 4.0d);
    org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var15 = var11.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var16 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
    var11.setBaseStroke(var17);
    var8.setMinorTickMarkStroke(var17);
    double var20 = var8.getUpperMargin();
    java.util.Locale var21 = var8.getLocale();
    org.jfree.chart.axis.TickUnitSource var22 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var21);
    var0.setStandardTickUnits(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var1.setBarPainter(var26);
//     org.jfree.data.xy.XYSeries var28 = null;
//     org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     boolean var32 = var29.hasListener((java.util.EventListener)var31);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var29, var33, var34);
//     var35.setForegroundAlpha(100.0f);
//     var35.setAngleGridlinesVisible(true);
//     java.awt.Paint var40 = var35.getBackgroundPaint();
//     var1.setGridBandAlternatePaint(var40);
//     org.jfree.chart.plot.DrawingSupplier var42 = var1.getDrawingSupplier();
//     org.jfree.chart.renderer.xy.XYBarRenderer var43 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var44 = var43.getNegativeItemLabelPositionFallback();
//     var43.setShadowVisible(true);
//     double var47 = var43.getBarAlignmentFactor();
//     org.jfree.chart.util.GradientPaintTransformer var48 = null;
//     var43.setGradientPaintTransformer(var48);
//     org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = var51.getRenderer(0);
//     java.util.List var54 = var51.getSubplots();
//     org.jfree.chart.axis.PeriodAxis var56 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var59 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var63 = var59.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var64 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var65 = var64.getBaseSectionOutlineStroke();
//     var59.setBaseStroke(var65);
//     var56.setMinorTickMarkStroke(var65);
//     var56.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var70 = var56.getLocale();
//     var56.setPositiveArrowVisible(false);
//     double var73 = var56.getAutoRangeMinimumSize();
//     org.jfree.chart.axis.ValueAxis[] var74 = new org.jfree.chart.axis.ValueAxis[] { var56};
//     var51.setDomainAxes(var74);
//     org.jfree.chart.plot.CombinedDomainXYPlot var76 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var78 = var76.getRenderer(0);
//     java.util.List var79 = var76.getSubplots();
//     org.jfree.chart.axis.AxisSpace var80 = new org.jfree.chart.axis.AxisSpace();
//     var76.setFixedRangeAxisSpace(var80, false);
//     var51.setFixedRangeAxisSpace(var80);
//     java.awt.Color var87 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
//     int var88 = var87.getRGB();
//     int var89 = var87.getAlpha();
//     var51.setDomainGridlinePaint((java.awt.Paint)var87);
//     var43.setSeriesFillPaint(2, (java.awt.Paint)var87, true);
//     var1.setItemLabelPaint((java.awt.Paint)var87);
//     
//     // Checks the contract:  equals-hashcode on var19 and var64
//     assertTrue("Contract failed: equals-hashcode on var19 and var64", var19.equals(var64) ? var19.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var19
//     assertTrue("Contract failed: equals-hashcode on var64 and var19", var64.equals(var19) ? var64.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getAxisOffset();
    org.jfree.chart.plot.DrawingSupplier var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDrawingSupplier(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    var0.clearSectionOutlinePaints(false);
    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder();
    boolean var5 = var0.equals((java.lang.Object)var4);
    java.awt.Stroke var6 = var0.getBaseSectionOutlineStroke();
    var0.setMinimumArcAngleToDraw(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("December 2014");
    var3.setLabelURL("$0.00?DomainOrder.NONE=3&amp;=2");
    java.awt.Font var6 = var3.getTickLabelFont();
    org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var6);
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
    var8.clearSectionOutlinePaints(false);
    double var12 = var8.getMaximumLabelWidth();
    java.awt.Paint var13 = null;
    var8.setLabelShadowPaint(var13);
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("$0.00?DomainOrder.NONE=3&amp;=2", var6, (org.jfree.chart.plot.Plot)var8, false);
    org.jfree.chart.labels.PieSectionLabelGenerator var17 = var8.getLegendLabelToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("[-1.0, 0.0]");
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.xy.XYSeries var1 = null;
    org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
    org.jfree.data.xy.XYSeries var3 = null;
    org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
    boolean var5 = var2.hasListener((java.util.EventListener)var4);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
    var9.setAntiAlias(true);
    var9.removeLegend();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    var15.setBaseSeriesVisible(false, false);
    java.awt.Paint var20 = var15.lookupSeriesFillPaint(3);
    var9.setBorderPaint(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
//     org.jfree.data.general.DefaultPieDataset var1 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues)var0);
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset)var1);
//     org.jfree.data.xy.XYSeries var3 = null;
//     org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
//     org.jfree.data.xy.XYSeries var5 = null;
//     org.jfree.data.xy.XYSeriesCollection var6 = new org.jfree.data.xy.XYSeriesCollection(var5);
//     boolean var7 = var4.hasListener((java.util.EventListener)var6);
//     double var9 = var6.getDomainUpperBound(true);
//     boolean var10 = var2.equals((java.lang.Object)true);
//     org.jfree.chart.axis.PeriodAxis var12 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var19 = var15.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var20 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var15.setBaseStroke(var21);
//     var12.setMinorTickMarkStroke(var21);
//     var12.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
//     java.util.Locale var26 = var12.getLocale();
//     org.jfree.chart.axis.TickUnitSource var27 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var26);
//     org.jfree.chart.labels.StandardPieToolTipGenerator var28 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var26);
//     java.lang.Object var29 = var28.clone();
//     java.lang.Object var30 = var28.clone();
//     var2.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator)var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = var1.getRenderer(0);
//     java.awt.Paint var4 = var1.getDomainCrosshairPaint();
//     java.awt.Paint var5 = var1.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var6 = var1.getDomainAxisLocation();
//     java.awt.Paint var7 = var1.getDomainZeroBaselinePaint();
//     var0.setRangeTickBandPaint(var7);
//     org.jfree.chart.plot.CombinedDomainXYPlot var9 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = var10.getRenderer(0);
//     java.awt.Paint var13 = var10.getDomainCrosshairPaint();
//     java.awt.Paint var14 = var10.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var15 = var10.getDomainAxisLocation();
//     java.awt.Paint var16 = var10.getDomainZeroBaselinePaint();
//     var9.setRangeTickBandPaint(var16);
//     org.jfree.chart.axis.ValueAxis var19 = var9.getRangeAxisForDataset(0);
//     org.jfree.chart.event.PlotChangeEvent var20 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.plot.Plot var21 = var20.getPlot();
//     var0.plotChanged(var20);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var4.setBaseStroke(var10);
//     var1.setMinorTickMarkStroke(var10);
//     java.awt.Shape var13 = var1.getDownArrow();
//     org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var23 = var19.getItemFillPaint(1, (-1), false);
//     var15.setLabelPaint(var23);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var31 = var27.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var32 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     var27.setBaseStroke(var33);
//     var15.setLabelOutlineStroke(var33);
//     double var36 = var15.getInteriorGap();
//     java.awt.Paint var37 = var15.getLabelShadowPaint();
//     java.awt.Font var38 = var15.getLabelFont();
//     org.jfree.chart.plot.CombinedDomainXYPlot var39 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = var40.getRenderer(0);
//     java.awt.Paint var43 = var40.getDomainCrosshairPaint();
//     java.awt.Paint var44 = var40.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var45 = var40.getDomainAxisLocation();
//     java.awt.Paint var46 = var40.getDomainZeroBaselinePaint();
//     var39.setRangeTickBandPaint(var46);
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("Pie 3D Plot", var38, var46, 0.0f);
//     var1.setLabelFont(var38);
//     
//     // Checks the contract:  equals-hashcode on var9 and var32
//     assertTrue("Contract failed: equals-hashcode on var9 and var32", var9.equals(var32) ? var9.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var9
//     assertTrue("Contract failed: equals-hashcode on var32 and var9", var32.equals(var9) ? var32.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.data.xy.XYSeries var0 = null;
//     org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection(var0);
//     org.jfree.data.xy.XYSeries var2 = null;
//     org.jfree.data.xy.XYSeriesCollection var3 = new org.jfree.data.xy.XYSeriesCollection(var2);
//     boolean var4 = var1.hasListener((java.util.EventListener)var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var1, var5, var6);
//     org.jfree.chart.axis.TickUnit var8 = var7.getAngleTickUnit();
//     java.awt.Paint var9 = var7.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItemCollection var10 = var7.getLegendItems();
//     java.util.Iterator var11 = var10.iterator();
//     java.lang.Object var12 = null;
//     boolean var13 = var10.equals(var12);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var17 = var16.getDefaultEntityRadius();
//     java.awt.Shape var19 = var16.getSeriesShape(1);
//     org.jfree.chart.LegendItemCollection var20 = var16.getLegendItems();
//     var10.addAll(var20);
//     
//     // Checks the contract:  equals-hashcode on var10 and var20
//     assertTrue("Contract failed: equals-hashcode on var10 and var20", var10.equals(var20) ? var10.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var10
//     assertTrue("Contract failed: equals-hashcode on var20 and var10", var20.equals(var10) ? var20.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("[-1.0, 0.0]");
    float var2 = var1.getMinorTickMarkOutsideLength();
    java.awt.Shape var3 = var1.getLeftArrow();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.data.xy.XYSeries var7 = null;
    org.jfree.data.xy.XYSeriesCollection var8 = new org.jfree.data.xy.XYSeriesCollection(var7);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    boolean var11 = var8.hasListener((java.util.EventListener)var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.PolarItemRenderer var13 = null;
    org.jfree.chart.plot.PolarPlot var14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var8, var12, var13);
    org.jfree.chart.axis.TickUnit var15 = var14.getAngleTickUnit();
    double var16 = var15.getSize();
    java.lang.Comparable var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var18 = new org.jfree.chart.entity.CategoryItemEntity(var3, "", "Value", var6, (java.lang.Comparable)var15, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 45.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    org.jfree.chart.util.RectangleEdge var26 = var0.getRangeAxisEdge(0);
    org.jfree.data.xy.XYSeries var28 = null;
    org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
    org.jfree.data.xy.XYSeries var30 = null;
    org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
    boolean var32 = var29.hasListener((java.util.EventListener)var31);
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.PolarItemRenderer var34 = null;
    org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var29, var33, var34);
    org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var35);
    boolean var37 = var0.equals((java.lang.Object)"");
    org.jfree.chart.axis.AxisLocation var39 = var0.getDomainAxisLocation(10);
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var42 = var41.getLabelAnchor();
    org.jfree.chart.util.Layer var43 = null;
    boolean var44 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var41, var43);
    java.awt.Paint var45 = var0.getRangeTickBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
    java.lang.String var4 = var3.getDomainDescription();
    var3.removeAgedItems(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var3.getTimePeriod(96);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Time"+ "'", var4.equals("Time"));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Value");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getPercentInstance();
    java.text.NumberFormat var2 = java.text.NumberFormat.getPercentInstance();
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    java.text.NumberFormat var4 = var3.getXFormat();
    java.lang.String var5 = var3.getFormatString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var9.clearSectionOutlinePaints(false);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder();
    boolean var14 = var9.equals((java.lang.Object)var13);
    java.awt.Paint var15 = var9.getBaseSectionOutlinePaint();
    var2.setWallPaint(var15);
    org.jfree.chart.plot.CategoryPlot var17 = var2.getPlot();
    var2.setBaseSeriesVisible(false);
    org.jfree.chart.LegendItemCollection var20 = var2.getLegendItems();
    int var21 = var20.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var1.setBarPainter(var26);
//     org.jfree.data.xy.XYSeries var28 = null;
//     org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection(var28);
//     org.jfree.data.xy.XYSeries var30 = null;
//     org.jfree.data.xy.XYSeriesCollection var31 = new org.jfree.data.xy.XYSeriesCollection(var30);
//     boolean var32 = var29.hasListener((java.util.EventListener)var31);
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var34 = null;
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var29, var33, var34);
//     var35.setForegroundAlpha(100.0f);
//     var35.setAngleGridlinesVisible(true);
//     java.awt.Paint var40 = var35.getBackgroundPaint();
//     var1.setGridBandAlternatePaint(var40);
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//     var1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var42);
//     org.jfree.chart.plot.PiePlot3D var44 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var52 = var48.getItemFillPaint(1, (-1), false);
//     var44.setLabelPaint(var52);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var56 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var60 = var56.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var61 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var62 = var61.getBaseSectionOutlineStroke();
//     var56.setBaseStroke(var62);
//     var44.setLabelOutlineStroke(var62);
//     boolean var66 = var44.equals((java.lang.Object)'4');
//     org.jfree.chart.plot.PieLabelLinkStyle var67 = var44.getLabelLinkStyle();
//     java.lang.String var68 = var67.toString();
//     var1.setLabelLinkStyle(var67);
//     
//     // Checks the contract:  equals-hashcode on var2 and var44
//     assertTrue("Contract failed: equals-hashcode on var2 and var44", var2.equals(var44) ? var2.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var61
//     assertTrue("Contract failed: equals-hashcode on var19 and var61", var19.equals(var61) ? var19.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var2
//     assertTrue("Contract failed: equals-hashcode on var44 and var2", var44.equals(var2) ? var44.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var19
//     assertTrue("Contract failed: equals-hashcode on var61 and var19", var61.equals(var19) ? var61.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.event.PlotChangeEvent var1 = null;
    var0.plotChanged(var1);
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var5 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var5.getRenderer(0);
    java.awt.Paint var8 = var5.getDomainCrosshairPaint();
    java.awt.Paint var9 = var5.getRangeMinorGridlinePaint();
    java.awt.Paint var10 = var5.getNoDataMessagePaint();
    boolean var11 = var5.isRangeGridlinesVisible();
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.plot.CrosshairState var14 = new org.jfree.chart.plot.CrosshairState();
    org.jfree.chart.plot.PlotOrientation var21 = null;
    var14.updateCrosshairPoint(0.0d, 1.0d, 2, 1, 0.0d, 4.0d, var21);
    org.jfree.data.xy.XYSeries var23 = null;
    org.jfree.data.xy.XYSeriesCollection var24 = new org.jfree.data.xy.XYSeriesCollection(var23);
    org.jfree.data.xy.XYSeries var25 = null;
    org.jfree.data.xy.XYSeriesCollection var26 = new org.jfree.data.xy.XYSeriesCollection(var25);
    boolean var27 = var24.hasListener((java.util.EventListener)var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.PolarItemRenderer var29 = null;
    org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var24, var28, var29);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.util.RectangleAnchor var35 = null;
    java.awt.geom.Point2D var36 = org.jfree.chart.util.RectangleAnchor.coordinates(var34, var35);
    var30.zoomDomainAxes(100.0d, (-1.0d), var33, var36);
    var14.setAnchor(var36);
    var5.panRangeAxes(10.0d, var13, var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomDomainAxes((-1.99999d), var4, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    java.util.List var9 = var1.getItems();
    boolean var10 = var1.getNotify();
    org.jfree.data.time.RegularTimePeriod var11 = null;
    org.jfree.chart.axis.PeriodAxis var13 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var20 = var16.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var21 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
    var16.setBaseStroke(var22);
    var13.setMinorTickMarkStroke(var22);
    var13.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var27 = var13.getLocale();
    var13.setPositiveArrowVisible(false);
    double var30 = var13.getAutoRangeMinimumSize();
    org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var32 = var31.previous();
    var13.setFirst((org.jfree.data.time.RegularTimePeriod)var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var34 = var1.createCopy(var11, (org.jfree.data.time.RegularTimePeriod)var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 10.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-237));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var0, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var2.getEndX((-16777216), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var9 = var5.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    var5.setBaseStroke(var11);
    var2.setMinorTickMarkStroke(var11);
    org.jfree.data.xy.XYSeries var14 = null;
    org.jfree.data.xy.XYSeriesCollection var15 = new org.jfree.data.xy.XYSeriesCollection(var14);
    org.jfree.data.xy.XYSeries var16 = null;
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection(var16);
    boolean var18 = var15.hasListener((java.util.EventListener)var17);
    boolean var19 = var2.equals((java.lang.Object)var18);
    java.lang.Class var20 = var2.getMinorTickTimePeriodClass();
    java.io.InputStream var21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     int var3 = var2.getDefaultEntityRadius();
//     java.awt.Shape var5 = var2.getSeriesShape(1);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
//     var9.setSeriesOutlineStroke(0, var12, true);
//     var2.setSeriesOutlineStroke(2, var12);
//     org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var25 = var21.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     var21.setBaseStroke(var27);
//     var18.setMinorTickMarkStroke(var27);
//     org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange();
//     var18.setRangeWithMargins((org.jfree.data.Range)var30);
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var18.java2DToValue(0.08d, var33, var34);
//     var18.setAutoRange(false);
//     java.awt.Font var38 = var18.getTickLabelFont();
//     var2.setLegendTextFont(1969, var38);
//     
//     // Checks the contract:  equals-hashcode on var11 and var26
//     assertTrue("Contract failed: equals-hashcode on var11 and var26", var11.equals(var26) ? var11.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var11
//     assertTrue("Contract failed: equals-hashcode on var26 and var11", var26.equals(var11) ? var26.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.data.general.PieDataset var10 = var0.getDataset();
    boolean var11 = var0.getSimpleLabels();
    double var12 = var0.getDepthFactor();
    org.jfree.chart.urls.PieURLGenerator var13 = var0.getLegendLabelURLGenerator();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.lang.String var15 = var14.getID();
    org.jfree.chart.util.RectangleInsets var16 = var14.getPadding();
    var0.setSimpleLabelOffset(var16);
    org.jfree.chart.plot.AbstractPieLabelDistributor var18 = var0.getLabelDistributor();
    org.jfree.chart.plot.PieLabelRecord var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.addPieLabelRecord(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.5d, 1.0E-8d);
    org.jfree.chart.plot.CategoryPlot var3 = var2.getPlot();
    org.jfree.chart.plot.CategoryPlot var4 = var2.getPlot();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var2.setSeriesURLGenerator(2, var6, true);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var2.setSeriesURLGenerator(10, var10);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var2.getBaseItemLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setPlot(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var2 = var0.getRenderer(0);
    java.util.List var3 = var0.getSubplots();
    org.jfree.chart.axis.PeriodAxis var5 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var12 = var8.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var8.setBaseStroke(var14);
    var5.setMinorTickMarkStroke(var14);
    var5.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var19 = var5.getLocale();
    var5.setPositiveArrowVisible(false);
    double var22 = var5.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var23);
    double var25 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = var29.getRenderer(0);
    java.util.List var32 = var29.getSubplots();
    org.jfree.chart.axis.PeriodAxis var34 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var41 = var37.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var42 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var43 = var42.getBaseSectionOutlineStroke();
    var37.setBaseStroke(var43);
    var34.setMinorTickMarkStroke(var43);
    var34.setLabelToolTip("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    java.util.Locale var48 = var34.getLocale();
    var34.setPositiveArrowVisible(false);
    double var51 = var34.getAutoRangeMinimumSize();
    org.jfree.chart.axis.ValueAxis[] var52 = new org.jfree.chart.axis.ValueAxis[] { var34};
    var29.setDomainAxes(var52);
    org.jfree.chart.plot.CombinedDomainXYPlot var54 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.renderer.xy.XYItemRenderer var56 = var54.getRenderer(0);
    java.util.List var57 = var54.getSubplots();
    org.jfree.chart.axis.AxisSpace var58 = new org.jfree.chart.axis.AxisSpace();
    var54.setFixedRangeAxisSpace(var58, false);
    var29.setFixedRangeAxisSpace(var58);
    java.awt.Color var65 = java.awt.Color.getHSBColor(1.0f, 0.0f, 0.0f);
    int var66 = var65.getRGB();
    int var67 = var65.getAlpha();
    var29.setDomainGridlinePaint((java.awt.Paint)var65);
    org.jfree.chart.plot.IntervalMarker var69 = new org.jfree.chart.plot.IntervalMarker(4.0d, 0.025d, (java.awt.Paint)var65);
    double var70 = var69.getStartValue();
    org.jfree.chart.util.Layer var71 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var69, var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 4.0d);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(1);
//     long var3 = var2.getLastMillisecond();
//     java.awt.Shape var8 = null;
//     org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYSeries var11 = null;
//     org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
//     org.jfree.data.xy.XYSeries var13 = null;
//     org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
//     boolean var15 = var12.hasListener((java.util.EventListener)var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var17 = null;
//     org.jfree.chart.plot.PolarPlot var18 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, var16, var17);
//     java.awt.Paint var19 = var18.getRadiusGridlinePaint();
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "Pie 3D Plot", "", "$0.00", var8, var10, var19);
//     var0.setTickLabelPaint((java.lang.Comparable)var3, var19);
//     var0.setTickMarkOutsideLength(10.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-62104204800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.data.xy.XYSeries var1 = null;
//     org.jfree.data.xy.XYSeriesCollection var2 = new org.jfree.data.xy.XYSeriesCollection(var1);
//     org.jfree.data.xy.XYSeries var3 = null;
//     org.jfree.data.xy.XYSeriesCollection var4 = new org.jfree.data.xy.XYSeriesCollection(var3);
//     boolean var5 = var2.hasListener((java.util.EventListener)var4);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var2, var6, var7);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var8);
//     var9.setAntiAlias(true);
//     java.awt.Image var12 = var9.getBackgroundImage();
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var21 = var17.getItemFillPaint(1, (-1), false);
//     var13.setLabelPaint(var21);
//     org.jfree.data.general.PieDataset var23 = var13.getDataset();
//     boolean var24 = var13.getSimpleLabels();
//     double var25 = var13.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     java.lang.Object var27 = var26.clone();
//     var9.addSubtitle((org.jfree.chart.title.Title)var26);
//     float var29 = var9.getBackgroundImageAlpha();
//     org.jfree.chart.plot.PiePlot3D var30 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var38 = var34.getItemFillPaint(1, (-1), false);
//     var30.setLabelPaint(var38);
//     org.jfree.data.general.PieDataset var40 = var30.getDataset();
//     boolean var41 = var30.getSimpleLabels();
//     double var42 = var30.getDepthFactor();
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var45 = var44.getID();
//     org.jfree.chart.util.RectangleInsets var46 = var44.getPadding();
//     double var48 = var46.extendWidth(10.0d);
//     var43.setItemLabelPadding(var46);
//     org.jfree.chart.block.BlockContainer var50 = null;
//     var43.setWrapper(var50);
//     boolean var52 = var43.isVisible();
//     var9.addSubtitle((org.jfree.chart.title.Title)var43);
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var1 = var0.getBaseSectionOutlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    var0.setLabelPaint(var8);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var16 = var12.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var17 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
    var12.setBaseStroke(var18);
    var0.setLabelOutlineStroke(var18);
    double var21 = var0.getInteriorGap();
    java.awt.Paint var22 = var0.getLabelShadowPaint();
    java.awt.Font var23 = var0.getLabelFont();
    var0.setAutoPopulateSectionOutlineStroke(true);
    double var26 = var0.getMaximumLabelWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.14d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var8 = var4.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var9 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var4.setBaseStroke(var10);
    var1.setMinorTickMarkStroke(var10);
    org.jfree.data.xy.XYSeries var13 = null;
    org.jfree.data.xy.XYSeriesCollection var14 = new org.jfree.data.xy.XYSeriesCollection(var13);
    org.jfree.data.xy.XYSeries var15 = null;
    org.jfree.data.xy.XYSeriesCollection var16 = new org.jfree.data.xy.XYSeriesCollection(var15);
    boolean var17 = var14.hasListener((java.util.EventListener)var16);
    boolean var18 = var1.equals((java.lang.Object)var17);
    var1.setLabelURL("");
    org.jfree.data.time.RegularTimePeriod var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setFirst(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0.08d);
    int var2 = var1.getItemCount();
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(1);
    java.util.Date var5 = var4.getStart();
    var1.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)Double.NaN, true);
    org.jfree.data.xy.XYSeries var9 = null;
    org.jfree.data.xy.XYSeriesCollection var10 = new org.jfree.data.xy.XYSeriesCollection(var9);
    org.jfree.data.xy.XYSeries var11 = null;
    org.jfree.data.xy.XYSeriesCollection var12 = new org.jfree.data.xy.XYSeriesCollection(var11);
    boolean var13 = var10.hasListener((java.util.EventListener)var12);
    double var14 = var12.getIntervalPositionFactor();
    var1.removeChangeListener((org.jfree.data.general.SeriesChangeListener)var12);
    org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var12);
    org.jfree.chart.axis.PeriodAxis var18 = new org.jfree.chart.axis.PeriodAxis("");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
    java.awt.Paint var25 = var21.getItemFillPaint(1, (-1), false);
    org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
    var21.setBaseStroke(var27);
    var18.setMinorTickMarkStroke(var27);
    org.jfree.chart.renderer.PolarItemRenderer var30 = null;
    org.jfree.chart.plot.PolarPlot var31 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var12, (org.jfree.chart.axis.ValueAxis)var18, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var34 = var12.getStartX(68, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("[-1.0, 0.0]");
//     org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var10 = var6.getItemFillPaint(1, (-1), false);
//     var2.setLabelPaint(var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var18 = var14.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var19 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var14.setBaseStroke(var20);
//     var2.setLabelOutlineStroke(var20);
//     double var23 = var2.getInteriorGap();
//     java.awt.Paint var24 = var2.getLabelShadowPaint();
//     var1.setPlotOutlinePaint(var24);
//     org.jfree.chart.renderer.category.BarPainter var26 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var1.setBarPainter(var26);
//     java.awt.Paint var28 = var1.getErrorIndicatorPaint();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
//     java.awt.Paint var35 = var31.getItemFillPaint(1, (-1), false);
//     org.jfree.chart.plot.PiePlot3D var36 = new org.jfree.chart.plot.PiePlot3D();
//     java.awt.Stroke var37 = var36.getBaseSectionOutlineStroke();
//     var31.setBaseStroke(var37);
//     org.jfree.chart.labels.XYItemLabelGenerator var39 = var31.getBaseItemLabelGenerator();
//     boolean var41 = var31.equals((java.lang.Object)(short)100);
//     java.awt.Paint var45 = var31.getItemOutlinePaint(2, 2, true);
//     var1.setCrosshairPaint(var45);
//     
//     // Checks the contract:  equals-hashcode on var19 and var36
//     assertTrue("Contract failed: equals-hashcode on var19 and var36", var19.equals(var36) ? var19.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var19
//     assertTrue("Contract failed: equals-hashcode on var36 and var19", var36.equals(var19) ? var36.hashCode() == var19.hashCode() : true);
// 
//   }

}
