
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var4 = new org.jfree.chart.entity.AxisLabelEntity(var0, var1, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, 100.0f, 100.0f, var4);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("hi!", var1, var2, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 10.0f);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, 1.0f, 100.0d, (-1.0f), 100.0f);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0d, 100.0f, 10.0f);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Paint var7 = null;
    java.awt.Paint var9 = null;
    java.awt.Stroke var10 = null;
    java.awt.Shape var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "", "", "hi!", false, var5, false, var7, true, var9, var10, false, var12, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    java.awt.Stroke var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeCrosshairStroke(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.awt.Shape var0 = null;
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var2 = new org.jfree.chart.title.LegendGraphic(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.TickUnit var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(var1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.axis.AxisLocation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 1, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 10.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("Category Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Category Plot", var1);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Point2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.getSubplotIndex(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.LegendItemEntity var1 = new org.jfree.chart.entity.LegendItemEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.util.RectangleEdge var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.ensureAtLeast(0.0d, var2);
      fail("Expected exception of type java.lang.IllegalStateException");
    } catch (java.lang.IllegalStateException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    org.jfree.chart.axis.Axis var1 = null;
    org.jfree.chart.util.RectangleEdge var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 0);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100.0f};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 10.0d};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.TickUnit var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getLargerTickUnit(var1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
    org.jfree.chart.util.RectangleEdge var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = var1.getLabelPosition(var2);
    org.jfree.chart.axis.CategoryLabelPosition var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 100.0d, 0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearRangeMarkers(0);
//     float var7 = var4.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     java.lang.String var10 = var4.getPlotType();
//     org.jfree.chart.util.RectangleInsets var11 = var4.getInsets();
//     var0.setInsets(var11, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Category Plot", var1);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.RectangleInsets var7 = var0.getInsets();
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var7.createOutsetRectangle(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearDomainAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var1 = null;
    var0.removeChangeListener(var1);
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.clearRangeMarkers(0);
    float var5 = var2.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var6 = null;
    int var7 = var2.getDomainAxisIndex(var6);
    java.lang.String var8 = var2.getPlotType();
    org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var10.setRenderer(0, var12, true);
    java.awt.Paint var15 = var10.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var9, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("Category Plot", var1, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Category Plot"+ "'", var8.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.plot.CategoryMarker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(10, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.event.TitleChangeEvent var5 = null;
//     var4.titleChanged(var5);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.Marker var8 = null;
//     org.jfree.chart.util.Layer var9 = null;
//     var0.addRangeMarker(var8, var9);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearRangeMarkers(0);
//     float var8 = var5.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     int var10 = var5.getDomainAxisIndex(var9);
//     java.lang.String var11 = var5.getPlotType();
//     org.jfree.chart.util.RectangleInsets var12 = var5.getInsets();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     var13.setRenderer(0, var15, true);
//     java.awt.Paint var18 = var13.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var12, var18);
//     var4.setPadding(var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)'a');
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Category Plot", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    boolean var5 = var4.isRangeCrosshairLockedOnData();
    org.jfree.chart.plot.CategoryMarker var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     org.jfree.chart.ChartRenderingInfo var2 = var1.getOwner();
//     java.awt.geom.Rectangle2D var3 = var1.getPlotArea();
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     var1.setDataArea(var6);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.axis.AxisLocation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.awt.Font var1 = null;
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var3 = var2.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("Category Plot", var1, var3, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var4.removeLegend();
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 1.0d);
    org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedHeight(0.0d);
    boolean var13 = var4.equals((java.lang.Object)var10);
    org.jfree.chart.event.ChartChangeListener var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addChangeListener(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getPaint();
    java.awt.Stroke var2 = null;
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.clearRangeMarkers(0);
    float var6 = var3.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    int var8 = var3.getDomainAxisIndex(var7);
    java.lang.String var9 = var3.getPlotType();
    org.jfree.chart.util.RectangleInsets var10 = var3.getInsets();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    var11.setRenderer(0, var13, true);
    java.awt.Paint var16 = var11.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var10, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var18 = new org.jfree.chart.block.LineBorder(var1, var2, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Category Plot"+ "'", var9.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     var4.setDataset(10, var6);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearRangeMarkers(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.clearRangeMarkers(0);
//     float var19 = var16.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
//     var20.removeLegend();
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var28 = var26.toFixedHeight(0.0d);
//     boolean var29 = var20.equals((java.lang.Object)var26);
//     var15.setChart(var20);
//     
//     // Checks the contract:  equals-hashcode on var8 and var16
//     assertTrue("Contract failed: equals-hashcode on var8 and var16", var8.equals(var16) ? var8.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var8
//     assertTrue("Contract failed: equals-hashcode on var16 and var8", var16.equals(var8) ? var16.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePaint(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var4.removeProgressListener(var5);
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Rectangle2D var9 = var8.getDataArea();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var9, 1.0d, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTextAntiAlias((java.lang.Object)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var1, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.axis.AxisLocation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(0, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, 0.0f, 0.5f, var4);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var5 = var4.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 4.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    java.lang.String var1 = var0.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "NOID"+ "'", var1.equals("NOID"));

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    java.util.List var2 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
    org.jfree.chart.util.RectangleEdge var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = var1.getLabelPosition(var2);
    org.jfree.chart.axis.CategoryLabelPosition var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setDrawBarOutline(true);
    java.awt.Font var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelFont((-1), var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("NOID", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    java.awt.Font var1 = null;
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var3 = var2.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("", var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.ChartRenderingInfo var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var9 = var4.createBufferedImage((-1), 100, 100, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    int var9 = var0.getWeight();
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var11 = var0.removeAnnotation(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var3 = var2.getFont();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearRangeMarkers(0);
//     float var7 = var4.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     java.lang.String var10 = var4.getPlotType();
//     org.jfree.chart.util.RectangleInsets var11 = var4.getInsets();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var12.setRenderer(0, var14, true);
//     java.awt.Paint var17 = var12.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(var11, var17);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.text.G2TextMeasurer var21 = new org.jfree.chart.text.G2TextMeasurer(var20);
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("NOID", var3, var17, 10.0f, (org.jfree.chart.text.TextMeasurer)var21);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
    java.lang.String var7 = var6.toString();
    org.jfree.chart.plot.PlotOrientation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var6, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "AxisLocation.TOP_OR_LEFT"+ "'", var7.equals("AxisLocation.TOP_OR_LEFT"));

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING", var1);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     boolean var9 = var4.equals((java.lang.Object)var8);
//     java.lang.Object var10 = var4.clone();
//     var0.setFixedDomainAxisSpace(var4);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var14 = null;
//     var13.removeChangeListener(var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.ChartRenderingInfo var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var17);
//     java.awt.geom.Rectangle2D var19 = var18.getDataArea();
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var19, 1.0d, (-1.0d));
//     var13.draw(var16, var19);
//     java.awt.geom.Point2D var24 = null;
//     org.jfree.chart.plot.PlotState var25 = null;
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     var0.draw(var12, var19, var24, var25, var27);
//     
//     // Checks the contract:  equals-hashcode on var18 and var27
//     assertTrue("Contract failed: equals-hashcode on var18 and var27", var18.equals(var27) ? var18.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var18
//     assertTrue("Contract failed: equals-hashcode on var27 and var18", var27.equals(var18) ? var27.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setDrawBarOutline(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     var1.setRenderer(0, var3, true);
//     java.awt.Paint var6 = var1.getRangeCrosshairPaint();
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var10 = var8.lookupSeriesFillPaint(10);
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     var18.setUpperBound(8.0d);
//     java.awt.Stroke var21 = var18.getAxisLineStroke();
//     var16.setOutlineStroke(var21);
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var21};
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Paint var26 = null;
//     java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
//     java.awt.Stroke var28 = null;
//     java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
//     java.awt.Stroke[] var30 = null;
//     java.awt.Shape var31 = null;
//     java.awt.Shape[] var32 = new java.awt.Shape[] { var31};
//     org.jfree.chart.plot.DefaultDrawingSupplier var33 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var27, var29, var30, var32);
//     java.awt.Paint var34 = null;
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     java.awt.Paint var36 = null;
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
//     java.awt.Stroke var38 = null;
//     java.awt.Stroke[] var39 = new java.awt.Stroke[] { var38};
//     java.awt.Stroke[] var40 = null;
//     java.awt.Shape var41 = null;
//     java.awt.Shape[] var42 = new java.awt.Shape[] { var41};
//     org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var35, var37, var39, var40, var42);
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var7, var11, var23, var30, var42);
//     
//     // Checks the contract:  equals-hashcode on var33 and var43
//     assertTrue("Contract failed: equals-hashcode on var33 and var43", var33.equals(var43) ? var33.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var33
//     assertTrue("Contract failed: equals-hashcode on var43 and var33", var43.equals(var33) ? var43.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var1.removeChangeListener(var2);
    double var4 = var1.getContentXOffset();
    org.jfree.data.KeyedObject var5 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var1);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 0.0d);
    org.jfree.chart.block.LengthConstraintType var4 = null;
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 1.0d);
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, 1.0d);
    org.jfree.chart.block.LengthConstraintType var18 = var17.getHeightConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint((-17.0d), var3, var4, 0.0d, var8, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var4.removeLegend();
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedHeight(0.0d);
//     boolean var13 = var4.equals((java.lang.Object)var10);
//     org.jfree.chart.event.PlotChangeEvent var14 = null;
//     var4.plotChanged(var14);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     var13.setDataset(10, var15);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearRangeMarkers(0);
//     float var20 = var17.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     org.jfree.chart.event.ChartProgressEvent var24 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var21, 0, 1);
//     var21.setBorderVisible(false);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var21);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var6, 1.0d, (-1.0d));
//     org.jfree.chart.ChartRenderingInfo var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
//     java.awt.geom.Rectangle2D var12 = var11.getDataArea();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var12, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     var17.setRenderer(0, var19, true);
//     java.awt.Paint var22 = var17.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var23 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var12, var22);
//     org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("SortOrder.ASCENDING", "AxisLocation.TOP_OR_LEFT", "SortOrder.ASCENDING", "Category Plot", (java.awt.Shape)var6, var22);
//     
//     // Checks the contract:  equals-hashcode on var5 and var11
//     assertTrue("Contract failed: equals-hashcode on var5 and var11", var5.equals(var11) ? var5.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var5
//     assertTrue("Contract failed: equals-hashcode on var11 and var5", var11.equals(var5) ? var11.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    boolean var5 = var4.isRangeCrosshairLockedOnData();
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, 10.0d, 8.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    var0.setForegroundAlpha(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getDataArea();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.awt.Paint var12 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     var15.setRenderer(0, var17, true);
//     java.awt.Paint var20 = var15.getRangeCrosshairPaint();
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     java.awt.Paint var22 = null;
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Stroke var26 = null;
//     java.awt.Stroke[] var27 = new java.awt.Stroke[] { var26};
//     java.awt.Stroke[] var28 = null;
//     java.awt.Shape var29 = null;
//     java.awt.Shape[] var30 = new java.awt.Shape[] { var29};
//     org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier(var23, var25, var27, var28, var30);
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var32.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var33);
//     org.jfree.chart.event.RendererChangeEvent var35 = null;
//     var32.notifyListeners(var35);
//     var32.setItemLabelAnchorOffset(4.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var39 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var40 = var32.findRangeBounds((org.jfree.data.category.CategoryDataset)var39);
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
//     var47.setUpperBound(8.0d);
//     java.awt.Stroke var50 = var47.getAxisLineStroke();
//     var45.setOutlineStroke(var50);
//     var32.setBaseStroke(var50);
//     java.awt.Stroke[] var53 = new java.awt.Stroke[] { var50};
//     java.awt.Paint var54 = null;
//     java.awt.Paint[] var55 = new java.awt.Paint[] { var54};
//     java.awt.Paint var56 = null;
//     java.awt.Paint[] var57 = new java.awt.Paint[] { var56};
//     java.awt.Stroke var58 = null;
//     java.awt.Stroke[] var59 = new java.awt.Stroke[] { var58};
//     java.awt.Stroke[] var60 = null;
//     java.awt.Shape var61 = null;
//     java.awt.Shape[] var62 = new java.awt.Shape[] { var61};
//     org.jfree.chart.plot.DefaultDrawingSupplier var63 = new org.jfree.chart.plot.DefaultDrawingSupplier(var55, var57, var59, var60, var62);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.clearRangeMarkers(0);
//     float var67 = var64.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var68 = null;
//     int var69 = var64.getDomainAxisIndex(var68);
//     java.lang.String var70 = var64.getPlotType();
//     org.jfree.chart.util.RectangleInsets var71 = var64.getInsets();
//     org.jfree.chart.ChartRenderingInfo var72 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var73 = new org.jfree.chart.plot.PlotRenderingInfo(var72);
//     java.awt.geom.Rectangle2D var74 = var73.getDataArea();
//     java.awt.geom.Rectangle2D var75 = var71.createOutsetRectangle(var74);
//     java.awt.Shape[] var76 = new java.awt.Shape[] { var75};
//     org.jfree.chart.plot.DefaultDrawingSupplier var77 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var21, var23, var53, var60, var76);
//     
//     // Checks the contract:  equals-hashcode on var1 and var73
//     assertTrue("Contract failed: equals-hashcode on var1 and var73", var1.equals(var73) ? var1.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var1
//     assertTrue("Contract failed: equals-hashcode on var73 and var1", var73.equals(var1) ? var73.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var15
//     assertTrue("Contract failed: equals-hashcode on var7 and var15", var7.equals(var15) ? var7.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var7
//     assertTrue("Contract failed: equals-hashcode on var15 and var7", var15.equals(var7) ? var15.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var63
//     assertTrue("Contract failed: equals-hashcode on var31 and var63", var31.equals(var63) ? var31.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var31
//     assertTrue("Contract failed: equals-hashcode on var63 and var31", var63.equals(var31) ? var63.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.plot.DatasetRenderingOrder var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     var8.setRenderer(0, var10, true);
//     java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var8);
//     org.jfree.chart.axis.AxisLocation var14 = var8.getRangeAxisLocation();
//     java.lang.String var15 = var14.toString();
//     var0.setRangeAxisLocation(10, var14);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var0.", var8.equals(var0) == var0.equals(var8));
//     
//     // Checks the contract:  equals-hashcode on var5 and var13
//     assertTrue("Contract failed: equals-hashcode on var5 and var13", var5.equals(var13) ? var5.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var5
//     assertTrue("Contract failed: equals-hashcode on var13 and var5", var13.equals(var5) ? var13.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     boolean var9 = var4.equals((java.lang.Object)var8);
//     java.lang.Object var10 = var4.clone();
//     var0.setFixedDomainAxisSpace(var4);
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var17 = var14.getStandardTickUnits();
//     var14.setLabelToolTip("SortOrder.ASCENDING");
//     var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var14, false);
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     java.awt.geom.Rectangle2D var25 = var24.getDataArea();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var25, 1.0d, (-1.0d));
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Rectangle2D var37 = var36.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.clearRangeMarkers(0);
//     float var41 = var38.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     int var43 = var38.getDomainAxisIndex(var42);
//     java.lang.String var44 = var38.getPlotType();
//     org.jfree.chart.util.SortOrder var45 = var38.getRowRenderingOrder();
//     var38.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var47 = var38.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var49 = var38.getRangeAxisEdge(0);
//     double var50 = var30.java2DToValue(10.0d, var37, var49);
//     double var51 = var14.java2DToValue((-1.0d), var25, var49);
//     
//     // Checks the contract:  equals-hashcode on var5 and var38
//     assertTrue("Contract failed: equals-hashcode on var5 and var38", var5.equals(var38) ? var5.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var5
//     assertTrue("Contract failed: equals-hashcode on var38 and var5", var38.equals(var5) ? var38.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var36
//     assertTrue("Contract failed: equals-hashcode on var24 and var36", var24.equals(var36) ? var24.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var24
//     assertTrue("Contract failed: equals-hashcode on var36 and var24", var36.equals(var24) ? var36.hashCode() == var24.hashCode() : true);
// 
//   }

//  public void test116() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var1);
//
//  }
//
  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    var4.removeLegend();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var7 = var4.getSubtitle((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit((-17.0d), var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     org.jfree.chart.axis.AxisLocation var13 = var7.getRangeAxisLocation();
//     org.jfree.chart.axis.AxisLocation var14 = org.jfree.chart.axis.AxisLocation.getOpposite(var13);
//     var0.setDomainAxisLocation(var13, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var12
//     assertTrue("Contract failed: equals-hashcode on var5 and var12", var5.equals(var12) ? var5.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var5
//     assertTrue("Contract failed: equals-hashcode on var12 and var5", var12.equals(var5) ? var12.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.lang.String var2 = var1.getText();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     var1.draw(var3, 100.0f, 10.0f, var6, 0.0f, (-1.0f), 0.0d);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 10.0d, 100.0d, 10, (java.lang.Comparable)"SortOrder.ASCENDING");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setSeriesItemLabelGenerator(10, var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var0.setSeriesToolTipGenerator(100, var8);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var10.lookupSeriesPaint(1);
    var0.setBaseOutlinePaint(var12, false);
    boolean var15 = var0.isDrawBarOutline();
    var0.setIncludeBaseInRange(false);
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-1), var19, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isBorderVisible();
//     java.awt.RenderingHints var6 = null;
//     var4.setRenderingHints(var6);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.chart.axis.TickUnits var4 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var4.add((org.jfree.chart.axis.TickUnit)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var8 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 4.0d, 0.0d, 100, (java.lang.Comparable)var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    java.awt.geom.Rectangle2D var10 = var9.getDataArea();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var10, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    var15.setRenderer(0, var17, true);
    java.awt.Paint var20 = var15.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var21 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var10, var20);
    var0.setSeriesShape(10, (java.awt.Shape)var10);
    boolean var23 = var0.getAutoPopulateSeriesPaint();
    java.awt.Paint var26 = var0.getItemFillPaint(0, 10);
    java.awt.Paint var28 = null;
    var0.setSeriesItemLabelPaint(100, var28);
    java.awt.Shape var31 = var0.getSeriesShape(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxis(0);
    org.jfree.chart.annotations.CategoryAnnotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var12 = var0.removeAnnotation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("java.awt.Color[r=0,g=0,b=0]", var1, var2);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, (-17.0d), 1, (java.lang.Comparable)"SortOrder.ASCENDING");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var11, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     var16.setRenderer(0, var18, true);
//     java.awt.Paint var21 = var16.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var11, var21);
//     var0.setOutlinePaint(var21);
//     boolean var24 = var0.isSubplot();
//     var0.zoom(1.0d);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    int var2 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    java.util.List var2 = var0.getColumnKeys();
    int var4 = var0.getColumnIndex((java.lang.Comparable)(short)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var0.getRowKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     java.lang.Object var6 = var0.clone();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     var8.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     java.awt.geom.Rectangle2D var15 = var14.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.clearRangeMarkers(0);
//     float var19 = var16.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     int var21 = var16.getDomainAxisIndex(var20);
//     java.lang.String var22 = var16.getPlotType();
//     org.jfree.chart.util.SortOrder var23 = var16.getRowRenderingOrder();
//     var16.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var25 = var16.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var27 = var16.getRangeAxisEdge(0);
//     double var28 = var8.java2DToValue(10.0d, var15, var27);
//     org.jfree.chart.ChartRenderingInfo var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = new org.jfree.chart.plot.PlotRenderingInfo(var29);
//     java.awt.geom.Rectangle2D var31 = var30.getDataArea();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var31, 1.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = org.jfree.chart.util.RectangleEdge.coordinate(var31, var35);
//     java.awt.geom.Rectangle2D var37 = var0.expand(var15, var31);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var30
//     assertTrue("Contract failed: equals-hashcode on var14 and var30", var14.equals(var30) ? var14.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var14
//     assertTrue("Contract failed: equals-hashcode on var30 and var14", var30.equals(var14) ? var30.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getDataArea();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.awt.Paint var12 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var14.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var15);
//     org.jfree.chart.event.RendererChangeEvent var17 = null;
//     var14.notifyListeners(var17);
//     var14.setItemLabelAnchorOffset(4.0d);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Rectangle2D var24 = var23.getDataArea();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var24, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     var29.setRenderer(0, var31, true);
//     java.awt.Paint var34 = var29.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var24, var34);
//     var14.setSeriesShape(10, (java.awt.Shape)var24);
//     boolean var37 = var14.getAutoPopulateSeriesPaint();
//     java.awt.Paint var40 = var14.getItemFillPaint(0, 10);
//     var13.setLinePaint(var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var29
//     assertTrue("Contract failed: equals-hashcode on var7 and var29", var7.equals(var29) ? var7.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var7
//     assertTrue("Contract failed: equals-hashcode on var29 and var7", var29.equals(var7) ? var29.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearRangeMarkers(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(8.0d);
//     java.awt.Stroke var9 = var6.getAxisLineStroke();
//     var4.setOutlineStroke(var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.clearRangeMarkers(0);
//     float var15 = var12.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     int var17 = var12.getDomainAxisIndex(var16);
//     java.lang.String var18 = var12.getPlotType();
//     org.jfree.chart.util.RectangleInsets var19 = var12.getInsets();
//     org.jfree.chart.ChartRenderingInfo var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     java.awt.geom.Rectangle2D var22 = var21.getDataArea();
//     java.awt.geom.Rectangle2D var23 = var19.createOutsetRectangle(var22);
//     java.awt.geom.Point2D var24 = null;
//     org.jfree.chart.plot.PlotState var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var26.setRenderer(0, var28, true);
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
//     java.lang.Object var34 = var33.clone();
//     java.awt.geom.Point2D var35 = null;
//     var26.zoomDomainAxes(0.0d, var33, var35);
//     var4.draw(var11, var22, var24, var25, var33);
//     
//     // Checks the contract:  equals-hashcode on var21 and var33
//     assertTrue("Contract failed: equals-hashcode on var21 and var33", var21.equals(var33) ? var21.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var21
//     assertTrue("Contract failed: equals-hashcode on var33 and var21", var33.equals(var21) ? var33.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.ChartRenderingInfo var2 = var1.getOwner();
    org.jfree.chart.ChartRenderingInfo var3 = null;
    org.jfree.chart.plot.PlotRenderingInfo var4 = new org.jfree.chart.plot.PlotRenderingInfo(var3);
    var1.addSubplotInfo(var4);
    java.awt.geom.Point2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var1.getSubplotIndex(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     java.awt.Paint var5 = var0.getRangeCrosshairPaint();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var9, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var14.setRenderer(0, var16, true);
//     java.awt.Paint var19 = var14.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var20 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var9, var19);
//     java.awt.geom.Point2D var21 = null;
//     org.jfree.chart.plot.PlotState var22 = null;
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     org.jfree.chart.ChartRenderingInfo var25 = var24.getOwner();
//     java.awt.geom.Rectangle2D var26 = var24.getDataArea();
//     var0.draw(var6, var9, var21, var22, var24);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var24
//     assertTrue("Contract failed: equals-hashcode on var8 and var24", var8.equals(var24) ? var8.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var8
//     assertTrue("Contract failed: equals-hashcode on var24 and var8", var24.equals(var8) ? var24.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5);
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setPaint(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    int var3 = java.awt.Color.HSBtoRGB(10.0f, (-1.0f), 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), var1, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(8.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     boolean var5 = var1.getAutoRangeIncludesZero();
//     double var6 = var1.getFixedDimension();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var12 = var10.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var10.getNegativeItemLabelPositionFallback();
//     var10.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var18 = var16.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var16.getPositiveItemLabelPosition(1, 1);
//     var10.setPositiveItemLabelPositionFallback(var21);
//     org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var26 = var25.getFont();
//     var10.setSeriesItemLabelFont(100, var26);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.clearRangeMarkers(0);
//     float var31 = var28.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     int var33 = var28.getDomainAxisIndex(var32);
//     java.lang.String var34 = var28.getPlotType();
//     org.jfree.chart.util.SortOrder var35 = var28.getRowRenderingOrder();
//     var28.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
//     java.awt.geom.Rectangle2D var39 = var38.getDataArea();
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var39, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
//     var44.setRenderer(0, var46, true);
//     java.awt.Paint var49 = var44.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var39, var49);
//     var28.setOutlinePaint(var49);
//     org.jfree.chart.text.TextBlock var52 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, var49);
//     org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var55 = var53.lookupSeriesPaint(1);
//     org.jfree.chart.text.TextBlock var56 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", var26, var55);
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=0,b=0]", var26);
//     var1.setTickLabelFont(var26);
//     org.jfree.chart.ChartRenderingInfo var60 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var61 = new org.jfree.chart.plot.PlotRenderingInfo(var60);
//     org.jfree.chart.ChartRenderingInfo var62 = var61.getOwner();
//     java.awt.geom.Rectangle2D var63 = var61.getDataArea();
//     org.jfree.chart.axis.AxisState var65 = new org.jfree.chart.axis.AxisState(1.0d);
//     var65.cursorLeft(8.0d);
//     org.jfree.chart.title.TextTitle var69 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var70 = null;
//     var69.removeChangeListener(var70);
//     org.jfree.chart.util.RectangleEdge var72 = var69.getPosition();
//     var65.moveCursor(0.0d, var72);
//     double var74 = var1.lengthToJava2D(8.0d, var63, var72);
//     
//     // Checks the contract:  equals-hashcode on var38 and var61
//     assertTrue("Contract failed: equals-hashcode on var38 and var61", var38.equals(var61) ? var38.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var38
//     assertTrue("Contract failed: equals-hashcode on var61 and var38", var61.equals(var38) ? var61.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setAutoTickUnitSelection(false, false);
    org.jfree.data.Range var5 = var1.getDefaultAutoRange();
    boolean var6 = var1.isTickLabelsVisible();
    double var7 = var1.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=0,g=0,b=0]", var1, 10.0f, 0.0f, var4, 10.0d, var6);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 116.0d, 0.0d, 1, (java.lang.Comparable)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     var1.draw(var2, 10.0f, 0.0f, var5, 0.5f, (-1.0f), 92.0d);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
//     java.lang.Object var8 = var7.clone();
//     java.lang.Object var9 = var7.clone();
//     
//     // Checks the contract:  equals-hashcode on var8 and var9
//     assertTrue("Contract failed: equals-hashcode on var8 and var9", var8.equals(var9) ? var8.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var8
//     assertTrue("Contract failed: equals-hashcode on var9 and var8", var9.equals(var8) ? var9.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getDataArea();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.awt.Paint var12 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
//     var13.setLineVisible(false);
//     java.awt.Shape var16 = var13.getShape();
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var18 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var17.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var18);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setUpperBound(8.0d);
//     java.awt.Stroke var25 = var22.getAxisLineStroke();
//     var17.setSeriesOutlineStroke(0, var25, true);
//     org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var30 = var28.lookupSeriesPaint(1);
//     var17.setBaseFillPaint(var30, false);
//     var13.setLinePaint(var30);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var34, var35, var36, var37);
//     org.jfree.data.category.CategoryDataset var40 = null;
//     var38.setDataset(10, var40);
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     java.awt.geom.Rectangle2D var45 = var44.getDataArea();
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var45, 1.0d, (-1.0d));
//     var38.drawBackgroundImage(var42, var45);
//     var13.setBounds(var45);
//     
//     // Checks the contract:  equals-hashcode on var1 and var44
//     assertTrue("Contract failed: equals-hashcode on var1 and var44", var1.equals(var44) ? var1.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var1
//     assertTrue("Contract failed: equals-hashcode on var44 and var1", var44.equals(var1) ? var44.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var38
//     assertTrue("Contract failed: equals-hashcode on var7 and var38", var7.equals(var38) ? var7.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var7
//     assertTrue("Contract failed: equals-hashcode on var38 and var7", var38.equals(var7) ? var38.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var12 = var10.lookupSeriesPaint(1);
//     var0.setBaseOutlinePaint(var12, false);
//     boolean var15 = var0.isDrawBarOutline();
//     var0.setIncludeBaseInRange(false);
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var20 = null;
//     var19.removeChangeListener(var20);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     java.awt.geom.Rectangle2D var25 = var24.getDataArea();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var25, 1.0d, (-1.0d));
//     var19.draw(var22, var25);
//     var19.setURLText("Category Plot");
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var34 = var32.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var35 = var32.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var37 = null;
//     var32.setSeriesItemLabelGenerator(10, var37);
//     org.jfree.chart.labels.CategoryToolTipGenerator var40 = null;
//     var32.setSeriesToolTipGenerator(100, var40);
//     org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var44 = var42.lookupSeriesPaint(1);
//     var32.setBaseOutlinePaint(var44, false);
//     var19.setBackgroundPaint(var44);
//     var0.setSeriesOutlinePaint(100, var44);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var32 and var0.", var32.equals(var0) == var0.equals(var32));
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var4 = var1.getStandardTickUnits();
    var1.setLabelToolTip("SortOrder.ASCENDING");
    var1.setLabelURL("hi!");
    var1.setRangeAboutValue(100.0d, 116.0d);
    java.lang.String var12 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.TickUnits var4 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var4.add((org.jfree.chart.axis.TickUnit)var6);
    var0.add(8.0d, 4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)var6);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    var9.setRenderer(0, var11, true);
    java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
    org.jfree.chart.axis.ValueAxis var16 = null;
    var9.setRangeAxis(0, var16);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var9);
    double var19 = var9.getAnchorValue();
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    var22.setUpperBound(8.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setRangeAxis((-16777216), (org.jfree.chart.axis.ValueAxis)var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setSeriesItemLabelGenerator(10, var5);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var10 = var8.lookupSeriesFillPaint(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var12 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var11.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var12);
    org.jfree.chart.event.RendererChangeEvent var14 = null;
    var11.notifyListeners(var14);
    var11.setItemLabelAnchorOffset(4.0d);
    var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11, true);
    java.awt.Shape var22 = var11.getItemShape(10, 0);
    var11.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var28 = var26.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var31 = var26.getPositiveItemLabelPosition(1, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSeriesPositiveItemLabelPosition((-16777216), var31, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     java.lang.String var8 = var2.getPlotType();
//     org.jfree.chart.util.SortOrder var9 = var2.getRowRenderingOrder();
//     var2.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var11 = var2.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var13 = var2.getRangeAxisEdge(0);
//     org.jfree.chart.axis.CategoryLabelPosition var14 = var1.getLabelPosition(var13);
//     org.jfree.chart.axis.CategoryLabelPositions var16 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearRangeMarkers(0);
//     float var20 = var17.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     int var22 = var17.getDomainAxisIndex(var21);
//     java.lang.String var23 = var17.getPlotType();
//     org.jfree.chart.util.SortOrder var24 = var17.getRowRenderingOrder();
//     var17.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var26 = var17.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var28 = var17.getRangeAxisEdge(0);
//     org.jfree.chart.axis.CategoryLabelPosition var29 = var16.getLabelPosition(var28);
//     org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.clearRangeMarkers(0);
//     float var35 = var32.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     int var37 = var32.getDomainAxisIndex(var36);
//     java.lang.String var38 = var32.getPlotType();
//     org.jfree.chart.util.SortOrder var39 = var32.getRowRenderingOrder();
//     var32.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var41 = var32.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var43 = var32.getRangeAxisEdge(0);
//     org.jfree.chart.axis.CategoryLabelPosition var44 = var31.getLabelPosition(var43);
//     org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     var47.clearRangeMarkers(0);
//     float var50 = var47.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     int var52 = var47.getDomainAxisIndex(var51);
//     java.lang.String var53 = var47.getPlotType();
//     org.jfree.chart.util.SortOrder var54 = var47.getRowRenderingOrder();
//     var47.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var56 = var47.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var58 = var47.getRangeAxisEdge(0);
//     org.jfree.chart.axis.CategoryLabelPosition var59 = var46.getLabelPosition(var58);
//     org.jfree.chart.axis.CategoryLabelPositions var60 = new org.jfree.chart.axis.CategoryLabelPositions(var14, var29, var44, var59);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var32
//     assertTrue("Contract failed: equals-hashcode on var2 and var32", var2.equals(var32) ? var2.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var47
//     assertTrue("Contract failed: equals-hashcode on var2 and var47", var2.equals(var47) ? var2.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var32
//     assertTrue("Contract failed: equals-hashcode on var17 and var32", var17.equals(var32) ? var17.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var47
//     assertTrue("Contract failed: equals-hashcode on var17 and var47", var17.equals(var47) ? var17.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var2
//     assertTrue("Contract failed: equals-hashcode on var32 and var2", var32.equals(var2) ? var32.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var17
//     assertTrue("Contract failed: equals-hashcode on var32 and var17", var32.equals(var17) ? var32.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var47
//     assertTrue("Contract failed: equals-hashcode on var32 and var47", var32.equals(var47) ? var32.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var2
//     assertTrue("Contract failed: equals-hashcode on var47 and var2", var47.equals(var2) ? var47.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var17
//     assertTrue("Contract failed: equals-hashcode on var47 and var17", var47.equals(var17) ? var47.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var32
//     assertTrue("Contract failed: equals-hashcode on var47 and var32", var47.equals(var32) ? var47.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(4.0d, var1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.general.DatasetGroup var3 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearRangeMarkers(0);
//     float var7 = var4.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     var8.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var3, var8, 10, 10);
//     var0.setGroup(var3);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var14.setRenderer(0, var16, true);
//     java.lang.Object var19 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     var14.setRangeAxis(0, var21);
//     var14.setWeight(100);
//     var14.configureRangeAxes();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var27 = var26.getPaint();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var29 = var28.getPaint();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.clearRangeMarkers(0);
//     float var33 = var30.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     int var35 = var30.getDomainAxisIndex(var34);
//     java.lang.String var36 = var30.getPlotType();
//     org.jfree.chart.util.RectangleInsets var37 = var30.getInsets();
//     var28.setMargin(var37);
//     double var40 = var37.calculateTopOutset(100.0d);
//     var26.setMargin(var37);
//     org.jfree.chart.util.UnitType var42 = var37.getUnitType();
//     var14.setInsets(var37);
//     var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var14);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(1.0d);
    var1.setMax(100.0d);
    var1.cursorDown(92.0d);
    var1.cursorRight(1.0d);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var4.removeLegend();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var8 = var7.getPaint();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearRangeMarkers(0);
//     float var12 = var9.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     int var14 = var9.getDomainAxisIndex(var13);
//     java.lang.String var15 = var9.getPlotType();
//     org.jfree.chart.util.RectangleInsets var16 = var9.getInsets();
//     var7.setMargin(var16);
//     double var19 = var16.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var21.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var24 = var21.getStandardTickUnits();
//     var21.resizeRange(4.0d);
//     var21.setLowerBound((-17.0d));
//     org.jfree.chart.ChartRenderingInfo var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = new org.jfree.chart.plot.PlotRenderingInfo(var29);
//     java.awt.geom.Rectangle2D var31 = var30.getDataArea();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var31, 1.0d, (-1.0d));
//     var21.setUpArrow((java.awt.Shape)var31);
//     java.awt.geom.Rectangle2D var36 = var16.createOutsetRectangle(var31);
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     var4.draw(var6, var31, var37);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
//     var2.setUpperBound(8.0d);
//     java.awt.Stroke var5 = var2.getAxisLineStroke();
//     org.jfree.chart.util.RectangleInsets var6 = var2.getLabelInsets();
//     org.jfree.data.KeyedObject var7 = new org.jfree.data.KeyedObject((java.lang.Comparable)10L, (java.lang.Object)var2);
//     double var8 = var2.getFixedDimension();
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var11 = var10.getPaint();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.clearRangeMarkers(0);
//     float var15 = var12.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     int var17 = var12.getDomainAxisIndex(var16);
//     java.lang.String var18 = var12.getPlotType();
//     org.jfree.chart.util.RectangleInsets var19 = var12.getInsets();
//     var10.setMargin(var19);
//     double var22 = var19.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
//     var24.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var27 = var24.getStandardTickUnits();
//     var24.resizeRange(4.0d);
//     var24.setLowerBound((-17.0d));
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
//     java.awt.geom.Rectangle2D var34 = var33.getDataArea();
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var34, 1.0d, (-1.0d));
//     var24.setUpArrow((java.awt.Shape)var34);
//     java.awt.geom.Rectangle2D var39 = var19.createOutsetRectangle(var34);
//     org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
//     var41.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.ChartRenderingInfo var46 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = new org.jfree.chart.plot.PlotRenderingInfo(var46);
//     java.awt.geom.Rectangle2D var48 = var47.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.clearRangeMarkers(0);
//     float var52 = var49.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     int var54 = var49.getDomainAxisIndex(var53);
//     java.lang.String var55 = var49.getPlotType();
//     org.jfree.chart.util.SortOrder var56 = var49.getRowRenderingOrder();
//     var49.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var58 = var49.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var60 = var49.getRangeAxisEdge(0);
//     double var61 = var41.java2DToValue(10.0d, var48, var60);
//     double var62 = var2.java2DToValue(Double.POSITIVE_INFINITY, var39, var60);
//     
//     // Checks the contract:  equals-hashcode on var12 and var49
//     assertTrue("Contract failed: equals-hashcode on var12 and var49", var12.equals(var49) ? var12.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var12
//     assertTrue("Contract failed: equals-hashcode on var49 and var12", var49.equals(var12) ? var49.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var47
//     assertTrue("Contract failed: equals-hashcode on var33 and var47", var33.equals(var47) ? var33.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var33
//     assertTrue("Contract failed: equals-hashcode on var47 and var33", var47.equals(var33) ? var47.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.ChartRenderingInfo var2 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var2);
//     java.awt.geom.Rectangle2D var4 = var3.getDataArea();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var4);
//     boolean var6 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     var11.setDataset(10, var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.awt.geom.Rectangle2D var18 = var17.getDataArea();
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var18, 1.0d, (-1.0d));
//     var11.drawBackgroundImage(var15, var18);
//     boolean var23 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape)var4, (java.awt.Shape)var18);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
//     boolean var15 = var9.equals((java.lang.Object)var11);
//     var11.setTickMarksVisible(false);
//     var11.setFixedDimension(0.0d);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     org.jfree.chart.axis.AxisSpace var25 = var24.getFixedDomainAxisSpace();
//     boolean var26 = var24.isOutlineVisible();
//     var11.setPlot((org.jfree.chart.plot.Plot)var24);
//     org.jfree.chart.axis.TickUnits var29 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var33);
//     boolean var35 = var29.equals((java.lang.Object)var33);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var36.removeChangeListener(var37);
//     org.jfree.chart.util.RectangleEdge var39 = var36.getPosition();
//     double var40 = var11.lengthToJava2D(116.0d, var33, var39);
//     org.jfree.chart.ChartRenderingInfo var41 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var42 = new org.jfree.chart.plot.PlotRenderingInfo(var41);
//     java.awt.geom.Rectangle2D var43 = var42.getDataArea();
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var43, 100.0d, 10.0f, 10.0f);
//     boolean var48 = org.jfree.chart.util.ShapeUtilities.equal((java.awt.Shape)var33, (java.awt.Shape)var43);
//     
//     // Checks the contract:  equals-hashcode on var32 and var42
//     assertTrue("Contract failed: equals-hashcode on var32 and var42", var32.equals(var42) ? var32.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var32
//     assertTrue("Contract failed: equals-hashcode on var42 and var32", var42.equals(var32) ? var42.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    var0.setSeriesCreateEntities(1, (java.lang.Boolean)false, false);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var8);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    org.jfree.data.category.CategoryDataset var16 = null;
    var14.setDataset(10, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.ChartRenderingInfo var19 = null;
    org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
    java.awt.geom.Rectangle2D var21 = var20.getDataArea();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var21, 1.0d, (-1.0d));
    var14.drawBackgroundImage(var18, var21);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    var26.setRenderer(0, var28, true);
    org.jfree.chart.ChartRenderingInfo var32 = null;
    org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
    java.lang.Object var34 = var33.clone();
    java.awt.geom.Point2D var35 = null;
    var26.zoomDomainAxes(0.0d, var33, var35);
    org.jfree.chart.util.Layer var37 = null;
    java.util.Collection var38 = var26.getRangeMarkers(var37);
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("");
    var41.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var44 = var41.getStandardTickUnits();
    var41.resizeRange(4.0d);
    org.jfree.chart.axis.TickUnitSource var47 = var41.getStandardTickUnits();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var49 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var48);
    org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var48);
    org.jfree.data.general.DatasetGroup var51 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
    var52.clearRangeMarkers(0);
    float var55 = var52.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var52);
    var56.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var60 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var51, var56, 10, 10);
    var48.setGroup(var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var7, var9, var21, var26, var39, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.data.category.CategoryDataset)var48, 10, (-1), (-16777216));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + 0.0d+ "'", var49.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.5f);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("AxisLocation.TOP_OR_LEFT", var1, var2);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    boolean var5 = var4.isBorderVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var8 = var4.createBufferedImage(15, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    java.awt.geom.Point2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.getSubplotIndex(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("0", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING", var1, var2);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.ChartRenderingInfo var2 = var1.getOwner();
    java.awt.geom.Rectangle2D var3 = var1.getPlotArea();
    java.awt.geom.Point2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var5 = var1.getSubplotIndex(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    int var1 = var0.size();
    java.awt.Stroke var3 = var0.getStroke(0);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(8.0d);
    java.awt.Stroke var9 = var6.getAxisLineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setStroke((-16777216), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var3 = var2.getPaint();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearRangeMarkers(0);
//     float var7 = var4.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     java.lang.String var10 = var4.getPlotType();
//     org.jfree.chart.util.RectangleInsets var11 = var4.getInsets();
//     var2.setMargin(var11);
//     double var14 = var11.calculateTopOutset(100.0d);
//     var0.setMargin(var11);
//     org.jfree.chart.util.UnitType var16 = var11.getUnitType();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearRangeMarkers(0);
//     float var20 = var17.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     int var22 = var17.getDomainAxisIndex(var21);
//     java.lang.String var23 = var17.getPlotType();
//     org.jfree.chart.util.RectangleInsets var24 = var17.getInsets();
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Rectangle2D var27 = var26.getDataArea();
//     java.awt.geom.Rectangle2D var28 = var24.createOutsetRectangle(var27);
//     java.awt.geom.Rectangle2D var29 = var11.createInsetRectangle(var28);
//     
//     // Checks the contract:  equals-hashcode on var4 and var17
//     assertTrue("Contract failed: equals-hashcode on var4 and var17", var4.equals(var17) ? var4.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var4
//     assertTrue("Contract failed: equals-hashcode on var17 and var4", var17.equals(var4) ? var17.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.data.category.CategoryDataset var6 = null;
    var4.setDataset(10, var6);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearRangeMarkers(0);
    float var11 = var8.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
    var15.setPercent(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5f);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var4 = var2.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var2.getNegativeItemLabelPositionFallback();
//     var2.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var10 = var8.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var8.getPositiveItemLabelPosition(1, 1);
//     var2.setPositiveItemLabelPositionFallback(var13);
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var18 = var17.getFont();
//     var2.setSeriesItemLabelFont(100, var18);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.clearRangeMarkers(0);
//     float var23 = var20.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     int var25 = var20.getDomainAxisIndex(var24);
//     java.lang.String var26 = var20.getPlotType();
//     org.jfree.chart.util.SortOrder var27 = var20.getRowRenderingOrder();
//     var20.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = new org.jfree.chart.plot.PlotRenderingInfo(var29);
//     java.awt.geom.Rectangle2D var31 = var30.getDataArea();
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var31, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     var36.setRenderer(0, var38, true);
//     java.awt.Paint var41 = var36.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var42 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var31, var41);
//     var20.setOutlinePaint(var41);
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, var41);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var47 = var45.lookupSeriesPaint(1);
//     org.jfree.chart.text.TextBlock var48 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", var18, var47);
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.text.TextBlockAnchor var52 = null;
//     java.awt.Shape var56 = var48.calculateBounds(var49, 0.0f, 0.0f, var52, 10.0f, 0.0f, 116.0d);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var4 = var1.getStandardTickUnits();
//     var1.resizeRange(4.0d);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.chart.axis.TickUnits var12 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.NumberTickUnit var14 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     var12.add((org.jfree.chart.axis.TickUnit)var14);
//     var8.add(8.0d, 4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)var14);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     var17.setRenderer(0, var19, true);
//     java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var17);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     var17.setRangeAxis(0, var24);
//     var8.addChangeListener((org.jfree.data.general.DatasetChangeListener)var17);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
//     var28.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var31 = var28.getStandardTickUnits();
//     var28.setLabelToolTip("SortOrder.ASCENDING");
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.clearRangeMarkers(0);
//     float var38 = var35.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     int var40 = var35.getDomainAxisIndex(var39);
//     java.lang.String var41 = var35.getPlotType();
//     org.jfree.chart.util.RectangleInsets var42 = var35.getInsets();
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     java.awt.geom.Rectangle2D var45 = var44.getDataArea();
//     java.awt.geom.Rectangle2D var46 = var42.createOutsetRectangle(var45);
//     org.jfree.chart.axis.AxisState var48 = new org.jfree.chart.axis.AxisState(1.0d);
//     var48.cursorLeft(8.0d);
//     org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var53 = null;
//     var52.removeChangeListener(var53);
//     org.jfree.chart.util.RectangleEdge var55 = var52.getPosition();
//     var48.moveCursor(0.0d, var55);
//     double var57 = var28.java2DToValue(8.0d, var46, var55);
//     org.jfree.chart.axis.CategoryLabelPositions var59 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     var60.clearRangeMarkers(0);
//     float var63 = var60.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var64 = null;
//     int var65 = var60.getDomainAxisIndex(var64);
//     java.lang.String var66 = var60.getPlotType();
//     org.jfree.chart.util.SortOrder var67 = var60.getRowRenderingOrder();
//     var60.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var69 = var60.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var71 = var60.getRangeAxisEdge(0);
//     org.jfree.chart.axis.CategoryLabelPosition var72 = var59.getLabelPosition(var71);
//     org.jfree.chart.axis.AxisSpace var73 = new org.jfree.chart.axis.AxisSpace();
//     double var74 = var73.getRight();
//     org.jfree.chart.axis.AxisSpace var75 = var1.reserveSpace(var7, (org.jfree.chart.plot.Plot)var17, var46, var71, var73);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var8 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var7);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var15.setUpperBound(8.0d);
    java.awt.Stroke var18 = var15.getAxisLineStroke();
    var13.setOutlineStroke(var18);
    var0.setBaseStroke(var18);
    java.awt.Font var23 = var0.getItemLabelFont(10, 0);
    org.jfree.chart.annotations.CategoryAnnotation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.lang.String var2 = var1.getText();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     float var5 = var1.calculateBaselineOffset(var3, var4);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     java.lang.String var8 = var2.getPlotType();
//     org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
//     var0.setMargin(var9);
//     double var12 = var9.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     var14.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var17 = var14.getStandardTickUnits();
//     var14.resizeRange(4.0d);
//     var14.setLowerBound((-17.0d));
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Rectangle2D var24 = var23.getDataArea();
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var24, 1.0d, (-1.0d));
//     var14.setUpArrow((java.awt.Shape)var24);
//     java.awt.geom.Rectangle2D var29 = var9.createOutsetRectangle(var24);
//     java.awt.geom.Rectangle2D var30 = null;
//     boolean var31 = org.jfree.chart.util.ShapeUtilities.contains(var24, var30);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     var4.setDataset(10, var6);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearRangeMarkers(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
//     var12.setBorderVisible(false);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var18.removeChangeListener(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var18.getPosition();
//     var12.removeSubtitle((org.jfree.chart.title.Title)var18);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     var27.setDataset(10, var29);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.clearRangeMarkers(0);
//     float var34 = var31.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     org.jfree.chart.event.ChartProgressEvent var38 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var35, 0, 1);
//     var18.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var35);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var35
//     assertTrue("Contract failed: equals-hashcode on var12 and var35", var12.equals(var35) ? var12.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var12
//     assertTrue("Contract failed: equals-hashcode on var35 and var12", var35.equals(var12) ? var35.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var5 = var4.getPaint();
    org.jfree.chart.block.BlockBorder var6 = new org.jfree.chart.block.BlockBorder(92.0d, 116.0d, 4.0d, 92.0d, var5);
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    double var9 = var7.calculateBottomInset(8.0d);
    double var11 = var7.trimWidth(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == Double.POSITIVE_INFINITY);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var0.setRangeAxis(0, var7);
//     var0.setWeight(100);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearRangeMarkers(0);
//     float var14 = var11.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     var15.removeLegend();
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var23 = var21.toFixedHeight(0.0d);
//     boolean var24 = var15.equals((java.lang.Object)var21);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.chart.axis.TickUnits var30 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.NumberTickUnit var32 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     var30.add((org.jfree.chart.axis.TickUnit)var32);
//     var26.add(8.0d, 4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)var32);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     var35.setRenderer(0, var37, true);
//     java.lang.Object var40 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var35);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     var35.setRangeAxis(0, var42);
//     var26.addChangeListener((org.jfree.data.general.DatasetChangeListener)var35);
//     double var45 = var35.getAnchorValue();
//     var0.setParent((org.jfree.chart.plot.Plot)var35);
//     
//     // Checks the contract:  equals-hashcode on var5 and var40
//     assertTrue("Contract failed: equals-hashcode on var5 and var40", var5.equals(var40) ? var5.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var5
//     assertTrue("Contract failed: equals-hashcode on var40 and var5", var40.equals(var5) ? var40.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.clearRangeMarkers(0);
    float var5 = var2.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var6 = null;
    int var7 = var2.getDomainAxisIndex(var6);
    java.lang.String var8 = var2.getPlotType();
    org.jfree.chart.util.SortOrder var9 = var2.getRowRenderingOrder();
    var2.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var11 = var2.getFixedDomainAxisSpace();
    org.jfree.chart.util.RectangleEdge var13 = var2.getRangeAxisEdge(0);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    var15.setUpperBound(8.0d);
    java.awt.Stroke var18 = var15.getAxisLineStroke();
    float var19 = var15.getTickMarkInsideLength();
    var15.setVerticalTickLabels(false);
    org.jfree.data.Range var22 = var2.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
    java.lang.String var23 = var15.getLabelURL();
    org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.event.RendererChangeEvent var25 = null;
    var24.notifyListeners(var25);
    org.jfree.chart.ChartRenderingInfo var28 = null;
    org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
    java.awt.geom.Rectangle2D var30 = var29.getDataArea();
    var24.setSeriesShape(1, (java.awt.Shape)var30, false);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    org.jfree.chart.annotations.CategoryAnnotation var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addAnnotation(var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Category Plot"+ "'", var8.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.RectangleEdge var5 = var4.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5);
    org.jfree.chart.util.LengthAdjustmentType var7 = var5.getLabelOffsetType();
    java.awt.Font var8 = var5.getLabelFont();
    org.jfree.chart.util.LengthAdjustmentType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setLabelOffsetType(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     java.awt.Image var5 = var4.getBackgroundImage();
//     org.jfree.chart.event.TitleChangeEvent var6 = null;
//     var4.titleChanged(var6);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.awt.Image var5 = var4.getBackgroundImage();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEventType var8 = null;
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"", var7, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTextAntiAlias((java.lang.Object)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(8.0d);
//     java.awt.Stroke var9 = var6.getAxisLineStroke();
//     var4.setOutlineStroke(var9);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     org.jfree.chart.util.Layer var14 = null;
//     var4.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var13, var14);
//     java.lang.Class var16 = null;
//     java.util.EventListener[] var17 = var13.getListeners(var16);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.clearRangeMarkers(0);
    float var5 = var2.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var6 = null;
    int var7 = var2.getDomainAxisIndex(var6);
    java.lang.String var8 = var2.getPlotType();
    org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
    var0.setMargin(var9);
    double var12 = var9.calculateBottomInset(8.0d);
    double var14 = var9.trimHeight(100.0d);
    double var15 = var9.getRight();
    java.awt.Paint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var9, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Category Plot"+ "'", var8.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 92.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 8.0d);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SortOrder.ASCENDING", var1);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.TickUnits var2 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var2.add((org.jfree.chart.axis.TickUnit)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var6 = var0.getLargerTickUnit((org.jfree.chart.axis.TickUnit)var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
    boolean var6 = var4.isOutlineVisible();
    org.jfree.chart.axis.CategoryAnchor var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainGridlinePosition(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    int var9 = var0.getWeight();
    org.jfree.chart.util.RectangleInsets var10 = var0.getAxisOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

//  public void test201() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("AxisLocation.TOP_OR_LEFT", var1);
//
//  }
//
  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var1 = null;
    var0.removeChangeListener(var1);
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var6, 1.0d, (-1.0d));
    var0.draw(var3, var6);
    var0.setURLText("Category Plot");
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var15 = var13.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var16 = var13.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var13.setSeriesItemLabelGenerator(10, var18);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var13.setSeriesToolTipGenerator(100, var21);
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var25 = var23.lookupSeriesPaint(1);
    var13.setBaseOutlinePaint(var25, false);
    var0.setBackgroundPaint(var25);
    java.awt.Graphics2D var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var30 = var0.arrange(var29);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     java.lang.String var8 = var2.getPlotType();
//     org.jfree.chart.util.SortOrder var9 = var2.getRowRenderingOrder();
//     var2.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var11 = var2.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var13 = var2.getRangeAxisEdge(0);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     var15.setUpperBound(8.0d);
//     java.awt.Stroke var18 = var15.getAxisLineStroke();
//     float var19 = var15.getTickMarkInsideLength();
//     var15.setVerticalTickLabels(false);
//     org.jfree.data.Range var22 = var2.getDataRange((org.jfree.chart.axis.ValueAxis)var15);
//     java.lang.String var23 = var15.getLabelURL();
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.event.RendererChangeEvent var25 = null;
//     var24.notifyListeners(var25);
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
//     java.awt.geom.Rectangle2D var30 = var29.getDataArea();
//     var24.setSeriesShape(1, (java.awt.Shape)var30, false);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var35 = var34.getPaint();
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.clearRangeMarkers(0);
//     float var39 = var36.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     int var41 = var36.getDomainAxisIndex(var40);
//     java.lang.String var42 = var36.getPlotType();
//     org.jfree.chart.util.RectangleInsets var43 = var36.getInsets();
//     var34.setMargin(var43);
//     double var46 = var43.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.TickUnits var47 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var48 = var47.clone();
//     org.jfree.chart.ChartRenderingInfo var49 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var50 = new org.jfree.chart.plot.PlotRenderingInfo(var49);
//     java.awt.geom.Rectangle2D var51 = var50.getDataArea();
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var51);
//     boolean var53 = var47.equals((java.lang.Object)var51);
//     java.awt.geom.Rectangle2D var56 = var43.createOutsetRectangle(var51, false, false);
//     var24.setBaseShape((java.awt.Shape)var56, false);
//     
//     // Checks the contract:  equals-hashcode on var2 and var36
//     assertTrue("Contract failed: equals-hashcode on var2 and var36", var2.equals(var36) ? var2.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var2
//     assertTrue("Contract failed: equals-hashcode on var36 and var2", var36.equals(var2) ? var36.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var50
//     assertTrue("Contract failed: equals-hashcode on var29 and var50", var29.equals(var50) ? var29.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var29
//     assertTrue("Contract failed: equals-hashcode on var50 and var29", var50.equals(var29) ? var50.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke[] var6 = null;
    java.awt.Shape var7 = null;
    java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
    org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
    boolean var15 = var9.equals((java.lang.Object)var11);
    java.awt.Stroke var16 = var11.getAxisLineStroke();
    java.lang.String var17 = var11.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "NOID", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "UnitType.ABSOLUTE");

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    boolean var9 = var4.equals((java.lang.Object)var8);
    java.lang.Object var10 = var4.clone();
    var0.setFixedDomainAxisSpace(var4);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var17 = var14.getStandardTickUnits();
    var14.setLabelToolTip("SortOrder.ASCENDING");
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var14, false);
    org.jfree.chart.util.Layer var22 = null;
    java.util.Collection var23 = var0.getRangeMarkers(var22);
    org.jfree.chart.plot.CategoryMarker var24 = null;
    org.jfree.chart.util.Layer var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var24, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
    var0.setPositiveItemLabelPositionFallback(var11);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var16 = var15.getFont();
    var0.setSeriesItemLabelFont(100, var16);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var0.getBaseURLGenerator();
    double var19 = var0.getMaximumBarWidth();
    org.jfree.chart.ChartRenderingInfo var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
    java.awt.geom.Rectangle2D var22 = var21.getDataArea();
    boolean var23 = var0.equals((java.lang.Object)var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-2), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var1.addRangeMarker((org.jfree.chart.plot.Marker)var6);
    org.jfree.chart.util.LengthAdjustmentType var8 = var6.getLabelOffsetType();
    java.awt.Stroke var9 = var6.getStroke();
    org.jfree.chart.text.TextAnchor var10 = var6.getLabelTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition(var0, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearDomainAxes();
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var11, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    var16.setRenderer(0, var18, true);
    java.awt.Paint var21 = var16.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var11, var21);
    var0.setOutlinePaint(var21);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    var25.setRenderer(0, var27, true);
    java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var25);
    org.jfree.chart.axis.AxisLocation var31 = var25.getRangeAxisLocation();
    java.lang.String var32 = var31.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-16777216), var31, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "AxisLocation.TOP_OR_LEFT"+ "'", var32.equals("AxisLocation.TOP_OR_LEFT"));

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 10.0d, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var11, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     var16.setRenderer(0, var18, true);
//     java.awt.Paint var21 = var16.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var11, var21);
//     var0.setOutlinePaint(var21);
//     boolean var24 = var0.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var26.setRenderer(0, var28, true);
//     org.jfree.chart.ChartRenderingInfo var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
//     java.lang.Object var34 = var33.clone();
//     java.awt.geom.Point2D var35 = null;
//     var26.zoomDomainAxes(0.0d, var33, var35);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var37 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var33);
//     java.awt.geom.Point2D var38 = null;
//     var0.zoomRangeAxes((-1.0d), var33, var38);
//     
//     // Checks the contract:  equals-hashcode on var16 and var26
//     assertTrue("Contract failed: equals-hashcode on var16 and var26", var16.equals(var26) ? var16.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var16
//     assertTrue("Contract failed: equals-hashcode on var26 and var16", var26.equals(var16) ? var26.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isBorderVisible();
//     java.lang.Object var6 = var4.clone();
//     java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
//     
//     // Checks the contract:  equals-hashcode on var6 and var7
//     assertTrue("Contract failed: equals-hashcode on var6 and var7", var6.equals(var7) ? var6.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var6
//     assertTrue("Contract failed: equals-hashcode on var7 and var6", var7.equals(var6) ? var7.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getOptionalLibraries();
    var0.setLicenceName("org.jfree.chart.event.ChartChangeEvent[source=]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getDataArea();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.awt.Paint var12 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
//     var13.setLineVisible(true);
//     java.awt.Stroke var16 = var13.getOutlineStroke();
//     java.lang.Object var17 = var13.clone();
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.clearRangeMarkers(0);
//     float var21 = var18.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     int var23 = var18.getDomainAxisIndex(var22);
//     java.lang.String var24 = var18.getPlotType();
//     org.jfree.chart.util.SortOrder var25 = var18.getRowRenderingOrder();
//     var18.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     java.awt.geom.Rectangle2D var29 = var28.getDataArea();
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var29, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     var34.setRenderer(0, var36, true);
//     java.awt.Paint var39 = var34.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var40 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var29, var39);
//     var18.setOutlinePaint(var39);
//     var13.setFillPaint(var39);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var34
//     assertTrue("Contract failed: equals-hashcode on var7 and var34", var7.equals(var34) ? var7.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var7
//     assertTrue("Contract failed: equals-hashcode on var34 and var7", var34.equals(var7) ? var34.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var2 = var1.getFont();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var1.calculateDimensions(var3);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var7 = var5.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var8 = var5.getNegativeItemLabelPositionFallback();
    var5.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var13 = var11.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var16 = var11.getPositiveItemLabelPosition(1, 1);
    var5.setPositiveItemLabelPositionFallback(var16);
    org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var21 = var20.getFont();
    var5.setSeriesItemLabelFont(100, var21);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearRangeMarkers(0);
    float var26 = var23.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    int var28 = var23.getDomainAxisIndex(var27);
    java.lang.String var29 = var23.getPlotType();
    org.jfree.chart.util.SortOrder var30 = var23.getRowRenderingOrder();
    var23.clearDomainAxes();
    org.jfree.chart.ChartRenderingInfo var32 = null;
    org.jfree.chart.plot.PlotRenderingInfo var33 = new org.jfree.chart.plot.PlotRenderingInfo(var32);
    java.awt.geom.Rectangle2D var34 = var33.getDataArea();
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var34, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    var39.setRenderer(0, var41, true);
    java.awt.Paint var44 = var39.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var45 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var34, var44);
    var23.setOutlinePaint(var44);
    org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-16777216), var44, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "Category Plot"+ "'", var29.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     var0.setDrawBarOutline(false);
//     java.awt.Paint var14 = var0.getItemOutlinePaint(0, 0);
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint var18 = null;
//     java.awt.Paint[] var19 = new java.awt.Paint[] { var18};
//     java.awt.Stroke var20 = null;
//     java.awt.Stroke[] var21 = new java.awt.Stroke[] { var20};
//     java.awt.Stroke[] var22 = null;
//     java.awt.Shape var23 = null;
//     java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
//     org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var17, var19, var21, var22, var24);
//     java.awt.Paint var26 = null;
//     java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
//     java.awt.Paint var28 = null;
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Stroke[] var32 = null;
//     java.awt.Shape var33 = null;
//     java.awt.Shape[] var34 = new java.awt.Shape[] { var33};
//     org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var27, var29, var31, var32, var34);
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var37 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var36.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var37);
//     org.jfree.chart.event.RendererChangeEvent var39 = null;
//     var36.notifyListeners(var39);
//     var36.setItemLabelAnchorOffset(4.0d);
//     org.jfree.chart.ChartRenderingInfo var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
//     java.awt.geom.Rectangle2D var46 = var45.getDataArea();
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var46, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     var51.setRenderer(0, var53, true);
//     java.awt.Paint var56 = var51.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var57 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var46, var56);
//     var36.setSeriesShape(10, (java.awt.Shape)var46);
//     boolean var59 = var36.getAutoPopulateSeriesPaint();
//     java.awt.Paint var62 = var36.getItemFillPaint(0, 10);
//     java.awt.Paint var64 = null;
//     var36.setSeriesItemLabelPaint(100, var64);
//     java.awt.Stroke var67 = var36.lookupSeriesOutlineStroke(10);
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
//     org.jfree.data.category.CategoryDataset var69 = null;
//     org.jfree.chart.axis.CategoryAxis var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var69, var70, var71, var72);
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("");
//     var75.setUpperBound(8.0d);
//     java.awt.Stroke var78 = var75.getAxisLineStroke();
//     var73.setOutlineStroke(var78);
//     java.awt.Stroke[] var80 = new java.awt.Stroke[] { var78};
//     org.jfree.chart.ChartRenderingInfo var81 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var82 = new org.jfree.chart.plot.PlotRenderingInfo(var81);
//     java.awt.geom.Rectangle2D var83 = var82.getDataArea();
//     java.awt.Shape[] var84 = new java.awt.Shape[] { var83};
//     org.jfree.chart.plot.DefaultDrawingSupplier var85 = new org.jfree.chart.plot.DefaultDrawingSupplier(var15, var19, var29, var68, var80, var84);
//     
//     // Checks the contract:  equals-hashcode on var25 and var35
//     assertTrue("Contract failed: equals-hashcode on var25 and var35", var25.equals(var35) ? var25.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var25
//     assertTrue("Contract failed: equals-hashcode on var35 and var25", var35.equals(var25) ? var35.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var82
//     assertTrue("Contract failed: equals-hashcode on var45 and var82", var45.equals(var82) ? var45.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var45
//     assertTrue("Contract failed: equals-hashcode on var82 and var45", var82.equals(var45) ? var82.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getDataArea();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.awt.Paint var12 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
//     var13.setLineVisible(true);
//     java.awt.Stroke var16 = var13.getOutlineStroke();
//     org.jfree.chart.util.StandardGradientPaintTransformer var17 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.lang.Object var18 = var17.clone();
//     var13.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var17);
//     org.jfree.chart.util.RectangleInsets var20 = var13.getMargin();
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var23, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     var28.setRenderer(0, var30, true);
//     java.awt.Paint var33 = var28.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var23, var33);
//     var34.setLineVisible(true);
//     java.awt.Shape var37 = var34.getLine();
//     java.awt.Shape var38 = var34.getShape();
//     var13.setLine(var38);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var28
//     assertTrue("Contract failed: equals-hashcode on var7 and var28", var7.equals(var28) ? var7.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    java.util.List var2 = var0.getColumnKeys();
    int var4 = var0.getColumnIndex((java.lang.Comparable)(short)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var0.getRowKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("SortOrder.ASCENDING", var1, 10.0f, 0.0f, var4);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     org.jfree.chart.event.ChartProgressListener var5 = null;
//     var4.removeProgressListener(var5);
//     java.awt.RenderingHints var7 = var4.getRenderingHints();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     var4.draw(var8, var11, var12);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearRangeMarkers(0);
//     float var4 = var1.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var5.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, 10, 10);
//     java.lang.Object var10 = var5.getTextAntiAlias();
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     var5.handleClick(15, (-2), var13);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.TickUnits var4 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var4.add((org.jfree.chart.axis.TickUnit)var6);
    var0.add(8.0d, 4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)var6);
    java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 8.0d+ "'", var9.equals(8.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Point2D var9 = null;
//     var0.zoomDomainAxes(0.0d, var7, var9);
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var12 = null;
//     var11.removeChangeListener(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var17, 1.0d, (-1.0d));
//     var11.draw(var14, var17);
//     var7.setDataArea(var17);
//     
//     // Checks the contract:  equals-hashcode on var7 and var16
//     assertTrue("Contract failed: equals-hashcode on var7 and var16", var7.equals(var16) ? var7.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var7
//     assertTrue("Contract failed: equals-hashcode on var16 and var7", var16.equals(var7) ? var16.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isBorderVisible();
//     int var6 = var4.getBackgroundImageAlignment();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     var11.setDataset(10, var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.clearRangeMarkers(0);
//     float var18 = var15.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var15);
//     org.jfree.chart.event.ChartProgressEvent var22 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var19, 0, 1);
//     var19.setBorderVisible(false);
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var26 = null;
//     var25.removeChangeListener(var26);
//     org.jfree.chart.util.RectangleEdge var28 = var25.getPosition();
//     var19.removeSubtitle((org.jfree.chart.title.Title)var25);
//     boolean var30 = var25.getExpandToFitSpace();
//     var4.removeSubtitle((org.jfree.chart.title.Title)var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    var7.setRenderer(0, var9, true);
    java.awt.Paint var12 = var7.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
    var13.setLineVisible(true);
    java.awt.Stroke var16 = var13.getOutlineStroke();
    java.awt.Paint var17 = var13.getOutlinePaint();
    org.jfree.chart.util.RectangleAnchor var18 = var13.getShapeAnchor();
    org.jfree.chart.text.TextBlockAnchor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition(var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.data.category.CategoryDataset var6 = null;
    var4.setDataset(10, var6);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearRangeMarkers(0);
    float var11 = var8.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
    org.jfree.chart.util.RectangleInsets var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setPadding(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5f);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("UnitType.ABSOLUTE");

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     var4.setDataset(10, var6);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearRangeMarkers(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
//     org.jfree.chart.plot.Plot var16 = var12.getPlot();
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var18 = null;
//     var17.removeChangeListener(var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var23, 1.0d, (-1.0d));
//     var17.draw(var20, var23);
//     var17.setURLText("Category Plot");
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.clearRangeMarkers(0);
//     float var33 = var30.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
//     boolean var35 = var34.isBorderVisible();
//     java.lang.Object var36 = var34.clone();
//     var17.addChangeListener((org.jfree.chart.event.TitleChangeListener)var34);
//     var12.addSubtitle((org.jfree.chart.title.Title)var17);
//     
//     // Checks the contract:  equals-hashcode on var8 and var30
//     assertTrue("Contract failed: equals-hashcode on var8 and var30", var8.equals(var30) ? var8.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var8
//     assertTrue("Contract failed: equals-hashcode on var30 and var8", var30.equals(var8) ? var30.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     java.lang.String var8 = var2.getPlotType();
//     org.jfree.chart.util.SortOrder var9 = var2.getRowRenderingOrder();
//     var2.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var11 = var2.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var13 = var2.getRangeAxisEdge(0);
//     org.jfree.chart.axis.CategoryLabelPosition var14 = var1.getLabelPosition(var13);
//     org.jfree.chart.JFreeChart var16 = null;
//     org.jfree.chart.event.ChartChangeEventType var17 = null;
//     org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"", var16, var17);
//     org.jfree.chart.JFreeChart var19 = null;
//     org.jfree.chart.event.ChartProgressEvent var22 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var18, var19, 10, 10);
//     boolean var23 = var14.equals((java.lang.Object)var18);
//     org.jfree.data.general.DatasetGroup var24 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.clearRangeMarkers(0);
//     float var28 = var25.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
//     var29.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var33 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var24, var29, 10, 10);
//     org.jfree.chart.title.LegendTitle var34 = var29.getLegend();
//     org.jfree.chart.title.TextTitle var35 = null;
//     var29.setTitle(var35);
//     java.awt.RenderingHints var37 = var29.getRenderingHints();
//     org.jfree.chart.title.LegendTitle var39 = var29.getLegend(10);
//     var18.setChart(var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var25
//     assertTrue("Contract failed: equals-hashcode on var2 and var25", var2.equals(var25) ? var2.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var2
//     assertTrue("Contract failed: equals-hashcode on var25 and var2", var25.equals(var2) ? var25.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     var4.setDataset(10, var6);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearRangeMarkers(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
//     var12.setBorderVisible(false);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var18.removeChangeListener(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var18.getPosition();
//     var12.removeSubtitle((org.jfree.chart.title.Title)var18);
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var25 = var23.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var23.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var28 = null;
//     var23.setSeriesItemLabelGenerator(10, var28);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var23.setSeriesToolTipGenerator(100, var31);
//     org.jfree.chart.ChartRenderingInfo var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var35 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     java.awt.geom.Rectangle2D var36 = var35.getDataArea();
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var36, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     var41.setRenderer(0, var43, true);
//     java.awt.Paint var46 = var41.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var47 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var36, var46);
//     var23.setSeriesPaint(0, var46);
//     var12.setBorderPaint(var46);
//     
//     // Checks the contract:  equals-hashcode on var4 and var41
//     assertTrue("Contract failed: equals-hashcode on var4 and var41", var4.equals(var41) ? var4.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var4
//     assertTrue("Contract failed: equals-hashcode on var41 and var4", var41.equals(var4) ? var41.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SortOrder.ASCENDING", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.event.RendererChangeEvent var5 = null;
//     var4.notifyListeners(var5);
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     java.awt.geom.Rectangle2D var10 = var9.getDataArea();
//     var4.setSeriesShape(1, (java.awt.Shape)var10, false);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var15 = var13.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var13.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
//     var13.setSeriesItemLabelGenerator(10, var18);
//     org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
//     var13.setSeriesToolTipGenerator(100, var21);
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var25 = var23.lookupSeriesPaint(1);
//     var13.setBaseOutlinePaint(var25, false);
//     boolean var28 = var13.isDrawBarOutline();
//     var13.setIncludeBaseInRange(false);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.clearRangeMarkers(0);
//     float var34 = var31.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     int var36 = var31.getDomainAxisIndex(var35);
//     java.lang.String var37 = var31.getPlotType();
//     org.jfree.chart.LegendItemCollection var38 = var31.getLegendItems();
//     boolean var39 = var13.hasListener((java.util.EventListener)var31);
//     org.jfree.chart.util.RectangleEdge var41 = var31.getDomainAxisEdge((-1));
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
//     org.jfree.chart.axis.AxisState var44 = var0.draw(var1, 0.0d, var3, var10, var41, var43);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    var7.setRenderer(0, var9, true);
    java.awt.Paint var12 = var7.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
    var13.setLineVisible(true);
    java.awt.Stroke var16 = var13.getOutlineStroke();
    java.awt.Paint var17 = var13.getOutlinePaint();
    org.jfree.chart.util.RectangleAnchor var18 = var13.getShapeAnchor();
    java.awt.Paint var19 = var13.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 0.5f, 10.0f, 1.0d, 1.0f, 1.0f);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     java.awt.Paint var10 = null;
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     java.awt.Paint var12 = null;
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     java.awt.Stroke var14 = null;
//     java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
//     java.awt.Stroke[] var16 = null;
//     java.awt.Shape var17 = null;
//     java.awt.Shape[] var18 = new java.awt.Shape[] { var17};
//     org.jfree.chart.plot.DefaultDrawingSupplier var19 = new org.jfree.chart.plot.DefaultDrawingSupplier(var11, var13, var15, var16, var18);
//     java.awt.Paint var20 = null;
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     java.awt.Paint var22 = null;
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     java.awt.Stroke var24 = null;
//     java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
//     java.awt.Stroke[] var26 = null;
//     java.awt.Shape var27 = null;
//     java.awt.Shape[] var28 = new java.awt.Shape[] { var27};
//     org.jfree.chart.plot.DefaultDrawingSupplier var29 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var23, var25, var26, var28);
//     java.awt.Paint var30 = null;
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var30};
//     java.awt.Paint var32 = null;
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Stroke[] var36 = null;
//     java.awt.Shape var37 = null;
//     java.awt.Shape[] var38 = new java.awt.Shape[] { var37};
//     org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier(var31, var33, var35, var36, var38);
//     java.awt.Paint var40 = null;
//     java.awt.Paint[] var41 = new java.awt.Paint[] { var40};
//     java.awt.Paint var42 = null;
//     java.awt.Paint[] var43 = new java.awt.Paint[] { var42};
//     java.awt.Stroke var44 = null;
//     java.awt.Stroke[] var45 = new java.awt.Stroke[] { var44};
//     java.awt.Stroke[] var46 = null;
//     java.awt.Shape var47 = null;
//     java.awt.Shape[] var48 = new java.awt.Shape[] { var47};
//     org.jfree.chart.plot.DefaultDrawingSupplier var49 = new org.jfree.chart.plot.DefaultDrawingSupplier(var41, var43, var45, var46, var48);
//     org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var13, var26, var36, var48);
//     
//     // Checks the contract:  equals-hashcode on var9 and var19
//     assertTrue("Contract failed: equals-hashcode on var9 and var19", var9.equals(var19) ? var9.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var29
//     assertTrue("Contract failed: equals-hashcode on var9 and var29", var9.equals(var29) ? var9.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var39
//     assertTrue("Contract failed: equals-hashcode on var9 and var39", var9.equals(var39) ? var9.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var49
//     assertTrue("Contract failed: equals-hashcode on var9 and var49", var9.equals(var49) ? var9.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var9
//     assertTrue("Contract failed: equals-hashcode on var19 and var9", var19.equals(var9) ? var19.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var29
//     assertTrue("Contract failed: equals-hashcode on var19 and var29", var19.equals(var29) ? var19.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var39
//     assertTrue("Contract failed: equals-hashcode on var19 and var39", var19.equals(var39) ? var19.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var49
//     assertTrue("Contract failed: equals-hashcode on var19 and var49", var19.equals(var49) ? var19.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var9
//     assertTrue("Contract failed: equals-hashcode on var29 and var9", var29.equals(var9) ? var29.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var19
//     assertTrue("Contract failed: equals-hashcode on var29 and var19", var29.equals(var19) ? var29.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var39
//     assertTrue("Contract failed: equals-hashcode on var29 and var39", var29.equals(var39) ? var29.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var49
//     assertTrue("Contract failed: equals-hashcode on var29 and var49", var29.equals(var49) ? var29.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var9
//     assertTrue("Contract failed: equals-hashcode on var39 and var9", var39.equals(var9) ? var39.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var19
//     assertTrue("Contract failed: equals-hashcode on var39 and var19", var39.equals(var19) ? var39.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var29
//     assertTrue("Contract failed: equals-hashcode on var39 and var29", var39.equals(var29) ? var39.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var49
//     assertTrue("Contract failed: equals-hashcode on var39 and var49", var39.equals(var49) ? var39.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var9
//     assertTrue("Contract failed: equals-hashcode on var49 and var9", var49.equals(var9) ? var49.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var19
//     assertTrue("Contract failed: equals-hashcode on var49 and var19", var49.equals(var19) ? var49.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var29
//     assertTrue("Contract failed: equals-hashcode on var49 and var29", var49.equals(var29) ? var49.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var39
//     assertTrue("Contract failed: equals-hashcode on var49 and var39", var49.equals(var39) ? var49.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getDataArea();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.awt.Paint var12 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
//     var13.setLineVisible(true);
//     java.awt.Stroke var16 = var13.getOutlineStroke();
//     java.awt.Paint var17 = var13.getOutlinePaint();
//     org.jfree.chart.util.RectangleAnchor var18 = var13.getShapeAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var20 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var19.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var20);
//     org.jfree.chart.event.RendererChangeEvent var22 = null;
//     var19.notifyListeners(var22);
//     var19.setItemLabelAnchorOffset(4.0d);
//     boolean var28 = var19.getItemVisible(1, 10);
//     org.jfree.chart.util.GradientPaintTransformer var29 = var19.getGradientPaintTransformer();
//     var13.setFillPaintTransformer(var29);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var33 = var32.getPaint();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.clearRangeMarkers(0);
//     float var37 = var34.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     int var39 = var34.getDomainAxisIndex(var38);
//     java.lang.String var40 = var34.getPlotType();
//     org.jfree.chart.util.RectangleInsets var41 = var34.getInsets();
//     var32.setMargin(var41);
//     double var44 = var41.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.TickUnits var45 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var46 = var45.clone();
//     org.jfree.chart.ChartRenderingInfo var47 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var48 = new org.jfree.chart.plot.PlotRenderingInfo(var47);
//     java.awt.geom.Rectangle2D var49 = var48.getDataArea();
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var49);
//     boolean var51 = var45.equals((java.lang.Object)var49);
//     java.awt.geom.Rectangle2D var54 = var41.createOutsetRectangle(var49, false, false);
//     var13.draw(var31, var54);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var9 = var8.getPaint();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearRangeMarkers(0);
//     float var13 = var10.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     int var15 = var10.getDomainAxisIndex(var14);
//     java.lang.String var16 = var10.getPlotType();
//     org.jfree.chart.util.RectangleInsets var17 = var10.getInsets();
//     var8.setMargin(var17);
//     double var20 = var17.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.TickUnits var21 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var22 = var21.clone();
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     java.awt.geom.Rectangle2D var25 = var24.getDataArea();
//     java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var25);
//     boolean var27 = var21.equals((java.lang.Object)var25);
//     java.awt.geom.Rectangle2D var30 = var17.createOutsetRectangle(var25, false, false);
//     java.awt.Paint var31 = null;
//     java.awt.Paint[] var32 = new java.awt.Paint[] { var31};
//     java.awt.Paint var33 = null;
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     java.awt.Stroke var35 = null;
//     java.awt.Stroke[] var36 = new java.awt.Stroke[] { var35};
//     java.awt.Stroke[] var37 = null;
//     java.awt.Shape var38 = null;
//     java.awt.Shape[] var39 = new java.awt.Shape[] { var38};
//     org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var34, var36, var37, var39);
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("");
//     var42.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var45 = var42.getStandardTickUnits();
//     boolean var46 = var40.equals((java.lang.Object)var42);
//     var42.setTickMarksVisible(false);
//     var42.setFixedDimension(0.0d);
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var51, var52, var53, var54);
//     org.jfree.chart.axis.AxisSpace var56 = var55.getFixedDomainAxisSpace();
//     boolean var57 = var55.isOutlineVisible();
//     var42.setPlot((org.jfree.chart.plot.Plot)var55);
//     org.jfree.chart.axis.TickUnits var60 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var61 = var60.clone();
//     org.jfree.chart.ChartRenderingInfo var62 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var63 = new org.jfree.chart.plot.PlotRenderingInfo(var62);
//     java.awt.geom.Rectangle2D var64 = var63.getDataArea();
//     java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var64);
//     boolean var66 = var60.equals((java.lang.Object)var64);
//     org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var68 = null;
//     var67.removeChangeListener(var68);
//     org.jfree.chart.util.RectangleEdge var70 = var67.getPosition();
//     double var71 = var42.lengthToJava2D(116.0d, var64, var70);
//     org.jfree.chart.axis.AxisSpace var72 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.String var73 = var72.toString();
//     org.jfree.chart.axis.AxisSpace var74 = var0.reserveSpace(var1, (org.jfree.chart.plot.Plot)var2, var30, var70, var72);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 8.0d);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var6 = null;
    var5.removeChangeListener(var6);
    org.jfree.chart.block.CenterArrangement var8 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var9.removeChangeListener(var10);
    java.lang.Object var12 = var9.clone();
    boolean var13 = var8.equals(var12);
    var4.add((org.jfree.chart.block.Block)var5, var12);
    org.jfree.chart.ChartRenderingInfo var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
    java.awt.geom.Rectangle2D var17 = var16.getDataArea();
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var17, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    var22.setRenderer(0, var24, true);
    java.awt.Paint var27 = var22.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var17, var27);
    org.jfree.chart.block.BlockResult var29 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var30 = var29.getEntityCollection();
    var4.add((org.jfree.chart.block.Block)var28, (java.lang.Object)var29);
    org.jfree.chart.entity.EntityCollection var32 = var29.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    boolean var9 = var4.equals((java.lang.Object)var8);
    java.lang.Object var10 = var4.clone();
    var0.setFixedDomainAxisSpace(var4);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var17 = var14.getStandardTickUnits();
    var14.setLabelToolTip("SortOrder.ASCENDING");
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var14, false);
    org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var14.setTickUnit(var23);
    java.lang.Comparable[] var25 = new java.lang.Comparable[] { var23};
    java.lang.Comparable[] var26 = null;
    double[] var27 = null;
    double[][] var28 = new double[][] { var27};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var25, var26, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setAutoTickUnitSelection(false, false);
    org.jfree.data.Range var5 = var1.getDefaultAutoRange();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.clearRangeMarkers(0);
    float var9 = var6.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    int var11 = var6.getDomainAxisIndex(var10);
    org.jfree.chart.plot.Plot var12 = null;
    var6.setParent(var12);
    org.jfree.chart.axis.CategoryAxis var15 = var6.getDomainAxis(1);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var18 = var6.removeAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke[] var6 = null;
    java.awt.Shape var7 = null;
    java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
    org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
    java.lang.Object var10 = var9.clone();
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(var13, 1.0d);
    org.jfree.chart.block.RectangleConstraint var17 = var15.toFixedHeight(0.0d);
    boolean var18 = var9.equals((java.lang.Object)var17);
    java.awt.Paint var19 = var9.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    boolean var9 = var4.equals((java.lang.Object)var8);
    java.lang.Object var10 = var4.clone();
    var0.setFixedDomainAxisSpace(var4);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var17 = var14.getStandardTickUnits();
    var14.setLabelToolTip("SortOrder.ASCENDING");
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var14, false);
    var0.mapDatasetToRangeAxis(15, 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
//     boolean var9 = var4.equals((java.lang.Object)var8);
//     java.lang.Object var10 = var4.clone();
//     var0.setFixedDomainAxisSpace(var4);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var16 = var13.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var13.addRangeMarker((org.jfree.chart.plot.Marker)var18);
//     org.jfree.chart.util.LengthAdjustmentType var20 = var18.getLabelOffsetType();
//     java.awt.Stroke var21 = var18.getStroke();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearRangeMarkers(0);
//     float var25 = var22.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     int var27 = var22.getDomainAxisIndex(var26);
//     java.lang.String var28 = var22.getPlotType();
//     org.jfree.chart.util.SortOrder var29 = var22.getRowRenderingOrder();
//     var22.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var31 = var22.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var33 = var22.getRangeAxisEdge(0);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("");
//     var35.setUpperBound(8.0d);
//     java.awt.Stroke var38 = var35.getAxisLineStroke();
//     float var39 = var35.getTickMarkInsideLength();
//     var35.setVerticalTickLabels(false);
//     org.jfree.data.Range var42 = var22.getDataRange((org.jfree.chart.axis.ValueAxis)var35);
//     var18.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var22);
//     org.jfree.chart.util.Layer var44 = null;
//     var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var18, var44);
//     
//     // Checks the contract:  equals-hashcode on var5 and var22
//     assertTrue("Contract failed: equals-hashcode on var5 and var22", var5.equals(var22) ? var5.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var5
//     assertTrue("Contract failed: equals-hashcode on var22 and var5", var22.equals(var5) ? var22.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(Double.POSITIVE_INFINITY, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.DatasetGroup var2 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getColumnKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + 0.0d+ "'", var1.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var7 = var4.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var9);
//     org.jfree.chart.util.LengthAdjustmentType var11 = var9.getLabelOffsetType();
//     java.awt.Stroke var12 = var9.getStroke();
//     org.jfree.chart.text.TextAnchor var13 = var9.getLabelTextAnchor();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var18 = var15.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var15.addRangeMarker((org.jfree.chart.plot.Marker)var20);
//     org.jfree.chart.util.LengthAdjustmentType var22 = var20.getLabelOffsetType();
//     java.awt.Stroke var23 = var20.getStroke();
//     org.jfree.chart.text.TextAnchor var24 = var20.getLabelTextAnchor();
//     java.awt.Shape var25 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var1, 0.0f, 1.0f, var13, 0.0d, var24);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isBorderVisible();
//     int var6 = var4.getBackgroundImageAlignment();
//     org.jfree.chart.util.HorizontalAlignment var7 = null;
//     org.jfree.chart.util.VerticalAlignment var8 = null;
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement(var7, var8, 100.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var15.getNegativeItemLabelPositionFallback();
//     var15.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var23 = var21.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var21.getPositiveItemLabelPosition(1, 1);
//     var15.setPositiveItemLabelPositionFallback(var26);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var31 = var30.getFont();
//     var15.setSeriesItemLabelFont(100, var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.clearRangeMarkers(0);
//     float var36 = var33.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     int var38 = var33.getDomainAxisIndex(var37);
//     java.lang.String var39 = var33.getPlotType();
//     org.jfree.chart.util.SortOrder var40 = var33.getRowRenderingOrder();
//     var33.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
//     java.awt.geom.Rectangle2D var44 = var43.getDataArea();
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var44, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
//     var49.setRenderer(0, var51, true);
//     java.awt.Paint var54 = var49.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var55 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var44, var54);
//     var33.setOutlinePaint(var54);
//     org.jfree.chart.text.TextBlock var57 = org.jfree.chart.text.TextUtilities.createTextBlock("", var31, var54);
//     org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var60 = var58.lookupSeriesPaint(1);
//     org.jfree.chart.text.TextBlock var61 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", var31, var60);
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=0,b=0]", var31);
//     var62.setToolTipText("SortOrder.ASCENDING");
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     var65.clearRangeMarkers(0);
//     float var68 = var65.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var69 = null;
//     int var70 = var65.getDomainAxisIndex(var69);
//     java.lang.String var71 = var65.getPlotType();
//     org.jfree.chart.util.SortOrder var72 = var65.getRowRenderingOrder();
//     java.lang.String var73 = var72.toString();
//     var11.add((org.jfree.chart.block.Block)var62, (java.lang.Object)var72);
//     var4.addSubtitle((org.jfree.chart.title.Title)var62);
//     
//     // Checks the contract:  equals-hashcode on var0 and var65
//     assertTrue("Contract failed: equals-hashcode on var0 and var65", var0.equals(var65) ? var0.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var0
//     assertTrue("Contract failed: equals-hashcode on var65 and var0", var65.equals(var0) ? var65.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
    boolean var5 = var0.equals((java.lang.Object)var4);
    java.lang.Object var6 = var0.clone();
    double var7 = var0.getLeft();
    var0.setRight(116.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
//     boolean var15 = var9.equals((java.lang.Object)var11);
//     var11.setTickMarksVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var19 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var18.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var19);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setUpperBound(8.0d);
//     java.awt.Stroke var26 = var23.getAxisLineStroke();
//     var18.setSeriesOutlineStroke(0, var26, true);
//     var11.setAxisLineStroke(var26);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var30.removeChangeListener(var31);
//     double var33 = var30.getContentXOffset();
//     java.lang.String var34 = var30.getText();
//     org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var36 = var35.getPaint();
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     var37.clearRangeMarkers(0);
//     float var40 = var37.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var41 = null;
//     int var42 = var37.getDomainAxisIndex(var41);
//     java.lang.String var43 = var37.getPlotType();
//     org.jfree.chart.util.RectangleInsets var44 = var37.getInsets();
//     var35.setMargin(var44);
//     double var47 = var44.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("");
//     var49.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var52 = var49.getStandardTickUnits();
//     var49.resizeRange(4.0d);
//     var49.setLowerBound((-17.0d));
//     org.jfree.chart.ChartRenderingInfo var57 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var58 = new org.jfree.chart.plot.PlotRenderingInfo(var57);
//     java.awt.geom.Rectangle2D var59 = var58.getDataArea();
//     java.awt.Shape var62 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var59, 1.0d, (-1.0d));
//     var49.setUpArrow((java.awt.Shape)var59);
//     java.awt.geom.Rectangle2D var64 = var44.createOutsetRectangle(var59);
//     var30.setBounds(var64);
//     var11.setDownArrow((java.awt.Shape)var64);
//     
//     // Checks the contract:  equals-hashcode on var14 and var52
//     assertTrue("Contract failed: equals-hashcode on var14 and var52", var14.equals(var52) ? var14.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var14
//     assertTrue("Contract failed: equals-hashcode on var52 and var14", var52.equals(var14) ? var52.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var13, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     var18.setRenderer(0, var20, true);
//     java.awt.Paint var23 = var18.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var24 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var13, var23);
//     var0.setSeriesPaint(0, var23);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearRangeMarkers(0);
//     float var29 = var26.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     int var31 = var26.getDomainAxisIndex(var30);
//     java.lang.String var32 = var26.getPlotType();
//     org.jfree.chart.util.SortOrder var33 = var26.getRowRenderingOrder();
//     var26.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Rectangle2D var37 = var36.getDataArea();
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var37, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     var42.setRenderer(0, var44, true);
//     java.awt.Paint var47 = var42.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var37, var47);
//     var26.setOutlinePaint(var47);
//     var0.setBasePaint(var47);
//     
//     // Checks the contract:  equals-hashcode on var12 and var36
//     assertTrue("Contract failed: equals-hashcode on var12 and var36", var12.equals(var36) ? var12.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var12
//     assertTrue("Contract failed: equals-hashcode on var36 and var12", var36.equals(var12) ? var36.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var42
//     assertTrue("Contract failed: equals-hashcode on var18 and var42", var18.equals(var42) ? var18.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var18
//     assertTrue("Contract failed: equals-hashcode on var42 and var18", var42.equals(var18) ? var42.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("NOID");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var3.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var6 = var3.getNegativeItemLabelPositionFallback();
    var3.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var11 = var9.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var14 = var9.getPositiveItemLabelPosition(1, 1);
    var3.setPositiveItemLabelPositionFallback(var14);
    org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var19 = var18.getFont();
    var3.setSeriesItemLabelFont(100, var19);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.clearRangeMarkers(0);
    float var24 = var21.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var25 = null;
    int var26 = var21.getDomainAxisIndex(var25);
    java.lang.String var27 = var21.getPlotType();
    org.jfree.chart.util.SortOrder var28 = var21.getRowRenderingOrder();
    var21.clearDomainAxes();
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    java.awt.geom.Rectangle2D var32 = var31.getDataArea();
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var32, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    var37.setRenderer(0, var39, true);
    java.awt.Paint var42 = var37.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var32, var42);
    var21.setOutlinePaint(var42);
    org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, var42);
    var1.setLabelFont(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Category Plot"+ "'", var27.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("UnitType.ABSOLUTE", "NOID", var3);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     var4.setDataset(10, var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var11, 1.0d, (-1.0d));
//     var4.drawBackgroundImage(var8, var11);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var21 = var18.getRowRenderingOrder();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     org.jfree.chart.ChartRenderingInfo var26 = var25.getOwner();
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     var25.addSubplotInfo(var28);
//     java.awt.geom.Point2D var30 = null;
//     var18.zoomDomainAxes(8.0d, (-1.0d), var25, var30);
//     var4.handleClick(0, 15, var25);
//     
//     // Checks the contract:  equals-hashcode on var10 and var28
//     assertTrue("Contract failed: equals-hashcode on var10 and var28", var10.equals(var28) ? var10.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var10
//     assertTrue("Contract failed: equals-hashcode on var28 and var10", var28.equals(var10) ? var28.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(8.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var7 = var6.getPaint();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearRangeMarkers(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     int var13 = var8.getDomainAxisIndex(var12);
//     java.lang.String var14 = var8.getPlotType();
//     org.jfree.chart.util.RectangleInsets var15 = var8.getInsets();
//     var6.setMargin(var15);
//     double var18 = var15.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.TickUnits var19 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var20 = var19.clone();
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var23);
//     boolean var25 = var19.equals((java.lang.Object)var23);
//     java.awt.geom.Rectangle2D var28 = var15.createOutsetRectangle(var23, false, false);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var33 = var30.getStandardTickUnits();
//     var30.resizeRange(4.0d);
//     var30.setLowerBound((-17.0d));
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     java.awt.geom.Rectangle2D var40 = var39.getDataArea();
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var40, 1.0d, (-1.0d));
//     var30.setUpArrow((java.awt.Shape)var40);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var45 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.chart.axis.TickUnits var49 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.NumberTickUnit var51 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     var49.add((org.jfree.chart.axis.TickUnit)var51);
//     var45.add(8.0d, 4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)var51);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     var54.setRenderer(0, var56, true);
//     java.lang.Object var59 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var54);
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     var54.setRangeAxis(0, var61);
//     var45.addChangeListener((org.jfree.data.general.DatasetChangeListener)var54);
//     double var64 = var54.getAnchorValue();
//     org.jfree.chart.util.RectangleEdge var65 = var54.getRangeAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var66 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var67 = new org.jfree.chart.plot.PlotRenderingInfo(var66);
//     java.awt.geom.Rectangle2D var68 = var67.getDataArea();
//     org.jfree.chart.ChartRenderingInfo var69 = var67.getOwner();
//     org.jfree.chart.axis.AxisState var70 = var1.draw(var4, 1.0d, var23, var40, var65, var67);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Size2D[width=-1.0, height=10.0]", var3);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isBorderVisible();
//     int var6 = var4.getBackgroundImageAlignment();
//     java.awt.Image var7 = var4.getBackgroundImage();
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     var12.setDataset(10, var14);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.clearRangeMarkers(0);
//     float var19 = var16.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.event.ChartProgressEvent var23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var20, 0, 1);
//     var20.setBorderVisible(false);
//     java.awt.RenderingHints var26 = var20.getRenderingHints();
//     var4.setRenderingHints(var26);
//     
//     // Checks the contract:  equals-hashcode on var0 and var16
//     assertTrue("Contract failed: equals-hashcode on var0 and var16", var0.equals(var16) ? var0.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var20
//     assertTrue("Contract failed: equals-hashcode on var4 and var20", var4.equals(var20) ? var4.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var4
//     assertTrue("Contract failed: equals-hashcode on var20 and var4", var20.equals(var4) ? var20.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var5 = var3.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var6 = var3.getNegativeItemLabelPositionFallback();
//     var3.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var11 = var9.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var14 = var9.getPositiveItemLabelPosition(1, 1);
//     var3.setPositiveItemLabelPositionFallback(var14);
//     org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var19 = var18.getFont();
//     var3.setSeriesItemLabelFont(100, var19);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.clearRangeMarkers(0);
//     float var24 = var21.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     int var26 = var21.getDomainAxisIndex(var25);
//     java.lang.String var27 = var21.getPlotType();
//     org.jfree.chart.util.SortOrder var28 = var21.getRowRenderingOrder();
//     var21.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     java.awt.geom.Rectangle2D var32 = var31.getDataArea();
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var32, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     var37.setRenderer(0, var39, true);
//     java.awt.Paint var42 = var37.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var32, var42);
//     var21.setOutlinePaint(var42);
//     org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, var42);
//     var1.setLabelFont(var19);
//     java.lang.Class var47 = null;
//     java.util.EventListener[] var48 = var1.getListeners(var47);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Point2D var9 = null;
//     var0.zoomDomainAxes(0.0d, var7, var9);
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var0.getRangeMarkers(var11);
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     java.awt.geom.Rectangle2D var15 = var14.getDataArea();
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var15, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     var20.setRenderer(0, var22, true);
//     java.awt.Paint var25 = var20.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var26 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var15, var25);
//     var0.setRangeGridlinePaint(var25);
//     
//     // Checks the contract:  equals-hashcode on var7 and var14
//     assertTrue("Contract failed: equals-hashcode on var7 and var14", var7.equals(var14) ? var7.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var7
//     assertTrue("Contract failed: equals-hashcode on var14 and var7", var14.equals(var7) ? var14.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setAutoTickUnitSelection(false, false);
//     org.jfree.data.Range var5 = var1.getDefaultAutoRange();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearRangeMarkers(0);
//     float var9 = var6.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     int var11 = var6.getDomainAxisIndex(var10);
//     org.jfree.chart.plot.Plot var12 = null;
//     var6.setParent(var12);
//     org.jfree.chart.axis.CategoryAxis var15 = var6.getDomainAxis(1);
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     var18.setRenderer(0, var20, true);
//     java.lang.Object var23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//     org.jfree.chart.axis.AxisLocation var24 = var18.getRangeAxisLocation();
//     org.jfree.chart.axis.AxisLocation var25 = org.jfree.chart.axis.AxisLocation.getOpposite(var24);
//     var6.setRangeAxisLocation(15, var25);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     var28.setRenderer(0, var30, true);
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var28);
//     boolean var34 = var25.equals((java.lang.Object)var28);
//     
//     // Checks the contract:  equals-hashcode on var18 and var28
//     assertTrue("Contract failed: equals-hashcode on var18 and var28", var18.equals(var28) ? var18.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var18
//     assertTrue("Contract failed: equals-hashcode on var28 and var18", var28.equals(var18) ? var28.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var3.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var6 = var3.getNegativeItemLabelPositionFallback();
    var3.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var11 = var9.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var14 = var9.getPositiveItemLabelPosition(1, 1);
    var3.setPositiveItemLabelPositionFallback(var14);
    org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var19 = var18.getFont();
    var3.setSeriesItemLabelFont(100, var19);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.clearRangeMarkers(0);
    float var24 = var21.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var25 = null;
    int var26 = var21.getDomainAxisIndex(var25);
    java.lang.String var27 = var21.getPlotType();
    org.jfree.chart.util.SortOrder var28 = var21.getRowRenderingOrder();
    var21.clearDomainAxes();
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    java.awt.geom.Rectangle2D var32 = var31.getDataArea();
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var32, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    var37.setRenderer(0, var39, true);
    java.awt.Paint var42 = var37.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var32, var42);
    var21.setOutlinePaint(var42);
    org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, var42);
    var1.setLabelFont(var19);
    org.jfree.chart.text.TextAnchor var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Category Plot"+ "'", var27.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
//     boolean var6 = var4.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.clearRangeMarkers(0);
//     float var10 = var7.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     int var12 = var7.getDomainAxisIndex(var11);
//     java.lang.String var13 = var7.getPlotType();
//     org.jfree.chart.LegendItemCollection var14 = var7.getLegendItems();
//     java.lang.Object var15 = var14.clone();
//     org.jfree.data.KeyedObjects2D var16 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var17 = var16.getColumnKeys();
//     java.util.List var18 = var16.getColumnKeys();
//     boolean var19 = var14.equals((java.lang.Object)var16);
//     var4.setFixedLegendItems(var14);
//     java.lang.Object var21 = var14.clone();
//     
//     // Checks the contract:  equals-hashcode on var15 and var21
//     assertTrue("Contract failed: equals-hashcode on var15 and var21", var15.equals(var21) ? var15.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var15
//     assertTrue("Contract failed: equals-hashcode on var21 and var15", var21.equals(var15) ? var21.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var12 = var10.lookupSeriesPaint(1);
//     var0.setBaseOutlinePaint(var12, false);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var15.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var20 = null;
//     var15.setSeriesItemLabelGenerator(10, var20);
//     org.jfree.chart.labels.CategoryToolTipGenerator var23 = null;
//     var15.setSeriesToolTipGenerator(100, var23);
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     java.awt.geom.Rectangle2D var28 = var27.getDataArea();
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var28, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     var33.setRenderer(0, var35, true);
//     java.awt.Paint var38 = var33.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var39 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var28, var38);
//     var15.setSeriesPaint(0, var38);
//     var0.setBasePaint(var38);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var15.", var10.equals(var15) == var15.equals(var10));
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    java.util.List var2 = var0.getColumnKeys();
    int var4 = var0.getColumnIndex((java.lang.Comparable)(short)(-1));
    int var6 = var0.getRowIndex((java.lang.Comparable)(short)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    int var2 = var0.getColumnCount();
    int var4 = var0.getColumnIndex((java.lang.Comparable)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(10.0d, 10.0d, var2);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     java.awt.Paint var10 = var9.getNextPaint();
//     java.awt.Shape var11 = var9.getNextShape();
//     java.awt.Stroke var12 = var9.getNextOutlineStroke();
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    var7.setRenderer(0, var9, true);
    java.awt.Paint var12 = var7.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
    var13.setLineVisible(true);
    java.awt.Stroke var16 = var13.getOutlineStroke();
    java.awt.Paint var17 = var13.getOutlinePaint();
    org.jfree.chart.util.RectangleAnchor var18 = var13.getShapeAnchor();
    org.jfree.chart.text.TextBlock var19 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.text.TextBlockAnchor var23 = null;
    var19.draw(var20, 0.0f, 0.0f, var23, 10.0f, 1.0f, 1.0d);
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.CategoryLabelPositions var32 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var34 = null;
    var33.removeChangeListener(var34);
    org.jfree.chart.util.RectangleEdge var36 = var33.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var37 = var32.getLabelPosition(var36);
    org.jfree.chart.text.TextBlockAnchor var38 = var37.getLabelAnchor();
    var19.draw(var28, 10.0f, 0.0f, var38, 0.0f, 0.0f, 100.0d);
    org.jfree.chart.axis.CategoryLabelWidthType var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var45 = new org.jfree.chart.axis.CategoryLabelPosition(var18, var38, var43, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var6 = var4.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     java.lang.String var8 = var2.getPlotType();
//     org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
//     var0.setMargin(var9);
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     var15.setDataset(10, var17);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.clearRangeMarkers(0);
//     float var22 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var23, 0, 1);
//     org.jfree.chart.plot.Plot var27 = var23.getPlot();
//     var0.addChangeListener((org.jfree.chart.event.TitleChangeListener)var23);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
//     boolean var6 = var4.isOutlineVisible();
//     int var7 = var4.getWeight();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearRangeMarkers(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var12 = null;
//     int var13 = var8.getDomainAxisIndex(var12);
//     java.lang.String var14 = var8.getPlotType();
//     org.jfree.chart.util.RectangleInsets var15 = var8.getInsets();
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     var16.setRenderer(0, var18, true);
//     java.awt.Paint var21 = var16.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(var15, var21);
//     var4.setInsets(var15, false);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.RectangleInsets var7 = var0.getInsets();
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     java.awt.geom.Rectangle2D var10 = var9.getDataArea();
//     java.awt.geom.Rectangle2D var11 = var7.createOutsetRectangle(var10);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var14, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     var19.setRenderer(0, var21, true);
//     java.awt.Paint var24 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var25 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var14, var24);
//     var25.setLineVisible(true);
//     java.awt.Stroke var28 = var25.getOutlineStroke();
//     java.awt.Paint var29 = var25.getOutlinePaint();
//     org.jfree.chart.util.RectangleAnchor var30 = var25.getShapeAnchor();
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var11, var30);
//     
//     // Checks the contract:  equals-hashcode on var9 and var13
//     assertTrue("Contract failed: equals-hashcode on var9 and var13", var9.equals(var13) ? var9.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var9
//     assertTrue("Contract failed: equals-hashcode on var13 and var9", var13.equals(var9) ? var13.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesPaint(1);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var6 = var4.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var7 = var4.getNegativeItemLabelPositionFallback();
    var4.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var10.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var15 = var10.getPositiveItemLabelPosition(1, 1);
    var4.setPositiveItemLabelPositionFallback(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-16777216), var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesPaint(1);
    org.jfree.chart.plot.CategoryPlot var3 = var0.getPlot();
    java.awt.Shape var5 = null;
    var0.setSeriesShape(0, var5, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var5 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var4.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var5);
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(8.0d);
//     java.awt.Stroke var12 = var9.getAxisLineStroke();
//     var4.setSeriesOutlineStroke(0, var12, true);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var15.getPositiveItemLabelPosition(1, 1);
//     var4.setBaseNegativeItemLabelPosition(var20, true);
//     org.jfree.chart.text.TextAnchor var23 = var20.getRotationAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var25.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var26);
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     var30.setUpperBound(8.0d);
//     java.awt.Stroke var33 = var30.getAxisLineStroke();
//     var25.setSeriesOutlineStroke(0, var33, true);
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var38 = var36.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var41 = var36.getPositiveItemLabelPosition(1, 1);
//     var25.setBaseNegativeItemLabelPosition(var41, true);
//     org.jfree.chart.text.TextAnchor var44 = var41.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.event.ChartChangeEvent[source=]", var1, 100.0f, 10.0f, var23, 0.0d, var44);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     java.lang.Object var6 = var0.clone();
//     double var7 = var0.getRight();
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     org.jfree.chart.ChartRenderingInfo var10 = var9.getOwner();
//     java.awt.geom.Rectangle2D var11 = var9.getDataArea();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var13 = var12.getPaint();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearRangeMarkers(0);
//     float var17 = var14.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     int var19 = var14.getDomainAxisIndex(var18);
//     java.lang.String var20 = var14.getPlotType();
//     org.jfree.chart.util.RectangleInsets var21 = var14.getInsets();
//     var12.setMargin(var21);
//     double var24 = var21.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.TickUnits var25 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var26 = var25.clone();
//     org.jfree.chart.ChartRenderingInfo var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
//     java.awt.geom.Rectangle2D var29 = var28.getDataArea();
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var29);
//     boolean var31 = var25.equals((java.lang.Object)var29);
//     java.awt.geom.Rectangle2D var34 = var21.createOutsetRectangle(var29, false, false);
//     java.awt.geom.Rectangle2D var35 = var0.expand(var11, var29);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var28
//     assertTrue("Contract failed: equals-hashcode on var9 and var28", var9.equals(var28) ? var9.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var9
//     assertTrue("Contract failed: equals-hashcode on var28 and var9", var28.equals(var9) ? var28.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     var1.setRenderer(0, var3, true);
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var8.notifyListeners(var9);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     var8.setSeriesShape(1, (java.awt.Shape)var14, false);
//     java.awt.geom.Point2D var17 = null;
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     var6.draw(var7, var14, var17, var18);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(8.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    float var5 = var1.getTickMarkInsideLength();
    var1.setLabelAngle(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0f);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(1.0d);
    var1.setCursor(0.0d);
    var1.cursorRight((-1.0d));
    double var6 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setSeriesItemLabelGenerator(10, var5);
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-1), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var1.addRangeMarker((org.jfree.chart.plot.Marker)var6);
    org.jfree.chart.util.LengthAdjustmentType var8 = var6.getLabelOffsetType();
    java.awt.Stroke var9 = var6.getStroke();
    org.jfree.chart.text.TextAnchor var10 = var6.getLabelTextAnchor();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var14 = var11.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var11.addRangeMarker((org.jfree.chart.plot.Marker)var16);
    org.jfree.chart.util.LengthAdjustmentType var18 = var16.getLabelOffsetType();
    java.awt.Stroke var19 = var16.getStroke();
    org.jfree.chart.text.TextAnchor var20 = var16.getLabelTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var22 = new org.jfree.chart.labels.ItemLabelPosition(var0, var10, var20, (-17.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("NOID", "", "", var3, "AxisLocation.TOP_OR_LEFT", "AxisLocation.TOP_OR_LEFT", "java.awt.Color[r=0,g=0,b=0]");
    java.util.List var8 = var7.getContributors();
    var7.setName("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, Double.NaN, false);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.ChartRenderingInfo var2 = null;
    org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var2);
    java.awt.geom.Rectangle2D var4 = var3.getDataArea();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var4);
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.lang.Object var7 = null;
    boolean var8 = var0.equals(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var10 = var0.get((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var4 = null;
    var3.removeChangeListener(var4);
    org.jfree.chart.util.RectangleEdge var6 = var3.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var7 = var2.getLabelPosition(var6);
    org.jfree.chart.text.TextBlockAnchor var8 = var7.getLabelAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(15, (-2), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var12 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var11.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var12);
    org.jfree.chart.event.RendererChangeEvent var14 = null;
    var11.notifyListeners(var14);
    var11.setItemLabelAnchorOffset(4.0d);
    var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11, true);
    java.awt.Shape var22 = var11.getItemShape(10, 0);
    java.awt.Paint var23 = var11.getBasePaint();
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSeriesItemLabelGenerator((-1), var25, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.RectangleInsets var7 = var0.getInsets();
    org.jfree.chart.util.SortOrder var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.DatasetGroup var2 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getRowKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + 0.0d+ "'", var1.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var0.notifyListeners(var3);
//     var0.setItemLabelAnchorOffset(4.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var8 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var7);
//     boolean var10 = var0.isSeriesVisible(0);
//     var0.setItemLabelAnchorOffset(0.0d);
//     java.awt.Paint var13 = var0.getBaseOutlinePaint();
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     java.awt.Paint var15 = null;
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
//     java.awt.Paint var17 = null;
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Stroke[] var21 = null;
//     java.awt.Shape var22 = null;
//     java.awt.Shape[] var23 = new java.awt.Shape[] { var22};
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var18, var20, var21, var23);
//     java.awt.Paint var25 = null;
//     java.awt.Paint[] var26 = new java.awt.Paint[] { var25};
//     java.awt.Paint var27 = null;
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     java.awt.Stroke[] var31 = null;
//     java.awt.Shape var32 = null;
//     java.awt.Shape[] var33 = new java.awt.Shape[] { var32};
//     org.jfree.chart.plot.DefaultDrawingSupplier var34 = new org.jfree.chart.plot.DefaultDrawingSupplier(var26, var28, var30, var31, var33);
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Paint var37 = null;
//     java.awt.Paint[] var38 = new java.awt.Paint[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Stroke[] var41 = null;
//     java.awt.Shape var42 = null;
//     java.awt.Shape[] var43 = new java.awt.Shape[] { var42};
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var38, var40, var41, var43);
//     java.awt.Paint var45 = null;
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var45};
//     java.awt.Paint var47 = null;
//     java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Stroke[] var51 = null;
//     java.awt.Shape var52 = null;
//     java.awt.Shape[] var53 = new java.awt.Shape[] { var52};
//     org.jfree.chart.plot.DefaultDrawingSupplier var54 = new org.jfree.chart.plot.DefaultDrawingSupplier(var46, var48, var50, var51, var53);
//     java.awt.Paint var55 = null;
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var55};
//     java.awt.Paint var57 = null;
//     java.awt.Paint[] var58 = new java.awt.Paint[] { var57};
//     java.awt.Stroke var59 = null;
//     java.awt.Stroke[] var60 = new java.awt.Stroke[] { var59};
//     java.awt.Stroke[] var61 = null;
//     java.awt.Shape var62 = null;
//     java.awt.Shape[] var63 = new java.awt.Shape[] { var62};
//     org.jfree.chart.plot.DefaultDrawingSupplier var64 = new org.jfree.chart.plot.DefaultDrawingSupplier(var56, var58, var60, var61, var63);
//     org.jfree.chart.plot.DefaultDrawingSupplier var65 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var16, var26, var41, var51, var63);
//     
//     // Checks the contract:  equals-hashcode on var24 and var34
//     assertTrue("Contract failed: equals-hashcode on var24 and var34", var24.equals(var34) ? var24.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var44
//     assertTrue("Contract failed: equals-hashcode on var24 and var44", var24.equals(var44) ? var24.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var54
//     assertTrue("Contract failed: equals-hashcode on var24 and var54", var24.equals(var54) ? var24.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var64
//     assertTrue("Contract failed: equals-hashcode on var24 and var64", var24.equals(var64) ? var24.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var24
//     assertTrue("Contract failed: equals-hashcode on var34 and var24", var34.equals(var24) ? var34.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var44
//     assertTrue("Contract failed: equals-hashcode on var34 and var44", var34.equals(var44) ? var34.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var54
//     assertTrue("Contract failed: equals-hashcode on var34 and var54", var34.equals(var54) ? var34.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var64
//     assertTrue("Contract failed: equals-hashcode on var34 and var64", var34.equals(var64) ? var34.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var24
//     assertTrue("Contract failed: equals-hashcode on var44 and var24", var44.equals(var24) ? var44.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var34
//     assertTrue("Contract failed: equals-hashcode on var44 and var34", var44.equals(var34) ? var44.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var54
//     assertTrue("Contract failed: equals-hashcode on var44 and var54", var44.equals(var54) ? var44.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var64
//     assertTrue("Contract failed: equals-hashcode on var44 and var64", var44.equals(var64) ? var44.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var24
//     assertTrue("Contract failed: equals-hashcode on var54 and var24", var54.equals(var24) ? var54.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var34
//     assertTrue("Contract failed: equals-hashcode on var54 and var34", var54.equals(var34) ? var54.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var44
//     assertTrue("Contract failed: equals-hashcode on var54 and var44", var54.equals(var44) ? var54.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var64
//     assertTrue("Contract failed: equals-hashcode on var54 and var64", var54.equals(var64) ? var54.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var24
//     assertTrue("Contract failed: equals-hashcode on var64 and var24", var64.equals(var24) ? var64.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var34
//     assertTrue("Contract failed: equals-hashcode on var64 and var34", var64.equals(var34) ? var64.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var44
//     assertTrue("Contract failed: equals-hashcode on var64 and var44", var64.equals(var44) ? var64.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var54
//     assertTrue("Contract failed: equals-hashcode on var64 and var54", var64.equals(var54) ? var64.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    boolean var9 = var4.equals((java.lang.Object)var8);
    java.lang.Object var10 = var4.clone();
    var0.setFixedDomainAxisSpace(var4);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var17 = var14.getStandardTickUnits();
    var14.setLabelToolTip("SortOrder.ASCENDING");
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var14, false);
    org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var14.setTickUnit(var23);
    java.lang.String var25 = var23.toString();
    java.awt.Shape var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)var25, var26, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "[size=10]"+ "'", var25.equals("[size=10]"));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { (short)1};
    java.lang.Comparable[] var2 = null;
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("[size=10]");

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5);
    org.jfree.chart.util.LengthAdjustmentType var7 = var5.getLabelOffsetType();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(8.0d);
    java.awt.Stroke var12 = var9.getAxisLineStroke();
    var5.setStroke(var12);
    org.jfree.chart.util.RectangleAnchor var14 = var5.getLabelAnchor();
    org.jfree.chart.util.RectangleAnchor var15 = var5.getLabelAnchor();
    org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextLine var17 = var16.getLastLine();
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.util.Size2D var19 = var16.calculateDimensions(var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.text.TextBlock var23 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.text.TextBlockAnchor var27 = null;
    var23.draw(var24, 0.0f, 0.0f, var27, 10.0f, 1.0f, 1.0d);
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.axis.CategoryLabelPositions var36 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
    org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var38 = null;
    var37.removeChangeListener(var38);
    org.jfree.chart.util.RectangleEdge var40 = var37.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var41 = var36.getLabelPosition(var40);
    org.jfree.chart.text.TextBlockAnchor var42 = var41.getLabelAnchor();
    var23.draw(var32, 10.0f, 0.0f, var42, 0.0f, 0.0f, 100.0d);
    var16.draw(var20, 0.0f, 0.0f, var42);
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
    var48.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var51 = var48.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var48.addRangeMarker((org.jfree.chart.plot.Marker)var53);
    org.jfree.chart.util.LengthAdjustmentType var55 = var53.getLabelOffsetType();
    java.awt.Stroke var56 = var53.getStroke();
    org.jfree.chart.text.TextAnchor var57 = var53.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var61 = new org.jfree.chart.axis.CategoryLabelPosition(var15, var42, var57, Double.POSITIVE_INFINITY, var59, 0.5f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    var1.setRenderer(0, var3, true);
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var10 = var6.createBufferedImage(255, 0, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.ChartRenderingInfo var4 = null;
    org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
    java.awt.geom.Rectangle2D var6 = var5.getDataArea();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var6);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var8.setRenderer(0, var10, true);
    java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var8);
    org.jfree.chart.axis.ValueAxis var15 = null;
    var8.setRangeAxis(0, var15);
    float var17 = var8.getBackgroundImageAlpha();
    java.awt.Paint var18 = var8.getNoDataMessagePaint();
    java.awt.Stroke var19 = null;
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var20.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var21);
    org.jfree.chart.event.RendererChangeEvent var23 = null;
    var20.notifyListeners(var23);
    var20.setItemLabelAnchorOffset(4.0d);
    java.awt.Paint var27 = var20.getBaseOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem(var0, "Range[0.0,0.0]", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Size2D[width=-1.0, height=10.0]", var7, var18, var19, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.5f, 0.0f, 10.0d, 0.5f, 0.0f);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(2.0d, var1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(Double.NaN, 2.0d);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(10, (-1), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    var0.setWeight(100);
    var0.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var13 = var0.getDataset((-16777216));
    org.jfree.chart.plot.CategoryMarker var14 = null;
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
    org.jfree.chart.plot.CategoryPlot var4 = var0.getPlot();
    org.jfree.chart.plot.DrawingSupplier var5 = var0.getDrawingSupplier();
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     java.lang.String var8 = var2.getPlotType();
//     org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
//     var0.setMargin(var9);
//     double var12 = var9.calculateTopOutset(100.0d);
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearRangeMarkers(0);
//     float var16 = var13.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     int var18 = var13.getDomainAxisIndex(var17);
//     java.lang.String var19 = var13.getPlotType();
//     org.jfree.chart.util.RectangleInsets var20 = var13.getInsets();
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     java.awt.geom.Rectangle2D var23 = var22.getDataArea();
//     java.awt.geom.Rectangle2D var24 = var20.createOutsetRectangle(var23);
//     java.awt.geom.Rectangle2D var27 = var9.createOutsetRectangle(var23, true, false);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    int var1 = var0.size();
    java.awt.Stroke var3 = var0.getStroke(0);
    int var4 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.data.category.CategoryDataset var6 = null;
    var4.setDataset(10, var6);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearRangeMarkers(0);
    float var11 = var8.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
    var12.setBorderVisible(false);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var19 = null;
    var18.removeChangeListener(var19);
    org.jfree.chart.util.RectangleEdge var21 = var18.getPosition();
    var12.removeSubtitle((org.jfree.chart.title.Title)var18);
    org.jfree.chart.title.LegendTitle var24 = var12.getLegend((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
    var0.setPositiveItemLabelPositionFallback(var11);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var16 = var15.getFont();
    var0.setSeriesItemLabelFont(100, var16);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var0.getBaseURLGenerator();
    boolean var19 = var0.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 10.0d);
    org.jfree.data.general.DatasetGroup var3 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearRangeMarkers(0);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var8.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var3, var8, 10, 10);
    boolean var13 = var2.equals((java.lang.Object)var12);
    org.jfree.chart.JFreeChart var14 = null;
    var12.setChart(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("NOID", "", "", var3, "AxisLocation.TOP_OR_LEFT", "AxisLocation.TOP_OR_LEFT", "java.awt.Color[r=0,g=0,b=0]");
    java.util.List var8 = var7.getContributors();
    java.awt.Image var9 = var7.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearRangeMarkers(0);
//     float var4 = var1.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var5.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, 10, 10);
//     org.jfree.chart.title.LegendTitle var10 = var5.getLegend();
//     org.jfree.chart.title.TextTitle var11 = null;
//     var5.setTitle(var11);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     var5.handleClick((-16777216), 100, var15);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     var4.setDataset(10, var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var11, 1.0d, (-1.0d));
//     var4.drawBackgroundImage(var8, var11);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.clearRangeMarkers(0);
//     float var19 = var16.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     int var21 = var16.getDomainAxisIndex(var20);
//     java.lang.String var22 = var16.getPlotType();
//     org.jfree.chart.util.RectangleInsets var23 = var16.getInsets();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     java.awt.geom.Rectangle2D var27 = var23.createOutsetRectangle(var26);
//     boolean var28 = org.jfree.chart.util.ShapeUtilities.intersects(var11, var27);
//     
//     // Checks the contract:  equals-hashcode on var10 and var25
//     assertTrue("Contract failed: equals-hashcode on var10 and var25", var10.equals(var25) ? var10.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var10
//     assertTrue("Contract failed: equals-hashcode on var25 and var10", var25.equals(var10) ? var25.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var2 = null;
//     var1.removeChangeListener(var2);
//     double var4 = var1.getContentXOffset();
//     org.jfree.data.KeyedObject var5 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var1);
//     org.jfree.chart.block.BlockResult var6 = new org.jfree.chart.block.BlockResult();
//     var5.setObject((java.lang.Object)var6);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var9 = var8.getPaint();
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var11 = var10.getPaint();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.clearRangeMarkers(0);
//     float var15 = var12.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     int var17 = var12.getDomainAxisIndex(var16);
//     java.lang.String var18 = var12.getPlotType();
//     org.jfree.chart.util.RectangleInsets var19 = var12.getInsets();
//     var10.setMargin(var19);
//     double var22 = var19.calculateTopOutset(100.0d);
//     var8.setMargin(var19);
//     var5.setObject((java.lang.Object)var19);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var28 = var25.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var25.addRangeMarker((org.jfree.chart.plot.Marker)var30);
//     org.jfree.chart.util.LengthAdjustmentType var32 = var30.getLabelOffsetType();
//     java.awt.Font var33 = var30.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.clearRangeMarkers(0);
//     float var37 = var34.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     int var39 = var34.getDomainAxisIndex(var38);
//     java.lang.String var40 = var34.getPlotType();
//     org.jfree.chart.util.RectangleInsets var41 = var34.getInsets();
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     var42.setRenderer(0, var44, true);
//     java.awt.Paint var47 = var42.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(var41, var47);
//     org.jfree.chart.util.RectangleInsets var49 = var48.getInsets();
//     java.lang.String var50 = var49.toString();
//     var30.setLabelOffset(var49);
//     org.jfree.chart.util.RectangleAnchor var52 = var30.getLabelAnchor();
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     var53.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var56 = var53.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var53.addRangeMarker((org.jfree.chart.plot.Marker)var58);
//     org.jfree.chart.util.LengthAdjustmentType var60 = var58.getLabelOffsetType();
//     var30.setLabelOffsetType(var60);
//     var5.setObject((java.lang.Object)var60);
//     
//     // Checks the contract:  equals-hashcode on var12 and var34
//     assertTrue("Contract failed: equals-hashcode on var12 and var34", var12.equals(var34) ? var12.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var12
//     assertTrue("Contract failed: equals-hashcode on var34 and var12", var34.equals(var12) ? var34.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearRangeMarkers(0);
//     float var4 = var1.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var5.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, 10, 10);
//     org.jfree.chart.title.LegendTitle var10 = var5.getLegend();
//     org.jfree.chart.title.TextTitle var11 = null;
//     var5.setTitle(var11);
//     java.awt.RenderingHints var13 = var5.getRenderingHints();
//     org.jfree.chart.title.LegendTitle var15 = var5.getLegend(10);
//     java.awt.RenderingHints var16 = null;
//     var5.setRenderingHints(var16);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var8 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var7);
    double var9 = var0.getMaximumBarWidth();
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var15 = var13.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var16 = var13.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var13.setSeriesItemLabelGenerator(10, var18);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var13.setSeriesToolTipGenerator(100, var21);
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var25 = var23.lookupSeriesPaint(1);
    var13.setBaseOutlinePaint(var25, false);
    boolean var28 = var13.isDrawBarOutline();
    var13.setIncludeBaseInRange(false);
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var33 = var31.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var34 = var31.getNegativeItemLabelPositionFallback();
    var31.setDrawBarOutline(true);
    java.awt.Stroke var37 = var31.getBaseOutlineStroke();
    var13.setBaseStroke(var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-16777216), var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    java.lang.Object var1 = var0.clone();
    java.lang.String var2 = var0.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "NOID"+ "'", var2.equals("NOID"));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(1, 1);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.clearRangeMarkers(0);
    float var10 = var7.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    int var12 = var7.getDomainAxisIndex(var11);
    java.lang.String var13 = var7.getPlotType();
    org.jfree.chart.util.RectangleInsets var14 = var7.getInsets();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    var15.setRenderer(0, var17, true);
    java.awt.Paint var20 = var15.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(var14, var20);
    var0.setSeriesOutlinePaint(0, var20, false);
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.data.category.CategoryDataset var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var27 = var0.findRangeBounds(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Category Plot"+ "'", var13.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var4 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var8 = var5.getRowRenderingOrder();
    boolean var9 = var4.equals((java.lang.Object)var8);
    java.lang.Object var10 = var4.clone();
    var0.setFixedDomainAxisSpace(var4);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    var14.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var17 = var14.getStandardTickUnits();
    var14.setLabelToolTip("SortOrder.ASCENDING");
    var0.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var14, false);
    var14.setUpperMargin(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(1.0d);
    org.jfree.chart.util.RectangleEdge var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = var1.getLabelPosition(var2);
    org.jfree.chart.axis.CategoryLabelPosition var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 1.0d);
//     org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
//     java.awt.Paint var6 = null;
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Paint var8 = null;
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Stroke[] var12 = null;
//     java.awt.Shape var13 = null;
//     java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var9, var11, var12, var14);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var20 = var17.getStandardTickUnits();
//     boolean var21 = var15.equals((java.lang.Object)var17);
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 1.0d);
//     org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var24, 0.0d);
//     var17.setRangeWithMargins(var24, true, false);
//     org.jfree.chart.block.RectangleConstraint var32 = var4.toRangeWidth(var24);
//     java.awt.Paint var33 = null;
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke[] var39 = null;
//     java.awt.Shape var40 = null;
//     java.awt.Shape[] var41 = new java.awt.Shape[] { var40};
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var36, var38, var39, var41);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     var44.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var47 = var44.getStandardTickUnits();
//     boolean var48 = var42.equals((java.lang.Object)var44);
//     org.jfree.data.Range var49 = null;
//     org.jfree.data.Range var51 = org.jfree.data.Range.expandToInclude(var49, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(var51, 1.0d);
//     org.jfree.data.Range var55 = org.jfree.data.Range.expandToInclude(var51, 0.0d);
//     var44.setRangeWithMargins(var51, true, false);
//     org.jfree.data.Range var59 = org.jfree.data.Range.combine(var24, var51);
//     
//     // Checks the contract:  equals-hashcode on var15 and var42
//     assertTrue("Contract failed: equals-hashcode on var15 and var42", var15.equals(var42) ? var15.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var15
//     assertTrue("Contract failed: equals-hashcode on var42 and var15", var42.equals(var15) ? var42.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var47
//     assertTrue("Contract failed: equals-hashcode on var20 and var47", var20.equals(var47) ? var20.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var20
//     assertTrue("Contract failed: equals-hashcode on var47 and var20", var47.equals(var20) ? var47.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     var0.setRenderer(var10, false);
//     org.jfree.chart.event.PlotChangeListener var13 = null;
//     var0.addChangeListener(var13);
//     org.jfree.chart.axis.ValueAxis var16 = var0.getRangeAxisForDataset(1);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearRangeMarkers(0);
//     float var20 = var17.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     int var22 = var17.getDomainAxisIndex(var21);
//     java.lang.String var23 = var17.getPlotType();
//     org.jfree.chart.util.SortOrder var24 = var17.getRowRenderingOrder();
//     var17.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var26 = var17.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var17.setRenderer(var27, false);
//     org.jfree.chart.event.PlotChangeListener var30 = null;
//     var17.addChangeListener(var30);
//     var0.setParent((org.jfree.chart.plot.Plot)var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.lang.Object var8 = var7.clone();
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(0.0d, var7, var9);
    org.jfree.chart.axis.CategoryAxis var11 = null;
    int var12 = var0.getDomainAxisIndex(var11);
    org.jfree.chart.plot.CategoryMarker var14 = null;
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(100, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 0.0f, 0.0f, var4, 10.0f, 1.0f, 1.0d);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.CategoryLabelPositions var13 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var14.removeChangeListener(var15);
    org.jfree.chart.util.RectangleEdge var17 = var14.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var18 = var13.getLabelPosition(var17);
    org.jfree.chart.text.TextBlockAnchor var19 = var18.getLabelAnchor();
    var0.draw(var9, 10.0f, 0.0f, var19, 0.0f, 0.0f, 100.0d);
    java.util.List var24 = var0.getLines();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var25 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var24);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
//     org.jfree.chart.util.GradientPaintTransformer var3 = var0.getGradientPaintTransformer();
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var5 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var4.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var5);
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(8.0d);
//     java.awt.Stroke var12 = var9.getAxisLineStroke();
//     var4.setSeriesOutlineStroke(0, var12, true);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var15.getPositiveItemLabelPosition(1, 1);
//     var4.setBaseNegativeItemLabelPosition(var20, true);
//     org.jfree.chart.text.TextAnchor var23 = var20.getRotationAnchor();
//     var0.setBaseNegativeItemLabelPosition(var20, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var4.", var0.equals(var4) == var4.equals(var0));
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     var5.setUpperBound(8.0d);
//     java.awt.Stroke var8 = var5.getAxisLineStroke();
//     var0.setSeriesOutlineStroke(0, var8, true);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var13 = var11.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var11.getPositiveItemLabelPosition(1, 1);
//     var0.setBaseNegativeItemLabelPosition(var16, true);
//     boolean var19 = var0.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var20.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var21);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     var25.setUpperBound(8.0d);
//     java.awt.Stroke var28 = var25.getAxisLineStroke();
//     var20.setSeriesOutlineStroke(0, var28, true);
//     org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var33 = var31.lookupSeriesPaint(1);
//     var20.setBaseFillPaint(var33, false);
//     org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var38 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var37.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var38);
//     org.jfree.chart.event.RendererChangeEvent var40 = null;
//     var37.notifyListeners(var40);
//     var37.setItemLabelAnchorOffset(4.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var44 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var45 = var37.findRangeBounds((org.jfree.data.category.CategoryDataset)var44);
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setUpperBound(8.0d);
//     java.awt.Stroke var55 = var52.getAxisLineStroke();
//     var50.setOutlineStroke(var55);
//     var37.setBaseStroke(var55);
//     var20.setSeriesStroke(1, var55, false);
//     var0.setBaseOutlineStroke(var55);
//     org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var62 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var61.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var62);
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("");
//     var66.setUpperBound(8.0d);
//     java.awt.Stroke var69 = var66.getAxisLineStroke();
//     var61.setSeriesOutlineStroke(0, var69, true);
//     org.jfree.chart.renderer.category.BarRenderer var72 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var74 = var72.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var77 = var72.getPositiveItemLabelPosition(1, 1);
//     var61.setBaseNegativeItemLabelPosition(var77, true);
//     org.jfree.chart.text.TextAnchor var80 = var77.getRotationAnchor();
//     var0.setBaseNegativeItemLabelPosition(var77, false);
//     
//     // Checks the contract:  equals-hashcode on var16 and var77
//     assertTrue("Contract failed: equals-hashcode on var16 and var77", var16.equals(var77) ? var16.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var16
//     assertTrue("Contract failed: equals-hashcode on var77 and var16", var77.equals(var16) ? var77.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearRangeMarkers(0);
    float var4 = var1.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    var5.removeLegend();
    org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, 10, 10);
    org.jfree.chart.title.LegendTitle var10 = var5.getLegend();
    org.jfree.chart.title.TextTitle var11 = null;
    var5.setTitle(var11);
    java.awt.RenderingHints var13 = var5.getRenderingHints();
    org.jfree.chart.title.LegendTitle var15 = var5.getLegend(10);
    org.jfree.chart.plot.CategoryPlot var16 = var5.getCategoryPlot();
    var16.setRangeCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
//     boolean var6 = var4.isOutlineVisible();
//     var4.setWeight(1);
//     java.awt.Paint var9 = var4.getDomainGridlinePaint();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var12 = var11.getPaint();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearRangeMarkers(0);
//     float var16 = var13.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     int var18 = var13.getDomainAxisIndex(var17);
//     java.lang.String var19 = var13.getPlotType();
//     org.jfree.chart.util.RectangleInsets var20 = var13.getInsets();
//     var11.setMargin(var20);
//     double var23 = var20.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.TickUnits var24 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var25 = var24.clone();
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     java.awt.geom.Rectangle2D var28 = var27.getDataArea();
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var28);
//     boolean var30 = var24.equals((java.lang.Object)var28);
//     java.awt.geom.Rectangle2D var33 = var20.createOutsetRectangle(var28, false, false);
//     java.awt.geom.Point2D var34 = null;
//     org.jfree.chart.plot.PlotState var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
//     var36.setRenderer(0, var38, true);
//     org.jfree.chart.ChartRenderingInfo var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
//     java.lang.Object var44 = var43.clone();
//     java.awt.geom.Point2D var45 = null;
//     var36.zoomDomainAxes(0.0d, var43, var45);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var47 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var43);
//     var4.draw(var10, var33, var34, var35, var43);
//     
//     // Checks the contract:  equals-hashcode on var27 and var43
//     assertTrue("Contract failed: equals-hashcode on var27 and var43", var27.equals(var43) ? var27.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var27
//     assertTrue("Contract failed: equals-hashcode on var43 and var27", var43.equals(var27) ? var43.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setAutoTickUnitSelection(false, false);
    org.jfree.data.Range var5 = var1.getDefaultAutoRange();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.clearRangeMarkers(0);
    float var9 = var6.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    int var11 = var6.getDomainAxisIndex(var10);
    org.jfree.chart.plot.Plot var12 = null;
    var6.setParent(var12);
    org.jfree.chart.axis.CategoryAxis var15 = var6.getDomainAxis(1);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    var18.setRenderer(0, var20, true);
    java.lang.Object var23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
    org.jfree.chart.axis.AxisLocation var24 = var18.getRangeAxisLocation();
    org.jfree.chart.axis.AxisLocation var25 = org.jfree.chart.axis.AxisLocation.getOpposite(var24);
    var6.setRangeAxisLocation(15, var25);
    org.jfree.chart.axis.AxisLocation var27 = var25.getOpposite();
    org.jfree.chart.plot.PlotOrientation var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var27, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(8.0d);
    java.awt.Stroke var9 = var6.getAxisLineStroke();
    var4.setOutlineStroke(var9);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    org.jfree.chart.util.Layer var14 = null;
    var4.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var13, var14);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    var17.setUpperBound(8.0d);
    java.awt.Stroke var20 = var17.getAxisLineStroke();
    org.jfree.chart.util.RectangleInsets var21 = var17.getLabelInsets();
    var4.setAxisOffset(var21);
    double var24 = var21.trimHeight((-17.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-23.0d));

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
//     boolean var15 = var9.equals((java.lang.Object)var11);
//     var11.setTickMarksVisible(false);
//     var11.setFixedDimension(0.0d);
//     var11.setNegativeArrowVisible(false);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     var22.setRenderer(0, var24, true);
//     java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var22);
//     var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.clearRangeMarkers(0);
//     float var32 = var29.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     int var34 = var29.getDomainAxisIndex(var33);
//     java.lang.String var35 = var29.getPlotType();
//     org.jfree.chart.util.SortOrder var36 = var29.getRowRenderingOrder();
//     var29.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var38 = var29.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var41 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var40.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var41);
//     org.jfree.chart.event.RendererChangeEvent var43 = null;
//     var40.notifyListeners(var43);
//     var40.setItemLabelAnchorOffset(4.0d);
//     var29.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40, true);
//     java.awt.Shape var51 = var40.getItemShape(10, 0);
//     java.awt.Color var55 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     java.lang.String var56 = var55.toString();
//     java.lang.String var57 = var55.toString();
//     org.jfree.chart.title.LegendGraphic var58 = new org.jfree.chart.title.LegendGraphic(var51, (java.awt.Paint)var55);
//     var11.setLabelPaint((java.awt.Paint)var55);
//     org.jfree.chart.ChartRenderingInfo var60 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var61 = new org.jfree.chart.plot.PlotRenderingInfo(var60);
//     java.awt.geom.Rectangle2D var62 = var61.getDataArea();
//     java.awt.Shape var66 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var62, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
//     var67.setRenderer(0, var69, true);
//     java.awt.Paint var72 = var67.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var73 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var62, var72);
//     var73.setLineVisible(false);
//     java.awt.Shape var76 = var73.getShape();
//     java.awt.Color var80 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     int var81 = var80.getRed();
//     org.jfree.chart.title.LegendGraphic var82 = new org.jfree.chart.title.LegendGraphic(var76, (java.awt.Paint)var80);
//     float[] var83 = null;
//     float[] var84 = var80.getRGBComponents(var83);
//     float[] var85 = var55.getRGBComponents(var83);
//     
//     // Checks the contract:  equals-hashcode on var22 and var67
//     assertTrue("Contract failed: equals-hashcode on var22 and var67", var22.equals(var67) ? var22.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var22
//     assertTrue("Contract failed: equals-hashcode on var67 and var22", var67.equals(var22) ? var67.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setAutoTickUnitSelection(false, false);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.awt.geom.Rectangle2D var8 = var7.getDataArea();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearRangeMarkers(0);
    float var12 = var9.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    int var14 = var9.getDomainAxisIndex(var13);
    java.lang.String var15 = var9.getPlotType();
    org.jfree.chart.util.SortOrder var16 = var9.getRowRenderingOrder();
    var9.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var18 = var9.getFixedDomainAxisSpace();
    org.jfree.chart.util.RectangleEdge var20 = var9.getRangeAxisEdge(0);
    double var21 = var1.java2DToValue(10.0d, var8, var20);
    var1.setRange(2.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Category Plot"+ "'", var15.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == Double.POSITIVE_INFINITY);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 8.0d);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var6 = null;
    var5.removeChangeListener(var6);
    org.jfree.chart.block.CenterArrangement var8 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var9.removeChangeListener(var10);
    java.lang.Object var12 = var9.clone();
    boolean var13 = var8.equals(var12);
    var4.add((org.jfree.chart.block.Block)var5, var12);
    var5.setToolTipText("[size=10]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, 0.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-100));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.lang.Object var8 = var7.clone();
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(0.0d, var7, var9);
    boolean var11 = var0.isRangeCrosshairVisible();
    org.jfree.chart.axis.AxisLocation var12 = var0.getRangeAxisLocation();
    org.jfree.chart.util.ObjectList var14 = new org.jfree.chart.util.ObjectList(10);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var18 = var15.getRowRenderingOrder();
    int var19 = var14.indexOf((java.lang.Object)var15);
    boolean var20 = var12.equals((java.lang.Object)var15);
    org.jfree.chart.plot.PlotOrientation var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var12, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.awt.Image var5 = var4.getBackgroundImage();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var6 = var4.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, Double.NaN);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var4 = null;
    var3.removeChangeListener(var4);
    org.jfree.chart.util.RectangleEdge var6 = var3.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var7 = var2.getLabelPosition(var6);
    org.jfree.chart.text.TextBlockAnchor var8 = var7.getLabelAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var12 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var11.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var12);
//     org.jfree.chart.event.RendererChangeEvent var14 = null;
//     var11.notifyListeners(var14);
//     var11.setItemLabelAnchorOffset(4.0d);
//     var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11, true);
//     java.awt.Shape var22 = var11.getItemShape(10, 0);
//     java.awt.Color var26 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     java.lang.String var27 = var26.toString();
//     java.lang.String var28 = var26.toString();
//     org.jfree.chart.title.LegendGraphic var29 = new org.jfree.chart.title.LegendGraphic(var22, (java.awt.Paint)var26);
//     java.awt.image.ColorModel var30 = null;
//     java.awt.Rectangle var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.clearRangeMarkers(0);
//     float var35 = var32.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     int var37 = var32.getDomainAxisIndex(var36);
//     java.lang.String var38 = var32.getPlotType();
//     org.jfree.chart.util.RectangleInsets var39 = var32.getInsets();
//     org.jfree.chart.ChartRenderingInfo var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
//     java.awt.geom.Rectangle2D var42 = var41.getDataArea();
//     java.awt.geom.Rectangle2D var43 = var39.createOutsetRectangle(var42);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var46 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var47 = var46.getRowCount();
//     org.jfree.chart.entity.CategoryItemEntity var50 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var42, "hi!", "", (org.jfree.data.category.CategoryDataset)var46, (java.lang.Comparable)1.0d, (java.lang.Comparable)(byte)0);
//     java.awt.geom.AffineTransform var51 = null;
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.clearRangeMarkers(0);
//     float var55 = var52.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var52);
//     org.jfree.chart.event.ChartProgressListener var57 = null;
//     var56.removeProgressListener(var57);
//     java.awt.RenderingHints var59 = var56.getRenderingHints();
//     java.awt.PaintContext var60 = var26.createContext(var30, var31, var42, var51, var59);
//     
//     // Checks the contract:  equals-hashcode on var32 and var52
//     assertTrue("Contract failed: equals-hashcode on var32 and var52", var32.equals(var52) ? var32.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var32
//     assertTrue("Contract failed: equals-hashcode on var52 and var32", var52.equals(var32) ? var52.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.event.RendererChangeEvent var1 = null;
//     var0.notifyListeners(var1);
//     double var3 = var0.getItemLabelAnchorOffset();
//     java.lang.Boolean var5 = var0.getSeriesVisibleInLegend(0);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var9 = var7.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var10 = var7.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
//     var7.setSeriesItemLabelGenerator(10, var12);
//     org.jfree.chart.labels.CategoryToolTipGenerator var15 = null;
//     var7.setSeriesToolTipGenerator(100, var15);
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var19 = var17.lookupSeriesPaint(1);
//     var7.setBaseOutlinePaint(var19, false);
//     var0.setSeriesPaint(0, var19);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var0.", var17.equals(var0) == var0.equals(var17));
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var1.removeChangeListener(var2);
    double var4 = var1.getContentXOffset();
    org.jfree.data.KeyedObject var5 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var1);
    org.jfree.chart.block.BlockResult var6 = new org.jfree.chart.block.BlockResult();
    var5.setObject((java.lang.Object)var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var9 = var8.getPaint();
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var11 = var10.getPaint();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.clearRangeMarkers(0);
    float var15 = var12.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var16 = null;
    int var17 = var12.getDomainAxisIndex(var16);
    java.lang.String var18 = var12.getPlotType();
    org.jfree.chart.util.RectangleInsets var19 = var12.getInsets();
    var10.setMargin(var19);
    double var22 = var19.calculateTopOutset(100.0d);
    var8.setMargin(var19);
    var5.setObject((java.lang.Object)var19);
    double var25 = var19.getRight();
    double var27 = var19.calculateLeftInset(10.0d);
    double var29 = var19.calculateTopInset((-17.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Category Plot"+ "'", var18.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 4.0d);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(1, 1);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     var7.setRangeAxis(0, var14);
//     float var16 = var7.getBackgroundImageAlpha();
//     java.awt.Paint var17 = var7.getNoDataMessagePaint();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var22 = var19.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var19.addRangeMarker((org.jfree.chart.plot.Marker)var24);
//     org.jfree.chart.util.LengthAdjustmentType var26 = var24.getLabelOffsetType();
//     java.awt.Font var27 = var24.getLabelFont();
//     org.jfree.chart.util.RectangleInsets var28 = var24.getLabelOffset();
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var30 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var29.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var30);
//     org.jfree.chart.event.RendererChangeEvent var32 = null;
//     var29.notifyListeners(var32);
//     var29.setItemLabelAnchorOffset(4.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var37 = var29.findRangeBounds((org.jfree.data.category.CategoryDataset)var36);
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var38, var39, var40, var41);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     var44.setUpperBound(8.0d);
//     java.awt.Stroke var47 = var44.getAxisLineStroke();
//     var42.setOutlineStroke(var47);
//     var29.setBaseStroke(var47);
//     var24.setOutlineStroke(var47);
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var51, var52, var53, var54);
//     org.jfree.data.category.CategoryDataset var57 = null;
//     var55.setDataset(10, var57);
//     java.awt.Graphics2D var59 = null;
//     org.jfree.chart.ChartRenderingInfo var60 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var61 = new org.jfree.chart.plot.PlotRenderingInfo(var60);
//     java.awt.geom.Rectangle2D var62 = var61.getDataArea();
//     java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var62, 1.0d, (-1.0d));
//     var55.drawBackgroundImage(var59, var62);
//     var0.drawRangeMarker(var6, var7, var18, (org.jfree.chart.plot.Marker)var24, var62);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
//     boolean var15 = var9.equals((java.lang.Object)var11);
//     var11.setTickMarksVisible(false);
//     var11.setFixedDimension(0.0d);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     org.jfree.chart.axis.AxisSpace var25 = var24.getFixedDomainAxisSpace();
//     boolean var26 = var24.isOutlineVisible();
//     var11.setPlot((org.jfree.chart.plot.Plot)var24);
//     org.jfree.chart.axis.TickUnits var29 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var33);
//     boolean var35 = var29.equals((java.lang.Object)var33);
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var36.removeChangeListener(var37);
//     org.jfree.chart.util.RectangleEdge var39 = var36.getPosition();
//     double var40 = var11.lengthToJava2D(116.0d, var33, var39);
//     org.jfree.data.Range var41 = var11.getRange();
//     var11.setAutoRangeIncludesZero(true);
//     org.jfree.data.Range var44 = null;
//     org.jfree.data.Range var46 = org.jfree.data.Range.expandToInclude(var44, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint(var46, 1.0d);
//     org.jfree.chart.block.LengthConstraintType var49 = var48.getHeightConstraintType();
//     java.awt.Paint var50 = null;
//     java.awt.Paint[] var51 = new java.awt.Paint[] { var50};
//     java.awt.Paint var52 = null;
//     java.awt.Paint[] var53 = new java.awt.Paint[] { var52};
//     java.awt.Stroke var54 = null;
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Stroke[] var56 = null;
//     java.awt.Shape var57 = null;
//     java.awt.Shape[] var58 = new java.awt.Shape[] { var57};
//     org.jfree.chart.plot.DefaultDrawingSupplier var59 = new org.jfree.chart.plot.DefaultDrawingSupplier(var51, var53, var55, var56, var58);
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("");
//     var61.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var64 = var61.getStandardTickUnits();
//     boolean var65 = var59.equals((java.lang.Object)var61);
//     org.jfree.data.Range var66 = null;
//     org.jfree.data.Range var68 = org.jfree.data.Range.expandToInclude(var66, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var70 = new org.jfree.chart.block.RectangleConstraint(var68, 1.0d);
//     org.jfree.data.Range var72 = org.jfree.data.Range.expandToInclude(var68, 0.0d);
//     var61.setRangeWithMargins(var68, true, false);
//     org.jfree.chart.block.RectangleConstraint var76 = var48.toRangeWidth(var68);
//     var11.setDefaultAutoRange(var68);
//     
//     // Checks the contract:  equals-hashcode on var9 and var59
//     assertTrue("Contract failed: equals-hashcode on var9 and var59", var9.equals(var59) ? var9.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var9
//     assertTrue("Contract failed: equals-hashcode on var59 and var9", var59.equals(var9) ? var59.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var64
//     assertTrue("Contract failed: equals-hashcode on var14 and var64", var14.equals(var64) ? var14.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var14
//     assertTrue("Contract failed: equals-hashcode on var64 and var14", var64.equals(var14) ? var64.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var1.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var4 = var1.getNegativeItemLabelPositionFallback();
    var1.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var9 = var7.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var12 = var7.getPositiveItemLabelPosition(1, 1);
    var1.setPositiveItemLabelPositionFallback(var12);
    org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var17 = var16.getFont();
    var1.setSeriesItemLabelFont(100, var17);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.clearRangeMarkers(0);
    float var22 = var19.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var23 = null;
    int var24 = var19.getDomainAxisIndex(var23);
    java.lang.String var25 = var19.getPlotType();
    org.jfree.chart.util.SortOrder var26 = var19.getRowRenderingOrder();
    var19.clearDomainAxes();
    org.jfree.chart.ChartRenderingInfo var28 = null;
    org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
    java.awt.geom.Rectangle2D var30 = var29.getDataArea();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var30, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
    var35.setRenderer(0, var37, true);
    java.awt.Paint var40 = var35.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var30, var40);
    var19.setOutlinePaint(var40);
    org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var40);
    org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Category Plot"+ "'", var25.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-2));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    var5.setUpperBound(8.0d);
    java.awt.Stroke var8 = var5.getAxisLineStroke();
    var0.setSeriesOutlineStroke(0, var8, true);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var13 = var11.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var16 = var11.getPositiveItemLabelPosition(1, 1);
    var0.setBaseNegativeItemLabelPosition(var16, true);
    boolean var19 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var20.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var21);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    var25.setUpperBound(8.0d);
    java.awt.Stroke var28 = var25.getAxisLineStroke();
    var20.setSeriesOutlineStroke(0, var28, true);
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var33 = var31.lookupSeriesPaint(1);
    var20.setBaseFillPaint(var33, false);
    org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var38 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var37.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var38);
    org.jfree.chart.event.RendererChangeEvent var40 = null;
    var37.notifyListeners(var40);
    var37.setItemLabelAnchorOffset(4.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var44 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var45 = var37.findRangeBounds((org.jfree.data.category.CategoryDataset)var44);
    org.jfree.data.category.CategoryDataset var46 = null;
    org.jfree.chart.axis.CategoryAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
    var52.setUpperBound(8.0d);
    java.awt.Stroke var55 = var52.getAxisLineStroke();
    var50.setOutlineStroke(var55);
    var37.setBaseStroke(var55);
    var20.setSeriesStroke(1, var55, false);
    var0.setBaseOutlineStroke(var55);
    java.awt.Paint var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelPaint(var61, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("java.awt.Color[r=0,g=0,b=0]", var1);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(8.0d);
//     java.awt.Stroke var9 = var6.getAxisLineStroke();
//     var4.setOutlineStroke(var9);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     org.jfree.chart.util.Layer var14 = null;
//     var4.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var13, var14);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var19 = var16.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var16.addRangeMarker((org.jfree.chart.plot.Marker)var21);
//     org.jfree.chart.util.LengthAdjustmentType var23 = var21.getLabelOffsetType();
//     java.awt.Font var24 = var21.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.clearRangeMarkers(0);
//     float var28 = var25.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     int var30 = var25.getDomainAxisIndex(var29);
//     java.lang.String var31 = var25.getPlotType();
//     org.jfree.chart.util.RectangleInsets var32 = var25.getInsets();
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     var33.setRenderer(0, var35, true);
//     java.awt.Paint var38 = var33.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder(var32, var38);
//     org.jfree.chart.util.RectangleInsets var40 = var39.getInsets();
//     java.lang.String var41 = var40.toString();
//     var21.setLabelOffset(var40);
//     org.jfree.chart.util.RectangleAnchor var43 = var21.getLabelAnchor();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var47 = var44.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var44.addRangeMarker((org.jfree.chart.plot.Marker)var49);
//     org.jfree.chart.util.LengthAdjustmentType var51 = var49.getLabelOffsetType();
//     var21.setLabelOffsetType(var51);
//     java.lang.String var53 = var51.toString();
//     var13.setLabelOffsetType(var51);
//     
//     // Checks the contract:  equals-hashcode on var13 and var49
//     assertTrue("Contract failed: equals-hashcode on var13 and var49", var13.equals(var49) ? var13.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var13
//     assertTrue("Contract failed: equals-hashcode on var49 and var13", var49.equals(var13) ? var49.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    java.lang.Comparable var0 = null;
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var4 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var1, "hi!", "TextBlockAnchor.BOTTOM_LEFT");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setSeriesItemLabelGenerator(10, var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var0.setSeriesToolTipGenerator(100, var8);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var10.lookupSeriesPaint(1);
    var0.setBaseOutlinePaint(var12, false);
    boolean var15 = var0.isDrawBarOutline();
    org.jfree.chart.annotations.CategoryAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    java.awt.Image var5 = var4.getBackgroundImage();
    int var6 = var4.getSubtitleCount();
    org.jfree.chart.event.ChartChangeListener var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.removeChangeListener(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
    java.lang.Object var8 = var7.clone();
    org.jfree.data.KeyedObjects2D var9 = new org.jfree.data.KeyedObjects2D();
    java.util.List var10 = var9.getColumnKeys();
    java.util.List var11 = var9.getColumnKeys();
    boolean var12 = var7.equals((java.lang.Object)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.removeRow(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    var4.setRenderer(0, var6, true);
    org.jfree.chart.ChartRenderingInfo var10 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
    java.lang.Object var12 = var11.clone();
    java.awt.geom.Point2D var13 = null;
    var4.zoomDomainAxes(0.0d, var11, var13);
    org.jfree.chart.renderer.category.CategoryItemRendererState var15 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var11);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    java.awt.geom.Rectangle2D var18 = var17.getDataArea();
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var18, 100.0d, 10.0f, 10.0f);
    var11.setPlotArea(var18);
    org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var26 = var24.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var27 = var24.getNegativeItemLabelPositionFallback();
    var24.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var32 = var30.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var35 = var30.getPositiveItemLabelPosition(1, 1);
    var24.setPositiveItemLabelPositionFallback(var35);
    org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var40 = var39.getFont();
    var24.setSeriesItemLabelFont(100, var40);
    org.jfree.chart.urls.CategoryURLGenerator var42 = var24.getBaseURLGenerator();
    double var43 = var24.getMaximumBarWidth();
    org.jfree.chart.ChartRenderingInfo var44 = null;
    org.jfree.chart.plot.PlotRenderingInfo var45 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
    java.awt.geom.Rectangle2D var46 = var45.getDataArea();
    boolean var47 = var24.equals((java.lang.Object)var45);
    java.awt.Paint var49 = var24.lookupSeriesOutlinePaint((-2));
    java.awt.Stroke var50 = null;
    java.awt.Paint var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("Category Plot", "Category Plot", "Size2D[width=-1.0, height=10.0]", "CONTRACT", (java.awt.Shape)var18, var49, var50, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     var4.removeLegend();
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var12 = var10.toFixedHeight(0.0d);
//     boolean var13 = var4.equals((java.lang.Object)var10);
//     var4.setTextAntiAlias(false);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var18 = var17.getPaint();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.clearRangeMarkers(0);
//     float var22 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     int var24 = var19.getDomainAxisIndex(var23);
//     java.lang.String var25 = var19.getPlotType();
//     org.jfree.chart.util.RectangleInsets var26 = var19.getInsets();
//     var17.setMargin(var26);
//     double var29 = var26.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     var31.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var34 = var31.getStandardTickUnits();
//     var31.resizeRange(4.0d);
//     var31.setLowerBound((-17.0d));
//     org.jfree.chart.ChartRenderingInfo var39 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var40 = new org.jfree.chart.plot.PlotRenderingInfo(var39);
//     java.awt.geom.Rectangle2D var41 = var40.getDataArea();
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var41, 1.0d, (-1.0d));
//     var31.setUpArrow((java.awt.Shape)var41);
//     java.awt.geom.Rectangle2D var46 = var26.createOutsetRectangle(var41);
//     org.jfree.chart.ChartRenderingInfo var47 = null;
//     var4.draw(var16, var46, var47);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPosition(1, 1);
//     org.jfree.chart.text.TextFragment var8 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var9 = var8.getFont();
//     var0.setSeriesItemLabelFont(100, var9);
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(var13, 1.0d);
//     org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
//     boolean var18 = var0.equals((java.lang.Object)var13);
//     java.awt.Shape var20 = var0.getSeriesShape(15);
//     java.awt.Font var22 = var0.getSeriesItemLabelFont((-2));
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.event.RendererChangeEvent var25 = null;
//     var24.notifyListeners(var25);
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
//     java.awt.geom.Rectangle2D var30 = var29.getDataArea();
//     var24.setSeriesShape(1, (java.awt.Shape)var30, false);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     var33.setCategoryLabelPositionOffset(0);
//     org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var39 = var37.lookupSeriesPaint(1);
//     var33.setTickLabelPaint((java.lang.Comparable)0, var39);
//     java.awt.Paint var41 = null;
//     java.awt.Paint[] var42 = new java.awt.Paint[] { var41};
//     java.awt.Paint var43 = null;
//     java.awt.Paint[] var44 = new java.awt.Paint[] { var43};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Stroke[] var47 = null;
//     java.awt.Shape var48 = null;
//     java.awt.Shape[] var49 = new java.awt.Shape[] { var48};
//     org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var42, var44, var46, var47, var49);
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("");
//     var52.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var55 = var52.getStandardTickUnits();
//     boolean var56 = var50.equals((java.lang.Object)var52);
//     var52.setTickMarksVisible(false);
//     var52.setFixedDimension(0.0d);
//     org.jfree.data.category.CategoryDataset var61 = null;
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var64 = null;
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot(var61, var62, var63, var64);
//     org.jfree.chart.axis.AxisSpace var66 = var65.getFixedDomainAxisSpace();
//     boolean var67 = var65.isOutlineVisible();
//     var52.setPlot((org.jfree.chart.plot.Plot)var65);
//     org.jfree.chart.util.Layer var69 = null;
//     org.jfree.chart.ChartRenderingInfo var70 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var71 = new org.jfree.chart.plot.PlotRenderingInfo(var70);
//     java.lang.Object var72 = var71.clone();
//     boolean var74 = var71.equals((java.lang.Object)true);
//     var0.drawAnnotations(var23, var30, var33, (org.jfree.chart.axis.ValueAxis)var52, var69, var71);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.chart.axis.TickUnits var4 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     var4.add((org.jfree.chart.axis.TickUnit)var6);
//     var0.add(8.0d, 4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)var6);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearRangeMarkers(0);
//     float var12 = var9.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var13 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var17 = var14.getRowRenderingOrder();
//     boolean var18 = var13.equals((java.lang.Object)var17);
//     java.lang.Object var19 = var13.clone();
//     var9.setFixedDomainAxisSpace(var13);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var26 = var23.getStandardTickUnits();
//     var23.setLabelToolTip("SortOrder.ASCENDING");
//     var9.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var23, false);
//     org.jfree.chart.axis.NumberTickUnit var32 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     var23.setTickUnit(var32);
//     java.lang.String var34 = var32.toString();
//     org.jfree.chart.axis.TickUnits var35 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.NumberTickUnit var37 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     var35.add((org.jfree.chart.axis.TickUnit)var37);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearRangeMarkers(0);
//     float var42 = var39.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var43 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var47 = var44.getRowRenderingOrder();
//     boolean var48 = var43.equals((java.lang.Object)var47);
//     java.lang.Object var49 = var43.clone();
//     var39.setFixedDomainAxisSpace(var43);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     var53.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var56 = var53.getStandardTickUnits();
//     var53.setLabelToolTip("SortOrder.ASCENDING");
//     var39.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var53, false);
//     org.jfree.chart.axis.NumberTickUnit var62 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     var53.setTickUnit(var62);
//     org.jfree.chart.axis.TickUnit var64 = var35.getLargerTickUnit((org.jfree.chart.axis.TickUnit)var62);
//     java.lang.Number var65 = var0.getStdDevValue((java.lang.Comparable)var32, (java.lang.Comparable)var64);
//     
//     // Checks the contract:  equals-hashcode on var4 and var35
//     assertTrue("Contract failed: equals-hashcode on var4 and var35", var4.equals(var35) ? var4.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var4
//     assertTrue("Contract failed: equals-hashcode on var35 and var4", var35.equals(var4) ? var35.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var39
//     assertTrue("Contract failed: equals-hashcode on var9 and var39", var9.equals(var39) ? var9.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var44
//     assertTrue("Contract failed: equals-hashcode on var14 and var44", var14.equals(var44) ? var14.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var9
//     assertTrue("Contract failed: equals-hashcode on var39 and var9", var39.equals(var9) ? var39.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var14
//     assertTrue("Contract failed: equals-hashcode on var44 and var14", var44.equals(var14) ? var44.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var56
//     assertTrue("Contract failed: equals-hashcode on var26 and var56", var26.equals(var56) ? var26.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var26
//     assertTrue("Contract failed: equals-hashcode on var56 and var26", var56.equals(var26) ? var56.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setSeriesItemLabelGenerator(10, var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var0.setSeriesToolTipGenerator(100, var8);
    var0.setDrawBarOutline(false);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.util.SortOrder var18 = var17.getColumnRenderingOrder();
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var22 = var20.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var23 = var20.getNegativeItemLabelPositionFallback();
    var20.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var28 = var26.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var31 = var26.getPositiveItemLabelPosition(1, 1);
    var20.setPositiveItemLabelPositionFallback(var31);
    org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var36 = var35.getFont();
    var20.setSeriesItemLabelFont(100, var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    var38.clearRangeMarkers(0);
    float var41 = var38.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var42 = null;
    int var43 = var38.getDomainAxisIndex(var42);
    java.lang.String var44 = var38.getPlotType();
    org.jfree.chart.util.SortOrder var45 = var38.getRowRenderingOrder();
    var38.clearDomainAxes();
    org.jfree.chart.ChartRenderingInfo var47 = null;
    org.jfree.chart.plot.PlotRenderingInfo var48 = new org.jfree.chart.plot.PlotRenderingInfo(var47);
    java.awt.geom.Rectangle2D var49 = var48.getDataArea();
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var49, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
    var54.setRenderer(0, var56, true);
    java.awt.Paint var59 = var54.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var49, var59);
    var38.setOutlinePaint(var59);
    org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, var59);
    var17.setNoDataMessageFont(var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelFont((-2), var36, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "Category Plot"+ "'", var44.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    var7.setRenderer(0, var9, true);
    java.awt.Paint var12 = var7.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
    var13.setLineVisible(true);
    java.awt.Stroke var16 = var13.getOutlineStroke();
    java.awt.Paint var17 = var13.getOutlinePaint();
    org.jfree.chart.util.RectangleAnchor var18 = var13.getShapeAnchor();
    java.lang.Object var19 = null;
    boolean var20 = var18.equals(var19);
    org.jfree.chart.axis.CategoryLabelPositions var22 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var24 = null;
    var23.removeChangeListener(var24);
    org.jfree.chart.util.RectangleEdge var26 = var23.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var27 = var22.getLabelPosition(var26);
    org.jfree.chart.text.TextBlockAnchor var28 = var27.getLabelAnchor();
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    var29.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var32 = var29.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var29.addRangeMarker((org.jfree.chart.plot.Marker)var34);
    org.jfree.chart.util.LengthAdjustmentType var36 = var34.getLabelOffsetType();
    java.awt.Stroke var37 = var34.getStroke();
    org.jfree.chart.text.TextAnchor var38 = var34.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var42 = new org.jfree.chart.axis.CategoryLabelPosition(var18, var28, var38, 0.05d, var40, 0.5f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    boolean var5 = var4.isBorderVisible();
    int var6 = var4.getBackgroundImageAlignment();
    org.jfree.chart.ChartRenderingInfo var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var12 = var4.createBufferedImage(0, (-1), (-1.0d), 0.0d, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 15);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var0.setRenderer(var10, false);
    org.jfree.chart.event.PlotChangeListener var13 = null;
    var0.addChangeListener(var13);
    org.jfree.chart.axis.ValueAxis var16 = var0.getRangeAxisForDataset(1);
    org.jfree.chart.annotations.CategoryAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var18 = var0.removeAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.notifyListeners(var1);
    var0.setBaseCreateEntities(false);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var13, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     var18.setRenderer(0, var20, true);
//     java.awt.Paint var23 = var18.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var24 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var13, var23);
//     var0.setSeriesPaint(0, var23);
//     org.jfree.chart.labels.ItemLabelPosition var27 = var0.getSeriesNegativeItemLabelPosition(1);
//     org.jfree.chart.block.BorderArrangement var28 = new org.jfree.chart.block.BorderArrangement();
//     var28.clear();
//     org.jfree.chart.block.BorderArrangement var30 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("");
//     var32.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var35 = var32.getStandardTickUnits();
//     var32.setLabelToolTip("SortOrder.ASCENDING");
//     boolean var38 = var30.equals((java.lang.Object)"SortOrder.ASCENDING");
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var28, (org.jfree.chart.block.Arrangement)var30);
//     
//     // Checks the contract:  equals-hashcode on var28 and var30
//     assertTrue("Contract failed: equals-hashcode on var28 and var30", var28.equals(var30) ? var28.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var28
//     assertTrue("Contract failed: equals-hashcode on var30 and var28", var30.equals(var28) ? var30.hashCode() == var28.hashCode() : true);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var0.setRangeAxis(0, var7);
//     var0.setWeight(100);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearRangeMarkers(0);
//     float var14 = var11.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     var15.removeLegend();
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var23 = var21.toFixedHeight(0.0d);
//     boolean var24 = var15.equals((java.lang.Object)var21);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
//     org.jfree.chart.event.ChartProgressListener var26 = null;
//     var15.addProgressListener(var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     var29.setRenderer(0, var31, true);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.lang.Object var37 = var36.clone();
//     java.awt.geom.Point2D var38 = null;
//     var29.zoomDomainAxes(0.0d, var36, var38);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var40 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var36);
//     org.jfree.chart.ChartRenderingInfo var41 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var42 = new org.jfree.chart.plot.PlotRenderingInfo(var41);
//     java.awt.geom.Rectangle2D var43 = var42.getDataArea();
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var43, 100.0d, 10.0f, 10.0f);
//     var36.setPlotArea(var43);
//     var15.draw(var28, var43);
// 
//   }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.RectangleInsets var7 = var0.getInsets();
    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    java.awt.geom.Rectangle2D var10 = var9.getDataArea();
    java.awt.geom.Rectangle2D var11 = var7.createOutsetRectangle(var10);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var15 = var14.getRowCount();
    org.jfree.chart.entity.CategoryItemEntity var18 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var10, "hi!", "", (org.jfree.data.category.CategoryDataset)var14, (java.lang.Comparable)1.0d, (java.lang.Comparable)(byte)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var21 = var14.getStdDevValue(100, (-100));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
    boolean var5 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.ChartRenderingInfo var10 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getDataArea();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var12, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    var17.setRenderer(0, var19, true);
    java.awt.Paint var22 = var17.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var23 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var12, var22);
    org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder(92.0d, 10.0d, 2.0d, 4.0d, var22);
    boolean var25 = var4.equals((java.lang.Object)10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var5 = var3.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var6 = var3.getNegativeItemLabelPositionFallback();
    var3.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var11 = var9.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var14 = var9.getPositiveItemLabelPosition(1, 1);
    var3.setPositiveItemLabelPositionFallback(var14);
    org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var19 = var18.getFont();
    var3.setSeriesItemLabelFont(100, var19);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.clearRangeMarkers(0);
    float var24 = var21.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var25 = null;
    int var26 = var21.getDomainAxisIndex(var25);
    java.lang.String var27 = var21.getPlotType();
    org.jfree.chart.util.SortOrder var28 = var21.getRowRenderingOrder();
    var21.clearDomainAxes();
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    java.awt.geom.Rectangle2D var32 = var31.getDataArea();
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var32, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    var37.setRenderer(0, var39, true);
    java.awt.Paint var42 = var37.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var32, var42);
    var21.setOutlinePaint(var42);
    org.jfree.chart.text.TextBlock var45 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, var42);
    org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var48 = var46.lookupSeriesPaint(1);
    org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", var19, var48);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=0,b=0]", var19);
    var50.setToolTipText("SortOrder.ASCENDING");
    double var53 = var50.getContentYOffset();
    java.lang.Object var54 = var50.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "Category Plot"+ "'", var27.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.ChartRenderingInfo var2 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var2);
//     java.awt.geom.Rectangle2D var4 = var3.getDataArea();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var4);
//     boolean var6 = var0.equals((java.lang.Object)var4);
//     java.lang.Object var7 = null;
//     boolean var8 = var0.equals(var7);
//     java.lang.Object var9 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var1 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var2 = new org.jfree.chart.plot.PlotRenderingInfo(var1);
//     org.jfree.chart.ChartRenderingInfo var3 = var2.getOwner();
//     java.awt.geom.Rectangle2D var4 = var2.getDataArea();
//     org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.2d, (java.awt.Shape)var4, "UnitType.ABSOLUTE", "");
//     java.lang.Comparable var8 = var7.getKey();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var9 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var10 = null;
//     java.lang.String var11 = var7.getImageMapAreaTag(var9, var10);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    var0.setSeriesCreateEntities(1, (java.lang.Boolean)false, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var0.getItemLabelGenerator((-2), 1);
    var0.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.Range var8 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var7);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearRangeMarkers(0);
    float var12 = var9.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    int var14 = var9.getDomainAxisIndex(var13);
    org.jfree.chart.plot.Plot var15 = null;
    var9.setParent(var15);
    org.jfree.chart.axis.CategoryAxis var18 = var9.getDomainAxis(1);
    var7.addChangeListener((org.jfree.data.general.DatasetChangeListener)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var22 = var7.getMeanValue((-100), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(8.0d, var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var12 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var11.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var12);
    org.jfree.chart.event.RendererChangeEvent var14 = null;
    var11.notifyListeners(var14);
    var11.setItemLabelAnchorOffset(4.0d);
    var0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11, true);
    java.awt.Shape var22 = var11.getItemShape(10, 0);
    java.awt.Color var26 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.lang.String var27 = var26.toString();
    java.lang.String var28 = var26.toString();
    org.jfree.chart.title.LegendGraphic var29 = new org.jfree.chart.title.LegendGraphic(var22, (java.awt.Paint)var26);
    java.awt.Paint var30 = var29.getFillPaint();
    org.jfree.chart.util.GradientPaintTransformer var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var29.setFillPaintTransformer(var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var27.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var28.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var12 = var10.lookupSeriesPaint(1);
//     var0.setBaseOutlinePaint(var12, false);
//     boolean var15 = var0.isDrawBarOutline();
//     var0.setIncludeBaseInRange(false);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.clearRangeMarkers(0);
//     float var21 = var18.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     int var23 = var18.getDomainAxisIndex(var22);
//     java.lang.String var24 = var18.getPlotType();
//     org.jfree.chart.LegendItemCollection var25 = var18.getLegendItems();
//     boolean var26 = var0.hasListener((java.util.EventListener)var18);
//     org.jfree.chart.ChartRenderingInfo var28 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = new org.jfree.chart.plot.PlotRenderingInfo(var28);
//     org.jfree.chart.ChartRenderingInfo var30 = var29.getOwner();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     var29.addSubplotInfo(var32);
//     java.awt.geom.Point2D var34 = null;
//     var18.zoomDomainAxes(1.0d, var29, var34);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     var37.setRenderer(0, var39, true);
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     java.lang.Object var45 = var44.clone();
//     java.awt.geom.Point2D var46 = null;
//     var37.zoomDomainAxes(0.0d, var44, var46);
//     boolean var48 = var37.isRangeCrosshairVisible();
//     org.jfree.chart.axis.AxisLocation var49 = var37.getRangeAxisLocation();
//     org.jfree.chart.util.ObjectList var51 = new org.jfree.chart.util.ObjectList(10);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var55 = var52.getRowRenderingOrder();
//     int var56 = var51.indexOf((java.lang.Object)var52);
//     boolean var57 = var49.equals((java.lang.Object)var52);
//     var18.setDomainAxisLocation(15, var49);
//     
//     // Checks the contract:  equals-hashcode on var52 and var18
//     assertTrue("Contract failed: equals-hashcode on var52 and var18", var52.equals(var18) ? var52.hashCode() == var18.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var52 and var18.", var52.equals(var18) == var18.equals(var52));
//     
//     // Checks the contract:  equals-hashcode on var32 and var44
//     assertTrue("Contract failed: equals-hashcode on var32 and var44", var32.equals(var44) ? var32.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var32
//     assertTrue("Contract failed: equals-hashcode on var44 and var32", var44.equals(var32) ? var44.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
    var0.setPositiveItemLabelPositionFallback(var11);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var16 = var15.getFont();
    var0.setSeriesItemLabelFont(100, var16);
    org.jfree.chart.urls.CategoryURLGenerator var18 = var0.getBaseURLGenerator();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    var19.setRenderer(0, var21, true);
    java.lang.Object var24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
    org.jfree.chart.axis.ValueAxis var26 = null;
    var19.setRangeAxis(0, var26);
    int var28 = var19.getWeight();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var19);
    boolean var30 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke[] var6 = null;
    java.awt.Shape var7 = null;
    java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
    org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
    boolean var15 = var9.equals((java.lang.Object)var11);
    var11.setTickMarksVisible(false);
    var11.setFixedDimension(0.0d);
    org.jfree.data.Range var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeWithMargins(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
    var0.setPositiveItemLabelPositionFallback(var11);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var16 = var15.getFont();
    var0.setSeriesItemLabelFont(100, var16);
    java.awt.Paint var18 = var0.getBaseItemLabelPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
    var0.setSeriesToolTipGenerator(15, var20);
    org.jfree.chart.annotations.CategoryAnnotation var22 = null;
    org.jfree.chart.util.Layer var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var22, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.util.SortOrder var6 = var5.getColumnRenderingOrder();
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var10 = var8.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var8.getNegativeItemLabelPositionFallback();
//     var8.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var16 = var14.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var19 = var14.getPositiveItemLabelPosition(1, 1);
//     var8.setPositiveItemLabelPositionFallback(var19);
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var24 = var23.getFont();
//     var8.setSeriesItemLabelFont(100, var24);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearRangeMarkers(0);
//     float var29 = var26.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     int var31 = var26.getDomainAxisIndex(var30);
//     java.lang.String var32 = var26.getPlotType();
//     org.jfree.chart.util.SortOrder var33 = var26.getRowRenderingOrder();
//     var26.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Rectangle2D var37 = var36.getDataArea();
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var37, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     var42.setRenderer(0, var44, true);
//     java.awt.Paint var47 = var42.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var37, var47);
//     var26.setOutlinePaint(var47);
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, var47);
//     var5.setNoDataMessageFont(var24);
//     org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var54 = var52.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var55 = var52.getNegativeItemLabelPositionFallback();
//     var52.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var60 = var58.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var63 = var58.getPositiveItemLabelPosition(1, 1);
//     var52.setPositiveItemLabelPositionFallback(var63);
//     org.jfree.chart.text.TextFragment var67 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var68 = var67.getFont();
//     var52.setSeriesItemLabelFont(100, var68);
//     java.awt.Font var72 = var52.getItemLabelFont((-2), 10);
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
//     var73.clearRangeMarkers(0);
//     float var76 = var73.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var77 = null;
//     int var78 = var73.getDomainAxisIndex(var77);
//     java.lang.String var79 = var73.getPlotType();
//     org.jfree.chart.util.RectangleInsets var80 = var73.getInsets();
//     org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var83 = null;
//     var81.setRenderer(0, var83, true);
//     java.awt.Paint var86 = var81.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var87 = new org.jfree.chart.block.BlockBorder(var80, var86);
//     var52.setBaseOutlinePaint(var86, true);
//     java.awt.Graphics2D var92 = null;
//     org.jfree.chart.text.G2TextMeasurer var93 = new org.jfree.chart.text.G2TextMeasurer(var92);
//     org.jfree.chart.text.TextBlock var94 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=-1.0, height=10.0]", var24, var86, 0.0f, 1, (org.jfree.chart.text.TextMeasurer)var93);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke[] var6 = null;
    java.awt.Shape var7 = null;
    java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
    org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
    boolean var15 = var9.equals((java.lang.Object)var11);
    var11.setTickMarksVisible(false);
    var11.setFixedDimension(0.0d);
    var11.setNegativeArrowVisible(false);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    var22.setRenderer(0, var24, true);
    java.lang.Object var27 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var22);
    var11.addChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
    org.jfree.chart.annotations.CategoryAnnotation var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.addAnnotation(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleEdge.LEFT");

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-16777216), (-16777216), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var2 = var1.getFont();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.clearRangeMarkers(0);
    float var6 = var3.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    int var8 = var3.getDomainAxisIndex(var7);
    java.lang.String var9 = var3.getPlotType();
    org.jfree.chart.util.RectangleInsets var10 = var3.getInsets();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    var11.setRenderer(0, var13, true);
    java.awt.Paint var16 = var11.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var10, var16);
    boolean var18 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.util.RectangleInsets var19 = var17.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Category Plot"+ "'", var9.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = var1.getDataArea();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var2, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     var7.setRenderer(0, var9, true);
//     java.awt.Paint var12 = var7.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var13 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var2, var12);
//     var13.setLineVisible(true);
//     java.awt.Shape var16 = var13.getLine();
//     org.jfree.chart.util.RectangleInsets var17 = var13.getPadding();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var20 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var19.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var20);
//     org.jfree.chart.event.RendererChangeEvent var22 = null;
//     var19.notifyListeners(var22);
//     var19.setItemLabelAnchorOffset(4.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var27 = var19.findRangeBounds((org.jfree.data.category.CategoryDataset)var26);
//     boolean var29 = var19.isSeriesVisible(0);
//     var19.setItemLabelAnchorOffset(0.0d);
//     java.awt.Paint var32 = var19.getBaseOutlinePaint();
//     org.jfree.chart.axis.TickUnits var33 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var34 = var33.clone();
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Rectangle2D var37 = var36.getDataArea();
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var37);
//     boolean var39 = var33.equals((java.lang.Object)var37);
//     var19.setBaseShape((java.awt.Shape)var37);
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var43 = null;
//     var42.removeChangeListener(var43);
//     double var45 = var42.getContentXOffset();
//     org.jfree.data.KeyedObject var46 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var42);
//     org.jfree.chart.util.HorizontalAlignment var47 = var42.getHorizontalAlignment();
//     java.lang.Object var48 = var13.draw(var18, var37, (java.lang.Object)var42);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var13 = var10.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var10.addRangeMarker((org.jfree.chart.plot.Marker)var15);
//     org.jfree.chart.ChartRenderingInfo var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var17);
//     java.awt.geom.Rectangle2D var19 = var18.getDataArea();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var19, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     var24.setRenderer(0, var26, true);
//     java.awt.Paint var29 = var24.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var30 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var19, var29);
//     var30.setLineVisible(false);
//     java.awt.Shape var33 = var30.getShape();
//     org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var35 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var34.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var35);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var39.setUpperBound(8.0d);
//     java.awt.Stroke var42 = var39.getAxisLineStroke();
//     var34.setSeriesOutlineStroke(0, var42, true);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var47 = var45.lookupSeriesPaint(1);
//     var34.setBaseFillPaint(var47, false);
//     var30.setLinePaint(var47);
//     var15.setPaint(var47);
//     java.awt.Paint[] var52 = new java.awt.Paint[] { var47};
//     java.awt.Paint var53 = null;
//     java.awt.Paint[] var54 = new java.awt.Paint[] { var53};
//     java.awt.Paint var55 = null;
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var55};
//     java.awt.Stroke var57 = null;
//     java.awt.Stroke[] var58 = new java.awt.Stroke[] { var57};
//     java.awt.Stroke[] var59 = null;
//     java.awt.Shape var60 = null;
//     java.awt.Shape[] var61 = new java.awt.Shape[] { var60};
//     org.jfree.chart.plot.DefaultDrawingSupplier var62 = new org.jfree.chart.plot.DefaultDrawingSupplier(var54, var56, var58, var59, var61);
//     java.awt.Paint var63 = null;
//     java.awt.Paint[] var64 = new java.awt.Paint[] { var63};
//     java.awt.Paint var65 = null;
//     java.awt.Paint[] var66 = new java.awt.Paint[] { var65};
//     java.awt.Stroke var67 = null;
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
//     java.awt.Stroke[] var69 = null;
//     java.awt.Shape var70 = null;
//     java.awt.Shape[] var71 = new java.awt.Shape[] { var70};
//     org.jfree.chart.plot.DefaultDrawingSupplier var72 = new org.jfree.chart.plot.DefaultDrawingSupplier(var64, var66, var68, var69, var71);
//     java.awt.Stroke[] var73 = null;
//     java.awt.Shape[] var74 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var75 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var52, var54, var69, var73, var74);
//     
//     // Checks the contract:  equals-hashcode on var9 and var62
//     assertTrue("Contract failed: equals-hashcode on var9 and var62", var9.equals(var62) ? var9.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var72
//     assertTrue("Contract failed: equals-hashcode on var9 and var72", var9.equals(var72) ? var9.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var9
//     assertTrue("Contract failed: equals-hashcode on var62 and var9", var62.equals(var9) ? var62.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var72
//     assertTrue("Contract failed: equals-hashcode on var62 and var72", var62.equals(var72) ? var62.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var9
//     assertTrue("Contract failed: equals-hashcode on var72 and var9", var72.equals(var9) ? var72.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var62
//     assertTrue("Contract failed: equals-hashcode on var72 and var62", var72.equals(var62) ? var72.hashCode() == var62.hashCode() : true);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(1.0d);
    org.jfree.chart.util.RectangleEdge var3 = null;
    var1.moveCursor(0.05d, var3);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearRangeMarkers(0);
    float var8 = var5.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    int var10 = var5.getDomainAxisIndex(var9);
    java.lang.String var11 = var5.getPlotType();
    org.jfree.chart.util.RectangleInsets var12 = var5.getInsets();
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var16 = var14.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var17 = var14.getNegativeItemLabelPositionFallback();
    var5.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    var20.setAutoTickUnitSelection(false, false);
    org.jfree.data.Range var24 = var20.getDefaultAutoRange();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    var25.clearRangeMarkers(0);
    float var28 = var25.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var29 = null;
    int var30 = var25.getDomainAxisIndex(var29);
    org.jfree.chart.plot.Plot var31 = null;
    var25.setParent(var31);
    org.jfree.chart.axis.CategoryAxis var34 = var25.getDomainAxis(1);
    var20.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var25);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    var37.setRenderer(0, var39, true);
    java.lang.Object var42 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var37);
    org.jfree.chart.axis.AxisLocation var43 = var37.getRangeAxisLocation();
    org.jfree.chart.axis.AxisLocation var44 = org.jfree.chart.axis.AxisLocation.getOpposite(var43);
    var25.setRangeAxisLocation(15, var44);
    org.jfree.chart.axis.AxisLocation var46 = var44.getOpposite();
    var5.setRangeAxisLocation(var44, false);
    boolean var49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.05d, (java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Category Plot"+ "'", var11.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     java.lang.Number[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "RectangleEdge.TOP", var2);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     var4.setDataset(10, var6);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearRangeMarkers(0);
//     float var11 = var8.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var12, 0, 1);
//     var12.setBorderVisible(false);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var18.removeChangeListener(var19);
//     org.jfree.chart.util.RectangleEdge var21 = var18.getPosition();
//     var12.removeSubtitle((org.jfree.chart.title.Title)var18);
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var27 = var25.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var25.getNegativeItemLabelPositionFallback();
//     var25.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var33 = var31.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var36 = var31.getPositiveItemLabelPosition(1, 1);
//     var25.setPositiveItemLabelPositionFallback(var36);
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var41 = var40.getFont();
//     var25.setSeriesItemLabelFont(100, var41);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     var43.clearRangeMarkers(0);
//     float var46 = var43.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     int var48 = var43.getDomainAxisIndex(var47);
//     java.lang.String var49 = var43.getPlotType();
//     org.jfree.chart.util.SortOrder var50 = var43.getRowRenderingOrder();
//     var43.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     java.awt.geom.Rectangle2D var54 = var53.getDataArea();
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var54, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     var59.setRenderer(0, var61, true);
//     java.awt.Paint var64 = var59.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var65 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var54, var64);
//     var43.setOutlinePaint(var64);
//     org.jfree.chart.text.TextBlock var67 = org.jfree.chart.text.TextUtilities.createTextBlock("", var41, var64);
//     org.jfree.chart.renderer.category.BarRenderer var68 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var70 = var68.lookupSeriesPaint(1);
//     org.jfree.chart.text.TextBlock var71 = org.jfree.chart.text.TextUtilities.createTextBlock("Category Plot", var41, var70);
//     var18.setFont(var41);
//     
//     // Checks the contract:  equals-hashcode on var4 and var59
//     assertTrue("Contract failed: equals-hashcode on var4 and var59", var4.equals(var59) ? var4.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var4
//     assertTrue("Contract failed: equals-hashcode on var59 and var4", var59.equals(var4) ? var59.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.lang.Object var8 = var7.clone();
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(0.0d, var7, var9);
    boolean var11 = var0.isRangeCrosshairVisible();
    org.jfree.chart.axis.AxisLocation var12 = var0.getRangeAxisLocation();
    org.jfree.chart.util.ObjectList var14 = new org.jfree.chart.util.ObjectList(10);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var18 = var15.getRowRenderingOrder();
    int var19 = var14.indexOf((java.lang.Object)var15);
    boolean var20 = var12.equals((java.lang.Object)var15);
    org.jfree.chart.plot.PlotOrientation var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var12, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var3 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var3);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setUpperBound(8.0d);
//     java.awt.Stroke var10 = var7.getAxisLineStroke();
//     var2.setSeriesOutlineStroke(0, var10, true);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var15 = var13.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var13.getPositiveItemLabelPosition(1, 1);
//     var2.setBaseNegativeItemLabelPosition(var18, true);
//     org.jfree.chart.text.TextAnchor var21 = var18.getRotationAnchor();
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Rectangle2D var24 = var23.getDataArea();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var24, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     var29.setRenderer(0, var31, true);
//     java.awt.Paint var34 = var29.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var24, var34);
//     var35.setLineVisible(true);
//     java.awt.Shape var38 = var35.getLine();
//     org.jfree.chart.util.RectangleInsets var39 = var35.getPadding();
//     double var41 = var39.calculateBottomOutset(2.0d);
//     boolean var42 = var21.equals((java.lang.Object)var39);
//     org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var44 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var43.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var44);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setUpperBound(8.0d);
//     java.awt.Stroke var51 = var48.getAxisLineStroke();
//     var43.setSeriesOutlineStroke(0, var51, true);
//     org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var56 = var54.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var59 = var54.getPositiveItemLabelPosition(1, 1);
//     var43.setBaseNegativeItemLabelPosition(var59, true);
//     org.jfree.chart.text.TextAnchor var62 = var59.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var64 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)1, "NOID", var21, var62, 8.0d);
//     
//     // Checks the contract:  equals-hashcode on var18 and var59
//     assertTrue("Contract failed: equals-hashcode on var18 and var59", var18.equals(var59) ? var18.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var18
//     assertTrue("Contract failed: equals-hashcode on var59 and var18", var59.equals(var18) ? var59.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
    var0.setPositiveItemLabelPositionFallback(var11);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var16 = var15.getFont();
    var0.setSeriesItemLabelFont(100, var16);
    org.jfree.chart.plot.CategoryPlot var18 = var0.getPlot();
    java.awt.Font var20 = var0.getSeriesItemLabelFont(15);
    var0.setIncludeBaseInRange(true);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(var13, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var17 = var15.toFixedHeight(0.0d);
//     boolean var18 = var9.equals((java.lang.Object)var17);
//     org.jfree.chart.block.RectangleConstraint var19 = var17.toUnconstrainedHeight();
//     org.jfree.chart.block.RectangleConstraint var21 = var19.toFixedWidth(0.0d);
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 1.0d);
//     org.jfree.chart.block.LengthConstraintType var27 = var26.getHeightConstraintType();
//     java.awt.Paint var28 = null;
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
//     java.awt.Paint var30 = null;
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Stroke[] var34 = null;
//     java.awt.Shape var35 = null;
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var29, var31, var33, var34, var36);
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("");
//     var39.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var42 = var39.getStandardTickUnits();
//     boolean var43 = var37.equals((java.lang.Object)var39);
//     org.jfree.data.Range var44 = null;
//     org.jfree.data.Range var46 = org.jfree.data.Range.expandToInclude(var44, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint(var46, 1.0d);
//     org.jfree.data.Range var50 = org.jfree.data.Range.expandToInclude(var46, 0.0d);
//     var39.setRangeWithMargins(var46, true, false);
//     org.jfree.chart.block.RectangleConstraint var54 = var26.toRangeWidth(var46);
//     org.jfree.chart.block.RectangleConstraint var55 = var21.toRangeHeight(var46);
//     
//     // Checks the contract:  equals-hashcode on var9 and var37
//     assertTrue("Contract failed: equals-hashcode on var9 and var37", var9.equals(var37) ? var9.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var9
//     assertTrue("Contract failed: equals-hashcode on var37 and var9", var37.equals(var9) ? var37.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("CONTRACT", var1);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    var0.setWeight(100);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.clearRangeMarkers(0);
    float var14 = var11.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    var15.removeLegend();
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, 1.0d);
    org.jfree.chart.block.RectangleConstraint var23 = var21.toFixedHeight(0.0d);
    boolean var24 = var15.equals((java.lang.Object)var21);
    var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
    java.awt.Image var26 = var15.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 1.0d);
//     org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
//     java.awt.Paint var6 = null;
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Paint var8 = null;
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Stroke[] var12 = null;
//     java.awt.Shape var13 = null;
//     java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var9, var11, var12, var14);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var20 = var17.getStandardTickUnits();
//     boolean var21 = var15.equals((java.lang.Object)var17);
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 1.0d);
//     org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var24, 0.0d);
//     var17.setRangeWithMargins(var24, true, false);
//     org.jfree.chart.block.RectangleConstraint var32 = var4.toRangeWidth(var24);
//     double var33 = var24.getUpperBound();
//     org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var24, 92.0d);
//     java.awt.Paint var36 = null;
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
//     java.awt.Paint var38 = null;
//     java.awt.Paint[] var39 = new java.awt.Paint[] { var38};
//     java.awt.Stroke var40 = null;
//     java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
//     java.awt.Stroke[] var42 = null;
//     java.awt.Shape var43 = null;
//     java.awt.Shape[] var44 = new java.awt.Shape[] { var43};
//     org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier(var37, var39, var41, var42, var44);
//     java.lang.Object var46 = var45.clone();
//     org.jfree.data.Range var47 = null;
//     org.jfree.data.Range var49 = org.jfree.data.Range.expandToInclude(var47, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint(var49, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var53 = var51.toFixedHeight(0.0d);
//     boolean var54 = var45.equals((java.lang.Object)var53);
//     org.jfree.chart.block.RectangleConstraint var55 = var53.toUnconstrainedHeight();
//     boolean var56 = var24.equals((java.lang.Object)var53);
//     
//     // Checks the contract:  equals-hashcode on var15 and var45
//     assertTrue("Contract failed: equals-hashcode on var15 and var45", var15.equals(var45) ? var15.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var15
//     assertTrue("Contract failed: equals-hashcode on var45 and var15", var45.equals(var15) ? var45.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setSeriesItemLabelGenerator(10, var5);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
    var0.setSeriesToolTipGenerator(100, var8);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var12 = var10.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var15 = var10.getPositiveItemLabelPosition(1, 1);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.clearRangeMarkers(0);
    float var20 = var17.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var21 = null;
    int var22 = var17.getDomainAxisIndex(var21);
    java.lang.String var23 = var17.getPlotType();
    org.jfree.chart.util.RectangleInsets var24 = var17.getInsets();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    var25.setRenderer(0, var27, true);
    java.awt.Paint var30 = var25.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(var24, var30);
    var10.setSeriesOutlinePaint(0, var30, false);
    var0.setBaseItemLabelPaint(var30);
    java.awt.Shape var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var35, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "Category Plot"+ "'", var23.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var2 = var1.getFont();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.clearRangeMarkers(0);
//     float var6 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     int var8 = var3.getDomainAxisIndex(var7);
//     java.lang.String var9 = var3.getPlotType();
//     org.jfree.chart.util.RectangleInsets var10 = var3.getInsets();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     var11.setRenderer(0, var13, true);
//     java.awt.Paint var16 = var11.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var10, var16);
//     boolean var18 = var1.equals((java.lang.Object)var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var23 = var20.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var20.addRangeMarker((org.jfree.chart.plot.Marker)var25);
//     org.jfree.chart.util.LengthAdjustmentType var27 = var25.getLabelOffsetType();
//     java.awt.Stroke var28 = var25.getStroke();
//     org.jfree.chart.text.TextAnchor var29 = var25.getLabelTextAnchor();
//     float var30 = var1.calculateBaselineOffset(var19, var29);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Point2D var9 = null;
//     var0.zoomDomainAxes(0.0d, var7, var9);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     org.jfree.chart.ChartRenderingInfo var14 = var12.getOwner();
//     java.lang.Object var15 = var12.clone();
//     var7.addSubplotInfo(var12);
//     
//     // Checks the contract:  equals-hashcode on var8 and var15
//     assertTrue("Contract failed: equals-hashcode on var8 and var15", var8.equals(var15) ? var8.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var8
//     assertTrue("Contract failed: equals-hashcode on var15 and var8", var15.equals(var8) ? var15.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var1.removeChangeListener(var2);
    double var4 = var1.getContentXOffset();
    org.jfree.data.KeyedObject var5 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var1);
    org.jfree.chart.util.HorizontalAlignment var6 = var1.getHorizontalAlignment();
    java.lang.String var7 = var1.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.clearRangeMarkers(0);
    float var5 = var2.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var6 = null;
    int var7 = var2.getDomainAxisIndex(var6);
    java.lang.String var8 = var2.getPlotType();
    org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
    var0.setMargin(var9);
    org.jfree.chart.util.UnitType var11 = var9.getUnitType();
    double var13 = var9.extendHeight(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Category Plot"+ "'", var8.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 16.0d);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var5 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var4.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var5);
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(8.0d);
//     java.awt.Stroke var12 = var9.getAxisLineStroke();
//     var4.setSeriesOutlineStroke(0, var12, true);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var15.getPositiveItemLabelPosition(1, 1);
//     var4.setBaseNegativeItemLabelPosition(var20, true);
//     org.jfree.chart.text.TextAnchor var23 = var20.getRotationAnchor();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var26, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     var31.setRenderer(0, var33, true);
//     java.awt.Paint var36 = var31.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var26, var36);
//     var37.setLineVisible(true);
//     java.awt.Shape var40 = var37.getLine();
//     org.jfree.chart.util.RectangleInsets var41 = var37.getPadding();
//     double var43 = var41.calculateBottomOutset(2.0d);
//     boolean var44 = var23.equals((java.lang.Object)var41);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.event.ChartChangeEvent[source=]", var1, 0.0f, (-1.0f), var23, (-23.0d), 0.5f, (-1.0f));
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     var6.setUpperBound(8.0d);
//     java.awt.Stroke var9 = var6.getAxisLineStroke();
//     var4.setOutlineStroke(var9);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     org.jfree.chart.util.Layer var14 = null;
//     var4.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var13, var14);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setUpperBound(8.0d);
//     java.awt.Stroke var20 = var17.getAxisLineStroke();
//     org.jfree.chart.util.RectangleInsets var21 = var17.getLabelInsets();
//     var4.setAxisOffset(var21);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearRangeMarkers(0);
//     float var26 = var23.getBackgroundImageAlpha();
//     org.jfree.chart.axis.AxisSpace var27 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var31 = var28.getRowRenderingOrder();
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     java.lang.Object var33 = var27.clone();
//     var23.setFixedDomainAxisSpace(var27);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     var35.setRenderer(0, var37, true);
//     java.lang.Object var40 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var35);
//     org.jfree.chart.axis.AxisLocation var41 = var35.getRangeAxisLocation();
//     java.lang.String var42 = var41.toString();
//     var23.setDomainAxisLocation(var41);
//     float var44 = var23.getBackgroundImageAlpha();
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var48 = var45.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var45.addRangeMarker((org.jfree.chart.plot.Marker)var50);
//     java.awt.Paint var52 = var50.getLabelPaint();
//     var23.setRangeGridlinePaint(var52);
//     java.awt.Color var57 = java.awt.Color.getHSBColor(1.0f, 0.0f, 100.0f);
//     var23.setBackgroundPaint((java.awt.Paint)var57);
//     var4.setDomainGridlinePaint((java.awt.Paint)var57);
//     
//     // Checks the contract:  equals-hashcode on var13 and var50
//     assertTrue("Contract failed: equals-hashcode on var13 and var50", var13.equals(var50) ? var13.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var13
//     assertTrue("Contract failed: equals-hashcode on var50 and var13", var50.equals(var13) ? var50.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 116.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var4 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.awt.geom.Rectangle2D var8 = var7.getDataArea();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var8);
//     boolean var10 = var4.equals((java.lang.Object)var8);
//     java.awt.Color var14 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     int var15 = var14.getRed();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     var22.setUpperBound(8.0d);
//     java.awt.Stroke var25 = var22.getAxisLineStroke();
//     var20.setOutlineStroke(var25);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.clearRangeMarkers(0);
//     float var30 = var27.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     int var32 = var27.getDomainAxisIndex(var31);
//     java.lang.String var33 = var27.getPlotType();
//     org.jfree.chart.util.SortOrder var34 = var27.getRowRenderingOrder();
//     var27.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     java.awt.geom.Rectangle2D var38 = var37.getDataArea();
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var38, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
//     var43.setRenderer(0, var45, true);
//     java.awt.Paint var48 = var43.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var49 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var38, var48);
//     var27.setOutlinePaint(var48);
//     org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("[size=10]", "AxisLocation.TOP_OR_LEFT", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Range[0.0,0.0]", (java.awt.Shape)var8, (java.awt.Paint)var14, var25, var48);
//     
//     // Checks the contract:  equals-hashcode on var7 and var37
//     assertTrue("Contract failed: equals-hashcode on var7 and var37", var7.equals(var37) ? var7.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var7
//     assertTrue("Contract failed: equals-hashcode on var37 and var7", var37.equals(var7) ? var37.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.util.StrokeList var1 = new org.jfree.chart.util.StrokeList();
//     int var2 = var1.size();
//     org.jfree.chart.axis.CategoryLabelPositions var4 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
//     boolean var5 = var1.equals((java.lang.Object)var4);
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var6.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var6.notifyListeners(var9);
//     var6.setItemLabelAnchorOffset(4.0d);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearRangeMarkers(0);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     var18.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var21 = var18.getStandardTickUnits();
//     var18.setLabelToolTip("SortOrder.ASCENDING");
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var26, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     var31.setRenderer(0, var33, true);
//     java.awt.Paint var36 = var31.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var26, var36);
//     var6.drawRangeGridline(var13, var14, (org.jfree.chart.axis.ValueAxis)var18, var26, (-1.0d));
//     boolean var40 = var1.equals((java.lang.Object)var26);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, (java.awt.Shape)var26, 1.0E-8d, 0.0f, 1.0f);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    var1.setRenderer(0, var3, true);
    java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var8 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var7);
    java.util.List var9 = var7.getColumnKeys();
    int var10 = var7.getRowCount();
    var1.setDataset((org.jfree.data.category.CategoryDataset)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var0.generateLabel((org.jfree.data.category.CategoryDataset)var7, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 0.0d+ "'", var8.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var1 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var2 = new org.jfree.chart.plot.PlotRenderingInfo(var1);
//     org.jfree.chart.ChartRenderingInfo var3 = var2.getOwner();
//     java.awt.geom.Rectangle2D var4 = var2.getDataArea();
//     org.jfree.chart.entity.CategoryLabelEntity var7 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.2d, (java.awt.Shape)var4, "UnitType.ABSOLUTE", "");
//     java.lang.Comparable var8 = var7.getKey();
//     java.lang.String var9 = var7.toString();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var10 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var11 = null;
//     java.lang.String var12 = var7.getImageMapAreaTag(var10, var11);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 8.0d);
    org.jfree.chart.block.BlockContainer var5 = null;
    java.awt.Graphics2D var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, 1.0d);
    org.jfree.chart.block.RectangleConstraint var12 = var11.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedWidth(92.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var15 = var4.arrange(var5, var6, var12);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var1.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var2);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    var6.setUpperBound(8.0d);
    java.awt.Stroke var9 = var6.getAxisLineStroke();
    var1.setSeriesOutlineStroke(0, var9, true);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var14 = var12.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var17 = var12.getPositiveItemLabelPosition(1, 1);
    var1.setBaseNegativeItemLabelPosition(var17, true);
    org.jfree.chart.text.TextAnchor var20 = var17.getRotationAnchor();
    org.jfree.chart.ChartRenderingInfo var21 = null;
    org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
    java.awt.geom.Rectangle2D var23 = var22.getDataArea();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var23, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    var28.setRenderer(0, var30, true);
    java.awt.Paint var33 = var28.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var34 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var23, var33);
    var34.setLineVisible(true);
    java.awt.Shape var37 = var34.getLine();
    org.jfree.chart.util.RectangleInsets var38 = var34.getPadding();
    double var40 = var38.calculateBottomOutset(2.0d);
    boolean var41 = var20.equals((java.lang.Object)var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var42 = new org.jfree.chart.labels.ItemLabelPosition(var0, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject("org.jfree.chart.event.ChartChangeEvent[source=]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Point2D var9 = null;
//     var0.zoomDomainAxes(0.0d, var7, var9);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     org.jfree.chart.ChartRenderingInfo var14 = var13.getOwner();
//     java.awt.geom.Rectangle2D var15 = var13.getDataArea();
//     org.jfree.chart.entity.CategoryLabelEntity var18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.2d, (java.awt.Shape)var15, "UnitType.ABSOLUTE", "");
//     var7.setDataArea(var15);
//     
//     // Checks the contract:  equals-hashcode on var7 and var13
//     assertTrue("Contract failed: equals-hashcode on var7 and var13", var7.equals(var13) ? var7.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var7
//     assertTrue("Contract failed: equals-hashcode on var13 and var7", var13.equals(var7) ? var13.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearRangeMarkers(0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var12.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var15 = var12.getStandardTickUnits();
    var12.setLabelToolTip("SortOrder.ASCENDING");
    org.jfree.chart.ChartRenderingInfo var18 = null;
    org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
    java.awt.geom.Rectangle2D var20 = var19.getDataArea();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var20, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    var25.setRenderer(0, var27, true);
    java.awt.Paint var30 = var25.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var31 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var20, var30);
    var0.drawRangeGridline(var7, var8, (org.jfree.chart.axis.ValueAxis)var12, var20, (-1.0d));
    org.jfree.chart.labels.CategoryItemLabelGenerator var34 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.CategoryToolTipGenerator var35 = var0.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     var1.setUpperBound(8.0d);
//     java.awt.Stroke var4 = var1.getAxisLineStroke();
//     org.jfree.chart.axis.TickUnits var5 = new org.jfree.chart.axis.TickUnits();
//     var1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource)var5);
//     org.jfree.chart.axis.TickUnit var7 = null;
//     var5.add(var7);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var3 = var2.getPaint();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearRangeMarkers(0);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    int var9 = var4.getDomainAxisIndex(var8);
    java.lang.String var10 = var4.getPlotType();
    org.jfree.chart.util.RectangleInsets var11 = var4.getInsets();
    var2.setMargin(var11);
    double var14 = var11.calculateTopOutset(100.0d);
    var0.setMargin(var11);
    org.jfree.chart.util.UnitType var16 = var11.getUnitType();
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets(var16, 92.0d, Double.POSITIVE_INFINITY, (-17.0d), 4.0d);
    org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets(var16, 0.0d, 116.0d, Double.POSITIVE_INFINITY, 116.0d);
    double var27 = var26.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Category Plot"+ "'", var10.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 116.0d);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var0.notifyListeners(var3);
//     var0.setItemLabelAnchorOffset(4.0d);
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     java.awt.geom.Rectangle2D var10 = var9.getDataArea();
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var10, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     var15.setRenderer(0, var17, true);
//     java.awt.Paint var20 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var21 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var10, var20);
//     var0.setSeriesShape(10, (java.awt.Shape)var10);
//     boolean var23 = var0.getAutoPopulateSeriesPaint();
//     java.awt.Paint var26 = var0.getItemFillPaint(0, 10);
//     java.awt.Paint var28 = null;
//     var0.setSeriesItemLabelPaint(100, var28);
//     java.awt.Stroke var31 = var0.lookupSeriesOutlineStroke(10);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var35 = var32.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var32.addRangeMarker((org.jfree.chart.plot.Marker)var37);
//     org.jfree.chart.util.LengthAdjustmentType var39 = var37.getLabelOffsetType();
//     java.awt.Font var40 = var37.getLabelFont();
//     org.jfree.chart.util.RectangleInsets var41 = var37.getLabelOffset();
//     org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var43 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var42.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var43);
//     org.jfree.chart.event.RendererChangeEvent var45 = null;
//     var42.notifyListeners(var45);
//     var42.setItemLabelAnchorOffset(4.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var49 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var50 = var42.findRangeBounds((org.jfree.data.category.CategoryDataset)var49);
//     org.jfree.data.category.CategoryDataset var51 = null;
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var51, var52, var53, var54);
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
//     var57.setUpperBound(8.0d);
//     java.awt.Stroke var60 = var57.getAxisLineStroke();
//     var55.setOutlineStroke(var60);
//     var42.setBaseStroke(var60);
//     var37.setOutlineStroke(var60);
//     var0.setBaseOutlineStroke(var60, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var42 and var0.", var42.equals(var0) == var0.equals(var42));
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     var0.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
//     var0.setPositiveItemLabelPositionFallback(var11);
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var16 = var15.getFont();
//     var0.setSeriesItemLabelFont(100, var16);
//     java.awt.Paint var18 = var0.getBaseItemLabelPaint();
//     org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
//     var0.setSeriesToolTipGenerator(15, var20);
//     org.jfree.chart.labels.ItemLabelPosition var23 = var0.getSeriesPositiveItemLabelPosition((-1));
//     
//     // Checks the contract:  equals-hashcode on var11 and var23
//     assertTrue("Contract failed: equals-hashcode on var11 and var23", var11.equals(var23) ? var11.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var11
//     assertTrue("Contract failed: equals-hashcode on var23 and var11", var23.equals(var11) ? var23.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 8.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var6 = null;
//     var5.removeChangeListener(var6);
//     org.jfree.chart.block.CenterArrangement var8 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var10 = null;
//     var9.removeChangeListener(var10);
//     java.lang.Object var12 = var9.clone();
//     boolean var13 = var8.equals(var12);
//     var4.add((org.jfree.chart.block.Block)var5, var12);
//     org.jfree.chart.ChartRenderingInfo var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = new org.jfree.chart.plot.PlotRenderingInfo(var15);
//     java.awt.geom.Rectangle2D var17 = var16.getDataArea();
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var17, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     var22.setRenderer(0, var24, true);
//     java.awt.Paint var27 = var22.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var17, var27);
//     org.jfree.chart.block.BlockResult var29 = new org.jfree.chart.block.BlockResult();
//     org.jfree.chart.entity.EntityCollection var30 = var29.getEntityCollection();
//     var4.add((org.jfree.chart.block.Block)var28, (java.lang.Object)var29);
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var34 = var32.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var35 = var32.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var37 = null;
//     var32.setSeriesItemLabelGenerator(10, var37);
//     org.jfree.chart.labels.CategoryToolTipGenerator var40 = null;
//     var32.setSeriesToolTipGenerator(100, var40);
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     java.awt.geom.Rectangle2D var45 = var44.getDataArea();
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var45, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     var50.setRenderer(0, var52, true);
//     java.awt.Paint var55 = var50.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var56 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var45, var55);
//     var32.setSeriesPaint(0, var55);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var58 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     var32.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var58);
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
//     var61.clearRangeMarkers(0);
//     float var64 = var61.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var65 = null;
//     int var66 = var61.getDomainAxisIndex(var65);
//     java.lang.String var67 = var61.getPlotType();
//     org.jfree.chart.util.SortOrder var68 = var61.getRowRenderingOrder();
//     var61.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var70 = var61.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.BarRenderer var72 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var73 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var72.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var73);
//     org.jfree.chart.event.RendererChangeEvent var75 = null;
//     var72.notifyListeners(var75);
//     var72.setItemLabelAnchorOffset(4.0d);
//     var61.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var72, true);
//     java.awt.Shape var83 = var72.getItemShape(10, 0);
//     java.awt.Color var87 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
//     java.lang.String var88 = var87.toString();
//     java.lang.String var89 = var87.toString();
//     org.jfree.chart.title.LegendGraphic var90 = new org.jfree.chart.title.LegendGraphic(var83, (java.awt.Paint)var87);
//     var32.setSeriesOutlinePaint(10, (java.awt.Paint)var87);
//     boolean var92 = var4.equals((java.lang.Object)var87);
//     
//     // Checks the contract:  equals-hashcode on var16 and var44
//     assertTrue("Contract failed: equals-hashcode on var16 and var44", var16.equals(var44) ? var16.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var16
//     assertTrue("Contract failed: equals-hashcode on var44 and var16", var44.equals(var16) ? var44.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var50
//     assertTrue("Contract failed: equals-hashcode on var22 and var50", var22.equals(var50) ? var22.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var22
//     assertTrue("Contract failed: equals-hashcode on var50 and var22", var50.equals(var22) ? var50.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearRangeMarkers(0);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var12.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var15 = var12.getStandardTickUnits();
    var12.setLabelToolTip("SortOrder.ASCENDING");
    org.jfree.chart.ChartRenderingInfo var18 = null;
    org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
    java.awt.geom.Rectangle2D var20 = var19.getDataArea();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var20, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    var25.setRenderer(0, var27, true);
    java.awt.Paint var30 = var25.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var31 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var20, var30);
    var0.drawRangeGridline(var7, var8, (org.jfree.chart.axis.ValueAxis)var12, var20, (-1.0d));
    var8.configureRangeAxes();
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    var35.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var38 = var35.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var35.addRangeMarker((org.jfree.chart.plot.Marker)var40);
    org.jfree.chart.util.LengthAdjustmentType var42 = var40.getLabelOffsetType();
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
    var44.setUpperBound(8.0d);
    java.awt.Stroke var47 = var44.getAxisLineStroke();
    var40.setStroke(var47);
    var8.setRangeGridlineStroke(var47);
    org.jfree.chart.util.Layer var50 = null;
    java.util.Collection var51 = var8.getDomainMarkers(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var1.removeChangeListener(var2);
    double var4 = var1.getContentXOffset();
    org.jfree.data.KeyedObject var5 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var1);
    org.jfree.chart.block.BlockResult var6 = new org.jfree.chart.block.BlockResult();
    var5.setObject((java.lang.Object)var6);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    var10.setUpperBound(8.0d);
    java.awt.Stroke var13 = var10.getAxisLineStroke();
    org.jfree.chart.util.RectangleInsets var14 = var10.getLabelInsets();
    org.jfree.data.KeyedObject var15 = new org.jfree.data.KeyedObject((java.lang.Comparable)10L, (java.lang.Object)var10);
    double var16 = var10.getFixedDimension();
    boolean var17 = var10.isTickLabelsVisible();
    boolean var18 = var10.getAutoRangeIncludesZero();
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var19, var20, var21, var22);
    org.jfree.data.category.CategoryDataset var25 = null;
    var23.setDataset(10, var25);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.clearRangeMarkers(0);
    float var30 = var27.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var27);
    org.jfree.chart.event.ChartProgressEvent var34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)10, var31, 0, 1);
    org.jfree.chart.plot.Plot var35 = var31.getPlot();
    var10.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var35);
    boolean var37 = var5.equals((java.lang.Object)var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     var0.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
//     var0.setPositiveItemLabelPositionFallback(var11);
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var16 = var15.getFont();
//     var0.setSeriesItemLabelFont(100, var16);
//     java.awt.Font var20 = var0.getItemLabelFont((-2), 10);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.clearRangeMarkers(0);
//     float var24 = var21.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     int var26 = var21.getDomainAxisIndex(var25);
//     java.lang.String var27 = var21.getPlotType();
//     org.jfree.chart.util.RectangleInsets var28 = var21.getInsets();
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     var29.setRenderer(0, var31, true);
//     java.awt.Paint var34 = var29.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(var28, var34);
//     var0.setBaseOutlinePaint(var34, true);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var42 = var39.getRowRenderingOrder();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var47, var48, var49, var50);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     var51.setDataset(10, var53);
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.ChartRenderingInfo var56 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var57 = new org.jfree.chart.plot.PlotRenderingInfo(var56);
//     java.awt.geom.Rectangle2D var58 = var57.getDataArea();
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var58, 1.0d, (-1.0d));
//     var51.drawBackgroundImage(var55, var58);
//     org.jfree.chart.renderer.category.BarRenderer var63 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var64 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var63.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var64);
//     java.awt.Paint var66 = var63.getBaseOutlinePaint();
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("Size2D[width=-1.0, height=10.0]", "Category Plot", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]", "Range[0.0,0.0]", (java.awt.Shape)var58, var66);
//     var0.drawOutline(var38, var39, var58);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    java.util.List var2 = var0.getColumnKeys();
    int var3 = var0.getRowCount();
    java.util.List var4 = var0.getColumnKeys();
    java.lang.Comparable var5 = null;
    java.lang.Comparable var6 = null;
    var0.removeObject(var5, var6);
    int var9 = var0.getRowIndex((java.lang.Comparable)"Category Plot");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var12 = var0.getObject(10, (-2));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearRangeMarkers(0);
//     float var4 = var1.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var5.removeLegend();
//     org.jfree.chart.event.ChartProgressEvent var9 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var5, 10, 10);
//     org.jfree.chart.title.LegendTitle var10 = var5.getLegend();
//     org.jfree.chart.title.TextTitle var11 = null;
//     var5.setTitle(var11);
//     java.awt.RenderingHints var13 = var5.getRenderingHints();
//     org.jfree.chart.title.LegendTitle var15 = var5.getLegend(10);
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     var5.handleClick(0, 0, var18);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperBound(8.0d);
    java.awt.Stroke var4 = var1.getAxisLineStroke();
    var1.setFixedDimension(4.0d);
    var1.centerRange(Double.NaN);
    var1.setTickLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.clearRangeMarkers(0);
    float var5 = var2.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var6 = null;
    int var7 = var2.getDomainAxisIndex(var6);
    java.lang.String var8 = var2.getPlotType();
    org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
    var0.setMargin(var9);
    double var12 = var9.calculateTopInset(3.0d);
    double var13 = var9.getBottom();
    double var15 = var9.calculateRightInset(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Category Plot"+ "'", var8.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 8.0d);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getLGPL();
    java.lang.String var2 = var0.getGPL();

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var6 = var4.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var4.getNegativeItemLabelPositionFallback();
//     var4.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var12 = var10.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var10.getPositiveItemLabelPosition(1, 1);
//     var4.setPositiveItemLabelPositionFallback(var15);
//     org.jfree.chart.text.TextFragment var19 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var20 = var19.getFont();
//     var4.setSeriesItemLabelFont(100, var20);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearRangeMarkers(0);
//     float var25 = var22.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     int var27 = var22.getDomainAxisIndex(var26);
//     java.lang.String var28 = var22.getPlotType();
//     org.jfree.chart.util.SortOrder var29 = var22.getRowRenderingOrder();
//     var22.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var33, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     var38.setRenderer(0, var40, true);
//     java.awt.Paint var43 = var38.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var44 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var33, var43);
//     var22.setOutlinePaint(var43);
//     org.jfree.chart.text.TextBlock var46 = org.jfree.chart.text.TextUtilities.createTextBlock("", var20, var43);
//     var2.setLabelFont(var20);
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     java.awt.geom.Rectangle2D var54 = var53.getDataArea();
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var54, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     var59.setRenderer(0, var61, true);
//     java.awt.Paint var64 = var59.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var65 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var54, var64);
//     org.jfree.chart.block.BlockBorder var66 = new org.jfree.chart.block.BlockBorder(92.0d, 10.0d, 2.0d, 4.0d, var64);
//     org.jfree.chart.text.TextFragment var67 = new org.jfree.chart.text.TextFragment("2", var20, var64);
//     
//     // Checks the contract:  equals-hashcode on var38 and var59
//     assertTrue("Contract failed: equals-hashcode on var38 and var59", var38.equals(var59) ? var38.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var38
//     assertTrue("Contract failed: equals-hashcode on var59 and var38", var59.equals(var38) ? var59.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var53
//     assertTrue("Contract failed: equals-hashcode on var32 and var53", var32.equals(var53) ? var32.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var32
//     assertTrue("Contract failed: equals-hashcode on var53 and var32", var53.equals(var32) ? var53.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var3 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var3);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     var7.setUpperBound(8.0d);
//     java.awt.Stroke var10 = var7.getAxisLineStroke();
//     var2.setSeriesOutlineStroke(0, var10, true);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var15 = var13.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var13.getPositiveItemLabelPosition(1, 1);
//     var2.setBaseNegativeItemLabelPosition(var18, true);
//     org.jfree.chart.text.TextAnchor var21 = var18.getRotationAnchor();
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Rectangle2D var24 = var23.getDataArea();
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var24, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     var29.setRenderer(0, var31, true);
//     java.awt.Paint var34 = var29.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var24, var34);
//     var35.setLineVisible(true);
//     java.awt.Shape var38 = var35.getLine();
//     org.jfree.chart.util.RectangleInsets var39 = var35.getPadding();
//     double var41 = var39.calculateBottomOutset(2.0d);
//     boolean var42 = var21.equals((java.lang.Object)var39);
//     org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var44 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var43.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var44);
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("");
//     var48.setUpperBound(8.0d);
//     java.awt.Stroke var51 = var48.getAxisLineStroke();
//     var43.setSeriesOutlineStroke(0, var51, true);
//     org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var56 = var54.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var59 = var54.getPositiveItemLabelPosition(1, 1);
//     var43.setBaseNegativeItemLabelPosition(var59, true);
//     org.jfree.chart.text.TextAnchor var62 = var59.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var64 = new org.jfree.chart.axis.NumberTick((java.lang.Number)2.0d, "RectangleAnchor.TOP_LEFT", var21, var62, 16.0d);
//     
//     // Checks the contract:  equals-hashcode on var18 and var59
//     assertTrue("Contract failed: equals-hashcode on var18 and var59", var18.equals(var59) ? var18.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var18
//     assertTrue("Contract failed: equals-hashcode on var59 and var18", var59.equals(var18) ? var59.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.RectangleInsets var7 = var0.getInsets();
    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    java.awt.geom.Rectangle2D var10 = var9.getDataArea();
    java.awt.geom.Rectangle2D var11 = var7.createOutsetRectangle(var10);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    int var15 = var14.getRowCount();
    org.jfree.chart.entity.CategoryItemEntity var18 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var10, "hi!", "", (org.jfree.data.category.CategoryDataset)var14, (java.lang.Comparable)1.0d, (java.lang.Comparable)(byte)0);
    var18.setColumnKey((java.lang.Comparable)0L);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var21 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.TickUnits var25 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var27 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var25.add((org.jfree.chart.axis.TickUnit)var27);
    var21.add(8.0d, 4.0d, (java.lang.Comparable)4.0d, (java.lang.Comparable)var27);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    var30.setRenderer(0, var32, true);
    java.lang.Object var35 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var30);
    org.jfree.chart.axis.ValueAxis var37 = null;
    var30.setRangeAxis(0, var37);
    var21.addChangeListener((org.jfree.data.general.DatasetChangeListener)var30);
    int var41 = var21.getRowIndex((java.lang.Comparable)"0");
    java.lang.Comparable var43 = null;
    java.lang.Number var44 = var21.getStdDevValue((java.lang.Comparable)3.0d, var43);
    var18.setDataset((org.jfree.data.category.CategoryDataset)var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var21, (java.lang.Comparable)(short)1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    java.awt.Paint var1 = null;
    java.awt.Paint[] var2 = new java.awt.Paint[] { var1};
    java.awt.Paint var3 = null;
    java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke[] var7 = null;
    java.awt.Shape var8 = null;
    java.awt.Shape[] var9 = new java.awt.Shape[] { var8};
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var2, var4, var6, var7, var9);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var12.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var15 = var12.getStandardTickUnits();
    boolean var16 = var10.equals((java.lang.Object)var12);
    var12.setTickMarksVisible(false);
    var12.setFixedDimension(0.0d);
    var12.setNegativeArrowVisible(false);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    var23.setRenderer(0, var25, true);
    java.lang.Object var28 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
    var12.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    var30.clearRangeMarkers(0);
    float var33 = var30.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var34 = null;
    int var35 = var30.getDomainAxisIndex(var34);
    java.lang.String var36 = var30.getPlotType();
    org.jfree.chart.util.SortOrder var37 = var30.getRowRenderingOrder();
    var30.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var39 = var30.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var42 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var41.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var42);
    org.jfree.chart.event.RendererChangeEvent var44 = null;
    var41.notifyListeners(var44);
    var41.setItemLabelAnchorOffset(4.0d);
    var30.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41, true);
    java.awt.Shape var52 = var41.getItemShape(10, 0);
    java.awt.Color var56 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.lang.String var57 = var56.toString();
    java.lang.String var58 = var56.toString();
    org.jfree.chart.title.LegendGraphic var59 = new org.jfree.chart.title.LegendGraphic(var52, (java.awt.Paint)var56);
    var12.setLabelPaint((java.awt.Paint)var56);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var61 = new org.jfree.chart.block.BlockBorder(var0, (java.awt.Paint)var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "Category Plot"+ "'", var36.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var57.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var58.equals("java.awt.Color[r=0,g=0,b=0]"));

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    var0.setSeriesItemLabelsVisible(10, false);
    var0.setBaseCreateEntities(true);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(Double.POSITIVE_INFINITY, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var5 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var4.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var5);
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
//     var9.setUpperBound(8.0d);
//     java.awt.Stroke var12 = var9.getAxisLineStroke();
//     var4.setSeriesOutlineStroke(0, var12, true);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var15.getPositiveItemLabelPosition(1, 1);
//     var4.setBaseNegativeItemLabelPosition(var20, true);
//     org.jfree.chart.text.TextAnchor var23 = var20.getRotationAnchor();
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = new org.jfree.chart.plot.PlotRenderingInfo(var24);
//     java.awt.geom.Rectangle2D var26 = var25.getDataArea();
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var26, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     var31.setRenderer(0, var33, true);
//     java.awt.Paint var36 = var31.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var26, var36);
//     var37.setLineVisible(true);
//     java.awt.Shape var40 = var37.getLine();
//     org.jfree.chart.util.RectangleInsets var41 = var37.getPadding();
//     double var43 = var41.calculateBottomOutset(2.0d);
//     boolean var44 = var23.equals((java.lang.Object)var41);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     var46.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var49 = var46.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var46.addRangeMarker((org.jfree.chart.plot.Marker)var51);
//     org.jfree.chart.util.LengthAdjustmentType var53 = var51.getLabelOffsetType();
//     java.awt.Stroke var54 = var51.getStroke();
//     org.jfree.chart.text.TextAnchor var55 = var51.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("SortOrder.ASCENDING", var1, 10.0f, 0.5f, var23, (-23.0d), var55);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     var0.setDrawBarOutline(false);
//     java.awt.Paint var14 = var0.getItemOutlinePaint(0, 0);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.util.ObjectList var17 = new org.jfree.chart.util.ObjectList(10);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var21 = var18.getRowRenderingOrder();
//     int var22 = var17.indexOf((java.lang.Object)var18);
//     var18.setRangeCrosshairLockedOnData(true);
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
//     var26.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.clearRangeMarkers(0);
//     float var37 = var34.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var38 = null;
//     int var39 = var34.getDomainAxisIndex(var38);
//     java.lang.String var40 = var34.getPlotType();
//     org.jfree.chart.util.SortOrder var41 = var34.getRowRenderingOrder();
//     var34.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var43 = var34.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleEdge var45 = var34.getRangeAxisEdge(0);
//     double var46 = var26.java2DToValue(10.0d, var33, var45);
//     var0.drawBackground(var15, var18, var33);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("org.jfree.chart.event.ChartChangeEvent[source=]", "", "SortOrder.ASCENDING", "java.awt.Color[r=0,g=0,b=0]");
    java.lang.String var5 = var4.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "SortOrder.ASCENDING"+ "'", var5.equals("SortOrder.ASCENDING"));

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
//     boolean var15 = var9.equals((java.lang.Object)var11);
//     var11.setTickMarksVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var19 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var18.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var19);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setUpperBound(8.0d);
//     java.awt.Stroke var26 = var23.getAxisLineStroke();
//     var18.setSeriesOutlineStroke(0, var26, true);
//     var11.setAxisLineStroke(var26);
//     java.text.NumberFormat var30 = var11.getNumberFormatOverride();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var33, 1.0d, (-1.0d));
//     org.jfree.chart.entity.AxisLabelEntity var39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var11, var36, "Category Plot", "[size=10]");
//     org.jfree.chart.axis.Axis var40 = var39.getAxis();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var41 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var42 = null;
//     java.lang.String var43 = var39.getImageMapAreaTag(var41, var42);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, true);
    org.jfree.data.KeyedObjects2D var5 = new org.jfree.data.KeyedObjects2D();
    java.util.List var6 = var5.getColumnKeys();
    java.util.List var7 = var5.getColumnKeys();
    int var9 = var5.getColumnIndex((java.lang.Comparable)(short)(-1));
    boolean var10 = var0.equals((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var12 = var5.getRowKey((-2));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + 0.0d+ "'", var1.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("2", var1);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     var0.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var8 = var6.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var6.getPositiveItemLabelPosition(1, 1);
//     var0.setPositiveItemLabelPositionFallback(var11);
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Font var16 = var15.getFont();
//     var0.setSeriesItemLabelFont(100, var16);
//     java.awt.Font var20 = var0.getItemLabelFont((-2), 10);
//     var0.setSeriesItemLabelsVisible(0, true);
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var26 = var24.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var27 = var24.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = null;
//     var24.setSeriesItemLabelGenerator(10, var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
//     var24.setSeriesToolTipGenerator(100, var32);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     java.awt.geom.Rectangle2D var37 = var36.getDataArea();
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var37, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     var42.setRenderer(0, var44, true);
//     java.awt.Paint var47 = var42.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var37, var47);
//     var24.setSeriesPaint(0, var47);
//     org.jfree.chart.labels.ItemLabelPosition var51 = var24.getSeriesNegativeItemLabelPosition(1);
//     var0.setBasePositiveItemLabelPosition(var51, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var24.", var6.equals(var24) == var24.equals(var6));
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getOptionalLibraries();
    org.jfree.chart.ui.Library[] var2 = var0.getLibraries();
    var0.setName("AxisLocation.TOP_OR_LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
//     var0.clearDomainAxes();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     java.awt.geom.Rectangle2D var11 = var10.getDataArea();
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var11, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     var16.setRenderer(0, var18, true);
//     java.awt.Paint var21 = var16.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var11, var21);
//     var0.setOutlinePaint(var21);
//     boolean var24 = var0.isSubplot();
//     int var25 = var0.getRangeAxisCount();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     var26.setCategoryLabelPositionOffset(0);
//     java.awt.Paint var30 = var26.getTickLabelPaint((java.lang.Comparable)false);
//     var0.setDomainAxis(var26);
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var33 = null;
//     var32.removeChangeListener(var33);
//     java.lang.Object var35 = var32.clone();
//     org.jfree.chart.util.HorizontalAlignment var36 = var32.getHorizontalAlignment();
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     double var40 = var37.getContentXOffset();
//     org.jfree.chart.util.VerticalAlignment var41 = var37.getVerticalAlignment();
//     org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement(var36, var41, 0.0d, 0.0d);
//     org.jfree.chart.ChartRenderingInfo var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var45);
//     java.awt.geom.Rectangle2D var47 = var46.getDataArea();
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var47, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     var52.setRenderer(0, var54, true);
//     java.awt.Paint var57 = var52.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var58 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var47, var57);
//     var58.setLineVisible(false);
//     java.awt.Shape var61 = var58.getShape();
//     org.jfree.chart.renderer.category.BarRenderer var62 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var63 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var62.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var63);
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("");
//     var67.setUpperBound(8.0d);
//     java.awt.Stroke var70 = var67.getAxisLineStroke();
//     var62.setSeriesOutlineStroke(0, var70, true);
//     org.jfree.chart.renderer.category.BarRenderer var73 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var75 = var73.lookupSeriesPaint(1);
//     var62.setBaseFillPaint(var75, false);
//     var58.setLinePaint(var75);
//     boolean var79 = var44.equals((java.lang.Object)var75);
//     var0.setRangeCrosshairPaint(var75);
//     
//     // Checks the contract:  equals-hashcode on var16 and var52
//     assertTrue("Contract failed: equals-hashcode on var16 and var52", var16.equals(var52) ? var16.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var16
//     assertTrue("Contract failed: equals-hashcode on var52 and var16", var52.equals(var16) ? var52.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var46
//     assertTrue("Contract failed: equals-hashcode on var10 and var46", var10.equals(var46) ? var10.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var10
//     assertTrue("Contract failed: equals-hashcode on var46 and var10", var46.equals(var10) ? var46.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryLabelPositionOffset(0);
//     java.awt.Paint var4 = var0.getTickLabelPaint((java.lang.Comparable)false);
//     int var5 = var0.getMaximumCategoryLabelLines();
//     org.jfree.chart.ChartRenderingInfo var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
//     java.awt.geom.Rectangle2D var9 = var8.getDataArea();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var9, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var14.setRenderer(0, var16, true);
//     java.awt.Paint var19 = var14.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var20 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var9, var19);
//     var20.setLineVisible(false);
//     java.awt.Shape var23 = var20.getShape();
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var24.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var25);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setUpperBound(8.0d);
//     java.awt.Stroke var32 = var29.getAxisLineStroke();
//     var24.setSeriesOutlineStroke(0, var32, true);
//     org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var37 = var35.lookupSeriesPaint(1);
//     var24.setBaseFillPaint(var37, false);
//     var20.setLinePaint(var37);
//     var0.setTickLabelPaint((java.lang.Comparable)15, var37);
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.event.RendererChangeEvent var45 = null;
//     var44.notifyListeners(var45);
//     org.jfree.chart.ChartRenderingInfo var48 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var49 = new org.jfree.chart.plot.PlotRenderingInfo(var48);
//     java.awt.geom.Rectangle2D var50 = var49.getDataArea();
//     var44.setSeriesShape(1, (java.awt.Shape)var50, false);
//     org.jfree.chart.ChartRenderingInfo var53 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
//     java.awt.geom.Rectangle2D var55 = var54.getDataArea();
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var55, 1.0d, (-1.0d));
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = org.jfree.chart.util.RectangleEdge.coordinate(var55, var59);
//     org.jfree.chart.title.TextTitle var61 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var62 = null;
//     var61.removeChangeListener(var62);
//     org.jfree.chart.util.RectangleEdge var64 = var61.getPosition();
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     org.jfree.chart.axis.AxisState var66 = var0.draw(var42, 0.0d, var50, var55, var64, var65);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
//     var4.clearDomainMarkers(0);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     var13.setDataset(10, var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
//     java.awt.geom.Rectangle2D var20 = var19.getDataArea();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var20, 1.0d, (-1.0d));
//     var13.drawBackgroundImage(var17, var20);
//     var4.drawBackgroundImage(var8, var20);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("TextBlockAnchor.BOTTOM_LEFT", "AxisLocation.TOP_OR_LEFT", "NOID", var3, "hi!", "", "Range[0.0,0.0]");

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getColumnKey((-100));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    var0.setItemLabelAnchorOffset(4.0d);
    org.jfree.chart.ChartRenderingInfo var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
    java.awt.geom.Rectangle2D var10 = var9.getDataArea();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var10, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    var15.setRenderer(0, var17, true);
    java.awt.Paint var20 = var15.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var21 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var10, var20);
    var0.setSeriesShape(10, (java.awt.Shape)var10);
    boolean var23 = var0.getAutoPopulateSeriesPaint();
    java.awt.Paint var26 = var0.getItemFillPaint(0, 10);
    var0.setSeriesVisibleInLegend(15, (java.lang.Boolean)false);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var0.setSeriesToolTipGenerator(0, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.Range var3 = null;
//     org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var9 = var7.toFixedHeight(0.0d);
//     org.jfree.data.Range var10 = var7.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var11 = var7.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var12 = var1.arrange(var2, var7);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var1 = null;
//     var0.removeChangeListener(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var6, 1.0d, (-1.0d));
//     var0.draw(var3, var6);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     var20.setDataset(10, var22);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     java.awt.geom.Rectangle2D var27 = var26.getDataArea();
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var27, 1.0d, (-1.0d));
//     var20.drawBackgroundImage(var24, var27);
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var32.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var33);
//     java.awt.Paint var35 = var32.getBaseOutlinePaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("Size2D[width=-1.0, height=10.0]", "Category Plot", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]", "Range[0.0,0.0]", (java.awt.Shape)var27, var35);
//     var0.draw(var11, var27);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 8.0d);
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedHeight(0.0d);
//     org.jfree.data.Range var14 = var11.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var15 = var11.toUnconstrainedHeight();
//     org.jfree.data.Range var16 = null;
//     org.jfree.data.Range var18 = org.jfree.data.Range.expandToInclude(var16, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(var18, 1.0d);
//     org.jfree.data.Range var22 = org.jfree.data.Range.expandToInclude(var18, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var23 = var11.toRangeWidth(var18);
//     org.jfree.chart.util.Size2D var24 = var4.arrange(var5, var6, var23);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var3 = var1.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var4 = var1.getNegativeItemLabelPositionFallback();
    var1.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var9 = var7.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var12 = var7.getPositiveItemLabelPosition(1, 1);
    var1.setPositiveItemLabelPositionFallback(var12);
    org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var17 = var16.getFont();
    var1.setSeriesItemLabelFont(100, var17);
    org.jfree.chart.plot.CategoryPlot var19 = var1.getPlot();
    java.awt.Font var21 = var1.getSeriesItemLabelFont(15);
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Font var25 = var24.getFont();
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var28 = var26.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var29 = var26.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var31 = null;
    var26.setSeriesItemLabelGenerator(10, var31);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var26.setSeriesToolTipGenerator(100, var34);
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var38 = var36.lookupSeriesPaint(1);
    var26.setBaseOutlinePaint(var38, false);
    org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("NOID", var25, var38, 0.0f);
    var1.setBaseItemLabelPaint(var38, true);
    java.awt.Stroke var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(3.0d, var38, var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 1.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var4.toFixedHeight(0.0d);
    org.jfree.data.Range var7 = var4.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var8 = var4.toUnconstrainedHeight();
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
    org.jfree.chart.block.RectangleConstraint var12 = var8.toRangeWidth(var11);
    double var13 = var11.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.clearRangeMarkers(0);
//     float var10 = var7.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     var11.removeLegend();
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(var15, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var19 = var17.toFixedHeight(0.0d);
//     boolean var20 = var11.equals((java.lang.Object)var17);
//     org.jfree.chart.util.Size2D var21 = var4.arrange(var5, var6, var17);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var4 = var1.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var1.addRangeMarker((org.jfree.chart.plot.Marker)var6);
//     org.jfree.chart.util.LengthAdjustmentType var8 = var6.getLabelOffsetType();
//     java.awt.Font var9 = var6.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearRangeMarkers(0);
//     float var13 = var10.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     int var15 = var10.getDomainAxisIndex(var14);
//     java.lang.String var16 = var10.getPlotType();
//     org.jfree.chart.util.SortOrder var17 = var10.getRowRenderingOrder();
//     var10.clearDomainAxes();
//     org.jfree.chart.axis.AxisSpace var19 = var10.getFixedDomainAxisSpace();
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var22 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var21.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var22);
//     org.jfree.chart.event.RendererChangeEvent var24 = null;
//     var21.notifyListeners(var24);
//     var21.setItemLabelAnchorOffset(4.0d);
//     var10.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21, true);
//     java.awt.Shape var32 = var21.getItemShape(10, 0);
//     java.awt.Paint var33 = var21.getBasePaint();
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.text.G2TextMeasurer var36 = new org.jfree.chart.text.G2TextMeasurer(var35);
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("CONTRACT", var9, var33, 0.0f, (org.jfree.chart.text.TextMeasurer)var36);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SortOrder.ASCENDING", var1);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5);
    org.jfree.chart.util.LengthAdjustmentType var7 = var5.getLabelOffsetType();
    java.awt.Stroke var8 = var5.getStroke();
    org.jfree.chart.text.TextAnchor var9 = var5.getLabelTextAnchor();
    org.jfree.chart.event.MarkerChangeEvent var10 = null;
    var5.notifyListeners(var10);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.clearRangeMarkers(0);
    float var15 = var12.getBackgroundImageAlpha();
    org.jfree.chart.axis.AxisSpace var16 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var20 = var17.getRowRenderingOrder();
    boolean var21 = var16.equals((java.lang.Object)var20);
    java.lang.Object var22 = var16.clone();
    var12.setFixedDomainAxisSpace(var16);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    var24.setRenderer(0, var26, true);
    java.lang.Object var29 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var24);
    org.jfree.chart.axis.AxisLocation var30 = var24.getRangeAxisLocation();
    java.lang.String var31 = var30.toString();
    var12.setDomainAxisLocation(var30);
    float var33 = var12.getBackgroundImageAlpha();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var37 = var34.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var34.addRangeMarker((org.jfree.chart.plot.Marker)var39);
    java.awt.Paint var41 = var39.getLabelPaint();
    var12.setRangeGridlinePaint(var41);
    java.awt.Color var46 = java.awt.Color.getHSBColor(1.0f, 0.0f, 100.0f);
    var12.setBackgroundPaint((java.awt.Paint)var46);
    var5.setPaint((java.awt.Paint)var46);
    org.jfree.chart.util.RectangleInsets var49 = var5.getLabelOffset();
    double var50 = var49.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "AxisLocation.TOP_OR_LEFT"+ "'", var31.equals("AxisLocation.TOP_OR_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 3.0d);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 1.0d);
//     org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
//     java.awt.Paint var6 = null;
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Paint var8 = null;
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Stroke[] var12 = null;
//     java.awt.Shape var13 = null;
//     java.awt.Shape[] var14 = new java.awt.Shape[] { var13};
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var9, var11, var12, var14);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
//     var17.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var20 = var17.getStandardTickUnits();
//     boolean var21 = var15.equals((java.lang.Object)var17);
//     org.jfree.data.Range var22 = null;
//     org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 1.0d);
//     org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var24, 0.0d);
//     var17.setRangeWithMargins(var24, true, false);
//     org.jfree.chart.block.RectangleConstraint var32 = var4.toRangeWidth(var24);
//     java.awt.Paint var33 = null;
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke[] var39 = null;
//     java.awt.Shape var40 = null;
//     java.awt.Shape[] var41 = new java.awt.Shape[] { var40};
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var36, var38, var39, var41);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("");
//     var44.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var47 = var44.getStandardTickUnits();
//     boolean var48 = var42.equals((java.lang.Object)var44);
//     org.jfree.data.Range var49 = null;
//     org.jfree.data.Range var51 = org.jfree.data.Range.expandToInclude(var49, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(var51, 1.0d);
//     org.jfree.data.Range var55 = org.jfree.data.Range.expandToInclude(var51, 0.0d);
//     var44.setRangeWithMargins(var51, true, false);
//     org.jfree.chart.block.RectangleConstraint var59 = var32.toRangeWidth(var51);
//     
//     // Checks the contract:  equals-hashcode on var15 and var42
//     assertTrue("Contract failed: equals-hashcode on var15 and var42", var15.equals(var42) ? var15.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var15
//     assertTrue("Contract failed: equals-hashcode on var42 and var15", var42.equals(var15) ? var42.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var47
//     assertTrue("Contract failed: equals-hashcode on var20 and var47", var20.equals(var47) ? var20.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var20
//     assertTrue("Contract failed: equals-hashcode on var47 and var20", var47.equals(var20) ? var47.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation();
    java.awt.Image var7 = var0.getBackgroundImage();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var10 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var9.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var10);
    org.jfree.chart.event.RendererChangeEvent var12 = null;
    var9.notifyListeners(var12);
    var9.setItemLabelAnchorOffset(4.0d);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.clearRangeMarkers(0);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
    var21.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var24 = var21.getStandardTickUnits();
    var21.setLabelToolTip("SortOrder.ASCENDING");
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    java.awt.geom.Rectangle2D var29 = var28.getDataArea();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var29, 100.0d, 10.0f, 10.0f);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    var34.setRenderer(0, var36, true);
    java.awt.Paint var39 = var34.getRangeCrosshairPaint();
    org.jfree.chart.title.LegendGraphic var40 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var29, var39);
    var9.drawRangeGridline(var16, var17, (org.jfree.chart.axis.ValueAxis)var21, var29, (-1.0d));
    org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var45 = var43.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var46 = var43.getNegativeItemLabelPositionFallback();
    var43.setDrawBarOutline(true);
    org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var51 = var49.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var54 = var49.getPositiveItemLabelPosition(1, 1);
    var43.setPositiveItemLabelPositionFallback(var54);
    var9.setBaseNegativeItemLabelPosition(var54, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-100), (org.jfree.chart.renderer.category.CategoryItemRenderer)var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var5 = var4.getPaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearRangeMarkers(0);
//     float var9 = var6.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     int var11 = var6.getDomainAxisIndex(var10);
//     java.lang.String var12 = var6.getPlotType();
//     org.jfree.chart.util.RectangleInsets var13 = var6.getInsets();
//     var4.setMargin(var13);
//     double var16 = var13.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.TickUnits var17 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var18 = var17.clone();
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var21 = var20.getDataArea();
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var21);
//     boolean var23 = var17.equals((java.lang.Object)var21);
//     java.awt.geom.Rectangle2D var26 = var13.createOutsetRectangle(var21, false, false);
//     var0.drawBackgroundImage(var3, var21);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var3 = var0.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5);
    org.jfree.chart.util.LengthAdjustmentType var7 = var5.getLabelOffsetType();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperBound(8.0d);
    java.awt.Stroke var12 = var9.getAxisLineStroke();
    var5.setStroke(var12);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearRangeMarkers(0);
    org.jfree.chart.util.SortOrder var17 = var14.getRowRenderingOrder();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
    var14.addRangeMarker((org.jfree.chart.plot.Marker)var19);
    org.jfree.chart.util.LengthAdjustmentType var21 = var19.getLabelOffsetType();
    java.awt.Font var22 = var19.getLabelFont();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearRangeMarkers(0);
    float var26 = var23.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var27 = null;
    int var28 = var23.getDomainAxisIndex(var27);
    java.lang.String var29 = var23.getPlotType();
    org.jfree.chart.util.RectangleInsets var30 = var23.getInsets();
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    var31.setRenderer(0, var33, true);
    java.awt.Paint var36 = var31.getRangeCrosshairPaint();
    org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(var30, var36);
    org.jfree.chart.util.RectangleInsets var38 = var37.getInsets();
    java.lang.String var39 = var38.toString();
    var19.setLabelOffset(var38);
    org.jfree.chart.util.RectangleAnchor var41 = var19.getLabelAnchor();
    var5.setLabelAnchor(var41);
    org.jfree.chart.text.TextBlockAnchor var43 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var46 = new org.jfree.chart.axis.CategoryLabelPosition(var41, var43, var44, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "Category Plot"+ "'", var29.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var39.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var4 = null;
    int var5 = var0.getDomainAxisIndex(var4);
    java.lang.String var6 = var0.getPlotType();
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    var0.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var9 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.util.RectangleEdge var11 = var0.getRangeAxisEdge(0);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var12, false);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.ItemLabelPosition var18 = var15.getNegativeItemLabelPositionFallback();
    var15.setDrawBarOutline(true);
    java.awt.Stroke var21 = var15.getBaseOutlineStroke();
    var12.setBaseOutlineStroke(var21);
    org.jfree.chart.annotations.CategoryAnnotation var23 = null;
    org.jfree.chart.util.Layer var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.addAnnotation(var23, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Category Plot"+ "'", var6.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearRangeMarkers(0);
//     float var5 = var2.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var2.getDomainAxisIndex(var6);
//     java.lang.String var8 = var2.getPlotType();
//     org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
//     var0.setMargin(var9);
//     double var12 = var9.calculateTopInset(3.0d);
//     double var13 = var9.getBottom();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var15.removeChangeListener(var16);
//     double var18 = var15.getContentXOffset();
//     org.jfree.data.KeyedObject var19 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var15);
//     org.jfree.chart.block.BlockResult var20 = new org.jfree.chart.block.BlockResult();
//     var19.setObject((java.lang.Object)var20);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var23 = var22.getPaint();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var25 = var24.getPaint();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearRangeMarkers(0);
//     float var29 = var26.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     int var31 = var26.getDomainAxisIndex(var30);
//     java.lang.String var32 = var26.getPlotType();
//     org.jfree.chart.util.RectangleInsets var33 = var26.getInsets();
//     var24.setMargin(var33);
//     double var36 = var33.calculateTopOutset(100.0d);
//     var22.setMargin(var33);
//     var19.setObject((java.lang.Object)var33);
//     double var39 = var33.getRight();
//     double var41 = var33.calculateLeftInset(10.0d);
//     boolean var42 = var9.equals((java.lang.Object)var33);
//     
//     // Checks the contract:  equals-hashcode on var2 and var26
//     assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var2
//     assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isBorderVisible();
//     int var6 = var4.getBackgroundImageAlignment();
//     java.awt.Image var7 = var4.getBackgroundImage();
//     var4.removeLegend();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     var9.setRenderer(0, var11, true);
//     java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     var9.setRangeAxis(0, var16);
//     var9.setWeight(100);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.clearRangeMarkers(0);
//     float var23 = var20.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     var24.removeLegend();
//     org.jfree.data.Range var26 = null;
//     org.jfree.data.Range var28 = org.jfree.data.Range.expandToInclude(var26, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(var28, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var32 = var30.toFixedHeight(0.0d);
//     boolean var33 = var24.equals((java.lang.Object)var30);
//     var9.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
//     org.jfree.chart.event.ChartProgressListener var35 = null;
//     var24.addProgressListener(var35);
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var39 = null;
//     var38.removeChangeListener(var39);
//     double var41 = var38.getContentXOffset();
//     org.jfree.data.KeyedObject var42 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var38);
//     org.jfree.chart.util.HorizontalAlignment var43 = var38.getHorizontalAlignment();
//     org.jfree.chart.event.TitleChangeEvent var44 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var38);
//     var24.titleChanged(var44);
//     var4.titleChanged(var44);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var24
//     assertTrue("Contract failed: equals-hashcode on var4 and var24", var4.equals(var24) ? var4.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var4
//     assertTrue("Contract failed: equals-hashcode on var24 and var4", var24.equals(var4) ? var24.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    var0.add(0.2d, 4.0d, (java.lang.Comparable)16.0d, (java.lang.Comparable)"0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + 0.0d+ "'", var1.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var13, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     var18.setRenderer(0, var20, true);
//     java.awt.Paint var23 = var18.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var24 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var13, var23);
//     var0.setSeriesPaint(0, var23);
//     org.jfree.chart.ChartRenderingInfo var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
//     java.awt.geom.Rectangle2D var28 = var27.getDataArea();
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var28, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     var33.setRenderer(0, var35, true);
//     java.awt.Paint var38 = var33.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var39 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var28, var38);
//     var39.setLineVisible(false);
//     java.awt.Shape var42 = var39.getShape();
//     java.awt.Paint var43 = var39.getFillPaint();
//     org.jfree.chart.util.RectangleAnchor var44 = var39.getShapeAnchor();
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var48 = var45.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var45.addRangeMarker((org.jfree.chart.plot.Marker)var50);
//     java.awt.Paint var52 = var50.getLabelPaint();
//     var39.setLinePaint(var52);
//     var0.setBasePaint(var52, false);
//     
//     // Checks the contract:  equals-hashcode on var12 and var27
//     assertTrue("Contract failed: equals-hashcode on var12 and var27", var12.equals(var27) ? var12.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var12
//     assertTrue("Contract failed: equals-hashcode on var27 and var12", var27.equals(var12) ? var27.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var33
//     assertTrue("Contract failed: equals-hashcode on var18 and var33", var18.equals(var33) ? var18.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var18
//     assertTrue("Contract failed: equals-hashcode on var33 and var18", var33.equals(var18) ? var33.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.event.RendererChangeEvent var1 = null;
//     var0.notifyListeners(var1);
//     org.jfree.chart.ChartRenderingInfo var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = new org.jfree.chart.plot.PlotRenderingInfo(var4);
//     java.awt.geom.Rectangle2D var6 = var5.getDataArea();
//     var0.setSeriesShape(1, (java.awt.Shape)var6, false);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var0.getPositiveItemLabelPositionFallback();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var11 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var10.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var11);
//     org.jfree.chart.event.RendererChangeEvent var13 = null;
//     var10.notifyListeners(var13);
//     var10.setItemLabelAnchorOffset(4.0d);
//     org.jfree.chart.ChartRenderingInfo var18 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = new org.jfree.chart.plot.PlotRenderingInfo(var18);
//     java.awt.geom.Rectangle2D var20 = var19.getDataArea();
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var20, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var25.setRenderer(0, var27, true);
//     java.awt.Paint var30 = var25.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var31 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var20, var30);
//     var10.setSeriesShape(10, (java.awt.Shape)var20);
//     boolean var33 = var10.getAutoPopulateSeriesPaint();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var10.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var10.getSeriesPositiveItemLabelPosition(15);
//     var0.setNegativeItemLabelPositionFallback(var37);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 8.0d);
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var9, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var13 = var11.toFixedHeight(0.0d);
//     org.jfree.chart.util.Size2D var14 = var4.arrange(var5, var6, var11);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    float var3 = var0.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
    boolean var5 = var4.isBorderVisible();
    java.lang.Object var6 = var4.clone();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var9.removeChangeListener(var10);
    double var12 = var9.getContentXOffset();
    org.jfree.data.KeyedObject var13 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var9);
    org.jfree.chart.util.HorizontalAlignment var14 = var9.getHorizontalAlignment();
    double var15 = var9.getContentXOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addSubtitle(255, (org.jfree.chart.title.Title)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var4 = var1.getStandardTickUnits();
    var1.resizeRange(4.0d);
    var1.setLowerBound((-17.0d));
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getDataArea();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var11, 1.0d, (-1.0d));
    var1.setUpArrow((java.awt.Shape)var11);
    org.jfree.chart.util.RectangleInsets var16 = var1.getTickLabelInsets();
    java.awt.Shape var17 = var1.getLeftArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(0, var7);
    var0.setWeight(100);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.clearRangeMarkers(0);
    float var14 = var11.getBackgroundImageAlpha();
    org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    var15.removeLegend();
    org.jfree.data.Range var17 = null;
    org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, 1.0d);
    org.jfree.chart.block.RectangleConstraint var23 = var21.toFixedHeight(0.0d);
    boolean var24 = var15.equals((java.lang.Object)var21);
    var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
    int var26 = var15.getSubtitleCount();
    boolean var27 = var15.isBorderVisible();
    org.jfree.chart.plot.CategoryPlot var28 = var15.getCategoryPlot();
    org.jfree.chart.ChartRenderingInfo var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var33 = var15.createBufferedImage((-1), 0, 10, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var0.setRangeAxis(0, var7);
//     var0.setWeight(100);
//     var0.configureRangeAxes();
//     org.jfree.data.category.CategoryDataset var13 = var0.getDataset((-16777216));
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var15.removeChangeListener(var16);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     java.awt.geom.Rectangle2D var21 = var20.getDataArea();
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var21, 1.0d, (-1.0d));
//     var15.draw(var18, var21);
//     var0.drawBackground(var14, var21);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var1 = var0.getPaint();
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var3 = var2.getPaint();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearRangeMarkers(0);
//     float var7 = var4.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var4.getDomainAxisIndex(var8);
//     java.lang.String var10 = var4.getPlotType();
//     org.jfree.chart.util.RectangleInsets var11 = var4.getInsets();
//     var2.setMargin(var11);
//     double var14 = var11.calculateTopOutset(100.0d);
//     var0.setMargin(var11);
//     org.jfree.chart.util.UnitType var16 = var11.getUnitType();
//     org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets(var16, 92.0d, Double.POSITIVE_INFINITY, (-17.0d), 4.0d);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearRangeMarkers(0);
//     float var25 = var22.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     boolean var27 = var26.isBorderVisible();
//     org.jfree.chart.event.ChartProgressEvent var30 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)4.0d, var26, (-16777216), 0);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var4
//     assertTrue("Contract failed: equals-hashcode on var22 and var4", var22.equals(var4) ? var22.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(100.0d, 0.2d);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var4 = var1.getStandardTickUnits();
    var1.resizeRange(4.0d);
    var1.setLowerBound((-17.0d));
    java.lang.Object var9 = var1.clone();
    var1.setVerticalTickLabels(false);
    java.awt.Paint var12 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var0.setRangeAxis(0, var7);
//     var0.setWeight(100);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearRangeMarkers(0);
//     float var14 = var11.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     var15.removeLegend();
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var19 = org.jfree.data.Range.expandToInclude(var17, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var23 = var21.toFixedHeight(0.0d);
//     boolean var24 = var15.equals((java.lang.Object)var21);
//     var0.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var15);
//     org.jfree.chart.event.ChartProgressListener var26 = null;
//     var15.addProgressListener(var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var30 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var29.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var30);
//     org.jfree.chart.event.RendererChangeEvent var32 = null;
//     var29.notifyListeners(var32);
//     var29.setItemLabelAnchorOffset(4.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.Range var37 = var29.findRangeBounds((org.jfree.data.category.CategoryDataset)var36);
//     boolean var39 = var29.isSeriesVisible(0);
//     var29.setItemLabelAnchorOffset(0.0d);
//     java.awt.Paint var42 = var29.getBaseOutlinePaint();
//     org.jfree.chart.axis.TickUnits var43 = new org.jfree.chart.axis.TickUnits();
//     java.lang.Object var44 = var43.clone();
//     org.jfree.chart.ChartRenderingInfo var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var45);
//     java.awt.geom.Rectangle2D var47 = var46.getDataArea();
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var47);
//     boolean var49 = var43.equals((java.lang.Object)var47);
//     var29.setBaseShape((java.awt.Shape)var47);
//     java.awt.geom.Point2D var51 = null;
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     var15.draw(var28, var47, var51, var52);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearRangeMarkers(0);
    org.jfree.chart.axis.AxisLocation var4 = var0.getRangeAxisLocation(0);
    org.jfree.chart.plot.CategoryMarker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.notifyListeners(var1);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearRangeMarkers(0);
    float var7 = var4.getBackgroundImageAlpha();
    org.jfree.chart.axis.CategoryAxis var8 = null;
    int var9 = var4.getDomainAxisIndex(var8);
    java.lang.String var10 = var4.getPlotType();
    org.jfree.chart.util.SortOrder var11 = var4.getRowRenderingOrder();
    var4.clearDomainAxes();
    org.jfree.chart.axis.AxisSpace var13 = var4.getFixedDomainAxisSpace();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.util.StandardGradientPaintTransformer var16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var15.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var16);
    org.jfree.chart.event.RendererChangeEvent var18 = null;
    var15.notifyListeners(var18);
    var15.setItemLabelAnchorOffset(4.0d);
    var4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15, true);
    java.awt.Shape var26 = var15.getItemShape(10, 0);
    java.awt.Color var30 = java.awt.Color.getHSBColor(10.0f, 10.0f, 0.0f);
    java.lang.String var31 = var30.toString();
    java.lang.String var32 = var30.toString();
    org.jfree.chart.title.LegendGraphic var33 = new org.jfree.chart.title.LegendGraphic(var26, (java.awt.Paint)var30);
    var0.setSeriesItemLabelPaint(0, (java.awt.Paint)var30, false);
    org.jfree.chart.urls.CategoryURLGenerator var38 = var0.getURLGenerator((-2), 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "Category Plot"+ "'", var10.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var31.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var32.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     int var5 = var0.getDomainAxisIndex(var4);
//     java.lang.String var6 = var0.getPlotType();
//     var0.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.CategoryAxis[] var10 = null;
//     var0.setDomainAxes(var10);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
//     var11.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
//     boolean var15 = var9.equals((java.lang.Object)var11);
//     var11.setTickMarksVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var19 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var18.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var19);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     var23.setUpperBound(8.0d);
//     java.awt.Stroke var26 = var23.getAxisLineStroke();
//     var18.setSeriesOutlineStroke(0, var26, true);
//     var11.setAxisLineStroke(var26);
//     java.text.NumberFormat var30 = var11.getNumberFormatOverride();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     java.awt.geom.Rectangle2D var33 = var32.getDataArea();
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var33, 1.0d, (-1.0d));
//     org.jfree.chart.entity.AxisLabelEntity var39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var11, var36, "Category Plot", "[size=10]");
//     org.jfree.chart.ChartRenderingInfo var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = new org.jfree.chart.plot.PlotRenderingInfo(var40);
//     java.awt.geom.Rectangle2D var42 = var41.getDataArea();
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var42, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     var47.setRenderer(0, var49, true);
//     java.awt.Paint var52 = var47.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var53 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var42, var52);
//     var53.setLineVisible(false);
//     java.awt.Shape var56 = var53.getShape();
//     java.awt.Paint var57 = var53.getFillPaint();
//     org.jfree.chart.util.RectangleAnchor var58 = var53.getShapeAnchor();
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, var58, 100.0d, 10.0d);
//     
//     // Checks the contract:  equals-hashcode on var32 and var41
//     assertTrue("Contract failed: equals-hashcode on var32 and var41", var32.equals(var41) ? var32.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var32
//     assertTrue("Contract failed: equals-hashcode on var41 and var32", var41.equals(var32) ? var41.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
    var0.setRenderer(0, var2, true);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.lang.Object var8 = var7.clone();
    java.awt.geom.Point2D var9 = null;
    var0.zoomDomainAxes(0.0d, var7, var9);
    boolean var11 = var0.isRangeCrosshairVisible();
    org.jfree.chart.axis.AxisLocation var12 = var0.getRangeAxisLocation();
    org.jfree.chart.axis.AxisLocation var13 = org.jfree.chart.axis.AxisLocation.getOpposite(var12);
    org.jfree.chart.plot.PlotOrientation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var12, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearRangeMarkers(0);
//     float var3 = var0.getBackgroundImageAlpha();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var0);
//     boolean var5 = var4.isBorderVisible();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var8 = var7.getPaint();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearRangeMarkers(0);
//     float var12 = var9.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     int var14 = var9.getDomainAxisIndex(var13);
//     java.lang.String var15 = var9.getPlotType();
//     org.jfree.chart.util.RectangleInsets var16 = var9.getInsets();
//     var7.setMargin(var16);
//     double var19 = var16.calculateBottomInset(8.0d);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("");
//     var21.setFixedAutoRange((-1.0d));
//     org.jfree.chart.axis.TickUnitSource var24 = var21.getStandardTickUnits();
//     var21.resizeRange(4.0d);
//     var21.setLowerBound((-17.0d));
//     org.jfree.chart.ChartRenderingInfo var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = new org.jfree.chart.plot.PlotRenderingInfo(var29);
//     java.awt.geom.Rectangle2D var31 = var30.getDataArea();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var31, 1.0d, (-1.0d));
//     var21.setUpArrow((java.awt.Shape)var31);
//     java.awt.geom.Rectangle2D var36 = var16.createOutsetRectangle(var31);
//     org.jfree.chart.ChartRenderingInfo var37 = null;
//     var4.draw(var6, var36, var37);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Stroke var4 = null;
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    java.awt.Stroke[] var6 = null;
    java.awt.Shape var7 = null;
    java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
    org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("");
    var11.setFixedAutoRange((-1.0d));
    org.jfree.chart.axis.TickUnitSource var14 = var11.getStandardTickUnits();
    boolean var15 = var9.equals((java.lang.Object)var11);
    var11.setTickMarksVisible(false);
    var11.setFixedDimension(0.0d);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.axis.AxisSpace var25 = var24.getFixedDomainAxisSpace();
    boolean var26 = var24.isOutlineVisible();
    var11.setPlot((org.jfree.chart.plot.Plot)var24);
    org.jfree.chart.axis.TickUnits var29 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var30 = var29.clone();
    org.jfree.chart.ChartRenderingInfo var31 = null;
    org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
    java.awt.geom.Rectangle2D var33 = var32.getDataArea();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape)var33);
    boolean var35 = var29.equals((java.lang.Object)var33);
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var37 = null;
    var36.removeChangeListener(var37);
    org.jfree.chart.util.RectangleEdge var39 = var36.getPosition();
    double var40 = var11.lengthToJava2D(116.0d, var33, var39);
    org.jfree.data.Range var41 = var11.getRange();
    org.jfree.data.Range var44 = org.jfree.data.Range.shift(var41, 10.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Stroke var4 = null;
//     java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
//     java.awt.Stroke[] var6 = null;
//     java.awt.Shape var7 = null;
//     java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
//     org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var6, var8);
//     java.lang.Object var10 = var9.clone();
//     java.lang.Object var11 = var9.clone();
//     
//     // Checks the contract:  equals-hashcode on var10 and var11
//     assertTrue("Contract failed: equals-hashcode on var10 and var11", var10.equals(var11) ? var10.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var10
//     assertTrue("Contract failed: equals-hashcode on var11 and var10", var11.equals(var10) ? var11.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var2 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setSeriesItemLabelGenerator(10, var5);
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = null;
//     var0.setSeriesToolTipGenerator(100, var8);
//     org.jfree.chart.ChartRenderingInfo var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = new org.jfree.chart.plot.PlotRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getDataArea();
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape)var13, 100.0d, 10.0f, 10.0f);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     var18.setRenderer(0, var20, true);
//     java.awt.Paint var23 = var18.getRangeCrosshairPaint();
//     org.jfree.chart.title.LegendGraphic var24 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var13, var23);
//     var0.setSeriesPaint(0, var23);
//     org.jfree.chart.labels.ItemLabelPosition var27 = var0.getSeriesNegativeItemLabelPosition(1);
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var31 = var29.lookupSeriesFillPaint(10);
//     int var32 = var29.getRowCount();
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var34 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var33.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var34);
//     org.jfree.chart.event.RendererChangeEvent var36 = null;
//     var33.notifyListeners(var36);
//     var33.setItemLabelAnchorOffset(4.0d);
//     java.awt.Paint var40 = var33.getBaseOutlinePaint();
//     var29.setBaseOutlinePaint(var40);
//     org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var44 = var42.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var45 = var42.getNegativeItemLabelPositionFallback();
//     var42.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var50 = var48.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var53 = var48.getPositiveItemLabelPosition(1, 1);
//     var42.setPositiveItemLabelPositionFallback(var53);
//     var29.setNegativeItemLabelPositionFallback(var53);
//     var0.setSeriesNegativeItemLabelPosition(255, var53, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var48 and var0.", var48.equals(var0) == var0.equals(var48));
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    int var2 = var0.getColumnCount();
    int var4 = var0.getRowIndex((java.lang.Comparable)1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)"RectangleEdge.TOP");
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var2 = null;
//     var0.setRenderer(0, var2, true);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Point2D var9 = null;
//     var0.zoomDomainAxes(0.0d, var7, var9);
//     boolean var11 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     var13.clearRangeMarkers(0);
//     org.jfree.chart.util.SortOrder var16 = var13.getRowRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY);
//     var13.addRangeMarker((org.jfree.chart.plot.Marker)var18);
//     org.jfree.chart.util.LengthAdjustmentType var20 = var18.getLabelOffsetType();
//     java.awt.Font var21 = var18.getLabelFont();
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearRangeMarkers(0);
//     float var25 = var22.getBackgroundImageAlpha();
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     int var27 = var22.getDomainAxisIndex(var26);
//     java.lang.String var28 = var22.getPlotType();
//     org.jfree.chart.util.RectangleInsets var29 = var22.getInsets();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     var30.setRenderer(0, var32, true);
//     java.awt.Paint var35 = var30.getRangeCrosshairPaint();
//     org.jfree.chart.block.BlockBorder var36 = new org.jfree.chart.block.BlockBorder(var29, var35);
//     org.jfree.chart.util.RectangleInsets var37 = var36.getInsets();
//     java.lang.String var38 = var37.toString();
//     var18.setLabelOffset(var37);
//     org.jfree.chart.util.Layer var40 = null;
//     var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var18, var40);
//     
//     // Checks the contract:  equals-hashcode on var0 and var30
//     assertTrue("Contract failed: equals-hashcode on var0 and var30", var0.equals(var30) ? var0.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var0
//     assertTrue("Contract failed: equals-hashcode on var30 and var0", var30.equals(var0) ? var30.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var4 = var2.lookupSeriesFillPaint(10);
//     int var5 = var2.getRowCount();
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.util.StandardGradientPaintTransformer var7 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     var6.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var7);
//     org.jfree.chart.event.RendererChangeEvent var9 = null;
//     var6.notifyListeners(var9);
//     var6.setItemLabelAnchorOffset(4.0d);
//     java.awt.Paint var13 = var6.getBaseOutlinePaint();
//     var2.setBaseOutlinePaint(var13);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var17 = var15.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var15.getNegativeItemLabelPositionFallback();
//     var15.setDrawBarOutline(true);
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var23 = var21.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var21.getPositiveItemLabelPosition(1, 1);
//     var15.setPositiveItemLabelPositionFallback(var26);
//     var2.setNegativeItemLabelPositionFallback(var26);
//     org.jfree.chart.labels.CategoryToolTipGenerator var29 = var2.getBaseToolTipGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var31 = var2.getSeriesNegativeItemLabelPosition(0);
//     var0.setSeriesNegativeItemLabelPosition(255, var31, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var21 and var0.", var21.equals(var0) == var0.equals(var21));
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = var0.getObject("2");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.axis.CategoryLabelPositions var4 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var6 = null;
    var5.removeChangeListener(var6);
    org.jfree.chart.util.RectangleEdge var8 = var5.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var9 = var4.getLabelPosition(var8);
    org.jfree.chart.text.TextBlockAnchor var10 = var9.getLabelAnchor();
    org.jfree.chart.text.TextAnchor var11 = var9.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var13 = new org.jfree.chart.axis.NumberTick((java.lang.Number)Double.NaN, "UnitType.ABSOLUTE", var2, var11, Double.POSITIVE_INFINITY);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

}
